import { IonicNativePlugin } from '@ionic-native/core';
/**
 * @name Picture In Picture
 * @description
 * This plugin does something
 *
 * @usage
 * ```typescript
 * import { PictureInPicture } from '@ionic-native/picture-in-picture';
 *
 *
 * constructor(private pictureInPicture: PictureInPicture) { }
 *
 * ...
 *
 *
 * this.pictureInPicture.functionName('Hello', 123)
 *   .then((res: any) => console.log(res))
 *   .catch((error: any) => console.error(error));
 *
 * ```
 */
export declare class IRootOriginal extends IonicNativePlugin {
    /**
     * This function does something
     * @param arg1 {string} Some param to configure something
     * @param arg2 {number} Another param to configure something
     * @return {Promise<any>} Returns a promise that resolves when something happens
     */
    isRooted(): Promise<any>;
    isRootedWithBusyBox(): Promise<any>;
}

export declare const IRoot: IRootOriginal;