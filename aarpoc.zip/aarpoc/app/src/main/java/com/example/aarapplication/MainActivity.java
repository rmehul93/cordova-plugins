package com.example.aarapplication;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.wave.test.Wave2;
import com.wave.test.Wave2Callback;
import com.wave.test.exception.WaveInvalidArgsException;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Button btnOpenSdk;
    private Wave2 sdkInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intialiseSdk();
        setViews();
        

    }

    private void setViews() {
        btnOpenSdk = findViewById(R.id.btnOpenSdk);
        btnOpenSdk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Open sdk here
                JSONObject authData =null;
                try {

                    authData = new JSONObject("{\n" +
                            "        \"message\":\"Welcome to fisdom!\"\n" +
                            "      }");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    sdkInstance.startWave2(Wave2.environment.UAT, "testpartner", authData, "portfolio", false, Wave2.session.INTERVAL_NONE, Wave2.session.TIMEOUT_NEVER,
                            new Wave2Callback() {
                                @Override
                                public void onLaunchSuccess() {
                                    Log.d("SampleHost", "onLaunchSuccess");
                                }

                                @Override
                                public void onLaunchFailed(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onLaunchFailed");
                                }

                                @Override
                                public void onLoginSuccess(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onLoginSuccess");
                                }

                                @Override
                                public void onLoginFailed(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onLoginFailed");
                                }

                                @Override
                                public void onUserKycIsComplete(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onUserKycIsComplete");
                                }

                                @Override
                                public void onOrderPlaced(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onOrderPlaced");
                                }

                                @Override
                                public void onOrderFailed(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onOrderFailed");
                                }

                                @Override
                                public void onAnalyticsEvent(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onAnalyticsEvent");
                                }

                                @Override
                                public void onSDKClosed() {
                                    Log.d("SampleHost", "onSDKClosed");
                                }

                                @Override
                                public void onAdditionalData(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onAdditionalData");
                                }

                                @Override
                                public void onError(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onError");
                                }

                                @Override
                                public void onSessionPingReceived() {
                                    Log.d("SampleHost", "onSessionPingReceived");
                                }

                                @Override
                                public void onSessionTimeout(JSONObject jsonObject) {
                                    Log.d("SampleHost", "onSessionTimeout");
                                }
                            });
                } catch (WaveInvalidArgsException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void intialiseSdk() {
        sdkInstance = Wave2.getInstance(this);
    }
}