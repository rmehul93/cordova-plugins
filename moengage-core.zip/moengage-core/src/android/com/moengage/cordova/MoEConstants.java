package com.moengage.cordova;

public final class MoEConstants {
    
    public static final String MODULE_TAG = "MoECordova_";
    public static final String INTEGRATION_TYPE = "cordova";
    public static final String CORDOVA_PLUGIN_VERSION = "7.1.1";
    public static final String KEY_TYPE = "type";
}