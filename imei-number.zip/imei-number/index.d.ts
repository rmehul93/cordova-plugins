import { IonicNativePlugin } from '@ionic-native/core';
/**
 * @name IMEINumber In IMEINumber
 * @description
 * This plugin does something
 *
 * @usage
 */
export declare class IMEIOriginal extends IonicNativePlugin {
    /**
     * This function does something
     * @return {Promise<any>} Returns a promise that resolves when something happens
     */
    get(): Promise<any>;
}

export declare const IMEI: IMEIOriginal;