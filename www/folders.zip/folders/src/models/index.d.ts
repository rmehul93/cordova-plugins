import { ModelInit, MutableModel, PersistentModelConstructor } from "@aws-amplify/datastore";





export declare class AppInfo {
  readonly id: string;
  readonly sParamName: string;
  readonly sParamValue?: string;
  readonly sTenantId: string;
  constructor(init: ModelInit<AppInfo>);
  static copyOf(source: AppInfo, mutator: (draft: MutableModel<AppInfo>) => MutableModel<AppInfo> | void): AppInfo;
}

export declare class MsgInfo {
  readonly id: string;
  readonly sMsgCode: string;
  readonly sMessage?: string;
  readonly sTenantId: string;
  constructor(init: ModelInit<MsgInfo>);
  static copyOf(source: MsgInfo, mutator: (draft: MutableModel<MsgInfo>) => MutableModel<MsgInfo> | void): MsgInfo;
}

export declare class NewWatchListProfile {
  readonly id: string;
  readonly nWatchListId: number;
  readonly sWatchListName: string;
  readonly bIsPrivate?: boolean;
  readonly bIsDefault?: boolean;
  readonly sUserId: string;
  readonly sTenantId: string;
  constructor(init: ModelInit<NewWatchListProfile>);
  static copyOf(source: NewWatchListProfile, mutator: (draft: MutableModel<NewWatchListProfile>) => MutableModel<NewWatchListProfile> | void): NewWatchListProfile;
}

export declare class NewWatchListScrips {
  readonly id: string;
  readonly nWatchListId: number;
  readonly nMarketSegmetId: number;
  readonly nToken: number;
  readonly nSequenceNo?: number;
  readonly sUserId: string;
  readonly sTenantId: string;
  constructor(init: ModelInit<NewWatchListScrips>);
  static copyOf(source: NewWatchListScrips, mutator: (draft: MutableModel<NewWatchListScrips>) => MutableModel<NewWatchListScrips> | void): NewWatchListScrips;
}

export declare class UserPreference {
  readonly id: string;
  readonly sUserId: string;
  readonly sProfilePicPath?: string;
  readonly sOrder?: string;
  readonly sNotification?: string;
  readonly sInAppNotification?: string;
  readonly sTheme?: string;
  readonly sExchange?: string;
  readonly sTenantId: string;
  constructor(init: ModelInit<UserPreference>);
  static copyOf(source: UserPreference, mutator: (draft: MutableModel<UserPreference>) => MutableModel<UserPreference> | void): UserPreference;
}