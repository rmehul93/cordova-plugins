export const schema = {
    "models": {
        "AppInfo": {
            "name": "AppInfo",
            "fields": {
                "id": {
                    "name": "id",
                    "isArray": false,
                    "type": "ID",
                    "isRequired": true,
                    "attributes": []
                },
                "sParamName": {
                    "name": "sParamName",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "sParamValue": {
                    "name": "sParamValue",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sTenantId": {
                    "name": "sTenantId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                }
            },
            "syncable": true,
            "pluralName": "AppInfos",
            "attributes": [
                {
                    "type": "model",
                    "properties": {}
                },
                {
                    "type": "key",
                    "properties": {
                        "name": "byAppTenant",
                        "fields": [
                            "sTenantId",
                            "sParamName"
                        ],
                        "queryField": "appInfoByTenant"
                    }
                }
            ]
        },
        "MsgInfo": {
            "name": "MsgInfo",
            "fields": {
                "id": {
                    "name": "id",
                    "isArray": false,
                    "type": "ID",
                    "isRequired": true,
                    "attributes": []
                },
                "sMsgCode": {
                    "name": "sMsgCode",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "sMessage": {
                    "name": "sMessage",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sTenantId": {
                    "name": "sTenantId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                }
            },
            "syncable": true,
            "pluralName": "MsgInfos",
            "attributes": [
                {
                    "type": "model",
                    "properties": {}
                },
                {
                    "type": "key",
                    "properties": {
                        "name": "byMsgTenant",
                        "fields": [
                            "sTenantId",
                            "sMsgCode"
                        ],
                        "queryField": "msgInfoByTenant"
                    }
                }
            ]
        },
        "NewWatchListProfile": {
            "name": "NewWatchListProfile",
            "fields": {
                "id": {
                    "name": "id",
                    "isArray": false,
                    "type": "ID",
                    "isRequired": true,
                    "attributes": []
                },
                "nWatchListId": {
                    "name": "nWatchListId",
                    "isArray": false,
                    "type": "Int",
                    "isRequired": true,
                    "attributes": []
                },
                "sWatchListName": {
                    "name": "sWatchListName",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "bIsPrivate": {
                    "name": "bIsPrivate",
                    "isArray": false,
                    "type": "Boolean",
                    "isRequired": false,
                    "attributes": []
                },
                "bIsDefault": {
                    "name": "bIsDefault",
                    "isArray": false,
                    "type": "Boolean",
                    "isRequired": false,
                    "attributes": []
                },
                "sUserId": {
                    "name": "sUserId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "sTenantId": {
                    "name": "sTenantId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                }
            },
            "syncable": true,
            "pluralName": "NewWatchListProfiles",
            "attributes": [
                {
                    "type": "model",
                    "properties": {}
                },
                {
                    "type": "key",
                    "properties": {
                        "name": "byNewWatchListTenant",
                        "fields": [
                            "sTenantId",
                            "sUserId",
                            "nWatchListId"
                        ],
                        "queryField": "NewWatchListByTenant"
                    }
                }
            ]
        },
        "NewWatchListScrips": {
            "name": "NewWatchListScrips",
            "fields": {
                "id": {
                    "name": "id",
                    "isArray": false,
                    "type": "ID",
                    "isRequired": true,
                    "attributes": []
                },
                "nWatchListId": {
                    "name": "nWatchListId",
                    "isArray": false,
                    "type": "Int",
                    "isRequired": true,
                    "attributes": []
                },
                "nMarketSegmetId": {
                    "name": "nMarketSegmetId",
                    "isArray": false,
                    "type": "Int",
                    "isRequired": true,
                    "attributes": []
                },
                "nToken": {
                    "name": "nToken",
                    "isArray": false,
                    "type": "Int",
                    "isRequired": true,
                    "attributes": []
                },
                "nSequenceNo": {
                    "name": "nSequenceNo",
                    "isArray": false,
                    "type": "Int",
                    "isRequired": false,
                    "attributes": []
                },
                "sUserId": {
                    "name": "sUserId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "sTenantId": {
                    "name": "sTenantId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                }
            },
            "syncable": true,
            "pluralName": "NewWatchListScrips",
            "attributes": [
                {
                    "type": "model",
                    "properties": {}
                },
                {
                    "type": "key",
                    "properties": {
                        "name": "byProfile",
                        "fields": [
                            "sTenantId",
                            "sUserId",
                            "nWatchListId",
                            "nMarketSegmetId",
                            "nToken"
                        ]
                    }
                }
            ]
        },
        "UserPreference": {
            "name": "UserPreference",
            "fields": {
                "id": {
                    "name": "id",
                    "isArray": false,
                    "type": "ID",
                    "isRequired": true,
                    "attributes": []
                },
                "sUserId": {
                    "name": "sUserId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                },
                "sProfilePicPath": {
                    "name": "sProfilePicPath",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sOrder": {
                    "name": "sOrder",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sNotification": {
                    "name": "sNotification",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sInAppNotification": {
                    "name": "sInAppNotification",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sTheme": {
                    "name": "sTheme",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sExchange": {
                    "name": "sExchange",
                    "isArray": false,
                    "type": "String",
                    "isRequired": false,
                    "attributes": []
                },
                "sTenantId": {
                    "name": "sTenantId",
                    "isArray": false,
                    "type": "String",
                    "isRequired": true,
                    "attributes": []
                }
            },
            "syncable": true,
            "pluralName": "UserPreferences",
            "attributes": [
                {
                    "type": "model",
                    "properties": {}
                },
                {
                    "type": "key",
                    "properties": {
                        "name": "byUserPreferenceTenant",
                        "fields": [
                            "sTenantId",
                            "sUserId"
                        ],
                        "queryField": "userPreferenceByUserId"
                    }
                }
            ]
        }
    },
    "enums": {},
    "nonModels": {},
    "version": "5691ea4c2ac4c523176f240bcaed0af5"
};