// @ts-check
import { initSchema } from '@aws-amplify/datastore';
import { schema } from './schema';



const { AppInfo, MsgInfo, NewWatchListProfile, NewWatchListScrips, UserPreference } = initSchema(schema);

export {
  AppInfo,
  MsgInfo,
  NewWatchListProfile,
  NewWatchListScrips,
  UserPreference
};