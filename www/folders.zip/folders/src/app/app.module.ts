import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { DatePipe } from '@angular/common'; 
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
// plugins
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Device } from '@ionic-native/device/ngx';
import { Network } from '@ionic-native/network/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
//import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Insomnia } from '@ionic-native/insomnia/ngx';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { Push } from '@ionic-native/push/ngx';
import { SQLitePorter } from '@ionic-native/sqlite-porter/ngx';
import { SQLite } from '@ionic-native/sqlite/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx'; 
import { Camera } from '@ionic-native/camera/ngx';
import { FileTransfer} from '@ionic-native/file-transfer/ngx'; 
import {ScreenOrientation} from '@ionic-native/screen-orientation/ngx';
import {IRoot} from '@ionic-native/iroot/ngx';
// Appcomponent
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AppState } from './app.global';
// Components
import { ComponentsModule } from './components/components.module';

// Common 
import { clsHttpService, clsHTTPResponseInterceptor } from './Common/clsHTTPService';
import { createTranslateLoader } from './Common/clsCustomeTranslateLoader'; 
import { clsLocalStorageService } from './Common/clsLocalStorageService';
import { clsAppInitService } from './Common/clsAppInitService';

// Communicator
import { CommunicatorPageModule } from './communicator/communicator.module';
import {Events} from './communicator/clsEvents';
// Directives
import { DirectiveSharedModule } from './directives/directive.shared.module';

// Providers
//import { PouchCouchServicesProvider } from './providers/pouch-couch-services/pouch-couch-services';
import { LogServicesProvider } from './providers/log-services/log-services';
import { AlertServicesProvider } from './providers/alert-services/alert-services';
import { BrowserServicesProvider } from './providers/browser-services/browser-services';
import { CDSServicesProvider } from './providers/cds-services/cds.services';
import { ToastServicesProvider } from './providers/toast-services/toast.services';
import { LoaderServicesProvider } from './providers/loader-services/loader-services';
import { RouterExtService } from './providers/router-ext-service.service';
import { NavParamService } from './providers/nav-param.service';
import { DatabaseService } from './providers/database-services/database-services';
import { RestApiService } from './providers/rest-api.service';
import { SocketConfig } from './providers/socket.service';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { WatchlistService } from './providers/watchlist-service.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PopoverPage } from './components/pop-over/popover.page';
import { IndicesTickerPopoverComponent } from './components/indices-ticker-popover/indices-ticker-popover.component';
import { WatchlistloaderPage } from './pages/watchlistloader/watchlistloader.page';
import { CodeInputModule } from 'angular-code-input';
import { MultilegLookupPage } from './pages/multileg-lookup/multileg-lookup.page';
import { MultilegConfirmationPage } from './pages/multileg-confirmation/multileg-confirmation.page';
import { OptionChainPage } from './pages/option-chain/option-chain.page';

@NgModule({
  declarations: [AppComponent,PopoverPage,IndicesTickerPopoverComponent,WatchlistloaderPage,MultilegLookupPage,MultilegConfirmationPage,OptionChainPage],
  entryComponents: [PopoverPage,IndicesTickerPopoverComponent,WatchlistloaderPage,MultilegLookupPage,MultilegConfirmationPage,OptionChainPage],
  imports: [
    BrowserModule, CodeInputModule,
    IonicModule.forRoot(),
    BrowserAnimationsModule,
    AppRoutingModule,
    ComponentsModule,
    HttpClientModule,
    DirectiveSharedModule,
    FormsModule,
    ReactiveFormsModule,
    CommunicatorPageModule.forRoot(),
    //IonicStorageModule.forRoot(), 
    IonicStorageModule.forRoot({
      name: '__mydb',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [clsHttpService]
      }
    })
  ],
  providers: [
    AppState, StatusBar, Device, SplashScreen, Network, AppVersion, 
      Insomnia, SpeechRecognition, InAppBrowser, 
    Camera,FileTransfer,ScreenOrientation,
    MobileAccessibility, Push, SQLitePorter, 
    SQLite,LocalNotifications,SocketConfig,SocialSharing,IRoot,
    DatePipe,
    RouterExtService,
	  SmsRetriever, 
    clsAppInitService, 
    LogServicesProvider,
    AlertServicesProvider,
    Events,
    // OnePlaceAPIServiceProvider 	,
    BrowserServicesProvider,
    CDSServicesProvider,
    // ChatService 	,
    ToastServicesProvider,
    LoaderServicesProvider,
    RouterExtService,
    NavParamService,
    DatabaseService,
    clsHttpService,
    HttpClientModule,
    clsLocalStorageService,
    { provide: HTTP_INTERCEPTORS, useClass: clsHTTPResponseInterceptor, multi: true },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    RestApiService,
    WatchlistService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
   