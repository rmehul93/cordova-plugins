import { Directive, AfterViewInit, ElementRef } from '@angular/core'
import { HostListener, Input } from "@angular/core";
import { clsGlobal } from '../Common/clsGlobal';

@Directive({
  selector: '[alphaNum]'
})
export class AlphaNumericDirective {

  private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);
  currentValue = '';
  previousValue = '';

  constructor(private el: ElementRef) { }

  @HostListener('input', ['$event'])
  onInputChange(event: any) {//KeyboardEvent
    try {
      const target = event.target;
      const newValue = target.value;
      //let newValue = event.target.value;
      let regExp = new RegExp('^[A-Za-z0-9]+$');
      let result = regExp.test(newValue)
      //console.log('Key Value: ', newValue, ' result: ', result);
      if (!result) {
        event.preventDefault();
        event.stopPropagation();
        let orgValue = newValue.replace(/[^a-zA-Z0-9]/g, '');
        target.value = orgValue;// this will remove any special character.
        this.el.nativeElement.value = orgValue;
        return false;
        
      }

      this.previousValue = newValue;
      return true;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('AlphaNumeric', 'onKeyDown', error);
    }

  }

}
