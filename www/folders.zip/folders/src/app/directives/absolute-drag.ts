import { Directive, Input, ElementRef, Renderer2,Output,EventEmitter } from '@angular/core';
import { DomController } from '@ionic/angular';

@Directive({
  selector: '[absolute-drag]'
})
export class AbsoluteDrag  {

    @Input('startLeft') startLeft: any;
    @Input('stopLeft') stopLeft: any;
    @Output() onDragComplete = new EventEmitter();
    public hammer:any;
    constructor(public element: ElementRef, public renderer: Renderer2, public domCtrl: DomController) {
    }

    ngAfterViewInit() {

        this.renderer.setStyle(this.element.nativeElement, 'position', 'absolute');
        this.renderer.setStyle(this.element.nativeElement, 'left', this.startLeft + 'px');
        //this.renderer.setElementStyle(this.element.nativeElement, 'top', this.startTop + 'px');

        this.hammer = new window['Hammer'](this.element.nativeElement);
        this.hammer.get('pan').set({ direction: window['Hammer'].DIRECTION_HORIZONTAL });

        this.hammer.on('pan', (ev) => {
            this.handlePan(ev);
        });
    }

    handlePan(ev){
        const newLeft = ev.center.x;
        //let newTop = ev.center.y;
        //console.log(newLeft);

        this.domCtrl.write(() => {

             try {
              if(parseInt(this.stopLeft)>=newLeft){
                this.renderer.setStyle(this.element.nativeElement, 'left', this.stopLeft + 'px');
                this.onDragComplete.emit({drag:"done"});
                this.hammer.destroy();
                }
                else
                {
                  this.renderer.setStyle(this.element.nativeElement, 'left', newLeft + 'px');
                }
             } catch (error) {
               console.log(error);
             }


           // this.renderer.setElementStyle(this.element.nativeElement, 'top', newTop + 'px');
        });

    }
    ngOnDestroy() {
      this.hammer.destroy();
  }
}
