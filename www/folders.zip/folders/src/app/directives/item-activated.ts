import { Directive, Input, ElementRef, OnInit } from '@angular/core';
import { DomController } from '@ionic/angular';


@Directive({
  selector: '[itemactivate]'
})
export class ItemActive implements OnInit {

  @Input('scrollContent') scrollContext: ElementRef;

  constructor(public element: ElementRef) {
    // console.log('item-activated now.');
    // console.log('top: ' + this.element.nativeElement.getBoundingClientRect().top);
  }

  ngOnInit() {

    setTimeout(() => {
   
      // console.log('bottom: ' + this.element.nativeElement.getBoundingClientRect().bottom);
      let scrollBottom = this.scrollContext.nativeElement.contentTop + this.scrollContext.nativeElement.contentHeight;//this.scrollContext.getScrollElement().scrollHeight;
      // console.log('scrollBottom: ' + scrollBottom);
     // let contentBtm = this.element.nativeElement.getBoundingClientRect().bottom;
      let contentBtm = (this.scrollContext.nativeElement.contentTop)
      + parseInt(this.element.nativeElement.offsetTop) 
      + parseInt(this.element.nativeElement.offsetHeight);
     // console.log('calc bottom: ' + contentBtm);
      if (scrollBottom < contentBtm) {
       // console.log('Item not in view.');
        const diff = Math.abs(scrollBottom - contentBtm) + 10; //* 2 
        this.scrollContext.nativeElement.scrollTo(0, diff, 500);
      }
    }, 1);

  }

}
