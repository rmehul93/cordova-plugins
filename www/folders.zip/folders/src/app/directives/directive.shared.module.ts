import { CallBackPipe } from './call-back.pipe';
import { NgModule } from '@angular/core'; 
import { SwipeVertical } from '../directives/directive-swipe-vertical';
import { SwipeHorizontal } from './directive-swipe-horizontal';
import {AbsoluteDrag} from './absolute-drag' ;
import { MaxLengthDirective } from './max-length';
import { OnlyNumberDirective } from './numberOnly.directive';
import { NumberTestDirective, NumericDirective, TwoDigitDecimaNumberDirective,NewNumericDirective} from './numeric.directive';
import { ItemActive } from './item-activated';
import { ScrollHideDirective } from './scroll-hide.directive';
import { AlphaNumericDirective } from './alpha-numeric.directive';
import { UpperCaseDirective } from './upper-case.directive';


@NgModule({
	declarations: [ SwipeVertical,SwipeHorizontal,AbsoluteDrag,MaxLengthDirective,OnlyNumberDirective,NumericDirective,ItemActive,ScrollHideDirective,CallBackPipe,TwoDigitDecimaNumberDirective,NumberTestDirective,NewNumericDirective, AlphaNumericDirective, UpperCaseDirective],
    exports: [ SwipeVertical,SwipeHorizontal,AbsoluteDrag,MaxLengthDirective,OnlyNumberDirective,NumericDirective,ItemActive,ScrollHideDirective , CallBackPipe,TwoDigitDecimaNumberDirective,NumberTestDirective,NewNumericDirective,AlphaNumericDirective,UpperCaseDirective]
})
export class DirectiveSharedModule {
 
}
