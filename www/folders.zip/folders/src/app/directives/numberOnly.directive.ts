﻿
import { Directive, HostListener, Input, Output, EventEmitter, ElementRef } from '@angular/core';


@Directive({
    selector: '[OnlyNumber]'
})
export class OnlyNumberDirective {

    constructor(private inputRef: ElementRef) { }

    @Input() OnlyNumber: string;
    @Output() onKeyPassSuccess = new EventEmitter();

    @HostListener('keydown', ['$event']) onkeydown(event) {
        let e = <KeyboardEvent>event;
        if (this.OnlyNumber == 'true') {
            let backOrDelete = false;
            if ([46, 8, 9, 27, 13].indexOf(e.keyCode) !== -1 ||
                // Allow: Ctrl+A
                (e.keyCode == 65 && e.ctrlKey === true) ||
                // Allow: Ctrl+C
                (e.keyCode == 67 && e.ctrlKey === true) ||
                // Allow: Ctrl+X
                (e.keyCode == 88 && e.ctrlKey === true) ||
                // Allow: home, end, left, right
                (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything

                if (e.keyCode == 8 || e.keyCode == 46) {
                    backOrDelete = true;
                }
                if (e.keyCode != 9) {
                    setTimeout(function () { this.onKeyPassSuccess.emit({ itemRemoved: backOrDelete, event: this.inputRef }) }.bind(this), 150);
                }
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            } else {
                setTimeout(function () { this.onKeyPassSuccess.emit({ itemRemoved: backOrDelete, event: this.inputRef }) }.bind(this), 150);
            }
        }
        else {
            let backOrDelete = false;
            if ([46, 8, 9, 27, 13].indexOf(e.keyCode) !== -1 ||
                // Allow: Ctrl+A
                (e.keyCode == 65 && e.ctrlKey === true) ||
                // Allow: Ctrl+C
                (e.keyCode == 67 && e.ctrlKey === true) ||
                // Allow: Ctrl+X
                (e.keyCode == 88 && e.ctrlKey === true) ||
                // Allow: home, end, left, right
                (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything

                if (e.keyCode == 8 || e.keyCode == 46) {
                    backOrDelete = true;
                }
                setTimeout(function () { this.onKeyPassSuccess.emit({ itemRemoved: backOrDelete, event: this.inputRef }) }.bind(this), 150);
                return;
            }
            // Ensure that it is a number and stop the keypress
            if (e.keyCode == 32) {
                e.preventDefault();
            } else {
                setTimeout(function () { this.onKeyPassSuccess.emit({ itemRemoved: backOrDelete, event: this.inputRef }) }.bind(this), 150);
            }
        }
    }
}

