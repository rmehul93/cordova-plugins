import { Directive, AfterViewInit, ElementRef } from '@angular/core'
import { HostListener, Input } from "@angular/core";
import { NgModel } from '@angular/forms';
import { ToastServicesProvider } from '../providers/toast-services/toast.services';

@Directive({ selector: "[numericDir1]" })
export class NumericDirective implements AfterViewInit {

    @Input() allowDecimals: boolean = true;
    @Input() allowSign: boolean = false;
    @Input() decimalSeparator: string = '.';
    @Input() precision: string = '2';
    @Input() requirePlaceHolder: boolean = false;

    previousValue: string = '';

    // --------------------------------------
    //  Regular expressions
    integerUnsigned: string = '^[0-9]*$';
    integerSigned: string = '^-?[0-9]+$';
    decimalUnsigned: string = '^\\d+(\\.\\d{1,' + this.precision + '})?$';//'^[0-9]+(.[0-9]{1,2}+)?$';
    decimalSigned: string = '^\\d+(\\.\\d{1,' + this.precision + '})?$';//'^-?[0-9]+(.[0-9]{1,2}+)?$';

    /**
     * Class constructor
     * @param hostElement
     */
    constructor(private hostElement: ElementRef) {

    }

    ngAfterViewInit() {
        this.decimalUnsigned = '^(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
        this.decimalSigned = '^(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
    }

    /**
     * Event handler for host's paste event
     * @param e
     */
    @HostListener('paste', ['$event']) onPaste(e) {

        // get and validate data from clipboard
        let value = e.clipboardData.getData('text/plain');
        this.validateValue(value);
        e.preventDefault();
    }

    @HostListener('focus', ['$event']) onFocus(e) {

        if (this.requirePlaceHolder && this.hostElement.nativeElement.value == '') {
            this.hostElement.nativeElement.placeholder = ''
        }
    }

    @HostListener('blur', ['$event']) onBlur(e) {

        if (this.requirePlaceHolder && this.hostElement.nativeElement.value == '') {
            this.hostElement.nativeElement.placeholder = this.allowDecimals ? (0).toFixed(parseInt(this.precision)) : '0';
        }
    }

    // @HostListener('input', ['$event']) onInputChange(event) {
    //     const initalValue = this.hostElement.nativeElement.value;
    //     this.hostElement.nativeElement.value  = initalValue.replace(/[^0-9]*/g, '');
    //     if ( initalValue !== this.hostElement.nativeElement.value) {
    //         event.preventDefault();
    //     }
    //   }


    /**
     * Event handler for host's keydown event
     * @param event
     */
    @HostListener('keyup', ['$event']) onKeyDown(e: KeyboardEvent) {

        // let regex: string;
        // if (!this.allowDecimals && !this.allowSign) { regex = this.integerUnsigned; }
        // else if (!this.allowDecimals && this.allowSign) { regex = this.integerSigned; }
        // else if (this.allowDecimals && !this.allowSign) {
        //     this.decimalUnsigned = '^(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
        //     regex = this.decimalUnsigned;
        // }
        // else if (this.allowDecimals && this.allowSign) {
        //     this.decimalSigned = '^(\\-)?(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
        //     //this.decimalSigned = '^\\-?[0-9]+(\.[0-9]{1,2}+)?$'
        //     regex = this.decimalSigned;
        // }

        // const initalValue = this.hostElement.nativeElement.value;
        // this.hostElement.nativeElement.value  = initalValue.replace(/^(\\-)?(\\d+)?(\\.\\d{0,2})?/g, '');
        // if ( initalValue !== this.hostElement.nativeElement.value) {
        //     e.preventDefault();
        // }

        let cursorPosition: number = e.target['selectionStart'];
        let originalValue: string = e.target['value'];
        let key: string = this.getName(e);
        let controlOrCommand = (e.ctrlKey === true || e.metaKey === true);
        let signExists = originalValue.includes('-');
        let separatorExists = originalValue.includes(this.decimalSeparator);

        // allowed keys apart from numeric characters
        let allowedKeys = [
            'Backspace', 'ArrowLeft', 'ArrowRight', 'Escape', 'Tab'
        ];

        // when decimals are allowed, add
        // decimal separator to allowed codes when
        // its position is not close to the the sign (-. and .-)
        let separatorIsCloseToSign = (signExists && cursorPosition <= 1);
        if (this.allowDecimals && !separatorIsCloseToSign && !separatorExists) {

            if (this.decimalSeparator == '.')
                allowedKeys.push('.');
            else
                allowedKeys.push(',');
        }

        // when minus sign is allowed, add its
        // key to allowed key only when the
        // cursor is in the first position, and
        // first character is different from
        // decimal separator
        let firstCharacterIsSeparator = (originalValue.charAt(0) != this.decimalSeparator);
        if (this.allowSign && !signExists &&
            firstCharacterIsSeparator && cursorPosition == 0) {

            allowedKeys.push('-');
        }

        if (this.requirePlaceHolder && this.hostElement.nativeElement.value != '') {
            this.hostElement.nativeElement.placeholder = this.allowDecimals ? (0).toFixed(parseInt(this.precision)) : '0';
        } else {
            this.hostElement.nativeElement.placeholder = '';
        }

        // allow some non-numeric characters
        if (allowedKeys.indexOf(key) != -1 ||
            // Allow: Ctrl+A and Command+A
            (key == 'a' && controlOrCommand) ||
            // Allow: Ctrl+C and Command+C
            (key == 'c' && controlOrCommand) ||
            // Allow: Ctrl+V and Command+V
            (key == 'v' && controlOrCommand) ||
            // Allow: Ctrl+X and Command+X
            (key == 'x' && controlOrCommand)) {
            // let it happen, don't do anything
            return;
        }

        // save value before keydown event
        //this.previousValue = originalValue;

        // allow number characters only
        let regex: string;
        if (!this.allowDecimals && !this.allowSign) { regex = this.integerUnsigned; }
        else if (!this.allowDecimals && this.allowSign) { regex = this.integerSigned; }
        else if (this.allowDecimals && !this.allowSign) {
            this.decimalUnsigned = '^(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
            regex = this.decimalUnsigned;
        }
        else if (this.allowDecimals && this.allowSign) {
            this.decimalSigned = '^(\\-)?(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
            //this.decimalSigned = '^\\-?[0-9]+(\.[0-9]{1,2}+)?$'
            regex = this.decimalSigned;
        }


        //let isNumber = (new RegExp(this.integerUnsigned)).test(key);
        //let currValue = [originalValue.slice(0, cursorPosition), key, originalValue.slice(cursorPosition)].join('');
        //let isNumber = (new RegExp(regex)).test(currValue);
        //console.log('Entered value: ',originalValue);
        let isNumber = (new RegExp(regex)).test(originalValue);
        if (isNumber) {
            //this.previousValue = originalValue;
            return;
        } else {
            //let newValue = 1;
            //this._renderer.setElementProperty(this.hostElement.nativeElement, 'value', newValue);
            //this.hostElement._renderer.setElementProperty(this.hostElement.getNativeElement(),"value",1);
            this.previousValue = [originalValue.slice(0, cursorPosition - 1), originalValue.slice(cursorPosition)].join('');
            //console.log('previous value: ',this.previousValue);
            this.hostElement.nativeElement.value = (this.previousValue || '');
            e.preventDefault();
            e.stopPropagation();
            return false;
        };

    }

    /**
     * Test whether value is a valid number or not
     * @param value
     */
    validateValue(value: string): void {

        // choose the appropiate regular expression
        let regex: string;
        if (!this.allowDecimals && !this.allowSign) { regex = this.integerUnsigned; }
        else if (!this.allowDecimals && this.allowSign) { regex = this.integerSigned; }
        else if (this.allowDecimals && !this.allowSign) {
            this.decimalUnsigned = '^(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
            regex = this.decimalUnsigned;
        }
        else if (this.allowDecimals && this.allowSign) {
            this.decimalSigned = '^(\\-)?(\\d+)?(\\.\\d{0,' + this.precision + '})?$';
            regex = this.decimalSigned;
        }

        // when a numbers begins with a decimal separator,
        // fix it adding a zero in the beginning
        let firstCharacter = value.charAt(0);
        if (firstCharacter == this.decimalSeparator)
            value = 0 + value;

        // when a numbers ends with a decimal separator,
        // fix it adding a zero in the end
        let lastCharacter = value.charAt(value.length - 1);
        if (lastCharacter == this.decimalSeparator)
            value = value + 0;

        // test number with regular expression, when
        // number is invalid, replace it with a zero
        let valid: boolean = (new RegExp(regex)).test(value);
        //this.hostElement.nativeElement['value'] = valid ? value : 0;
        this.hostElement.nativeElement.value = (valid ? value : 0);
    }

    /**
     * Get key's name
     * @param e
     */
    getName(e): string {

        if (e.key) {

            return e.key;

        } else {

            // for old browsers
            if (e.keyCode && String.fromCharCode) {

                switch (e.keyCode) {
                    case 8: return 'Backspace';
                    case 9: return 'Tab';
                    case 27: return 'Escape';
                    case 37: return 'ArrowLeft';
                    case 39: return 'ArrowRight';
                    case 188: return ',';
                    case 190: return '.';
                    case 109: return '-'; // minus in numbpad
                    case 173: return '-'; // minus in alphabet keyboard in firefox
                    case 189: return '-'; // minus in alphabet keyboard in chrome
                    default: return String.fromCharCode(e.keyCode);
                }
            }
        }
    }

}

@Directive({
    selector: '[numericDir3]',
})
export class TwoDigitDecimaNumberDirective {

    private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

    private regexIntSigned: RegExp = new RegExp(/^-?[0-9]*$/g);
    private regexIntUnSigned: RegExp = new RegExp(/[0-9]+$/g);

    private regexDecSigned: RegExp = new RegExp(/^(\-{0,1})?\d*\.?\d{0,2}$/g);
    private regexDecUnSigned: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

    private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-', 'ArrowLeft', 'ArrowRight'];
    @Input() allowDecimals: boolean = true;
    @Input() allowSign: boolean = false;
    @Input() precision: string = '2';
    @Input() requirePlaceHolder: boolean = false;

    ngAfterViewInit() {

        if (this.precision == '2') {
            this.regexDecSigned = new RegExp(/^-?\d*\.?\d{0,2}$/g);
            this.regexDecUnSigned = new RegExp(/^\d*\.?\d{0,2}$/g);
        } else {
            this.regexDecSigned = new RegExp(/^-?\d*\.?\d{0,4}$/g);
            this.regexDecUnSigned = new RegExp(/^\d*\.?\d{0,4}$/g);
        }
    }

    constructor(private el: ElementRef,
        private toastCtrl: ToastServicesProvider) {

    }

    @HostListener('focus', ['$event']) onFocus(e) {

        if (this.requirePlaceHolder && this.el.nativeElement.value == '') {
            this.el.nativeElement.placeholder = ''
        }
    }

    @HostListener('blur', ['$event']) onBlur(e) {

        if (this.requirePlaceHolder && this.el.nativeElement.value == '') {
            this.el.nativeElement.placeholder = this.allowDecimals ? (0).toFixed(parseInt(this.precision)) : '0';
        }
    }

    @HostListener('keydown', ['$event'])
    onKeyDown(event: KeyboardEvent) {
        // Allow Backspace, tab, end, and home keys
        if (this.allowDecimals == true) {
            if (this.specialKeys.indexOf(event.key) !== -1) {
                return;
            }
            let current: string = this.el.nativeElement.value;
            let next: string = current.concat(event.key);
            if (this.allowSign == true) {
                if (next && !String(next).match(this.regexDecSigned)) {
                    event.preventDefault();
                }
            } else {
                if (next && !String(next).match(this.regexDecUnSigned)) {
                    event.preventDefault();
                }
            }
        }
        else if (this.allowDecimals == false) {

            if (this.specialKeys.indexOf(event.key) !== -1) {
                return;
            }
            let current: string = this.el.nativeElement.value;
            //this.toastCtrl.showAtBottom("Event Key: " + String.fromCharCode(event.keyCode));
            let next: string = current.concat(String.fromCharCode(event.keyCode));
            if (this.allowSign == true) {
                if (next && !String(next).match(this.regexIntSigned)) {
                    event.preventDefault();
                    return false;
                }
                return true;
            } else {
                let isInvalid = false;
                this.toastCtrl.showAtBottom("Value: " + current + " Next: " + next);
                if (next && !String(next).match(this.regexIntUnSigned)) {
                    event.preventDefault();
                    return false;
                }
                return true;

            }
        }
    }
}

@Directive({
    selector: '[numericDir]'
})
export class NumberTestDirective {

    private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

    private regexIntSigned: RegExp = new RegExp(/^-?[0-9]*$/g);
    private regexIntUnSigned: RegExp = new RegExp(/^[0-9]+$/g);

    private regexDecSigned: RegExp = new RegExp(/^(\-{0,1})?\d*\.?\d{0,2}$/g);
    private regexDecUnSigned: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

    private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-', 'ArrowLeft', 'ArrowRight'];
    @Input() allowDecimals: boolean = true;
    @Input() allowSign: boolean = false;
    @Input() precision: string = '2';
    @Input() requirePlaceHolder: boolean = false;

    ngAfterViewInit() {

        this.regexIntSigned = /^[0-9]+$/g;
        this.regexIntUnSigned = /^-?[0-9]*$/g;

        if (this.precision == '2') {
            this.regexDecSigned = (/^-?\d*\.?\d{0,2}$/g);
            this.regexDecUnSigned = (/^\d*\.?\d{0,2}$/g);
        } else {
            this.regexDecSigned = (/^-?\d*\.?\d{0,4}$/g);
            this.regexDecUnSigned = (/^\d*\.?\d{0,4}$/g);
        }
    }

    constructor(private _el: ElementRef, private toastCtrl: ToastServicesProvider,private ngModel:NgModel) { }

    currentValue = '';
    previousValue = '';
    @HostListener('input', ['$event'])
    //@HostListener("keyup", ["$event"])
    onInputChange(evt) {

        const target = evt.target;
        const value = target.value;
        let cursorPosition: number = evt.target['selectionStart'];
        //console.log('Keyup: ',value);
        if(value == ""){
            this.previousValue = value;
            return true;
        }
        if (!this.canInputValue(value)) {
            evt.preventDefault();
            evt.stopPropagation();
            target.value = this.previousValue;
            this._el.nativeElement.value = this.previousValue;
            evt.target.setSelectionRange(cursorPosition, cursorPosition - 1);
            this.ngModel.update.emit(this.previousValue);
            //evt.target['selectionStart'] = cursorPosition;
            //this.setStateForInput(target, InputState.reset);
            return false;
        }

        // let key = evt.target.value;
        // console.log((key))
        // if (!this.regexIntUnSigned.test(key)) {
        //     evt.preventDefault();
        //     this._el.nativeElement.value = this.previousValue;
        //     evt.target.value = this.previousValue
        //     return false;
        // }
        this.previousValue = value;
        return true;
    }

    private setInputValue(input: HTMLInputElement, value: any): void {
        const isEmpty = this.isEmpty(value);
        const valueClassCSS = 'has-value';
        const emptyClassCSS = 'empty';
        if (isEmpty) {
            input.value = '';
            //input.classList.remove(valueClassCSS);
            // tslint:disable-next-line:no-non-null-assertion
            //input.parentElement!.classList.add(emptyClassCSS);
        }
        else {
            input.value = value;
            //input.classList.add(valueClassCSS);
            // tslint:disable-next-line:no-non-null-assertion
            //input.parentElement!.classList.remove(emptyClassCSS);
        }
    }

    private canInputValue(value: any): boolean {
        // if (this.isEmpty(value)) {
        //     return false;
        // }

        if (this.allowDecimals == true) {
            let isDigitsValue = false;
            if (this.allowSign == true) {

                if (this.precision == '2') {
                    isDigitsValue = (/^-?\d*\.?\d{0,2}$/g).test(value);
                } else {
                    isDigitsValue = (/^-?\d*\.?\d{0,4}$/g).test(value);
                }
                //const isDigitsValue = this.regexDecSigned.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            } else {
                if (this.precision == '2') {
                    isDigitsValue = (/^\d*\.?\d{0,2}$/g).test(value);
                } else {
                    isDigitsValue = (/^\d*\.?\d{0,4}$/g).test(value);
                }
                //const isDigitsValue = this.regexDecUnSigned.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            }
        }
        else if (this.allowDecimals == false) {

            if (this.allowSign == true) {
                //const isDigitsValue = this.regexIntSigned.test(value.toString());
                const isDigitsValue = /^-?[0-9]+$/.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            } else {

                const isDigitsValue = /^[0-9]+$/.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;

            }
        }

        //const isDigitsValue = /^[0-9]+$/.test(value.toString());
        // const isDigitsValue = this.regexIntUnSigned.test(value.toString());
        // return isDigitsValue;
    }

    private isEmpty(value: any): boolean {
        return value === null || value === undefined || !value.toString().length;
    }

}

@Directive({
    selector: "[numericDirViv]"
})
export class NewNumericDirective {
    @Input("allowSign") allowSign: boolean = false;
    @Input() allowDecimals: boolean = true;
    @Input() precision: string = '2';
    @Input() requirePlaceHolder: boolean = false;

    private regexDecSigned: RegExp = new RegExp(/^(\-{0,1})?\d*\.?\d{0,2}$/g);
    private regexDecUnSigned: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

    ngAfterViewInit() {
        if (this.precision == '2') {
            this.regexDecSigned = new RegExp(/^-?\d*\.?\d{0,2}$/g);
            this.regexDecUnSigned = new RegExp(/^\d*\.?\d{0,2}$/g);
        } else {
            this.regexDecSigned = new RegExp(/^-?\d*\.?\d{0,4}$/g);
            this.regexDecUnSigned = new RegExp(/^\d*\.?\d{0,4}$/g);
        }
    }

    private canInputValue(value: any): boolean {
        // if (this.isEmpty(value)) {
        //     return false;
        // }

        if (this.allowDecimals == true) {
            let isDigitsValue = false;
            if (this.allowSign == true) {

                if (this.precision == '2') {
                    isDigitsValue = (/^-?\d*\.?\d{0,2}$/g).test(value);
                } else {
                    isDigitsValue = (/^-?\d*\.?\d{0,4}$/g).test(value);
                }
                //const isDigitsValue = this.regexDecSigned.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            } else {
                if (this.precision == '2') {
                    isDigitsValue = (/^\d*\.?\d{0,2}$/g).test(value);
                } else {
                    isDigitsValue = (/^\d*\.?\d{0,4}$/g).test(value);
                }
                //const isDigitsValue = this.regexDecUnSigned.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            }
        }
        else if (this.allowDecimals == false) {

            if (this.allowSign == true) {
                //const isDigitsValue = this.regexIntSigned.test(value.toString());
                const isDigitsValue = /^-?[0-9]+$/.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;
            } else {

                const isDigitsValue = /^[0-9]+$/.test(value);
                //console.log('value: ',value ,", isValid: ", isDigitsValue);
                return isDigitsValue;

            }
        }

        //const isDigitsValue = /^[0-9]+$/.test(value.toString());
        // const isDigitsValue = this.regexIntUnSigned.test(value.toString());
        // return isDigitsValue;
    }

    private checkAllowNegative(value: string) {
        if (!this.allowDecimals) {
            return String(value).match(this.regexDecUnSigned);
        } else {
            return String(value).match(this.regexDecSigned);
        }
    }

    private check(value: string) {
        if (!this.allowDecimals) {
            return String(value).match(new RegExp(/^[0-9]+$/));
            ///^[0-9]+$/
            ///^\d+$/
        } else {
            //var regExpString = "^\\s*((\\d+(\\.\\d{0," + this.precision + "})?)|((\\d*(\\.\\d{1," + this.precision + "}))))\\s*$";
            return String(value).match(new RegExp(/^-?[0-9]+$/));
            ///^-?[0-9]+$/
        }
    }

    private run(oldValue) {
        setTimeout(() => {
            let currentValue: string = this.el.nativeElement.value;
            if (this.allowSign) {
                if (
                    !["", "-"].includes(currentValue) &&
                    !this.checkAllowNegative(currentValue)
                ) {
                    this.el.nativeElement.value = oldValue;
                }
            } else {
                if (currentValue !== "" && !this.canInputValue(currentValue)) {
                    this.el.nativeElement.value = oldValue;
                }
            }
            // if (!this.canInputValue(currentValue)) {
            //     this.el.nativeElement.value = oldValue;
            // }
        });
    }

    constructor(private el: ElementRef) { }

    @HostListener("keydown", ["$event"])
    onKeyDown(event: KeyboardEvent) {
        this.run(this.el.nativeElement.value);
    }

    @HostListener("paste", ["$event"])
    onPaste(event: ClipboardEvent) {
        this.run(this.el.nativeElement.value);
    }

    @HostListener('focus', ['$event']) onFocus(e) {
        if (this.requirePlaceHolder && this.el.nativeElement.value == '') {
            this.el.nativeElement.placeholder = ''
        }
    }

    @HostListener('blur', ['$event']) onBlur(e) {

        if (this.requirePlaceHolder && this.el.nativeElement.value == '') {
            this.el.nativeElement.placeholder = this.allowDecimals ? (0).toFixed(parseInt(this.precision)) : '0';
        }
    }
}





