import { Directive, ElementRef, HostListener } from '@angular/core';
import { clsGlobal } from '../Common/clsGlobal';

@Directive({
  selector: '[upper-case]'
})
export class UpperCaseDirective {

  constructor(private el: ElementRef) { }

  @HostListener('keyup', ['$event'])
  onKeyup(event: any) {//KeyboardEvent
    try {
      const target = event.target;
      const newValue = target.value.toUpperCase().trim();
      target.value = newValue;
      this.el.nativeElement.value = newValue;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('Uppercase', 'onKeyDown', error);
    }

  }

}
