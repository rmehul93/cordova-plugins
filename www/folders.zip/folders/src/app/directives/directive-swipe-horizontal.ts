import {Directive, ElementRef, Output, OnInit, OnDestroy, EventEmitter} from '@angular/core';
import {GestureController} from '@ionic/core/dist/collection/utils/gesture/gesture-controller'
import { Gesture, createGesture } from '@ionic/core';

declare var Hammer: any;

@Directive({
    selector: '[swipe-horizontal]' // Attribute selector
})
export class SwipeHorizontal implements OnInit, OnDestroy {
    @Output() onSwipeLeft = new EventEmitter();
    @Output() onSwipeRight = new EventEmitter();
   

    private el: HTMLElement;
    private swipeGestureLeft: Gesture ;
    private swipeGestureRight: Gesture ;
    //private swipeDownGesture: Gesture;

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
       
    }

    ngOnInit() {

         let configLeft = {
            el: this.el,
            gestureName:'swipeleft',
            onEnd:(e => {
                this.onSwipeLeft.emit({ el: this.el });
            })
         };
         this.swipeGestureLeft = createGesture(configLeft);

         let configRight = {
            el: this.el,
            gestureName:'swiperight',
            onEnd:(e => {
                this.onSwipeRight.emit({ el: this.el });
            })
         };
         this.swipeGestureRight = createGesture(configRight);

       /*
        this.swipeGesture.listen();
        this.swipeGesture.on('swipeleft', e => {
            this.onSwipeLeft.emit({ el: this.el });
        });
        
        this.swipeGesture.on('swiperight', e => {
            this.onSwipeRight.emit({ el: this.el });
        });
        */
    }

    ngOnDestroy() {
        //this.swipeGesture.destroy();
    }
}