import { Directive, EventEmitter, HostListener, Input, Output, ElementRef } from '@angular/core';
import { Platform } from '@ionic/angular';


@Directive({
  selector: '[cMaxLength]'
})
export class MaxLengthDirective {

  @Input('cMaxLength') cMaxLength: any;
  @Output() ngModelChange: EventEmitter<any> = new EventEmitter();
  previousValue: string = '';

  constructor(private hostElement: ElementRef,
    private platform: Platform) {
  }

  //keypress event doesn't work in ionic android. keydown event will work but the value doesn't effect until this event has finished. hence using keyup event. 
  @HostListener('keyup', ['$event']) onKeyup(evt) {
    /*
    const element = event.target as HTMLInputElement;
    const limit = this.cMaxLength;
    let cursorPosition: number = event.target['selectionStart'];
    let originalValue: string = event.target['value'];

    if (this.platform.is('android')) {
      const value = element.value.substr(0, limit);
      if (value.length <= limit) {
        element.value = value;
      } else {
        this.previousValue = [originalValue.slice(0, cursorPosition - 1), originalValue.slice(cursorPosition)].join('');
        this.hostElement.nativeElement.value = (this.previousValue || '');
        event.preventDefault();
        //element.value = value.substr(0, limit-1);
      }
      //this.ngModelChange.emit(element.value);
    }
    */



  }

  currentValue = '';

  // @HostListener('input', ['$event']) onInputChange(evt) {
  //   const target = evt.target;
  //   const value = target.value;
  //   let cursorPosition: number = evt.target['selectionStart'];
  //   const limit = this.cMaxLength;

  //   if (value.length <= limit) {
  //     target.value = value;
  //     this.previousValue = value;
  //   } else {
  //     evt.preventDefault();
  //     evt.stopPropagation();
  //     target.value = this.previousValue;
  //     //evt.target.setSelectionRange(cursorPosition, cursorPosition - 1);
  //     //element.value = value.substr(0, limit-1);
  //     return;
  //   }
  // }

  // @HostListener('keydown', ['$event']) onInputChange(evt) {
  //   const target = evt.target;
  //   const value = target.value;
  //   //let cursorPosition: number = evt.target['selectionStart'];
  //   const limit = this.cMaxLength;

  //   if (value.length <= limit) {
  //     target.value = value;
  //     this.previousValue = value;
  //   } else {
  //     evt.preventDefault();
  //     evt.stopPropagation();
  //     evt.target.value = this.previousValue;
  //     //evt.target.setSelectionRange(cursorPosition, cursorPosition - 1);
  //     //element.value = value.substr(0, limit-1);
  //     return;
  //   }
  // }

  @HostListener('keypress', ['$event']) onInputChange(evt) {
    if (evt.target.value.length >= this.cMaxLength) return false;
    return true;
  }

  @HostListener('ionFocus', ['$event']) onFocus(event) {
    const element = event.target as HTMLInputElement;
    element.setAttribute('maxlength', this.cMaxLength)
    if (!this.platform.is('android')) {
      element.setAttribute('pattern', "/^-?\d+\.?\d*$/")
    }
  }
}