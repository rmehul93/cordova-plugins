export class clsAppConfigConstants {
    public static APP_API_KEY: string = "APP_API_KEY";
    public static APP_PASSWORD_LENGTH: string = "APP_PASSWORD_LENGTH";
    public static APP_MIN_PASSWORD_LENGTH: string = "APP_MIN_PASSWORD_LENGTH";
    public static APP_GUEST_DEF_TEMPLATE: string = "APP_GUEST_DEF_TEMPLATE";
    //public static APP_GUEST_WFH_IP: string = "GUEST_WFH_IP";
    //public static APP_GUEST_WFH_PORT: string = "GUEST_WFH_PORT";
    public static APP_FREE_STREAMING: string = "APP_FREE_STREAMING";
    public static APP_GUEST_BCAST_SOCKET_URL: string = "APP_GUEST_BCAST_SOCKET_URL";
    // Added by Sonali to store Guest trial days
    public static APP_GUEST_MODE_TRIAL_DAYS: string = "APP_GUEST_MODE_TRIAL_DAYS"
    //Added by Vivian to store XMPP Socket URL globally
    public static APP_XMPP_WEBSOCKET_URL: string = "APP_XMPP_WEBSOCKET_URL";

    public static APP_SCRIPS_BATCH_COUNT: string = "APP_SCRIPS_BATCH_COUNT";

    public static APP_SOCKET_RECONNECTION_RETRY_COUNT: string = "APP_SOCKET_RECONNECTION_RETRY_COUNT";
    public static APP_EJABBERD_SOCKET_RECONNECTION_RETRY_COUNT: string = "APP_EJABBERD_SOCKET_RECONNECTION_RETRY_COUNT";

    public static APP_SOCKET_AUTOREFRESH_TIMER_VALUE: string = "APP_SOCKET_AUTOREFRESH_TIMER_VALUE";
    public static APP_SOCKET_RECONNECTION_TIME_VALUE: string = "APP_SOCKET_RECONNECTION_TIME_VALUE";

    public static APP_CUSTOMER_CARE: string = "APP_CUSTOMER_CARE";
    public static APP_TECHNICAL_CARE: string = "APP_TECHNICAL_CARE";
    public static APP_OPEN_ACCOUNT_URL: string = "APP_OPEN_ACCOUNT_URL";
    public static APP_QTY_AUTOFILL: string = "APP_QTY_AUTOFILL";
    public static APP_CONTACT_EMAIL: string = "APP_CONTACT_EMAIL";
    //
    
    public static APP_INIT_SCREEN_TEXT: string = "APP_INIT_SCREEN_TEXT";
    public static APP_OTPTIMER: string = "APP_OTPTIMER";
    public static APP_OTPSENDER: string = "APP_OTPSENDER";
    public static APP_OTP_SUCCESS_MSG: string = "APP_OTP_SUCCESS_MSG";
    public static APP_OTP_SUCCESS_SUBTITLE_MSG: string = "APP_OTP_SUCCESS_SUBTITLE_MSG";
    public static APP_OTP_SUCCESS_BTN_TEXT: string = "APP_OTP_SUCCESS_BTN_TEXT";
    public static APP_OTP_INVALID_ATTEMPT_COUNT: string = "APP_OTP_INVALID_ATTEMPT_COUNT";

    public static APP_ONEPLACE_FUND_SUMMARY_URL: string = "APP_ONEPLACE_FUND_SUMMARY_URL";
    public static APP_ONEPLACE_PORTFOLIO_URL: string = "APP_ONEPLACE_PORTFOLIO_URL";
    public static APP_ONEPLACE_DP_HOLDINGS_URL: string = "APP_ONEPLACE_DP_HOLDINGS_URL";
    public static APP_ONEPLACE_LEDGER_URL: string = "APP_ONEPLACE_LEDGER_URL";
    public static APP_ONEPLACE_FO_POSITIONS_URL: string = "APP_ONEPLACE_FO_POSITIONS_URL";
    public static APP_ONEPLACE_PROFILE_URL: string = "APP_ONEPLACE_PROFILE_URL";
    public static APP_ONEPLACE_LINKED_PROFILES_URL: string = "APP_ONEPLACE_LINKED_PROFILES_URL";
    public static APP_ONEPLACE_PROFIT_LOSS_URL: string = "APP_ONEPLACE_PROFIT_LOSS_URL";


    //landing page
    public static APP_GUEST_RECO_CATEGORY: string = "APP_GUEST_RECO_CATEGORY";
    public static APP_RECO_SCRIP_COUNT: string = "APP_RECO_SCRIP_COUNT";
    public static APP_HOTPURSUIT_SCRIP_COUNT: string = "APP_HOTPURSUIT_SCRIP_COUNT";

    //watchlist constant
    public static APP_GUESTUSER_WATCHLIST_COUNT: string = "APP_GUESTUSER_WATCHLIST_COUNT";
    public static APP_LOGINUSER_WATCHLIST_COUNT: string = "APP_LOGINUSER_WATCHLIST_COUNT";
    public static APP_WATCHLIST_SCRIP_COUNT: string = "APP_WATCHLIST_SCRIP_COUNT";

    //CDS
    public static APP_CDS_PAGE_SIZE: string = "APP_CDS_PAGE_SIZE";
    public static APP_CHAR_SIZE: string = "APP_CHAR_SIZE";

    public static APP_BANNED_SCRIP_POPUP: string = "APP_BANNED_SCRIP_POPUP";
    public static APP_BANNED_SCRIP_MESSAGE: string = "APP_BANNED_SCRIP_MESSAGE";

    // for FORGOT Password
    public static APP_FORGOTPASS_OTP_MAX_ATTEMPTS: string = "APP_FORGOTPASS_OTP_MAX_ATTEMPTS";
    public static APP_FORGOTPASS_REQUEST_MAX_ATTEMPTS: string = "APP_FORGOTPASS_REQUEST_MAX_ATTEMPTS";

    public static APP_MARKETLIVE_LIVENEWS_URL: string = "APP_MARKETLIVE_LIVENEWS_URL";
    public static APP_MARKETLIVE_BOT_URL: string = "APP_MARKETLIVE_BOT_URL";
    public static APP_MARKETLIVE_SUBMENU_ONE: string = "APP_MARKETLIVE_SUBMENU_ONE";
    public static APP_MARKETLIVE_SUBMENU_TWO: string = "APP_MARKETLIVE_SUBMENU_TWO";
    public static APP_MARKETLIVE_SUBMENU_THREE: string = "APP_MARKETLIVE_SUBMENU_THREE";
    public static APP_MARKETLIVE_SUBMENU_FOUR: string = "APP_MARKETLIVE_SUBMENU_FOUR";

    public static APP_FIRST_LOGIN_OF_DAY: string = "APP_FIRST_LOGIN_OF_DAY";
    public static APP_MPIN_MAX_INVALID_ATTEMPT: string = "APP_MPIN_MAX_INVALID_ATTEMPT";
    public static APP_MPIN_SKIP_ENABLE: string = "APP_MPIN_SKIP_ENABLE";
    public static APP_MPIN_EXPIRY_DAYS: string = "APP_MPIN_EXPIRY_DAYS";
    public static APP_MPIN_LAST_CHECK_COUNT: string = "APP_MPIN_LAST_CHECK_COUNT";

    //LOOKUP CONSTANT
    public static APP_LASTVISIT_CNT: string = "APP_LASTVISIT_CNT";
    public static APP_BANNER_IMAGES: string = "APP_BANNER_IMAGES";
    public static APP_QUICKTOUR_IMAGES: string = "APP_QUICKTOUR_IMAGES";//added by omprakash on 22 july for quick tour cdn files.
    public static APP_CDN_BASE_PATH: string = "APP_CDN_BASE_PATH";

    public static APP_LOADER_DISPLAY_MILLISECONDS: string = "APP_LOADER_DISPLAY_MILLISECONDS";
    public static APP_TOAST_DISPLAY_MILLISECONDS: string = "APP_TOAST_DISPLAY_MILLISECONDS";
    public static APP_TRENDING_NEWS_REFERESH_INTERVAL: string = "APP_TRENDING_NEWS_REFERESH_INTERVAL";

    public static APP_ANDROID_APPVERSION: string = "APP_ANDROID_APPVERSION";
    public static APP_SCREENERS_IDS: string = "APP_SCREENERS_IDS"
    public static APP_EDIS_REQUEST_NEWNETNET_URL: string = "APP_EDIS_REQUEST_NEWNETNET_URL";
    public static APP_CHART_TIME_INTERVAL: string = "APP_CHART_TIME_INTERVAL";
    public static APP_MAX_PROFILE_COUNT: string = "APP_MAX_PROFILE_COUNT";

    public static APP_SSO1_ALLOWED: string = "APP_SSO1_ALLOWED";
    public static APP_SSO2_ALLOWED: string = "APP_SSO2_ALLOWED";
    public static APP_SSO3_ALLOWED: string = "APP_SSO3_ALLOWED";
    public static APP_SSO1_LINK: string = "APP_SSO1_LINK";
    public static APP_SSO2_LINK: string = "APP_SSO2_LINK";
    public static APP_SSO3_LINK: string = "APP_SSO3_LINK";

    public static APP_DOWNLOAD_KYC_URL: string = "APP_DOWNLOAD_KYC_URL";

    public static APP_NETNET_URL: string = "APP_NETNET_URL";

    public static APP_SHOW_SSO: string = "APP_SHOW_SSO";
    public static APP_SHOW_LINKS: string = "APP_SHOW_LINKS";
    public static APP_SHOW_INVITE_FRIENDS: string = "APP_SHOW_INVITE_FRIENDS";

    public static APP_CMOT_MODE: string = "APP_CMOT_MODE";
    public static APP_X_API_KEY_PREFIX: string = "APP_X_API_KEY_PREFIX";
    
}
