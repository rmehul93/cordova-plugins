export class clsConstants {
    public static version: string = "1.0.0.0";
    public static guestRegistrationDate = new Date();
    //public static guestTrailDays = 8;
    public static PRODUCT_SOURCE = "WAVEAPI"; // it will be MOBILEAPI, WEBAPI,WAVEAPI
    public static C_V_PHOENIX_MOBILE = 19;
    public static C_V_PHOENIX_TABLET = 20;

    public static C_S_DEFAULT_PASSWORD: string = "ftodin1";
    public static C_S_ABOUTUS_FILE: string = "AboutUs.txt";
    public static C_S_BROKER_INFO_FILE: string = "brokerinformation.json";
    public static C_S_PASSWORD_POLICY_FILE: string = "passwordpolicy.txt";
    public static C_S_DISCLAIMER_FILE: string = "disclaimer";
    public static C_S_TERMS_CONDITION_FILE: string = "TermsCondition";
    public static C_S_COUNTRYMASTER_FILE: string = "country-master.txt";
    public static C_S_MSGINFO = "MSGINFO.json";
    public static C_S_APPINFO = "APPINFO.json"
    public static C_S_APPMENU = "APPMENU.json"
    public static C_S_EXCHANGE_TIME_FILE: string = "exchangeTime.json";
    /// #region "ExcryptedPswd Replace Delimiter Constants"
    public static C_S_ENCRYP_BACK_SLASH: string = "/";
    public static C_S_ENCRYP_EQUAL: string = "=";
    public static C_S_ENCRYP_SLASH_REPLACER: string = "::";
    public static C_S_ENCRYP_EQUAL_REPLACER: string = "**";
    public static C_S_IS_PWD_ENCRYPT: string = "Encrypted Pwd";


    /// #endregion

    public static C_V_MSGCODES_LOGINREQUEST: number = 101;
    public static C_V_MSGCODES_LOGONRESPONSE: number = 102;
    public static C_V_MSGCODES_MARKETWATCH_RESPONSE: number = 209;
    public static C_V_MSGCODE_FORCELOGIN: number = 261;
    public static C_V_MSGCODES_CHANGEPWDREQUEST: number = 271;
    public static C_V_MSGCODES_KEEPALIVE_REQUEST: number = 1000;
    public static C_V_TAG_MKTSEGID: number = 1;
    public static C_V_TAG_BUYQTY: number = 2;
    public static C_V_TAG_BUYPRICE: number = 3;
    public static C_V_TAG_SESSIONID: number = 4;
    public static C_V_TAG_SELLQTY: number = 5;
    public static C_V_TAG_SELLPRICE: number = 6;
    public static C_V_TAG_SCRIPTOKEN: number = 7;
    public static C_V_TAG_LTP: number = 8;
    public static C_V_TAG_LTQ: number = 9;
    public static C_V_TAG_CLIENTORDERNO: number = 10;
    public static C_V_TAG_BUYORSELL: number = 11;
    public static C_V_TAG_ORIGQTY: number = 12;
    public static C_V_TAG_DISCLOSEDQTY: number = 13;
    public static C_V_TAG_ORDPRICE: number = 14;
    public static C_V_TAG_SCRIPDESC: number = 1111;
    public static C_V_TAG_TRIGPRICE: number = 15;
    public static C_V_TAG_VALIDITY: number = 16;
    public static C_V_TAG_ORDEXCHORDERNO: number = 18;
    public static C_V_TAG_ORDERRORSTRING: number = 19;
    public static C_V_TAG_ORDSTATUS: number = 20;
    public static C_V_TAG_ORDGTD: number = 21;
    public static C_V_TAG_ORDREQUEST_TYPE: number = 22;
    public static C_V_TAG_ORDRESPONSE_TYPE: number = 23;
    public static C_V_TAG_TRADENO: number = 25;
    public static C_V_TAG_INDEXTYPE: number = 26;
    public static C_V_TAG_INDEXVALUE: number = 27;
    public static C_V_TAG_GATEWAYORDERNO: number = 28;
    public static C_V_TAG_INSTRUMENTNAME: number = 29;
    public static C_V_TAG_SYMBOL: number = 31;
    public static C_V_TAG_SERIES: number = 32;
    public static C_V_TAG_EXPIRYDATE: number = 33;
    public static C_V_TAG_STRIKEPRICE: number = 34;
    public static C_V_TAG_OPTIONTYPE: number = 35;
    public static C_V_TAG_BEST5NOOFORDERS: number = 37;
    public static C_V_TAG_CLOSING_INDEX_VALUE: number = 41;
    public static C_V_TAG_INSTRUMENTID: number = 43;
    public static C_V_TAG_MARKETLOT: number = 47;
    public static C_V_TAG_PRICETICK: number = 48;
    public static C_V_TAG_NETCHANGEFROMPREVCLOSE: number = 54;
    public static C_V_TAG_USERMARKS: number = 55;
    public static C_V_TAG_CLIENTID: number = 59;
    public static C_V_TAG_PARTICIPANTID: number = 60;
    public static C_V_TAG_MSGVERSION: number = 63;
    public static C_V_TAG_MSGCODE: number = 64;
    public static C_V_TAG_MSGLENGTH: number = 65;
    public static C_V_TAG_MSGTIME: number = 66;
    public static C_V_TAG_USERID: number = 67;
    public static C_V_TAG_PWD: number = 68;
    public static C_V_TAG_TIME: number = 71;
    public static C_V_TAG_ORDERTYPE: number = 72;
    public static C_V_TAG_LTT: number = 73;
    public static C_V_TAG_LUT: number = 74;
    public static C_V_TAG_OPENPRICE: number = 75;
    public static C_V_TAG_CLOSEPRICE: number = 76;
    public static C_V_TAG_HIGHPRICE: number = 77;
    public static C_V_TAG_LOWPRICE: number = 78;
    public static C_V_TAG_VOLUME: number = 79;
    public static C_V_TAG_ATP: number = 80;
    public static C_V_TAG_TOTBUYQTY: number = 81;
    public static C_V_TAG_TOTSELLQTY: number = 82;
    public static C_V_TAG_OPENINTEREST: number = 88;
    public static C_V_TAG_VALUE: number = 91;
    public static C_V_TAG_LIFETIMEHIGH: number = 93;
    public static C_V_TAG_LIFETIMELOW: number = 94;
    public static C_V_TAG_PERCENTAGECHANGE: number = 99;
    public static C_V_TAG_CONSTTRADEVALUE: number = 101;
    public static C_V_TAG_ORDERTIME: number = 254;
    public static C_V_TAG_CANCELCOLID: number = 110012;
    public static C_V_TAG_HOLDSELECTID: number = 110013;

    public static C_V_TAG_NETCHANGEINRS: number = 393;
    public static C_V_TAG_GROUPID: number = 396;
    public static C_V_TAG_DECIMALLOCATOR: number = 399;
    public static C_V_TAG_IWINLOGONTAG: number = 400;
    public static C_V_TAG_BSEPARTTYPE: number = 404;
    public static C_V_POSINDICATOR: number = 416;
    public static C_V_TAG_MWSCRIPDESC: number = 1001;
    public static C_V_TAG_ALERTREMARK: number = 1003;
    public static C_V_TAG_DUALLUT: number = 427;
    public static C_V_TAG_SORID: number = 424;
    public static C_V_TAG_ORDERFROM: number = 5000;
    public static C_V_TAG_USERCODE: number = 397;
    public static C_V_TAG_PRODUCTTYPE: number = 368;
    public static C_V_TAG_SOURCEPRODTYPE = 455;
    //added for MarginPlus
    public static C_S_TAG_MARGINPLUS_EXPIRYVALUE: number = 458;
    public static C_S_TAG_MARGINPLUS_STRIKEPRICEVALUE: number = 459;
    public static C_S_TAG_MARGINPLUS_BASEPRICE: number = 460;
    public static C_S_TAG_MARGINPLUS_MFFLAG: number = 461;
    //Spread
    public static C_V_TAG_ISSPREADSCRIP: number = 471;
    //End
    public static C_S_EXCHNAME: string = "200";
    public static C_V_TAG_MKTORDER: number = 457;

    public static C_V_TAG_ISTABLETDEVICE: string = "465";
    public static C_V_TAG_COL: number = 57;

    public static C_V_TAG_SLJUMPPRICE: number = 489;
    public static C_V_TAG_LTPJUMPPRICE: number = 490;
    public static C_V_TAG_SLORDERPRICE: number = 491;
    public static C_V_TAG_SLTRIGGERPRICE: number = 492;
    public static C_V_TAG_PROFITORDERPRICE: number = 493;
    public static C_V_TAG_BRACKETORDERID: number = 494;
    public static C_V_TAG_BO_GATEWAYORDERNO: number = 496;
    public static C_V_TAG_BO_MODIFYTERMS: number = 497;
    public static C_V_TAG_BO_SLORDERTYPE: number = 498;
    public static C_V_TAG_OFSMARGIN: number = 503;
    public static C_V_TAG_RECOMMENDATIONID: number = 495;

    // Cross Currency
    public static C_V_TAG_CROSSCUR_FLAG: number = 509;
    public static C_V_TAG_CROSSCUR_BASECUR: number = 562;

    public static C_S_FIELD_DELIMITER: string = "|";
    public static C_S_NAMEVALUE_DELIMITER: string = "=";
    public static C_S_RECORD_DELIMITER: string = "$";
    public static C_S_COMMA_DELIMITER: string = ",";
    public static C_S_MULTIRESP_DELIMITER: string = "#";
    public static C_S_EXCH_DELIMITER: string = ":";
    public static C_S_ALERT_DELIMITER: string = ":";
    public static C_S_INST_DELIMITER: string = "$";
    // #region "Login Status"

    public static C_V_LOGON_SUCCESS: string = "10000";
    public static C_V_PWD_EXPIRES_IN_DAYS: string = "10004";
    public static C_V_NEWPASSWORD_CHANGED_SUCCESS: string = "10006";
    public static C_V_PASSWORD_EXPIRED: string = "10007";
    public static C_V_USER_ALREADYLOGGED: string = "10008";
    public static C_V_NEWOLD_SAME_PWD: string = "10013";
    public static C_V_PWD_ACCOUNT_EXPIRES_IN_DAYS: string = "10019";
    public static C_V_ACCOUNT_EXPIRES_IN_DAYS: string = "10020";
    public static C_V_NETNETINTERNAL_PWDCHANGE: string = "10051";

    public static C_V_TAG_SI_TEMPLATEID: number = 5015;
    public static C_V_TAG_MANAGERVERSION: number = 5016;
    public static C_V_TAG_ORDERSUBMITSTATUS: number = 5022;
    public static C_V_TAG_AMOLICENSEALLOWED: number = 5028;
    public static C_S_TAG_DEVICE_TYPE: string = "5031";

    public static C_S_TAG_EXCHANGEALLOWED: string = "EA";
    public static C_S_TAG_LOGINALLOWED: string = "LA";
    public static C_S_2FA_REGENERATE_MESSAGE: string = "A15";
    public static C_V_TAG_MARGINPLUSALLOWED: number = 5038;

    public static C_V_NSE_CASH: number = 1;
    public static C_V_NSE_DERIVATIVES: number = 2;
    public static C_V_BSE_CASH: number = 3;
    public static C_V_BSE_DERIVATIVES: number = 4;
    public static C_V_MCX_DERIVATIVES: number = 5;
    public static C_V_MCX_SPOT: number = 6;
    public static C_V_NCDEX_DERIVATIVES: number = 7;
    public static C_V_NCDEX_SPOT: number = 8;
    public static C_V_NSEL_DERIVATIVES: number = 9;
    public static C_V_NSEL_SPOT: number = 10;
    public static C_V_MSX_DERIVATIVES: number = 11;
    public static C_V_MSX_SPOT: number = 12;
    public static C_V_MSX_CASH: number = 15;
    public static C_V_MSX_FAO: number = 16;
    public static C_V_DSE_CASH: number = 17;
    public static C_V_NMCE_DERIVATIVES: number = 18;
    public static C_V_UCX_DERIVATIVES: number = 19;
    public static C_V_UCX_SPOT: number = 20;
    public static C_V_DGCX_DERIVATIVES: number = 21;
    public static C_V_DGCX_SPOT: number = 22;
    public static C_V_BFX_DERIVATIVES: number = 25;
    public static C_V_BFX_SPOT: number = 26;
    public static C_V_GBOT_DERIVATIVES: number = 27;
    public static C_V_OFS_IPO_BONDS: number = 33;
    public static C_V_DFM_CASH: number = 31;
    public static C_V_ADX_CASH: number = 32;
    public static C_V_MSX_FIM = 37;
    public static C_V_NMCE_DERVIVATIVES = 18;
    public static C_V_NSE_DEBT = 36;
    public static C_V_NSE_SPOS = 20;
    public static C_V_BSE_PCA = 100;
    public static C_V_MSX_SPOS = 21;
    public static C_V_BSECOMM_DERIVATIVES = 18;
    public static C_V_NSECOMM_DERIVATIVES = 19;
    public static C_V_BSECOMM_SPOT = 40;
    public static C_V_NSECOMM_SPOT = 20;

    public static C_V_COMBINED_CASH = 521;
    public static C_V_COMBINED_FNO = 4102;
    public static C_V_COMBINED_CDS = 268438528;

    public static C_V_NSX_DERIVATIVES: number = 13;
    public static C_V_NSX_SPOT: number = 14;
    public static C_V_BSECDX_DERIVATIVES: number = 38;
    public static C_V_BSECDX_SPOT: number = 39;

    public static C_V_MAPPED_NSE_CASH: number = 1;
    public static C_V_MAPPED_NSE_DERIVATIVES: number = 2;
    public static C_V_MAPPED_BSE_DERIVATIVES: number = 4;
    public static C_V_MAPPED_BSE_CASH: number = 8;
    public static C_V_MAPPED_MCX_DERIVATIVES: number = 16;
    public static C_V_MAPPED_MCX_SPOT: number = 32;
    public static C_V_MAPPED_NCDEX_DERIVATIVES: number = 64;
    public static C_V_MAPPED_NCDEX_SPOT: number = 128;
    public static C_V_MAPPED_NSEL_DERIVATIVES: number = 256;
    public static C_V_MAPPED_NSEL_SPOT: number = 257;
    public static C_V_MAPPED_MSX_DERIVATIVES: number = 1024;
    public static C_V_MAPPED_MSX_SPOT: number = 1025;
    public static C_V_MAPPED_MSX_CASH: number = 512;
    public static C_V_MAPPED_MSX_FAO: number = 4096;
    public static C_V_MAPPED_DSE_CASH: number = 8192;
    public static C_V_MAPPED_NMCE_DERIVATIVES: number = 16384;
    public static C_V_MAPPED_BSECOMM_DERIVATIVES: number = 16384;
    public static C_V_MAPPED_DFM_CASH: number = 524288;
    public static C_V_MAPPED_ADX_CASH: number = 1048576;

    public static C_V_MAPPED_NSX_DERIVATIVES: number = 2048;         //Dummy values used since exchanges are no longer in use
    public static C_V_MAPPED_NSX_SPOT: number = 2049;                //Dummy values used since exchanges are no longer in use
    public static C_V_MAPPED_BSECDX_DERIVATIVES: number = 268435456;
    public static C_V_MAPPED_BSECDX_SPOT: number = 268435457;
    public static C_V_MAPPED_UCX_DERIVATIVES: number = 32768;
    public static C_V_MAPPED_NSECOMM_DERIVATIVES: number = 32768;

    public static C_V_MAPPED_UCX_SPOT: number = 32769;
    public static C_V_MAPPED_DGCX_DERIVATIVES: number = 65536;
    public static C_V_MAPPED_DGCX_SPOT: number = 65537;
    public static C_V_MAPPED_BFX_DERIVATIVES: number = 262144;
    public static C_V_MAPPED_BFX_SPOT: number = 262145;
    public static C_V_MAPPED_OFS_IPO_BONDS: number = 536870912;
    public static C_V_MAPPED_GBOT_DERIVATIVES: number = 2097152;
    public static C_V_MAPPED_GBOT_SPOT: number = 2097153;

    public static C_V_MAPPED_COMBINED_CASH: number = 521;
    public static C_V_MAPPED_COMBINED_FNO: number = 4102;
    public static C_V_MAPPED_COMBINED_CDS: number = 268438528;

    /**
     * USD  : BT-12359
     * Date : 21/02/2020* Name : Nikhil Gawade
     * Description : constant added for ICEX exchange
     */
    public static C_V_MAPPED_ICEX_DERIVATIVES: number = 8388608;

    public static C_V_MSGCODES_TOPGAINERSLOSERSRESPONSENEW = 161;
    public static C_V_MSGCODES_MOSTACTIVERESPONSENEW = 162;

    // #region MarketWatck MultiView
    public static C_V_TAG_GRIDVIEW: number = 1;
    public static C_V_TAG_BLOCKVIEW: number = 2;
    public static C_V_TAG_HEATMAP: number = 4;
    public static C_V_TAG_PIVOTPOINT: number = 8;

    public static C_S_TAG_GRIDVIEW: string = "Grid";
    public static C_S_TAG_BLOCKVIEW: string = "Block";
    public static C_S_TAG_HEATMAP: string = "Heat Map";
    public static C_S_TAG_PP: string = "Pivot Point";
    public static C_S_ON: string = "ON";
    public static C_S_OFF: string = "OFF";

    public static C_S_YES: string = "Y";

    public static C_S_SPACE: string = " ";
    public static C_S_STREAMING_MODE: number = 2;
    public static C_S_REFRESH_MODE: number = 1;
    public static C_S_CONNECTIONTYPE: string = "4";
    public static C_S_NETNETLOGONTAG: string = "0";

    public static C_S_TAG_ISIN: string = "ISIN";

    // #region "Exchange Names"
    public static C_S_NSE_EXCHANGE_TEXT: string = "NSE";
    public static C_S_BSE_EXCHANGE_TEXT: string = "BSE";
    public static C_S_MCX_EXCHANGE_TEXT: string = "MCX";
    public static C_S_NCDEX_EXCHANGE_TEXT: string = "NCDEX";
    public static C_S_NSEL_EXCHANGE_TEXT: string = "NSEL";
    public static C_S_MSX_EXCHANGE_TEXT: string = "MSE";
    public static C_S_NSX_EXCHANGE_TEXT: string = "NSECDS";
    public static C_S_BSECDX_EXCHANGE_TEXT: string = "BSECDS";
    public static C_S_DSE_EXCHANGE_TEXT: string = "DSE";
    public static C_S_NMCE_EXCHANGE_TEXT: string = "NMCE";
    public static C_S_BFX_EXCHANGE_TEXT: string = "BFX";
    public static C_S_DGCX_EXCHANGE_TEXT: string = "DGCX";
    public static C_S_UCX_EXCHANGE_TEXT: string = "UCX";
    public static C_S_OTSTXT_EXCHANGE_TEXT: string = "NSE-OTS";

    public static C_S_NSE_EQ_DESC: string = "NSE CASH";
    public static C_S_NSE_DERV_DESC: string = "NSE DERIVATIVES";
    public static C_S_BSE_EQ_DESC: string = "BSE CASH";
    // public static C_S_BSE_EQ_SPECIALPREOPEN: string ="BSE Special PreOpen";
    public static C_S_BSE_DERV_DESC: string = "BSE DERIVATIVES";
    public static C_S_MCX_FUTURES_DESC: string = "MCX FUTURES";
    public static C_S_NCDEX_FUTURES_DESC: string = "NCDEX FUTURES";
    public static C_S_MCX_DERV_DESC = "MCX DERIVATIVES"; //CR 5117 Modified for MCX Options
    public static C_S_NCDEX_DERV_DESC = "NCDEX DERIVATIVES"; //CR 5117 Modified for NCDEX Options
    public static C_S_NSEL_SPTCOM_DESC: string = "NSEL SPTCOM";
    public static C_S_MCXSX_FUTURES_DESC: string = "MSE CURRENCY";
    public static C_S_MCXSX_EQUITIES_DESC: string = "MSE CASH";
    // public static C_S_MCXSX_EQ_SPECIALPREOPEN: string ="MSECASH SPOS";
    public static C_S_MCXSX_FAO_DESC: string = "MSE DERIVATIVES";
    public static C_S_NSX_FUTURES_DESC: string = "NSECDS";
    public static C_S_DSE_EQUITIES_DESC: string = "DSE EQUITIES";
    public static C_S_NMCE_FUTURES_DESC: string = "NMCE FUTURES";
    public static C_S_BSE_COMM_DESC: string = "BSE COMM"; // added by sonali
    public static C_S_BFX_FUTURES_DESC: string = "BFX";
    public static C_S_DGCX_FUTURES_DESC: string = "DGCX";
    public static C_S_UCX_FUTURES_DESC: string = "UCX FUTURES";
    public static C_S_BSECDX_FUTURES_DESC: string = "BSECDS";
    public static C_S_IPO_DESC: string = "NSE-OTS";
    public static C_S_DFM_EQ_DESC: string = "DFM CASH";
    public static C_S_ADX_EQ_DESC: string = "ADX CASH";
    public static C_S_MSX_FIM_EXCHANGE_TEXT = "MSE-FIM";//CR 5355
    public static C_S_DFM_EXCHANGE_TEXT = "DFM";
    public static C_S_ADX_EXCHANGE_TEXT = "ADX";

    public static C_S_NSE_EQ: string = "NSE EQ";
    public static C_S_NSE_FAO: string = "NSE FO";
    public static C_S_BSE_EQ: string = "BSE EQ";
    public static C_S_BSE_FAO: string = "BSE FO";
    public static C_S_MCX_FAO: string = "MCX FO";
    public static C_S_NMCE_FAO: string = "NMCE FO";
    public static C_S_MCXSX_CUR: string = "MSE CUR";
    public static C_S_MCXSX_FUT: string = "MSE FO";
    public static C_S_MCXSX_EQ: string = "MSE EQ";
    public static C_S_NCDEX_FAO: string = "NCDEX FO";
    public static C_S_NSE_EQ_FAO: string = "NSE EQ & FO";
    public static C_S_BSE_EQ_FAO: string = "BSE EQ & FO";
    public static C_S_MSE_CDS: string = "MSECDS";

    public static C_S_INSTRUMENT_EQUITIES_TEXT: string = "EQUITIES";
    public static C_S_INSTRUMENT_FUTIDX_TEXT: string = "FUTIDX";
    public static C_S_INSTRUMENT_FUTIVX_TEXT: string = "FUTIVX";

    public static C_S_INSTRUMENT_FUTSTK_TEXT: string = "FUTSTK";
    public static C_S_INSTRUMENT_OPTIDX_TEXT: string = "OPTIDX";
    public static C_S_INSTRUMENT_OPTSTK_TEXT: string = "OPTSTK";
    public static C_S_INSTRUMENT_FUTCOM_TEXT: string = "FUTCOM";
    public static C_S_INSTRUMENT_FUTSPT_TEXT: string = "SPOT";
    public static C_S_INSTRUMENT_FUTCUR_TEXT: string = "FUTCUR";
    public static C_S_INSTRUMENT_CUR_TEXT: string = "CUR";
    public static C_S_INSTRUMENT_FUTINT_TEXT: string = "FUTINT";
    public static C_S_INSTRUMENT_OPTCUR_TEXT: string = "OPTCUR";
    public static C_S_INSTRUMENT_OPTFUT_TEXT: string = "OPTFUT"; //CR 5117 Added New Constant for MCX Option.
    public static C_S_INSTRUMENT_DEBT_TEXT = "DEBT";

    //Added for BFX/DGCX
    public static C_S_INSTRUMENT_OPTCOM_TEXT: string = "OPTCOM";
    public static C_S_INSTRUMENT_FUTURES_TEXT: string = "FUTURES";
    public static C_S_INSTRUMENT_OPTIONS_TEXT: string = "OPTIONS";

    //Added for Auction related change
    public static C_S_INSTRUMENT_AUCBI_TEXT: string = "AUCBI";
    public static C_S_INSTRUMENT_AUCSO_TEXT: string = "AUCSO";
    public static C_S_INSTRUMENT_AUCTBI_TEXT: string = "AUCTBI";
    public static C_S_INSTRUMENT_AUCTSI_TEXT: string = "AUCTSO";

    public static C_S_INSTRUMENT_MCXFUTSPT_TEXT: string = "COM";
    public static C_S_INSTRUMENT_NCDEXSPOT_TEXT: string = "COM";
    public static C_S_INSTRUMENT_NCDEXCOMDTY_TEXT: string = "COMDTY";
    public static C_S_INSTRUMENT_NSELSPTCOM_TEXT: string = "SPTCOM";
    public static C_S_INSTRUMENT_CURRENCY_TEXT: string = "CURRENCY";
    public static C_S_INSTRUMENT_UCXFUTSPT_TEXT = "COM";

    //Added for NSE CDS
    public static C_S_INSTRUMENT_FUTIRD_TEXT: string = "FUTIRD";
    public static C_S_INSTRUMENT_FUTIRT_TEXT: string = "FUTIRT";
    public static C_S_INSTRUMENT_INDEX_TEXT: string = "INDEX";
    public static C_S_INSTRUMENT_UNDCUR_TEXT: string = "UNDCUR";
    public static C_S_INSTRUMENT_UNDIRD_TEXT: string = "UNDIRD";
    public static C_S_INSTRUMENT_UNDIRT_TEXT: string = "UNDIRT";

    //Added for GBOT
    public static C_S_INSTRUMENT_COMCFD_TEXT = "COMCFD";
    public static C_S_INSTRUMENT_CURCFD_TEXT = "CURCFD";

    public static C_S_INSTRUMENT_DGCXFUTSPT_TEXT: string = "COM";
    public static C_S_INSTRUMENT_DGCXSPOT_TEXT: string = "SPOT";
    public static C_S_INSTRUMENT_BFXFUTSPT_TEXT: string = "COM";
    public static C_S_INSTRUMENT_FUTIRC_TEXT: string = "FUTIRC";
    public static C_S_INSTRUMENT_FUTIRF_TEXT: string = "FUTIRF";

    public static C_S_INSTRUMENT_FUT: string = "FUT";
    public static C_S_INSTRUMENT_OPT: string = "OPT";

    public static C_V_INSTRUMENT_EQUITIES: number = 0;
    public static C_V_INSTRUMENT_FUTIDX: number = 1;
    public static C_V_INSTRUMENT_OPTIDX: number = 3;
    public static C_V_INSTRUMENT_FUTCOM: number = 5;
    public static C_V_INSTRUMENT_SPTCOM: number = 8;
    public static C_V_INSTRUMENT_FUTCUR: number = 9;
    public static C_V_INSTRUMENT_FUTINT: number = 11;
    public static C_V_INSTRUMENT_OPTCUR: number = 12;

    public static C_V_INSTRUMENT_AUCBI: number = 13;
    public static C_V_INSTRUMENT_AUCSO: number = 14;
    public static C_V_INSTRUMENT_AUCTBI: number = 15;
    public static C_V_INSTRUMENT_AUCTSI: number = 16;

    public static C_V_INSTRUMENT_OPTCOM: number = 23;
    // #region "ProductType Values"
    public static C_S_PRODUCTTYPE_MARGIN_TEXT: string = "MARGIN";
    public static C_S_PRODUCTTYPE_DELIVERY_TEXT: string = "DELIVERY";
    public static C_S_PRODUCTTYPE_MTF_TEXT: string = "MTF";
    public static C_S_PRODUCTTYPE_MP_TEXT: string = "COVER";
    public static C_S_PRODUCTTYPE_PTST_TEXT: string = "BTST";
    public static C_S_PRODUCTTYPE_INTRADAY_TEXT: string = "INTRADAY";
    public static C_S_PRODUCTTYPE_CARRYFORWARD_TEXT: string = "CARRYFORWARD";
    public static C_S_PRODUCTTYPE_OFS_TXT: string = "OFS";
    //added by vishal to updated bracket order text
    public static C_S_PRODUCTTYPE_BRACKET_ORDER_TXT: string = "BRACKET";
    public static C_S_PRODUCTTYPE_SIP_TXT: string = "SIP";


    public static C_S_PRODUCTTYPE_MARGIN_VALUE: string = "M";
    public static C_S_PRODUCTTYPE_DELIVERY_VALUE: string = "D";
    public static C_S_PRODUCTTYPE_DELIVERY_CARRYFORWARD_VALUE: string = "D";
    public static C_S_PRODUCTTYPE_MTF_VALUE: string = "MF";
    public static C_S_PRODUCTTYPE_MP_VALUE: string = "MP";
    public static C_S_PRODUCTTYPE_PTST_VALUE: string = "PT";
    public static C_S_PRODUCTTYPE_BRACKET_VALUE: string = "B";

    public static C_S_PRODUCTTYPE_AMO_MARGIN_TEXT: string = "AMO MARGIN";
    public static C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT: string = "AMO DELIVERY";
    public static C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT: string = "AMO INTRADAY";
    public static C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT: string = "AMO CARRYFORWARD";

    public static C_S_PRODUCTTYPE_AMO_MARGIN_VALUE: string = "AM";
    public static C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE: string = "AD";

    // #region "Manager Version nos"
    public static C_S_MANAGER_VER_9105: string = "9.1.0.5";
    public static C_S_MANAGER_VER_9105_PLUS: string = "9.1.0.5+";
    public static C_S_MANAGER_VER_9105_INTEGRATED: string = "9.1.0.5++";
    public static C_S_MANAGER_VER_10000: string = "10.0.0.2";
    public static C_S_MANAGER_VER_10003: string = "10.0.0.3";
    public static C_S_MANAGER_VER_10004: string = "10.0.0.4";
    public static C_S_MANAGER_VER_10005: string = "10.0.0.5";

    // #region "Order Types"
    public static C_V_ORDER_REGULARLOT: number = 1;
    public static C_V_ORDER_REGULARLOT_MARKET: number = 2;
    public static C_V_ORDER_STOPLOSS: number = 3;
    public static C_V_ORDER_STOPLOSS_MARKET: number = 4;
    public static C_V_ORDER_CALLAUCTION: number = 11;
    public static C_V_ORDER_MCXSXEQ_CALLAUCTION: number = 12;

    public static C_V_BSE_SPOS: number = 19;
    public static C_V_AUCBI_ORDERTYPE: string = "8";
    public static C_V_AUCSO_ORDERTYPE: string = "9";
    public static C_V_AUCTBI_ORDERTYPE: string = "10";
    public static C_V_AUCTSI_ORDERTYPE: string = "11";

    public static C_S_ORDER_REGULARLOT_TEXT: string = "RL";
    public static C_S_ORDER_REGULARLOT_MARKET_TEXT: string = "RL-MKT";
    public static C_S_ORDER_STOPLOSS_TEXT: string = "SL";
    public static C_S_ORDER_STOPLOSS_MARKET_TEXT: string = "SL-MKT";
    public static C_S_ORDER_CALLAUCTION_TEXT: string = "CA";

    public static C_S_ORDER_TYPE_REGULARLOT_TEXT: string = "Regular Lot";
    public static C_S_ORDER_TYPE_CALLAUCTION_TEXT: string = "Call Auction";
    public static C_S_ORDER_TYPE_STOPLOSS_TEXT: string = "Stop Loss";

    // #region "Validity"
    public static C_S_VALUE_IOC: string = "IOC";
    public static C_S_VALUE_GTC: string = "GTC";
    public static C_S_VALUE_DAY: string = "DAY";
    public static C_S_VALUE_GTD: string = "GTD";
    public static C_S_VALUE_EOS: string = "EOS";
    public static C_S_VALUE_FOK: string = "FOK";
    public static C_S_VALUE_AON: string = "AON";

    public static C_S_VALUE_EOSESS: string = "EOSESS";
    public static C_S_VALUE_EOTODY: string = "EOTODY";
    public static C_S_VALUE_EOSTLM: string = "EOSTLM";

    public static C_S_ORDER_FOK: string = "FillOrKill"; //"FOK";
    public static C_S_VALUE_GTT: string = "GTT"; //"FOK";

    public static C_V_ORDER_VALID_TILL_DAY: number = 1;
    public static C_V_ORDER_GTD: number = 2;
    public static C_V_ORDER_GTC: number = 3;
    public static C_V_ORDER_IOC: number = 4;
    public static C_V_ORDER_EOSESS: number = 1;
    public static C_V_ORDER_EOTODY: number = 2;
    public static C_V_ORDER_EOSTLM: number = 3;
    public static C_V_ORDER_EOS: number = 5;
    public static C_V_ORDER_FOK: number = 6;
    public static C_V_ORDER_GTT: number = 7;

    // #region "OE Labels"
    public static CONST_QTY_CAPTION: string = "Qty.";
    public static CONST_LOT_CAPTION: string = "Lot.";

    public static C_V_ORDER_BUY: number = 1;
    public static C_V_ORDER_SELL: number = 2;
    public static C_S_ORDER_BUY_TEXT: string = "BUY";
    public static C_S_ORDER_SELL_TEXT: string = "SELL";

    // #region PivotPointWatch related constants
    public static C_S_TAG_PREVDAYOPEN: string = "700";
    public static C_S_TAG_PREVDAYHIGH: string = "701";
    public static C_S_TAG_PREVDAYLOW: string = "702";
    public static C_S_TAG_PREVDAYCLOSE: string = "703";
    public static C_S_TAG_RESISTANCE4: string = "704";
    public static C_S_TAG_RESISTANCE3: string = "705";
    public static C_S_TAG_RESISTANCE2: string = "706";
    public static C_S_TAG_RESISTANCE1: string = "707";
    public static C_S_TAG_PIVOTPOINT: string = "708";
    public static C_S_TAG_SUPPORT1: string = "709";
    public static C_S_TAG_SUPPORT2: string = "710";
    public static C_S_TAG_SUPPORT3: string = "711";
    public static C_S_TAG_SUPPORT4: string = "712";

    public static C_S_PP_CALC_METHOD: string = "CalcMethod";
    public static C_S_PP_FORMULA_TYPE: string = "FormulaType";
    public static C_S_PP_FORMULA: string = "Formula";
    // #region Pivot Point Calculation Method
    public static C_S_PP_METHOD_CLASSIC: string = "Classic";
    public static C_S_PP_METHOD_WOODIE: string = "Woodie";
    public static C_S_PP_METHOD_CAMARILLA: string = "Camarilla";
    public static C_S_PP_METHOD_FIBONACCI: string = "Fibonacci";

    // #region Pivot Poiint Formula Type
    public static C_S_PP_Default: string = "DefaultPP";
    public static C_S_PP_Custom: string = "CustomPP";

    // #region Pivot Poiint Formula
    public static C_S_PP_FORMULA_HLC: string = "(H+L+C)/3";
    public static C_S_PP_FORMULA_HLO: string = "(H+L+O)/3";
    public static C_S_PP_FORMULA_HLCO: string = "(H+L+C+O)/4";
    public static C_S_PP_FORMULA_HLCC: string = "(H+L+C+C)/4";
    public static C_S_PP_FORMULA_HLOO: string = "(H+L+O+O)/4";
    public static C_S_PP_FORMULA_HL: string = "(H+L)/2";
    public static C_S_PP_FORMULA_HC: string = "(H+C)/2";
    public static C_S_PP_FORMULA_LC: string = "(L+C)/2";


    // #region "Request-Response packet related constants"
    public static C_S_TAG_BODQT: string = "3701"
    public static C_S_TAG_BUYVAL: string = "3801"
    public static C_S_TAG_CURRENTVAL: string = "3901"

    public static C_S_TAG_MKTSEGID: string = "1";
    public static C_S_TAG_BUYQTY: string = "2";
    public static C_S_TAG_BUYPRICE: string = "3";
    public static C_S_TAG_SESSIONID: string = "4";
    public static C_S_TAG_SELLQTY: string = "5";
    public static C_S_TAG_SELLPRICE: string = "6";
    public static C_S_TAG_SCRIPTOKEN: string = "7";
    public static C_S_TAG_LTP: string = "8";
    public static C_S_TAG_LTQ: string = "9";
    public static C_S_TAG_ORIGQTY: string = "12";
    public static C_S_TAG_DISCLOSEDQTY: string = "13";
    public static C_S_TAG_ORDPRICE: string = "14";
    public static C_S_TAG_TRIGPRICE: string = "15";
    public static C_S_TAG_VALIDITY: string = "16";
    public static C_S_TAG_ORDEXCHORDERNO: string = "18";
    public static C_S_TAG_INDEXTYPE: string = "26";
    public static C_S_TAG_INDEXVALUE: string = "27";
    public static C_S_TAG_SYMBOL: string = "31";
    public static C_S_TAG_SERIES: string = "32";
    public static C_S_TAG_EXPIRYDATE: string = "33";
    public static C_S_TAG_STRIKEPRICE: string = "34";
    public static C_S_TAG_OPTIONTYPE: string = "35";
    public static C_S_TAG_NOOFRECORDS: string = "36";
    public static C_S_TAG_BEST5NOOFORDERS: string = "37";
    public static C_S_TAG_MARKETTYPE: string = "38";
    public static C_S_TAG_NEWS_COL: string = "40";
    public static C_S_TAG_CLOSING_INDEX_VALUE: string = "41";
    public static C_S_TAG_INSTRUMENTID: string = "43";
    public static C_S_TAG_MARKETLOT: string = "47";
    public static C_S_TAG_PRICETICK: string = "48";
    public static C_S_TAG_CUMULATIVEOI: string = "49";
    public static C_S_TAG_CONNECTION_TYPE: string = "51";
    public static C_S_TAG_NETCHANGEFROMPREVCLOSE: string = "54";
    public static C_S_TAG_MSGVERSION: string = "63";
    public static C_S_TAG_MSGCODE: string = "64";
    public static C_S_TAG_MSGLENGTH: string = "65";
    public static C_S_TAG_MSGTIME: string = "66";
    public static C_S_TAG_USERID: string = "67";
    public static C_S_TAG_PWD: string = "68";
    public static C_S_TAG_AUTHCODE: string = "70";
    public static C_S_TAG_ORDERTYPE: string = "72";
    public static C_S_TAG_LTT: string = "73";
    public static C_S_TAG_LUT: string = "74";
    public static C_S_TAG_OPENPRICE: string = "75";
    public static C_S_TAG_CLOSEPRICE: string = "76";
    public static C_S_TAG_HIGHPRICE: string = "77";
    public static C_S_TAG_LOWPRICE: string = "78";
    public static C_S_TAG_VOLUME: string = "79";
    public static C_S_TAG_ATP: string = "80";
    public static C_S_TAG_TOTBUYQTY: string = "81";
    public static C_S_TAG_TOTSELLQTY: string = "82";
    public static C_S_TAG_FLAG: string = "85";
    public static C_S_TAG_CHANGEINDICATOR: string = "87";
    public static C_S_TAG_OPENINTEREST: string = "88";
    public static C_S_TAG_PREVCLOSEPRICE: string = "92";
    public static C_S_TAG_LIFETIMEHIGH: string = "93";
    public static C_S_TAG_LIFETIMELOW: string = "94";
    public static C_S_TAG_BCASTREQTYPE: string = "95";
    public static C_S_TAG_SECURITYDESCRIPTION: string = "96";
    public static C_S_TAG_PERCENTAGECHANGE: string = "99";
    public static C_S_TAG_INDEXNAME: string = "100";
    public static C_S_TAG_MKTCAPITALIZATION: string = "102";
    public static C_S_TAG_OPERATIONTYPE: string = "230";
    public static C_S_TAG_MINVALUE: string = "309";
    public static C_S_TAG_MAXVALUE: string = "310";
    public static C_S_TAG_ALERT_SUBJECT: string = "325";
    public static C_S_TAG_PRODUCTTYPE: string = "368";
    public static C_S_TAG_DPR: string = "380";
    public static C_S_TAG_NETCHANGEINRS: string = "393";
    public static C_S_TAG_IPADDRESS: string = "395";
    public static C_S_TAG_GROUPID: string = "396";
    public static C_S_TAG_USERCODE: string = "397";
    public static C_S_TAG_DECIMALLOCATOR: string = "399";
    public static C_S_POSINDICATOR: string = "416";
    public static C_S_TAG_ALERTERRORCODE: string = "451";
    public static C_S_TAG_AUCTIONSESSIONNO: string = "453";
    public static C_S_TAG_SPOSFLAG: string = "462";
    public static C_S_TAG_MARGINPLUSPROTPERC: string = "463";
    public static C_S_TAG_GLOBALSCRIP: string = "464";
    public static C_S_TAG_SPREAD: string = "468";
    public static C_S_TAG_FIILIMIT: string = "469";
    public static C_S_TAG_NRILIMIT: string = "470";
    public static C_S_TAG_ISSPREADSCRIP: string = "471";
    public static C_S_TAG_FIRST_LEGPRICE: string = "472";
    public static C_S_TAG_SECOND_LEGPRICE: string = "473";
    public static C_V_ALERTERRORCODEVALUE: string = "33";
    public static C_S_TAG_IMPLIEDVOLATILITY: string = "601";
    public static C_S_TAG_BUYVOLATILITY: string = "602";
    public static C_S_TAG_SELLVOLATILITY: string = "603";
    public static C_S_TAG_THEORETICALPRICE: string = "604";
    public static C_S_TAG_DELTA: string = "605";
    public static C_S_TAG_GAMMA: string = "606";
    public static C_S_TAG_THETA: string = "607";
    public static C_S_TAG_VEGA: string = "608";
    public static C_S_TAG_RHO: string = "609";
    public static C_S_TAG_INTHEMONEY: string = "610";
    public static C_S_TAG_PERC_OPENINTEREST: string = "465";
    public static C_S_TAG_HIGH_OPENINTEREST: string = "466";
    public static C_S_TAG_LOW_OPENINTEREST: string = "467";
    public static C_V_TAG_LV_VALUE: string = "1024";
    public static C_S_TAG_FAIR_VALUE: string = "716";

    public static C_S_TAG_MWSCRIPDESC: string = "1001";
    public static C_S_TAG_Collapse: string = "11004";
    public static C_S_TAG_ALERTREMARK: string = "1003";
    public static C_S_TAG_POS: string = "477";
    public static C_S_TAG_RECOMMENDATION_COL: string = "199";
    public static C_S_TAG_TRADE_EXECUTION_RANGE: string = "499";
    public static C_S_TAG_TRADE_EXECUTION_RANGE_RESPONSE: string = "155";

    //Corporate Action and More Column
    public static C_S_TAG_EVENTS: string = "1004";
    public static C_S_TAG_ONE_WEEK_HIGH: string = "1005";
    public static C_S_TAG_ONE_WEEK_LOW: string = "1006";
    public static C_S_TAG_ONE_MONTH_HIGH: string = "1007";
    public static C_S_TAG_ONE_MONTH_LOW: string = "1008";
    public static C_S_TAG_THREE_MONTHS_HIGH: string = "1009";
    public static C_S_TAG_THREE_MONTHS_LOW: string = "1010";
    public static C_S_TAG_SIX_MONTHS_HIGH: string = "1011";
    public static C_S_TAG_SIX_MONTHS_LOW: string = "1012";
    public static C_S_TAG_ONE_WEEK_PER_CHANGE: string = "1013";
    public static C_S_TAG_ONE_MONTH_PER_CHANGE: string = "1014";
    public static C_S_TAG_THREE_MONTHS_PER_CHANGE: string = "1015";
    public static C_S_TAG_SIX_MONTHS_PER_CHANGE: string = "1016";
    public static C_S_TAG_PER_BELOW_52_WEEK_HIGH: string = "1017";
    public static C_S_TAG_PER_ABOVE_52_WEEK_LOW: string = "1018";
    public static C_S_TAG_YESTERDAY_HIGH: string = "1019";
    public static C_S_TAG_YESTERDAY_LOW: string = "1020";
    public static C_S_TAG_FIVE_DAYS_AVERAGE_VOLUME: string = "1021";
    public static C_S_TAG_THREE_MONTHS_AVERAGE_VOLUME: string = "1022";
    public static C_S_TAG_SIX_MONTHS_AVERAGE_VOLUME: string = "1023";
    public static C_S_TAG_PREMIUM: string = "1025";
    public static C_S_TAG_DISCOUNT: string = "1026";
    public static C_S_TAG_CONTROLTYPE: string = "503";

    // public static C_V_MSGCODES_LOGOFFREQUEST: string ="108";
    public static C_V_MSGCODES_MARKETSTATUS_REPONSE: string = "110";
    public static C_S_MSGCODE_BESTFIVE_REQUEST: string = "127";
    public static C_S_MSGCODE_BESTFIVE_RESPONSE: string = "128";
    public static C_S_MSGCODE_MULTIPLE_TOUCHLINE_REQUEST: string = "206";
    public static C_S_MSGCODE_MULTIPLE_TOUCHLINE_RESPONSE: string = "209";
    public static C_S_MSGCODE_SOCKETLOGINREQUEST: string = "255";
    public static C_S_MSGCODE_SOCKETLOGONRESPONSE: string = "102";
    public static C_S_MSGCODE_LOGOFF_RESPONSE: string = "109";
    public static C_S_MSGCODE_INDEX_SUBSCRIPTION_REQUEST: string = "1002";
    public static C_S_MSGCODE_MORE_INDICES_REQUEST: string = "262";
    public static C_S_MSGCODE_INDEX_SUBSCRIPTION_RESPONSE: string = "222";
    public static C_S_MSGCODE_INDEX_DETAILS_REQUEST: string = "224";
    public static C_S_MSGCODE_INDEX_DETAILS_RESPONSE: string = "225";
    public static C_S_MSGCODE_TOPGAINERSLOSERS_REQUEST: string = "157";
    public static C_S_MSGCODE_TOPGAINERSLOSERS_RESPONSE: string = "158";
    public static C_S_MSGCODE_MOSTACTIVE_REQUEST: string = "159";
    public static C_S_MSGCODE_MOSTACTIVE_RESPONSE: string = "160";
    public static C_V_MSGCODES_ORDERENTRYMODIFYCANCEL_REQUEST: string = "121";
    public static C_V_MSGCODES_ORDER_RESPONSE: string = "122";
    public static C_V_MSGCODES_ORDER_ACKNOWLEDGEMENT: string = "123";
    public static C_V_MSGCODES_TRADE_RESPONSE: string = "124";
    public static C_V_MSGCODES_TRADE_RESPONSE_TRADEBOOK: string = "137";
    public static C_V_MSGCODES_SLTRIGGER_RESPONSE: string = "150";
    public static C_V_MSGCODES_POSITION_CONVERSION_ENTRY: string = "1";
    public static C_V_MSGCODES_POSITION_CONVERSION_REQUEST: string = "250";
    public static C_V_MSGCODES_POSITION_CONVERSION_RESPONSE: string = "252";
    public static C_V_MSGCODES_POSITION_CONVERSION_ACK: string = "251";
    public static C_V_MSGCODES_AUCTIONSTATUS_REPONSE: string = "265";
    public static C_V_MSGCODES_ADMINMESSAGE: string = "907";
    public static C_S_MSGCODES_NEWS_RESPONSE: string = "301";
    public static C_V_MSGCODES_BRACKETORDER_ORDER_REQUEST: string = "421";
    public static C_V_MSGCODES_BRACKETORDER_ORDER_RESPONSE: string = "422";
    public static C_V_MSGCODES_BRACKETORDER_ORDER_ACKNOWLEDGEMENT: string = "423";
    public static C_V_MSGCODES_SSO_TOKEN_NOT_FOUND: string = "112";

    public static C_S_MSGCODE_LTP_MULTIPLE_TOUCHLINE_REQUEST = "347";
    public static C_S_MSGCODE_LTP_MULTIPLE_TOUCHLINE_RESPONSE = "348";
    public static C_S_MSGCODE_PAUSERESUME_REQUEST: string = "106";

    //3725
    public static C_S_TAG_ASSETTOKEN: string = "5049";

    public static C_S_TAG_COMMPROTOCOL: string = "FT3.0";

    public static C_S_CHAR0: string = "\u0000";  //End of response
    public static C_S_CHAR2: string = "\u0002";  //Start of response

    public static E_OK: number = 0;
    public static C_V_NORMAL_DECIMALLOCATOR: number = 100;
    public static C_V_CURRENCY_DECIMALLOCATOR: number = 10000;
    public static C_S_SERIES_SM: string = "SM";
    public static C_S_MSGCAT_ACK: string = "ACK";
    public static C_S_MSGCAT_ORDER: string = "ORDER";
    public static C_S_MSGCAT_TRADE: string = "TRADE";
    public static C_S_MSGCAT_ALERT: string = "ALERT";
    public static C_S_MSGCAT_SCRIPALERT: string = "SCRIPALERT";
    public static C_S_MSGCAT_NEWS: string = "NEWS";
    public static C_S_MSGCAT_RECO: string = "RECO";
    public static C_S_MSGCAT_LOGIN: string = "LOGIN";
    public static C_S_MSGCAT_POSCON: string = "POSCON";

    public static C_S_INVALIDPROFILEID: string = "-1";
    public static C_S_SYSTEM_PROFILEID: string = "100";

    public static C_V_NSECDS_DECLOC: string = "10000000";
    public static C_V_BSECDX_DECLOC: string = "10000000";

    public static C_V_TAG_MKT_PROT: number = 486;



    // #region "Order Status"
    public static C_V_ORDER_REQUEST_ENTRY: string = "1";
    public static C_V_ORDER_REQUEST_MODIFY: string = "2";
    public static C_V_ORDER_REQUEST_CANCEL: string = "3";
    public static C_S_ORDERSTATUS_DEVICEXMITTED: string = "1";
    public static C_S_ORDERSTATUS_GATEWAYXMITTED: string = "2";
    public static C_S_ORDERSTATUS_OMSXMITTED: string = "3";
    public static C_S_ORDERSTATUS_EXCHANGEXMITTED: string = "4";
    public static C_S_ORDERSTATUS_PENDING: string = "5";
    public static C_S_ORDERSTATUS_CANCELLED: string = "6";
    public static C_S_ORDERSTATUS_EXECUTED: string = "7";
    public static C_S_ORDERSTATUS_ADMINPENDING: string = "8";
    public static C_S_ORDERSTATUS_GATEWAYREJECT: string = "9";
    public static C_S_ORDERSTATUS_OMSREJECT: string = "10";
    public static C_S_ORDERSTATUS_ORDERERROR: string = "11";
    public static C_S_ORDERSTATUS_FROZEN: string = "12";
    public static C_S_ORDERSTATUS_MINIADMINPENDING: string = "13";
    public static C_S_ORDERSTATUS_ADMINACCEPT: string = "14";
    public static C_S_ORDERSTATUS_ADMINREJECT: string = "15";
    public static C_S_ORDERSTATUS_ADMINMODIFY: string = "16";
    public static C_S_ORDERSTATUS_ADMINCANCEL: string = "17";
    public static C_S_ORDERSTATUS_AMOSUBMITTED: string = "18";
    public static C_S_ORDERSTATUS_AMOCANCELLED: string = "19";
    public static C_V_ORDERSTATUS_BOCONVERTED: string = "22";

    public static C_S_ORDERSTATUS_DEVICEXMITTED_TEXT: string = "CLIENT XMITTED";
    public static C_S_ORDERSTATUS_PENDING_TEXT: string = "PENDING";
    public static C_S_ORDERSTATUS_TRADED_TEXT: string = "TRADED";
    public static C_S_ORDERSTATUS_CANCEL_TEXT: string = "CANCELLED";
    public static C_S_ORDERSTATUS_EXECUTED_TEXT: string = "EXECUTED";
    public static C_S_ORDERSTATUS_ADMINPENDING_TEXT: string = "ADMIN PENDING";
    public static C_S_ORDERSTATUS_GATEWAYREJECT_TEXT: string = "GATEWAY REJECT";
    public static C_S_ORDERSTATUS_OMSREJECT_TEXT: string = "OMS REJECT";
    public static C_S_ORDERSTATUS_ORDERERROR_TEXT: string = " ORDER ERROR";
    public static C_S_ORDERSTATUS_OMSXMITTED_TEXT: string = "OMS XMITTED";
    public static C_S_ORDERSTATUS_GATEWAYXMITTED_TEXT: string = "GATEWAY XMITTED";
    public static C_S_ORDERSTATUS_EXCHANGEXMITTED_TEXT: string = "EXCHANGE XMITTED";
    public static C_S_ORDERSTATUS_FROZEN_TEXT: string = "FROZEN";
    public static C_S_ORDERSTATUS_REJECTED_TEXT: string = "REJECTED";

    public static C_S_ORDERSTATUS_AMOSUBMITTED_TEXT: string = "AMO SUBMITTED";
    public static C_S_ORDERSTATUS_AMOCANCELLED_TEXT: string = "AMO CANCELLED";

    public static C_S_ORDERSTATUS_MINIADMINPENDING_TEXT: string = "M.PENDING";
    public static C_S_ORDERSTATUS_ADMINACCEPT_TEXT: string = "A.ACCEPT";
    public static C_S_ORDERSTATUS_ADMINREJECT_TEXT: string = "A.REJECT";
    public static C_S_ORDERSTATUS_ADMINMODIFY_TEXT: string = "A.MODIFY";
    public static C_S_ORDERSTATUS_ADMINCANCEL_TEXT: string = "A.CANCEL";



    // #region "Page ID's"
    public static C_V_MARKETWATCH_PAGENO: number = 1;
    public static C_V_SYMBOLLOOKUP_PAGENO: number = 2;
    public static C_V_ORDERBOOK_PAGENO: number = 3;
    public static C_V_BESTFIVE_PAGENO: number = 4;
    public static C_V_NETPOSITION_PAGENO: number = 5;
    public static C_V_STOCKVIEW_PAGENO: number = 6;

    public static C_V_COMBINEDDEPTH_PAGE: number = 12;
    public static C_V_ORDERENTRY_PAGE: number = 13;
    public static C_V_INDEXWATCH_PAGE: number = 14;
    public static C_V_BULKORDERENTRY_PAGE: number = 15;
    public static C_V_AUCTIONSTATUS_PAGE: number = 16;
    public static C_V_RECOMMENDATION_PAGE: number = 17;
    public static C_V_MARGINCALCULATOR_PAGE: string = "221";
    public static C_V_NETPOSITION_ADD_POSITION: number = 20;

    public static C_V_CALLPUTRATIO_PAGE: number = 19;
    public static OE_PANELTYPE_DERV: string = "DERIVATIVES";
    public static LOOKUP_DERV: string = "LOOKUPDERV";
    public static C_V_POLMT: string = "1";
    public static C_V_POMKT: string = "2";

    public static C_S_SETALERTS_QUERYSTAMPID: string = "QueryStampId";
    public static C_S_SETALERTS_PREDEFINEDID: string = "PredefinedId";

    public static C_S_TAG_ALERT_IN_QUEUE: string = "In Queue";
    public static C_S_TAG_ALERT_SUCCESS: string = "Success";

    public static C_V_TAG_SCA_MSGBOX: number = 8;
    public static C_V_TAG_SCA_MSGBAR: number = 16;
    public static C_V_TAG_SCA_BALLOON: number = 32;
    public static C_V_TAG_SCA_SMS: number = 4;
    public static C_V_TAG_SCA_EMAIL: number = 2;

    public static C_S_SETALERTS_PARAM1: string = "Param1";
    public static C_S_SETALERTS_PARAM2: string = "Param2";
    public static C_S_SETALERTS_OPERATOR: string = "Operator";
    public static C_S_SETALERTS_MODESALLOWED: string = "Modes Allowed";
    public static C_S_SETALERTS_ALERTNO: string = "Alert Number";
    public static C_S_SETALERTS_LTP: string = "Last Traded Price";
    public static C_S_SETALERTS_BID: string = "Bid Price";
    public static C_S_SETALERTS_OFFER: string = "Offer Price";
    public static C_S_SETALERTS_LTQ: string = "Last Traded Quantity";
    public static C_S_SETALERTS_BIDQTY: string = "Bid Quantity";
    public static C_S_SETALERTS_OFFERQTY: string = "Offer Quantity";
    public static C_S_SETALERTS_VOLUME: string = "Volume";
    public static C_S_SETALERTS_VALUE: string = "Value";
    public static C_S_SETALERTS_PERCENTCHANGE: string = "% Change";
    public static C_S_SETALERTS_ATP: string = "Average Traded Price";
    public static C_S_SETALERTS_OICHANGE: string = "Open Interest % Change";
    public static C_S_SETALERTS_PREVCLOSE: string = "Previous Close";
    public static C_S_SETALERTS_PREVHIGH: string = "Previous High";
    public static C_S_SETALERTS_PREVLOW: string = "Previous Low";
    public static C_S_SETALERTS_PREVOPEN: string = "Previous Open";
    public static C_S_SETALERTS_OPENPRICE: string = "Open Price";
    public static C_S_SETALERTS_HIGH: string = "High";
    public static C_S_SETALERTS_LOW: string = "Low";
    public static C_S_SETALERTS_52WEEKHIGH: string = "52Week High/Life Time High";
    public static C_S_SETALERTS_52WEEKLOW: string = "52Week Low/Life Time Low";
    public static C_S_SETALERTS_USEVALUE: string = "Use Value";
    public static C_S_SETALERTS_PREVVOLUME: string = "Previous Volume";
    public static C_S_SETALERTS_PREVVALUE: string = "Previous Value";
    public static C_S_SETALERTS_PREVOI: string = "Previous OI";
    public static C_S_SETALERTS_OPENINTEREST: string = "Open Interest";

    public static C_S_GREATER_THAN_EQUAL_TO_STR: string = ">=";
    public static C_V_GREATER_THAN_EQUAL_TO_STR_ID: number = 0;
    public static C_S_LESS_THAN_EQUAL_TO_STR: string = "<=";
    public static C_V_LESS_THAN_EQUAL_TO_STR_ID: number = 1;
    public static C_S_GREATER_THAN_STR: string = ">";
    public static C_V_GREATER_THAN_STR_ID: number = 2;
    public static C_S_LESS_THAN_STR: string = "<";
    public static C_V_LESS_THAN_STR_ID: number = 3;
    public static C_S_EQUAL_TO_STR: string = "=";
    public static C_V_EQUAL_TO_STR_ID: number = 4;

    public static C_V_SETALERTS_LTP: number = 0;
    public static C_V_SETALERTS_BID: number = 1;
    public static C_V_SETALERTS_OFFER: number = 2;
    public static C_V_SETALERTS_LTQ: number = 3;
    public static C_V_SETALERTS_BIDQTY: number = 4;
    public static C_V_SETALERTS_OFFERQTY: number = 5;
    public static C_V_SETALERTS_VOLUME: number = 6;
    public static C_V_SETALERTS_VALUE: number = 7;
    public static C_V_SETALERTS_PERCENTCHANGE: number = 8;
    public static C_V_SETALERTS_ATP: number = 9;
    public static C_V_SETALERTS_OIPERCCHANGE: number = 11;
    public static C_V_SETALERTS_PREVCLOSE: number = 12;
    public static C_V_SETALERTS_PREVHIGH: number = 14;
    public static C_V_SETALERTS_PREVLOW: number = 16;
    public static C_V_SETALERTS_PREVOPEN: number = 18;
    public static C_V_SETALERTS_OPENPRICE: number = 17;
    public static C_V_SETALERTS_HIGH: number = 13;
    public static C_V_SETALERTS_LOW: number = 15;
    public static C_V_SETALERTS_52WEEKHIGH: number = 22;
    public static C_V_SETALERTS_52WEEKLOW: number = 21;
    public static C_V_SETALERTS_USEVALUE: number = 24;
    public static C_V_SETALERTS_PREVVOLUME: number = 19;
    public static C_V_SETALERTS_PREVVALUE: number = 20;
    public static C_V_SETALERTS_PREVOI: number = 23;
    public static C_V_SETALERTS_OPENINTEREST: number = 10;

    public static C_V_TAG_MSGBOX: number = 8;
    public static C_V_TAG_MSGBAR: number = 16;
    public static C_V_TAG_BALLOON: number = 32;
    public static C_S_AMO_TEXT: string = "AMO";
    public static C_S_PREOPENMARKET_TEXT: string = "Pre Open";
    public static ScripStoreToken: number = 0;
    public static ScripStoreSymbol: number = 1;
    public static ScripStoreOptionType: number = 2;
    public static ScripStoreStrikePrice: number = 3;
    public static ScripStoreExpiryDateValue: number = 4;
    public static ScripStoreExpiryDate: number = 4;
    public static ScripStoreSeries: number = 5;
    public static ScripStoreInstrumentName: number = 6;
    public static ScripStoreRegularLot: number = 8;
    public static ScripStorePriceTick: number = 9;
    public static ScripStoreDecimalLocator: number = 10;
    public static ScripStoreISIN: number = 11;
    public static ScripStoreAssetToken: number = 12;
    public static ScripStoreSPOSType: number = 13;
    public static ScripStoreIsGlobal: number = 14;

    public static ScripStoreSpread: number = 15;
    public static ScripStoreFIILimit: number = 16;
    public static ScripStoreNRILimit: number = 17;
    public static ScripStorePOS: number = 18;        // added for MCXSX EQ

    public static ScripStorePriceNumerator: number = 21;
    public static ScripStorePriceDenominator: number = 22;
    public static ScripStoreGenNumerator: number = 23;
    public static ScripStoreGenDenominator: number = 24;
    public static ScripStoreIntrinsicValue: number = 19;

    public static C_S_CHANNEL_INTERACTIVE: string = "Interactive";
    public static C_S_CHANNEL_BROADCAST: string = "Broadcast";
    public static C_S_CHANNEL_WCF: string = "WCF";

    public static DATA_TYPE: number = 2;
    public static COMPRESSION_LEVEL: number = 5;

    public static DEFAULT_BASICINTRADAY_DAYS_NOS: number = 0;
    public static DEFAULT_ADVANCEDINTRADAY_DAYS_NOS: number = 25;
    public static DEFAULT_BASICHISTORIC_RECORDS_NOS: number = 0; //001-00-490160
    public static DEFAULT_ADVANCEDHISTORIC_RECORDS_NOS: number = 0;

    public static C_V_TAG_POSITIONTYPE: number = 5023;
    public static C_S_TAG_REFRESH: string = "992";

    public static C_V_TAG_NETQTY: number = 999;
    public static C_V_TAG_MAPPEDMKTSEGID: number = 5026;
    public static C_V_TAG_OPT: number = 6011;

    public static C_S_TAG_NEWS_VENDORCODE: string = "1";
    public static C_S_TAG_NEWSID: string = "421";
    public static C_S_TAG_NEWS_OLDTOKEN: string = "422";
    public static C_S_TAG_NEWS_CATEGORIES: string = "424";
    public static C_S_TAG_ISIN_NO: string = "426";
    public static C_S_TAG_NEWS_ACTIVEFLAG: string = "427";
    public static C_S_TAG_NEWSTYPE: string = "431";
    public static C_S_TAG_NEWS_HEADLINE: string = "429";
    public static C_S_TAG_NEWS_ERRORCODE: string = "432";

    public static C_S_NEWS_DISPLAY_POPUP: string = "1";
    public static C_S_NEWS_DISPLAY_MSGBAR: string = "2";
    public static C_S_NEWS_DISPLAY_POPUPNMSGBAR: string = "3";

    public static C_S_NEWS_NONEWS: string = "0";
    public static C_S_NEWS_NORMALNEWS_UNREAD: string = "1";
    public static C_S_NEWS_HOTNEWS_UNREAD: string = "2";
    public static C_S_NEWSTYPE_HOT: string = "H";
    public static C_S_NEWSFEEDER_ID: string = "1011";

    public static C_S_MENU_TRADING_MKTWATCH: string = "200";
    public static C_S_MENU_HOME_LANDINGPAGE: string = "269";
    public static C_S_MENU_TRADING_TRADEBOOK: string = "244"; //
    public static C_S_MENU_TRADING_ORDERBOOK: string = "243"; //
    public static C_S_MENU_TRADING_NETPOSITION: string = "245"; //
    public static C_S_MENU_TRADING_STOCKVIEW: string = "246"; //
    public static C_S_MENU_TRADING_FUNDSVIEW: string = "247";//
    public static C_S_MENU_TRADING_TRADEHISTORY: string = "226"; //

    public static C_S_MENU_MKTINQUIRY_ONLINEMSG: string = "250";
    public static C_S_MENU_MKTINQUIRY_MOSTACTIVE: string = "201";
    public static C_S_MENU_MKTINQUIRY_TOPGAINERSLOSERS: string = "202";
    public static C_S_MENU_MKTINQUIRY_INDEXDETAILS: string = "203";//

    public static C_S_MENU_FAIRVALUECALCULATOR: string = "215";//
    public static C_S_MENU_OPTIONCALCULATOR: string = "219";//
    public static C_S_MENU_ADVANCECHART: string = "211";//

    public static C_S_MENU_MARGINREPORT: string = "234";
    public static C_S_MENU_ALERTS: string = "236";
    public static C_S_MENU_EVENTSCANNER: string = "261";

    public static C_S_MENU_TRADING_BULKORDERENTRY: string = "252";
    public static C_S_MENU_TRADING_KEYBOARDSHORTCUTS: string = "265";

    public static C_S_MENU_OE_SPOT: string = "248";
    public static C_S_MENU_FUND_TRANSFER: string = "230";
    public static C_S_MENU_BESTFIVE: string = "1002";
    public static C_S_MENU_CURRENCYCALCULATOR: string = "216";
    public static C_S_MENU_PIVOTPOINTCALCULATOR: string = "218";//

    public static C_S_MENU_RETRACEMENTCALCULATOR: string = "220";
    public static C_S_MENU_EXTENSIONCALCULATOR: string = "217";
    public static C_S_MENU_OPTIONSCHAIN: string = "1022";
    public static C_S_MENU_MYPORTFOLIO: string = "263";
    public static C_S_MENU_RECO_HISTORY: string = "238";
    public static C_S_LOG_LOGIN: string = "Login";
    public static C_S_LOG_MKTWATCH: string = "MarketWatch";
    public static C_S_LOG_POSCONV: string = "PositionConversion";
    public static C_S_BYVOLUME: string = "1";
    public static C_S_BYVALUE: string = "2";
    public static C_S_GAINERS: string = "1";
    public static C_S_LOSERS: string = "2";

    public static C_V_COLUMNTEMPLATE_ORDERBOOK: number = 1;
    public static C_V_COLUMNTEMPLATE_TRADEBOOK: number = 2;
    public static C_V_COLUMNTEMPLATE_MARKETWATCH: number = 3;
    public static C_V_COLUMNTEMPLATE_NETPOSITION: number = 4;
    public static C_V_COLUMNTEMPLATE_STOCKVIEW: number = 5;
    public static C_V_COLUMNTEMPLATE_OPTIONSCHAIN: number = 6;
    public static C_V_COLUMNTEMPLATE_MW_PIVOT_WATCH: number = 7;
    public static C_S_EXCH_NSEFNO: string = "NSE F&O";
    public static C_S_EXCH_BSEFNO: string = "BSE F&O";
    public static C_S_EXCH_NCDEX: string = "NCDEX";
    public static C_S_EXCH_MCX: string = "MCX";
    public static C_S_EXCH_MCXSX_CURR: string = "MSE CURR";
    public static C_S_EXCH_MCXSX_FAO: string = "MSE F&O";
    public static C_S_EXCH_NSX: string = "NSECDS";
    public static C_S_EXCH_NMCE: string = "NMCE";
    public static C_S_EXCH_BFX: string = "BFX";
    public static C_S_EXCH_DGCX: string = "DGCX";
    public static C_S_EXCH_UCX: string = "UCX";
    public static C_S_EXCH_ALL: string = "ALL";
    public static C_S_EXCH_BSECDX: string = "BSECDS";

    public static C_V_MORE_INDEX_NSE: number = 1;
    public static C_V_MORE_INDEX_BSE: number = 21;
    public static C_V_MORE_INDEX_MCX: number = 31;
    public static C_V_MORE_INDEX_NCDEX: number = 41;
    public static C_V_GLOBAL_INDEX: number = 51;

    public static C_V_MSXEQ_INDEX = 512;
    public static C_V_GLOBALINDEX_DJ: number = 26027;
    public static C_V_GLOBALINDEX_SP: number = 26028;
    public static C_V_GLOBALINDEX_FTSE100: number = 26039;
    public static C_V_PRODUCT_CODE_AWP: number = 2;
    public static C_S_VENDOR_VERISIGN: string = "2";
    public static C_S_VENDOR_PTN: string = "3";
    public static C_S_VENDOR_ECIPHER: string = "4";
    public static C_S_VENDOR_TWOFAQA: string = "9";

    public static C_V_TAG_2FA_TOKEN: number = 5031;
    public static C_V_TAG_2FA_SYNCHTOKEN: number = 5034;
    public static ECIPHER_VAL_SESSION: number = 1;
    public static C_V_2FA_PRODUCTID_NETNET: number = 1;

    public static C_S_PRODUCTNAME_NETNET: string = "NETNET";

    public static C_S_PRODUCTNAME_NETNETHT_DESKTOP: string = "Net.Net HT";
    public static C_S_PRODUCTNAME_NETNETHT_TABLET: string = "Net.Net HT Tab";
    public static C_S_PRODUCTNAME_NETNETHT_MOBILE: string = "Net.Net HT Mobile";
    public static C_V_TAG_MANAGERTIME: number = 5080;
    public static C_V_TAG_MANAGERTIMESPANLOST: number = 5081;

    public static C_S_FACILITY_ALERT: string = "ALERT";
    public static C_S_FACILITY_BULKORDER: string = "BULKORDER";
    public static C_S_FACILITY_POSITIONCONVERSION: string = "POSCONV";
    public static C_S_FACILITY_STOCKWATCH: string = "STOCKWATCH";
    public static C_S_FACILITY_PREVIOUSTRADES: string = "PREVTRADES";
    public static C_S_FACILITY_HEATMAP: string = "HEATMAP";
    public static C_S_CHART_TYPE: string = "2";
    public static C_S_CHART_TYPE_INTRADAY: string = "1";
    public static C_S_CHART_TYPE_HISTORIC: string = "2";
    public static C_S_CHART_TYPE_HISTORIC_CD: string = "3";
    public static C_S_ADVANCED_CHART_TEXT: string = "Advanced Chart";
    public static CONST_CURRENCY: string = "$";
    public static CONST_DATEFORMATTER: string = "%%DATE%%";
    public static CONST_TIMEFORMATTER: string = "%%TIME%%";

    public static CSS_ExpandCheckBoxTreeView: string = "ExpandCheckBoxTree";
    public static CSS_CollapseCheckBoxTreeView: string = "CollapseCheckBoxTree";
    public static C_S_HTML_MOBILE_DEVICE: string = "6";
    public static C_S_HTML_TABLET_DEVICE: string = "5";
    public static C_V_QTYCOUNTERTOUCHLINEBASED: number = 1;
    public static C_V_QTYVALUEBASED: number = 3;
    public static C_V_QTYLOTBASED: number = 2;
    public static C_S_PRODUCTNAME_NETNET_HTML5_TABLET_SL: string = "SMC ACE";
    public static C_S_FORGOTPWD_EMAILVALIDTYPE: string = "E";
    public static C_S_FORGOTPWD_MOBILEVALIDTYPE: string = "M";
    public static C_S_FORGOTPWD_PANVALIDTYPE: string = "P";
    public static C_S_FORGOTPWD_EMAILMOBILEVALIDTYPE: string = "E,M";
    public static C_S_FORGOTPWD_EMAILPANVALIDTYPE: string = "E,P";
    public static C_S_FORGOTPWD_MOBILEPANVALIDTYPE: string = "M,P";
    public static C_S_FORGOTPWD_EMAILMOBILEPANVALIDTYPE: string = "E,M,P";
    public static C_V_TAG_INTRAHIST_FLAG: number = 20;
    public static C_V_TAG_INTRADAY_DAYS: number = 21;
    public static C_V_TAG_CHARTDATA_TYPE: number = 22;
    public static C_V_TAG_CHARTTYPE: number = 23;
    public static C_V_TAG_CHART_RECORDS: number = 24;
    public static C_V_TAG_CHARTCONTINIOUS_FLAG: number = 25;

    public static C_V_BRACKET_MAIN_LEG_INDICATOR: number = 9;
    public static C_V_BRACKET_SL_LEG_INDICATOR: number = 10;
    public static C_V_BRACKET_PROFIT_LEG_INDICATOR: number = 11;
    public static C_V_BRACKET_PARTIAL_PROFIT_LEG_INDICATOR: number = 12;
    public static C_V_BRACKET_SL_RESV_LEG_INDICATOR: number = 13;
    public static C_V_BRACKET_PROFIT_RESV_LEG_INDICATOR: number = 14;

    public static C_V_CRP_PRODTYPE_MASKMARGINPLUS: number = 4;
    public static C_V_CRP_PRODTYPE_MASKBRACKETORDER: number = 8192;

    public static C_V_BRACKET_ORDER_MODIFY_LEG1_MASKBIT: number = 1;
    public static C_V_BRACKET_ORDER_MODIFY_LEG2_MASKBIT: number = 2;
    public static C_V_BRACKET_ORDER_MODIFY_LEG3_MASKBIT: number = 4;

    public static C_V_Int32_MAXVALUE: number = 2147483647;
    public static C_S_FULL_MARGIN: string = "FULL";
    public static C_S_FIXED_MARGIN: string = "FIXED";
    public static C_V_MARKETWATCH_FONT_SIZE: string = "11px";
    public static C_S_REQUIREHEADER: string = "RH";

    public static CONST_RESP_FIELDS_ROW_SEPERATOR = "|";
    public static CONST_RESP_FIELDS_COL_SEPERATOR = "~";
    public static C_S_VendorId_FTIL: any = 3;
    public static C_S_PTNType_TOKEN: any = 1;
    public static C_S_PTNType_QA: any = 9;
    public static C_V_TAG_ASSETTOKEN = 5049;
    public static C_V_TAG_ISIN = 426;

    public static C_S_BOM_BANKID: string = "BOM";
    public static C_S_BOMHOLD_BANKID: string = "BOMHOLD";
    public static C_S_SIB_BANKID: string = "SIB";
    public static C_S_SIBHOLD_BANKID: string = "SIBHOLD";
    public static C_S_CBI_BANKID: string = "CBI";
    public static C_S_CBIHOLD_BANKID: string = "CBIHOLD";
    public static C_S_ING_BANKID: string = "ING";
    public static C_S_INGHOLD_BANKID: string = "INGHOLD";
    public static C_S_OBC_BANKID: string = "OBC";
    public static C_S_OBCHOLD_BANKID: string = "OBCHOLD";
    public static C_S_PNB_BANKID: string = "PNB";
    public static C_S_PNBHOLD_BANKID: string = "PNBHOLD";
    public static C_S_HDFC_BANKID: string = "HDFC";
    public static C_S_ATOMPG_BANKID: string = "ATOMPG";
    public static C_S_UBI_BANKID: string = "UBI";
    public static C_S_INDIANHOLD_BANKID: string = "INDIANHOLD";
    public static C_S_HDFCS2S_BANKID: string = "HDFCS2S";
    public static C_S_ANDHRA_BANKID: string = "ANDHRA";
    public static C_S_UBIHOLD_BANKID: string = "UBIHOLD";
    public static C_S_BOBHOLD_BANKID: string = "BOB";
    public static C_S_BANK_ID_UCOHOLDSYNC: string = "UCOHOLDSYNC";
    public static C_S_MW_SINGLE_COLTEMPLATE_NAME: string = "UDCOLTMPT";

    public static C_V_TEMPLATESTRING = 507;
    public static C_V_TEMPLATEDETAILS = 508;
    public static C_V_TEMPLATENAME = 509;
    public static C_V_TAG_LOGONTYPE = 5001;
    public static C_V_TAG_TERMID = 5002;
    public static C_V_TAG_USERNAME = 5003;
    public static C_V_TAG_GROUPCODE = 5004;
    public static C_V_TAG_FORCELOGININPUTFLAG = 5005;
    public static C_V_TAG_USERPRODUCT = 5006;
    public static C_V_TAG_LOGONSUCCESS = 5007;
    public static C_V_TAG_OCINTERACTIVEIP = 5008;
    public static C_V_TAG_OCINTERACTIVEPORT = 5009;
    public static C_V_TAG_OCINTERACTIVEPORT2 = 5010;
    public static C_V_TAG_OCBROADCASTIP = 5011;
    public static C_V_TAG_OCBROADCASTPORT = 5012;
    public static C_V_TAG_OCPOLICYIP = 5013;
    public static C_V_TAG_OCPOLICYPORT = 5014;
    public static C_V_TAG_ODINUSER = 5017;
    public static C_V_TAG_LOGINTHRUODIN = 5018;
    public static C_V_TAG_PRODUCTTYPEBIT = 5019;
    public static C_V_TAG_LASTLOGINIPADDR = 5020;
    public static C_V_TAG_LASTLOGINMACADDR = 5021;
    public static C_V_TAG_STREAMINGALLOWED = 5023;
    public static C_V_TAG_ADMINSQOFF = 5024;
    public static C_V_TAG_MANAGERIP = 5027;
    public static C_V_TAG_ALLOWEDPRODUCTS = 5026;
    public static C_V_TAG_NSXPARTCODE = 5029;
    public static C_V_TAG_MISPASSWORD = 5030;
    public static C_S_TAG_CULTURE_TYPE = 5090;
    public static C_V_TAG_OCINTERACTIVEWSSPORT = 5091;
    public static C_V_TAG_OCBROADCASTWSSPORT = 5092;
    public static C_V_TAG_MW_fontSize = 5035;
    public static C_S_LICENSE_NETNET_LANGUAGE_HINDI = "2";
    public static C_S_LIMITSETTABLE = "LT";
    public static C_V_TAG_ALLOWEDPRODUCTSLIST = 1234;

    public static CONST_SYSTEM_PROFILENAME = "Profile 1";
    public static CONST_SYSTEM_PROFILEID = "100";

    // CR 5353 CMOT Integration
    public static C_V_MONTH_JAN = "01";
    public static C_S_MONTH_JAN = "JAN";
    public static C_V_MONTH_FEB = "02";
    public static C_S_MONTH_FEB = "FEB";
    public static C_V_MONTH_MARCH = "03";
    public static C_S_MONTH_MARCH = "MAR";
    public static C_V_MONTH_APRIL = "04";
    public static C_S_MONTH_APRIL = "APR";
    public static C_V_MONTH_MAY = "05";
    public static C_S_MONTH_MAY = "MAY";
    public static C_V_MONTH_JUNE = "06";
    public static C_S_MONTH_JUNE = "JUN";
    public static C_V_MONTH_JULY = "07";
    public static C_S_MONTH_JULY = "JUL";
    public static C_V_MONTH_AUG = "08";
    public static C_S_MONTH_AUG = "AUG";
    public static C_V_MONTH_SEPT = "09";
    public static C_S_MONTH_SEPT = "SEP";
    public static C_V_MONTH_OCT = "10";
    public static C_S_MONTH_OCT = "OCT";
    public static C_V_MONTH_NOV = "11";
    public static C_S_MONTH_NOV = "NOV";
    public static C_V_MONTH_DEC = "12";
    public static C_S_MONTH_DEC = "DEC";
    public static C_S_QUARTERLTY = "Quarterly";
    public static C_S_HALF_YEARLY = "Half-Yearly";
    public static C_S_YEARLY = "Yearly";
    public static C_S_TTM = "TTM";

    public static BTN_SELECTED_CSS: string = '#09d0fd';
    public static BTN_SELECTED_CLASS: string = "tab-btn-activated";

    public static C_S_NEWS_CSS_READ = "News_Read";
    public static C_S_NEWS_CSS_UNREAD = "News_Unread";
    public static C_S_NEWS_CSS_HOT = "News_Hot";
    public static C_S_NEWS_CSS_DEFAULT = "News_Default";

    public static C_S_RECO_CSS_READ = "Calls_Read";
    public static C_S_RECO_CSS_UNREAD = "Calls_Unread";
    public static C_S_RECO_CSS_HOT = "Calls_Hot";
    public static C_S_RECO_CSS_DEFAULT = "Calls_Default";

    public static C_V_TEMPLATE_CISDEFAULTValue = "1";

    public static C_S_ANL_LASTUPDATE_TIME = "Analytics data LUT ";

    // 5917 autologin - Local storage object name. declared in constant so that can be used anywhere.
    // 5917 16-Mar-2018, By Akshay Ghanekar
    public static C_S_AUTOLOGIN_OBJECTNAME = "LastLoggedInUserObj";
    public static C_S_TAG_AUTOLOGIN = "autologin";

    // CR 6053 start MDaaS
    public static C_S_MARK_FOR_DELETION = "1111";
    public static C_S_TAG_MDaaSStatus = 'MDaaSStatus';
    public static C_S_TAG_MDaaSURL = 'MDaaSURL';
    //public static C_S_BROADCAST_IP = ""; // Temp variable to store the OC IP will be used if MDaaS URL is not available after retry attempts
    //public static C_S_BROADCAST_PORT = ""; // Temp variable to store the OC Port will be used if MDaaS URL is not available after retry attempts
    //public static C_S_DEFAULT_BROADCAST_IP = "0.0.0.0";
    //public static C_S_DEFAULT_BROADCAST_PORT = 0;
    // CR 6053 end

    // Autologin issue socket
    public static C_S_SOCKET_ERROR_RESPONSE = "19";
    public static C_S_SOCKET_ERROR_ANOTHER_DEVICE = "User connected through another terminal.";

    // 6258 Alert Changes
    public static C_S_ALERT_GREATER_THAN_EQUAL_TO_STR = "Greater than equal to ( >= )";
    public static C_V_ALERT_GREATER_THAN_EQUAL_TO_STR_ID = 0;
    public static C_S_ALERT_LESS_THAN_EQUAL_TO_STR = "Less than equal to ( <= )";
    public static C_V_ALERT_LESS_THAN_EQUAL_TO_STR_ID = 1;
    public static C_S_ALERT_GREATER_THAN_STR = "Greater than ( > )";
    public static C_V_ALERT_GREATER_THAN_STR_ID = 2;
    public static C_S_ALERT_LESS_THAN_STR = "Less than ( < )";
    public static C_V_ALERT_LESS_THAN_STR_ID = 3;
    public static C_S_ALERT_EQUAL_TO_STR = "Equal to ( = )";
    public static C_V_ALERT_EQUAL_TO_STR_ID = 4;

    //USD: 6507 : by PrajyotD on 03 Sep 2018 :Logoff Message handling.(start)
    // Error code sent by OC in TAG 451
    //When logoff from MGR with force logon=true
    public static C_V_LOGOUT_ERRORCODE_FORCE_LOGOUT = 1;
    //logout due to idle time out
    public static C_V_LOGOUT_ERRORCODE_IDLE = 2;
    //When OC is going to shut down (stop menu from OC UI)
    public static C_V_LOGOUT_ERRORCODE_UI_SHUTDOWN = 3;
    //When all user will be logged out due 24hr logoff time set (Choice Requirement)
    public static C_V_LOGOUT_ERRORCODE_24HR_TIMER = 4;
    //When received message size greater than 2048
    public static C_V_LOGOUT_ERRORCODE_MESSAGESIZE = 5;
    //When invalid packet received like TAG with empty value like 4=| etc
    public static C_V_LOGOUT_ERRORCODE_EMPTY_SESSION = 6;
    //When User Forcefully Disconnected from OCAdmin
    public static C_V_LOGOUT_ERRORCODE_FORCE_DISCONNECT_ADMIN = 7;
    //Disconnected from OC UI
    public static C_V_LOGOUT_ERRORCODE_FORCE_DISCONNECT_UI = 8;
    //When same user open 2 socket with same session id then this message will send by OC on old socket
    //and then new socket will be accepted
    public static C_V_LOGOUT_ERRORCODE_MULTIPLE_SOCKET = 9;
    //When user is not logged in OC
    public static C_V_LOGOUT_ERRORCODE_USER_NOT_LOGGEDIN = 10;

    public static C_S_LOGOUT_ERRORCODE_FORCE_LOGOUT_MSG = "You have been logged off due to successful login from another device.";
    public static C_S_LOGOUT_ERRORCODE_GENERAL_MSG = "Something went Wrong.";
    public static C_S_LOGOUT_ERRORCODE_FORCE_DISCONNECT_MSG = "User Forcefully Disconnected.";

    //USD: 6507 : by PrajyotD on 03 Sep 2018 :Logoff Message handling.(end)

    /// #region "API Constants."
    public static C_S_API_LOAD_SCRIP_DETAILS_FOR_EQ = "LoadScripDetailsForEQ";
    public static C_S_API_LOAD_SCRIP_DETAILS_FOR_OPTIONS = "LoadScripDetailsForOptions";
    public static C_S_API_LOAD_SCRIP_DETAILS_FOR_FUTURES = "LoadScripDetailsForFutures";
    public static C_S_API_LOAD_SCRIP_SERIES = "LoadScripSeries";
    public static C_S_API_LOAD_SCRIP_EXPDATE_N_OPTIONTYPE = "LoadScripExpDateNOptionType";
    public static C_S_API_LOAD_SCRIP_STRIKE_PRICE = "LoadScripStrikePrice";
    public static C_S_API_GET_SPOS_STATUS_FOR_MCXSXEQ = "GetSPOSStatusForMCXSXEQ";

    //CDS common constants+
    public static CDS_SUCCESS = "SUCCESS";
    public static CDS_PROVIDERCODE = "CMOT";
    public static CDS_PAGE_SIZE = 10;
    public static CDS_CHAR_LIMIT = 45;
    public static CDS_PAGE_NO = 1;
    public static CDS_NSE = "NSE";
    public static CDS_ERROR_MESSAGE = "Unable to show data.";
    public static CDS_NO_DATA = "No Data Found."
    public static CDS_DATE_ERROR = "Date Selection is Incorrect."
    public static CDS_DELISTED_SHARES = "Delisted Shares";
    public static CDS_COMPANY_NAME = "Change in Company Name";
    public static CDS_ANNOUNCEMENT = "Announcements";
    public static CDS_BOARD_MEETINGS = "Board Meetings";
    public static CDS_BOOK_CLOSURE = "Book Closure";
    public static CDS_MERGER_AQUISITION = "Merger Acquisition";
    public static CDS_AGM_EGM = "AGM/EGM";
    public static CDS_CORPORATE_ACTIONS = "Corporate Actions";
    public static CDS_FORTHCOMING_RESULTS = "Forthcoming Results";
    public static CDS_CALCULATORS = "Calculators";

    public static CDS_BULK_BLOCK = "Bulk/Block Deals";
    public static CDS_FII_DII_MF = "FII/DII/MF Activity";

    public static CDS_PREMIUM_DISCOUNT = "Premium-Discount";

    public static CDS_BULKBLOCK_BULK = "Bulk";
    public static CDS_BULKBLOCK_EXCHANGE = "nse";

    //CDS FII DII MF

    public static CDS_FIIDIIMF_FII = "FII";
    public static CDS_FIIDIIMF_DII = "DII";
    public static CDS_FIIDIIMF_MF = "MF";
    public static CDS_FIIDIIMF_Equity = "EQUITY";
    public static CDS_FIIDIIMF_Debt = "DEBT";
    public static CDS_FIIDIIMF_Chart_Buy_Color = "rgba(56, 126, 245,1)";
    public static CDS_FIIDIIMF_Chart_Sell_Color = "rgba(229, 55, 108,1)";

    //CDS AGM/EGM

    public static CDS_AGM = "AGM";

    //CDS CORPORATE ACTIONS

    public static CDS_CORPORATE_ACTIONTYPE_DIVIDEND = "Dividend";
    public static CDS_CORPORATE_ACTIONTYPE_BUYBACK = "Buy-back";

    //CDS IPO PAGE CONSTAT

    public static CDS_OPENIPO_TYPE = "1";
    public static CDS_COMINGIPO_TYPE = "2";
    public static CDS_CLOSEDIPO_TYPE = "3";

    public static CDS_OPENIPO_NODATAFOUND = "Currently there are no IPOs available for subscription";
    public static CDS_COMINGIPO_NODATAFOUND = "No Upcoming IPOs in near future.";
    public static CDS_CLOSEDIPO_NODATAFOUND = "No Data Found.";

    //CDS FPO PAGE CONSTAT

    public static CDS_OPENFPO_TYPE = "1";
    public static CDS_COMINGFPO_TYPE = "2";
    public static CDS_CLOSEDFPO_TYPE = "3";

    public static CDS_OPENFPO_NODATAFOUND = "Currently there are no FPOs available for subscription.";
    public static CDS_COMINGFPO_NODATAFOUND = "No Upcoming FPOs in near future.";
    public static CDS_CLOSEDFPO_NODATAFOUND = "No Data Found.";

    // IPO-FPO MODAL CONSTAT

    public static CDS_MODAL_DETAILNOTFOUND = "No details available.";

    //Common Message NonTransactional

    public static NONTRANSACTIONAL = "nontransactional/";
    public static SPANMARGIN_URL = "/getSpanMargin/";
    public static WATCHLIST_PROFILE_URL = "/getWatchlistProfile/";

    //Quotes

    public static RECOMMENDATION_URL = "/getRecommendation"

    //Common Message Transactional

    public static RESPONSE_MSG = "Unable to show data.";
    public static CALL_ERROR = "No Data Found.";
    public static BUY = "BUY";
    public static SELL = "SELL";
    public static URL_ERROR = "Oops something went wrong. Please try again later.";
    public static TRANSACTIONAL = "transactional/";
    public static ORDERBOOK_URL = "/getOrderBook";
    public static TRADEBOOK_URL = "/getTradeBook";
    public static NETPOSITION_URL = "/getNetPosition/";
    public static STOCKVIEW_URL = "/getStockView/";

    //OrderBook

    public static ORDERBOOK_PENDING = "OPEN";
    public static ORDERBOOK_EXECUTED = "EXECUTED";
    public static ORDERBOOK_ALL = "OTHERS";
    public static ORDERBOOK_OPEN_CALL_ERROR = "No Open order in OrderBook.";
    public static ORDERBOOK_ALL_CALL_ERROR = "No Data in OrderBook.";

    public static ORDERBOOK_PENDING_STATUSCOLOR = "pending";
    public static ORDERBOOK_EXECUTED_STATUSCOLOR = "executed";
    public static ORDERBOOK_REJECT_STATUSCOLOR = "reject";

    public static ORDERBOOK_CANCEL_ERRORMSG = "You are currently not allowed to cancel order in this segment";
    public static ORDERBOOK_MODIFY_ERRORMSG = "You are currently not allowed to modify order in this segment";
    public static STOCKVIEW_ERRORMSG = "You are currently not allowed to place order in this segment";


    // Trade Book

    public static TRADEBOOK_CALL_ERROR = "No Data in TradeBook.";
    //Net Position

    public static NETPOSITION_DAILY = "TODAYS";
    public static NETPOSITION_EXPIRY = "OVERALL";
    public static NETPOSITION_DAILY_CALL_ERROR = "No Today's Position in NetPosition.";
    public static NETPOSITION_EXPIRY_CALL_ERROR = "No Overall Position in NetPosition.";
    public static MARGINPLUSERRORMSG = "You are currently not allowed to square off for this Product Type";


    //Constants related to pouch couch
    //Watchlist keyword Append.
    public static WATCHLIST_KEY = "Watchlist_";
    public static C_S_POUCH_DEFAULTINDICES = "DEFAULTINDICES";

    public static REGISTERED_USER = "registered";
    public static GUEST_USER = "guest";
    public static EXISTING_REG_USER = "reg_existing";
    public static EXISTING_GUEST_USER = "guest_existing";

    //vivian
    public static OMEX_MESSAGETYPE_ORDER = "ORD_NRML";
    public static OMEX_MESSAGETYPE_GTD_ORDER = "GTD_ORD_NRML"
    public static OMEX_MESSAGETYPE_TRADE = "TRD_MSG";
    public static OMEX_MESSAGETYPE_CHAT = "CHAT_MSG";
    public static OMEX_MESSAGETYPE_POS_CONV = "POS_CONV";
    public static OMEX_MESSAGETYPE_ALERT = "USR_ALERT";
    public static OMEX_MESSAGETYPE_MKTSTAT = "MKT_STAT";

    public static OMEX_ORDER_CLI = "1";
    public static MEX_ORDER_PRO = "2";
    public static OMEX_ORDER_BUY = "1";
    public static OMEX_ORDER_SELL = "2";

    public static OMEX_ORDER_CLIENT_XMITTED = 1;
    public static OMEX_ORDER_GATEWAY_XMITTED = 2;
    public static OMEX_ORDER_OMS_XMITTED = 3;
    public static OMEX_ORDER_EXCHANGE_XMITTED = 4;
    public static OMEX_ORDER_PENDING = 5;
    public static OMEX_ORDER_CANCELLED = 6;
    public static OMEX_ORDER_EXECUTED = 7;
    public static OMEX_ORDER_ADMIN_PENDING = 8;
    public static OMEX_ORDER_GATEWAY_REJECT = 9;
    public static OMEX_ORDER_OMS_REJECT = 10;
    public static OMEX_ORDER_ORDER_ERROR = 11;
    public static OMEX_ORDER_FROZEN = 12;
    public static OMEX_ORDER_M_PENDING_MINIADMINPENDING = 13;
    public static OMEX_ORDER_A_ACCEPT_ADMINACCEPT = 14;
    public static OMEX_ORDER_A_REJECT_ADMINREJECT = 15;
    public static OMEX_ORDER_A_MODIFY_ADMINMODIFY = 16;
    public static OMEX_ORDER_A_CANCEL_ADMINCANCEL = 17;
    public static OMEX_ORDER_AMO_SUBMITTED = 18;
    public static OMEX_ORDER_AMO_CANCELLED = 19;
    public static OMEX_ORDER_COMPLETED = 20;
    public static OMEX_ORDER_STOPPED = 21;
    public static OMEX_ORDER_CONVERTED = 22;



    public static XMPP_MESSAGE_BUY_TEXT = "BUY";
    public static XMPP_MESSAGE_SELL_TEXT = "SELL";
    public static XMPP_MESSAGE_CLIENT_XMITTED = "CLIENT XMITTED";
    public static XMPP_MESSAGE_GATEWAY_XMITTED = "GATEWAY XMITTED";
    public static XMPP_MESSAGE_OMS_XMITTED = "OMS XMITTED";
    public static XMPP_MESSAGE_EXCHANGE_XMITTED = "EXCHANGE XMITTED";
    public static XMPP_MESSAGE_PENDING = "PENDING";
    public static XMPP_MESSAGE_CANCELLED = "CANCELLED";
    public static XMPP_MESSAGE_EXECUTED = "EXECUTED";
    public static XMPP_MESSAGE_ADMIN_PENDING = "ADMIN PENDING";
    public static XMPP_MESSAGE_GATEWAY_REJECT = "GATEWAY REJECT";
    public static XMPP_MESSAGE_OMS_REJECT = "OMS REJECT";
    public static XMPP_MESSAGE_ORDER_ERROR = "ORDER ERROR";
    public static XMPP_MESSAGE_FROZEN = "FROZEN";
    public static XMPP_MESSAGE_M_PENDING_MINIADMINPENDING = "M.PENDING [MINIADMINPENDING]";
    public static XMPP_MESSAGE_A_ACCEPT_ADMINACCEPT = "A.ACCEPT [ADMINACCEPT]";
    public static XMPP_MESSAGE_A_REJECT_ADMINREJECT = "A.REJECT [ADMINREJECT]";
    public static XMPP_MESSAGE_A_MODIFY_ADMINMODIFY = "A.MODIFY [ADMINMODIFY]";
    public static XMPP_MESSAGE_A_CANCEL_ADMINCANCEL = "A.CANCEL [ADMINCANCEL]";
    public static XMPP_MESSAGE_AMO_SUBMITTED = "AMO SUBMITTED ";
    public static XMPP_MESSAGE_AMO_CANCELLED = "AMO CANCELLED";
    public static XMPP_MESSAGE_COMPLETED = "COMPLETED";
    public static XMPP_MESSAGE_STOPPED = "STOPPED";
    public static XMPP_MESSAGE_CONVERTED = "CONVERTED";


    //vivian
    public static C_S_MARKETLIVE_LIVENEWS_URL: string = "http://139.59.63.208:5000/liveNews/Json/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1heWFuay52b3JhQG5pcm1hbGJhbmcuY29tIiwiaWF0IjoxNTE3MzgyMzkzfQ.cdvb1F_1T4w0eeUw33uAziZV6eQzQ1D-xQtHO_9umsA";
    public static C_S_MARKETLIVE_BOT_URL: string = "http://139.59.63.208:5000/apiMessage/json/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1heWFuay52b3JhQG5pcm1hbGJhbmcuY29tIiwiaWF0IjoxNTE3MzgyMzkzfQ.cdvb1F_1T4w0eeUw33uAziZV6eQzQ1D-xQtHO_9umsA";

    public static C_S_MARKETLIVE_SUBMENU_ONE = "Commentary";
    public static C_S_MARKETLIVE_SUBMENU_TWO = "Stocks in Action";
    public static C_S_MARKETLIVE_SUBMENU_THREE = "News";
    public static C_S_MARKETLIVE_SUBMENU_FOUR = "Sectors";

    public static C_S_MARKETLIVE_LOCALSTORAGEOBJ_COMMENTARY = "marketlivestats-commentaryNews";
    public static C_S_MARKETLIVE_LOCALSTORAGEOBJ_STOCK_IN_ACTION = "marketlivestats-stockInAction";
    public static C_S_MARKETLIVE_LOCALSTORAGEOBJ_NEWS = "marketlivestats-news";
    public static C_S_MARKETLIVE_LOCALSTORAGEOBJ_SECTORS = "marketlivestats-sectors";

    public static C_S_PHYSICAL_DELIVERY = "Physical Delivery";
    public static C_S_CASH_SETTLEMENT = "Cash Settled";
    // Code Comment : These values declared to check with values comming from ODIN DB tbl_ScriptMaster of 
    // sDeliveryUnit table of Derivative Segments
    public static C_S_PHYSICAL_DELIVERY_UNIT = "D";
    public static C_S_CASH_SETTLEMENT_UNIT = "C";
    public static C_S_SETTLEMENT_TYPE_DELIMITER = "_";



    public static C_S_API_PROFILE_LIST = "v1/user/watchlistProfile";
    public static C_S_API_GLOBAL_PROFILE_LIST = "v1/globalProfile";
    public static C_S_API_PROFILE_ADDNEW = "v1/user/addProfile";
    public static C_S_API_PROFILE_DELETE = "v1/user/deleteProfile";
    public static C_S_API_UPDATE_PROFILE_SCRIP = "v1/user/updateProfileScrip";
    public static C_S_API_REMOVE_PROFILE_SCRIP = "v1/user/removeProfileScrip";
    public static C_S_API_UPDATE_PROFILE_NAME = "v1/user/updateProfileName";

    /** PAGE NAME CONSTANTS FOR ROUTE */
    public static C_S_PAGE_ROUTE_INIT = 'initialize';
    public static C_S_PAGE_ROUTE_HOME = "home";
    public static C_S_PAGE_ROUTE_LOGIN = "signin";

    public static C_S_PAGE_ROUTE_MPIN = "mpinlogin";
    public static C_S_PAGE_ROUTE_LANDING = "LandingPage";
    public static C_S_PAGE_ROUTE_ERROROOPS = "ErrorOopsPage";
    public static C_S_PAGE_ROUTE_ERRORNETWORK = "network-error";
    public static C_S_PAGE_ROUTE_SIGNIN = "signin";
    public static C_S_PAGE_ROUTE_PROFILE = "profile";
    public static C_S_PAGE_ROUTE_MPIN_FINGERPRINT = "MpinFingerprintLoginPage";
    public static C_S_ROUTE_FORGETMPIN = "forgetmpin";
    public static C_S_PAGE_ROUTE_PREMIUM_DISCOUNT = "PremiumDiscountPage";
    public static C_S_PAGE_ROUTE_FORTH_COMING_RESULT = "ForthComingResultsPage";
    public static C_S_PAGE_ROUTE_FII_DII_MF = "FiiDiiMfPage";
    public static C_S_PAGE_ROUTE_EXCHANGE_TIME = "ExchangeTimePage";
    public static C_S_PAGE_ROUTE_AGM_EGM = "AgmEgmPage";
    public static C_S_PAGE_ROUTE_DELISTED_SHARE = "DelistedSharePage";
    public static C_S_PAGE_ROUTE_ABOUTUS = "AboutUsPage";
    public static C_S_PAGE_ROUTE_BRANCHLOCATOR = "BranchlocatorPage";
    public static C_S_PAGE_ROUTE_BOOKCLOSURE = "BookClosurePage";
    public static C_S_PAGE_ROUTE_MENUHAMBURGER = "menuhamburger"
    public static C_S_PAGE_ROUTE_BULKBLOCKDETAILS = "BulkBlockDetailsPage";
    public static C_S_PAGE_ROUTE_MERGERACQUISITION = "MergerAcquisitionPage";
    public static C_S_PAGE_ROUTE_NEWS_COMMENTARY = "NewsCommentaryPage";
    public static C_S_PAGE_ROUTE_DASHBOARD = "DashboardPage";
    public static C_S_PAGE_ROUTE_SETMPIN = "setmpin";
    public static C_S_PAGE_ROUTE_CHANGEMPIN = "changempin";
    public static C_S_PAGE_ROUTE_CHANGEPASSWORD = "changepassword";
    public static C_S_PAGE_ROUTE_ORDER_ENTRY = "OrderEntryPage";
    public static C_S_PAGE_ROUTE_TRANSACTION = "transaction";
    public static C_S_PAGE_ROUTE_MARKETMAIN = "marketmain";
    public static C_S_PAGE_ROUTE_PORTFOLIO = "portfolio";
    public static C_S_PAGE_ROUTE_WATCHLIST = "watchlist";
    public static C_S_PAGE_ROUTE_QUOTE = "Quote";
    public static C_S_PAGE_ROUTE_MESSAGEHUB = "MessageHubPage";
    public static C_S_PAGE_ROUTE_STOCKVIEW = "StockView";
    public static C_S_PAGE_ROUTE_QUICKTOUR = "Quicktour";
    public static C_S_PAGE_ROUTE_IFRAME = "IframeContainerPage";
    public static C_S_PAGE_ROUTE_ARCMENU = "ArchMenuDynamicPage";
    public static C_S_PAGE_ROUTE_SETTING = "settings";
    public static C_S_PAGE_ROUTE_ADVANCE_CHART = "AdvanceChartPage";
    public static C_S_PAGE_ROUTE_NETPOSITION = "NetPositionsPage";
    public static C_S_PAGE_ROUTE_TRADEBOOK = "TradeBook";
    public static C_S_PAGE_ROUTE_SECTORS = "Sectors";
    //public static C_S_PAGE_ROUTE_LOGIN = "LoginPage";
    public static C_S_PAGE_ROUTE_CHGPWD = "changepassword";
    public static C_S_PAGE_STOCK_IN_ACTION = "StockInActionPage";
    public static C_S_PAGE_ROUTE_GUEST_TRIAL_PERIOD_EXPIRED = "GuestTrialPeriodExpiredPage";
    public static C_S_PAGE_ROUTE_SUBMIT_OTP = "SumbitOtpPage";
    public static C_S_PAGE_ROUTE_MARKET_STATUS = "MarketStatusPage";
    public static C_S_PAGE_ROUTE_BODETAILS = "BODetails";
    public static C_S_PAGE_ROUTE_QUICK_TOUR = "QuickTour";
    public static C_S_PAGE_ROUTE_FORGOT_PASSWORD = "forgotpassword";
    public static C_S_PAGE_ROUTE_FORGOTMPIN = "ForgotmpinPage";
    public static C_S_PAGE_ROUTE_ORDER_CONFIRMATION = "OrderConfirmation";
    public static C_S_PAGE_ROUTE_ORDER_RESULT = "OrderResult";
    public static C_S_PAGE_ROUTE_RESEARCH_CALLS = "ResearchCallsPage";

    public static C_S_PAGE_ROUTE_ANNOUNCEMENTS = "AnnouncementsPage";
    public static C_S_PAGE_ROUTE_BOARD_MEETINGS = "BoardMeetingsPage";
    public static C_S_PAGE_ROUTE_COMPANY_NAME = "CompanyNamePage";
    public static C_S_PAGE_ROUTE_CORPORATE_ACTIONS = "CorporateActionsPage";
    public static C_S_PAGE_ROUTE_CALCULATOR = "CalculatorsPage";
    public static C_S_PAGE_ROUTE_FPO_WATCH = "FPOWatchPage";
    public static C_S_PAGE_ROUTE_IPO_WATCH = "IpoWatchPage";
    public static C_S_PAGE_ROUTE_IPO_FPOMODAL = "IpoFpoModalPage";
    public static C_S_PAGE_ROUTE_INDEX_MAIN = "IndexMainPage";
    public static C_S_PAGE_ROUTE_INDEX_VIEW = "IndexViewPage";
    public static C_S_PAGE_ROUTE_LOOKUP = "LookupPage";
    public static C_S_PAGE_ROUTE_NEWS = "NewsPage";
    public static C_S_PAGE_ROUTE_NOTIFICATIONS = "NotificationsPage";
    public static C_S_PAGE_ROUTE_SCREENERS = "ScreenersPage";
    public static C_S_PAGE_ROUTE_SCREENERS_EQUITY = "ScreenersEquityPage";
    public static C_S_PAGE_ROUTE_PASSWORD_POLICY = "PasswordPolicyPage";
    public static C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING = "create-watch-list-existing";
    public static C_S_PAGE_ROUTE_FINGERPRINT_ENABLE = "fingerprint-enable";


    //USD 6221 Added by Vivian Fernandes for Bracket Order Book
    public static C_S_BRACKET_MAIN_LEG_INDICATOR = "Main Leg";
    public static C_S_BRACKET_SL_LEG_INDICATOR = "Stop Loss Leg";
    public static C_S_BRACKET_PROFIT_LEG_INDICATOR = "Profit Leg";
    public static C_S_BRACKET_PARTIAL_PROFIT_LEG_INDICATOR = "Partial Profit Leg";
    public static C_S_BRACKET_SL_RESV_LEG_INDICATOR = "Stop Loss Reserve Leg";
    public static C_S_BRACKET_PROFIT_RESV_LEG_INDICATOR = "Profit Reserve Leg";

    //USD 6221 Added by Vivian Fernandes for Bracket Order Book
    public static C_S_ORDERSTATUS_BOCOMPLETED: string = "20";
    public static C_S_ORDERSTATUS_BOSTOPPED: string = "21";
    public static C_S_ORDERSTATUS_BOCONVERTED: string = "22";
    public static C_S_ORDERSTATUS_NOT_INITIATED: string = "-1";

    public static C_S_ORDERSTATUS_BOCOMPLETED_TEXT: string = "COMPLETED";
    public static C_S_ORDERSTATUS_NOTINITIATED_TEXT: string = "NOT INITIATED";
    public static C_S_ORDERSTATUS_BOSTOPPED_TEXT: string = "STOPPED";
    public static C_S_ORDERSTATUS_BOCONVERTED_TEXT: string = "CONVERTED";

    //all localstorage constants will be handle here.
    public static LOCAL_STORAGE_USER_DETAILS: string = "USER_DETAILS";

    public static LOCAL_STORAGE_FAVOURITE_INDICES: string = "INDICES_FAVOURITE";
    public static LOCAL_STORAGE_WATCHLIST_FILTER: string = "WATCHLIST_FILTER";
    public static LOCAL_STORAGE_WATCHLIST_DEMO: string = "WATCHLIST_DEMO";
    public static LOCAL_STORAGE_SCREENERS_FILTER: string = "SCREENERS_FILTER";
    public static LOCAL_STORAGE_FAVOURITE_SCREENERS: string = "SCREENERS_FAVOURITE";
    public static LOCAL_STORAGE_PREFERRED_LANGUAGE: string = "PREFERRED_LANGUAGE";
    public static LOCAL_STORAGE_THEME: string = "THEME";
    public static LOCAL_STORAGE_GLOBAL_PROFILE: string = "GLOBAL_PROFILE";
    public static LOCAL_STORAGE_PREFERRED_EXCHANGE: string = "PREFERRED_EXCHANGE";

    public static LOCAL_STORAGE_GUEST_USER_DETAILS: string = "GUEST_USER_DETAILS";
    public static LOCAL_STORAGE_GUEST_WATCHLIST_FILTER: string = "GUEST_WATCHLIST_FILTER";
    public static LOCAL_STORAGE_INDICES_TICKER: string = "INDICES_TICKER";

    public static LOCAL_STORAGE_WATCHLIST_DEFAULT_PROFILE: string = "WATCHLIST_DEFAULT";
    public static LOCAL_STORAGE_GUEST_WATCHLIST_DEFAULT_PROFILE: string = "GUEST_WATCHLIST_DEFAULT";

    public static C_S_EDIS_MODE_ONLINE = 'ONLINE';
    public static C_S_EDIS_MODE_OFFLINE = 'OFFLINE';

    public static C_S_NSE_EQT: string = "NSE_EQ";
    public static C_S_NSE_DERV: string = "NSE_FO";
    public static C_S_BSE_DERV: string = "BSE_FO";
    public static C_S_MCX_DERV: string = "MCX_FO";//CR 5117 Modified for MCX Options
    public static C_S_MCX_SPOT: string = "MCX_SPOT";
    public static C_S_ICEX_DERV: string = "ICEX_FO"; //CR 5117 Modified for MCX Options    
    public static C_S_NCDEX_DERV: string = "NCDEX_FO"; //CR 5117 Modified for NCDEX Options
    public static C_S_NCDEX_SPOT: string = "NCDEX_SPOT";
    public static C_S_MCXSX_DERV: string = "MSE_FO";
    public static C_S_MCXSX_CURR: string = "MSE_CUR";
    public static C_S_MCXSX_SPOT: string = "MSE_SPOT";
    public static C_S_NSX_DERV: string = "NSE_CUR";
    public static C_S_NSX_SPOT: string = "NSECUR_SPOT";
    public static C_S_BSECDX_DERV: string = "BSE_CUR";
    public static C_S_BSECDX_SPOT: string = "BSECUR_SPOT";
    public static C_S_NSE_OTS: string = "NSE_OTS";
    public static C_S_BSE_COMM: string = "BSE_COMM";
    public static C_S_NSE_COMM: string = "NSE_COMM";
    public static C_S_BSECOMM_SPOT: string = "BSECOMM_SPOT";
    public static C_S_NSECOMM_SPOT: string = "NSECOMM_SPOT";
    public static C_S_ERROR_PROFILE_SCRIP = "Cannot add more than 50 scrip in single profile.";

    public static C_S_NSE_EQ_API_NAME: string = "NSE_EQ";
    public static C_S_NSE_DERV_API_NAME: string = "NSE_FO";
    public static C_S_BSE_EQ_API_NAME: string = "BSE_EQ";

    public static C_S_COMBINED_CASH: string = "EQ Combined";
    public static C_S_COMBINED_FNO: string = "FNO Combined";
    public static C_S_COMBINED_CDS: string = "CDS Combined";


    public static CONST_EQUITY = "Equity";
    public static CONST_EQFAO = "Equity FAO";
    public static CONST_CURR = "Currency";
    public static CONST_COMMODITY = "Commodity";


    // public static C_S_COMBINED_ALL_EXCHANGE_TEXT = "All Combined";
    // public static C_S_COMBINED_CASH_EXCHANGE_TEXT = "EQ Combined"; // CASH = Equity(EQ)
    // public static C_S_COMBINED_FNO_EXCHANGE_TEXT = "FNO Combined"; // FNO = Derivatives
    // public static C_S_COMBINED_CDS_EXCHANGE_TEXT = "CDS Combined"; // CDS = Currency

    public static C_S_CONST_COMBINED_EQ = "EQ Combined";
    public static C_S_CONST_COMBINED_DERV = "Derv Combined";
    public static C_S_CONST_COMBINED_CUR = "Currency Combined";

    // public static C_S_BSE_EQ_SPECIALPREOPEN: string ="BSE Special PreOpen";
    public static C_S_BSE_DERV_API_NAME: string = "BSE_FO";
    public static C_S_MCX_FUTURES_API_NAME: string = "MCX_FO";
    public static C_S_NCDEX_FUTURES_API_NAME: string = "NCDEX_FO";
    public static C_S_NSE_CUR_API_NAME: string = "NSE_CUR";
    public static C_S_BSE_CUR_API_NAME: string = "BSE_CUR";
    public static C_S_ICEX_EXCHANGE_TEXT: string = "ICEX";
    public static C_V_ICEX_DERIVATIVES: number = 34;

    public static C_S_NSE_EQ_API: string = "NSE_EQ";
    public static C_S_NSE_DERV_API: string = "NSE_FO";
    public static C_S_BSE_EQ_API: string = "BSE_EQ";
    public static C_S_BSE_DERV_API: string = "BSE_FO";
    public static C_S_MCX_DERV_API: string = "MCX_FO"; //CR 5117 Modified for MCX Options
    public static C_S_MCX_SPOT_API: string = "MCX_SPOT";
    public static C_S_ICEX_DERV_API: string = "ICEX_FO";//CR 5117 Modified for MCX Options    
    public static C_S_NCDEX_DERV_API: string = "NCDEX_FO"; //CR 5117 Modified for NCDEX Options
    public static C_S_NCDEX_SPOT_API: string = "NCDEX_SPOT";
    public static C_S_MCXSX_EQ_API: string = "MSE_EQ";
    public static C_S_MCXSX_DERV_API: string = "MSE_FO";
    public static C_S_MCXSX_CURR_API: string = "MSE_CUR";
    public static C_S_MCXSX_SPOT_API: string = "MSE_SPOT";
    public static C_S_NSX_DERV_API: string = "NSE_CUR";
    public static C_S_NSX_SPOT_API: string = "NSECUR_SPOT";
    public static C_S_BSECDX_DERV_API: string = "BSE_CUR";
    public static C_S_BSECDX_SPOT_API: string = "BSECUR_SPOT";
    public static C_S_NSE_OTS_API: string = "NSE_OTS";
    public static C_S_BSE_COMM_API: string = "BSE_COMM";
    public static C_S_NSE_COMM_API: string = "NSE_COMM";
    public static C_S_BSECOMM_SPOT_API: string = "BSECOMM_SPOT";
    public static C_S_NSECOMM_SPOT_API: string = "NSECOMM_SPOT";
    public static C_S_NSEL_SPTCOM_DESC_API: string = "NSEL_SPTCOM";

    public static C_S_DSE_EQUITIES_API: string = "DSE_EQ";
    public static C_S_BFX_FUTURES_API: string = "BFX";
    public static C_S_BFX_SPOT_API: string = "BFX_SPOT";
    // C_S_DGCX_FUTURES:"DGCX";
    // C_S_DGCX_SPOT:"DGCX_SPOT";
    // C_S_UCX_FUTURES:"UCX FUTURES";
    // C_S_UCX_SPOT:"UCX_SPOT";
    public static C_S_DFM_EQ_API: string = "DFM_EQ";
    public static C_S_ADX_EQ_API: string = "ADX_EQ";
    public static C_S_MSX_FIM_API: string = "MCXSX_FIM";
    // public static C_S_MCX_DERV_DESC = "MCX DERIVATIVES"; //CR 5117 Modified for MCX Options
    // public static C_S_NCDEX_DERV_DESC = "NCDEX DERIVATIVES"; //CR 5117 Modified for NCDEX Options
    // public static C_S_NSEL_SPTCOM_DESC: string = "NSEL SPTCOM";
    // public static C_S_MCXSX_FUTURES_DESC: string = "MSE CURRENCY";
    // public static C_S_MCXSX_EQUITIES_DESC: string = "MSE CASH";
    // // public static C_S_MCXSX_EQ_SPECIALPREOPEN: string ="MSECASH SPOS";
    // public static C_S_MCXSX_FAO_DESC: string = "MSE DERIVATIVES";
    // public static C_S_NSX_FUTURES_DESC: string = "NSECDS";
    // public static C_S_DSE_EQUITIES_DESC: string = "DSE EQUITIES";
    // public static C_S_NMCE_FUTURES_DESC: string = "NMCE FUTURES";
    // public static C_S_BFX_FUTURES_DESC: string = "BFX";
    // public static C_S_DGCX_FUTURES_DESC: string = "DGCX";
    // public static C_S_UCX_FUTURES_DESC: string = "UCX FUTURES";
    // public static C_S_BSECDX_FUTURES_DESC: string = "BSECDS";
    // public static C_S_IPO_DESC: string = "NSE-OTS";
    // public static C_S_DFM_EQ_DESC: string = "DFM CASH";
    // public static C_S_ADX_EQ_DESC: string = "ADX CASH";
    /**
     * USD  : BT-12359
     * Date : 21/02/2020
     * Name : Nikhil Gawade
     * Description : constant added for ICEX FUTURES
     */
    public static C_S_ICEX_FUTURES_DESC: string = "ICEX FUTURES";
    public static C_S_ICEX_DERV_DESC = "ICEX DERIVATIVES";
    public static C_S_ICEX_FAO: string = "ICEX FO";
    public static C_S_EXCH_ICEX: string = "ICEX";
    public static CHART_TIME_INTERVAL = 5;

    // Authentication Service Route Constants
    public static AUTHENTICATION = "authentication/";
    public static C_S_API_AUTHENTICATION_VERIFY_PASSWORD_OTP = "/user/password/reset/verify-otp";
    public static C_S_API_AUTHENTICATION_RESET_PASSWORD_OTP = "/user/password/reset/send-otp";
    public static C_S_API_AUTHENTICATION_CHANGE_MPIN = "/user/mpin";
    public static C_S_API_AUTHENTICATION_CHANGE_PASSWORD = "/user/password";
    public static C_S_API_AUTHENTICATION = "/user/session"
    public static C_S_API_AUTHENTICATION_REGISTRATION = "/user/createaccount"
    public static C_S_API_AUTHENTICATION_PROFILE = "/user/profile";
    public static C_S_API_AUTHENTICATION_RESET_MPIN_OTP = "/user/mpin/reset/send-otp";
    public static C_S_API_AUTHENTICATION_VERIFY_MPIN_OTP = "/user/mpin/reset/verify-otp";
    public static C_S_API_AUTHENTICATION_BALANCE = "/user/balance";

    //PrajyotD - 20-01-2021 for MTL Touchline (s)
    public static C_S_MSGCODE_MTL_MULTIPLE_TOUCHLINE_RESPONSE = "51";
    public static C_S_OFFSET_MTL_RESPONSE_MKTSEGID = "0";
    public static C_S_OFFSET_MTL_RESPONSE_TOKEN = "1";
    public static C_S_OFFSET_MTL_RESPONSE_LUT = "2";
    public static C_S_OFFSET_MTL_RESPONSE_LTT = "3";
    public static C_S_OFFSET_MTL_RESPONSE_LTP = "4";
    public static C_S_OFFSET_MTL_RESPONSE_BQTY = "5";
    public static C_S_OFFSET_MTL_RESPONSE_BPRICE = "6";
    public static C_S_OFFSET_MTL_RESPONSE_SQTY = "7";
    public static C_S_OFFSET_MTL_RESPONSE_SPRICE = "8";
    public static C_S_OFFSET_MTL_RESPONSE_OPEN = "9";
    public static C_S_OFFSET_MTL_RESPONSE_HIGH = "10";
    public static C_S_OFFSET_MTL_RESPONSE_LOW = "11";
    public static C_S_OFFSET_MTL_RESPONSE_CLOSE = "12";
    public static C_S_OFFSET_MTL_RESPONSE_DECLOC = "13";
    //PrajyotD - 20-01-2021 for MTL Touchline (e)

    public static C_S_PG_ATOM_UPIID_VALUE_HEADER = "UP|SMSUPI|";
    public static C_S_PG_ATOM_UPIID_TEXT = "UPIID";
    public static C_S_URL_PARAMERTER_DELIMITER = "&";

    // MenuId Constants for SSO Links
    public static C_S_MENU_MYACCOUNT_BACKOFFICE = "246";
    public static C_S_MENU_MYACCOUNT_BACKOFFICE2 = "247";
    public static C_S_MENU_MYACCOUNT_BACKOFFICE3 = "248";

    public static C_S_EDIS_URL_KEY = "EDIS_REQUEST_NEWNETNET_URL"; //// NewNetNet URL
    public static C_S_EDIS_ODRREQ_DEPOSITORY_CDSL = "CDSL";
    public static C_S_EDIS_ODRREQ_DEPOSITORY_NSDL = "NSDL";
    public static C_S_EDIS_ODRREQ_ERRMSG1 = "Number of transaction limit reached.";
    public static C_S_EDIS_ODRREQ_ERRMSG2 = "Single transaction limit reached.";
    public static C_S_EDIS_ODRREQ_ERRMSG3 = "Daily transaction limit reached.";
    public static C_S_EDIS_ODRREQ_ERRMSG4 = "eDIS quantity can not less than order quantity.";
    public static C_S_EDIS_ODRREQ_ERRMSG5 = "eDIS quantity can not be zero or blank for selected scrip.";
    public static C_S_EDIS_ODRREQ_ERRMSG6 = "eDIS quantity should be less than equal to DP quantity.";
    public static C_S_EDIS_THIRD_PARTY_RESPONSE_KEY = "document.getElementById('hdfldresponse').value";
    public static C_S_USER_POWER_OF_ATTORNEY = "POA";

    public static C_S_CASH_TEXT = "CASH";


    //AjayG: Logger changes-08Apr2021-Start
    public static C_S_LOGTYPE_APPINIT = "appinit";
    public static C_S_LOGTYPE_API = "api";
    public static C_S_LOGTYPE_LATENCY = "latency";
    public static C_S_LOGTYPE_INFO = "info";
    public static C_S_LOGTYPE_ERROR: "error";
    public static C_S_LOGTYPE_APPERROR: "apperr";
    public static C_S_LOGTYPE_OC: "oclog";
    //AjayG: Logger changes-08Apr2021-End

    //added by Vivian F to Handle navigation at UI end , based on error code <start>
    public static ECODE_PWD_EXPIRED = 'e-1';
    public static ECODE_ACC_LOCKED = 'e-2';
    public static ECODE_LOGIN_NOT_ALLOWED = 'e-3';
    public static ECODE_UNSUCESSFUL_MPIN_FINGERPRINT_LOGIN = 'e-4';
    public static ECODE_MPIN_EXPIRED_RESET_MPIN = 'e-5';
    public static ECODE_MPIN_LOCKED_RESET_MPIN = 'e-6';
    public static ECODE_MPIN_EXPIRED = 'e-7';
    public static ECODE_INVALID_MPIN = 'e-8';
    public static ECODE_RESPONSE_FAILURE = 'e-9';
    public static ECODE_FINGERPRINT_AUTHORIZATION_FAILURE = 'e-10';
    public static ECODE_INCORRECT_CLIENTID_OR_PASSWORD = 'e-11';
    public static ECODE_INCORRECT_2FA = 'e-12';
    public static ECODE_REQ_BODY_VALIDATIONS = 'e-13';
    public static ECODE_OC_UNSUCESSFUL_LOGIN = 'e-14';
    //<end>

}

export enum OperationType {
    ADD = 1,
    REMOVE
}



