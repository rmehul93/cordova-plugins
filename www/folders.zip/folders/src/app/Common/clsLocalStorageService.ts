import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
@Injectable({ providedIn: 'root' })
export class clsLocalStorageService {
  constructor(private storage: Storage) {
    //console.log('Hello Localstorage Provider');
  }
  //store the email address
  setObject(key, value) {
    this.storage.set(key, JSON.stringify(value));
  }
  //delete the email address
  remove(key) {
    this.storage.remove(key).then(() => {
      //console.log('email is removed');
    });
  }
  setItem(key, value) {
    this.storage.set(key, value);
  }
  getItem(key) {
    return this.storage.get(key);
  }
  //clear the whole local storage
  clearStorage() {
    this.storage.clear().then(() => {
      console.log('all keys are cleared');
    });
  }
}
