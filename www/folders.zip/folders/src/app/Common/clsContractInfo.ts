import { clsTradingMethods } from "./clsTradingMethods";
import { ToastServicesProvider } from "../providers/toast-services/toast.services";
import { AlertServicesProvider } from "../providers/alert-services/alert-services";
import { clsHttpService } from "./clsHTTPService";
import { clsGlobal } from "./clsGlobal";
import { clsScrip } from "./clsScrip";

export class clsContractInfo {

    constructor(public toastCtrl: ToastServicesProvider,
        public alertCtrl: AlertServicesProvider,
        public httpService: clsHttpService) {

    }
    // Observable properties for displaying contract releated information...
    ScripSymbol = '';
    ContractName = '';
    Token = '';
    Maturity = '';
    ULAsset = '';
    MarketLot = '';
    PriceTick = '';
    IPDate = '';
    LotUnit = '';
    MaxOrderQty = '';
    MaxOrderValue = '';

    ExDate = '';
    PriceQuote = '';
    Margin = '';
    ExMultiplier = '';
    ContractStartDate = '';
    ContractEndDate = '';
    TenderStartDate = '';

    TenderEndDate = '';
    DelStartDate = '';
    DelEndDate = '';
    NearMonthId = '';
    FarMonthId = '';

    OtLongMargin = '';
    OtShortMargin = '';
    InLongMargin = '';
    InShortMargin = '';
    ExMargin = '';
    AddLongMargin = '';

    AddShortMargin = '';
    AddPreMargin = '';
    SPLGCMargin = '';
    SPSHCMargin = '';
    AppLongMargin = '';
    AppShortMargin = '';

    marketSegId: any = '';
    mapmarketSegId: any = '';
    ArrSubTokens = null;
    ReportName = "";

    AssetToken = '';
    ISIN = '';
    MCapCallBack = null;


    PrevDayOpen = '';
    PrevDayHigh = '';
    PrevDayLow = '';
    PrevDayClose = '';
    scripInfo: clsScrip;
    showSettlementType = false;//Code Comment : Flag Variable to display Physical Settlement Type 
    SettlementType = '';//Code Comment : Variable to store Settlement Type value.This will display in Contract Info Section.


    // Function to get the contract information for the selected scrip...
    displayDetails(objScrip: clsScrip) {
        try {

            this.scripInfo = objScrip;
            this.marketSegId = objScrip.scripDet.MktSegId;
            this.mapmarketSegId = objScrip.scripDet.MapMktSegId;
            this.Token = objScrip.scripDet.token;

            let mpParamReq: any = {};
            mpParamReq.mktSegmentId = this.mapmarketSegId;
            mpParamReq.token = this.Token;
            mpParamReq.symbol = objScrip.symbol;
            mpParamReq.instName = objScrip.InstrumentName;
            mpParamReq.strkPrice =objScrip.StrikePrice !="NA" ? parseFloat(objScrip.StrikePrice) * objScrip.DecimalLocator: "-1";
            mpParamReq.optType = objScrip.OptionType != "NA" ? objScrip.OptionType:"";
            mpParamReq.expDate = clsTradingMethods.convertToSeconds(objScrip.ExpiryDate);
            mpParamReq.siTemplateId = clsGlobal.User.SITemplateId;

            this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getContractInfo', mpParamReq).subscribe((data => {

                if (data.status) {
                    this.setContInfo(data);
                } else {
                    this.toastCtrl.showAtBottom(data.errorCode);
                }
            }),
                error => {
                   //this.toastCtrl.showAtBottom(error);
                   this.toastCtrl.showAtBottom("Unable to fetch scrip details.");
                   clsGlobal.logManager.writeErrorLog("clsContractInfo", "displayDetails_getContractInfo", error.message);
                });

        }
        catch (e) {
           // this.toastCtrl.showAtBottom('displayDetails contractinfo: ' + e.message);
           clsGlobal.logManager.writeErrorLog("clsContractInfo", "displayDetails", e.message);
        }
    }

    // Success call back function for GetContractInfo wcf and here the details will be assigned to the observable properties...
    setContInfo(objResponse) {
        try {
            var dcResp = objResponse.result;
            var dcDetails = clsTradingMethods.getContractInfo(dcResp.secInfo[0],dcResp.pivot[0], this.marketSegId);

            // var _objScrip = new fn_Scrip();
            // _objScrip.ScripDet.MktSegId = (parseInt(MarketSegId));
            // _objScrip.ScripDet.MapMktSegId = TradingGlobal.TradingMethods.GetMappedMarketSegmentId(parseInt(MarketSegId));
            // //
            // _objScrip.ScripDet.Token = dcDetails.Token;
            // _objScrip.Symbol = dcDetails.sSymbol.toUpperCase();
            // _objScrip.Series = dcDetails.sSeries;
            // _objScrip.InstrumentName = dcDetails.sInstrumentName;
            // _objScrip.ExchangeName = TradingGlobal.TradingMethods.GetExchangeName(parseInt(MarketSegId));
            // _objScrip.ExpiryDate = dcDetails.ExDate;
            // _objScrip.OptionType = dcDetails.sOptionType;
            // _objScrip.StrikePrice = dcDetails.nStrikePrice;
            // _objScrip.DecimalLocator = dcDetails.nDecimalLocator;

            //_objScrip.MWSecurityDesc = TradingGlobal.TradingMethods.FormatScripDescForMW(_objScrip);
            this.ScripSymbol = this.scripInfo.MWSecurityDesc;

            this.ContractName = (dcDetails.ContractName);
            //Token=(dcDetails.Token);
            this.ULAsset = (dcDetails.ULAsset);
            this.IPDate = (dcDetails.IPDate);
            this.MarketLot = (dcDetails.MarketLot);
            this.PriceTick = (dcDetails.PriceTick);
            this.Maturity = (dcDetails.Maturity);
            this.ExDate = (dcDetails.ExDate);
            this.PriceQuote = (dcDetails.PriceQuote);
            this.Margin = (dcDetails.Margin);
            this.ExMultiplier = (dcDetails.ExMultiplier);
            this.ContractStartDate = (dcDetails.ContractStartDate);
            this.ContractEndDate = (dcDetails.ContractEndDate);
            this.TenderStartDate = (dcDetails.TenderStartDate);
            this.TenderEndDate = (dcDetails.TenderEndDate);
            this.DelStartDate = (dcDetails.DelStartDate);
            this.DelEndDate = (dcDetails.DelEndDate);
            this.NearMonthId = (dcDetails.NearMonthId);
            this.FarMonthId = (dcDetails.FarMonthId);
            this.OtLongMargin = (dcDetails.OLongMargin);
            this.OtShortMargin = (dcDetails.OShortMargin);
            this.ExMargin = (dcDetails.ExMargin);
            this.AddLongMargin = (dcDetails.AddLongMargin);
            this.AddShortMargin = (dcDetails.AddShortMargin);
            this.AddPreMargin = (dcDetails.AddPreMargin);
            this.SPLGCMargin = (dcDetails.SPLGCMargin);
            this.SPSHCMargin = (dcDetails.SPSHCMargin);
            this.InLongMargin = (dcDetails.InLongMargin);
            this.InShortMargin = (dcDetails.InShortMargin);
            this.AppLongMargin = (dcDetails.AppLongMargin);
            this.AppShortMargin = (dcDetails.AppShortMargin);
            this.LotUnit = (dcDetails.LotUnit);
            this.MaxOrderQty = (dcDetails.MaxOrderQty);
            this.MaxOrderValue = (dcDetails.MaxOrderValue);
            this.AssetToken = dcResp.nAssetToken;
            this.ISIN = dcResp.sISINCode;
            if (this.ISIN == null || this.ISIN == undefined)
                this.ISIN = '';

            if (dcResp.highlowclose.length > 0) {
                this.PrevDayOpen = dcResp.highlowclose[0].PrevOpen;
                this.PrevDayHigh = dcResp.highlowclose[0].PrevHigh;
                this.PrevDayLow = dcResp.highlowclose[0].PrevLow;
                this.PrevDayClose = dcResp.highlowclose[0].PrevClose;
            }

            this.showSettlementType = dcDetails.showSettlementType;
            this.SettlementType = dcDetails.SettlementType;

            dcResp = null;
            dcDetails = null;

            if (this.MCapCallBack != null) {
                this.MCapCallBack('NA');
            }

        }
        catch (e) {

        }
    }

};

