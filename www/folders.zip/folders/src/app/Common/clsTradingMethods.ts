import { IKeyedCollection, Dictionary } from './clsCustomClasses';
import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsScrip } from './clsScrip';
import { clsOEFormDetl } from './clsOrderEntryFormDetl';
import { DatePipe } from '@angular/common';
import { clsCommonMethods } from './clsCommonMethods';
import { StringBuilder } from './clsCustomClasses';
import { clsHttpService } from './clsHTTPService';


export class clsTradingMethods {
    //private static _lkUp: IKeyedCollection<string> = new Dictionary<string>();

    constructor() { }
    /**
     * Method to get mapped market segment id (manager once) from normal Market Segment Id (OC once)
     * e.g. for BSE if method input is 3 then method output will be 8
    */
    public static getMappedMarketSegmentId(_iMarketSegmentId) {
        let _iMappedMarketSegmentId = -1;
        try {
            switch (parseInt(_iMarketSegmentId)) {
                case clsConstants.C_V_NSE_CASH:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSE_CASH;
                    break;
                case clsConstants.C_V_NSE_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSE_DERIVATIVES;
                    break;
                case clsConstants.C_V_BSE_CASH:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BSE_CASH;
                    break;
                case clsConstants.C_V_BSE_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BSE_DERIVATIVES;
                    break;
                case clsConstants.C_V_MCX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MCX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MCX_SPOT;
                    break;
                case clsConstants.C_V_NCDEX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES;
                    break;
                case clsConstants.C_V_NCDEX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NCDEX_SPOT;
                    break;
                case clsConstants.C_V_NSEL_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSEL_DERIVATIVES;
                    break;
                case clsConstants.C_V_NSEL_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSEL_SPOT;
                    break;
                case clsConstants.C_V_MSX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MSX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MSX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MSX_SPOT;
                    break;
                case clsConstants.C_V_NSX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSX_DERIVATIVES;
                    break;
                case clsConstants.C_V_NSX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NSX_SPOT;
                    break;
                case clsConstants.C_V_BSECDX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES;
                    break;
                case clsConstants.C_V_BSECDX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BSECDX_SPOT;
                    break;
                case clsConstants.C_V_MSX_CASH:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MSX_CASH;
                    break;
                case clsConstants.C_V_MSX_FAO:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_MSX_FAO;
                    break;
                case clsConstants.C_V_NMCE_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_NMCE_DERIVATIVES;
                    break;
                case clsConstants.C_V_DSE_CASH:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_DSE_CASH;
                    break;
                case clsConstants.C_V_UCX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_UCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_UCX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_UCX_SPOT;
                    break;
                case clsConstants.C_V_DGCX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_DGCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_DGCX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_DGCX_SPOT;
                    break;
                case clsConstants.C_V_BFX_DERIVATIVES:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BFX_DERIVATIVES;
                    break;
                case clsConstants.C_V_BFX_SPOT:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_BFX_SPOT;
                    break;
                case clsConstants.C_V_OFS_IPO_BONDS:
                    _iMappedMarketSegmentId = clsConstants.C_V_MAPPED_OFS_IPO_BONDS;
                    break;
                default:
                    _iMappedMarketSegmentId = -1;
                    break;
            }
        }
        catch (e) {
            console.log(e);
            // LogManager.WriteLog(e.message, 'GetMappedMarketSegmentId', 'WWTradingMethods.js', '');
        }
        return _iMappedMarketSegmentId;
    }

    /**
     * Method to get normal Market Segment Id (OC once) from mapped market segment id (manager once)
     * e.g. for BSE if method input is 8 then method output will be 3
    */
    public static GetMarketSegmentID(_iMappedMarketSegmentId): any {
        let _iMarketSegmentId = -1;
        try {
            switch (parseInt(_iMappedMarketSegmentId)) {
                case clsConstants.C_V_MAPPED_NSE_CASH:
                    _iMarketSegmentId = clsConstants.C_V_NSE_CASH;
                    break;
                case clsConstants.C_V_MAPPED_NSE_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_NSE_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_BSE_CASH:
                    _iMarketSegmentId = clsConstants.C_V_BSE_CASH;
                    break;
                case clsConstants.C_V_MAPPED_BSE_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_BSE_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_MCX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_MCX_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_MCX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_NCDEX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_NCDEX_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_NCDEX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_NSEL_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_NSEL_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_NSEL_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_NSEL_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_MSX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MSX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_MSX_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_MSX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_NSX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_NSX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_NSX_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_NSX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_BSECDX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_BSECDX_SPOT:
                    _iMarketSegmentId = clsConstants.C_V_BSECDX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_MSX_CASH:
                    _iMarketSegmentId = clsConstants.C_V_MSX_CASH;
                    break;
                case clsConstants.C_V_MAPPED_MSX_FAO:
                    _iMarketSegmentId = clsConstants.C_V_MSX_FAO;
                    break;
                case clsConstants.C_V_MAPPED_NMCE_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_NMCE_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_DSE_CASH:
                    _iMarketSegmentId = clsConstants.C_V_DSE_CASH;
                    break;
                case clsConstants.C_V_MAPPED_UCX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_UCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_DGCX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_DGCX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_BFX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_BFX_DERIVATIVES;
                    break;
                case clsConstants.C_V_MAPPED_OFS_IPO_BONDS:
                    _iMarketSegmentId = clsConstants.C_V_OFS_IPO_BONDS;
                    break;
                default:
                    _iMarketSegmentId = -1;
                    break;
            }
        }
        catch (e) {
            throw e;

            //LogManager.WriteLog('Exception: ' + e.message, 'GetMarketSegmentID', 'tr_TradingMethods.js', '');

        }
        return _iMarketSegmentId;
    }


    public static GetSegmentId(exchangename): any {
        let strExName = exchangename.toUpperCase();
        let intMktSegId;

        switch (strExName) {
            case clsConstants.C_S_NSE_EQ_API_NAME:
                intMktSegId = clsConstants.C_V_NSE_CASH;
                break;
            case clsConstants.C_S_NSE_DERV_API_NAME:
                intMktSegId = clsConstants.C_V_NSE_DERIVATIVES;
                break;
            case clsConstants.C_S_BSE_EQ_API_NAME:
                intMktSegId = clsConstants.C_V_BSE_CASH;
                break;
            case clsConstants.C_S_BSE_DERV_API_NAME:
                intMktSegId = clsConstants.C_V_BSE_DERIVATIVES;
                break;
        }

        return intMktSegId;
    }

    public static getSpotMarketSegmentId(_iMappedMarketSegmentId): number {
        let _iMarketSegmentId = -1;
        try {
            switch (parseInt(_iMappedMarketSegmentId)) {

                case clsConstants.C_V_MAPPED_NSE_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_NSE_CASH;
                    break;
                case clsConstants.C_V_MAPPED_BSE_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_BSE_CASH;
                    break;
                case clsConstants.C_V_MAPPED_MCX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_MCX_SPOT;
                    break;

                case clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_NCDEX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_NSEL_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_NSEL_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_MSX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_MSX_SPOT;
                    break;

                case clsConstants.C_V_MAPPED_NSX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_NSX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_BSECDX_SPOT;
                    break;
                case clsConstants.C_V_MAPPED_MSX_FAO:
                    _iMarketSegmentId = clsConstants.C_V_MAPPED_MSX_CASH;
                    break;
                default:
                    _iMarketSegmentId = -1;
                    break;
            }
        }
        catch (e) {
            throw e;

            //LogManager.WriteLog('Exception: ' + e.message, 'GetMarketSegmentID', 'tr_TradingMethods.js', '');

        }
        return _iMarketSegmentId;
    }

    /**
     * Get 
     * 
     */
    public static getGroupedSegement(exchange, segment){
        try {
          var strSelectedExch = exchange.trim().toUpperCase();
          var strSelectedInst = segment.trim().toUpperCase();
          var strGroupedSeg = "";
        
          if (strSelectedExch == clsConstants.C_S_NSE_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT:
                      strGroupedSeg =clsConstants.CONST_EQUITY;
                      break;
                  case clsConstants.C_S_INSTRUMENT_FUTURES_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIONS_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT:
                      strGroupedSeg = clsConstants.CONST_EQFAO;
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_BSE_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT:
                      strGroupedSeg = clsConstants.CONST_EQUITY;
                      break;
                  case clsConstants.C_S_INSTRUMENT_FUTURES_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIONS_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT:
                      strGroupedSeg = clsConstants.CONST_EQFAO;
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_MCX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT:
                      strGroupedSeg = clsConstants.CONST_COMMODITY;
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_NCDEX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT:
                      strGroupedSeg = clsConstants.CONST_COMMODITY;
                      break;
                  case clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT:
                      strGroupedSeg = "";
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_NSEL_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_NSELSPTCOM_TEXT:
                  case clsConstants.C_S_INSTRUMENT_MCXFUTSPT_TEXT:
                      strGroupedSeg = "";
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_MSX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_CURRENCY_TEXT: 
                  case clsConstants.C_S_INSTRUMENT_CUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT:
                      strGroupedSeg = clsConstants.CONST_CURR;
                      break;
    
                  case clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT:
                      strGroupedSeg = clsConstants.CONST_EQUITY;
                      break;
                  case clsConstants.C_S_INSTRUMENT_FUTURES_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIONS_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT:
                      strGroupedSeg =clsConstants.CONST_EQFAO; 
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_NSX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT:
                      strGroupedSeg =clsConstants.CONST_CURR;
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_BSECDX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT:
                      strGroupedSeg = clsConstants.CONST_CURR; 
                      break;
              }
          }
          else if (strSelectedExch == clsConstants.C_S_DSE_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT:
                      strGroupedSeg = clsConstants.CONST_EQUITY; 
                      break;
              }
          } 
          else if (strSelectedExch == clsConstants.C_S_BFX_EXCHANGE_TEXT) {
              switch (strSelectedInst) {
                  case clsConstants.C_S_INSTRUMENT_FUTURES_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT:
                      strGroupedSeg = "";
                      break;
                  case clsConstants.C_S_INSTRUMENT_OPTIONS_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT:
                  case clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT:
                      strGroupedSeg = "";
                      break;
              }
          }
          /**<USD : BT-12359> <Yogesh Kadam> <28/02/2020> Added Of ICEX Exchange */
          else if (strSelectedExch == clsConstants.C_S_ICEX_EXCHANGE_TEXT) {
            strGroupedSeg = clsConstants.CONST_COMMODITY;
          }
          /**END */
          /** <Norwin Dcruz> <22/01/2020> <USD : BT-11345> <Used for segemnt array, for interoperability> **/
          else if (strSelectedExch == clsConstants.C_S_COMBINED_CASH.trim().toUpperCase()) {
              strGroupedSeg = clsConstants.C_S_CONST_COMBINED_EQ;
          }
          else if (strSelectedExch == clsConstants.C_S_COMBINED_FNO.trim().toUpperCase()) {
              strGroupedSeg = clsConstants.C_S_CONST_COMBINED_DERV;
          }
          else if (strSelectedExch == clsConstants.C_S_COMBINED_CDS.trim().toUpperCase()) {
              strGroupedSeg = clsConstants.C_S_CONST_COMBINED_CUR;
          }
          //<End>
          /** <Norwin Dcruz> <22/01/2020> <USD : BT-11345> <Used for segemnt array, for interoperability> **/
          return strGroupedSeg;      
        } catch (error) {
          
        }
      }

     public static checkIsCombined(SegmentID, CombinedSegment){
        try {
            var flag = false;
            if ((SegmentID == clsConstants.C_V_COMBINED_CASH && CombinedSegment == clsConstants.C_S_CONST_COMBINED_EQ) ||
                (SegmentID == clsConstants.C_V_COMBINED_FNO && CombinedSegment == clsConstants.C_S_CONST_COMBINED_DERV) ||
                (SegmentID == clsConstants.C_V_COMBINED_CDS && CombinedSegment == clsConstants.C_S_CONST_COMBINED_CUR))
                    flag= true
         
            return flag;
        }
        catch (e) {        
            clsGlobal.logManager.writeErrorLog('NetPositionsPage', 'checkIsCombined', e);        
        }
    }

    /// Accepts normal MktSegId and returns ExchangeName

    public static getExchangeName(intMktSegId: number): string {
        let strExName: string = "";

        switch (intMktSegId) {
            case clsConstants.C_V_NSE_CASH:
            case clsConstants.C_V_NSE_DERIVATIVES:
                strExName = clsConstants.C_S_NSE_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_BSE_CASH:
            case clsConstants.C_V_BSE_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_MCX_DERIVATIVES:
            case clsConstants.C_V_MCX_SPOT:
                strExName = clsConstants.C_S_MCX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_NCDEX_DERIVATIVES:
            case clsConstants.C_V_NCDEX_SPOT:
                strExName = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_NSEL_DERIVATIVES:
            case clsConstants.C_V_NSEL_SPOT:
                strExName = clsConstants.C_S_NSEL_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_MSX_DERIVATIVES:
            case clsConstants.C_V_MSX_SPOT:
            case clsConstants.C_V_MSX_CASH:
            case clsConstants.C_V_MSX_FAO:
                strExName = clsConstants.C_S_MSX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_DSE_CASH:
                strExName = clsConstants.C_S_DSE_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_NMCE_DERIVATIVES:
                strExName = clsConstants.C_S_NMCE_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_NSX_DERIVATIVES:
            case clsConstants.C_V_NSX_SPOT:
                strExName = clsConstants.C_S_NSX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_BSECDX_DERIVATIVES:
            case clsConstants.C_V_BSECDX_SPOT:
                strExName = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_UCX_DERIVATIVES:
            case clsConstants.C_V_UCX_SPOT:
                strExName = clsConstants.C_S_UCX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_DGCX_DERIVATIVES:
            case clsConstants.C_V_DGCX_SPOT:
                strExName = clsConstants.C_S_DGCX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_BFX_DERIVATIVES:
            case clsConstants.C_V_BFX_SPOT:
                strExName = clsConstants.C_S_BFX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_OFS_IPO_BONDS:
                strExName = clsConstants.C_S_OTSTXT_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_ADX_CASH:
                strExName = clsConstants.C_S_ADX_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_DFM_CASH:
                strExName = clsConstants.C_S_DFM_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_COMBINED_CASH:
                strExName = clsConstants.C_S_COMBINED_CASH;
                break;
            case clsConstants.C_V_COMBINED_FNO:
                strExName = clsConstants.C_S_COMBINED_FNO;
                break;
            case clsConstants.C_V_COMBINED_CDS:
                strExName = clsConstants.C_S_COMBINED_CDS;
                break;
        }

        return strExName;
    }

    /// converts a price in paise to a price in rupees depending upon the decimal locator passed
    public static ConvertToRe(strPrice: any, intMktSegId: number, strDecimalLoc: string): string {
        try {
            if (!(strPrice))
                return '0.00';
            let strOutput = '0.00';

            if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLoc.trim() == "0")
                    strDecimalLoc = "100";

                if (strDecimalLoc.trim() == "0")
                    strDecimalLoc = "10000";
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
                intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT) {
                if (strDecimalLoc.trim() == "0")
                    strDecimalLoc = clsConstants.C_V_NSECDS_DECLOC;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
                intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT) {
                if (strDecimalLoc.trim() == "0")
                    strDecimalLoc = clsConstants.C_V_BSECDX_DECLOC;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT ||
                intMktSegId == clsConstants.C_V_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_BFX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO ||
                intMktSegId == clsConstants.C_V_MSX_CASH || intMktSegId == clsConstants.C_V_MSX_FAO) {
                if (strDecimalLoc.trim() == "0")
                    strDecimalLoc = "100";
            }
            else {
                strDecimalLoc = "100";
            }

            let strPriceFormat = this.GetPriceFormatterWithDLAndMksSegID(strDecimalLoc, intMktSegId);
            if (intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT ||
                intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT ||
                intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT ||
                intMktSegId == clsConstants.C_V_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_BFX_SPOT ||
                intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO ||
                intMktSegId == clsConstants.C_V_MSX_CASH || intMktSegId == clsConstants.C_V_MSX_FAO)
                strOutput = (parseFloat(strPrice) / parseFloat(strDecimalLoc)).toFixed(strPriceFormat);
            else
                strOutput = (parseFloat(strPrice) / 100).toFixed(strPriceFormat);
            return strOutput;
        }
        catch (e) {

        }
    }

    /// To get the Price format as per the Decimal Locator i.e 0.00 or 0.0000 and MktSegId
    public static GetPriceFormatterWithDLAndMksSegID(strDecimalLocator: string, intMktSegId: number): number {
        try {
            if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT
                || intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT
                || intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLocator.trim() == "0")
                    strDecimalLocator = "100";

                if (strDecimalLocator.trim() == "0")
                    strDecimalLocator = "10000";

                if (strDecimalLocator == ("100"))
                    return 2;
                else if (strDecimalLocator == ("10000") || strDecimalLocator == (clsConstants.C_V_NSECDS_DECLOC))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT) {
                if (strDecimalLocator == ("1000"))
                    return 3;
                else if (strDecimalLocator == ("10000"))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO) {
                if (strDecimalLocator.trim() == "0")
                    return 2;
                else
                    return this.getPriceFormatterFromDecimalLocator(parseInt(strDecimalLocator, 10));
            }
            else {
                return 2;
            }
        }
        catch (e) {

        }
    }

    /// To get the Price format as per the Decimal Locator i.e 0.00 or 0.0000
    public static getPriceFormatterFromDecimalLocator(iDecimalLc: number): number {
        let strFormat = "2";
        try {
            strFormat = (iDecimalLc.toString().length - 1).toString();
        }
        catch (e) {
        }
        return parseInt(strFormat);
    }


    /// converts a price in paise to a price in rupees depending upon the price passed
    public static ConvertToReWithPrice(strPrice: any) {
        try {
            if (!(strPrice))
                return '0.00';
            let strOutput = '2';
            strOutput = (parseFloat(strPrice) / 100.00).toFixed(2);
            return strOutput;
        }
        catch (e) {
        }
    }

    public static getExchangeColor(_iMarketSegmentId: number): string {
        let strCSS = '';
        try {
            switch (_iMarketSegmentId) {
                case clsConstants.C_V_NSE_CASH:
                case clsConstants.C_V_NSE_DERIVATIVES:
                case clsConstants.C_V_NSX_DERIVATIVES:
                case clsConstants.C_V_NSX_SPOT:
                case clsConstants.C_V_OFS_IPO_BONDS:
                    strCSS = 'nse';
                    break;
                case clsConstants.C_V_BSE_CASH:
                case clsConstants.C_V_BSE_DERIVATIVES:
                case clsConstants.C_V_BSECDX_DERIVATIVES:
                case clsConstants.C_V_BSECDX_SPOT:
                    strCSS = 'bse';
                    break;
                case clsConstants.C_V_MCX_DERIVATIVES:
                case clsConstants.C_V_MCX_SPOT:
                    strCSS = 'mcx';
                    break;
                case clsConstants.C_V_NCDEX_DERIVATIVES:
                case clsConstants.C_V_NCDEX_SPOT:
                    strCSS = 'ncdex';
                    break;
                case clsConstants.C_V_MSX_DERIVATIVES:
                case clsConstants.C_V_MSX_SPOT:
                case clsConstants.C_V_MSX_CASH:
                case clsConstants.C_V_MSX_FAO:
                    strCSS = 'ncdex';
                    break;
                case clsConstants.C_V_NMCE_DERIVATIVES:
                    strCSS = 'nmce';
                    break;
                default:
                    strCSS = 'nse';
                    break;
            }
        }
        catch (e) {

        }
        return strCSS;
    }

    public static getSpotFutureSegmentId(_iMarketSegmentId: number): number {
        let strMapMktSegId = -1;
        try {
            // If Mapped market segment id is spot, then change it to futures
            // as for MCX, NCDEX etc. the Exchange allowed dictionary contains only futures
            // so if futures is ON, then consider spot also as ON.
            switch (_iMarketSegmentId) {
                case (clsConstants.C_V_MAPPED_MCX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_MCX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_NCDEX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_NSEL_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_NSEL_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_MSX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_MSX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_NSX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_NSX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_UCX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_UCX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_DGCX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_DGCX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_BFX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_BFX_DERIVATIVES);
                    break;
                case (clsConstants.C_V_MAPPED_BSECDX_SPOT): strMapMktSegId = (clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES);
                    break;
                default:
                    strMapMktSegId = _iMarketSegmentId;
                    break;
            }
        }
        catch (e) {
        }
        return strMapMktSegId;
    }

    // get current time in hh:mm:ss format
    public static GetCurrentTime(): string {
        let CurrentDate = new Date();
        let strTime = "";
        let hr, min, sec;
        hr = CurrentDate.getHours();
        min = CurrentDate.getMinutes();
        sec = CurrentDate.getSeconds();
        if (hr < 10)
            hr = "0" + hr;
        if (min < 10)
            min = "0" + min;
        if (sec < 10)
            sec = "0" + sec;
        strTime = hr + ":" + min + ":" + sec;
        return strTime;
    }

    public static getDateandTime(date): string {
        let inputDate = new Date(date);
        let Day: any = inputDate.getDate();
        Day = Day < 10 ? "0" + Day.toString() : Day;
        let Month: any = (inputDate).toLocaleString('default', { month: 'short' }).toUpperCase();
        let Year: any = inputDate.getFullYear().toString().substr(-2)
        let strDate = Day + ' ' + Month + ' ' + "'" + Year;

        let hours = inputDate.getHours();
        let minutes = inputDate.getMinutes().toString();
        let seconds = inputDate.getSeconds();
        let ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        let hrs: any;
        let sec: any;
        if (hours < 10) {
            hrs = "0" + hours.toString();
        }
        else {
            hrs = hours;
        }
        if (seconds < 10) {
            sec = "0" + seconds.toString();
        }
        else {
            sec = seconds;
        }
        minutes = parseFloat(minutes) < 10 ? '0' + minutes : minutes;
        let strDateTime = strDate + ' ' + hrs + ':' + minutes + ':' + sec + ' ' + ampm;
        return strDateTime;
    }

    public static getAgoTIme(d): any {
        let currentDate = new Date(new Date().toUTCString());
        let date = new Date(d);

        let year = currentDate.getFullYear() - date.getFullYear();
        let month = currentDate.getMonth() - date.getMonth();
        let day = currentDate.getDate() - date.getDate();
        let hour = currentDate.getHours() - date.getHours();
        let minute = currentDate.getMinutes() - date.getMinutes();
        let second = currentDate.getSeconds() - date.getSeconds();

        let createdSecond = (year * 31556926) + (month * 2629746) + (day * 86400) + (hour * 3600) + (minute * 60) + second;

        if (createdSecond >= 31556926) {
            let yearAgo = Math.floor(createdSecond / 31556926);
            return yearAgo > 1 ? yearAgo + " years ago" : yearAgo + " year ago";
        } else if (createdSecond >= 2629746) {
            let monthAgo = Math.floor(createdSecond / 2629746);
            return monthAgo > 1 ? monthAgo + " months ago" : monthAgo + " month ago";
        } else if (createdSecond >= 86400) {
            let dayAgo = Math.floor(createdSecond / 86400);
            return dayAgo > 1 ? dayAgo + " days ago" : dayAgo + " day ago";
        } else if (createdSecond >= 3600) {
            let hourAgo = Math.floor(createdSecond / 3600);
            return hourAgo > 1 ? hourAgo + " hours ago" : hourAgo + " hour ago";
        } else if (createdSecond >= 60) {
            let minuteAgo = Math.floor(createdSecond / 60);
            return minuteAgo > 1 ? minuteAgo + " minutes ago" : minuteAgo + " minute ago";
        } else if (createdSecond < 60) {
            return createdSecond > 1 ? createdSecond + " seconds ago" : createdSecond + " second ago";
        } else if (createdSecond < 0) {
            return "0 second ago";
        }

    }

    public static getOnlyTime(time): any {
        let measuredTime = new Date(null);
        measuredTime.setSeconds(time);
        let MHSTime = measuredTime.toISOString().substr(11, 8);
        let ts = MHSTime;
        let H = +ts.substr(0, 2);
        let h: any = (H % 12) || 12;
        h = (h < 10) ? ("0" + h) : h;
        let ampm = H < 12 ? " AM" : " PM";
        ts = h + ts.substr(2) + ampm;
        return ts;
    }

    public static getSecondLegDate(time): any {
        let measuredTime = new Date("01-01-1980");
        measuredTime.setSeconds(time);
        let Day: any = measuredTime.getDate();
        Day = Day < 10 ? "0" + Day.toString() : Day;
        let Month: any = (measuredTime).toLocaleString('default', { month: 'short' }).toUpperCase();
        let Year: any = measuredTime.getFullYear().toString();
        let strDate = Day + '' + Month + '' + Year;
        return strDate;
    }

    public static getOnlyDate(date): string {
        let inputDate = new Date(date);
        let Day: any = inputDate.getDate();
        Day = Day < 10 ? "0" + Day.toString() : Day;
        let Month: any = (inputDate).toLocaleString('default', { month: 'short' }).toUpperCase();
        let Year: any = inputDate.getFullYear().toString().substr(-2)
        let strDate = Day + ' ' + Month + ' ' + "'" + Year;
        return strDate;
    }

    // Finds the value of the tag in the raw message from OC
    public static FindValue(arrInput: any, strCheckFor: string): string {
        let sVal = '';
        try {
            arrInput = "|" + arrInput;
            let myRegExp = new RegExp('[^0-9]' + strCheckFor.trim() + '[ ]*=[ ]*([^|]*)', 'g');
            let aRegResult = myRegExp.exec(arrInput);
            if (aRegResult !== null && aRegResult[1] != 'undefined' && aRegResult[1] != '') {
                sVal = aRegResult[1];
            }
        } catch (e) {
            throw e;
        }
        return sVal;
    }

    // Returns an array of an comnbined result of KeyValuePair where key holds an msg tag and Value hold an data value related to the tag based on Field Delimiter
    public static LookUp(_strResponse) {
        let _lkUp: IKeyedCollection<string> = new Dictionary<string>();
        try {
            var iIterator, sFieldData = "";
            var aFieldData;
            if (_strResponse != undefined) {
                var _respData = _strResponse.split(clsConstants.C_S_FIELD_DELIMITER);
                for (iIterator = 0; iIterator < _respData.length; iIterator++) {
                    sFieldData = _respData[iIterator];
                    if (sFieldData != 'undefined') {
                        aFieldData = sFieldData.split(clsConstants.C_S_NAMEVALUE_DELIMITER);
                        _lkUp.Add(aFieldData[0], aFieldData[1]);
                    }
                }
            }
        }
        catch (e) {

        }
        return _lkUp;
    };

    /// <summary>
    /// Removing the pipe delimiter from the response string if it is appended at the end of response packet
    /// </summary>
    /// <param name="_strSource">Response packet string</param>
    public static RemoveFieldDelimiter(_strSource) {
        if (_strSource.endsWith(clsConstants.C_S_FIELD_DELIMITER))
            _strSource = _strSource.substring(0, _strSource.length - 1);
        return _strSource;
    };

    // Returns an array of an comnbined result of KeyValuePair where key holds an msg tag and Value hold an data value related to the tag based on Record Delimiter
    public static RecordDelimitLookUp(_strResponse) {
        let _lkUp: IKeyedCollection<string> = new Dictionary<string>();
        try {
            var iIterator;
            var aFieldData;
            //Splitting incoming packet by "|"
            var _respData = _strResponse.split(clsConstants.C_S_RECORD_DELIMITER);
            for (iIterator = 0; iIterator < _respData.length; iIterator++) {
                aFieldData = _respData[iIterator].split(clsConstants.C_S_NAMEVALUE_DELIMITER);
                //lkUp[aFieldData[0]] = aFieldData[1];
                _lkUp.Add(aFieldData[0], aFieldData[1]);
            }
        }
        catch (e) {

        }
        return _lkUp;
    };

    /// To get the Price format as per the Decimal Locator, MktSegId, InstName using DecimalLocator, MktSegId
    public static getPriceFormatter(strDecimalLocator, intMktSegId: number) {
        try {
            if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT || intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
                intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLocator.trim() == "0")
                    strDecimalLocator = "100";

                if (strDecimalLocator.trim() == "0")
                    strDecimalLocator = "10000";

                if (strDecimalLocator === ("100"))
                    return 2;
                else if (strDecimalLocator === ("10000") || strDecimalLocator === (clsConstants.C_V_NSECDS_DECLOC))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT) {
                if (strDecimalLocator === ("1000"))
                    return 3;
                else if (strDecimalLocator === ("10000"))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO) {
                return this.getPriceFormatterFromDecimalLocator(parseInt(strDecimalLocator, 10));
            }
            else if (strDecimalLocator !== null && strDecimalLocator !== "" && strDecimalLocator !== "0") {
                return this.GetNoOfZeros(strDecimalLocator);
            }
            else {
                return 2;
            }
        }
        catch (e) {

        }
    };

    /// To get the No. Of Zeros in the decimal locator
    public static GetNoOfZeros(num) {
        num = parseFloat(num);
        let count = 0;
        let last = 0;
        while (last == 0) {
            last = parseFloat((num % 10).toString());
            num = num / 10;
            count++;
        }
        return count - 1;
    }

    public static ParseTER(intMktSegId, strTER) {
        if (intMktSegId != clsConstants.C_V_NSE_DERIVATIVES && intMktSegId != clsConstants.C_V_NSX_DERIVATIVES && intMktSegId != clsConstants.C_V_MAPPED_NSX_DERIVATIVES)
            strTER = "";

        return strTER;
    };

    /// <summary>
    /// Function to return the string value for a value with decimal places set according to segments
    /// </summary>
    /// <param name="strOrgValue"></param>
    /// <returns></returns>
    public static getPreciseValue(strOrgValue, MktSegId, DecimalLocator) {
        var strPrecValue = strOrgValue;
        var strPrecison = "2"; //Default Value as 2 precisions
        if (strOrgValue != "" && parseFloat(strOrgValue) > 0) {
            if (MktSegId == clsConstants.C_V_MSX_DERIVATIVES || MktSegId == clsConstants.C_V_MSX_SPOT || MktSegId == clsConstants.C_V_NSX_SPOT || MktSegId == clsConstants.C_V_NSX_DERIVATIVES ||
                MktSegId == clsConstants.C_V_BSECDX_SPOT || MktSegId == clsConstants.C_V_BSECDX_DERIVATIVES) {
                if (MktSegId == clsConstants.C_V_NSX_SPOT || MktSegId == clsConstants.C_V_BSECDX_SPOT) {
                    if (DecimalLocator == 100)
                        strPrecison = "2";
                    else
                        strPrecison = "4";
                }
                else
                    strPrecison = "4";
            }
            else if (MktSegId == clsConstants.C_V_MCX_SPOT || MktSegId == clsConstants.C_V_NSEL_SPOT || MktSegId == clsConstants.C_V_MCX_DERIVATIVES) {
                if (DecimalLocator == 10000)
                    strPrecison = "4";
            }
            else if (MktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || MktSegId == clsConstants.C_V_MAPPED_BFX_SPOT
                || MktSegId == clsConstants.C_V_BFX_DERIVATIVES || MktSegId == clsConstants.C_V_BFX_SPOT) {
                if (DecimalLocator == 1000)
                    strPrecison = "3";
                if (DecimalLocator == 10000)
                    strPrecison = "4";
            }
            else if (MktSegId == clsConstants.C_V_MSX_CASH || MktSegId == clsConstants.C_V_MSX_FAO ||
                MktSegId == clsConstants.C_V_MAPPED_MSX_CASH || MktSegId == clsConstants.C_V_MAPPED_MSX_FAO) {
                var strFormat = "2";
                strFormat = (DecimalLocator.toString().length - 1).toString();
                strPrecison = strFormat;
            }

            strPrecValue = parseFloat(strOrgValue).toFixed(parseInt(strPrecison));
        }
        return strPrecValue;
    }

    public static getDateTimePart(_strDT) {
        if (this.Trim(_strDT) != '') {
            if (_strDT.indexOf(' ') == -1)
                return _strDT;
            else {
                _strDT = _strDT.split(' ');
                if (_strDT.length == 2) {
                    if (parseFloat(_strDT[1]) == 0)
                        return '';
                    else {
                        let str1 = this.Trim(_strDT[1]).substr(0, 2);
                        let str2 = this.Trim(_strDT[1]).substr(2, 2);
                        let str3 = this.Trim(_strDT[1]).substr(4, 2);

                        return str1 + ':' + str2 + ':' + str3 + ' ' + _strDT[0];
                    }
                }
                else
                    return '';
            }
        }
    };

    public static getErrorMessage(sErrMsg) {
        let iIndex, sReturnMsg;
        iIndex = sErrMsg.indexOf('=');
        sReturnMsg = sErrMsg.substr(iIndex + 1);
        return sReturnMsg.replaceAllChar("@^", "=");
    };

    public static getErrorMsg(strData) {
        let sReturnMsg = '';
        let iIndex = strData.indexOf('=');
        sReturnMsg = strData.substring(iIndex + 1);

        // This case was written just to test CR 3688 as NCDEX COMDTY broadcast was not available
        //if (sReturnMsg.indexOf('NSE') > -1)
        //    sReturnMsg = "LTP for NCDEX FUT COMDTY CHANACOM 01JAN2025 is greater than equal to UseValue, LTP = 1532.00 UseValue = 2.50@8@3001@8@500410@1114261922@250@DFH";

        // CR 3688
        if (sReturnMsg.indexOf(' COMDTY ') > -1) {
            sReturnMsg = sReturnMsg.replace(' FUT ', ' ');
            sReturnMsg = sReturnMsg.replace(' 01JAN2025 ', ' ');
        }
        return sReturnMsg;
    };

    public static setBuySell(_sBuySell) {
        try {
            let _iBuySell;
            if (_sBuySell == clsConstants.C_S_ORDER_BUY_TEXT)
                _iBuySell = clsConstants.C_V_ORDER_BUY;
            else if (_sBuySell == clsConstants.C_S_ORDER_SELL_TEXT)
                _iBuySell = clsConstants.C_V_ORDER_SELL;

            return _iBuySell;
        }
        catch (e) {

        }
    }

    /// <summary>
    /// </summary>
    // <returns></returns>
    public static calculateFinalPrice(_dblPrice, _intDecimalLocator) {
        let _dblDecimalLocator = 0;
        let _dblPriceinPaise = 0;

        try {
            if (_intDecimalLocator == '' || _intDecimalLocator == 'undefined')
                _dblDecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
            else
                _dblDecimalLocator = _intDecimalLocator;

            if (_dblPrice == 'undefined' || parseFloat(_dblPrice) == 0)
                _dblPrice = 0;

            _dblPriceinPaise = parseInt((_dblPrice * _dblDecimalLocator).toFixed(0));
        }
        catch (e) {

        }
        return _dblPriceinPaise;
    }

    /// <summary>
    /// </summary>
    // <returns></returns>
    public static calculateFinalProtPerc(_dblProtPerc) {
        var _dblProtPercinPaise = 0;

        try {
            if (_dblProtPerc == '' || _dblProtPerc == 'undefined')
                _dblProtPerc = 0;

            _dblProtPercinPaise = parseInt((_dblProtPerc * 100).toFixed(0));
        }
        catch (e) {

        }

        return _dblProtPercinPaise;
    };

    // Function to return Instrument text on passing InstrumentID
    public static getInstrumentName(sInstrumentName) {
        let sInstName;
        // For EQUITIES, Instrument Id passed is blank, hence mapped it to EQ
        if (sInstrumentName == "")
            sInstName = clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT;
        else
            sInstName = sInstrumentName;

        return sInstName;
    };

    // Formatting the Order Type
    public static getOrderType(sOrderType, sExchangeName) {
        let sFormatOrderType;
        if (sOrderType == clsConstants.C_V_ORDER_REGULARLOT) {
            sFormatOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
        }
        else if (sOrderType == clsConstants.C_V_ORDER_REGULARLOT_MARKET) {
            sFormatOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
        }
        else if (sOrderType == clsConstants.C_V_ORDER_STOPLOSS) {
            sFormatOrderType = clsConstants.C_S_ORDER_STOPLOSS_TEXT;
        }
        else if (sOrderType == clsConstants.C_V_ORDER_STOPLOSS_MARKET) {
            sFormatOrderType = clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT;
        }
        else if (sOrderType == clsConstants.C_V_ORDER_CALLAUCTION) {

            if (sExchangeName == clsConstants.C_S_NSEL_EXCHANGE_TEXT || sExchangeName == clsConstants.C_S_MCX_EXCHANGE_TEXT)
                sFormatOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
            else
                sFormatOrderType = clsConstants.C_S_ORDER_CALLAUCTION_TEXT;
        }
        // Case of MCXSX SPOS, in this case order type will be received as 12, but still order has to be displayed as Regular Order....
        else if (sOrderType == clsConstants.C_V_ORDER_MCXSXEQ_CALLAUCTION) {
            if (sExchangeName == clsConstants.C_S_MSX_EXCHANGE_TEXT)
                sFormatOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
        }
        return sFormatOrderType;
    };

    // For converting the Rs to Paise...
    public static ConvertToRsDL(strPrice, strPrecision, strMktSegId): any {
        let strOutput = "0";
        try {
            if (this.Trim(strPrice) == "") return "0.00";

            if (this.Trim(strPrecision) == "") {
                strPrecision = "100";
            }
            var iPrecision = parseInt(strPrecision);
            strOutput = (parseInt(strPrice) / iPrecision).toFixed(this.getPriceFormatter(strPrecision.toString(), strMktSegId));
        }
        catch (e) {

        }
        return strOutput;
    }

    // Function to return Product Type Text text on passing Product Type value
    public static getProductType(sProductType, sMktSegId) {
        let sMessage = "";
        // to do
        //var sManagerVersion = this.WWclsuser.ManagerVersion;
        //TODO:
        let sManagerVersion = clsGlobal.User.managerVersion;

        if (sProductType == clsConstants.C_S_PRODUCTTYPE_MARGIN_VALUE) {
            if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH)
                sMessage += " " + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT; //+ " ProductType";
            else {
                if (sManagerVersion == clsConstants.C_S_MANAGER_VER_9105_PLUS || sManagerVersion == clsConstants.C_S_MANAGER_VER_9105_INTEGRATED ||
                    sManagerVersion == clsConstants.C_S_MANAGER_VER_10000 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10003 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10004 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10005) {
                    if (sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES) {
                        sMessage += " " + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT;// + " ProductType";
                    }
                    else if (sMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                        sMessage += " " + clsConstants.C_S_PRODUCTTYPE_OFS_TXT;// + " ProductType";
                    }
                    else {
                        sMessage += " " + clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;// + " ProductType";
                    }
                }
                else
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT;// + " ProductType";
            }
        }
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_DELIVERY_VALUE) {
            if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH || sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES)
                sMessage += " " + clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;// + " ProductType";
            else {
                if (sManagerVersion == clsConstants.C_S_MANAGER_VER_9105_PLUS || sManagerVersion == clsConstants.C_S_MANAGER_VER_9105_INTEGRATED || sManagerVersion == clsConstants.C_S_MANAGER_VER_10000 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10003 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10004 || sManagerVersion == clsConstants.C_S_MANAGER_VER_10005) {
                    if (sMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                        sMessage += " " + clsConstants.C_S_PRODUCTTYPE_OFS_TXT;// + " ProductType";
                    }
                    else {
                        sMessage += " " + clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT;// + " ProductType";
                    }
                }
                else
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;// + " ProductType";
            }
        }
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE)                 //case AMO
        {
            if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH)
                sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT;// + " ProductType";
            else {
                if (sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES) {
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT;// + " ProductType";
                }
                else {
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT;// + " ProductType";
                }
            }
        }
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE)               //case AMO
        {
            if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH)
                sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT;// + " ProductType";
            else {
                if (sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES) {
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT;// + " ProductType";
                }
                else {
                    sMessage += " " + clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT;
                }
            }
        }
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_MTF_VALUE)
            sMessage += " " + clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;// + " ProductType";
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE)
            sMessage += " " + clsConstants.C_S_PRODUCTTYPE_MP_TEXT;// + " ProductType";
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_PTST_VALUE)
            sMessage += " " + clsConstants.C_S_PRODUCTTYPE_PTST_TEXT;// + " ProductType";
        else if (sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE)
            sMessage += " " + clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;// + " ProductType";
        return sMessage;
    };

    // Formatting the initial data to be appended to the Online message depending upon type of response
    public static getRequestType(sRequestType, sMsgCode) {
        var sMessage;
        sMessage = "Order ";
        if (sRequestType == clsConstants.C_V_ORDER_REQUEST_ENTRY)
            sMessage = "New " + sMessage;
        else if (sRequestType == clsConstants.C_V_ORDER_REQUEST_MODIFY)
            sMessage = "Modify " + sMessage;
        else if (sRequestType == clsConstants.C_V_ORDER_REQUEST_CANCEL)
            sMessage = "Cancel " + sMessage;
        if (sMsgCode == clsConstants.C_V_MSGCODES_ORDER_ACKNOWLEDGEMENT)
            sMessage = sMessage + "Ack. ";
        else
            sMessage = sMessage + "Resp. ";
        return sMessage;
    };

    public static getProductTypeValue(productType) {
        productType = productType.trim();
        var strProdType = "";
        switch (productType) {
            case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_MARGIN_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_MTF_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_MTF_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_MP_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_PTST_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_PTST_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE;
                break;
        }
        return strProdType;
    }

    public static ConvertFromMappedSegmentIdToNormal(iMappedSegmentId) {
        try {
            switch (iMappedSegmentId) {
                case clsConstants.C_V_MAPPED_NSE_CASH:
                    return clsConstants.C_V_NSE_CASH;
                case clsConstants.C_V_MAPPED_NSE_DERIVATIVES:
                    return clsConstants.C_V_NSE_DERIVATIVES;
                case clsConstants.C_V_MAPPED_BSE_CASH:
                    return clsConstants.C_V_BSE_CASH;
                case clsConstants.C_V_MAPPED_BSE_DERIVATIVES:
                    return clsConstants.C_V_BSE_DERIVATIVES;
                case clsConstants.C_V_MAPPED_MCX_DERIVATIVES:
                    return clsConstants.C_V_MCX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_MCX_SPOT:
                    return clsConstants.C_V_MCX_SPOT;
                case clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES:
                    return clsConstants.C_V_NCDEX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_NCDEX_SPOT:
                    return clsConstants.C_V_NCDEX_SPOT;
                case clsConstants.C_V_MAPPED_NSEL_DERIVATIVES:
                    return clsConstants.C_V_NSEL_DERIVATIVES;
                case clsConstants.C_V_MAPPED_NSEL_SPOT:
                    return clsConstants.C_V_NSEL_SPOT;
                case clsConstants.C_V_MAPPED_MSX_DERIVATIVES:
                    return clsConstants.C_V_MSX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_MSX_SPOT:
                    return clsConstants.C_V_MSX_SPOT;
                case clsConstants.C_V_MAPPED_MSX_CASH:
                    return clsConstants.C_V_MSX_CASH;
                case clsConstants.C_V_MAPPED_MSX_FAO:
                    return clsConstants.C_V_MSX_FAO;
                case clsConstants.C_V_MAPPED_DSE_CASH:
                    return clsConstants.C_V_DSE_CASH;
                case clsConstants.C_V_MAPPED_NMCE_DERIVATIVES:
                    return clsConstants.C_V_NMCE_DERIVATIVES;
                case clsConstants.C_V_MAPPED_NSX_DERIVATIVES:
                    return clsConstants.C_V_NSX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_NSX_SPOT:
                    return clsConstants.C_V_NSX_SPOT;
                case clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES:
                    return clsConstants.C_V_BSECDX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_BSECDX_SPOT:
                    return clsConstants.C_V_BSECDX_SPOT;
                case clsConstants.C_V_MAPPED_UCX_DERIVATIVES:
                    return clsConstants.C_V_UCX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_UCX_SPOT:
                    return clsConstants.C_V_UCX_SPOT;
                case clsConstants.C_V_MAPPED_DGCX_DERIVATIVES:
                    return clsConstants.C_V_DGCX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_DGCX_SPOT:
                    return clsConstants.C_V_DGCX_SPOT;
                case clsConstants.C_V_MAPPED_BFX_DERIVATIVES:
                    return clsConstants.C_V_BFX_DERIVATIVES;
                case clsConstants.C_V_MAPPED_BFX_SPOT:
                    return clsConstants.C_V_BFX_SPOT;
                case clsConstants.C_V_MAPPED_OFS_IPO_BONDS:
                    return clsConstants.C_V_OFS_IPO_BONDS;
                case clsConstants.C_V_MAPPED_ADX_CASH:
                    return clsConstants.C_V_ADX_CASH;
                case clsConstants.C_V_MAPPED_DFM_CASH:
                    return clsConstants.C_V_DFM_CASH;
                default:
                    return clsConstants.C_V_MAPPED_NSE_CASH;
            }
        }
        catch (Exception) {
            return clsConstants.C_V_MAPPED_NSE_CASH;
        }
    }


    //MTM CALCULATION FOR NETPOSITION
    public static CalculateMTM(dblSellVal, dblNetQty, dblLTP, dblRegLot, dblGenNum, dblGenDen, dblPriceNum, dblPriceDen, dblBuyValue, intMktSegID, dblRefRate) {
        var dblMTMValue = 0;
        intMktSegID = clsTradingMethods.ConvertFromMappedSegmentIdToNormal(intMktSegID);
        if (isNaN(dblLTP))
            dblLTP = 0;
        if (dblLTP == 0) {
            dblMTMValue = 0;
        }
        else if (intMktSegID == clsConstants.C_V_MCX_DERIVATIVES || intMktSegID == clsConstants.C_V_NSEL_DERIVATIVES || intMktSegID == clsConstants.C_V_MSX_DERIVATIVES
            || intMktSegID == clsConstants.C_V_NSX_DERIVATIVES || intMktSegID == clsConstants.C_V_DGCX_DERIVATIVES || intMktSegID == clsConstants.C_V_BFX_DERIVATIVES || intMktSegID == clsConstants.C_V_UCX_DERIVATIVES
            || intMktSegID == clsConstants.C_V_MSX_FAO || intMktSegID == clsConstants.C_V_BSECDX_DERIVATIVES) {
            if (isNaN(dblRefRate) || dblRefRate == null || dblRefRate == undefined)
                dblMTMValue = (dblSellVal + (dblNetQty * dblLTP * dblRegLot * (dblGenNum / dblGenDen) * (dblPriceNum / dblPriceDen))) - dblBuyValue;
            else
                dblMTMValue = (dblSellVal + (dblNetQty * (dblLTP * (dblRefRate / 10000000)) * dblRegLot * (dblGenNum / dblGenDen) * (dblPriceNum / dblPriceDen))) - dblBuyValue;
        }
        else if (intMktSegID == clsConstants.C_V_NSE_DERIVATIVES || intMktSegID == clsConstants.C_V_BSE_DERIVATIVES) {
            dblMTMValue = (dblSellVal + (dblNetQty * dblLTP)) - dblBuyValue;
        }
        else if (intMktSegID == clsConstants.C_V_NCDEX_DERIVATIVES || intMktSegID == clsConstants.C_V_NMCE_DERIVATIVES) {
            dblMTMValue = (dblSellVal - dblBuyValue) + ((dblNetQty * dblLTP) * (dblPriceNum / dblPriceDen));
        }
        else {
            dblMTMValue = (dblSellVal + (dblNetQty * dblLTP)) - dblBuyValue;
        }


        return parseFloat(dblMTMValue.toFixed(2));
    };


    public static getBUYSELLColor(_iBuySellid) {
        var strBuySellCSS = '';

        if (_iBuySellid == clsConstants.C_V_ORDER_BUY) {
            strBuySellCSS = 'buy-color'
        }
        else {
            strBuySellCSS = 'sell-color'
        }

        return strBuySellCSS;
    }

    public static getLegIndicatorText(sProductType, sLegIndicator) {
        let sLegIndicatorText = "";
        if (sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
            switch (sLegIndicator) {
                case clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR.toString():
                    sLegIndicatorText = ' MAIN LEG';
                    break;
                case clsConstants.C_V_BRACKET_SL_LEG_INDICATOR.toString():
                    sLegIndicatorText = ' SL LEG';
                    break;
                case clsConstants.C_V_BRACKET_PROFIT_LEG_INDICATOR.toString():
                    sLegIndicatorText = ' PROFIT LEG';
                    break;
                case clsConstants.C_V_BRACKET_SL_RESV_LEG_INDICATOR.toString():
                    sLegIndicatorText = '  SL LEG';
                    break;
                case clsConstants.C_V_BRACKET_PROFIT_RESV_LEG_INDICATOR.toString():
                    sLegIndicatorText = ' PROFIT LEG';
                    break;
                case clsConstants.C_V_BRACKET_PARTIAL_PROFIT_LEG_INDICATOR.toString():
                    sLegIndicatorText = '  Square Off LEG';
                    break;
                default:
                    sLegIndicatorText = '';
                    break;
            }
        }

        return sLegIndicatorText;
    }

    // Formatting the Scrip Desc
    public static getScripDesc(sMktSegId, sExchangeName, sInstrumentName, sSymbol, sSeries, sExpiryDate, sStrikePrice, sOptionType, sToken) {
        let sScripDesc;
        //For  EQ	segments
        if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH ||
            sMktSegId == clsConstants.C_V_OFS_IPO_BONDS)
            sScripDesc = sExchangeName + " " + sInstrumentName + " " + sToken + " " + sSymbol + " " + sSeries;

        //For NSE DERV
        else if (sMktSegId == clsConstants.C_V_NSE_DERIVATIVES || sMktSegId == clsConstants.C_V_MSX_FAO) {
            if (sInstrumentName == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT || sInstrumentName == clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT || sInstrumentName == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT)
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate;
            else
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate + " " + sStrikePrice + " " + sOptionType;
        }

        // For BSE EQ
        else if (sMktSegId == clsConstants.C_V_BSE_CASH)
            sScripDesc = sExchangeName + " " + sInstrumentName + " " + sToken + " " + sSymbol + " " + sSeries;

        // For BSE DERV
        else if (sMktSegId == clsConstants.C_V_BSE_DERIVATIVES) {
            if (sInstrumentName == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT || sInstrumentName == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT)
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate;
            else
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate + " " + sStrikePrice + " " + sOptionType;
        }

        // For MCX, NCDEX, MCXSX, NSX
        else if (sMktSegId == clsConstants.C_V_MCX_DERIVATIVES || sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BFX_DERIVATIVES
            || sMktSegId == clsConstants.C_V_NCDEX_DERIVATIVES || sMktSegId == clsConstants.C_V_MSX_DERIVATIVES || sMktSegId == clsConstants.C_V_NSX_DERIVATIVES
            || sMktSegId == clsConstants.C_V_NMCE_DERIVATIVES || sMktSegId == clsConstants.C_V_UCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES) {

            if ((sMktSegId == clsConstants.C_V_MSX_DERIVATIVES || sMktSegId == clsConstants.C_V_NSX_DERIVATIVES || sMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES)
                && sInstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate + " " + sStrikePrice + " " + sOptionType;

            else if ((sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BFX_DERIVATIVES || sMktSegId == clsConstants.C_V_UCX_DERIVATIVES || sMktSegId == clsConstants.C_V_MCX_DERIVATIVES || sMktSegId == clsConstants.C_V_NCDEX_DERIVATIVES)
                && (sInstrumentName == clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT || sInstrumentName == clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT))
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate + " " + sStrikePrice + " " + sOptionType;

            else if (sMktSegId == clsConstants.C_V_MCX_DERIVATIVES && (this.Trim(sInstrumentName) == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT ||
                this.Trim(sInstrumentName) == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || this.Trim(sInstrumentName) == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT
                || this.Trim(sInstrumentName) == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT) || (this.Trim(sInstrumentName) == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)) {
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " ";
            }
            else
                sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol + " " + sExpiryDate;
        }

        // For NSEL
        else if (sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES)				//case for NSEL
            sScripDesc = sExchangeName + " " + sInstrumentName + " " + sSymbol;
        else if (sMktSegId == "" || sMktSegId == "undefined" || sMktSegId == "null")
            sScripDesc = "";

        return sScripDesc;
    };

    // For Getting the Validaity Text
    // Getting Validity name depending upon exchange and Validity value passed
    public static getValdDesc(sExchangeID, sValidity) {
        let sValidityDesc = "";

        if (sExchangeID == clsConstants.C_V_NSE_CASH || sExchangeID == clsConstants.C_V_MSX_CASH || sExchangeID == clsConstants.C_V_OFS_IPO_BONDS) {
            if (sValidity == clsConstants.C_V_ORDER_VALID_TILL_DAY)
                sValidityDesc = clsConstants.C_S_VALUE_DAY;
            else if (sValidity == clsConstants.C_V_ORDER_GTD)
                sValidityDesc = clsConstants.C_S_VALUE_GTD;
            else if (sValidity == clsConstants.C_V_ORDER_GTC)
                sValidityDesc = clsConstants.C_S_VALUE_GTC;
            else if (sValidity == clsConstants.C_V_ORDER_IOC)
                sValidityDesc = clsConstants.C_S_VALUE_IOC;
            else if (sValidity == clsConstants.C_V_ORDER_EOS)
                sValidityDesc = clsConstants.C_S_VALUE_EOS;
        }
        else if (sExchangeID == clsConstants.C_V_BSE_CASH) {
            if (sValidity == clsConstants.C_V_ORDER_EOSESS)
                sValidityDesc = clsConstants.C_S_VALUE_EOSESS;
            else if (sValidity == clsConstants.C_V_ORDER_EOTODY)
                sValidityDesc = clsConstants.C_S_VALUE_EOTODY;
            else if (sValidity == clsConstants.C_V_ORDER_EOSTLM)
                sValidityDesc = clsConstants.C_S_VALUE_EOSTLM;
            else if (sValidity == clsConstants.C_V_ORDER_IOC)
                sValidityDesc = clsConstants.C_S_VALUE_IOC;
        }
        else if (sExchangeID == clsConstants.C_V_BSE_DERIVATIVES || sExchangeID == clsConstants.C_V_DGCX_DERIVATIVES ||
            sExchangeID == clsConstants.C_V_BSE_DERIVATIVES || sExchangeID == clsConstants.C_V_UCX_DERIVATIVES) {
            if (sValidity == clsConstants.C_V_ORDER_VALID_TILL_DAY)
                sValidityDesc = clsConstants.C_S_VALUE_DAY;
            else if (sValidity == clsConstants.C_V_ORDER_GTD)
                sValidityDesc = clsConstants.C_S_VALUE_GTD;
            else if (sValidity == clsConstants.C_V_ORDER_GTC)
                sValidityDesc = clsConstants.C_S_VALUE_GTC;
            else if (sValidity == clsConstants.C_V_ORDER_IOC)
                sValidityDesc = clsConstants.C_S_VALUE_IOC;
        }
        else if (sExchangeID == clsConstants.C_V_MCX_DERIVATIVES || sExchangeID == clsConstants.C_V_MSX_DERIVATIVES || sExchangeID == clsConstants.C_V_NSEL_DERIVATIVES
            || sExchangeID == clsConstants.C_V_NSX_DERIVATIVES || sExchangeID == clsConstants.C_V_DSE_CASH || sExchangeID == clsConstants.C_V_MSX_CASH ||
            sExchangeID == clsConstants.C_V_MSX_FAO || sExchangeID == clsConstants.C_V_NMCE_DERIVATIVES || sExchangeID == clsConstants.C_V_BSECDX_DERIVATIVES) {
            if (sValidity == clsConstants.C_V_ORDER_VALID_TILL_DAY)
                sValidityDesc = clsConstants.C_S_VALUE_DAY;
            else if (sValidity == clsConstants.C_V_ORDER_GTD)
                sValidityDesc = clsConstants.C_S_VALUE_GTD;
            else if (sValidity == clsConstants.C_V_ORDER_GTC)
                sValidityDesc = clsConstants.C_S_VALUE_GTC;
            else if (sValidity == clsConstants.C_V_ORDER_IOC)
                sValidityDesc = clsConstants.C_S_VALUE_IOC;
            else if (sValidity == clsConstants.C_V_ORDER_EOS)
                sValidityDesc = clsConstants.C_S_VALUE_EOS;
            else if (sValidity == clsConstants.C_V_ORDER_FOK)
                sValidityDesc = clsConstants.C_S_VALUE_FOK;
        }
        else {
            if (sValidity == clsConstants.C_V_ORDER_VALID_TILL_DAY)
                sValidityDesc = clsConstants.C_S_VALUE_DAY;
            else if (sValidity == clsConstants.C_V_ORDER_GTD)
                sValidityDesc = clsConstants.C_S_VALUE_GTD;
            else if (sValidity == clsConstants.C_V_ORDER_GTC)
                sValidityDesc = clsConstants.C_S_VALUE_GTC;
            else if (sValidity == clsConstants.C_V_ORDER_IOC)
                sValidityDesc = clsConstants.C_S_VALUE_IOC;
        }
        return sValidityDesc;
    }

    public static formReqType(sMsgCode, sOrderStatus, sErrorMsg) {
        var sMessage = "";
        if (sMsgCode == "123")
            sMessage = sErrorMsg;
        else if (sMsgCode == "122") {
            sMessage += " " + this.getOrderStatus(sOrderStatus);
            sMessage += sErrorMsg;
        }
        else {
            sMessage += " " + this.getOrderStatus(sOrderStatus);
            sMessage += sErrorMsg;
        }
        return sMessage;
    };

    //Function to return OrderStatus
    public static getOrderStatus(sOrderStatus) {
        let sReturnStatus;

        if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_OMSXMITTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_OMSXMITTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_EXCHANGEXMITTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_EXCHANGEXMITTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_PENDING)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_PENDING_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_CANCELLED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_CANCEL_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_EXECUTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_EXECUTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ADMINPENDING)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ADMINPENDING_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_OMSREJECT)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_OMSREJECT_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ORDERERROR)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ORDERERROR_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_FROZEN)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_FROZEN_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_MINIADMINPENDING)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_MINIADMINPENDING_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ADMINACCEPT)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ADMINACCEPT_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ADMINREJECT)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ADMINREJECT_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ADMINMODIFY)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ADMINMODIFY_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_ADMINCANCEL)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_ADMINCANCEL_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_AMOSUBMITTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_AMOSUBMITTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_AMOCANCELLED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_AMOCANCELLED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_DEVICEXMITTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_DEVICEXMITTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_GATEWAYXMITTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_GATEWAYXMITTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_GATEWAYREJECT)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_GATEWAYREJECT_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_BOCOMPLETED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_BOCOMPLETED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_BOSTOPPED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_BOSTOPPED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_BOCONVERTED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_BOCONVERTED_TEXT;
        else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_NOT_INITIATED)
            sReturnStatus = clsConstants.C_S_ORDERSTATUS_NOTINITIATED_TEXT;

        return sReturnStatus + " ";
    };

    public static getChangeInRs(LTP, ClosePrice, nFormat, isMktWatch, arrowType?: any) {
        let arrChnageData = [];
        if (LTP != '' && ClosePrice != '') {
            let NetChgRs = parseFloat(LTP) - parseFloat(ClosePrice);
            let NetChangeInRs = NetChgRs.toFixed(nFormat);
            let PercNetChng = parseFloat(ClosePrice) != 0 ? (parseFloat(NetChangeInRs) / parseFloat(ClosePrice)) * 100 : 0;
            let PercNetChange = PercNetChng.toFixed(2);
            let LTPTrend = '', trendArrow = '';

            // LTPTrend = ""; trendArrow = "no-icon";
            // if (parseFloat(NetChangeInRs) > 0) {
            //     LTPTrend = "+"; 
            //     trendArrow = (arrowType == 'arrow' ? 'up-arrow' : (arrowType == 'icon') ? 'up-icon' : (arrowType == 'arrowround') ? "arrow-round-up" : "uptrend-icon");
            // }
            // else if (parseFloat(NetChangeInRs) < 0) {
            //     LTPTrend = "-"; 
            //     trendArrow = (arrowType == 'arrow' ? 'down-arrow' : (arrowType == 'icon') ? 'down-icon' : (arrowType == 'arrowround') ? "arrow-round-down" : "downtrend-icon");
            // }
            // else {
            //     LTPTrend = ""; 
            //     trendArrow = (arrowType == 'arrow' ? 'no-change-icon' : (arrowType == 'icon') ? 'no-change-icon' : (arrowType == 'arrowround') ? "no-change-icon" : "notrend-icon");
            // }

            if (parseFloat(NetChangeInRs) > 0) {
                arrChnageData.push('+' + Math.abs(parseFloat(NetChangeInRs)).toFixed(nFormat));
                arrChnageData.push("(+" + Math.abs(parseFloat(PercNetChange)).toFixed(2) + "%)");
                ///arrChnageData.push("+" + Math.abs(parseFloat(PercNetChange)).toFixed(2));
                LTPTrend = "color-positive";
            }
            else if (parseFloat(NetChangeInRs) < 0) {
                arrChnageData.push('-' + Math.abs(parseFloat(NetChangeInRs)).toFixed(nFormat));
                arrChnageData.push("(-" + Math.abs(parseFloat(PercNetChange)).toFixed(2) + "%)");
                //arrChnageData.push("-" + Math.abs(parseFloat(PercNetChange)).toFixed(2));
                LTPTrend = "color-negative";
            } else {
                arrChnageData.push(Math.abs(parseFloat(NetChangeInRs)).toFixed(nFormat));
                //arrChnageData.push("(" + Math.abs(parseFloat(PercNetChange)).toFixed(2) + "%)");
                arrChnageData.push("(" + Math.abs(parseFloat(PercNetChange)).toFixed(2) + ")" );
                LTPTrend = "";
            }

            //arrChnageData.push(Math.abs(parseFloat(NetChangeInRs)).toFixed(nFormat));
            //arrChnageData.push(Math.abs(parseFloat(PercNetChange)).toFixed(2));
            arrChnageData.push(LTPTrend);
            arrChnageData.push(parseFloat(PercNetChange));

            if (isMktWatch != undefined && isMktWatch)
                arrChnageData.push(PercNetChange);

        } else {
            let zeroVal = 0;
            arrChnageData.push(zeroVal.toFixed(nFormat));
            arrChnageData.push('(0.00)');
            arrChnageData.push('');
            if (isMktWatch != undefined && isMktWatch)
                arrChnageData.push('0.00');
        }


        return arrChnageData;
    }

    public static getLTPTrendCss(LTP, ClosePrice) {
        let NetChgRs = parseFloat(LTP) - parseFloat(ClosePrice);
        if (NetChgRs == 0) {
            return '';
        }
        else if (NetChgRs > 0) {
            return "buy";
        }
        else if (NetChgRs < 0) {
            return "sell";
        }
    }

    public static getLTPArrowTrendCss(LTP, ClosePrice) {
        let NetChgRs = parseFloat(LTP) - parseFloat(ClosePrice);
        if (NetChgRs == 0) {
            return '';
        }
        else if (NetChgRs > 0) {
            return "up-arrow";
        }
        else if (NetChgRs < 0) {
            return "down-arrow";
        }
    }

    public static AddOCDiffToOCTime(Fhms) {
        this.fn_split(Fhms, ':');

        let TimeinSec;
        for (let i = this.splitIndex - 1, j = 1, TimeinSec = 0; i >= 0; i = i - 1, j = j * 60) {
            TimeinSec += this.splitArray[i] * j - 0;
        }
        //TODO:
        // if (WWclsUser.ServerDiff.length == 0)
        //     WWclsUser.ServerDiff = '0';
        let diff = 0;//WWclsUser.ServerDiff;
        let TotalSec = eval(TimeinSec.toString()) + eval(diff.toString());
        let hms = this.fn_hms2(TotalSec);
        return hms
    }

    public static fn_splits(string, text) {
        // splits string at text
        var strLength = string.length, txtLength = text.length;
        if ((strLength == 0) || (txtLength == 0)) return;

        var i = string.indexOf(text);
        if ((!i) && (text != string.substring(0, txtLength))) return;
        if (i == -1) {
            this.splitArray[this.splitIndex++] = string;
            return;
        }

        this.splitArray[this.splitIndex++] = string.substring(0, i);

        if (i + txtLength < strLength)
            this.fn_splits(string.substring(i + txtLength, strLength), text);

        return;
    }

    public static splitIndex: any = 0;
    public static splitArray: any = [];
    public static fn_split(string, text) {
        this.splitIndex = 0;
        this.fn_splits(string, text);
    }

    public static fn_hms2(secs) {
        secs = secs % 86400;
        // to do
        var t: any;
        t = new Date(1970, 0, 1);
        t.setSeconds(secs);
        var s: any;
        s = t.toTimeString().substr(0, 8);
        if (secs > 86399)
            s = Math.floor((t - Date.parse("1/1/70")) / 3600000) + s.substr(2);
        return s;
    }

    public static Trim(objTxtValue): string {
        return objTxtValue.toString().split(" ").join("");
    }

    public static priceOutOfRangeMsg(caption): any {
        return clsGlobal.dMsgMaster.getItem("NNSL360").replace('{0}', caption);
    }

    public static priceNotInPriceTickMsg(caption, priceTick, bIncludePaisaText): any {
        if (bIncludePaisaText)
            return clsGlobal.dMsgMaster.getItem("NNSL359").replace('{0}', caption) + priceTick + clsGlobal.dMsgMaster.getItem("NNSL63");
        else
            return clsGlobal.dMsgMaster.getItem("NNSL359").replace('{0}', caption) + priceTick;
    }

    public static priceNotInDecDigitsMsg(caption, digits): any {
        return clsGlobal.dMsgMaster.getItem("NNSL358").replace('{0}', caption).replace('{1}', digits);
    }

    public static PriceCanNotBeZeroMsg(caption): any {
        return clsGlobal.dMsgMaster.getItem("NNSL357").replace('{0}', caption);
    }

    public static MPNotAllowedMsg(prodType): any {
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
            return clsGlobal.dMsgMaster.getItem("NNSL372").replace('{0}', clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
        else {
            return clsGlobal.dMsgMaster.getItem("NNSL220").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
    }

    public static MPNotAllowedForValidityMsg(prodType): any {
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
            return clsGlobal.dMsgMaster.getItem("NNSL371").replace('{0}', clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
        else if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
            return clsGlobal.dMsgMaster.getItem("NNSL218").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
        else
            return clsGlobal.dMsgMaster.getItem("NNSL218");
    }

    public static MPNotAllowedForLTPMsg(prodType, price): any {
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
            if (price == 0)
                return clsGlobal.dMsgMaster.getItem("NNSL370").replace('{0}', clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
            else
                return clsGlobal.dMsgMaster.getItem("NNSL374").replace('{0}', clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
        }
        else if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
            return clsGlobal.dMsgMaster.getItem("NNSL215").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
        else
            return clsGlobal.dMsgMaster.getItem("NNSL215");
    }

    public static MPNotAllowedForUnderlyingLTPMsg(prodType): any {
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
            return clsGlobal.dMsgMaster.getItem("NNSL373").replace('{0}', clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
        else if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
            return clsGlobal.dMsgMaster.getItem("NNSL219").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
        else
            return clsGlobal.dMsgMaster.getItem("NNSL219");
    }

    public static priceCanNotBeNegativeMsg(caption): any {
        return clsGlobal.dMsgMaster.getItem("NNSL362").replace('{0}', caption);
    }

    public static priceGreaterInt32MaxMsg(caption, decimalLocator, priceFormatter): any {
        return caption + " should be less than " + (parseFloat(clsConstants.C_V_Int32_MAXVALUE.toString()) / decimalLocator).toFixed(priceFormatter)
    }

    /// To get the Price format as per the Decimal Locator, MktSegId, InstName using DecimalLocator, MktSegId, InstName
    public static GetPriceFormatter(strDecimalLocator, intMktSegId, strInstName): any {
        try {
            if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT || intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
                intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLocator.trim() == "0")
                    strDecimalLocator = "100";

                if (strDecimalLocator == "0")
                    strDecimalLocator = "10000";

                if ((intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT || intMktSegId == clsConstants.C_V_NSX_SPOT) && strInstName == clsConstants.C_S_INSTRUMENT_INDEX_TEXT)
                    strDecimalLocator = "100";

                if (strDecimalLocator === ("100"))
                    return 2;
                else if (strDecimalLocator === ("10000") || strDecimalLocator === (clsConstants.C_V_NSECDS_DECLOC))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT) {
                if (strDecimalLocator === ("1000"))
                    return 3;
                else if (strDecimalLocator === ("10000"))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO) {
                return this.getPriceFormatterFromDecimalLocator(parseInt(strDecimalLocator, 10));
            }
            else {
                return 2;
            }
        }
        catch (e) {
            throw e;


        }
    }

    /// Accepts normal MktSegId and returns ExchangeName
    public static getExchangeNameDesc(intMktSegId): any {
        var strExName = '';

        switch (intMktSegId) {
            case clsConstants.C_V_NSE_CASH:
                strExName = clsConstants.C_S_NSE_EQ_DESC;
                break;
            case clsConstants.C_V_NSE_DERIVATIVES:
                strExName = clsConstants.C_S_NSE_DERV_DESC;
                break;
            case clsConstants.C_V_BSE_CASH:
                strExName = clsConstants.C_S_BSE_EQ_DESC;
                break;
            case clsConstants.C_V_BSE_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_DERV_DESC;
                break;
            case clsConstants.C_V_MCX_DERIVATIVES:
            case clsConstants.C_V_MCX_SPOT:
                strExName = clsConstants.C_S_MCX_FUTURES_DESC;
                break;
            case clsConstants.C_V_NCDEX_DERIVATIVES:
            case clsConstants.C_V_NCDEX_SPOT:
                strExName = clsConstants.C_S_NCDEX_FUTURES_DESC;
                break;
            case clsConstants.C_V_NSEL_DERIVATIVES:
            case clsConstants.C_V_NSEL_SPOT:
                strExName = clsConstants.C_S_NSEL_SPTCOM_DESC;
                break;
            case clsConstants.C_V_MSX_DERIVATIVES:
                strExName = clsConstants.C_S_MCXSX_FUTURES_DESC;
                break;
            case clsConstants.C_V_MSX_CASH:
                strExName = clsConstants.C_S_MCXSX_EQUITIES_DESC;
                break;
            case clsConstants.C_V_MSX_FAO:
                strExName = clsConstants.C_S_MCXSX_FAO_DESC;
                break;
            case clsConstants.C_V_DSE_CASH:
                strExName = clsConstants.C_S_DSE_EQUITIES_DESC;
                break;
            // case clsConstants.C_V_NMCE_DERIVATIVES:
            //     strExName = clsConstants.C_S_NMCE_FUTURES_DESC;
            //     break;
            // added by sonali
            case clsConstants.C_V_BSECOMM_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_COMM_DESC;
                break;

            case clsConstants.C_V_NSX_DERIVATIVES:
            case clsConstants.C_V_NSX_SPOT:
                strExName = clsConstants.C_S_NSX_FUTURES_DESC;
                break;
            case clsConstants.C_V_BSECDX_DERIVATIVES:
            case clsConstants.C_V_BSECDX_SPOT:
                strExName = clsConstants.C_S_BSECDX_FUTURES_DESC;
                break;
            case clsConstants.C_V_UCX_DERIVATIVES:
            case clsConstants.C_V_UCX_SPOT:
                strExName = clsConstants.C_S_UCX_FUTURES_DESC;
                break;
            case clsConstants.C_V_DGCX_DERIVATIVES:
            case clsConstants.C_V_DGCX_SPOT:
                strExName = clsConstants.C_S_DGCX_FUTURES_DESC;
                break;
            case clsConstants.C_V_BFX_DERIVATIVES:
            case clsConstants.C_V_BFX_SPOT:
                strExName = clsConstants.C_S_BFX_FUTURES_DESC;
                break;
            case clsConstants.C_V_OFS_IPO_BONDS:
                strExName = clsConstants.C_S_OTSTXT_EXCHANGE_TEXT;
                break;
            case clsConstants.C_V_ICEX_DERIVATIVES:
                strExName = clsConstants.C_S_ICEX_FUTURES_DESC;
                break;
            case clsConstants.C_V_MSX_FIM:
                strExName = clsConstants.C_S_MSX_FIM_API;
                break;

        }

        return strExName;
    }

    public static convertToDate(seconds, strFormat): any {
        var d1 = new Date("01/01/1980 00:00:00");
        d1.setSeconds(seconds);
        var t = "";
        if (strFormat == undefined || strFormat == null || strFormat == '') {
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'sep', 'Oct', 'Nov', 'Dec'];
            t = this.getFormattedDays(d1.getDate()) + months[d1.getMonth()].toUpperCase() + d1.getFullYear();
            return t;
        }
        else {
            return clsGlobal.dateFormatter.transform(d1, strFormat);
            //return d1.toString();
        }

    }

    public static convertToDateWith1970(seconds, strFormat): any {
        var d1 = new Date("01/01/1970 00:00:00");
        d1.setSeconds(seconds);
        var t = "";
        if (strFormat == undefined || strFormat == null || strFormat == '') {
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'sep', 'Oct', 'Nov', 'Dec'];
            t = this.getFormattedDays(d1.getDate()) + months[d1.getMonth()].toUpperCase() + d1.getFullYear();
            return t;
        }
        else {
            return clsGlobal.dateFormatter.transform(d1, strFormat);
            //return d1.toString();
        }

    }

    public static getFormattedDays(day): any {
        let retDays = '';
        if (day.toString().length < 2) {
            retDays = '0' + day;
        } else {
            retDays = day;
        }
        return retDays;
    }



    public static convertToSeconds(dateToConvert: string): any {
        let dBseDate: any = new Date(1980, 0, 1, 0, 0, 0, 0);

        let day = parseInt(dateToConvert.substr(0, 2));
        let month = parseInt(clsCommonMethods.getNumericMonth(dateToConvert.substr(2, 3)));
        let year = parseInt(dateToConvert.substr(5, 4));

        let dSelDate: any = new Date(year, month, day, 0, 0, 0, 0);

        let diff = Math.abs(Math.floor(dSelDate - dBseDate)) / 1000;
        return diff;

    }

    public static convertToDateTime(dateToConvert: string): any {
        let dSelDate: any;
        if (dateToConvert != undefined && dateToConvert != '') {
            let day = parseInt(dateToConvert.substr(0, 2));
            let month = parseInt(clsCommonMethods.getNumericMonth(dateToConvert.substr(2, 3)));
            let year = parseInt(dateToConvert.substr(5, 4));

            dSelDate = new Date(year, month, day, 0, 0, 0, 0);
        }

        return dSelDate;
    }

    public static checkNonBlankNonZero(strInput): any {
        var bStatus = false;
        try {
            if (strInput.length > 0 && strInput != "0")
                bStatus = true;
        }
        catch (e) {
            bStatus = false;
        }
        return bStatus;
    }

    public static fn_CheckForNonMinusOne(strVerificationString): any {
        var bStatus = false;
        try {
            if (parseFloat(strVerificationString).toFixed(2).toString() == "-1.00")
                bStatus = false;
            else
                bStatus = true;
        }
        catch (e) {
            bStatus = false;
        }
        return bStatus;
    }

    public static formatToPercentage(strUnmodified): any {
        var strModified = "";
        try {
            if (strUnmodified.length > 0)
                strModified = parseFloat(strUnmodified).toFixed(2).toString() + " %";
        }
        catch (e) {
            strModified = "";
        }
        return strModified;
    }

    /// To get the Price format as per the Decimal Locator i.e 0.00 or 0.0000 and MktSegId
    public static getPriceFormatterWithDLAndMksSegID(strDecimalLocator: string, intMktSegId: number): number {
        try {
            if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT
                || intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT
                || intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLocator.trim() == "0")
                    strDecimalLocator = "100";

                if (strDecimalLocator.trim() == "0")
                    strDecimalLocator = "10000";

                if (strDecimalLocator == ("100"))
                    return 2;
                else if (strDecimalLocator == ("10000") || strDecimalLocator == (clsConstants.C_V_NSECDS_DECLOC))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT) {
                if (strDecimalLocator == ("1000"))
                    return 3;
                else if (strDecimalLocator == ("10000"))
                    return 4;
                else
                    return 2;
            }
            else if (intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO) {
                if (strDecimalLocator.trim() == "0")
                    return 2;
                else
                    return this.getPriceFormatterFromDecimalLocator(parseInt(strDecimalLocator, 10));
            }
            else {
                return 2;
            }
        }
        catch (e) {

        }
    }


    ///Function formats the number with thousand separator "," and 2 decimal
    public static formatNumber(num, decCnt) {
        var p = num.toFixed(decCnt).split(".");
        var chars = p[0].split("").reverse();
        var sep1000 = false;
        var newstr = '';
        var count = 0;
        var count2 = 0;
        for (var x = 0; x < chars.length; x++) {
            count++;
            if (count % 3 == 1 && count != 1 && !sep1000) {

                newstr = chars[x] + ',' + newstr;
                sep1000 = true;
            }
            else {
                if (!sep1000) {
                    newstr = chars[x] + newstr;
                }
                else {
                    count2++;
                    if (count2 % 2 === 0 && count2 != 1 && chars[x] != '-') {
                        newstr = chars[x] + ',' + newstr;
                    }
                    else {
                        newstr = chars[x] + newstr;
                    }
                }
            }
        }
        var formatVal = newstr + "." + p[1]
        return formatVal;
    }

    public static roundDown(dblValue, RoundFactor, DecimalLocator): any {
        var dblRoundDown: number;
        dblRoundDown = dblValue - (dblValue % RoundFactor);
        //if (DecimalLocator == "F2")
        //    return Math.round(dblRoundDown);
        //else if (DecimalLocator == "F4")
        //    return Math.round(dblRoundDown);
        //else
        return Math.round(dblRoundDown);
    }

    public static roundNearestPriceTick(dblValue, dblPriceTick): any {
        var RoundFactor = 1 / dblPriceTick;
        return Math.round(dblValue * RoundFactor) / RoundFactor;
    }

    public static getOEFormDetail(opType: number, scripDetl: clsScrip, sPagesource: number, iBuyQty: number, iSellQty: number, iLTP: number, iClosePrice: number, COL: number): clsOEFormDetl {
        try {

            let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
            objOEFormDetail.buySell = opType;
            objOEFormDetail.pageSource = sPagesource;
            objOEFormDetail.scripDetl = scripDetl;
            objOEFormDetail.buyQty = iBuyQty;
            objOEFormDetail.sellQty = iSellQty;
            objOEFormDetail.ltp = iLTP;
            objOEFormDetail.closePrice = iClosePrice;
            objOEFormDetail.COL = COL;

            return objOEFormDetail;

        } catch (error) {
            return null;
        }
    }

    public static formatDisplayDate(sDate, expression, dateFormatter: DatePipe) {
        let _formattedDate;
        try {
            let dateString = sDate;
            let reggie = expression;
            let dateArray = reggie.exec(dateString);
            let dateObject = new Date(
                (+dateArray[1]),
                (+dateArray[2]) - 1, // Careful, month starts at 0!
                (+dateArray[3]),
                (+dateArray[4]),
                (+dateArray[5]),
                (+dateArray[6])
            );
            _formattedDate = dateFormatter.transform(dateObject, "dd/MM/yyyy HH:mm:ss");
        }
        catch (e) {

        }
        return _formattedDate;
    };


    public static getSecurityInfo(_dcSecDetails, _segId) {
        var _ExchName = clsTradingMethods.getExchangeName(parseInt(_segId));
        var _dicSecInfo = _dcSecDetails;
        _dicSecInfo.SecurityName = _dcSecDetails.sSecurityDesc;
        _dicSecInfo.Token = _dcSecDetails.nToken;
        _dicSecInfo.Instrument = _dcSecDetails.nInstrumentType;
        _dicSecInfo.ISIN = _dcSecDetails.sISINCode;
        _dicSecInfo.MarketLot = _dcSecDetails.nRegularLot;
        _dicSecInfo.PriceTick = _dcSecDetails.nPriceTick != "" ? (parseFloat(_dcSecDetails.nPriceTick) / 100).toFixed(2) : "";
        _dicSecInfo.IssuedCapital = clsTradingMethods.formatNumber(parseFloat(_dcSecDetails.nIssuedCapital), 2);

        _dicSecInfo.FaceValue = (parseFloat(_dcSecDetails.nFaceValue) / 100).toFixed(2);
        _dicSecInfo.QtyFreeze = (parseFloat(_dcSecDetails.nFreezePercent) / 100).toFixed(2).toString() + "%";
        _dicSecInfo.Margin = (parseFloat(_dcSecDetails.nMarginMultiplier) / 100).toFixed(2).toString() + "%";
        _dicSecInfo.Multiplier = _dcSecDetails.nIntrinsicValue;

        //Pre Open
        _dicSecInfo.PreOpen = _dcSecDetails.nNormal_SecurityStatus;

        // Special Pre Open
        if (_dcSecDetails.SPOS.toString().trim() == "12" && _dcSecDetails.SPOSTYPE.toString().trim() == "12") {
            _dicSecInfo.SPOS = "Yes";
        }
        else {
            _dicSecInfo.SPOS = "No";
        }

        //if (_ExchName === clsConstants.C_S_NSE_EXCHANGE_TEXT) {//Call Auction available only for NSE
        if (_dcSecDetails.nPriceQuotFactor.toString().trim() == "5" || _dcSecDetails.SPOSTYPE.toString().trim() == "12")
            _dicSecInfo.CallAuction = "YES";
        else
            _dicSecInfo.CallAuction = "No";
        //}
        //else
        //    _dicSecInfo.CallAuction = "";

        if (_dcSecDetails.nBookClosureStartDate.toString() == "0")
            _dicSecInfo.StartDate = "NA";
        else
            _dicSecInfo.StartDate = clsTradingMethods.convertToDate(_dcSecDetails.nBookClosureStartDate, null).toUpperCase();
        if (_dcSecDetails.nBookClosureEndDate.toString() == "0")
            _dicSecInfo.EndDate = "NA";
        else
            _dicSecInfo.EndDate = clsTradingMethods.convertToDate(_dcSecDetails.nBookClosureEndDate, null).toUpperCase();

        if (_ExchName === clsConstants.C_S_NSEL_EXCHANGE_TEXT) {
            _dicSecInfo.StartDate = "";
            _dicSecInfo.EndDate = "";
        }

        if (_dcSecDetails.nExDate.toString() == "0")
            _dicSecInfo.ExDate = "NA";
        else
            _dicSecInfo.ExDate = clsTradingMethods.convertToDate(_dcSecDetails.nExDate, null).toUpperCase();

        if (_segId === clsConstants.C_V_MSX_CASH) {
            _dicSecInfo.Purpose = "";
        }
        else {
            _dicSecInfo.Purpose = _dcSecDetails.sRemarks;
        }

        return _dcSecDetails;
    };

    public static getContractInfo(_dcConInfoDetails, _dcMarginDetails, _segId) {
        var _dicContInfo = _dcConInfoDetails;
        _dicContInfo.ContractName = _dcConInfoDetails.sSecurityDesc;
        _dicContInfo.Token = _dcConInfoDetails.nToken;
        _dicContInfo.ULAsset = _dcConInfoDetails.sAssetName;
        _dicContInfo.MarketLot = _dcConInfoDetails.nRegularLot;
        _dicContInfo.InstrumentName = _dcConInfoDetails.sInstrumentName;

        if (_dcConInfoDetails.nPriceTick != undefined && _dcConInfoDetails.nPriceTick != "") {
            var decLoc = _dcConInfoDetails.nDecimalLocator === "0" ? "100" : _dcConInfoDetails.nDecimalLocator;
            var strPriceFormat = clsTradingMethods.getPriceFormatterWithDLAndMksSegID(decLoc.toString(), _segId);
            _dicContInfo.PriceTick = (parseFloat(_dcConInfoDetails.nPriceTick) / decLoc).toFixed(strPriceFormat); // Prict Tick will be in Paise in Db... so convert to RS is required...
        }
        if (_segId === clsConstants.C_V_NSEL_DERIVATIVES || _segId === clsConstants.C_V_NSEL_SPOT) {
            _dicContInfo.Maturity = "";
        }
        else {
            _dicContInfo.Maturity = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueMaturityDate, null).toUpperCase();
        }

        if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_NSEL_SPOT)
            || (_segId === clsConstants.C_V_MCX_DERIVATIVES && _dicContInfo.InstrumentName.startsWith("AUC"))
            || (_segId === clsConstants.C_V_MSX_FAO)
            || (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)) {
            _dicContInfo.ExDate = "";
        }
        else {
            if (_dcConInfoDetails.nExpiryDate.toString() == "0")
                _dicContInfo.ExDate = "";
            else
                _dicContInfo.ExDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExpiryDate, null).toUpperCase();
        }

        if (_dicContInfo.nStrikePrice == undefined || _dicContInfo.nStrikePrice == "NA" || parseFloat(_dicContInfo.nStrikePrice) <= 0) {
            _dicContInfo.nStrikePrice = '';
        }
        else {
            if (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / 10000).toString();
            else if ((_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT) || (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_MSX_FAO))
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / parseFloat(_dicContInfo.nDecimalLocator)).toFixed(4);
            else if (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / parseFloat(_dicContInfo.nDecimalLocator)).toFixed(4);
            else
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / 100).toString();
        }

        if (_dcConInfoDetails.nPriceQuotFactor.toString() != "0") {
            _dicContInfo.PriceQuote = _dcConInfoDetails.nPriceQuotFactor.toString() + " " + _dcConInfoDetails.sPriceQuotUnit.toString();
        }
        else {
            if (_dcConInfoDetails.sPriceQuotUnit.toString() == "")
                _dicContInfo.PriceQuote = "NA";
            else
                _dicContInfo.PriceQuote = _dcConInfoDetails.sPriceQuotUnit.toString();
        }

        var intMTI = _dcConInfoDetails.nMarginTypeIndicator.toString() != "" ? parseInt(_dcConInfoDetails.nMarginTypeIndicator.toString()) : 0;
        var strMarginMul = _dcConInfoDetails.nMarginMultiplier.toString();
        if (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
            intMTI = 2;
        if (intMTI == 1)
            _dicContInfo.Margin = parseFloat(strMarginMul).toFixed(2) + "%";
        else if (intMTI == 2)
            _dicContInfo.Margin = (parseFloat(strMarginMul) / 100).toFixed(2);
        else
            _dicContInfo.Margin = "NA";

        if (_segId == clsConstants.C_V_NSE_DERIVATIVES ||
            _segId == clsConstants.C_V_BSE_DERIVATIVES) {
            var dblIntVal = _dcConInfoDetails.nIntrinsicValue.toString() != "" ? parseFloat(_dcConInfoDetails.nIntrinsicValue.toString()) / 10000 : 0;
            _dicContInfo.ExMultiplier = dblIntVal.toFixed(2);
        }
        else {
            _dicContInfo.ExMultiplier = _dcConInfoDetails.nIntrinsicValue.toString();
        }

        //IP date
        if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)
            || (_segId == clsConstants.C_V_NSEL_SPOT)
            || (_segId == clsConstants.C_V_MSX_DERIVATIVES)
            || (_segId == clsConstants.C_V_NMCE_DERIVATIVES)
            || (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
            _dicContInfo.IPDate = "NA";
        else if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
            _dicContInfo.IPDate = " ";
        else if ((_segId == clsConstants.C_V_DGCX_DERIVATIVES) || (_segId == clsConstants.C_V_BFX_DERIVATIVES) || (_segId == clsConstants.C_V_UCX_DERIVATIVES)
            || (_segId == clsConstants.C_V_DGCX_SPOT) || (_segId == clsConstants.C_V_BFX_SPOT) || (_segId == clsConstants.C_V_UCX_SPOT))
            _dicContInfo.IPDate = 'NA';
        else {
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssuePDate.toString())) {
                _dicContInfo.IPDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssuePDate, null).toUpperCase(); //clsTradingMethods.convertToDate_dcConInfoDetails.nIssuePDate).toUpperCase();
            }
            else {
                _dicContInfo.IPDate = "NA";
            }
        }

        if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssueStartDate.toString()) && _segId != clsConstants.C_V_BSE_DERIVATIVES) {
            //_dicContInfo.ContractStartDate = TradingclsTradingMethods.ConvertToDate(_dcConInfoDetails.nIssueStartDate, "ddmmmyyyy HH:MM:ss").toUpperCase();
            _dicContInfo.ContractStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueStartDate, 'ddMMMyyyy HH:mm:ss').toUpperCase();
        }
        else {
            _dicContInfo.ContractStartDate = "NA";
        }
        try {
            // Contract End Date ...
            if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)
                || (_segId == clsConstants.C_V_NSEL_SPOT)
                || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT))
                || (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.ContractEndDate = "";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssueMaturityDate.toString()))
                //_dicContInfo.ContractEndDate = TradingclsTradingMethods.ConvertToDate(_dcConInfoDetails.nIssueMaturityDate, "ddmmmyyyy HH:MM:ss").toUpperCase();
                _dicContInfo.ContractEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueMaturityDate, 'ddMMMyyyy HH:mm:ss').toUpperCase();
            else
                _dicContInfo.ContractEndDate = "NA";

            if (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
                _dicContInfo.TenderStartDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nExerciseStartDate.toString()) && _segId != clsConstants.C_V_BSE_DERIVATIVES) {
                _dicContInfo.TenderStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseStartDate, null).toUpperCase(); //clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseStartDate).toUpperCase();
            }
            else
                _dicContInfo.TenderStartDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.TenderEndDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nExerciseEndDate.toString()) && (_segId != clsConstants.C_V_BSE_DERIVATIVES && _segId != clsConstants.C_V_NSEL_SPOT)) {
                if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
                    _dicContInfo.TenderEndDate = 'NA';
                else
                    _dicContInfo.TenderEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseEndDate, null).toUpperCase(); // clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseEndDate).toUpperCase();
            }
            else
                _dicContInfo.TenderEndDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.DelStartDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nNoDeliveryStartDate.toString()))
                _dicContInfo.DelStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryStartDate, null).toUpperCase(); //clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryStartDate).toUpperCase();
            else
                _dicContInfo.DelStartDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.DelEndDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nNoDeliveryEndDate.toString()) && (_segId != clsConstants.C_V_BSE_DERIVATIVES && _segId != clsConstants.C_V_NSEL_SPOT))
                if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
                    _dicContInfo.DelEndDate = 'NA';
                else
                    _dicContInfo.DelEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryEndDate, null).toUpperCase(); //clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryEndDate).toUpperCase();
            else
                _dicContInfo.DelEndDate = "NA";

            _dicContInfo.showSettlementType = false;
            //Code Comment : if Map Market Seg id is NSE DERIVATIVES OR BSE DERIVATIVES or MSE then Show Settlement Type
            if (_segId == clsConstants.C_V_NSE_DERIVATIVES || _segId == clsConstants.C_V_BSE_DERIVATIVES || _segId == clsConstants.C_V_MSX_FAO) {
                _dicContInfo.showSettlementType = true;
                //Code Comment : _dcConInfoDetails.sDeliveryUnit getting from tbl_ScripMaster (stp_GetContractInfo) of Odin DB
                if (_dcConInfoDetails.sDeliveryUnit != "" || _dcConInfoDetails.sDeliveryUnit != undefined) {
                    var DeliveryUnit = "";
                    //Code Comment : Split _dcConInfoDetails.sDeliveryUnit by '_'
                    DeliveryUnit = _dcConInfoDetails.sDeliveryUnit.split(clsConstants.C_S_SETTLEMENT_TYPE_DELIMITER)
                    //Code Comment : if _dcConInfoDetails.sDeliveryUnit is 'D_-1_1' then it is PHYSICAL DELIVERY
                    if (_dcConInfoDetails.sDeliveryUnit.length > 1) {
                        DeliveryUnit = DeliveryUnit[0];//Code Comment : means It is 'D'
                    } else if (DeliveryUnit.length == 1) {
                        //Code Comment : In case of 'C' i.e Cash Settled following code will execute.
                        DeliveryUnit = DeliveryUnit;
                    } else {
                        DeliveryUnit = "";
                    }
                    //Code Comment : If 'D' then it is 'Physical Delivery' AND If 'C' then it is 'Cash Settled'
                    //Code Comment : If not above then show 'NA'
                    if (DeliveryUnit != "") {
                        if (DeliveryUnit == clsConstants.C_S_PHYSICAL_DELIVERY_UNIT) {
                            _dicContInfo.SettlementType = clsConstants.C_S_PHYSICAL_DELIVERY;
                        } else if (DeliveryUnit == clsConstants.C_S_CASH_SETTLEMENT_UNIT) {
                            _dicContInfo.SettlementType = clsConstants.C_S_CASH_SETTLEMENT;
                        } else {
                            _dicContInfo.SettlementType = "NA";
                        }
                    } else {
                        _dicContInfo.SettlementType = "NA";
                    }
                } else {
                    _dicContInfo.SettlementType = "NA";
                }
            } else {
                //Code Comment : If It is not derivative BSE or NSE then don't show settlement type
                _dicContInfo.showSettlementType = false;
            }

        }
        catch (e) {

        }
        _dicContInfo.NearMonthId = 'NA';
        _dicContInfo.FarMonthId = 'NA';
        _dicContInfo.OLongMargin = 'NA';
        _dicContInfo.OShortMargin = 'NA';
        _dicContInfo.ExMargin = 'NA';
        _dicContInfo.AddPreMargin = 'NA';
        _dicContInfo.AddShortMargin = 'NA';
        _dicContInfo.SPLGCMargin = 'NA';
        _dicContInfo.AddLongMargin = 'NA';
        _dicContInfo.SPSHCMargin = 'NA';
        _dicContInfo.InLongMargin = "NA";
        _dicContInfo.InShortMargin = "NA";
        _dicContInfo.AppLongMargin = "NA";
        _dicContInfo.AppShortMargin = "NA";

        //MSX Information ...
        if (_segId == clsConstants.C_V_MSX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nOtherLongMargin))
                _dicContInfo.OLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nOtherLongMargin.toString());

            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nOtherLongMargin))
                _dicContInfo.OShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nOtherShortMargin.toString());
        }
        //MCX Information ...
        if (_segId == clsConstants.C_V_MCX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashLongMargin))
                _dicContInfo.OLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashLongMargin.toString());

            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashShortMargin))
                _dicContInfo.OShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashShortMargin.toString());
        }

        //NCDEX Information ...
        if (_segId == clsConstants.C_V_NCDEX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nExposureMarginAdditional.toString()))
                _dicContInfo.ExMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nExposureMarginAdditional.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nPreExpiryMargin.toString()))
                _dicContInfo.AddPreMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nPreExpiryMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nAdditionalShortMargin.toString()))
                _dicContInfo.AddShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nAdditionalShortMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashLongMargin.toString()))
                _dicContInfo.SPLGCMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashLongMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nAdditionalLongMargin.toString()))
                _dicContInfo.AddLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nAdditionalLongMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashShortMargin.toString()))
                _dicContInfo.SPSHCMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashShortMargin.toString());
        }

        //Margin Info
        if (_dcMarginDetails != undefined) {
            if (_dcMarginDetails.hasOwnProperty("Initial Margin Long")) {
                if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId == clsConstants.C_V_NSEL_SPOT) || (_segId == clsConstants.C_V_NMCE_DERIVATIVES) ||
                    (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)) ||
                    _segId == clsConstants.C_V_BSE_DERIVATIVES || _segId == clsConstants.C_V_DGCX_DERIVATIVES || _segId == clsConstants.C_V_BFX_DERIVATIVES ||
                    _segId == clsConstants.C_V_UCX_DERIVATIVES || _segId == clsConstants.C_V_UCX_SPOT ||
                    _segId == clsConstants.C_V_DGCX_SPOT || _segId == clsConstants.C_V_BFX_SPOT) {
                    _dicContInfo.InLongMargin = 'NA';
                    _dicContInfo.InShortMargin = 'NA';
                    _dicContInfo.AppLongMargin = 'NA';
                    _dicContInfo.AppShortMargin = 'NA';
                }
                else {
                    _dicContInfo.InLongMargin = _dcMarginDetails["Initial Margin Long"].toString() != "" ? _dcMarginDetails["Initial Margin Long"].toFixed(2) : 'NA';
                    _dicContInfo.InShortMargin = _dcMarginDetails["Initial Margin Short"].toString() != "" ? _dcMarginDetails["Initial Margin Short"].toFixed(2) : 'NA';
                    _dicContInfo.AppLongMargin = _dcMarginDetails["Total Margin Long"].toString() != "" ? _dcMarginDetails["Total Margin Long"].toFixed(2) : 'NA';
                    _dicContInfo.AppShortMargin = _dcMarginDetails["Total Margin Short"].toString() != "" ? _dcMarginDetails["Total Margin Short"].toFixed(2) : 'NA';
                }
            }
        }
        else {
            if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId == clsConstants.C_V_NSEL_SPOT) || (_segId == clsConstants.C_V_NMCE_DERIVATIVES) ||
                (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)) ||
                _segId == clsConstants.C_V_BSE_DERIVATIVES || _segId == clsConstants.C_V_DGCX_DERIVATIVES || _segId == clsConstants.C_V_BFX_DERIVATIVES ||
                _segId == clsConstants.C_V_UCX_DERIVATIVES || _segId == clsConstants.C_V_UCX_SPOT ||
                _segId == clsConstants.C_V_DGCX_SPOT || _segId == clsConstants.C_V_BFX_SPOT ||
                _segId == clsConstants.C_V_MSX_FAO) {
                _dicContInfo.InLongMargin = 'NA';
                _dicContInfo.InShortMargin = 'NA';
                _dicContInfo.AppLongMargin = 'NA';
                _dicContInfo.AppShortMargin = 'NA';
            }
            else {
                if (_segId == clsConstants.C_V_MCX_DERIVATIVES) {
                    if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nPreExpiryMargin))
                        _dicContInfo.InLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nPreExpiryMargin.toString());

                    if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nAdditionalLongMargin))
                        _dicContInfo.InShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nAdditionalLongMargin.toString());

                    if (parseFloat(_dcConInfoDetails.nSpecialCashLongMargin) != NaN && parseFloat(_dcConInfoDetails.nPreExpiryMargin) != NaN) {
                        var AppLongMTotal = parseFloat(_dcConInfoDetails.nPreExpiryMargin) + parseFloat(_dcConInfoDetails.nSpecialCashLongMargin);
                        _dicContInfo.AppLongMargin = clsTradingMethods.formatToPercentage(AppLongMTotal.toString());
                    }

                    if (parseFloat(_dcConInfoDetails.nSpecialCashShortMargin) != NaN && parseFloat(_dcConInfoDetails.nAdditionalLongMargin) != NaN) {
                        var AppShortMTotal = parseFloat(_dcConInfoDetails.nPreExpiryMargin) + parseFloat(_dcConInfoDetails.nSpecialCashLongMargin);
                        _dicContInfo.AppShortMargin = clsTradingMethods.formatToPercentage(AppShortMTotal.toString());
                    }
                } else {
                    if (_segId == clsConstants.C_V_NCDEX_DERIVATIVES) {
                        if (_dcConInfoDetails.nExposureMarginAdditional.toString() != "-1.0000" && _dcConInfoDetails.nPreExpiryMargin.toString() != "-1.0000" && _dcConInfoDetails.nSpecialCashLongMargin.toString() != "-1.0000" && _dcConInfoDetails.nAdditionalLongMargin.toString() != "-1.0000") {
                            _dicContInfo.AppLongMargin = (parseFloat(_dcConInfoDetails.nExposureMarginAdditional) + parseFloat(_dcConInfoDetails.nPreExpiryMargin) + parseFloat(_dcConInfoDetails.nSpecialCashLongMargin) + parseFloat(_dcConInfoDetails.nAdditionalLongMargin)).toFixed(2);
                        }
                        else {
                            _dicContInfo.AppLongMargin = "NA";
                        }
                        if (_dcConInfoDetails.nExposureMarginAdditional.toString() != "-1.0000" && _dcConInfoDetails.nPreExpiryMargin.toString() != "-1.0000" && _dcConInfoDetails.nSpecialCashShortMargin.toString() != "-1.0000" && _dcConInfoDetails.nAdditionalShortMargin.toString() != "-1.0000") {
                            _dicContInfo.AppShortMargin = (parseFloat(_dcConInfoDetails.nExposureMarginAdditional) + parseFloat(_dcConInfoDetails.nPreExpiryMargin) + parseFloat(_dcConInfoDetails.nSpecialCashShortMargin) + parseFloat(_dcConInfoDetails.nAdditionalShortMargin)).toFixed(2);
                        }
                        else {
                            _dicContInfo.AppShortMargin = "NA";
                        }
                    }
                    else {
                        _dicContInfo.InLongMargin = "NA";
                        _dicContInfo.InShortMargin = "NA";
                        _dicContInfo.AppLongMargin = "NA";
                        _dicContInfo.AppShortMargin = "NA";
                    }
                }

            }
        }

        if (_dcConInfoDetails.hasOwnProperty("NearMonthSymbol") && _dcConInfoDetails.hasOwnProperty("NearMonthExpiry") &&
            _dcConInfoDetails.hasOwnProperty("FarMonthSymbol") && _dcConInfoDetails.hasOwnProperty("FarMonthExpiry")) {
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.NearMonthExpiry.toString())) {
                _dicContInfo.NearMonthId = _dcConInfoDetails.NearMonthSymbol + " " + clsTradingMethods.convertToDate(parseFloat(_dcConInfoDetails.NearMonthExpiry), undefined).toUpperCase();
            }
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.FarMonthExpiry.toString())) {
                _dicContInfo.FarMonthId = _dcConInfoDetails.FarMonthSymbol + " " + clsTradingMethods.convertToDate(parseFloat(_dcConInfoDetails.FarMonthExpiry), undefined).toUpperCase();
            }
        }

        _dicContInfo.LotUnit = 'NA';
        _dicContInfo.MaxOrderQty = 'NA';
        _dicContInfo.MaxOrderValue = 'NA';

        if (_segId == clsConstants.C_V_MCX_DERIVATIVES || _segId == clsConstants.C_V_NCDEX_DERIVATIVES || _segId == clsConstants.C_V_NMCE_DERIVATIVES || _segId == clsConstants.C_V_NSX_DERIVATIVES || _segId == clsConstants.C_V_NSE_DERIVATIVES) {
            if (_dcConInfoDetails.hasOwnProperty("sQtyUnit")) {
                _dicContInfo.LotUnit = _dcConInfoDetails.sQtyUnit != "" ? _dcConInfoDetails.sQtyUnit : 'NA';
            }
            if (_dcConInfoDetails.hasOwnProperty("nMaxSingleTransactionQty")) {
                _dicContInfo.MaxOrderQty = _dcConInfoDetails.nMaxSingleTransactionQty.toString() != "" ? _dcConInfoDetails.nMaxSingleTransactionQty : 'NA';
            }
            if (_dcConInfoDetails.hasOwnProperty("nMaxSingleTransactionValue")) {
                _dicContInfo.MaxOrderValue = (_dcConInfoDetails.nMaxSingleTransactionValue.toString() != "") ? (_dcConInfoDetails.nMaxSingleTransactionValue.toString() != "-1") ? _dcConInfoDetails.nMaxSingleTransactionValue : "Unlimited" : "NA";
            }
        }

        return _dicContInfo;
    };

    public static getLifeTimeHighCaption(_nMktSegId) {
        var _LTHCaption = '';
        try {
            if (_nMktSegId == clsConstants.C_V_NSE_CASH || _nMktSegId == clsConstants.C_V_BSE_CASH ||
                _nMktSegId == clsConstants.C_V_DSE_CASH || _nMktSegId == clsConstants.C_V_MSX_CASH ||
                _nMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                _LTHCaption = '52W H';
            }
            else {
                _LTHCaption = 'LT H';
            }
        }
        catch (e) {

        }
        return _LTHCaption;
    };

    ///<summary>
    ///Function to return the caption for LifeTimeHigh used in case BestFive
    ///</summary>
    public static getLifeTimeLowCaption(_nMktSegId) {
        var _LTLCaption = '';
        try {
            if (_nMktSegId == clsConstants.C_V_NSE_CASH || _nMktSegId == clsConstants.C_V_BSE_CASH ||
                _nMktSegId == clsConstants.C_V_DSE_CASH || _nMktSegId == clsConstants.C_V_MSX_CASH ||
                _nMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                _LTLCaption = '52W L';
            }
            else {
                _LTLCaption = 'LT L';
            }
        }
        catch (e) {

        }
        return _LTLCaption;
    };

    // 5353, Method added so that it can format price to decimals which we provide
    public static formatPrice(val, nFormat) {
        return (val != undefined && val.trim() != '') ? parseFloat(val).toFixed(nFormat) : (0).toFixed(nFormat);
    }

    public static getAllowedSegmentList(_iMarketSegmentId) {
        let arrMktSegList = [];
        try {

            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSE_CASH) == clsConstants.C_V_MAPPED_NSE_CASH) {
                arrMktSegList.push(clsConstants.C_V_NSE_CASH.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSE_DERIVATIVES) == clsConstants.C_V_MAPPED_NSE_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_NSE_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_BSE_CASH) == clsConstants.C_V_MAPPED_BSE_CASH) {
                arrMktSegList.push(clsConstants.C_V_BSE_CASH.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_BSE_DERIVATIVES) == clsConstants.C_V_MAPPED_BSE_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_BSE_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MCX_DERIVATIVES) == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_MCX_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MCX_SPOT) == clsConstants.C_V_MAPPED_MCX_SPOT) {
                arrMktSegList.push(clsConstants.C_V_MCX_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES) == clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_NCDEX_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NCDEX_SPOT) == clsConstants.C_V_MAPPED_NCDEX_SPOT) {
                arrMktSegList.push(clsConstants.C_V_NCDEX_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSEL_DERIVATIVES) == clsConstants.C_V_MAPPED_NSEL_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_MAPPED_NSEL_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSEL_SPOT) == clsConstants.C_V_MAPPED_NSEL_SPOT) {
                arrMktSegList.push(clsConstants.C_V_NSEL_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MSX_DERIVATIVES) == clsConstants.C_V_MAPPED_MSX_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_MSX_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MSX_SPOT) == clsConstants.C_V_MAPPED_MSX_SPOT) {
                arrMktSegList.push(clsConstants.C_V_MSX_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSX_DERIVATIVES) == clsConstants.C_V_MAPPED_NSX_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_NSX_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NSX_SPOT) == clsConstants.C_V_MAPPED_NSX_SPOT) {
                arrMktSegList.push(clsConstants.C_V_NSX_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES) == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_BSECDX_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_BSECDX_SPOT) == clsConstants.C_V_MAPPED_BSECDX_SPOT) {
                arrMktSegList.push(clsConstants.C_V_BSECDX_SPOT.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MSX_CASH) == clsConstants.C_V_MAPPED_MSX_CASH) {
                arrMktSegList.push(clsConstants.C_V_MSX_CASH.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_MSX_FAO) == clsConstants.C_V_MAPPED_MSX_FAO) {
                arrMktSegList.push(clsConstants.C_V_MSX_FAO.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_NMCE_DERIVATIVES) == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES) {
                arrMktSegList.push(clsConstants.C_V_NMCE_DERIVATIVES.toString());
            }
            if ((_iMarketSegmentId & clsConstants.C_V_MAPPED_OFS_IPO_BONDS) == clsConstants.C_V_MAPPED_OFS_IPO_BONDS) {
                arrMktSegList.push(clsConstants.C_V_OFS_IPO_BONDS.toString());
            }

        }
        catch (e) {
            console.log(e);
            // LogManager.WriteLog(e.message, 'GetMappedMarketSegmentId', 'WWTradingMethods.js', '');
        }
        return arrMktSegList;
    }


    public static GeneratePositionConversionMessage(message) {
        let _sbFinalMessage = new StringBuilder();
        let reason = '';
        _sbFinalMessage.Append('Position Converted : ');
        _sbFinalMessage.Append(' from ');

        if (message.Product == 16) {
            if (message.Exchange == clsConstants.C_V_NSE_CASH || message.Exchange == clsConstants.C_V_BSE_CASH || message.Exchange == clsConstants.C_V_MSX_CASH) {
                reason = clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
            }
            else {
                reason = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT;
            }
        }
        else if (message.Product == 32) {
            if (message.Exchange == clsConstants.C_V_NSE_CASH || message.Exchange == clsConstants.C_V_BSE_CASH || message.Exchange == clsConstants.C_V_MSX_CASH) {
                reason = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT;
            }
            else {
                reason = clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
            }
        }
        else if (message.Product == 128) {
            reason = clsConstants.C_S_PRODUCTTYPE_PTST_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
        }
        else if (message.Product == 256) {
            reason = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_PTST_TEXT;
        }
        else if (message.Product == 512) {
            reason = clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_PTST_TEXT;
        }
        else if (message.Product == 1024) {
            reason = clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;
        }
        else if (message.Product == 2048) {
            reason = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;
        }
        else if (message.Product == 4096) {
            reason = clsConstants.C_S_PRODUCTTYPE_PTST_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT;
        }
        else if (message.Product == 16384) {
            reason = clsConstants.C_S_PRODUCTTYPE_MTF_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT;
        }
        else if (message.Product == 32768) {
            reason = clsConstants.C_S_PRODUCTTYPE_MTF_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
        }
        else if (message.Product == 65536) {
            reason = clsConstants.C_S_PRODUCTTYPE_MTF_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_PTST_TEXT;
        }
        else if (message.Product == 131072) {
            reason = clsConstants.C_S_PRODUCTTYPE_PTST_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;
        }
        else {
            reason = clsConstants.C_S_PRODUCTTYPE_PTST_TEXT + ' to ' + clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;
        }

        _sbFinalMessage.Append(reason);
        _sbFinalMessage.Append(' for ' + this.getExchangeNameDesc(message.Exchange) + ' ');
        _sbFinalMessage.Append(this.getInstrumentName(message.InstrumentName) + ' ');
        _sbFinalMessage.Append(message.Symbol + ' ');
        _sbFinalMessage.Append('Quantity = ' + message.OrderOriginalQty);
        _sbFinalMessage.Append(' at ' + message.LastModifiedTime);

        return _sbFinalMessage.toString();
    }

    public static getLastLogonTime(seconds, strFormat): any {
        var d1 = new Date("01/01/1970 00:00:00");
        d1.setSeconds(seconds);
        var t = "";
        if (strFormat == undefined || strFormat == null || strFormat == '') {
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'sep', 'Oct', 'Nov', 'Dec'];
            t = this.getFormattedDays(d1.getDate()) + ' ' + months[d1.getMonth()].toUpperCase() + ' ' + (parseInt(d1.getHours().toString()) + 5) + ':' + (parseInt(d1.getMinutes().toString()) + 30) + ':' + d1.getSeconds();
            return t;
        }
        else {
            return clsGlobal.dateFormatter.transform(d1, strFormat);
            //return d1.toString();
        }

    }

    // /**
    // * To get scrip info from server.
    // * @param mktSegId
    // * @param token
    // */
    public static getScripInfo(segmentId: any, token: any, objHttpService: clsHttpService) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
                        + 'v1/getScrip/' + segmentId + "/" + token + "/" + clsGlobal.User.SITemplateId)
                        .subscribe(respData => {
                            resolve(respData);
                        }, error => {
                            //this.objToast.showAtBottom("Unable to fetch data.");
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    //this.objToast.showAtBottom("Unable to fetch data.");
                    reject("Unable to fetch data.");
                }
            });
        } catch (error) {
            clsGlobal.logManager.writeErrorLog('clsTrandingMethods', 'getScripInfo', error);
        }
    }

    public static getScripInfoElasticSearch(scrip: any, objHttpService: clsHttpService) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    objHttpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
                        + clsGlobal.versionId + '/getScripbytokenandMktSegId', scrip)
                        .subscribe(respData => {
                            resolve(respData);
                        }, error => {
                            //this.objToast.showAtBottom("Unable to fetch data.");
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    //this.objToast.showAtBottom("Unable to fetch data.");
                    reject("Unable to fetch data.");
                }
            });
        } catch (error) {
            clsGlobal.logManager.writeErrorLog('clsTrandingMethods', 'getScripInfoElasticSearch', error);
        }
    }

    // /**
    // * To get api exchange name based on market segment id provided .
    // * @param mktSegId

    // */
    public static getApiExchangeName(intMktSegId): any {
        var strExName = '';

        /*
        switch (intMktSegId) {
            case clsConstants.C_V_NSE_CASH:
                strExName = clsConstants.C_S_NSE_EQ_API_NAME;
                break;
            case clsConstants.C_V_NSE_DERIVATIVES:
                strExName = clsConstants.C_S_NSE_DERV_API_NAME;
                break;
            case clsConstants.C_V_BSE_CASH:
                strExName = clsConstants.C_S_BSE_EQ_API_NAME;
                break;
            case clsConstants.C_V_BSE_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_DERV_API_NAME;
                break;
            case clsConstants.C_V_MCX_DERIVATIVES:
            case clsConstants.C_V_MCX_SPOT:
                strExName = clsConstants.C_S_MCX_FUTURES_API_NAME;
                break;
            case clsConstants.C_V_NCDEX_DERIVATIVES:
            case clsConstants.C_V_NCDEX_SPOT:
                strExName = clsConstants.C_S_NCDEX_FUTURES_API_NAME;
                break;
            case clsConstants.C_V_NSEL_DERIVATIVES:
            case clsConstants.C_V_NSEL_SPOT:
                strExName = clsConstants.C_S_NSEL_SPTCOM_DESC;
                break;
            case clsConstants.C_V_MSX_DERIVATIVES:
                strExName = clsConstants.C_S_MCXSX_FUTURES_DESC;
                break;
            case clsConstants.C_V_MSX_CASH:
                strExName = clsConstants.C_S_MCXSX_EQUITIES_DESC;
                break;
            case clsConstants.C_V_MSX_FAO:
                strExName = clsConstants.C_S_MCXSX_FAO_DESC;
                break;
            case clsConstants.C_V_DSE_CASH:
                strExName = clsConstants.C_S_DSE_EQUITIES_DESC;
                break;
            case clsConstants.C_V_NMCE_DERIVATIVES:
                strExName = clsConstants.C_S_NMCE_FUTURES_DESC;
                break;
            case clsConstants.C_V_NSX_DERIVATIVES:
            case clsConstants.C_V_NSX_SPOT:
                strExName = clsConstants.C_S_NSX_FUTURES_DESC;
                break;
            case clsConstants.C_V_BSECDX_DERIVATIVES:
            case clsConstants.C_V_BSECDX_SPOT:
                strExName = clsConstants.C_S_BSECDX_FUTURES_DESC;
                break;
            case clsConstants.C_V_UCX_DERIVATIVES:
            case clsConstants.C_V_UCX_SPOT:
                strExName = clsConstants.C_S_UCX_FUTURES_DESC;
                break;
            case clsConstants.C_V_DGCX_DERIVATIVES:
            case clsConstants.C_V_DGCX_SPOT:
                strExName = clsConstants.C_S_DGCX_FUTURES_DESC;
                break;
            case clsConstants.C_V_BFX_DERIVATIVES:
            case clsConstants.C_V_BFX_SPOT:
                strExName = clsConstants.C_S_BFX_FUTURES_DESC;
                break;
            case clsConstants.C_V_OFS_IPO_BONDS:
                strExName = clsConstants.C_S_OTSTXT_EXCHANGE_TEXT;
                break;

        }
        */

        switch (intMktSegId) {
            case clsConstants.C_V_NSE_CASH:
                strExName = clsConstants.C_S_NSE_EQ_API;
                break;
            case clsConstants.C_V_NSE_DERIVATIVES:
                strExName = clsConstants.C_S_NSE_DERV_API;
                break;
            case clsConstants.C_V_MSX_FIM:
                strExName = clsConstants.C_S_MSX_FIM_API;
                break;
            case clsConstants.C_V_NSEL_DERIVATIVES:
                strExName = clsConstants.C_S_NSEL_SPTCOM_DESC_API;
                break;
            case clsConstants.C_V_BSE_CASH:
                strExName = clsConstants.C_S_BSE_EQ_API;
                break;
            case clsConstants.C_V_BSE_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_DERV_API;
                break;
            case clsConstants.C_V_MCX_DERIVATIVES:
                strExName = clsConstants.C_S_MCX_DERV_API;
                break;
            case clsConstants.C_V_MCX_SPOT:
                strExName = clsConstants.C_S_MCX_SPOT_API;
                break;
            case clsConstants.C_V_ICEX_DERIVATIVES:
                strExName = clsConstants.C_S_ICEX_DERV_API;
                break;
            case clsConstants.C_V_BSECOMM_DERIVATIVES:
                strExName = clsConstants.C_S_BSE_COMM_API;
                break;
            case clsConstants.C_V_NSECOMM_DERIVATIVES:
                strExName = clsConstants.C_S_NSE_COMM_API;
                break;
            case clsConstants.C_V_BSECOMM_SPOT:
                strExName = clsConstants.C_S_BSECOMM_SPOT_API;
                break;
            case clsConstants.C_V_NSECOMM_SPOT:
                strExName = clsConstants.C_S_NSECOMM_SPOT_API;
                break;
            case clsConstants.C_V_NCDEX_DERIVATIVES:
                strExName = clsConstants.C_S_NCDEX_DERV_API;
                break;
            case clsConstants.C_V_NCDEX_SPOT:
                strExName = clsConstants.C_S_NCDEX_SPOT_API;
                break;
            case clsConstants.C_V_MSX_DERIVATIVES:
                strExName = clsConstants.C_S_MCXSX_CURR_API;
                break;
            case clsConstants.C_V_MSX_CASH:
                strExName = clsConstants.C_S_MCXSX_EQ_API;
                break;
            case clsConstants.C_V_MSX_FAO:
                strExName = clsConstants.C_S_MCXSX_DERV_API;
                break;
            case clsConstants.C_V_MSX_SPOT:
                strExName = clsConstants.C_S_MCXSX_SPOT_API;
                break;
            // case clsConstants.C_V_DSE_CASH:
            //   strExName = clsConstants.C_S_DSE_EQUITIES;
            //   break;
            case clsConstants.C_V_NSX_DERIVATIVES:
                strExName = clsConstants.C_S_NSX_DERV_API;
                break;
            case clsConstants.C_V_NSX_SPOT:
                strExName = clsConstants.C_S_NSX_SPOT_API;
                break;
            case clsConstants.C_V_BSECDX_DERIVATIVES:
                strExName = clsConstants.C_S_BSECDX_DERV_API;
                break;
            case clsConstants.C_V_BSECDX_SPOT:
                strExName = clsConstants.C_S_BSECDX_SPOT_API;
                break;
            // case clsConstants.C_V_UCX_DERIVATIVES:
            //   strExName = clsConstants.C_S_UCX_FUTURES;
            //   break;
            // case clsConstants.C_V_UCX_SPOT:
            //   strExName = clsConstants.C_S_UCX_SPOT;
            //   break;
            // case clsConstants.C_V_DGCX_DERIVATIVES:
            //   strExName = clsConstants.C_S_DGCX_FUTURES;
            //   break;
            // case clsConstants.C_V_DGCX_SPOT:
            //   strExName = clsConstants.C_S_DGCX_SPOT;
            //   break;
            // case clsConstants.C_V_BFX_DERIVATIVES:
            //   strExName = clsConstants.C_S_BFX_FUTURES;
            //   break;
            // case clsConstants.C_V_BFX_SPOT:
            //   strExName = clsConstants.C_S_BFX_SPOT;
            //   break;
            case clsConstants.C_V_OFS_IPO_BONDS:
                strExName = clsConstants.C_S_NSE_OTS_API;
                break;
        }

        return strExName;
    }
/**
 * 
 * @param arrExchName 
 * @returns 
 * 0: "NSE_EQ"
1: "NSE_FO"
2: "BSE_EQ"
3: "MCX_FO"
4: "NCDEX_FO"
5: "MSE_CUR"
6: "MSE_EQ"
7: "MSE_FO"
8: "MCXSX_FIM"
9: "BSE_COMM"
10: "NSE_CUR"
11: "BSE_CUR"
12: "NSE_OTS"
13: "ICEX_FO"
 */
    public static getApiExchangeMktSegment(arrExchName): any {
        var strExchName = '';
        let iMtSegVal = 0;
        for (let index = 0; index < arrExchName.length; index++) {
            const strExchName = arrExchName[index];

            if (strExchName == clsConstants.C_S_NSE_EQ_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_NSE_CASH;
                continue;
            } 
            if (strExchName == clsConstants.C_S_NSE_DERV_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_NSE_DERIVATIVES;
                continue;
            }

            if (strExchName == clsConstants.C_S_BSE_EQ_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_BSE_CASH;
                continue;
            }

            if (strExchName == clsConstants.C_S_BSE_DERV_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_BSE_DERIVATIVES;
                continue;
            }

            if (strExchName == clsConstants.C_S_MCX_FUTURES_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_MCX_DERIVATIVES;
                continue;
            }

            if (strExchName == clsConstants.C_S_NCDEX_FUTURES_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES;
                continue;
            }  
            //NSE CUR
            if (strExchName == clsConstants.C_S_NSE_CUR_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_NSX_DERIVATIVES;
                continue;
            }
            //BSE CUR
            if (strExchName == clsConstants.C_S_BSE_CUR_API_NAME) {
                iMtSegVal += clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES;
                continue;
            }
            //NSE_COMM
            if (strExchName == clsConstants.C_S_NSE_COMM_API) {
                iMtSegVal += clsConstants.C_V_MAPPED_NSECOMM_DERIVATIVES;
                continue;
            }
            //BSE_COMM 
            if (strExchName == clsConstants.C_S_BSE_COMM_API) {
                iMtSegVal += clsConstants.C_V_MAPPED_BSECOMM_DERIVATIVES;
                continue;
            }
            // //C_S_ICEX_DERV_API
            if (strExchName == clsConstants.C_S_ICEX_DERV_API) {
                iMtSegVal += clsConstants.C_V_MAPPED_ICEX_DERIVATIVES;
                continue;
            } 
            // //C_S_NSE_OTS_API
             if (strExchName == clsConstants.C_S_NSE_OTS_API) {
                iMtSegVal += clsConstants.C_V_MAPPED_OFS_IPO_BONDS;
                continue;
            }
            //C_S_MSX_FIM_API
            // if (strExchName == clsConstants.C_S_MSX_FIM_API) {
            //     iMtSegVal += clsConstants.C_V_MAPPED_OFS_IPO_BONDS;
            //     continue;
            // }
        } 
        return iMtSegVal;
    }

    public static getMktSegFromApiExchangeName(strExchange): any {
        let mktSegId = -1;

        switch (strExchange) {
            case clsConstants.C_S_NSE_EQ:
            case clsConstants.C_S_NSE_EQ_API_NAME:
                mktSegId = clsConstants.C_V_NSE_CASH;
                break;
            case clsConstants.C_S_NSE_DERV_API_NAME:
                mktSegId = clsConstants.C_V_NSE_DERIVATIVES;
                break;
            case clsConstants.C_S_BSE_EQ:
            case clsConstants.C_S_BSE_EQ_API_NAME:
                mktSegId = clsConstants.C_V_BSE_CASH;
                break;
            case clsConstants.C_S_BSE_DERV_API_NAME:
                mktSegId = clsConstants.C_V_BSE_DERIVATIVES;
                break;
            case clsConstants.C_S_MCX_FUTURES_API_NAME:
            //case clsConstants.C_V_MCX_SPOT: check
            case clsConstants.C_S_MCX_DERV:
                mktSegId = clsConstants.C_V_MCX_DERIVATIVES;
                break;
            case clsConstants.C_S_NCDEX_FUTURES_API_NAME:
            //case clsConstants.C_S_NCDEX_DERV:
            //case clsConstants.C_V_NCDEX_SPOT: 
                mktSegId = clsConstants.C_V_NCDEX_DERIVATIVES;
                break;
            case clsConstants.C_S_NSEL_SPTCOM_DESC:
            case clsConstants.C_S_NSEL_SPTCOM_DESC_API:
                mktSegId = clsConstants.C_V_NSEL_DERIVATIVES;
                break;
            case clsConstants.C_S_MCXSX_FUTURES_DESC:
            case clsConstants.C_S_MCXSX_CURR:
                mktSegId = clsConstants.C_V_MSX_DERIVATIVES;
                break;
            case clsConstants.C_S_MCXSX_EQUITIES_DESC:
            case clsConstants.C_S_MCXSX_EQ_API:
            case clsConstants.C_S_MCXSX_EQ:
                mktSegId = clsConstants.C_V_MSX_CASH;
                break;
            case clsConstants.C_S_MCXSX_FAO_DESC:
            case clsConstants.C_S_MCXSX_DERV:
                mktSegId = clsConstants.C_V_MSX_FAO;
                break;
            case clsConstants.C_S_DSE_EQUITIES_DESC:
                mktSegId = clsConstants.C_V_DSE_CASH;
                break;
            case clsConstants.C_S_NSX_FUTURES_DESC:
            case clsConstants.C_S_NSE_CUR_API_NAME:
                mktSegId = clsConstants.C_V_NSX_DERIVATIVES;
                break;
            case clsConstants.C_S_BSECDX_FUTURES_DESC:
            case clsConstants.C_S_BSE_CUR_API_NAME:
                mktSegId = clsConstants.C_V_BSECDX_DERIVATIVES;
                break;
            case clsConstants.C_S_COMBINED_CASH:
                mktSegId = clsConstants.C_V_COMBINED_CASH;
                break;
            case clsConstants.C_S_COMBINED_FNO:
                mktSegId = clsConstants.C_V_COMBINED_FNO;
                break;
            case clsConstants.C_S_COMBINED_CDS:
                mktSegId = clsConstants.C_V_COMBINED_CDS;
                break;
            // added by sonali
            case clsConstants.C_S_MSX_FIM_API:
                mktSegId = clsConstants.C_V_MSX_FIM;
                break;
            case clsConstants.C_S_MCX_SPOT:
                mktSegId = clsConstants.C_V_MCX_SPOT;
                break;
            case clsConstants.C_S_ICEX_DERV:
                mktSegId = clsConstants.C_V_ICEX_DERIVATIVES;
                break;
            case clsConstants.C_S_BSE_COMM:
                mktSegId = clsConstants.C_V_BSECOMM_DERIVATIVES; 
                break;
            case clsConstants.C_S_NSE_COMM:
                mktSegId = clsConstants.C_V_NSECOMM_DERIVATIVES;
                break;
            case clsConstants.C_S_BSECOMM_SPOT:
                mktSegId = clsConstants.C_V_BSECOMM_SPOT;
                break;
            case clsConstants.C_S_NSECOMM_SPOT:
                mktSegId = clsConstants.C_V_NSECOMM_SPOT;
                break;
            case clsConstants.C_S_NCDEX_SPOT:
                mktSegId = clsConstants.C_V_NCDEX_SPOT;
                break;
            case clsConstants.C_S_MCXSX_SPOT:
                mktSegId = clsConstants.C_V_MSX_SPOT;
                break;
            case clsConstants.C_S_BSECDX_SPOT:
                mktSegId = clsConstants.C_V_BSECDX_SPOT;
                break;
            case clsConstants.C_S_NSE_OTS:
                mktSegId = clsConstants.C_V_OFS_IPO_BONDS;
                break;
            case clsConstants.C_S_NSX_SPOT:
                mktSegId = clsConstants.C_V_NSX_SPOT;
                break;
        }

        return mktSegId;
    }

    public static getProductTypeDescription(productType) {
        productType = productType.trim();
        var strProdType = "";
        switch (productType) {
            case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
                strProdType = "Buy & Sell Today";
                break;
            case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:

                strProdType = "Hold Long term";
                break;

            case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
                strProdType = "Till Expiry";
                break;
            case clsConstants.C_S_PRODUCTTYPE_MTF_TEXT:
                strProdType = "Margin Trading Funding";
                break;
            case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
                strProdType = "Cover";
                break;
            case clsConstants.C_S_PRODUCTTYPE_PTST_TEXT:
                strProdType = "Buy Today & Sell Tomorrow";
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
                strProdType = "Bracket";
                break;
        }
        return strProdType;
    }

    public static getValidityTypeDescription(validityType) {
        validityType = validityType.trim();
        let strValidityType = "";
        switch (validityType) {
            case clsConstants.C_S_VALUE_GTD:
                strValidityType = "Till Date";
                break;
            case clsConstants.C_S_VALUE_IOC:
            case clsConstants.C_S_VALUE_FOK:
                strValidityType = "Trade or Cancel";
                break;
            case clsConstants.C_S_VALUE_GTC:
                strValidityType = "Till Cancel";
                break;
            case clsConstants.C_S_VALUE_DAY:
            case clsConstants.C_S_VALUE_EOTODY:
                strValidityType = "Till Today";
                break;
            case clsConstants.C_S_VALUE_EOS:
            case clsConstants.C_S_VALUE_EOSESS:

                strValidityType = "Till Session";
                break;
            default:
                strValidityType = validityType;
                break;
        }
        return strValidityType;
    }

    public static getProductTypeName(productType) {
        productType = productType.trim();
        var strProdType = "";
        switch (productType) {
            case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
                strProdType = "Intraday";
                break;
            case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT: 
                strProdType = "Delivery";
                break; 
            case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
                strProdType = "Carryforward";
                break;
            case clsConstants.C_S_PRODUCTTYPE_MTF_TEXT:
                strProdType = "MTF";
                break;
            case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
                strProdType = "Cover";
                break;
            case clsConstants.C_S_PRODUCTTYPE_PTST_TEXT:
                strProdType = "BTST";
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT:
            case clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT:
                strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE;
                break;
            case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
                strProdType = "Bracket";
                break;
        }
        return strProdType;
    }

    public static getOrderIdentifier() {
        let date1 = new Date(); // current date
        let date2 = new Date("01/01/1980"); // mm/dd/yyyy format
        let timeDiff = Math.abs(date1.getTime() - date2.getTime()); // in miliseconds
        let timeDiffInSecond = Math.ceil(timeDiff / 1000); // in second

        return timeDiffInSecond;

    }

    public static getAllProductType() {

        return [

            clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT,
            clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT,
            clsConstants.C_S_PRODUCTTYPE_MTF_TEXT,
            clsConstants.C_S_PRODUCTTYPE_MP_TEXT,
            clsConstants.C_S_PRODUCTTYPE_PTST_TEXT,
            clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT,
            clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT,
            clsConstants.C_S_PRODUCTTYPE_OFS_TXT,
            clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT
        ]
    }

    //PrajyotD - 20-01-2021 for MTL Touchline (s)
    public static getDateTime(iSeconds) {
        var dteBase = new Date("01/01/1980");
        dteBase.setSeconds(dteBase.getSeconds() + iSeconds);
        //yyyy-MM-dd HHmmss
        var strDate = dteBase.getFullYear() + "-" +
            ("0" + (dteBase.getMonth() + 1)).slice(-2) + "-" +
            ("0" + dteBase.getDay()).slice(-2) + " " +
            ("0" + dteBase.getHours()).slice(-2) +
            ("0" + dteBase.getMinutes()).slice(-2) +
            ("0" + dteBase.getSeconds()).slice(-2);
        return strDate;
    };
    //PrajyotD - 20-01-2021 for MTL Touchline (e)

    /// converts a price in paise to a price in rupees depending upon the decimal locator passed
    public static convertToRupees(strPrice, intMktSegId, strDecimalLoc) {
        if (!(strPrice))
            return '0.00';
        let strOutput = '0.00';

        if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
            if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLoc == "0")
                strDecimalLoc = "100";

            if (strDecimalLoc.trim() == "0")
                strDecimalLoc = "10000";
        } else if (intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
            intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT) {
            if (strDecimalLoc == "0")
                strDecimalLoc = clsConstants.C_V_NSECDS_DECLOC;
        } else if (intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
            intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT) {
            if (strDecimalLoc == "0")
                strDecimalLoc = clsConstants.C_V_BSECDX_DECLOC;
        } else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO ||
            intMktSegId == clsConstants.C_V_MSX_CASH || intMktSegId == clsConstants.C_V_MSX_FAO) {
            if (strDecimalLoc == "0")
                strDecimalLoc = "100";
        } else {
            strDecimalLoc = "100";
        }

        let strPriceFormat = clsTradingMethods.getPriceFormatterWithDLAndMksSegID(strDecimalLoc, intMktSegId);
        if (intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MSX_SPOT ||
            intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT ||
            intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO ||
            intMktSegId == clsConstants.C_V_MSX_CASH || intMktSegId == clsConstants.C_V_MSX_FAO)
            strOutput = (parseFloat(strPrice) / parseFloat(strDecimalLoc)).toFixed(strPriceFormat);
        else
            strOutput = (parseFloat(strPrice) / 100).toFixed(strPriceFormat);
        return strOutput;
    }

    /// converts a price in rupees to a price in paise depending upon the decimal locator passed
    public static convertRupeesToPaisa(strPrice, intMktSegId, strDecimalLoc) {
        let strOutput = 0;

        if (intMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_MSX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT || intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
            if (intMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES && strDecimalLoc == "0")
                strDecimalLoc = "100";

            if (strDecimalLoc.trim() == "0")
                strDecimalLoc = "10000";
        } else if (intMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_NSX_SPOT ||
            intMktSegId == clsConstants.C_V_NSX_DERIVATIVES || intMktSegId == clsConstants.C_V_NSX_SPOT) {
            if (strDecimalLoc == "0")
                strDecimalLoc = clsConstants.C_V_NSECDS_DECLOC;
        } else if (intMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BSECDX_SPOT ||
            intMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || intMktSegId == clsConstants.C_V_BSECDX_SPOT) {
            if (strDecimalLoc == "0")
                strDecimalLoc = clsConstants.C_V_BSECDX_DECLOC;
        } else if (intMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_MAPPED_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_BFX_DERIVATIVES || intMktSegId == clsConstants.C_V_BFX_SPOT ||
            intMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || intMktSegId == clsConstants.C_V_MAPPED_MSX_FAO ||
            intMktSegId == clsConstants.C_V_MSX_CASH || intMktSegId == clsConstants.C_V_MSX_FAO) {
            if (strDecimalLoc == "0")
                strDecimalLoc = "100";
        } else {
            strDecimalLoc = "100";
        }
        strOutput = Math.round(parseFloat(strPrice) * parseFloat(strDecimalLoc));
        return strOutput;
    }


    public static formatScripDesc(expiryDate, instrument, opstionType, strikePrice) {

        let sExpiryDate = ""; let sIntrument = ""; let sOptionType = ""; let sStrikePrice = "";
        if (expiryDate) {
            sExpiryDate = clsCommonMethods.getFormattedExpirydate(expiryDate) + ' ';
        } else {
            sExpiryDate = ""
        }

        if ((instrument == 'EQ') || (instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) || (instrument == clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT) || (instrument == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
            || (instrument == clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT) || (instrument == clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT) || (instrument == clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT)) {
            sIntrument = ""
        }
        else {
            sIntrument = instrument.substr(0, 3) + " ";
        }



        if ((strikePrice == '-1') || (strikePrice == '0.00')) {
            sStrikePrice = ""
        }
        else {
            sStrikePrice = strikePrice + " ";
        }

        if ((opstionType == 'XX')) {
            sOptionType = ""
        }
        else {
            sOptionType = opstionType
        }

        return " " + sExpiryDate + sIntrument + sStrikePrice + sOptionType;

    }

    public static convertToDateObj(seconds) {
        var d1 = new Date("01/01/1980 00:00:00");
        d1.setSeconds(seconds);
        return d1;
    }

    public static decryptChartData(strDecryptedData) {

        strDecryptedData = strDecryptedData.replaceAll(")", ",0,0,0,0,");       //9
        strDecryptedData = strDecryptedData.replaceAll("(", ",0,0,0,");         //7
        strDecryptedData = strDecryptedData.replaceAll("!", ",0,0,");                 //6
        strDecryptedData = strDecryptedData.replaceAll("|", ",0,");                   //5   
        strDecryptedData = strDecryptedData.replaceAll(":", "0,");                    //4
        strDecryptedData = strDecryptedData.replaceAll("{", ",+");                    //10
        strDecryptedData = strDecryptedData.replaceAll("}", ",-");                    //11        
        strDecryptedData = strDecryptedData.replaceAll("%", "5,");                    //3         
        strDecryptedData = strDecryptedData.replaceAll("~", "10");                    //12        
        strDecryptedData = strDecryptedData.replaceAll("@", "20");                    //13        
        strDecryptedData = strDecryptedData.replaceAll("#", "30");                    //14        
        strDecryptedData = strDecryptedData.replaceAll("$", "40");                    //15        
        strDecryptedData = strDecryptedData.replaceAll("^", "50");                    //16
        strDecryptedData = strDecryptedData.replaceAll("&", "60");                    //17
        strDecryptedData = strDecryptedData.replaceAll("*", "70");                    //18
        strDecryptedData = strDecryptedData.replaceAll("<", "80");                    //19
        strDecryptedData = strDecryptedData.replaceAll(">", "90");                    //20
        strDecryptedData = strDecryptedData.replaceAll("a", "0");
        strDecryptedData = strDecryptedData.replaceAll("b", "1");
        strDecryptedData = strDecryptedData.replaceAll("b", "1");
        strDecryptedData = strDecryptedData.replaceAll("b", "1");
        strDecryptedData = strDecryptedData.replaceAll("c", "2");
        strDecryptedData = strDecryptedData.replaceAll("d", "3");
        strDecryptedData = strDecryptedData.replaceAll("e", "4");
        strDecryptedData = strDecryptedData.replaceAll("f", "5");
        strDecryptedData = strDecryptedData.replaceAll("g", "6");
        strDecryptedData = strDecryptedData.replaceAll("h", "7");
        strDecryptedData = strDecryptedData.replaceAll("i", "8");
        strDecryptedData = strDecryptedData.replaceAll("j", "9");
        strDecryptedData = strDecryptedData.replaceAll(";", "00");                //8

        return strDecryptedData;

    }

    public static isCommodityExchange(_sMktSegId) {
        try {
            if (_sMktSegId == clsConstants.C_V_MAPPED_BSECOMM_DERIVATIVES ||
                _sMktSegId == clsConstants.C_V_MAPPED_NSECOMM_DERIVATIVES ||
                _sMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES ||
                _sMktSegId == clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES) {
                return true;
            }
            else {
                return false;
            }
        }
        catch (e) {

        }
    }

    public static generateEDISUrl(EDISOnlineDetails, SelExchange, SelInstrument, MarketSegmentId, arryMultiScrips) {
        let strURL = "";
        try {
            let arryResponse = EDISOnlineDetails;

            let ScripDetails = "";
            if (arryMultiScrips != undefined && arryMultiScrips != null && arryMultiScrips.length > 0) {
                let str = "";
                for (let cntDPQty = 0; cntDPQty < arryMultiScrips.length; cntDPQty++) {
                    if (cntDPQty == (arryMultiScrips.length - 1))
                        str += "{ISIN:'" + arryMultiScrips[cntDPQty].sISINCode.toString().trim() + "',Quantity:" + arryMultiScrips[cntDPQty].nEDISQty + ",ISINName:'" + arryMultiScrips[cntDPQty].sSecurityDesc.toString().trim() + "'}";
                    else
                        str += "{ISIN:'" + arryMultiScrips[cntDPQty].sISINCode.toString().trim() + "',Quantity:" + arryMultiScrips[cntDPQty].nEDISQty + ",ISINName:'" + arryMultiScrips[cntDPQty].sSecurityDesc.toString().trim() + "'},";
                }
                ScripDetails = "[" + ScripDetails.concat(str) + "]";
            }
            else {
                ScripDetails = "[{ISIN:'" + arryResponse.ISIN.toString().trim() + "',Quantity:" + arryResponse.QuantityToHold + ",ISINName:'" + arryResponse.SecurityDescription.toString().trim() + "'}]";
            }

            let data = this.findDPAndClientID(arryResponse, arryResponse.sDepository);

            let strQS;
            strURL = arryResponse.URL + "?";
            strQS = "userCode=" + clsGlobal.User.userCode;
            strQS += "&managerIP=" + clsGlobal.User.managerIP;
            strQS += "&sessionID=" + clsGlobal.User.OCToken;
            strQS += "&channel=" + "MOB";
            strQS += "&isin=" + (arryResponse.ISIN ? arryResponse.ISIN.trim() : '');
            strQS += "&isinName=" + (arryResponse.SecurityDescription ?  arryResponse.SecurityDescription.trim() : '');
            strQS += "&exchangeCd=" + SelExchange;
            strQS += "&product=" + "1";
            strQS += "&instrument=" + (SelInstrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT ? "Equity" : SelInstrument);
            strQS += "&quantity=" + (arryResponse.QuantityToHold || 0);
            strQS += "&dpId=" + data[0];
            strQS += "&clientId=" + data[1];
            strQS += "&depository=" + arryResponse.sDepository;
            strQS += "&productcode=" + "WAVE";
            strQS += "&MarketSegId=" + MarketSegmentId;
            strQS += "&ScripDetails=" + ScripDetails.replace(clsConstants.C_S_URL_PARAMERTER_DELIMITER, clsConstants.C_S_INST_DELIMITER);
            strQS += "&userId=" + clsGlobal.User.userId;
            strQS += "&groupId=" + clsGlobal.User.groupId;
            strURL += "enct=" + clsCommonMethods.EncodeToBase64(strQS);
            //strURL += strQS;
        }
        catch (e) {
            clsGlobal.logManager.writeErrorLog("TradingMethods", 'generateEDISUrl', 'Exception: ' + e.message);
        }
        return strURL;
    }

    public static findDPAndClientID(ClientBenfId, Depository) {
        var data = [0, 0];
        try {
            let DPId = ClientBenfId.sDPId;//ClientBenfId.substring(0, ClientBenfId.indexOf("#")); // 92200;
            let ClientId = ClientBenfId.nBeneficiaryAccountNumber;//ClientBenfId.substring(ClientBenfId.indexOf("#") + 1);  // 1209220000000202;

            if (Depository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_CDSL) {
                if (DPId.length > 6)
                    DPId = DPId.substring(DPId.length - 6);
                else if (DPId.length < 6) {
                    let temp = "";
                    temp = temp.padStart((6 - (DPId.length)), "0");
                    DPId = temp.concat(DPId);
                }
                ClientId = "";
                ClientId = (ClientBenfId.sDPId + "#" + ClientBenfId.nBeneficiaryAccountNumber).replace(/[^\w\s]/gi, '');
            }

            data = [DPId, ClientId];
        }
        catch (e) {
            clsGlobal.logManager.writeErrorLog("TradingMethods", 'FindDPAndClientID', 'Exception: ' + e.message);
        }
        return data;
    }

    public static updateEDISDPHolding (MultiScrips, _callbackSuccess) {
        try {

            
            //create request string   
            // var _sbRequest = new fn_StringBuilder();
            // _sbRequest.Append(Global.Constants.C_V_TAG_USERID + Global.Constants.C_S_NAMEVALUE_DELIMITER + Global.User.UserId + Global.Constants.C_S_FIELD_DELIMITER);
            // _sbRequest.Append(Global.Constants.C_V_TAG_GROUPID + Global.Constants.C_S_NAMEVALUE_DELIMITER + Global.User.GroupId + Global.Constants.C_S_FIELD_DELIMITER);
            // _sbRequest.Append(Global.Constants.C_V_TAG_USERCODE + Global.Constants.C_S_NAMEVALUE_DELIMITER + Global.User.UserCode + Global.Constants.C_S_FIELD_DELIMITER);
            // _sbRequest.Append(Global.Constants.C_V_TAG_SI_TEMPLATEID + Global.Constants.C_S_NAMEVALUE_DELIMITER + Global.User.SITemplateId);

            // var strMultiscrips = "";
            // for (var count = 0; count < MultiScrips.length; count++) {
            //     if (count < MultiScrips.length - 1) {
            //         strMultiscrips = strMultiscrips + MultiScrips[count].sISINCode + Global.Constants.C_S_FIELD_DELIMITER;
            //         strMultiscrips = strMultiscrips + MultiScrips[count].Quantity + Global.Constants.C_S_RECORD_DELIMITER;
            //     }
            //     else {
            //         strMultiscrips = strMultiscrips + MultiScrips[count].sISINCode + Global.Constants.C_S_FIELD_DELIMITER;
            //         strMultiscrips = strMultiscrips + MultiScrips[count].Quantity;
            //     }
            // }

            // var _strRequest = _sbRequest.toString() + Global.Constants.C_S_MULTIRESP_DELIMITER + strMultiscrips + '/' + Global.User.OCToken;
            // Global.CommonMethods.AjaxCall(Global.URL_TRADINGWCF, 'UpdateEDISDPHolding', _strRequest, _callbackSuccess, "", true);
        }
        catch (e) {
            clsGlobal.logManager.writeErrorLog("TradingMethods", 'UpdateEDISDPHolding', 'Exception: ' + e.message);
        }
    }


}
