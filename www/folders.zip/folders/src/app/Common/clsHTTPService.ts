import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsCommonMethods } from './clsCommonMethods';


@Injectable({ providedIn: 'root' })
export class clsHttpService {

  constructor(private http: HttpClient) {
  }

  public getStaticFile(url: string) {

    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    return this.http.get(url, { headers, responseType: 'text' });
  }

  public get(url: string, methodName: string) {

    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MDE1NzQwNywibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS50ZXN0IiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6IldBVkU0NCIsInRlbXBsYXRlSWQiOiJXQVZFIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwaXJ5SW5NaWxsaXMiOjE1NTAyOTE0MjN9.x_kAIQ9OcFyKiEl0p8ce0UX0xxw9VlSNvw0ldfOREj0'); //this will be set by global values
    if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) {
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
    }
    if(clsGlobal.X_API_KEY!=undefined && clsGlobal.X_API_KEY!="")
    headers = headers.append('x-api-key', clsGlobal.X_API_KEY);

    return this.http.get(url + methodName, /*options*/ { headers, responseType: 'text' });
  }
  public getWithOutHeader(url: string) {
    this.checkNetworkStatus()
    return this.http.get(url);
  }
  public getJson(url: string, methodName: string) {

    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    let options ;
    try {
      if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) {
        // headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
        headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
        if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
          headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
        options = { headers: headers };
        return this.http.get(url + methodName, options);
      }
      else {
        if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "") {
          headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
          options = { headers: headers };
          return this.http.get(url + methodName, options);
        }
        else {
          return this.http.get(url + methodName);
        }
      }
    } catch (error) {
      return null;
    }

  }
  //dont use this method , it is for texting purpose.
  /**
   * Dont use this method.
   * @param url 
   * @param methodName 
   * @returns 
   */
  public getJsonForSearch(url: string, methodName: string) {

    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    let options ;
    try {
      if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) {
        // headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
        headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
        if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
          headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
        options = { headers: headers };
        alert("WITH SESSION "+JSON.stringify(options));
        return this.http.get(url + methodName, options);
      }
      else {
        if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "") {
          headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
          options = { headers: headers };
          alert("WITHOUT SESSION 1 "+JSON.stringify(options));
          return this.http.get(url + methodName, options);
        }
        else {
          alert("WITH SESSION 2 ");
          return this.http.get(url + methodName);
        }
      }
    } catch (error) {
      return null;
    }

  }
  public post(url: string, methodName: string, body?: any) {
    this.checkNetworkStatus();
    let _strReq = "";
    let _strOCTok = "";
    if (body != undefined) {
      _strReq = body.split('/')[0];
      _strOCTok = body.split('/')[1];
    }
    let parameters: any = { strRequest: _strReq };

    if (_strOCTok != undefined && _strOCTok != "") {
      //_strOCTok = _self.EncryptOCToken(_strOCTok, 4096);
      parameters.strOCToken = _strOCTok;
      parameters.EncOCToken = true;
    }
   
    if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "") {
      let headers = new HttpHeaders({});
      headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
      let options = { headers: headers };
      return this.http.post<any>(url + methodName, parameters,options);
    }
    else{
    return this.http.post<any>(url + methodName, parameters);
    }
  }
  public postJson(url: string, methodName: string, parameter?: any) {

    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) { 
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")  
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY); 
      let options = { headers: headers };
      return this.http.post<any>(url + methodName, parameter, options);
    }
    else {
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")  {
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY); 
        let options = { headers: headers };
          return this.http.post<any>(url + methodName, parameter,options);
      }
      else{
        return this.http.post<any>(url + methodName, parameter);
      }
     
    }
  }

  public putJson(url: string, methodName: string, parameter?: any) {

    this.checkNetworkStatus();
    if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) {
      let headers = new HttpHeaders({});
        headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")   
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY); 
      let options = { headers: headers };
      return this.http.put<any>(url + methodName, parameter, options); 
    }
    else {
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")  {
        let headers = new HttpHeaders({});
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY); 
        let options = { headers: headers };
        return this.http.put<any>(url + methodName, parameter,options);
      }
      else{
      return this.http.put<any>(url + methodName, parameter);
      }
    }
  }

  /**
   * 
   */
  public deleteJson(url: string, methodName: string, parameter?: any) {
    this.checkNetworkStatus(); 
    if (!clsCommonMethods.isEmpty(clsGlobal.User.sessionId)) {
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
      let options = { headers: headers };
      return this.http.delete<any>(url + methodName, options);
    }
    else {
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
        headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
      let options = { headers: headers };
      return this.http.delete<any>(url + methodName, options);
    }
  }

  public postWithHeaders(url: string, methodName: string, parameter?: any) {
    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
    headers = headers.append('x-api-key', clsGlobal.X_API_KEY);
    let options = { headers: headers };
    return this.http.post<any>(url + methodName, parameter, options);
  }

  public getWithHeaders(url: string, methodName: string) {
    this.checkNetworkStatus();
    let headers = new HttpHeaders({});
    //headers = headers.append('jTenantToken', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiJEUzEiLCJUZW5hbnRJRCI6IkFOIiwiZXhwIjoxNTQ5NTY0MTk5MDAwLCJpYXQiOjE1NDk1MTg0Mjd9.752ZzCj9Iy2QUQP9PQJfyUeh5G9TYZlWNxZ5r2ILOE8'); //this will be set by global values
    headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
    headers = headers.append('jTenantToken', '1'); //this will be set by global values
    headers = headers.append('jTenantID', clsGlobal.LocalComId.substring(0, clsGlobal.LocalComId.length - 1));  // this will be set by global values.
    
    if (clsGlobal.X_API_KEY != undefined && clsGlobal.X_API_KEY != "")
    headers = headers.append('x-api-key', clsGlobal.X_API_KEY);

    let options = { headers: headers };
    return this.http.get<any>(url + methodName, options);

  } 

  public checkNetworkStatus() {
    /*  if (!clsPluginConstants.NetWorkConnected && !clsGlobal.nwPopupOpen) {
       clsGlobal.nwPopupOpen = true;
       this.objtoast.showAtBottom("Oops Network disconnected, please check your internet connection.");
       setTimeout(function(){  clsGlobal.nwPopupOpen = false; },parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_TOAST_DISPLAY_MILLISECONDS)) || 2000)
   } */
  }
}


@Injectable()
export class clsHTTPResponseInterceptor implements HttpInterceptor {
  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      tap(event => {
        if (event instanceof HttpResponse) {
          this.interceptResponse(event.body);
        }
      }),
      catchError(errorReponse => {
        let errMsg: string;
        /*
        IF USER SESSION EXPIRED THEN
        {
          "success":false,
          "statusCode":"gtw-401-901",
          "message":"The user is not Authorized",
          "data": {
                  status: false,
                  request: request,
                  errorCode: 'SESSION_EXPIRED',
                  errorString : 'Your session has expired.'
                },
          "traceId":"b0bb0949-e697-4945-9c66-d323ea391b75"
        
          errorCode: "SESSION_EXPIRED"
        errorString: "Your session has expired."
        request: null
        status: false
        }*/
        if (errorReponse.error != undefined &&
          errorReponse.error.data != undefined &&
          errorReponse.error.data.errorCode != undefined &&
          errorReponse.error.data.status == false &&
          errorReponse.error.data.errorCode == "SESSION_EXPIRED") {
          console.log(errorReponse.error.data.errorString);
          clsGlobal.pubsub.publish('SESSIONEXPIRE_GATEWAY', errorReponse.error.data.errorString);

        }
        else if (errorReponse.error != undefined &&
          errorReponse.error.message != undefined && errorReponse.error.message != null &&
          errorReponse.error.message == "The user is not Authorized" &&
          errorReponse.error.success == false) {
          clsGlobal.pubsub.publish('SESSIONEXPIRE_GATEWAY', "Session Expired!");
        }

        if (errorReponse instanceof HttpErrorResponse) {

          const err = errorReponse.message || JSON.stringify(errorReponse.error);
          errMsg = `${errorReponse.status} - ${errorReponse.statusText || ''} Details: ${err}`;
        } else {
          errMsg = errorReponse.message ? errorReponse.message : errorReponse.toString();
        }

         let objError :any ={};
         objError.error = errorReponse.error;
         objError.msg = errMsg;
         objError.status = errorReponse.status;


        return throwError(objError);
      })
    );
  }

  private interceptResponse(response) {
    if (response != undefined && (response.ResponseObject == clsConstants.C_S_MSGCODE_LOGOFF_RESPONSE || response.ResponseObject == clsConstants.C_V_MSGCODES_SSO_TOKEN_NOT_FOUND)) {

    }
  }
}
