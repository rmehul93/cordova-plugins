export class Profile {
    profileId:string = '';
    profileName:string = '';
    isSystemTemplate:boolean =false;
    profileClass:string = '';
}