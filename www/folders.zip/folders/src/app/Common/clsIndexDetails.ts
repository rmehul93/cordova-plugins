import { clsScrip } from "./clsScrip";

export class clsIndexDetail {
    
    scripDetail:clsScrip;// = new fn_Scrip();
    LTP:string = '0.00';
    PercNetChange:string = '0.00';
    OpenPrice:string = '0.00';
    HighPrice:string = '0.00';
    LowPrice:string = '0.00';
    ClosePrice:string = '0.00';
    NetChangeInRs:string = '0.00';
    LUT:string = '';
    LTPTrend :string = '';
    arrowTrend :string = '';
    PercNetChangeRaw:string = '';
    BuyPrice :string = '0.00';
    BuyQty :string = '0.00';
    SellPrice :string = '0.00';
    SellQty :string = '0.00';
    Volume :string = '0.00';
    LTPChangeCss:string="";
}
