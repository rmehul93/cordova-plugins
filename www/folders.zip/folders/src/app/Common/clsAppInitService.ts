/**
 * Created by Omprakash D on 12 Aug 2020
 * This class will be used to initialize application.
 * Main function of this class are as follow
 * 1. Check SQLLite local db for data(applicationconfig, msgmaster, menu master.) 
 * 2. If local data exist then app will initialize , async get calls to CDN for latest update 
 * 3. If local data not exist then fetch all config from CDN and update sqllite and app will init. 
 */
import { Injectable } from '@angular/core';
import { clsGlobal } from './clsGlobal';
import { DatePipe } from '@angular/common';
import { DatabaseService } from '../providers/database-services/database-services';
import { AppsyncDbService } from '../providers/appsync-db.service';

@Injectable()
export class clsAppInitService {
    private resolveFnc: any;
    private rejectFnc: any;
    // private flagAllUpdate = false;
    // private SQLLitePromiseAll: any;
    // private CDNPromiseAll: any;

    private docArray: any = [
        'APPINFO',
        'APPMENU',
        'DEFAULTWATCHLIST',
        'MSGINFO',
        'DEFAULTINDICES',
        'DYNAMICPRODUCTTYPES',
        'APPLANG'
    ];
    
    constructor(
        public dateFormatter: DatePipe,
        public objSqlLiteDB: DatabaseService,
        private appSync : AppsyncDbService
    ) { }

    public initializeApp() {
       try {
            return new Promise((resolve, reject) => {
            console.log('I must be first to call.');
            this.resolveFnc = resolve;
            this.rejectFnc = reject;
            // To check SQL lite database is ready
            // this.objSqlLiteDB.getDatabaseState().subscribe(data=>{
            //     if (data){
            //         this.setGlobalConfig();
            //         return this.resolveFnc(true);  
            //     }
            //     else{
            //         //for local chrome SQLLite will not available.
            //          //this.setGlobalConfig();
            //          return this.rejectFnc(true);  
            //     }
            // });
                 this.appSync.initializeAppsync().then((result) => {  
                  this.appSync.getAppInfoFromAppSync().then((result)=>{
                      console.log("App info read success");
                    this.appSync.getMsgInfoFromAppSync().then((result)=>{
                        console.log("MSG info read success");
                        this.resolveFnc(true);
                    }).catch((error)=>{
                        this.rejectFnc(false);
                    }); 
                  }).catch((error)=>{
                    this.rejectFnc(true);
                  }); 
                 }).catch(() => {
                     return this.rejectFnc();
                 });
        });
       } catch (error) {
           alert("Error in init call "+error);
            return this.rejectFnc(false);  
       }
    }

    /**
     * created by omprakahs on 12 AUG feb
     * This method will call all global config set methods for SQL lite
     */

    async setGlobalConfig() {
        try {
             
                await  this.getConfigFromDB().then(() => {
                    // data fetch from db.
                    console.log('appconfig data fetch.');
                }).catch(() => {
                    console.log('Error in appconfig data fetch.');
                });
                
                // await this.getMenuFromDB().then(() => {
                //     // data fetch from db.
                //     console.log('Menu data fetch.');
                // }).catch(() => {
                //     console.log('Error in Menu data fetch.');
                // });
                
                await this.getMsgFromDB().then(() => {
                    // data fetch from db.
                    console.log('Message data fetch.');
                }).catch(() => {
                    console.log('Error in Message data fetch.');
                });

            // Checking local config if not available then fetch from JSON and add to SQL lite.
            if (clsGlobal.dConfigMaster.Count() === 0) { 
                await this.objSqlLiteDB.getAppInfo().then(() => {
                    console.log("Application config count ."+clsGlobal.dConfigMaster.Count());
                }).catch(() => {
                    console.log("Error in reading appconfig from net.");
                });
            }

            // local menu checking if not available then fetch from JSON and add to SQL lite.
            // if (clsGlobal.lstMenuMaster.length === 0) {
                
            //     await this.objSqlLiteDB.getAppMenu().then(() => {
            //         console.log("Application lstMenuMaster count ."+clsGlobal.lstMenuMaster.length);
            //     }).catch(() => {
            //         console.log("Error in reading appmenu from net.");
            //     });
            // }

            // local MSG master checking if not available then fetch from JSON and add to SQL lite.
            if (clsGlobal.dMsgMaster.Count() === 0) {    
                await this.objSqlLiteDB.getMsgInfo().then(() => {
                    console.log("Application dMsgMaster count ."+clsGlobal.dMsgMaster.Count());
                }).catch(() => {
                    console.log('Error in reading msg info from net.');
                });
            }

            if (  (clsGlobal.dConfigMaster.Count() === 0)
               || (clsGlobal.dMsgMaster.Count() === 0)) {
                   console.log("All dictioncary fill return rejection.");
                return this.rejectFnc(false);
            }
            else { 
                console.log("All dictioncary fill return resolve.");
                return this.resolveFnc(true); 
            }
        } catch (error) {
           console.log("setConfig error ."+error);
            return this.rejectFnc(false);
        }
    }
    
    /**
     * Desc : Get config data from SQL lite
     */ 

    async getConfigFromDB() {
        try{
           await this.objSqlLiteDB.loadAppInfo().then((value) => {
               this.resolveFnc(true)
            }).catch((error) => {
                console.log('Error: getConfigFromDB1: ' + error);
               this.resolveFnc(false);
            });
        } catch(error){
            this.rejectFnc(false)
        }
    }

    /**
     * Desc : Get config data from SQL lite
     */
   
    // async getMenuFromDB() {
    //     try{
    //         await this.objSqlLiteDB.loadAppMenu().then((value) => {
    //             this.resolveFnc(true);
    //         }).catch((error) => {
    //             this.rejectFnc(false)
    //             console.log('Error: getMenuFromDB1: ' + error);
    //         });
    //     } catch(error){
    //         this.rejectFnc(false)
    //     }
    // }

    /**
     * Desc : Get config data from SQL lite
     */
    async getMsgFromDB() {
        try{
           await this.objSqlLiteDB.loadMsgInfo().then((value) => {
                this.resolveFnc(true)
            }).catch((error) => {
                console.log('Error: getMsgFromDB1: ' + error);
               this.rejectFnc(false)
            });
        } catch(error){
            this.rejectFnc(false)
        }
    }

    //test code to check if data available in db.
    getDBConfig() {
        try {
            debugger
            this.objSqlLiteDB.getAppInfoFromDB().then((value) => {
                alert("success call for db fetch");
            }).catch((error) => {
                console.log('Error: getConfigFromDB1: ' + error);
                alert("error in sqllite fetch");
            });
        } catch (error) {
            alert("error in sqllite fetch 1" + error);
        }
    }
  
}

export function appInitLoader(configService: clsAppInitService) {
    return () => configService.initializeApp();
}
