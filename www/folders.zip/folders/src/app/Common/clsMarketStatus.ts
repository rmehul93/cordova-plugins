
import { IKeyedCollection, Dictionary } from './clsCustomClasses';
import { clsGlobal } from './clsGlobal';
import { clsHttpService } from './clsHTTPService';
import { clsConstants } from './clsConstants';
//import { Dictonary, IKeyedCollection } from '@angular/core';

export class clsMarketStatus {
 

    dcMarketStatus: IKeyedCollection<string> = new Dictionary<string>();

    http: clsHttpService;
    constructor(clsHttpService, LogManagerService) {
        this.http = clsHttpService;
        this.getMktStatus();
        //this.logManager = LogManagerService;
       
    }  

    async getMktStatus() {
       try{

        this.dcMarketStatus.Clear();

        let strNormalNSEEQmkt = "", strAMONSEEQmkt = "", strNormalBSEEQmkt = "", strAMOBSEEQmkt = "", strNormalDFMEQmkt = "", strNormalADXEQmkt = "";
        let strNormalNSEFAOmkt = "", strAMONSEFAOmkt = "", strExtendedNSEFAOmkt = "", strNormalBSEFAOmkt = "", strAMOBSEFAOmkt = "";
        let strNormalNSEDEBTmkt = "", strAMONSEDEBTmkt = "";
        let strNormalNSEOTSmkt = "", strAMONSEOTSmkt = "";
        let strNormalMCXSXFIMmkt = "", strAMOMCXSXFIMmkt = "";
        let strNormalMCXmkt = "", strNormalGBOTmkt = "", strAMOMCXmkt = "", strAMOGBOTmkt = "", strNormalNCDEXmkt = "", strAMONCDEXmkt = "", strNormalNSELmkt = "",
        strAMONSELmkt = "", strNormalNSXmkt = "", strAMONSXmkt = "", strNormalMCXSXmkt = "", strAMOMCXSXmkt = "",
        strNormalMCXSXEQmkt = "", strAMOMCXSXEQmkt = "", strNormalMCXSXFAOmkt = "", strAMOMCXSXFAOmkt = "",
        strNormalDSEEQmkt = "", strAMODSEEQmkt = "", strNormalNMCEFUTmkt = "", sBSESPOSStatus = "", sNSESPOSStatus = "", strAMONMCEFUTmkt = "", strNormalDGCXmkt = "", strNormalBFXmkt = "", strAMODGCXmkt = "", strAMOBFXmkt = "", strNormalUCXmkt = "", strAMOUCXmkt = "", sMCXSXEQSPOSStatus = "", sBSEPCAStatus = "";
        let nDFMUpdatedTime = new Date();
        await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getMarketStatus').subscribe(((data: any) => {
            try {
      
              if (data.status) {
                let Response = data.result;

               
               
                Response.forEach(obj => {
                
                    let iKeyMktSegmentId = obj.nMarketSegmentId;
                    let strValueMktStatus = obj.nMarketStatus
                    let strMktType =obj.nMarketType
                    let strSessionId =obj.nSessionId
                    let strSessionType =obj.nSessionType

                    let nLastUpdatedTime = new Date();
                    try
                    {
                        if (obj.nLastUpdateTime != null && (obj.nLastUpdateTime).toString() != "")
                            nLastUpdatedTime = new Date(obj.nSessionType.toString());
                    }
                    catch (error)
                    {

                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NSE_CASH)
                    {
                        if (strMktType == "1")
                            strNormalNSEEQmkt = strValueMktStatus;
                        if (strMktType == "67")
                            sNSESPOSStatus = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSEEQmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NSE_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalNSEFAOmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSEFAOmkt = strValueMktStatus;
                        if (strMktType == "8")
                            strExtendedNSEFAOmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NSE_DEBT)
                    {
                        if (strMktType == "1")
                            strNormalNSEDEBTmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSEDEBTmkt = strValueMktStatus;
                    }
                    if (iKeyMktSegmentId == clsConstants.C_V_BSE_CASH)
                    {
                        if (strMktType == "1")
                            strNormalBSEEQmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOBSEEQmkt = strValueMktStatus;
                        // Added by Sakthi for SPOS Change for BSE
                        else if (strMktType == "67")        //SPOS Change for OE
                        {
                            if (strSessionType == "10")
                            {
                                if (strSessionId == "200")
                                {
                                    if (strValueMktStatus == "1")
                                    {
                                        sBSEPCAStatus = "PCA Open";
                                    }
                                    else
                                    {
                                        sBSEPCAStatus = "PCA Close";
                                    }
                                }

                                if (strSessionId != "200")
                                {
                                    if (strValueMktStatus == "1")
                                    {
                                        sBSESPOSStatus = "SPOS Open";
                                    }
                                    else
                                    {
                                        sBSESPOSStatus = "SPOS Close";
                                    }
                                }
                            }

                            else if (strSessionType == "12")        //SPOS Change for Matching
                            {
                                if (strSessionId == "202")
                                {
                                    if (strValueMktStatus == "1")
                                    {
                                        sBSEPCAStatus = "PCA Matching Open";
                                    }
                                    else
                                    {
                                        sBSEPCAStatus = "PCA Matching Close";
                                    }
                                }
                                if (strSessionId != "202")
                                {
                                    if (strValueMktStatus == "1")
                                    {
                                        sBSESPOSStatus = "Matching Open";
                                    }
                                    else
                                    {
                                        sBSESPOSStatus = "Matching Close";
                                    }
                                }
                            }

                            else if (strSessionType == "13")        //SPOS Change for Continous Session
                            {
                                if (strValueMktStatus == "1")
                                {
                                    sBSESPOSStatus = "SPOS Close";
                                }
                                else
                                {
                                    sBSESPOSStatus = "SPOS Close";
                                }
                            }
                        }
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_BSE_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalBSEFAOmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOBSEFAOmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_MCX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalMCXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOMCXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NCDEX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalNCDEXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONCDEXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NSEL_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalNSELmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSELmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_MSX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalMCXSXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOMCXSXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NSX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalNSXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_MSX_CASH)
                    {
                        if (strMktType == "1")
                            strNormalMCXSXEQmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOMCXSXEQmkt = strValueMktStatus;

                         // Added by Sakthi for SPOS Change for BSE
                        else if (strMktType == "67")        //SPOS Change for OE
                        {
                            if (strSessionType == "10")
                            {
                                if (strValueMktStatus == "1")
                                {
                                    sMCXSXEQSPOSStatus = "SPOS Open";
                                }
                                else
                                {
                                    sMCXSXEQSPOSStatus = "SPOS Close";
                                }
                            }
                            else if (strSessionType == "12")        //SPOS Change for Matching
                            {
                                if (strValueMktStatus == "1")
                                {
                                    sMCXSXEQSPOSStatus = "Betterment Open";
                                }
                                else
                                {
                                    sMCXSXEQSPOSStatus = "Betterment Close";
                                }
                            }

                            else if (strSessionType == "13")        //SPOS Change for Continous Session
                            {
                                if (strValueMktStatus == "1")
                                {
                                    sMCXSXEQSPOSStatus = "SPOS Close";
                                }
                                else
                                {
                                    sMCXSXEQSPOSStatus = "SPOS Close";
                                }
                            }
                        }
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_MSX_FAO)
                    {
                        if (strMktType == "1")
                            strNormalMCXSXFAOmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOMCXSXFAOmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_MSX_FIM)
                    {
                        if (strMktType == "1")
                            strNormalMCXSXFIMmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOMCXSXFIMmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_DSE_CASH)
                    {
                        if (strMktType == "1")
                            strNormalDSEEQmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMODSEEQmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_NMCE_DERVIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalNMCEFUTmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONMCEFUTmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_DGCX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalDGCXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMODGCXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_BFX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalBFXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOBFXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_UCX_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalUCXmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOUCXmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_DFM_CASH)
                    {
                        if (nDFMUpdatedTime <= nLastUpdatedTime)
                        {
                            //if (strMktType == "1" || strMktType == "6" || strMktType == "7")
                            if (strMktType == "1")
                                strNormalDFMEQmkt = strValueMktStatus;
                            else if (strMktType == "6")
                            {
                                if (strValueMktStatus == "1")
                                    strNormalDFMEQmkt = "6"; // Indicates Pre Closing Open
                                else if (strValueMktStatus == "2")
                                    strNormalDFMEQmkt = "7"; // Indicates Pre Closing Ends (Closing...)
                            }
                            nDFMUpdatedTime = nLastUpdatedTime;
                        }
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_ADX_CASH)
                    {
                        if (strMktType == "1")
                            strNormalADXEQmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_GBOT_DERIVATIVES)
                    {
                        if (strMktType == "1")
                            strNormalGBOTmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMOGBOTmkt = strValueMktStatus;
                    }

                    if (iKeyMktSegmentId == clsConstants.C_V_OFS_IPO_BONDS)
                    {
                        if (strMktType == "1")
                            strNormalNSEOTSmkt = strValueMktStatus;
                        if (strMktType == "7")
                            strAMONSEOTSmkt = strValueMktStatus;
                    }
                });  
                
           


                this.dcMarketStatus.Add(clsConstants.C_V_NSE_CASH.toString(), this.getMktStatusDesc(strNormalNSEEQmkt, strAMONSEEQmkt, "", clsConstants.C_V_NSE_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalNSEFAOmkt, strAMONSEFAOmkt, strExtendedNSEFAOmkt, clsConstants.C_V_NSE_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_NSE_DEBT.toString(), this.getMktStatusDesc(strNormalNSEDEBTmkt, strAMONSEDEBTmkt, "", clsConstants.C_V_NSE_DEBT));
                this.dcMarketStatus.Add(clsConstants.C_V_BSE_CASH.toString(), this.getMktStatusDesc(strNormalBSEEQmkt, strAMOBSEEQmkt, "", clsConstants.C_V_BSE_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalBSEFAOmkt, strAMOBSEFAOmkt, "", clsConstants.C_V_BSE_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalMCXmkt, strAMOMCXmkt, "", clsConstants.C_V_MCX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalNCDEXmkt, strAMONCDEXmkt, "", clsConstants.C_V_NCDEX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalNSELmkt, strAMONSELmkt, "", clsConstants.C_V_NSEL_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalMCXSXmkt, strAMOMCXSXmkt, "", clsConstants.C_V_MSX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalNSXmkt, strAMONSXmkt, "", clsConstants.C_V_NSX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_MSX_CASH.toString(), this.getMktStatusDesc(strNormalMCXSXEQmkt, strAMOMCXSXEQmkt, "", clsConstants.C_V_MSX_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_MSX_FAO.toString(), this.getMktStatusDesc(strNormalMCXSXFAOmkt, strAMOMCXSXFAOmkt, "", clsConstants.C_V_MSX_FAO));
                this.dcMarketStatus.Add(clsConstants.C_V_DSE_CASH.toString(), this.getMktStatusDesc(strNormalDSEEQmkt, strAMODSEEQmkt, "", clsConstants.C_V_DSE_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_NMCE_DERVIVATIVES.toString(), this.getMktStatusDesc(strNormalNMCEFUTmkt, strAMONMCEFUTmkt, "", clsConstants.C_V_NMCE_DERVIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_BSE_SPOS.toString(), sBSESPOSStatus);
                this.dcMarketStatus.Add(clsConstants.C_V_NSE_SPOS.toString(), sNSESPOSStatus);
                this.dcMarketStatus.Add(clsConstants.C_V_MSX_SPOS.toString(), sMCXSXEQSPOSStatus);
                this.dcMarketStatus.Add(clsConstants.C_V_BSE_PCA.toString(), sBSEPCAStatus);
                this.dcMarketStatus.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalDGCXmkt, strAMODGCXmkt, "", clsConstants.C_V_DGCX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalBFXmkt, strAMOBFXmkt, "", clsConstants.C_V_BFX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_DFM_CASH.toString(), this.getMktStatusDesc(strNormalDFMEQmkt, "", "", clsConstants.C_V_DFM_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_ADX_CASH.toString(), this.getMktStatusDesc(strNormalADXEQmkt, "", "", clsConstants.C_V_ADX_CASH));
                this.dcMarketStatus.Add(clsConstants.C_V_GBOT_DERIVATIVES.toString(), this.getMktStatusDesc(strNormalGBOTmkt, strAMOGBOTmkt, "", clsConstants.C_V_GBOT_DERIVATIVES));
                this.dcMarketStatus.Add("91", this.getMktStatusDesc(strNormalUCXmkt, strAMOUCXmkt, "", clsConstants.C_V_UCX_DERIVATIVES));
                this.dcMarketStatus.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), this.getMktStatusDesc(strNormalNSEOTSmkt, strAMONSEOTSmkt, "", clsConstants.C_V_OFS_IPO_BONDS));
               
              }
             
              //return this.dcMarketStatus.getItem(mktSegmentId.toString());
      
            } catch (error) {
              
              clsGlobal.logManager.writeErrorLog('Order Entry', 'getMarketStatus', error);
            }
          }), error => {
           
          })
       }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatusDictionary()', 'tr_ExchManager.js'.toString(), '');

        }
    }

    getMktStatusColor(sMktStatus) {
        try {
            let sColor = 'Exchange_tile ';
            if (sMktStatus != undefined) {
                if (sMktStatus.toUpperCase() == "OPEN" || sMktStatus.toUpperCase() == "PRE OPEN" || sMktStatus.toUpperCase() == "SPOS OPEN"
                    || sMktStatus.toUpperCase() == "MATCHING OPEN") {
                    sColor += "OPEN";
                }
                else {
                    if (sMktStatus.toUpperCase() == "CLOSE" || sMktStatus.toUpperCase() == "SPOS CLOSE" || sMktStatus.toUpperCase() == "MATCHING CLOSE" || sMktStatus.toUpperCase() == "PRE OPEN ENDED") {
                        sColor += "CLOSE";
                    }
                    else {
                        if (sMktStatus.toUpperCase() == "UNAVAILABLE" || sMktStatus.toUpperCase() == "" ||
                            sMktStatus.toUpperCase() == "-") {
                            sColor += "UNAV";
                        }
                        else {
                            if (sMktStatus.toUpperCase() == "EXTENDED MARKET") {
                                sColor += "EXTMKT";
                            }
                            else {
                                sColor += "AMO";
                            }
                        }
                    }
                }
            }

            return sColor;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetMktStatusColor()', 'tr_ExchManager.js'.toString(), '');

        }
    }

    getMktStatusDesc(sMkt, sAMOMkt, sExtendedMkt, sMaktSegmentId) {
        let sMarketStatus = '';
        if (sAMOMkt == "1") {
            sMarketStatus = "AMO";
        }
        else if (sExtendedMkt == "1") {
            sMarketStatus = "Extended Market";
        }
        else if (sMkt == "1") {
            sMarketStatus = "Open";
        }
        else if (sMkt == "2" || sMkt == "5") {
            sMarketStatus = "Close";
        }
        else if (sMkt == "0") {
            if (sMaktSegmentId == "1" || sMaktSegmentId == "2" || sMaktSegmentId == "3" || sMaktSegmentId == "4" || sMaktSegmentId == "15")
                sMarketStatus = "Pre Open";
            else
                sMarketStatus = "Unavailable";
        }
        else if (sMkt == "3") {
            if (sMaktSegmentId == "1" || sMaktSegmentId == "2" || sMaktSegmentId == "3" || sMaktSegmentId == "4" || sMaktSegmentId == "15")
                sMarketStatus = "Pre Open Ended";
            else
                sMarketStatus = "Unavailable";
        }
        else if (sMkt == "4") {
            sMarketStatus = "Post Closing";
        }

        else if (sMkt == "6" && sMaktSegmentId == clsConstants.C_V_DFM_CASH)
        {
            sMarketStatus = "Pre Closing";
        }
        else if (sMkt == "7" && sMaktSegmentId == clsConstants.C_V_DFM_CASH)
        {
            sMarketStatus = "Closing";
        }

        else {
            sMarketStatus = "Unavailable";
        }

        return sMarketStatus;
    }
    
}


