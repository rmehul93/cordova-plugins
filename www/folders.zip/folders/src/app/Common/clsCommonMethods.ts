import { clsGlobal } from "./clsGlobal";
import { clsConstants } from "./clsConstants";
import { clsScripKey } from './clsScripKey';
import { clsScrip } from "./clsScrip";
import { clsIndexDetail } from "./clsIndexDetails";
import { clsTradingMethods } from "./clsTradingMethods";
import { clsTripleDes } from "./clsTripleDes";
import { clsHttpService } from "./clsHTTPService";
import { Platform } from '@ionic/angular';
//import { PouchCouchServicesProvider } from "../providers/pouch-couch-services/pouch-couch-services";
import { NavigationExtras } from '@angular/router';
declare var window: any;
export class clsCommonMethods {
  public static TripleDESEncrypt(plainText) {
    try {
      //Convert to base64
      //let pass = cryptoJS.enc.Utf8.parse(plainText);
      //let en = cryptoJS.enc.Base64.stringify(pass);
      let bkey = clsGlobal.dConfigMaster.getItem("APP_TRIPLEDES_KEY") || "1234567890";// "1234567890";
      //let encryptedText = cryptoJS.TripleDES.encrypt(plainText, bkey);
      let encryptedText = clsTripleDes.encrypt(bkey, plainText);//Encrypt using TripleDes
      return encryptedText.toString();

    } catch (e) {
      return "";
      //Global.LogManager.WriteLog(e.message, 'TripleDESEncryptOCToken', 'CommonMethods.js', '');
    }
  }

  public static TripleDESDecrypt(plainText) {
    try {
      //Convert to base64
      //let pass = cryptoJS.enc.Utf8.parse(plainText);
      //let en = cryptoJS.enc.Base64.stringify(pass);

      let bkey = "1234567890";
      let encryptedText = clsTripleDes.decrypt(bkey, plainText);//Encrypt using TripleDes
      return encryptedText.toString();

    } catch (e) {
      return "";
      //Global.LogManager.WriteLog(e.message, 'TripleDESEncryptOCToken', 'CommonMethods.js', '');
    }
  }
  public static UrlEncoding(inputString) {
    let encodedInputString = encodeURIComponent(inputString);
    //Following two parameters are not encoded by the in built escape function
    encodedInputString = encodedInputString.replace("+", "%2B");
    encodedInputString = encodedInputString.replace("/", "%2F");
    encodedInputString = encodedInputString.replace("&", "%26");
    return encodedInputString;
  }

  public static DecDigits(_value, _noOfDecimals) {
    let _bIsValidDec = true;
    let _intDecIdx = _value.indexOf(".");
    if (_intDecIdx != -1) {
      _intDecIdx = _value.length - _intDecIdx - 1;
      if (_intDecIdx > _noOfDecimals) _bIsValidDec = false;
    }

    return _bIsValidDec;
  }

  public static isEmpty(input) {
    return !input || !input.trim();
  }

  public static containsScrip(data, strCompare: clsScrip) {
    if (data.filter(x => x.scripDetail.scripDet.token == strCompare.scripDet.token).length > 0)
      return true;
    else
      return false;
  }

  //added to calc day for specified start and end date by vishal on 29JUN2015 -- referred from NewNetNet CR 4524 [001-00-506746]
  //input expected in default date format i.e new Date() returned value
  public static CalculateDays(startDate, endDate) {
    let today = startDate;
    let sExpiry =
      (endDate.getDate().toString().length == 1
        ? "0" + endDate.getDate()
        : endDate.getDate()) +
      this.getAlphaMonth(endDate.getMonth()) +
      endDate.getFullYear();

    let dd = today.getDate();
    let mm = today.getMonth();
    let yyyy = today.getFullYear();

    if (dd < 10) dd = "0" + dd;

    if (mm < 10) mm = "0" + mm;

    if (startDate != undefined && endDate != undefined) {
      let expdd: any = sExpiry.substring(0, 2);
      let expmmm: any = sExpiry.substring(2, 5);
      let expyyyy: any = sExpiry.substring(5);

      let smm: any = this.getNumericMonth(expmmm);

      let oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
      let firstDate = new Date(yyyy, mm, dd);
      let secondDate = new Date(expyyyy, smm, expdd);

      let diffDays = Math.round(
        Math.abs((firstDate.getTime() - secondDate.getTime()) / oneDay)
      );

      return diffDays;
    } else return 0;
  }

  public static getNumericMonth(sMonth) {
    try {
      let sRetval = "";
      switch (sMonth) {
        case "JAN":
          sRetval = "00";
          break;
        case "FEB":
          sRetval = "01";
          break;
        case "MAR":
          sRetval = "02";
          break;
        case "APR":
          sRetval = "03";
          break;
        case "MAY":
          sRetval = "04";
          break;
        case "JUN":
          sRetval = "05";
          break;
        case "JUL":
          sRetval = "06";
          break;
        case "AUG":
          sRetval = "07";
          break;
        case "SEP":
          sRetval = "08";
          break;
        case "OCT":
          sRetval = "09";
          break;
        case "NOV":
          sRetval = "10";
          break;
        case "DEC":
          sRetval = "11";
          break;
      }
      return sRetval;
    } catch (e) { }
  }

  public static getAlphaMonth(sMonth) {
    try {
      let sRetval = "";
      switch (sMonth) {
        case 0:
          sRetval = "Jan";
          break;
        case 1:
          sRetval = "Feb";
          break;
        case 2:
          sRetval = "Mar";
          break;
        case 3:
          sRetval = "Apr";
          break;
        case 4:
          sRetval = "May";
          break;
        case 5:
          sRetval = "Jun";
          break;
        case 6:
          sRetval = "Jul";
          break;
        case 7:
          sRetval = "Aug";
          break;
        case 8:
          sRetval = "Sep";
          break;
        case 9:
          sRetval = "Oct";
          break;
        case 10:
          sRetval = "Nov";
          break;
        case 11:
          sRetval = "Dec";
          break;
      }
      return sRetval;
    } catch (e) { }
  }

  public static getCDSDate(sDate) {
    let _returnDate: string = "";
    //day
    _returnDate = new Date(sDate).getDate().toString();
    //month
    _returnDate =
      _returnDate + "-" + this.getAlphaMonth(new Date(sDate).getMonth());
    //year
    _returnDate = _returnDate + "-" + new Date(sDate).getFullYear();

    return _returnDate;
  }



  public static getAlertsDateTime(sDate){
    let _ampm = new Date(sDate).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(sDate).getMinutes() > 9 ? new Date(sDate).getMinutes().toString() : ('0' + new Date(sDate).getMinutes().toString());
    let _hrs: any = new Date(sDate).getHours() % 12 > 0 ? new Date(sDate).getHours() % 12 : new Date(sDate).getHours();

    let day: any = new Date(sDate).getDate();
    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }

    if (day < 10) {
      day = '0' + day
    }

    return _hrs + ':' + _minutes + ' ' + _ampm  + ', ' + day + ' ' + this.getAlphaMonth(new Date(sDate).getMonth()) + ' `' + new Date(sDate).getFullYear().toString().substring(2, 4);
  } 

  public static getOrderDateTime(sDate) {

    let tempDate = sDate.replace(/[ :]/g, '-').split('-');
    let newDate = tempDate[1]+ '/' + tempDate[2]+ '/' + tempDate[0] + ' ' + tempDate[3]+ ':'+ tempDate[4]+ ':'+tempDate[5];
    let _ampm = new Date(newDate).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(newDate).getMinutes() > 9 ? new Date(newDate).getMinutes().toString() : ('0' + new Date(newDate).getMinutes().toString());
    let _hrs: any = new Date(newDate).getHours() % 12 > 0 ? new Date(newDate).getHours() % 12 : new Date(newDate).getHours();

    let day: any = new Date(newDate).getDate();
    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }

    if (day < 10) {
      day = '0' + day
    }

    return _hrs + ':' + _minutes + ' ' + _ampm
    + ', ' + day + ' ' + this.getAlphaMonth(new Date(sDate).getMonth()) + ' `' + new Date(sDate).getFullYear().toString().substring(2, 4);
  }



  public static getTradeTime(sDate) {
    let _returnTime: string = "";

    let tempDate = sDate.replace(/[ :]/g, '-').split('-');
    let newDate = tempDate[1]+ '/' + tempDate[2]+ '/' + tempDate[0] + ' ' + tempDate[3]+ ':'+ tempDate[4]+ ':'+tempDate[5];
    let _ampm = new Date(newDate).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(newDate).getMinutes() > 9 ? new Date(newDate).getMinutes().toString() : ('0' + new Date(newDate).getMinutes().toString());
    let _hrs: any = new Date(newDate).getHours() % 12 > 0 ? new Date(newDate).getHours() % 12 : new Date(newDate).getHours();

    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }

    _returnTime = _hrs + ':' + _minutes + ' ' + _ampm

    return _returnTime;
  }
  public static ConvertToDateObj(seconds) {
    let _returnTime: string = "";
    var d1 = new Date("01/01/1980 00:00:00");
    d1.setSeconds(seconds);
    //console.log(d1);
    let _ampm = new Date(d1).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(d1).getMinutes() > 9 ? new Date(d1).getMinutes().toString() : ('0' + new Date(d1).getMinutes().toString());
    let _hrs: any = new Date(d1).getHours() % 12 > 0 ? new Date(d1).getHours() % 12 : new Date(d1).getHours();

    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }
    _returnTime = _hrs + ':' + _minutes
    return _returnTime;
  }

  public static ConvertToDateObjAmPM(seconds) {
    let _returnTime: string = "";
    var d1 = new Date("01/01/1980 00:00:00");
    d1.setSeconds(seconds);
    //console.log(d1);
    let _ampm = new Date(d1).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(d1).getMinutes() > 9 ? new Date(d1).getMinutes().toString() : ('0' + new Date(d1).getMinutes().toString());
    let _hrs: any = new Date(d1).getHours() % 12 > 0 ? new Date(d1).getHours() % 12 : new Date(d1).getHours();

    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }
    _returnTime = _hrs + ':' + _minutes +" "+ _ampm
    return _returnTime;
  }
  public static getTradeTimeForChart(sDate) {
    let _returnTime: string = "";

    let _ampm = new Date(sDate).getHours() >= 12 ? 'PM' : 'AM';
    let _minutes = new Date(sDate).getMinutes() > 9 ? new Date(sDate).getMinutes().toString() : ('0' + new Date(sDate).getMinutes().toString());
    let _hrs: any = new Date(sDate).getHours() % 12 > 0 ? new Date(sDate).getHours() % 12 : new Date(sDate).getHours();

    if (_hrs < 10) {
      _hrs = '0' + _hrs;
    }

    _returnTime = _hrs + ':' + _minutes

    return _returnTime;
  }

  public static getNumberWithCurrencyFormat(sNumber: string) {
    return Number(sNumber).toLocaleString('en-IN', { minimumFractionDigits: 2 })
  }

  //+ " `" + arr[0].substr(2, 2)
  public static getFormattedExpirydate(sDate) {

    let arr = sDate.split('-');

    return arr[2] + " " + this.getMonthFormat(arr[1]) + "'" + arr[0].substr(-2); 


  }
  // To check login allowed or Not, market Segment Wise. By Akshay
  public static isLoginAllowed(SegmentId) {
    if (
      clsGlobal.ExchManager.loginAllowed.getItem(SegmentId) == "OFF" ||
      SegmentId == "" ||
      SegmentId == undefined ||
      isNaN(SegmentId) ||
      SegmentId == clsConstants.C_V_MCX_SPOT ||
      SegmentId == clsConstants.C_V_NCDEX_SPOT ||
      SegmentId == clsConstants.C_V_NSEL_SPOT ||
      SegmentId == clsConstants.C_V_MSX_SPOT ||
      SegmentId == clsConstants.C_V_UCX_SPOT ||
      SegmentId == clsConstants.C_V_DGCX_SPOT ||
      SegmentId == clsConstants.C_V_BFX_SPOT ||
      SegmentId == clsConstants.C_V_NSX_SPOT ||
      SegmentId == clsConstants.C_V_BSECDX_SPOT
    ) {
      //Global.Popup.showAlert("Order Error!", "You are currently not allowed to place/modify/cancel order in this segment", null);

      return false;
    } else {
      return true;
    }
  }

  public static isAllowedClientFacility(segmentId, mappedSegId) {
    let isAllowed = true;
    isAllowed = this.isMktDataAllowed(segmentId);
    if (isAllowed && clsGlobal.User.cftAllowed != undefined && clsGlobal.User.cftAllowed != '-1') {
      if ((clsGlobal.User.cftAllowed & parseInt(mappedSegId, 10)) !== parseInt(mappedSegId, 10)) {
        isAllowed = false;
      }
      else {
        isAllowed = true;
      }
    }
    return isAllowed;
  }



  public static isMktDataAllowed(SegmentId) {
    var isMarketAllowed = false;
    var strSegmentStatus = clsGlobal.ExchManager.exchangeAllowed.getItem(SegmentId);
    if (strSegmentStatus == clsConstants.C_S_ON)
      isMarketAllowed = true;

    return isMarketAllowed;
  }

  public static changeDateFormat(DateArray, DateStartsWith, YearSpliterIndex) {
    let strDate = "";
    let changedDateFormat = [];
    for (let i = 0; i < DateArray.length; i++) {
      strDate = "";
      let strYear = "";
      let strMonth = "";
      strDate = DateArray[i];

      //Checks weather array item contains date format or not.
      if (strDate.startsWith(DateStartsWith)) {
        strYear = strDate.split(DateStartsWith)[1].slice(0, -2);
        strMonth = clsCommonMethods.getMonthFormat(
          strDate.split(DateStartsWith)[1].split(strYear)[1]
        );

        changedDateFormat.push({
          DateId: strDate,
          Date: strMonth + " " + strYear
        });
      }
    }
    return changedDateFormat;
  }

  public static getMonthFormat(strMonth) {
    switch (strMonth) {
      case clsConstants.C_V_MONTH_JAN:
        strMonth = clsConstants.C_S_MONTH_JAN;
        break;
      case clsConstants.C_V_MONTH_FEB:
        strMonth = clsConstants.C_S_MONTH_FEB;
        break;
      case clsConstants.C_V_MONTH_MARCH:
        strMonth = clsConstants.C_S_MONTH_MARCH;
        break;
      case clsConstants.C_V_MONTH_APRIL:
        strMonth = clsConstants.C_S_MONTH_APRIL;
        break;
      case clsConstants.C_V_MONTH_MAY:
        strMonth = clsConstants.C_S_MONTH_MAY;
        break;
      case clsConstants.C_V_MONTH_JUNE:
        strMonth = clsConstants.C_S_MONTH_JUNE;
        break;
      case clsConstants.C_V_MONTH_JULY:
        strMonth = clsConstants.C_S_MONTH_JULY;
        break;
      case clsConstants.C_V_MONTH_AUG:
        strMonth = clsConstants.C_S_MONTH_AUG;
        break;
      case clsConstants.C_V_MONTH_SEPT:
        strMonth = clsConstants.C_S_MONTH_SEPT;
        break;
      case clsConstants.C_V_MONTH_OCT:
        strMonth = clsConstants.C_S_MONTH_OCT;
        break;
      case clsConstants.C_V_MONTH_NOV:
        strMonth = clsConstants.C_S_MONTH_NOV;
        break;
      case clsConstants.C_V_MONTH_DEC:
        strMonth = clsConstants.C_S_MONTH_DEC;
        break;
      default:
        strMonth;
    }
    return strMonth;
  };

  public static getScripObject(scrip) {


    let objScrpKey = new clsScripKey();

    objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(parseInt(scrip.nMarketSegmentId));
    objScrpKey.token = scrip.nToken;

    let scripInfo: clsScrip = new clsScrip();
    scripInfo.scripDet = objScrpKey;
    scripInfo.symbol = scrip.sSymbol.trim();
    scripInfo.Series = scrip.sSeries;
    scripInfo.DecimalLocator = scrip.nPriceBdAttribute == "0" ? "100" : scrip.nPriceBdAttribute;
    scripInfo.InstrumentName = scrip.sInstrumentName.trim();
    scripInfo.ExpiryDate = (scrip.nExpiryDate != null && scrip.nExpiryDate.toString() != "" && scrip.nExpiryDate.toString() != "0") ? clsTradingMethods.convertToDate(scrip.nExpiryDate, undefined) : "0";
    scripInfo.OptionType = scrip.sOptionType;
    scripInfo.MarketLot = scrip.nRegularLot || scrip.nRegularLot[0];
    scripInfo.PriceTick = scrip.nPriceTick;
    scripInfo.SecurityDesc = scrip.sSecurityDesc.trim();
    scripInfo.MWSecurityDesc = scrip.sSecurityDesc.trim();
    scripInfo.StrikePrice = scrip.nStrikePrice1.trim().toString();
    scripInfo.ISIN = scrip.sISINCode;
    scripInfo.SPOS = "";
    scripInfo.POS = "";
    scripInfo.Spread = scrip.nSpread;
    //scripInfo.Quantity = scrip.nRegularLot;
    scripInfo.AssetToken = scrip.nAssetToken;
    scripInfo.FIILimit = scrip.nFIILimit;
    scripInfo.NRILimit = scrip.nNRILimit;
    scripInfo.NRILimit = scrip.nNRILimit;
    scripInfo.FOExists = scrip.nFOExists;
    scripInfo.MarginTypeIndicator = scrip.nMarginTypeIndicator;
    if (scrip.sInstrumentName.indexOf('IDX') != -1) {
      scripInfo.isIndex = true;
    }
    else {
      scripInfo.isIndex = false;
    }

    scripInfo.formatScripDisplayName()

    let idData = new clsIndexDetail();
    idData.scripDetail = scripInfo;
    return idData;
  }
  public static getScripObjectForWatchList(scrip) {


    let objScrpKey = new clsScripKey();

    if (scrip.nMarketSegmentId != undefined) {
      objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(parseInt(scrip.nMarketSegmentId));
    }
    else {
      objScrpKey.MktSegId = parseInt(scrip.nSegmentId);
    }
    //objScrpKey.MktSegId = (parseInt(scrip.nSegmentId || scrip.nMarketSegmentId));
    objScrpKey.token = scrip.nToken;

    let scripInfo: clsScrip = new clsScrip();
    scripInfo.scripDet = objScrpKey;
    scripInfo.symbol = scrip.sSymbol.trim();
    scripInfo.Series = scrip.sSeries;
    scripInfo.DecimalLocator = scrip.nPriceBdAttribute == "0" ? "100" : scrip.nPriceBdAttribute;
    scripInfo.InstrumentName = scrip.sInstrumentName.trim();
    scripInfo.ExpiryDate = (scrip.nExpiryDate != null && scrip.nExpiryDate.toString() != "" && scrip.nExpiryDate.toString() != "0") ? clsTradingMethods.convertToDate(scrip.nExpiryDate, undefined) : "0";
    scripInfo.OptionType = scrip.sOptionType;
    scripInfo.MarketLot = scrip.nRegularLot;
    scripInfo.PriceTick = scrip.nPriceTick;
    scripInfo.SecurityDesc = scrip.sSecurityDesc;
    scripInfo.MWSecurityDesc = scrip.sSecurityDesc;
    scripInfo.StrikePrice = (scrip.nStrikePrice1 == undefined) ? scrip.nStrikePrice.toString() : scrip.nStrikePrice1.toString();
    scripInfo.ISIN = scrip.sISINCode;
    scripInfo.SPOS = "";
    scripInfo.POS = "";
    //scripInfo.Quantity = scrip.nRegularLot;
    scripInfo.AssetToken = scrip.nAssetToken;
    scripInfo.FIILimit = scrip.nFIILimit;
    scripInfo.NRILimit = scrip.nNRILimit;
    scripInfo.MarginTypeIndicator = scrip.nMarginTypeIndicator;
    if (scrip.sInstrumentName.indexOf('IDX') != -1) {
      scripInfo.isIndex = true;
    }
    else {
      scripInfo.isIndex = false;
    }
    if (scrip.nIsIndex != undefined) {
      scripInfo.spotIndex = scrip.nIsIndex;
    }
    else {
      scripInfo.spotIndex = 0;
    }
    scripInfo.formatScripDisplayName()
    let idData = new clsIndexDetail();
    idData.scripDetail = scripInfo;
    return idData;
  }

  /* This is hexadecimal userid as per old logic same is required for */
  public static EncrypQueryString(strUserId: string) {
    let ch = "";
    for (var i = 0; i < strUserId.length; i++) {
      let a: any = strUserId.charCodeAt(i);
      let b: any = 111;
      let orComputed: any = a ^ b;
      ch = ch + this.ToHexadecimal(orComputed);
    }
    console.log(ch);
    return ch;
  }

  public static getExchangeName(segmentid: string) {
    let intMktSegId = parseInt(segmentid);
    var strExName = "";

    switch (intMktSegId) {
      case clsConstants.C_V_NSE_CASH:
        strExName = clsConstants.C_S_NSE_EQ_API_NAME;
        break;
      case clsConstants.C_V_NSE_DERIVATIVES:
        strExName = clsConstants.C_S_NSE_DERV_API_NAME;
        break;
      case clsConstants.C_V_BSE_CASH:
        strExName = clsConstants.C_S_BSE_EQ_API_NAME;
        break;
      case clsConstants.C_V_BSE_DERIVATIVES:
        strExName = clsConstants.C_S_BSE_DERV_API_NAME;
        break;
      case clsConstants.C_V_MCX_DERIVATIVES:
        strExName = clsConstants.C_S_MCX_FUTURES_API_NAME;
        break;
      case clsConstants.C_V_MCX_SPOT:
        strExName = clsConstants.C_S_MCX_SPOT;
        break;
      case clsConstants.C_V_NCDEX_DERIVATIVES:
        strExName = clsConstants.C_S_NCDEX_FUTURES_API_NAME;
        break;
      case clsConstants.C_V_NCDEX_SPOT:
        strExName = clsConstants.C_S_NCDEX_SPOT;
        break;
      case clsConstants.C_V_MSX_DERIVATIVES:
        strExName = clsConstants.C_S_MCXSX_CURR;
        break;
      case clsConstants.C_V_MSX_CASH:
        strExName = clsConstants.C_S_MCXSX_EQ;
        break;
      case clsConstants.C_V_MSX_FAO:
        strExName = clsConstants.C_S_MCXSX_DERV;
        break;
      case clsConstants.C_V_MSX_SPOT:
        strExName = clsConstants.C_S_MCXSX_SPOT;
        break;
      case clsConstants.C_V_NSX_DERIVATIVES:
        strExName = clsConstants.C_S_NSX_DERV;
        break;
      case clsConstants.C_V_NSX_SPOT:
        strExName = clsConstants.C_S_NSX_SPOT;
        break;
      case clsConstants.C_V_BSECDX_DERIVATIVES:
        strExName = clsConstants.C_S_BSECDX_DERV;
        break;
      case clsConstants.C_V_BSECDX_SPOT:
        strExName = clsConstants.C_S_BSECDX_SPOT;
        break;

    }
    return strExName.trim();
  }

  public static getAssetExchangeName(segmentid: string) {
    let intMktSegId = parseInt(segmentid);
    var strExName = "";

    switch (intMktSegId) {
      case clsConstants.C_V_NSE_CASH:
      case clsConstants.C_V_NSE_DERIVATIVES:
        strExName = clsConstants.C_S_NSE_EQ_API_NAME;
        break;
      case clsConstants.C_V_BSE_CASH:
      case clsConstants.C_V_BSE_DERIVATIVES:
        strExName = clsConstants.C_S_BSE_EQ_API_NAME;
        break;
      case clsConstants.C_V_MCX_SPOT:
      case clsConstants.C_V_MCX_DERIVATIVES:
        strExName = clsConstants.C_S_MCX_SPOT;
        break;
      case clsConstants.C_V_NCDEX_SPOT:
      case clsConstants.C_V_NCDEX_DERIVATIVES:
        strExName = clsConstants.C_S_NCDEX_SPOT;
        break;
      case clsConstants.C_V_MSX_CASH:
      case clsConstants.C_V_MSX_FAO:
        strExName = clsConstants.C_S_MCXSX_EQ;
        break;
      case clsConstants.C_V_MSX_SPOT:
      case clsConstants.C_V_MSX_DERIVATIVES:
        strExName = clsConstants.C_S_MCXSX_SPOT;
        break;
      case clsConstants.C_V_NSX_SPOT:
      case clsConstants.C_V_NSX_DERIVATIVES:
        strExName = clsConstants.C_S_NSX_SPOT;
        break;
      case clsConstants.C_V_BSECDX_SPOT:
      case clsConstants.C_V_BSECDX_DERIVATIVES:
        strExName = clsConstants.C_S_BSECDX_SPOT;
        break;

    }
    return strExName.trim();
  }



  public static ToHexadecimal(n: number) {
    let result = "";
    let r: number = 0;
    if (n == 0) return "";
    else {
      r = parseInt((n % 16).toString());
      n = parseInt((n / 16).toString());

      this.ToHexadecimal(n);
      switch (r) {
        case 10:
          result = n + "A";
          break;
        case 11:
          result = n + "B";
          break;
        case 12:
          result = n + "C";
          break;
        case 13:
          result = n + "D";
          break;
        case 14:
          result = n + "E";
          break;
        case 15:
          result = n + "F";
          break;
        default:
          result = n + "" + r;
          break;
      }
      return result;
    }
  }


  // public static getScripObjectCds(scrip, mktSegmentId) {


  //   let objScrpKey = new clsScripKey();

  //   objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(parseInt(mktSegmentId));
  //   let scripDataCMOT = objScrpKey.MktSegId == clsConstants.C_V_NSE_CASH ? scrip.ScripData_NSE : scrip.ScripData_BSE;
  //   objScrpKey.token = scripDataCMOT.ODINCode;


  //   let objScrip = new clsScrip();
  //   objScrip.scripDet = objScrpKey;
  //   objScrip.symbol = scripDataCMOT.Symbol.toString().trim();
  //   //objScrip.ExchangeName = '';
  //   //objScrip.InstrumentName = scripDataCMOT.InstrumentName.toString().trim(); //'EQUITIES';
  //   //objScrip.ExpiryDate = scripDataCMOT.ExpiryDate.toString().trim();
  //   objScrip.Series = scripDataCMOT.Series.toString().trim();
  //   //objScrip.ExchangeName = clsTradingMethods.getExchangeName(mktSegmentId);
  //   objScrip.MarketLot = 1;
  //   objScrip.PriceTick = 1;
  //   objScrip.DecimalLocator = "100";
  //   objScrip.formatScripDisplayName();

  //   let idData = new clsIndexDetail();
  //   idData.scripDetail = objScrip;

  //   return idData;
  // }

  public static getScripSegmentType(mktSegmentId: number): boolean {
    let isEqDervSegment: boolean = true;
    try {

      if (mktSegmentId == clsConstants.C_V_NSE_CASH || mktSegmentId == clsConstants.C_V_BSE_CASH ||
        mktSegmentId == clsConstants.C_V_MSX_CASH || mktSegmentId == clsConstants.C_V_NSE_DERIVATIVES ||
        mktSegmentId == clsConstants.C_V_MSX_FAO || mktSegmentId == clsConstants.C_V_BSE_DERIVATIVES) {
        isEqDervSegment = true;
      } else {
        isEqDervSegment = false;
      }

    } catch (error) {

    }

    return isEqDervSegment;

  }

  // View Port changes
  // public static isScrolledIntoView(elem, id) {

  //     if (elem == null) {
  //         return false;
  //     }

  //     let docViewTop = id.contentTop;
  //     let docViewBottom = docViewTop + id.contentHeight;

  //     let elemTop = elem.offsetTop;

  //     let elemBottom = elemTop + elem.offsetHeight;

  //     return (docViewBottom >= elemTop && docViewTop <= elemBottom);
  // }

  public static isScrolledIntoView(docViewTop, docViewBottom, elemTop, elemBottom) {

    let isInView = (docViewTop <= elemBottom && elemBottom <= docViewBottom) ||
      (docViewTop <= elemTop && elemTop <= docViewBottom);
    return (docViewBottom >= elemTop && docViewTop <= elemBottom);
  }
  /**Array chunk based on size usefull in two or more column display in ng-repeat.
   * create by omprakash on 26 march .
   * @param arr
   * @param size
   */
  public static arrayChunk(arr, size) {
    var newArr = [];
    for (var i = 0; i < arr.length; i += size) {
      newArr.push(arr.slice(i, i + size));
    }
    return newArr;
  }

  public static subscribePushTopic(httpService: clsHttpService, isRegistered: boolean, platform: Platform, response: any) {
    try {

      httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getFCMUserTopicDetails').subscribe(((respData: any) => {
        if (respData.status) {
          //console.log(respData.status)
          let dataResultarr = respData.result;
          let _fcmTopicListSelected: any = [];
          let _fcmTopicListUnSelected: any = [];
          let topicList: any = [];

          if (isRegistered) {

            //pouchcouch.getLocalDataByDocId(clsGlobal.User.userId).then((response: any) => {
            if (response != undefined && response.preferencedoc != undefined) {
              let subTopicList = response.preferencedoc[0].FCMTopicList;

              for (let i = 0; i < dataResultarr.length; i++) {
                if (dataResultarr[i].bSystemDefined != 1 ||
                  dataResultarr[i].sTopicName.toLowerCase() == "registered".toLowerCase()) {
                  topicList.push({
                    TopicNo: dataResultarr[i].nTopicNo,
                    TopicName: dataResultarr[i].sTopicName,
                    TopicDisplayName: dataResultarr[i].sTopicDisplayName,
                    bIsCompalsary: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false,
                    bIsDisplay: parseInt(dataResultarr[i].bIsDisplay) > 0 ? true : false,
                    //if topic is compalsory we will set selected by default
                    Selected: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : (subTopicList != undefined && subTopicList.includes(dataResultarr[i].nTopicNo)) ? true : false
                  });
                }
              }

              topicList.forEach(element => {
                if (element.Selected) {
                  _fcmTopicListSelected.push(element);
                }
                else {
                  _fcmTopicListUnSelected.push(element);
                }
              });

              clsGlobal.pubsub.publish('TOPIC:CHANGED', { Sub: _fcmTopicListSelected, Unsub: _fcmTopicListUnSelected });
              //});
            }
          }
          /*
          else {
            for (let i = 0; i < dataResultarr.length; i++) {
              if (dataResultarr[i].bSystemDefined == 1) {

                let topicName = dataResultarr[i].sTopicName;

                if (platform.is('android') && topicName.indexOf('ios') >= 0) {
                  continue;
                }
                if (platform.is('iphone') && topicName.indexOf('android') >= 0) {
                  continue;
                }

                if (topicName.toLowerCase() == "registered".toLowerCase())
                  continue;

                _fcmTopicListSelected.push({
                  TopicNo: dataResultarr[i].nTopicNo,
                  TopicName: dataResultarr[i].sTopicName,
                  TopicDisplayName: dataResultarr[i].sTopicDisplayName,
                  bIsCompalsary: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false,
                  bIsDisplay: parseInt(dataResultarr[i].bIsDisplay) > 0 ? true : false,
                  //if topic is compalsory we will set selected by default
                  Selected: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : topicList.includes(dataResultarr[i].nTopicNo) ? true : false
                });
              } else {
                _fcmTopicListUnSelected.push({
                  TopicNo: dataResultarr[i].nTopicNo,
                  TopicName: dataResultarr[i].sTopicName,
                  TopicDisplayName: dataResultarr[i].sTopicDisplayName,
                  bIsCompalsary: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false,
                  bIsDisplay: parseInt(dataResultarr[i].bIsDisplay) > 0 ? true : false,
                  //if topic is compalsory we will set selected by default
                  Selected: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : topicList.includes(dataResultarr[i].nTopicNo) ? true : false
                })
              }
            }

            clsGlobal.pubsub.publish('TOPIC:CHANGED', { Sub: _fcmTopicListSelected, Unsub: _fcmTopicListUnSelected });

          }
           */

        }
        else {
          clsGlobal.logManager.writeErrorLog('clsCommonMethods', 'service subscribePushTopic', "stp return 0 records.");
        }
      }), error => {
        clsGlobal.logManager.writeErrorLog('clsCommonMethods', 'service subscribePushTopic', error);
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('clsCommonMethods', 'service subscribePushTopic', error);
    }
  }

  public static getRecoDateTime(sDate) {
    let _returnDate: string = "";
    try {


      //day
      _returnDate = new Date(sDate).getDate().toString();
      //month
      _returnDate =
        _returnDate + "-" + this.getAlphaMonth(new Date(sDate).getMonth());
      //year
      _returnDate = _returnDate + "-" + new Date(sDate).getFullYear();

      //Hours
      _returnDate = _returnDate + " " + new Date(sDate).getUTCHours() + ":" + new Date(sDate).getUTCMinutes();
    } catch (error) {
      _returnDate = "";
      clsGlobal.logManager.writeErrorLog('clsCommonMethods', 'getRecoDateTime', error);
    }
    return _returnDate;
  }

  /**
   * 
   * @param data: data that will be formatted for passing to another page. 
   */
  public static formatNavigationParam(objParam) {
    try {
      let navigationObj: NavigationExtras = {
        state: {
          data: objParam
        }
      };
      return navigationObj

    } catch (error) {
      return null;
    }
  }

  /**
   * Sonali Dongare
   * Desc : To calculate the difference between user registration date to currentdate
   * @param currentdate : User current date of login
   */
  public static dateDifferenceInDay(currentdate, guestRegisteredDate) {
    var t = currentdate.getTime() - guestRegisteredDate;//.getTime(); 
    var day = t / (1000 * 3600 * 24);
    return Math.round(day);
  }

  public static EncodeToBase64 = function (strVal) {
    var Base64 = { _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) { var t = ""; var n, r, i, s, o, u, a; var f = 0; e = Base64._utf8_encode(e); while (f < e.length) { n = e.charCodeAt(f++); r = e.charCodeAt(f++); i = e.charCodeAt(f++); s = n >> 2; o = (n & 3) << 4 | r >> 4; u = (r & 15) << 2 | i >> 6; a = i & 63; if (isNaN(r)) { u = a = 64 } else if (isNaN(i)) { a = 64 } t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a) } return t }, decode: function (e) { var t = ""; var n, r, i; var s, o, u, a; var f = 0; e = e.replace(/[^A-Za-z0-9\+\/\=]/g, ""); while (f < e.length) { s = this._keyStr.indexOf(e.charAt(f++)); o = this._keyStr.indexOf(e.charAt(f++)); u = this._keyStr.indexOf(e.charAt(f++)); a = this._keyStr.indexOf(e.charAt(f++)); n = s << 2 | o >> 4; r = (o & 15) << 4 | u >> 2; i = (u & 3) << 6 | a; t = t + String.fromCharCode(n); if (u != 64) { t = t + String.fromCharCode(r) } if (a != 64) { t = t + String.fromCharCode(i) } } t = Base64._utf8_decode(t); return t }, _utf8_encode: function (e) { e = e.replace(/\r\n/g, "\n"); var t = ""; for (var n = 0; n < e.length; n++) { var r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r) } else if (r > 127 && r < 2048) { t += String.fromCharCode(r >> 6 | 192); t += String.fromCharCode(r & 63 | 128) } else { t += String.fromCharCode(r >> 12 | 224); t += String.fromCharCode(r >> 6 & 63 | 128); t += String.fromCharCode(r & 63 | 128) } } return t }, _utf8_decode: function (e) { var t = ""; var n = 0; var r = 0; var c1 = 0; var c2 = 0; var c3 = 0; while (n < e.length) { r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r); n++ } else if (r > 191 && r < 224) { c2 = e.charCodeAt(n + 1); t += String.fromCharCode((r & 31) << 6 | c2 & 63); n += 2 } else { c2 = e.charCodeAt(n + 1); c3 = e.charCodeAt(n + 2); t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63); n += 3 } } return t } }
    return Base64.encode(strVal);
  };

  public static sortArray(array: any, type: any, field: any, orderDesc: any) {

    if (array != undefined) {
      array.sort((a: any, b: any) => {
        if (type == 'S') {
          if (a[field] < b[field]) {
            return (orderDesc) ? 1 : -1;
          } else if (a[field] > b[field]) {
            return (orderDesc) ? -1 : 1;
          } else {
            return 0;
          }
        }
        else {
          if (parseFloat(a[field]) < parseFloat(b[field])) {
            return (orderDesc) ? 1 : -1;
          } else if (parseFloat(a[field]) > parseFloat(b[field])) {
            return (orderDesc) ? -1 : 1;
          } else {
            return 0;
          }
        }

      });
      return array;
    }
  }
  public static getFormattedDays(day): any {
    let retDays = '';
    if (day.toString().length < 2) {
      retDays = '0' + day;
    } else {
      retDays = day;
    }
    return retDays;
  }


  //Method to display value in K and Cr. format
  public static kFormatter(value) {
    try {
      let num = parseFloat(value);
      let digits = 1;
      var si = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E5, symbol: "Lac" },
        { value: 1E7, symbol: "Cr." },
        { value: 1E12, symbol: "Cr." },
        { value: 1E15, symbol: "Cr." },
        { value: 1E18, symbol: "Cr." }
      ];
      var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
      var i;
      for (i = si.length - 1; i > 0; i--) {
        if (num >= si[i].value) {
          break;
        }
      }
      return (num / si[i].value).toFixed(digits).replace(rx, "$1") + ' ' + si[i].symbol;
    } catch (error) {
      console.log("Error in k commom methods. " + error);
      return "0.00";
    }
  }


  public static EncryptString(sDataToEncrypt, size = undefined) {
    try {
      // Text to encrypt.
      var pwd = sDataToEncrypt;
      var sEncryptedData;
      // Use OAEP padding (PKCS#1 v2).
      var doOaepPadding = true;
      // RSA 512-bit key: Public (Modulus), Private (D) and CRT (P, Q, DP, DQ, InverseQ).
      var xmlParams =
        "<RSAKeyValue>" +
        "<Modulus>lnLDMeWvTgO17E50M5DQ1dbMLMKfOv2YclgyJIs+6Bls+/0ngDiLtROdMYBftJwQYD8g9OSJ5p2uMxVFucSFOG9Cwjy2g5+yw910TIYIVrmB3mHV8U9yoVNYq8ZXoc/r/MnCNDsnJv4HBeP4HcSM7IlyIYFX64HPJDztuimqUFs=</Modulus>" +
        "<Exponent>AQAB</Exponent>" +
        "<P>y/p1jfwg4RiabQ6gBkRliYCsQ+zaU4miKFNr1SXLwpH8Ia5TAG5yKU//0dekq4wlYmrvaW/J2FgoL4NUxFPwPQ==</P>" +
        "<Q>vNFhIFKITGZtYBvEZFEunnx/+yVMk2GOEN2tqWklWys3tOnyjyvK45qXunIMMJNK9tZeP0CwVAtMohKv95J0dw==</Q>" +
        "<DP>nxNWtkJYyfNMC50KQ5j3rsKAlgCTS+7cXaKhR/tP6w+6l/HBnWaE9Z8EHPyV2YtUZGqNB6c8vNITlOpRI0Nq6Q==</DP>" +
        "<DQ>u31daG8LkHGU4f4wgTxrgkw1+PgMlbwlCXJV4wbZZTIA2tADX08o4+C6ERT2LbXUlk4+v6hIbuvZaIYN3VO7+Q==</DQ>" +
        "<InverseQ>DSKvNnM0wLqBUsB4vG/JMR4rBOAjquj9+u3F1oJ//vLH/NL+dyB4MTNYfWht0kztMMd1qr0bjn2x90TmQuhvkg==</InverseQ>" +
        "</RSAKeyValue>";
      // ------------------------------------------------
      // RSA Keys
      // ------------------------------------------------
      var rsa;
      if (size != undefined) {
        // doOaepPadding = false;
        rsa = new window.System.Security.Cryptography.RSACryptoServiceProvider();
      }
      else
        rsa = new window.System.Security.Cryptography.RSACryptoServiceProvider();
      // Import parameters from XML string.
      rsa.FromXmlString(xmlParams);
      // Export RSA key to RSAParameters and include:
      //    false - Only public key required for encryption.
      //    true  - Private key required for decryption.
      // Export parameters and include only Public Key (Modulus + Exponent) required for encryption.
      var rsaParamsPublic = rsa.ExportParameters(false);
      // Export Public Key (Modulus + Exponent) and include Private Key (D) required for decryption.
      //var rsaParamsPrivate = rsa.ExportParameters(true);
      // ------------------------------------------------
      // Encrypt Password
      // ------------------------------------------------
      var decryptedPwdBytes = window.System.Text.Encoding.UTF8.GetBytes(pwd);
      // Create a new instance of RSACryptoServiceProvider.
      //rsa = new System.Security.Cryptography.RSACryptoServiceProvider();
      if (size != undefined) {
        //  doOaepPadding = false;
        rsa = new window.System.Security.Cryptography.RSACryptoServiceProvider();
      }
      else
        rsa = new window.System.Security.Cryptography.RSACryptoServiceProvider();
      // Import the RSA Key information.
      rsa.ImportParameters(rsaParamsPublic);
      // Encrypt byte array.
      var encryptedPwdBytes = rsa.Encrypt(decryptedPwdBytes, doOaepPadding);
      // Convert bytes to base64 string.
      var encryptedPwd = window.System.Convert.ToBase64String(encryptedPwdBytes);
      sEncryptedData = encryptedPwd;
      return sEncryptedData;
    } catch (error) {
      console.log("Error in RSA encryption." + error);
      return '';
    }
  }

  public static ImpliedVolatility(nIndexPrice, nStrikePrice, nInterestRate, nExpiryDays, nPrice, nCallOrPut) {
    // Bhushit A for CR1082 001-00-365412/001-00-345355: Buy & Sell Volatility  problem in Odin Client. on 5Feb13
    if (nIndexPrice <= 0) {
      return 0.0;
    }
    // Bhushit A for CR1082 001-00-345355: Buy & Sell Volatility  problem in Odin Client. on 5Feb13 End 

    let lnLowSigma = 0.0001;
    let lnPrice = 0.0;
    if (nCallOrPut == 'CALL') {
      lnPrice = clsCommonMethods.CallOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnLowSigma, nExpiryDays);
    }
    if (nCallOrPut == 'PUT') {
      lnPrice = clsCommonMethods.PutOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnLowSigma, nExpiryDays);
    }
    if (lnPrice > nPrice) {
      return 0.0;
    }


    let lnAccuracy = 1.0e-10/*4*//*2*/; // make this smaller for higher accuracy
    let lnMaxIterations = 100;
    let lnHighValue = 1e10;
    let lnError = 0;

    // want to bracket sigma. first find a maximum sigma by finding a sigma
    // with a estimated lnPrice higher than the actual lnPrice.

    let lnSigmaHigh = 0.3;
    if (nCallOrPut == 'CALL') {
      lnPrice = clsCommonMethods.CallOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigmaHigh, nExpiryDays);
    }
    if (nCallOrPut == 'PUT') {
      lnPrice = clsCommonMethods.PutOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigmaHigh, nExpiryDays);
    }
    while (lnPrice < nPrice) {
      lnSigmaHigh = 2.0 * lnSigmaHigh; // keep doubling.
      if (nCallOrPut == 'CALL') {
        lnPrice = clsCommonMethods.CallOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigmaHigh, nExpiryDays);
      }
      if (nCallOrPut == 'PUT') {
        lnPrice = clsCommonMethods.PutOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigmaHigh, nExpiryDays);
      }
      if (lnSigmaHigh > lnHighValue) {
        return lnError; // 
      }
    }

    for (let i = 0; i < lnMaxIterations; i++) {
      let lnSigma = (lnLowSigma + lnSigmaHigh) * 0.5;
      if (nCallOrPut == 'CALL') {
        lnPrice = clsCommonMethods.CallOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigma, nExpiryDays);
      }
      if (nCallOrPut == 'PUT') {
        lnPrice = clsCommonMethods.PutOptionValue(nIndexPrice, nStrikePrice, nInterestRate, lnSigma, nExpiryDays);
      }
      //fabs
      let lnTest = (lnPrice - nPrice);
      if (Math.abs(lnTest) < lnAccuracy) {
        return lnSigma;
      }
      if (lnTest < 0.0) {
        lnLowSigma = lnSigma;
      }
      else {
        lnSigmaHigh = lnSigma;
      }
    }
    return lnError;
  }

  public static CallOptionValue(nIndexPrice, nStrikePrice, nInterestRate, nHighSigma, nExpiryDays) {
    let lnCall = 0.0,
      lnIndexPrice = 0.0, lnStrikePrice = 0.0, lnVolatility = 0.0,
      lnInterestRate = 0.0, lnDaysUntilExpiry = 0.0;
    let lnD1 = 0.0, lnD2 = 0.0;
    let lnStdNormalD1 = 0.0, lnStdNormalD2 = 0.0;

    lnIndexPrice = nIndexPrice;
    lnStrikePrice = nStrikePrice;
    lnInterestRate = nInterestRate / 100.00;
    lnDaysUntilExpiry = nExpiryDays / 365.0;
    lnVolatility = nHighSigma / 100.00;

    /*
    The Following Steps are required to Calculate the Black & Scholes Model
    Steps :
    lnD1 = (LN(IndexPrice/StrikePrice) + (InterestRate + pow(volatilty, 2)/2)*daysUntilExpiry )/ Volatility*pow((DaysUntilExpiry), 1/2)
    lnD2 = lnD1 - Volatility*pow((DaysUntilExpiry), 1/2)
    Call = IndexPrice * N(lnD1) - StrikePrice * EXP(-InterestRate*DaysUntilExpiry) * N(lnD2)
    Put  = StrikePrice  * EXP(-InterestRate*DaysUntilExpiry)*N(-lnD2) - IndexPrice * N(-lnD1)  
    */

    let lnExponential = Math.exp((-lnInterestRate) * lnDaysUntilExpiry);
    let lnNaturalLog = 0.0;
    //if(lnStrikePrice != 0)
    if (lnStrikePrice != 0 && lnIndexPrice != 0) // Bhushit A on 28Feb2013 for Bonanza: 001-00-346812 Open -- Odin Client exe crash / 001-00-347079 Open -- Broadcast delay issue
    {
      if ((lnIndexPrice / lnStrikePrice) > 0)  //-- Amol K - 001-00-295201 - Client application is getting crashed while adding scrip in  Greek watch window -- [15/06/2012]
        lnNaturalLog = Math.log(lnIndexPrice / lnStrikePrice);
    }
    let lnVolatilitySq = Math.pow(lnVolatility, 2);
    let lnSqrtDaysUntilExpiry = Math.pow(lnDaysUntilExpiry, 0.5);


    if ((lnVolatility * lnSqrtDaysUntilExpiry) != 0)
      lnD1 = (lnNaturalLog + ((lnInterestRate + (lnVolatilitySq / 2)) * lnDaysUntilExpiry)) / (lnVolatility * lnSqrtDaysUntilExpiry);
    lnD2 = lnD1 - lnVolatility * Math.pow((lnDaysUntilExpiry), 0.5);
    lnStdNormalD1 = this.fn_StdNormal(lnD1);
    lnStdNormalD2 = this.fn_StdNormal(lnD2);
    if ((lnVolatility * lnSqrtDaysUntilExpiry) == 0) {
      if (lnNaturalLog >= 0) {
        lnStdNormalD1 = 1;
        lnStdNormalD2 = 1;
      }
      else {
        lnStdNormalD1 = 0;
        lnStdNormalD2 = 0;
      }
    }

    lnCall = lnIndexPrice * lnStdNormalD1 - lnStrikePrice * lnExponential * lnStdNormalD2;

    return lnCall;

  }

  public static PutOptionValue(nIndexPrice, nStrikePrice, nInterestRate, nHighSigma, nExpiryDays) {

    let lnPut = 0.0,
      lnIndexPrice = 0.0, lnStrikePrice = 0.0, lnVolatility = 0.0,
      lnInterestRate = 0.0, lnDaysUntilExpiry = 0.0;
    let lnD1 = 0.0, lnD2 = 0.0;
    let lnStdNormalD1 = 0.0, lnStdNormalD2 = 0.0;

    lnIndexPrice = nIndexPrice;
    lnStrikePrice = nStrikePrice;
    lnInterestRate = nInterestRate / 100.00;
    lnDaysUntilExpiry = nExpiryDays / 365.0;
    lnVolatility = nHighSigma / 100.00;

    /*
    The Following Steps are required to Calculate the Black & Scholes Model
    Steps :
    lnD1 = (LN(IndexPrice/StrikePrice) + (InterestRate + pow(volatilty, 2)/2)*daysUntilExpiry )/ Volatility*pow((DaysUntilExpiry), 1/2)
    lnD2 = lnD1 - Volatility*pow((DaysUntilExpiry), 1/2)
    Call = IndexPrice * N(lnD1) - StrikePrice * EXP(-InterestRate*DaysUntilExpiry) * N(lnD2)
    Put  = StrikePrice  * EXP(-InterestRate*DaysUntilExpiry)*N(-lnD2) - IndexPrice * N(-lnD1)  
    */

    let lnExponential = Math.exp((-lnInterestRate) * lnDaysUntilExpiry);
    let lnNaturalLog = 0.0;
    //if(lnStrikePrice != 0)
    if (lnStrikePrice != 0 && lnIndexPrice != 0) // Bhushit A on 28Feb2013 for Bonanza: 001-00-346812 Open -- Odin Client exe crash / 001-00-347079 Open -- Broadcast delay issue
      lnNaturalLog = Math.log(lnIndexPrice / lnStrikePrice);
    let lnVolatilitySq = Math.pow(lnVolatility, 2);
    let lnSqrtDaysUntilExpiry = Math.pow(lnDaysUntilExpiry, 0.5);


    if ((lnVolatility * lnSqrtDaysUntilExpiry) != 0)
      lnD1 = (lnNaturalLog + ((lnInterestRate + (lnVolatilitySq / 2)) * lnDaysUntilExpiry)) / (lnVolatility * lnSqrtDaysUntilExpiry);
    lnD2 = lnD1 - lnVolatility * Math.pow((lnDaysUntilExpiry), 0.5);
    lnStdNormalD1 = this.fn_StdNormal(-lnD1);
    lnStdNormalD2 = this.fn_StdNormal(-lnD2);
    if ((lnVolatility * lnSqrtDaysUntilExpiry) == 0) {
      if (lnNaturalLog >= 0) {
        lnStdNormalD1 = 0;
        lnStdNormalD2 = 0;
      }
      else {
        lnStdNormalD1 = 1;
        lnStdNormalD2 = 1;
      }
    }
    lnPut = lnStrikePrice * lnExponential * lnStdNormalD2 - lnIndexPrice * lnStdNormalD1;

    return lnPut;

  }

  
  public static fn_StdNormal(nX){
    try {
      let lnResult;
      if (nX < -7.0)
          lnResult = this.fn_NormalDensityFunction(nX) / (Math.sqrt(1.0 + nX * nX));
      else if (nX > 7.0)
          lnResult = 1.0 - this.fn_StdNormal(-nX);
      else {
          lnResult = 0.2316419;
          let nNormalValues = [0.31938153,-0.356563782,1.7814477937,-1.8212255978,1.330274429];
          lnResult = 1.0 / (1 + lnResult * Math.abs(nX));
          lnResult = 1 - this.fn_NormalDensityFunction(nX) * (lnResult * (nNormalValues[0] +
                                                                    lnResult * (nNormalValues[1] +
                                                                    lnResult * (nNormalValues[2] +
                                                                    lnResult * (nNormalValues[3] +
                                                                   lnResult * (nNormalValues[4]))))));
          if (nX <= 0.0)
              lnResult = 1.0 - lnResult;
      }
      return lnResult;
      
    } catch (error) {
      console.log(error);
    }
  }

  
  public static fn_NormalDensityFunction(nVal){
    let result = 0.39894228040133 * Math.exp(-nVal * nVal / 2);
    return result;
  }

   // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
   public static getMarketSegmentIdForIndex(_ExchName) {
    try {
        let iMktSegId: number = -1;

        switch (_ExchName) {
            case clsConstants.C_S_NSE_EXCHANGE_TEXT:
                iMktSegId = clsConstants.C_V_NSE_CASH;
                break;
            case clsConstants.C_S_BSE_EXCHANGE_TEXT:
                iMktSegId = clsConstants.C_V_BSE_CASH;
                break;
            case clsConstants.C_S_MCX_EXCHANGE_TEXT:
                iMktSegId = clsConstants.C_V_MCX_SPOT;
                break;
            case clsConstants.C_S_NCDEX_EXCHANGE_TEXT:
                iMktSegId = clsConstants.C_V_NCDEX_SPOT;
                break;
            case clsConstants.C_S_MSX_EXCHANGE_TEXT:
                iMktSegId = clsConstants.C_V_MSX_CASH;
                break;
        }

        return iMktSegId;
    }
    catch (e) {

    }
}

}
