
export class clsPivotPoint {

    prevDayOpen = '0.0000';
    prevDayHigh = '0.0000';
    prevDayLow = '0.0000';
    prevDayClose = '0.0000';

    resistance4 = ('0.0000');
    resistance3 = ('0.0000');
    resistance2 = ('0.0000');
    resistance1 = ('0.0000');

    pivotPoint = ('0.0000');

    support1 = ('0.0000');
    support2 = ('0.0000');
    support3 = ('0.0000');
    support4 = ('0.0000');

    calculationMethod = ('Classic');
    PPFormula = ('(H+L+C)/3');

    minimum:any = ('0.0000');
    maximum :any= ('0.0000');
    range:any = ('0.0000');

    FBRatio1 = ('0.0000');
    FBRatio2 = ('0.0000');
    FBRatio3 = ('0.0000');
    FBRatio4 = ('0.0000');
    //     if(clsGlobal.User.PivotPrefDetails != undefined && clsGlobal.User.PivotPrefDetails != null) {
    //     FBRatio1 = (clsGlobal.User.PivotPrefDetails[0].nRatio1);
    // }
    //     else {
    //     FBRatio1 = ('0.0000');
    // }

    // if (clsGlobal.User.PivotPrefDetails != undefined && clsGlobal.User.PivotPrefDetails != null) {
    //     FBRatio2 = (clsGlobal.User.PivotPrefDetails[0].nRatio2);
    // }
    // else {
    //     FBRatio2 = ('0.0000');
    // }

    // if (clsGlobal.User.PivotPrefDetails != undefined && clsGlobal.User.PivotPrefDetails != null) {
    //     FBRatio3 = (clsGlobal.User.PivotPrefDetails[0].nRatio3);
    // }
    // else {
    //     FBRatio3 = ('0.0000');
    // }

    // if (clsGlobal.User.PivotPrefDetails != undefined && clsGlobal.User.PivotPrefDetails != null) {
    //     FBRatio4 = (clsGlobal.User.PivotPrefDetails[0].nRatio4);
    // }
    // else {
    //     FBRatio4 = ('0.0000');
    // }

    Midpoint1 = ('0.0000');
    Midpoint2 = ('0.0000');
    Midpoint3 = ('0.0000');
    Midpoint4 = ('0.0000');
    Midpoint5 = ('0.0000');
    Midpoint6 = ('0.0000');
    Midpoint7 = ('0.0000');
    Midpoint8 = ('0.0000');

    PriceFormat = 2;
    calculatePP () {
        var pivotPoint;
        
        switch (this.PPFormula) {
            case "(H+L+C)/3":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow) + parseFloat(this.prevDayClose)) / 3).toFixed(this.PriceFormat);
                break;
            case "(H+L+O)/3":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow) + parseFloat(this.prevDayOpen)) / 3).toFixed(4);
                break;
            case "(H+L+C+O)/4":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow) + parseFloat(this.prevDayClose) + parseFloat(this.prevDayOpen)) / 4).toFixed(4);
                break;
            case "(H+L+C+C)/4":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow) + parseFloat(this.prevDayClose) + parseFloat(this.prevDayClose)) / 4).toFixed(4);
                break;
            case "(H+L+O+O)/4":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow) + parseFloat(this.prevDayOpen) + parseFloat(this.prevDayOpen)) / 4).toFixed(4);
                break;
            case "(H+L)/2":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayLow)) / 2).toFixed(4);
                break;
            case "(H+C)/2":
                pivotPoint = ((parseFloat(this.prevDayHigh) + parseFloat(this.prevDayClose)) / 2).toFixed(4);
                break;
            case "(L+C)/2":
                pivotPoint = ((parseFloat(this.prevDayLow) + parseFloat(this.prevDayClose)) / 2).toFixed(4);
                break;

            default:
                break;
        }
        this.pivotPoint = (pivotPoint);
        this.calculateSupportResistance();
    }

    calculateSupportResistance() {
        this.calculaterange();
        switch (this.calculationMethod) {
            case "Classic":
                this.maximum = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * 3).toFixed(this.PriceFormat));
                this.minimum = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * 3).toFixed(this.PriceFormat));
                this.calculateMinimum();

                this.resistance4 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * 3).toFixed(this.PriceFormat));
                this.resistance3 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * 2).toFixed(this.PriceFormat));
                this.resistance2 = ((parseFloat(this.pivotPoint) + parseFloat(this.range)).toFixed(this.PriceFormat));
                this.resistance1 = ((2 * parseFloat(this.pivotPoint) - parseFloat(this.prevDayLow)).toFixed(this.PriceFormat));
                this.support1 = ((2 * parseFloat(this.pivotPoint) - parseFloat(this.prevDayHigh)).toFixed(this.PriceFormat));
                this.support2 = ((parseFloat(this.pivotPoint) - parseFloat(this.range)).toFixed(this.PriceFormat));
                this.support3 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * 2).toFixed(this.PriceFormat));
                this.support4 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * 3).toFixed(this.PriceFormat));
                break;
            case "Woodie":

                this.maximum = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * 3).toFixed(4));
                this.minimum = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * 3).toFixed(4));
                this.calculateMinimum();

                this.resistance4 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * 3).toFixed(4));
                this.resistance3 = ((parseFloat(this.prevDayHigh) + 2 * (parseFloat(this.pivotPoint) - parseFloat(this.prevDayLow))).toFixed(4));
                this.resistance2 = ((parseFloat(this.pivotPoint) + parseFloat(this.range)).toFixed(4));
                this.resistance1 = ((2 * parseFloat(this.pivotPoint) - parseFloat(this.prevDayLow)).toFixed(4));
                this.support1 = ((2 * parseFloat(this.pivotPoint) - parseFloat(this.prevDayHigh)).toFixed(4));
                this.support2 = ((parseFloat(this.pivotPoint) - parseFloat(this.range)).toFixed(4));
                this.support3 = ((parseFloat(this.prevDayLow) - 2 * (parseFloat(this.prevDayHigh) - parseFloat(this.pivotPoint))).toFixed(4));
                this.support4 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * 3).toFixed(4));
                break;
            case "Camarilla":
                this.maximum = ((parseFloat(this.prevDayClose) + parseFloat(this.range) * (1.1 / 2)).toFixed(4));
                this.minimum = ((parseFloat(this.prevDayClose) - parseFloat(this.range) * (1.1 / 2)).toFixed(4));
                this.calculateMinimum();

                this.resistance4 = ((parseFloat(this.prevDayClose) + parseFloat(this.range) * (1.1 / 2)).toFixed(4));
                this.resistance3 = ((parseFloat(this.prevDayClose) + parseFloat(this.range) * (1.1 / 4)).toFixed(4));
                this.resistance2 = ((parseFloat(this.prevDayClose) + parseFloat(this.range) * (1.1 / 6)).toFixed(4));
                this.resistance1 = ((parseFloat(this.prevDayClose) + parseFloat(this.range) * (1.1 / 12)).toFixed(4));
                this.support1 = ((parseFloat(this.prevDayClose) - parseFloat(this.range) * (1.1 / 12)).toFixed(4));
                this.support2 = ((parseFloat(this.prevDayClose) - parseFloat(this.range) * (1.1 / 6)).toFixed(4));
                this.support3 = ((parseFloat(this.prevDayClose) - parseFloat(this.range) * (1.1 / 4)).toFixed(4));
                this.support4 = ((parseFloat(this.prevDayClose) - parseFloat(this.range) * (1.1 / 2)).toFixed(4));
                break;
            case "Fibonacci":

                this.maximum = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * parseFloat(this.FBRatio4)).toFixed(4));
                this.minimum = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * parseFloat(this.FBRatio4)).toFixed(4));
                this.calculateMinimum();

                this.resistance4 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * parseFloat(this.FBRatio4)).toFixed(4));
                this.resistance3 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * parseFloat(this.FBRatio3)).toFixed(4));
                this.resistance2 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * parseFloat(this.FBRatio2)).toFixed(4));
                this.resistance1 = ((parseFloat(this.pivotPoint) + parseFloat(this.range) * parseFloat(this.FBRatio1)).toFixed(4));
                this.support1 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * parseFloat(this.FBRatio1)).toFixed(4));
                this.support2 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * parseFloat(this.FBRatio2)).toFixed(4));
                this.support3 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * parseFloat(this.FBRatio3)).toFixed(4));
                this.support4 = ((parseFloat(this.pivotPoint) - parseFloat(this.range) * parseFloat(this.FBRatio4)).toFixed(4));
                break;
            default:
                break;
        }

        //fn_CalculateMidpoint();
    }

calculaterange() {
    this.range = (parseFloat(this.prevDayHigh) - parseFloat(this.prevDayLow));
}

calculateMidpoint() {
    this.Midpoint1=((parseFloat(this.resistance4) + parseFloat(this.resistance3)) / 2).toFixed(4);
    this.Midpoint2=((parseFloat(this.resistance3) + parseFloat(this.resistance2)) / 2).toFixed(4);
    this.Midpoint3=((parseFloat(this.resistance2) + parseFloat(this.resistance1)) / 2).toFixed(4);
    this.Midpoint4=((parseFloat(this.resistance1) + parseFloat(this.pivotPoint)) / 2).toFixed(4);
    this.Midpoint5=((parseFloat(this.pivotPoint) + parseFloat(this.support1)) / 2).toFixed(4);
    this.Midpoint6=((parseFloat(this.support1) + parseFloat(this.support2)) / 2).toFixed(4);
    this.Midpoint7=((parseFloat(this.support2) + parseFloat(this.support3)) / 2).toFixed(4);
    this.Midpoint8=((parseFloat(this.support3) + parseFloat(this.support4)) / 2).toFixed(4);
}

calculateMinimum() {
    if ((parseFloat(this.maximum) - parseFloat(this.minimum)) <= 40)
        this.minimum = (parseFloat(this.minimum) - (parseFloat(this.maximum) - parseFloat(this.minimum) / 9)).toFixed(4);
    else
        this.minimum = (parseFloat(this.minimum) - 10);
}
}
