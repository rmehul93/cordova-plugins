import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsTradingMethods } from './clsTradingMethods';
import { clsCommonMethods } from './clsCommonMethods';
import { IKeyedCollection, Dictionary } from './clsCustomClasses';


/**
 * USD  : BT-12359
 * Date : 20/02/2020
 * Name : Nikhil Gawade
 * Description : ICEX file added for ICEX exchange
 */
export class clsICEX {
    arrInst = []; // Hash table for Holding Instruments for the selected / passed exchange (key would be ExchName and value would be list of instruments 
    arrOrderType = []; // List of Order Types allowed in this exchange
    arrProductType = []; // List of Product Types allowed in this exchange  
    arrValidity = []; // List of Validities allowed in this exchange
    arrError = []; //List of error messages 

    dcMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();//Dictonary for Market Seg
    dcDecimalLoc: IKeyedCollection<number> = new Dictionary<number>();
    dcMapMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();
    dcEnableDisableFields: IKeyedCollection<boolean> = new Dictionary<boolean>();

    //Fields for MarketStatus
    sICEXDervNormalMkt: string = '-';
    sICEXDervAMOMkt: string = '-';
    sICEXAUCBI: string = '-';
    sICEXAUCSO: string = '-';
    sICEXAUCTBI: string = '-';
    sICEXAUCTSO: string = '-';
    sICEXAUCBISessionNo: string = '-';
    sICEXAUCSOSessionNo: string = '-';
    sICEXAUCTBISessionNo: string = '-';
    sICEXAUCTSOSessionNo: string = '-';
    sICEXStatus: string = '-';

    constructor(InstName) {
        this.arrInst = InstName.split('$');
        // Hash table for MarketSegment Id, Key is the instrument and value will be the segment id for that instrument...
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT, clsConstants.C_V_ICEX_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT, clsConstants.C_V_ICEX_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_AUCBI_TEXT, clsConstants.C_V_ICEX_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_AUCSO_TEXT, clsConstants.C_V_ICEX_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT, clsConstants.C_V_ICEX_DERIVATIVES);
        //this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT, clsConstants.C_V_ICEX_SPOT);
        //this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_ICEXFUTSPT_TEXT, clsConstants.C_V_ICEX_SPOT);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT, clsConstants.C_V_ICEX_DERIVATIVES); //CR 5117 Initialize the New Value OPTFUT in Constructor of ICEX.
        this.dcDecimalLoc.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), clsConstants.C_V_NORMAL_DECIMALLOCATOR);

        this.dcMapMarketSegementId.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), clsConstants.C_V_MAPPED_ICEX_DERIVATIVES);
        //this.dcMapMarketSegementId.Add(clsConstants.C_V_ICEX_SPOT.toString(), clsConstants.C_V_MAPPED_ICEX_SPOT);

        // Hash table for holding the enable property for all the Order Entry UI fields...
        this.dcEnableDisableFields.Add("hasBuySell", true);
        this.dcEnableDisableFields.Add("hasExchange", true);
        this.dcEnableDisableFields.Add("hasInstrument", true);
        this.dcEnableDisableFields.Add("hasSymbol", true);
        this.dcEnableDisableFields.Add("hasOrderType", true);

        this.dcEnableDisableFields.Add("hasQty", true);
        this.dcEnableDisableFields.Add("hasPrice", true);
        this.dcEnableDisableFields.Add("hasDiscQty", true);
        this.dcEnableDisableFields.Add("hasTriggerPrice", true);
        this.dcEnableDisableFields.Add("hasProductType", true);
        this.dcEnableDisableFields.Add("hasValidity", true);
        this.dcEnableDisableFields.Add("hasDay", true);

        this.dcEnableDisableFields.Add("hasSeries", false);
        this.dcEnableDisableFields.Add("hasOptionType", false);
        this.dcEnableDisableFields.Add("hasExpire", false);
        this.dcEnableDisableFields.Add("hasProdPer", false);
        this.dcEnableDisableFields.Add("hasStrikePrice", false);
        this.dcEnableDisableFields.Add("hasCOL", false);
        this.dcEnableDisableFields.Add("hasCutOff", false);

        //if ((clsConstants.C_V_MAPPED_ICEX_DERIVATIVES & clsGlobal.User.TSLAllowed) == clsConstants.C_V_MAPPED_ICEX_DERIVATIVES)
        //    this.dcEnableDisableFields.Add("hasTrailingSL", true);
        //else
        //    this.dcEnableDisableFields.Add("hasTrailingSL", false);
    }

    // Function to Enable / Disable the UI Elements property based on the the instument...
    enableDisable(InstName) {
        try {
            // Case for Future....
            if (InstName == clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) {

                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", false);
                this.dcEnableDisableFields.Add("hasOptionType", false);
                this.dcEnableDisableFields.Add("hasExpire", true);
                this.dcEnableDisableFields.Add("hasProdPer", false);
            }
            else if (InstName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT || InstName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT ||
                InstName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || InstName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT) {
                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", false);
                this.dcEnableDisableFields.Add("hasOptionType", false);
                this.dcEnableDisableFields.Add("hasExpire", false);
                this.dcEnableDisableFields.Add("hasProdPer", false);
                this.dcEnableDisableFields.Add("hasDiscQty", false);
            }
            else if (InstName == clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT) //CR 5117 Enabled Fields to be Validated for ICEX Options 
            {
                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", true);
                this.dcEnableDisableFields.Add("hasOptionType", true);
                this.dcEnableDisableFields.Add("hasExpire", true);
                this.dcEnableDisableFields.Add("hasProdPer", false);
                this.dcEnableDisableFields.Add("hasDiscQty", false);
            }
            else {
                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", false);
                this.dcEnableDisableFields.Add("hasOptionType", false);
                this.dcEnableDisableFields.Add("hasExpire", false);
                this.dcEnableDisableFields.Add("hasProdPer", false);
            }
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'EnableDisable', 'ICEX.js', '');
        }
        // return the dictionary with the values based on the instrument...
        return this.dcEnableDisableFields;
    }


    // Split the validity string and populate the array...
    populateValidity(Validity) {
        try {
            this.arrValidity = Validity.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateValidity', 'ICEX.js', '');


        }
    }

    // Split the Product Types string and populate teh array...
    populateProductTypes(ProductTypes) {
        try {
            this.arrProductType = ProductTypes.split('$');
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateProductTypes', 'ICEX.js', '');               
        }
    }

    // Split the Product Types string and populate teh array...
    populateOrderTypes(OrderTypes) {
        try {
            this.arrOrderType = OrderTypes.split('$');
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes', 'ICEX.js', '');
        }
    }

    // Get the details for the selected Order Type
    getDetailsForOrderType(OrderTypes, Instrument) {
        try {
            if (Instrument == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT) {
                ///////////// don't do anything for timebeing //////////////
            }
            else {
                if (OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
                    this.dcEnableDisableFields.Add("hasTriggerPrice", false);
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
                }
                else if (OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                    OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                    this.dcEnableDisableFields.Add("hasTriggerPrice", true);
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
                }
                else {
                    this.dcEnableDisableFields.Add("hasTriggerPrice", false);
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
                }
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForOrderType', 'ICEX.js', '');


        }
        return this.dcEnableDisableFields;
    }

    // Get the details for the selected Validity
    getDetailsForValidity(Validity, Instrument) {
        try {
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                this.dcEnableDisableFields.Add("hasDay", true);
            }
            else {
                this.dcEnableDisableFields.Add("hasDay", false);
            }
            if (Instrument == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT) {
                ///////////// don't do anything for timebeing //////////////
            }
            else {
                if (Validity == clsConstants.C_S_VALUE_IOC) {
                    this.dcEnableDisableFields.Add("hasDiscQty", false);
                }
                else {
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
                }
            }
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity', 'ICEX.js', '');
        }
        return this.dcEnableDisableFields;
    }

    // Get the details of MktProtPerc
    getDetailsForMktProtPerc(MapMarketSegmentId, Price, MarketSegmentId, MPPrice, ProdType) {
        let ProtPerc: any, ProtPercOrderPref = '';
        try {
            if (MapMarketSegmentId == clsConstants.C_V_MAPPED_ICEX_DERIVATIVES
                && clsGlobal.User.marketProtPercList.ContainsKey(MapMarketSegmentId)) {
                if (Price == 0 || (ProdType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && MPPrice == 0)) {
                    ProtPerc = parseInt(clsGlobal.User.marketProtPercList.getItem(MapMarketSegmentId)) / 100;
                    if (isNaN(ProtPerc))
                        ProtPerc = '';
                    ProtPercOrderPref = ProtPerc;
                    // if (clsGlobal.User.OrderPrefDic[MarketSegmentId].sPrefType == 'USER')
                    //     ProtPercOrderPref = clsGlobal.User.OrderPrefDic[MarketSegmentId].nProtPerc;
                    // else
                    //     ProtPercOrderPref = ProtPerc;

                    if (ProtPerc > 0)
                        this.dcEnableDisableFields.Add("hasProdPer", true);
                }
                else {
                    this.dcEnableDisableFields.Add("hasProdPer", false);
                }
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForMktProtPerc', 'ICEX.js', '');

        }
        return [this.dcEnableDisableFields, ProtPerc, ProtPercOrderPref];
    }

    // Function to Validate the scripdetails...
    validateScripDetails(dcLookupDetails) {
        this.arrError = [];

        try {
            //var clsGlobal.dMsgMaster = new fn_HashTable();

            //var Exchange = dcLookupDetails["SelExchange"] == undefined ? '' : dcLookupDetails["SelExchange"];
            var Instrument = dcLookupDetails["SelInstrument"] == undefined ? '' : dcLookupDetails["SelInstrument"];
            //var MarketSegmentId = dcLookupDetails["MarketSegmentId"] == undefined ? '' : dcLookupDetails["MarketSegmentId"];

            var Symbol = dcLookupDetails["SelSymbol"] == undefined ? '' : dcLookupDetails["SelSymbol"];
            var Series = dcLookupDetails["SelSeries"] == undefined ? '' : dcLookupDetails["SelSeries"];
            var StrikePrice = dcLookupDetails["SelStrikePrice"] == undefined ? '' : dcLookupDetails["SelStrikePrice"];
            var OptionType = dcLookupDetails["SelOptionType"] == undefined ? '' : dcLookupDetails["SelOptionType"];
            var ExpiryDate = dcLookupDetails["SelExpDate"] == undefined ? '' : dcLookupDetails["SelExpDate"];

            //var MarketLot = dcLookupDetails["SelScripMarketLot"] == undefined ? '' : dcLookupDetails["SelScripMarketLot"];
            //var DecimalLocator = dcLookupDetails["SelScripDecimalloc"] == undefined ? '' : dcLookupDetails["SelScripDecimalloc"];

            //var PriceTick = dcLookupDetails["SelScripPriceTick"] == undefined ? '' : dcLookupDetails["SelScripPriceTick"];
            //var TokenNo = dcLookupDetails["SelScripToken"] == undefined ? '' : dcLookupDetails["SelScripToken"];

            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            //Case for NSE FUTIDX /  NSE FUTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
            }

            //Case for NSE OPTIDX / NSE OPTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().length == 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.length == 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }


        } catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateScripDetails', 'ICEX.js', '');


        }
        return this.arrError;
    };

    addError(sErrElement, sErrMsg) {
        this.arrError.push(sErrMsg);
    }

    // Function to Validate the orders...
    validateOrder(dcOrderDetail) {
        this.arrError = [];
        let dcOrderDetails: Dictionary<string> = dcOrderDetail as Dictionary<string>;
        try {

            //let Exchange = dcOrderDetails.getItem("SelExchange") == undefined ? '' : dcOrderDetails.getItem("SelExchange");
            let Instrument = dcOrderDetails.getItem("SelInstrument") == undefined ? '' : dcOrderDetails.getItem("SelInstrument");
            let MarketSegmentId: any = dcOrderDetails.getItem("MarketSegmentId") == undefined ? '' : dcOrderDetails.getItem("MarketSegmentId");
            let MapMarketSegmentId: any = dcOrderDetails.getItem("MapMarketSegmentId") == undefined ? '' : dcOrderDetails.getItem("MapMarketSegmentId");
            let Validity = dcOrderDetails.getItem("SelValidity") == undefined ? '' : dcOrderDetails.getItem("SelValidity");
            let ProductType = dcOrderDetails.getItem("SelProduct") == undefined ? '' : dcOrderDetails.getItem("SelProduct");

            let OrderType = dcOrderDetails.getItem("SelOrderTypes") == undefined ? '' : dcOrderDetails.getItem("SelOrderTypes");
            let OrderSide = dcOrderDetails.getItem("SelOperation") == undefined ? '' : dcOrderDetails.getItem("SelOperation");
            let Symbol = dcOrderDetails.getItem("SelSymbol") == undefined ? '' : dcOrderDetails.getItem("SelSymbol");
            let Series = dcOrderDetails.getItem("SelSeries") == undefined ? '' : dcOrderDetails.getItem("SelSeries");
            let StrikePrice = dcOrderDetails.getItem("SelStrikePrice") == undefined ? '' : dcOrderDetails.getItem("SelStrikePrice");

            let OptionType = dcOrderDetails.getItem("SelOptionType") == undefined ? '' : dcOrderDetails.getItem("SelOptionType");
            let ExpiryDate = dcOrderDetails.getItem("SelExpire") == undefined ? '' : dcOrderDetails.getItem("SelExpire");
            let ProtPerc: any = dcOrderDetails.getItem("SelProdPer") == undefined ? '0' : dcOrderDetails.getItem("SelProdPer");
            let Quantity: any = dcOrderDetails.getItem("SelQty") == undefined ? 0 : dcOrderDetails.getItem("SelQty");
            let Price: any = dcOrderDetails.getItem("SelPrice") == undefined ? '' : dcOrderDetails.getItem("SelPrice");

            let DiscQty: any = dcOrderDetails.getItem("SelDiscQty") == undefined ? '' : dcOrderDetails.getItem("SelDiscQty");
            let TriggerPrice: any = dcOrderDetails.getItem("SelTriggerPrice") == undefined ? '' : dcOrderDetails.getItem("SelTriggerPrice");
            let Days: any = dcOrderDetails.getItem("SelDay") == undefined ? '' : dcOrderDetails.getItem("SelDay");
            //let MarketLot = dcOrderDetails.getItem("SelMarketLot") == undefined ? '' : dcOrderDetails.getItem("SelMarketLot");
            let DecimalLocator: any = dcOrderDetails.getItem("SelDecimalloc") == undefined ? '' : dcOrderDetails.getItem("SelDecimalloc");

            let PriceTick = dcOrderDetails.getItem("SelPriceTick") == undefined ? '' : dcOrderDetails.getItem("SelPriceTick");
            let TokenNo = dcOrderDetails.getItem("SelToken") == undefined ? '' : dcOrderDetails.getItem("SelToken");

            //let MarketStatus = dcOrderDetails.getItem("MarketStatus") == undefined ? '' : dcOrderDetails.getItem("MarketStatus");
            let ModifyFlag = dcOrderDetails.getItem("ModifyFlag") == undefined ? false : dcOrderDetails.getItem("ModifyFlag");

            let MPSuccessFailure = dcOrderDetails.getItem("MPSuccessFailure") == undefined ? false : dcOrderDetails.getItem("MPSuccessFailure");
            let MPLimitPriceLowRange: any = dcOrderDetails.getItem("MPLimitPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("MPLimitPriceLowRange");
            let MPLimitPriceHighRange: any = dcOrderDetails.getItem("MPLimitPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("MPLimitPriceHighRange");
            let MPTriggerPriceLowRange: any = dcOrderDetails.getItem("MPTriggerPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPriceLowRange");
            let MPTriggerPriceHighRange: any = dcOrderDetails.getItem("MPTriggerPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPriceHighRange");

            let MPTradingAllowed: any = dcOrderDetails.getItem("MPTradingAllowed") == undefined ? '' : dcOrderDetails.getItem("MPTradingAllowed");
            let MPOrderType = dcOrderDetails.getItem("MPOrderType") == undefined ? '' : dcOrderDetails.getItem("MPOrderType");
            let MPPrice: any = dcOrderDetails.getItem("MPPrice") == undefined ? '' : dcOrderDetails.getItem("MPPrice");
            let MPTriggerPrice: any = dcOrderDetails.getItem("MPTriggerPrice") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPrice");

            let ProfitOrderPrice: any = dcOrderDetails.getItem("ProfitOrderPrice") == undefined ? '' : dcOrderDetails.getItem("ProfitOrderPrice");
            let TrailingSL = dcOrderDetails.getItem("TrailingSL") == undefined ? '' : dcOrderDetails.getItem("TrailingSL");
            let SLJumpPrice: any = dcOrderDetails.getItem("SLJumpPrice") == undefined ? '' : dcOrderDetails.getItem("SLJumpPrice");
            let LTPJumpPrice: any = dcOrderDetails.getItem("LTPJumpPrice") == undefined ? '' : dcOrderDetails.getItem("LTPJumpPrice");
            let ProfitPriceLowRange: any = dcOrderDetails.getItem("ProfitPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("ProfitPriceLowRange");
            let ProfitPriceHighRange: any = dcOrderDetails.getItem("ProfitPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("ProfitPriceHighRange");
            let MPLTP: any = dcOrderDetails.getItem("MPLTP") == undefined ? '' : dcOrderDetails.getItem("MPLTP");
            let BOModifyTerms: any = dcOrderDetails.getItem("BOModifyTerms") == undefined ? '' : dcOrderDetails.getItem("BOModifyTerms");
            let UnderlyingLTP: any = dcOrderDetails.getItem("UnderlyingLTP") == undefined ? '' : dcOrderDetails.getItem("UnderlyingLTP");
            let bAMO = dcOrderDetails.getItem("AMO") == undefined ? false : dcOrderDetails.getItem("AMO");
            let OriginalOrdType = dcOrderDetails.getItem("OriginalOrderType") == undefined ? '' : dcOrderDetails.getItem("OriginalOrderType");
            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("OE60"));
                if (ExpiryDate.toString().length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("OE61"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("OE57"));
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("OE58"));
                if (isNaN(ProtPerc))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL31"));
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                let regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }
            //Series
            if (Series.length > 0) {
                let regSeries = new RegExp("([A-Za-z0-9]$)");
                if (!regSeries.test(Series))
                    this.addError("Series1", clsGlobal.dMsgMaster.getItem("NNSL40"));
            }
            //                //ExpiryDate
            //                if (ExpiryDate.length > 0) {
            //                    let regExpDt = new RegExp("^(([1-9])|([0][1-9])|([1-2][0-9])|(30)|(31))([Jj][Aa][Nn]|[Ff][Ee][bB]|[Mm][Aa][Rr]|[Aa][Pp][Rr]|[Mm][Aa][Yy]|[Jj][Uu][Nn]|[Jj][Uu][Ll]|[aA][Uu][gG]|[Ss][eE][pP]|[oO][Cc][Tt]|[Nn][oO][Vv]|[Dd][Ee][Cc])(19|20)\d\d$");
            //                    if (!regExpDt.test(ExpiryDate))
            //                        this.addError("ExpiryDate1", clsGlobal.dMsgMaster.getItem("NNSL41"]);
            //                }
            //Option Type
            if (OptionType.length > 0) {
                let regOptType = new RegExp("([A-Za-z]$)");
                if (!regOptType.test(OptionType))
                    this.addError("OptionType1", clsGlobal.dMsgMaster.getItem("NNSL42"));
            }
            //                //Days
            //                if (Days.length > 0) {
            //                    let regDays = new RegExp("([1-7]$)");
            //                    if (!regDays.test(Days))
            //                        this.addError("Days1", clsGlobal.dMsgMaster.getItem("NNSL43"]);
            //                }
            // Product Type
            if (ProductType.length == 0) {
                this.addError("ProductType1", "Product Type cannot be blank");
            }
            //////////////////////// Secondary Validations ///////////////////////////
            // if (!HasErrors)

            //let DecLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
            let PriceinPaise = 0;
            let TrigPriceinPaise = 0;

            let decChkTrgPrice = 0;
            let decChkPrice = 0;


            //let DiscQty = dcOrderDetails.getItem("SelDiscQty") == undefined ? '' : dcOrderDetails.getItem("SelDiscQty");
            //let Quantity = dcOrderDetails.getItem("SelQty") == undefined ? '' : dcOrderDetails.getItem("SelQty");
            let DiscQtyCaption = "Disclosed " + clsConstants.CONST_LOT_CAPTION;
            let QtyCaption = clsConstants.CONST_LOT_CAPTION;

            if (DecimalLocator == '' || DecimalLocator == 0)
                DecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;

            let _AllowedDecimal = DecimalLocator.length - 1;
            let secondLegPriceCaption = 'Price';
            secondLegPriceCaption = ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT ? "SL Price" : secondLegPriceCaption;
            let decChkMPPrice = 0;

            //Quantity related Validations
            if (isNaN(Quantity)) {
                this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption);
            }

            else if (!isNaN(Quantity)) {
                /** <Norwin Dcruz> <10/12/2019> <USD : BT-3884> <When Main Leg fully executed and 2nd and 3rd leg is pending then populate qty 0 and not to validate in submit for bracket order only> **/
                if ((Quantity == 0) && (!(ModifyFlag && ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT))) {
                    this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL45"));
                }

                // Case to check Quantity should not have decimal character
                if (Quantity.toString().indexOf('.') != -1)
                    this.addError("Quantity2", QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));
            }
            // Quantity validations end

            //Disclosed Quantity related Validations
            //  Case to validate Disc Qty Entered. Here case has been checked for Disc LOT as well as Disc Qty.

            if (!isNaN(DiscQty))      //If Disc Qty has some value
            {
                if (DiscQty != 0 && DiscQty != "") {
                    if (!isNaN(Quantity))            //If Qty has some value
                    {
                        if (parseInt(DiscQty) > parseInt(Quantity))
                            this.addError("DiscQty", clsGlobal.dMsgMaster.getItem("NNSL44") + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL48") + QtyCaption);

                        //For ICEX Disc LOT cannot be less than 20% of Original LOT entered         
                        if (DiscQty != 0) {
                            if ((Quantity / 5) > DiscQty)
                                this.addError("DiscQty", clsGlobal.dMsgMaster.getItem("NNSL51") + DiscQtyCaption + " The " + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL388") + QtyCaption);
                        }
                    }
                    //Disc Qty / Lot not allowed for IOC order
                    if (Validity == clsConstants.C_S_VALUE_IOC && (!isNaN(DiscQty)))
                        this.addError("DiscQty2", DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL55"));


                    // Case to check Quantity should not have decimal character
                    if (DiscQty.toString().indexOf('.') != -1)
                        this.addError("DiscQty3", DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));
                }
            }

            //////////////////////// disclosed qty validation ends here.....//////////////////////////////

            // Validations related to Price
            if (!isNaN(Price)) {
                if (Price < 0) {
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL59"));
                }
                if (Price != 0) {

                    decChkPrice = parseFloat(Price);

                    if (!(clsCommonMethods.DecDigits(decChkPrice.toString(), _AllowedDecimal)))
                        this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL61"));

                    PriceinPaise = parseInt(Math.round(parseFloat((Price * DecimalLocator).toString())).toString());

                    if (PriceinPaise % parseInt(PriceTick) != 0) {
                        if (TokenNo != "") {
                            this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                        }
                    }
                }
                /** <Norwin Dcruz> <13/12/2019> <USD : BT-3884> <Commented for not using toggle anymore > **/
                // else {
                //     //If price is 0 and order type selected are RL/SL --> Show error message
                //     if (ProductType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                //         if (OrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)
                //             this.addError("Price", "Price cannot be zero for Limit order");
                //     }
                // }
            }

            //Additional validation for margin plus as the price field for MP is different
            if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && !isNaN(MPPrice)) {
                if (MPPrice < 0) {
                    this.addError("Price", clsTradingMethods.priceCanNotBeNegativeMsg(secondLegPriceCaption));
                }
                if (MPPrice != 0) {

                    decChkMPPrice = parseFloat(MPPrice);

                    if (!(clsCommonMethods.DecDigits(decChkMPPrice.toString(), _AllowedDecimal)))
                        this.addError("Price", clsTradingMethods.priceNotInDecDigitsMsg(secondLegPriceCaption, _AllowedDecimal));

                    PriceinPaise = parseInt(Math.round(parseFloat((MPPrice * DecimalLocator).toString())).toString());

                    if (PriceinPaise % parseInt(PriceTick) != 0) {
                        if (TokenNo != "") {
                            this.addError("Price", clsTradingMethods.priceNotInPriceTickMsg(secondLegPriceCaption, PriceTick, true));
                        }
                    }
                }
                if (MPTradingAllowed === 1 && MPPrice == 0) {//In case the Margin Plus Trading Allowed is 1 then Limit order is mandatory
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL347"));
                }
                else if (MPTradingAllowed === 3 && MPPrice != 0) {//In case the Margin Plus Trading Allowed is 3 then Market order is mandatory
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL348"));
                }

                if ((parseFloat(MPPrice) < parseFloat(MPLimitPriceLowRange) || parseFloat(MPPrice) > parseFloat(MPLimitPriceHighRange)) && parseFloat(MPPrice) != 0)
                    this.addError("Price", clsTradingMethods.priceOutOfRangeMsg(secondLegPriceCaption));
            }
            // Validations of Price ends

            /* Validations to check TriggerPrice */
            //First validation of trigger price for margin plus as it has separate order type else for normal order
            if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && MPOrderType === clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                if (isNaN(MPTriggerPrice))
                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL65"));

                if (!isNaN(MPTriggerPrice)) {
                    if (MPTriggerPrice == 0)
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL66"));
                    else {
                        decChkTrgPrice = parseFloat(MPTriggerPrice);

                        if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL68"));

                        TrigPriceinPaise = parseInt(Math.round(parseFloat((MPTriggerPrice * DecimalLocator).toString())).toString());

                        if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                            }
                        }

                        if (MPOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT && (parseFloat(MPTriggerPrice) < parseFloat(MPTriggerPriceLowRange) || parseFloat(MPTriggerPrice) > parseFloat(MPTriggerPriceHighRange)) && parseFloat(MPTriggerPrice) != 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL217"));

                        if (!isNaN(MPPrice)) {
                            /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                            other than Margin Plus. For Margin Plus case is vice versa  
                            Note: Case is viceversa only for fresh order
                            * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                            if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                //if (!ModifyFlag) //case for MarginPlus - Fresh Order
                                //{
                                if ((decChkTrgPrice < decChkMPPrice) && decChkMPPrice != 0)
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL70"));
                                //}
                                //else {//case for MarginPlus - Modify Order
                                //    if ((decChkTrgPrice > decChkMPPrice) && decChkMPPrice != 0)
                                //        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL71"));
                                //}
                            }
                            /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                            other than Margin Plus. For Margin Plus case is vice versa  
                            Note: Case is viceversa only for fresh order
                            For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                            else//Sell side case
                            {
                                //if (!ModifyFlag)//case for MarginPlus - Fresh Order
                                //{
                                if (decChkTrgPrice > decChkMPPrice && decChkMPPrice != 0)
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL72"));
                                //}
                                //else {//case for MarginPlus - Modify Order
                                //    if (decChkTrgPrice < decChkMPPrice)
                                //        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL73"));
                                //}
                            }

                            //For Buy Bracket Order with First Leg Limit Price,SL trigger Price sohuld be less than Limit Price
                            //For Buy Bracket Order with First Leg market Price,SL trigger Price sohuld be less than LTP
                            //For Sell Bracket Order with First Leg Limit Price,SL trigger Price sohuld be greater than Limit Price
                            //For Sell Bracket Order with First Leg market Price,SL trigger Price sohuld be greater than LTP
                            if (ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    if (decChkPrice != 0) {
                                        if (decChkTrgPrice > decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL363").replace('{0}', 'Trigger Price'));
                                    }
                                    else {
                                        if (decChkTrgPrice > MPLTP)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL364").replace('{0}', 'Trigger Price'));
                                    }
                                }
                                else {
                                    if (decChkPrice != 0) {
                                        if (decChkTrgPrice < decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL365").replace('{0}', 'Trigger Price'));
                                    }
                                    else {
                                        if (decChkTrgPrice < MPLTP)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL366").replace('{0}', 'Trigger Price'));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {//In case of normal product type other than margin plus
                if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                    OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {

                    if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                        if (Price == 0) {
                            this.addError("Price", "Price cannot be zero for Limit order");
                        }
                    }

                    if (ModifyFlag) {
                        if (OriginalOrdType == clsConstants.C_S_ORDER_REGULARLOT_TEXT || OriginalOrdType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
                            this.addError("OrderType", "Order type cannot be changed from " + OriginalOrdType + " to " + OrderType);
                    }

                    if (isNaN(TriggerPrice))
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL65"));

                    if (TriggerPrice < 0) {
                        this.addError("TriggerPrice", 'Please enter valid Trigger Price. Trigger Price cannot be negative.');
                    }

                    if (!isNaN(TriggerPrice)) {
                        if (TriggerPrice == 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL66"));
                        else {
                            decChkTrgPrice = parseFloat(TriggerPrice);

                            if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL68"));

                            TrigPriceinPaise = parseInt(Math.round(parseFloat((TriggerPrice * DecimalLocator).toString())).toString());

                            if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                                }
                            }

                            if (!isNaN(Price)) {
                                /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    if (ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag) //case for MarginPlus
                                    {
                                        if ((decChkTrgPrice < decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL70"));
                                    }
                                    else {
                                        if ((decChkTrgPrice > decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL71"));
                                    }
                                }
                                /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                                else                //Sell side case
                                {
                                    if (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag)      //case for MarginPlus
                                    {
                                        if (decChkTrgPrice > decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL72"));
                                    }
                                    else {
                                        if (decChkTrgPrice < decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL73"));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //Trigger Price Validations end

            //Case --> Only DAY validity allowed for MarginPlus order
            if (MPOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT && (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && Validity != clsConstants.C_S_VALUE_DAY) {
                this.addError("Validity2", clsGlobal.dMsgMaster.getItem("NNSL76").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT));
            }

            //Case to check Days field when Validity selected is GTD
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                if (Days.length == 0)
                    this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL77"));
                else {
                    let ValidExpireDays: any = clsCommonMethods.CalculateDays(new Date(), new Date(ExpiryDate));
                    // if (Days > ValidExpireDays || Days <= 0)
                    //if (Days > ValidExpireDays || Days < 0) //001-00-506746
                    //    this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL43").replace('7', ValidExpireDays));
                    //let regDays = new RegExp("(^[1-7)?$)");
                    //if (!regDays.test(Days)) {
                    //    this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL43"));
                    //}
                    /////////// 001-00-506746 /////////////
                    if (ValidExpireDays == 0 && Days > 0) {
                        //alert("Value of Days should be 0");
                        //return;
                        this.addError("Days", "Value of Days should be 0");
                    }
                    else if (ValidExpireDays != 0 && Days == 0) {
                        this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL43").replace('7', ValidExpireDays));
                    }
                    else {
                        if (Days > ValidExpireDays || Days < 0) //001-00-506746
                            this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL43").replace('7', ValidExpireDays));
                    }
                    //////////// 001-00-506746 /////////////
                }
            }

            // Stop loss validations....
            if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_VALUE_IOC) {
                if (MarketSegmentId != clsConstants.C_V_NSE_DERIVATIVES)
                    this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL80"));
            }

            if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_ORDER_FOK)
                this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL81"));

            //Auction changes start
            if (Instrument == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || Instrument == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT) {
                if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)
                    this.addError("OrderType", clsGlobal.dMsgMaster.getItem("NNSL82"));
                if (Validity != clsConstants.C_S_VALUE_EOS)
                    this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL83"));
                if (Instrument == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT)   //Only sell Orders allowed
                {
                    if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                        this.addError("OrderSideList", clsGlobal.dMsgMaster.getItem("NNSL84"));
                }
                if (Instrument == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT)   //Only Buy Orders Allowed   
                {
                    if (OrderSide == clsConstants.C_S_ORDER_SELL_TEXT)
                        this.addError("OrderSideList", clsGlobal.dMsgMaster.getItem("NNSL85"));
                }
                if (Price == 0)
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL86"));
            }

            ///Validations for Margin Plus
            if ((ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)) {
                if (!MPSuccessFailure) {
                    if (Instrument.startsWith('OPT') && UnderlyingLTP <= 0)
                        this.addError("OrderEntry", clsTradingMethods.MPNotAllowedForUnderlyingLTPMsg(ProductType));
                    else
                        this.addError("OrderEntry", clsTradingMethods.MPNotAllowedForLTPMsg(ProductType, decChkPrice));
                }

                if (Validity != clsConstants.C_S_VALUE_DAY && Validity != clsConstants.C_S_VALUE_EOSESS)
                    this.addError("Validity", clsTradingMethods.MPNotAllowedForValidityMsg(ProductType));

                if (MPOrderType === clsConstants.C_S_ORDER_REGULARLOT_TEXT && MPPrice != 0)
                    this.addError("Price", "RL Limit order not allowed for Margin Plus");
            }

            /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Protection Percent validation for bracket order entry> **/
            if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                if ((MPPrice == 0 || MPPrice == undefined || MPPrice == '') &&
                    (ProtPerc == 0 || ProtPerc == undefined || ProtPerc == '')) {
                    this.addError("ProtPerc", 'Please Enter Protection Percent');
                }
            }

            //Validation for Market Protection %
            if ((Price == 0 || (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && MPPrice == 0)) && MapMarketSegmentId == clsConstants.C_V_MAPPED_ICEX_DERIVATIVES) {
                //If protection % > configured protection %
                if (clsGlobal.User.marketProtPercList.ContainsKey(MapMarketSegmentId)) {
                    let confProtPerc = parseInt(clsGlobal.User.marketProtPercList.getItem(MapMarketSegmentId)) / 100;
                    if (ProtPerc > confProtPerc)
                        this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL352") + confProtPerc + " %");
                }
            }

            if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                let decChkProfitOrderPrice = 0;
                let decChkSLJumpPrice = 0;
                let decChkLTPJumpPrice = 0;

                if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || OrderType == clsConstants.C_S_ORDER_CALLAUCTION_TEXT)
                    this.addError("OrderType", "Bracket order not allowed for stop loss order type");

                if (ModifyFlag && BOModifyTerms === 0)
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL375"));

                //if (ProtPerc == 0) {
                //    if (decChkPrice == 0)
                //        this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL376"));
                //    //else if (decChkMPPrice == 0)
                //    //    this.addError("MPPrice", clsGlobal.dMsgMaster.getItem("NNSL377"));
                //}

                if (TrailingSL) {
                    if (!isNaN(SLJumpPrice)) {
                        if (SLJumpPrice == 0) {
                            this.addError("SLJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('SL Jump Price'));
                        }
                        if (SLJumpPrice != 0) {

                            decChkSLJumpPrice = parseFloat(SLJumpPrice);

                            if (!(clsCommonMethods.DecDigits(decChkSLJumpPrice.toString(), _AllowedDecimal)))
                                this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('SL Jump Price', _AllowedDecimal));

                            PriceinPaise = parseInt(Math.round(parseFloat((SLJumpPrice * DecimalLocator).toString())).toString());

                            if (PriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("SLJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('SL Jump Price', PriceTick, true));
                                }
                            }
                        }
                    }

                    if (clsGlobal.isJumpBothLtpAndTrigPrice) {
                        if (!isNaN(LTPJumpPrice)) {
                            if (LTPJumpPrice == 0) {
                                this.addError("LTPJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('LTP Jump Price'));
                            }
                            if (LTPJumpPrice != 0) {

                                decChkLTPJumpPrice = parseFloat(LTPJumpPrice);

                                if (!(clsCommonMethods.DecDigits(decChkLTPJumpPrice.toString(), _AllowedDecimal)))
                                    this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('LTP Jump Price', _AllowedDecimal));

                                PriceinPaise = parseInt(Math.round(parseFloat((LTPJumpPrice * DecimalLocator).toString())).toString());

                                if (PriceinPaise % parseInt(PriceTick) != 0) {
                                    if (TokenNo != "") {
                                        this.addError("LTPJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('LTP Jump Price', PriceTick, true));
                                    }
                                }

                                if (decChkSLJumpPrice > decChkLTPJumpPrice)
                                    this.addError("SLJumpPrice", clsGlobal.dMsgMaster.getItem("NNSL361"));
                            }
                        }
                    }
                }

                // Validations related to ProfitOrderPrice
                if (!isNaN(ProfitOrderPrice)) {
                    if (ProfitOrderPrice == 0) {
                        this.addError("ProfitOrderPrice", clsTradingMethods.PriceCanNotBeZeroMsg('Profit Order Price'));
                    }
                    if (ProfitOrderPrice != 0) {

                        decChkProfitOrderPrice = parseFloat(ProfitOrderPrice);

                        if (!(clsCommonMethods.DecDigits(decChkProfitOrderPrice.toString(), _AllowedDecimal)))
                            this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInDecDigitsMsg('Profit Order Price', _AllowedDecimal));

                        PriceinPaise = parseInt(Math.round(parseFloat((ProfitOrderPrice * DecimalLocator).toString())).toString());

                        if (PriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInPriceTickMsg('Profit Order Price', PriceTick, true));
                            }
                        }

                        //profit order price validation with PPR
                        if ((decChkProfitOrderPrice < ProfitPriceLowRange || decChkProfitOrderPrice > ProfitPriceHighRange))
                            this.addError("ProfitOrderPrice", clsTradingMethods.priceOutOfRangeMsg('Profit Order Price'));

                        //For Buy Bracket Order with First Leg Limit Price,Profit Order Price sohuld be greater than Limit Price
                        //For Buy Bracket Order with First Leg market Price,Profit Order Price sohuld be greater than LTP
                        //For Sell Bracket Order with First Leg Limit Price,Profit Order Price sohuld be less than Limit Price
                        //For Sell Bracket Order with First Leg market Price,Profit Order Price sohuld be less than LTP
                        if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                            if (decChkPrice != 0) {
                                if (decChkProfitOrderPrice <= decChkPrice)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL365").replace('{0}', 'Profit Order Price'));
                            }
                            else {
                                if (decChkProfitOrderPrice <= MPLTP)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL366").replace('{0}', 'Profit Order Price'));
                            }
                        }
                        else {
                            if (decChkPrice != 0) {
                                if (decChkProfitOrderPrice >= decChkPrice)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL363").replace('{0}', 'Profit Order Price'));
                            }
                            else {
                                if (decChkProfitOrderPrice >= MPLTP)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL364").replace('{0}', 'Profit Order Price'));
                            }
                        }
                    }
                }
            }
            if (bAMO) {
                if (this.getStatus(MarketSegmentId) != clsConstants.C_S_AMO_TEXT) {
                    this.addError("AMO", clsGlobal.dMsgMaster.getItem("OE201"));
                }
            }
            //End

        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateOrder', 'ICEX.js', '');


        }
        return this.arrError;
    }

    populateMarketStatus(sMktSegData, sMarketType, sStatusFlag, sAucSessionNo) {
        try {
            if (sMktSegData == "5") {

                if (sMarketType == "1")
                    this.sICEXDervNormalMkt = sStatusFlag;
                else if (sMarketType == "7")
                    this.sICEXDervAMOMkt = sStatusFlag;
                else if (sMarketType == "8")        //ICEX Call Auction
                {
                    if (sStatusFlag == "1")
                        this.sICEXAUCBI = "Open";
                    else
                        this.sICEXAUCBI = "Close";
                    this.sICEXAUCBISessionNo = sAucSessionNo;
                }
                else if (sMarketType == "9")        //ICEX Call Auction
                {
                    if (sStatusFlag == "1")
                        this.sICEXAUCSO = "Open";
                    else
                        this.sICEXAUCSO = "Close";
                    this.sICEXAUCSOSessionNo = sAucSessionNo;
                }
                else if (sMarketType == "10")        //ICEX Call Auction
                {
                    if (sStatusFlag == "1")
                        this.sICEXAUCTBI = "Open";
                    else
                        this.sICEXAUCTBI = "Close";
                    this.sICEXAUCTBISessionNo = sAucSessionNo;
                }
                else if (sMarketType == "11")        //ICEX Call Auction
                {
                    if (sStatusFlag == "1")
                        this.sICEXAUCTSO = "Open";
                    else
                        this.sICEXAUCTSO = "Close";
                    this.sICEXAUCTSOSessionNo = sAucSessionNo;
                }

            }
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatus', 'ICEX.js', '');
        }
    }

    getStatus(sMktSegData) {
        try {
            let sMktStatus = '';

            if (sMktSegData == clsConstants.C_V_ICEX_DERIVATIVES)
                sMktStatus = this.sICEXStatus = clsGlobal.ExchManager.getMktStatusDesc(this.sICEXDervNormalMkt, this.sICEXDervAMOMkt, "", sMktSegData);

            return sMktStatus;
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetStatus', 'ICEX.js', '');


        }
    }

    getAuctionStatusData() {
        let jsonobj = [];
        try {

            jsonobj.push({ "SessionType": "Auction Buy In", "SessionNumber": this.sICEXAUCBISessionNo, "SessionStatus": this.sICEXAUCBI })
            jsonobj.push({ "SessionType": "Auction Sell Out", "SessionNumber": this.sICEXAUCSOSessionNo, "SessionStatus": this.sICEXAUCSO })
            jsonobj.push({ "SessionType": "Auction Trading Buy In", "SessionNumber": this.sICEXAUCTBISessionNo, "SessionStatus": this.sICEXAUCTBI })
            jsonobj.push({ "SessionType": "Auction Trading Sell out", "SessionNumber": this.sICEXAUCTSOSessionNo, "SessionStatus": this.sICEXAUCTSO })
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetAuctionStatusData', 'ICEX.js', '');


        }
        return jsonobj;
    }

}