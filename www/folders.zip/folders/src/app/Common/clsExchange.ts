﻿import {clsTradingMethods} from './clsTradingMethods';

//An Exchange class
export class clsExchange {

    exchangeDesc: any;
    marketSegmentId: any;
    instrName: any;
    shortInstrName: any;
    mappedMarketSegmentId: any;
    mappedExcInstName: any;
    exchName: any;

    constructor(mktSgmtId: any, exchangeDesc: any, shrtInstrName?: any, instName?: any) {

        this.exchangeDesc = exchangeDesc;
        this.marketSegmentId = mktSgmtId;
        this.instrName = instName;
        this.shortInstrName = shrtInstrName;

        this.mappedMarketSegmentId = clsTradingMethods.getMappedMarketSegmentId(this.marketSegmentId);
        this.mappedExcInstName = clsTradingMethods.getExchangeName(this.marketSegmentId) + " " + this.shortInstrName;
        this.exchName = clsTradingMethods.getExchangeName(this.marketSegmentId);
    }
}