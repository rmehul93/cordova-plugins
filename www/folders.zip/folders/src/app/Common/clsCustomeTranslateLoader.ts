import { Injectable } from '@angular/core';
import { TranslateLoader } from '@ngx-translate/core';
import { clsGlobal } from "./clsGlobal"
import {Observable} from 'rxjs/Observable';
import {clsHttpService} from '../Common/clsHTTPService';

@Injectable({ providedIn: 'root' })
export class clsCustomTranslateLoader implements TranslateLoader  {
       //contentHeader = new Headers({"Content-Type": "application/json","Access-Control-Allow-Origin":"*"});

    constructor(
        public clsHttpService : clsHttpService

        ) {
        console.log("some ");
    }
    getTranslation(lang: string): Observable<any>{

        return Observable.create(observer => {

          if(lang!="english" && lang!=""){
          this.clsHttpService.get(clsGlobal.VirtualDirectory, 'nontransactional/files/' + clsGlobal.LocalComId + 'v1/' +lang + ".json" ).subscribe((respData:any) => {
            observer.next(JSON.parse(respData));
            observer.complete();
          }, error => {
            observer.next();
            observer.complete();
          });
        }
        else
        {
          let _engblankjson:any={};
          observer.next(_engblankjson);
          observer.complete();
        }}); 
    }
}

  export function createTranslateLoader(clshttpService : clsHttpService) {
  return new clsCustomTranslateLoader(clshttpService);
}

