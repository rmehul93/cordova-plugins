﻿import { clsTradingMethods } from './clsTradingMethods';
import { String } from 'typescript-string-operations';
import { clsScrip } from './clsScrip';

export class clsScripKey {
    constructor() {
    }
   
    public isGlobal: string = "0"; /// 0 - Normal scrip & 1 - Global scrip
    private _MktSegId: number;/// Normal Market Segment Id
    get MktSegId() {
        return this._MktSegId;
    }
    set MktSegId(value:number) {
        this._MktSegId = value;
        this._MapMktSegId = clsTradingMethods.getMappedMarketSegmentId(value);
    }
    public token: string = '';
    private _MapMktSegId: number;
    get MapMktSegId() {
        return this._MapMktSegId;
    }
    
    toString(): string
    {
        return  String.Join("-",this._MktSegId.toString(),this._MapMktSegId.toString() ,this.token);
    }
}

export class clsScripStoreItem{
    constructor() {
    }

    public count: number =0;
    public key:clsScripKey;
    public scripDet:clsScrip;

}
