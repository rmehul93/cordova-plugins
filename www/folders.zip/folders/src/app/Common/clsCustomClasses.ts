export interface IKeyedCollection<T> {
    Add(key: string, value: T);
    ContainsKey(key: string): boolean;
    Count(): number;
    getItem(key: string): T;
    Keys(): string[];
    Remove(key: string): T;
    setItems(obj: Object);
    Clear();
}

export class Dictionary<T> implements IKeyedCollection<T> {
    
    private items: { [index: string]: T } = {};
 
    private count: number = 0;
 
    public ContainsKey(key: string): boolean {
        return this.items.hasOwnProperty(key);
    }
 
    public Count(): number {
        return this.count;
    }
 
    public Add(key: string, value: T) {
        if(!this.items.hasOwnProperty(key))
             this.count++;
 
        this.items[key] = value;
    }
 
    public Remove(key: string): T {
        var val = this.items[key];
        delete this.items[key];
        this.count--;
        return val;
    }

    public setItems(obj: Object)
    {
        for (let item in obj) {
            if (obj.hasOwnProperty(item)) {
                this[item] = obj[item];
                this.count++;
            }
        }
    }
 
    public getItem(key: string): T {
        return this.items[key];
    }
 
    public Keys(): string[] {
        var keySet: string[] = [];
 
        for (var prop in this.items) {
            if (this.items.hasOwnProperty(prop)) {
                keySet.push(prop);
            }
        }
 
        return keySet;
    }
 
    public Values(): T[] {
        var values: T[] = [];
 
        for (var prop in this.items) {
            if (this.items.hasOwnProperty(prop)) {
                values.push(this.items[prop]);
            }
        }
 
        return values;
    }

    public Clear() {
        this.items = {}
        this.count = 0;
    }
}


export class StringBuilder {

    strings = new Array<string>();

    public Append(str) {
        str = this.verify(str);
        if (str.length > 0) this.strings[this.strings.length] = str;
    }

    public appendLine(string) {
        string = this.verify(string);
        if (this.isEmpty()) {
            if (string.length > 0) this.strings[this.strings.length] = string;
            else return;
        }
        else this.strings[this.strings.length] = string.length > 0 ? "\r\n" + string : "\r\n";
    }

    public isEmpty() {
        return this.strings.length == 0;
    }

    public toString() {
        return this.strings.join("");
    }

    verify(s) {
        if (!this.defined(s)) return "";
        if (this.getType(s) != this.getType(new String())) return String(s);
        return s;
    }

    defined(el) {
        return el != null && typeof (el) != "undefined";
    }

    getType(inst) {
        if (!this.defined(inst.constructor)) throw Error("Unexpected object type");
        var type = String(inst.constructor).match(/function\s+(\w+)/);
        return this.defined(type) ? type[1] : "undefined";
    }
}



