import { clsScripKey } from './clsScripKey';
import { clsConstants } from './clsConstants';
import { clsTradingMethods } from './clsTradingMethods';
import { String } from 'typescript-string-operations';

export class clsScrip {
    constructor() {
        this.scripDet = new clsScripKey();
    }
    public scripDet: clsScripKey;
    public symbol: string = "";
    private _Series: string = "";
    get Series() { return this._Series; }
    set Series(newValue: string) {
        let strSeries = newValue;
        if (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSEL_SPOT || this.scripDet.MktSegId == clsConstants.C_V_NSEL_SPOT)
            strSeries = "EQ";
        else if (!(strSeries) || strSeries.trim() == "XX")
            strSeries = "NA";
        else
            strSeries = strSeries.trim();

        this._Series = strSeries;
    }

    private _InstrumentName: string = "";
    get InstrumentName() { return this._InstrumentName; }
    set InstrumentName(newValue) {
        var strInstrumentName = newValue;
        if (strInstrumentName == String.Empty)
            strInstrumentName = clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT;
        else if (strInstrumentName.trim() == clsConstants.C_S_INSTRUMENT_MCXFUTSPT_TEXT && this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSEL_SPOT)
            strInstrumentName = clsConstants.C_S_INSTRUMENT_MCXFUTSPT_TEXT;
        else if (strInstrumentName.trim() == clsConstants.C_S_INSTRUMENT_MCXFUTSPT_TEXT || strInstrumentName.trim() == clsConstants.C_S_INSTRUMENT_NCDEXSPOT_TEXT)
            strInstrumentName = clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT;
        else if (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_DSE_CASH)
            strInstrumentName = clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT;
        else
            strInstrumentName = strInstrumentName.toUpperCase().trim();

        this._InstrumentName = strInstrumentName;
    }

    private _ExchangeName: string = "";
    get ExchangeName() {
        if (this.scripDet.MktSegId != undefined) {
            let _ExchName = clsTradingMethods.getExchangeName(this.scripDet.MktSegId);
            this._ExchangeName = _ExchName;
        }
         return this._ExchangeName; 
    }
    set ExchangeName(newValue) {
        this._ExchangeName = newValue;
        // if (this.scripDet.MktSegId != undefined) {
        //     var _ExchName = newValue;
        //     _ExchName = clsTradingMethods.getExchangeName(this.scripDet.MktSegId);
        //     this._ExchangeName = _ExchName;
        // }
    }

    private _ExpiryDate: string = "";
    get ExpiryDate() { return this._ExpiryDate; }
    set ExpiryDate(newValue: string) {
        let strExpiryDate = newValue;

        if (!(strExpiryDate) || strExpiryDate.trim() == "01Jan1980" || strExpiryDate.trim() == "0" || strExpiryDate.toUpperCase().replace(" ", "") == "01JAN2020")
            strExpiryDate = "NA";
        else {
            if (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSEL_DERIVATIVES && this.InstrumentName.trim() != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)
                strExpiryDate = "NA";
            else if (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_CASH || this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_DSE_CASH)
                strExpiryDate = "NA";
            else
                strExpiryDate = strExpiryDate.toUpperCase().trim();
        }
        this._ExpiryDate = strExpiryDate;
    }

    private _OptionType: string = "";
    get OptionType() { return this._OptionType; }
    set OptionType(newvalue) {
        let strOptionType = newvalue;
        if (strOptionType == String.Empty || strOptionType == undefined || strOptionType.trim() == "XX") //change by pallavi
            strOptionType = "NA";
        else
            strOptionType = strOptionType.trim();

        this._OptionType = strOptionType;
    }

    private _StrikePrice: string = "";
    get StrikePrice() { return this._StrikePrice; }
    set StrikePrice(newValue) {
        var strStrikePrice = newValue;
        if (strStrikePrice == undefined || strStrikePrice == "undefined" || strStrikePrice == "" || strStrikePrice.trim() == "-1" || strStrikePrice.trim() == "0" || strStrikePrice.trim() == "0.00" || strStrikePrice.trim() == "-0.01" || strStrikePrice.trim() == "0.0000" || strStrikePrice.trim() == "-0.0001" || strStrikePrice.trim() == "-1.00")
            strStrikePrice = "NA";
        else {
            if (strStrikePrice.toString().trim().indexOf('.') == -1) {
                if (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES && this.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                    strStrikePrice = clsTradingMethods.ConvertToRe(strStrikePrice.trim(), this.scripDet.MapMktSegId, "10000");
                else if ((this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES && this.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT) || (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BFX_DERIVATIVES)
                    || (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_FAO) || (this.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES && this.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT))
                    strStrikePrice = clsTradingMethods.ConvertToRe(strStrikePrice.trim(), this.scripDet.MapMktSegId, this.DecimalLocator);
                else
                    strStrikePrice = clsTradingMethods.ConvertToReWithPrice(strStrikePrice.trim());
            }
        }

        this._StrikePrice = strStrikePrice;

    }

    public MarketLot: number = 0;
    public PriceTick: number = 0;
    public SecurityDesc: string = "";
    public MWSecurityDesc: string = "";
    public DecimalLocator: any = "";
    public PriceFormat: string = "";
    public ISIN: string = "";
    public SPOS: string = "";
    public POS: string = "";
    public OrderType: string = "";
    public Quantity: number = 0;
    public Price: number = 0;
    public ProductType: string = "";
    public AssetToken: string = "";
    public Spread: string = "";
    public FIILimit: string = "";
    public NRILimit: string = "";
    public FOExists: string = "";
    public MarginTypeIndicator: string = "";

    public priceNumerator: any = 1;
    public priceDenominator: any = 1;
    public genNumerator: any = 1;
    public genDenominator: any = 1;
    public intrinsicValue: any = 1;

    public displaySymbol: string = "";
    public displaySeries: string = "";
    public displayExchange: string = "";
    public displayInstrument: string = "";
    public displayExpiryDate: string = "";
    public displayStrikePrice: string = "";
    public displayOptionType: string = "";

    public exchangeColorCss: string = "";
    public isIndex: boolean = false;
    public spotIndex:any = 0;

    formatScripDisplayName() {
        let strSymbol = (this.symbol != null && this.symbol != undefined) ? this.symbol : "";
        this.displaySymbol = strSymbol.trim();
        this.displaySeries = '';
        let iSegId = (this.scripDet.MktSegId);

        let strExchangeName = this.ExchangeName;
        let sInstrumentName = this.InstrumentName;
        if (sInstrumentName == 'EQUITIES') {
            sInstrumentName = '';
        }
        else {
            if (sInstrumentName.startsWith('OPT')) {
                sInstrumentName = '';
            } else {
                sInstrumentName = sInstrumentName.substring(0, 3);
            }
        }
        if (iSegId == clsConstants.C_V_NSE_DERIVATIVES) {
            strExchangeName = 'NFAO';
        } else if (iSegId == clsConstants.C_V_BSE_DERIVATIVES) {
            strExchangeName = 'BFAO';
        }
        else if (iSegId == clsConstants.C_V_MSX_FAO) {
            strExchangeName = 'MFAO';
        }
        else if (iSegId == clsConstants.C_V_NSX_DERIVATIVES) {
            strExchangeName = 'NCDS';
        }
        else if (iSegId == clsConstants.C_V_BSECDX_DERIVATIVES) {
            strExchangeName = 'BCDS';
        }
        else if (iSegId == clsConstants.C_V_MSX_DERIVATIVES) {
            strExchangeName = 'MCDS';
        }
        else if (iSegId == clsConstants.C_V_MSX_DERIVATIVES) {
            strExchangeName = 'MCDS';
        }

        this.displayExchange = strExchangeName;//.substring(0, 1);
        this.displayInstrument = sInstrumentName;
        let strExpDate = (this.ExpiryDate != null && this.ExpiryDate != undefined && this.ExpiryDate != "NA") ? this.ExpiryDate : "";
        if (strExpDate != '' && strExpDate != undefined)
            this.displayExpiryDate = strExpDate.substring(0, 2) + ' ' + strExpDate.substring(2, 5) + '\'' + strExpDate.substring(7, 9);

        let strStkPrice = '';
        strStkPrice = (this.StrikePrice != null && this.StrikePrice != undefined && this.StrikePrice != "NA" && this.StrikePrice != "-1") ? this.StrikePrice : "";
        this.displayStrikePrice = strStkPrice;
        var strOptType = '';
        strOptType = (this.OptionType != null && this.OptionType != undefined && this.OptionType != "NA" && this.OptionType != "XX") ? this.OptionType : "";
        this.displayOptionType = strOptType;

        this.exchangeColorCss = clsTradingMethods.getExchangeColor(iSegId);

        // let sbScrip = new StringBuilder();
        // sbScrip.Append(strSymbol.trim());
        // sbScrip.Append(strExpDate.trim());
        // sbScrip.Append(strStkPrice.trim());
        // sbScrip.Append(strOptType);
        // sbScrip.Append(this._Series.trim());
        // sbScrip.Append(sInstrumentName.trim());
        //this.MWSecurityDesc = sbScrip.ToString();
        let tarr = [];
        tarr.push([strSymbol.trim(), strExpDate.trim(), strStkPrice.trim(), strOptType.trim(), this._Series.trim(), sInstrumentName.trim()]);

        this.MWSecurityDesc = tarr.join(" ").replace(/,/gi, " ");

    }

    formatScripExpiryinfo() {

        if (this.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
            this.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
            this.scripDet.MktSegId != clsConstants.C_V_MSX_CASH
        ) {
            let sInstrumentName = this.InstrumentName.substring(0, 3);

            let strExpDate = (this.ExpiryDate != null && this.ExpiryDate != undefined && this.ExpiryDate != "NA") ? this.ExpiryDate : "";
            if (strExpDate != '' && strExpDate != undefined)
                strExpDate = strExpDate.substring(0, 2) + ' ' + strExpDate.substring(2, 5) + "'" + strExpDate.substring(7, 9);

            let strStkPrice = '';
            strStkPrice = (this.StrikePrice != null && this.StrikePrice != undefined && this.StrikePrice != "NA" && this.StrikePrice != "-1") ? this.StrikePrice : "";
            let strOptType = '';
            strOptType = (this.OptionType != null && this.OptionType != undefined && this.OptionType != "NA" && this.OptionType != "XX") ? this.OptionType : "";

            let tarr = [];
            tarr.push([sInstrumentName, strExpDate.trim(), strStkPrice.trim(), strOptType.trim()]);

            return tarr.join(" ").replace(/,/gi, " ");
        } else {
            return "";
        }
    }

}