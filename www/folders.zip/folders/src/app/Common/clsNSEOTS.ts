import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsCommonMethods } from './clsCommonMethods';
import { IKeyedCollection, Dictionary } from './clsCustomClasses';


export class clsNSEOTS {

    arrInst = []; // Hash table for Holding Instruments for the selected / passed exchange (key would be ExchName and value would be list of instruments)
    arrOrderType = []; // List of Order Types allowed in this exchange
    arrProductType = []; // List of Product Types allowed in this exchange
    arrValidity = []; // List of Validities allowed in this exchange
    arrError = [];
    dcMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();
    dcDecimalLoc: IKeyedCollection<number> = new Dictionary<number>();
    dcMapMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();
    dcEnableDisableFields: IKeyedCollection<boolean> = new Dictionary<boolean>();
    //Fields for Maret Status
    sNSEOTSNormalMkt: string = '-';
    sNSEOTSAMOMkt: string = '-';
    sNSEOTSStatus: string = '-';

    //Following arrays required for lookup
    arrScripMaster = []; //array of Scrips for NSE
    arrSeries = [];
    arrExpiryDate = [];
    arrStrikePrice = [];
    arrOptionType = [];

    constructor(InstName) {
        this.arrInst = InstName.split('$'); // Split the Instrument string which is $ separated and create the instrument list...
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT, clsConstants.C_V_OFS_IPO_BONDS);
        this.dcDecimalLoc.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), clsConstants.C_V_NORMAL_DECIMALLOCATOR);
        this.dcMapMarketSegementId.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), clsConstants.C_V_MAPPED_OFS_IPO_BONDS);
        this.dcEnableDisableFields.Add("hasBuySell", true);
        this.dcEnableDisableFields.Add("hasExchange", true);
        this.dcEnableDisableFields.Add("hasInstrument", true);
        this.dcEnableDisableFields.Add("hasSymbol", true);
        this.dcEnableDisableFields.Add("hasOrderType", true);
        this.dcEnableDisableFields.Add("hasQty", true);
        this.dcEnableDisableFields.Add("hasPrice", true);
        this.dcEnableDisableFields.Add("hasDiscQty", true);
        this.dcEnableDisableFields.Add("hasTriggerPrice", true);
        this.dcEnableDisableFields.Add("hasProductType", true);
        this.dcEnableDisableFields.Add("hasValidity", true);
        this.dcEnableDisableFields.Add("hasDay", true);
        this.dcEnableDisableFields.Add("hasSeries", true);
        this.dcEnableDisableFields.Add("hasOptionType", true);
        this.dcEnableDisableFields.Add("hasExpire", true);
        this.dcEnableDisableFields.Add("hasProdPer", true);
        this.dcEnableDisableFields.Add("hasStrikePrice", true);
        this.dcEnableDisableFields.Add("hasCOL", false);
        this.dcEnableDisableFields.Add("hasCutOff", false);
        this.dcEnableDisableFields.Add("hasTrailingSL", false);
    }

    // Function to Enable / Disable the UI Elements property based on the the instument...
    enableDisable(InstName) {
        try {
            // Case for EQ Segment....
            if (InstName == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                // For NSE Cash Series,Day & Disc Qty will be in enabled mode
                this.dcEnableDisableFields.Add("hasSeries" ,  true);
                // this.dcEnableDisableFields.Add("hasDiscQty" ,  true;
                // this.dcEnableDisableFields.Add("hasDay" ,  true;

                // The following will be in disabled mode...
                this.dcEnableDisableFields.Add("hasBuySell" ,  false);
                this.dcEnableDisableFields.Add("hasOptionType" ,  false);
                this.dcEnableDisableFields.Add("hasOrderType" ,  false);
                this.dcEnableDisableFields.Add("hasExpire" ,  false);
                this.dcEnableDisableFields.Add("hasProdPer" ,  false);
                this.dcEnableDisableFields.Add("hasStrikePrice" ,  false);
                this.dcEnableDisableFields.Add("hasValidity" ,  false);
                this.dcEnableDisableFields.Add("hasDiscQty" ,  false);
                this.dcEnableDisableFields.Add("hasCOL" ,  false);
                this.dcEnableDisableFields.Add("hasProductType" ,  false);
                this.dcEnableDisableFields.Add("hasTriggerPrice" ,  false);
            }
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'EnableDisable', 'NSEOTS.js', '');
        }
        // return the dictionary with the values based on the instrument...
        return this.dcEnableDisableFields;
    }

    // Split the validity string and populate the array...
    populateValidity(Validity) {
        try {
            this.arrValidity = Validity.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateValidity', 'NSEOTS.js', '');

        }
    }

    // Split the Product Types string and populate the array...
    populateProductTypes(ProductTypes) {
        try {
            this.arrProductType = ProductTypes.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateProductTypes', 'NSEOTS.js', '');

        }
    }


    // Split the Product Types string and populate teh array...
    populateOrderTypes(OrderTypes) {
        try {
            this.arrOrderType = OrderTypes.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes', 'NSEOTS.js', '');

        }
    }

    // Get the details for the selected Order Type
    getDetailsForOrderType(OrderTypes, InstName) {
        try {
            if (OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
                this.dcEnableDisableFields.Add("hasTriggerPrice" ,  false);
                this.dcEnableDisableFields.Add("hasDiscQty" ,  false);
            }
            else if (OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                this.dcEnableDisableFields.Add("hasTriggerPrice" ,  true);
                this.dcEnableDisableFields.Add("hasDiscQty" ,  false);
            }

        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForOrderType', 'NSEOTS.js', '');

        }
        return this.dcEnableDisableFields;
    }

    getDetailsForValidity(Validity) {
        try {
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                this.dcEnableDisableFields.Add("hasDay" ,  true);
            }
            else {
                this.dcEnableDisableFields.Add("hasDay" ,  false);
            }
            //                if (_Validity == clsConstants.C_S_VALUE_IOC) {
            //                    this.dcEnableDisableFields.Add("hasDiscQty" ,  false;
            //                }
            //                else {
            //                    this.dcEnableDisableFields.Add("hasDiscQty" ,  true;
            //                }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity', 'NSEOTS.js', '');


        }
        return this.dcEnableDisableFields;
    }

    // Get the details of MktProtPerc, This Exchange doesn't support this functionality hence returning default values
    getDetailsForMktProtPerc(MapMarketSegmentId, Price, _MarketSegmentId, MPPrice, ProdType) {
        var ProtPerc = '', ProtPercOrderPref = '';
        return [this.dcEnableDisableFields, ProtPerc, ProtPercOrderPref];
    }

    // Function to Validate the scripdetails...
    validateScripDetails(dcLookupDetails) {
        this.arrError = [];
        try {
            //var clsGlobal.dMsgMaster = new fn_HashTable();

            //var Exchange = dcLookupDetails["SelExchange"] == undefined ? '' : dcLookupDetails["SelExchange"];
            var Instrument = dcLookupDetails["SelInstrument"] == undefined ? '' : dcLookupDetails["SelInstrument"];
            //var MarketSegmentId = dcLookupDetails["MarketSegmentId"] == undefined ? '' : dcLookupDetails["MarketSegmentId"];

            var Symbol = dcLookupDetails["SelSymbol"] == undefined ? '' : dcLookupDetails["SelSymbol"];
            var Series = dcLookupDetails["SelSeries"] == undefined ? '' : dcLookupDetails["SelSeries"];
            var StrikePrice = dcLookupDetails["SelStrikePrice"] == undefined ? '' : dcLookupDetails["SelStrikePrice"];
            var OptionType = dcLookupDetails["SelOptionType"] == undefined ? '' : dcLookupDetails["SelOptionType"];
            var ExpiryDate = dcLookupDetails["SelExpDate"] == undefined ? '' : dcLookupDetails["SelExpDate"];

            //var MarketLot = dcLookupDetails["SelScripMarketLot"] == undefined ? '' : dcLookupDetails["SelScripMarketLot"];
            //var DecimalLocator = dcLookupDetails["SelScripDecimalloc"] == undefined ? '' : dcLookupDetails["SelScripDecimalloc"];

            //var PriceTick = dcLookupDetails["SelScripPriceTick"] == undefined ? '' : dcLookupDetails["SelScripPriceTick"];
            //var TokenNo = dcLookupDetails["SelScripToken"] == undefined ? '' : dcLookupDetails["SelScripToken"];

            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            // Validation for Cash Market...
            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                if (Series.length == 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL27"));
                if (ExpiryDate.length != 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL28"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL29"));
                if (OptionType.length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL30"));
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateScripDetails', 'NSEOTS.js', '');

        }
        return this.arrError;
    }

    addError(sErrElement, sErrMsg) {
        this.arrError.push(sErrMsg);
    }

    // Function to Validate the orders...
    validateOrder(dcOrderDetails) {
        this.arrError = [];
        try {
            //var clsGlobal.dMsgMaster = new fn_HashTable();

            var BuySell = dcOrderDetails.getItem("SelOperation") == undefined ? '' : dcOrderDetails.getItem("SelOperation");
            //var Exchange = dcOrderDetails.getItem("SelExchange") == undefined ? '' : dcOrderDetails.getItem("SelExchange");
            var Instrument = dcOrderDetails.getItem("SelInstrument") == undefined ? '' : dcOrderDetails.getItem("SelInstrument");
            var MarketSegmentId = dcOrderDetails.getItem("MarketSegmentId") == undefined ? '' : dcOrderDetails.getItem("MarketSegmentId");
            //var Validity = dcOrderDetails.getItem("SelValidity") == undefined ? '' : dcOrderDetails.getItem("SelValidity");
            var ProductType = dcOrderDetails.getItem("SelProduct") == undefined ? '' : dcOrderDetails.getItem("SelProduct");

            var OrderType = dcOrderDetails.getItem("SelOrderTypes") == undefined ? '' : dcOrderDetails.getItem("SelOrderTypes");
            var OrderSide = dcOrderDetails.getItem("SelOperation") == undefined ? '' : dcOrderDetails.getItem("SelOperation");
            var Symbol = dcOrderDetails.getItem("SelSymbol") == undefined ? '' : dcOrderDetails.getItem("SelSymbol");
            var Series = dcOrderDetails.getItem("SelSeries") == undefined ? '' : dcOrderDetails.getItem("SelSeries");
            var StrikePrice = dcOrderDetails.getItem("SelStrikePrice") == undefined ? '' : dcOrderDetails.getItem("SelStrikePrice");

            var OptionType = dcOrderDetails.getItem("SelOptionType") == undefined ? '' : dcOrderDetails.getItem("SelOptionType");
            var ExpiryDate = dcOrderDetails.getItem("SelExpire") == undefined ? '' : dcOrderDetails.getItem("SelExpire");
            var ProtPerc = dcOrderDetails.getItem("SelProdPer") == undefined ? '' : dcOrderDetails.getItem("SelProdPer");
            var Quantity = dcOrderDetails.getItem("SelQty") == undefined ? 0 : dcOrderDetails.getItem("SelQty");
            var Price = dcOrderDetails.getItem("SelPrice") == undefined ? '' : dcOrderDetails.getItem("SelPrice");
            var MPPrice = dcOrderDetails.getItem("MPPrice") == undefined ? '' : dcOrderDetails.getItem("MPPrice");

            var DiscQty = dcOrderDetails.getItem("SelDiscQty") == undefined ? '' : dcOrderDetails.getItem("SelDiscQty");
            var TriggerPrice = dcOrderDetails.getItem("SelTriggerPrice") == undefined ? '' : dcOrderDetails.getItem("SelTriggerPrice");
            //var Days = dcOrderDetails.getItem("SelDay") == undefined ? '' : dcOrderDetails.getItem("SelDay");
            var MarketLot = dcOrderDetails.getItem("SelMarketLot") == undefined ? '' : dcOrderDetails.getItem("SelMarketLot");
            var DecimalLocator = dcOrderDetails.getItem("SelDecimalloc") == undefined ? '' : dcOrderDetails.getItem("SelDecimalloc");

            var PriceTick = dcOrderDetails.getItem("SelPriceTick") == undefined ? '' : dcOrderDetails.getItem("SelPriceTick");
            var TokenNo = dcOrderDetails.getItem("SelToken") == undefined ? '' : dcOrderDetails.getItem("SelToken");


            //var MarketStatus = dcOrderDetails.getItem("MarketStatus") == undefined ? '' : dcOrderDetails.getItem("MarketStatus");
            var ModifyFlag = dcOrderDetails.getItem("ModifyFlag") == undefined ? false : dcOrderDetails.getItem("ModifyFlag");

            var ChkCutOff = dcOrderDetails.getItem("ChkCutOff") == undefined ? '' : dcOrderDetails.getItem("ChkCutOff");
            var IsCutOffAllowed = dcOrderDetails.getItem("IsCutOffAllowed") == undefined ? '' : dcOrderDetails.getItem("IsCutOffAllowed");

            var IsCutOffVisible = dcOrderDetails.getItem("hasCutOff") == undefined ? false : dcOrderDetails.getItem("hasCutOff");
            var CapPrice = dcOrderDetails.getItem("CapPrice") == undefined ? '0' : dcOrderDetails.getItem("CapPrice");
            var FloorPrice = dcOrderDetails.getItem("FloorPrice") == undefined ? '0' : dcOrderDetails.getItem("FloorPrice");
            var bAMO = dcOrderDetails.getItem("AMO") == undefined ? false : dcOrderDetails.getItem("AMO");

            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            if (BuySell == clsConstants.C_S_ORDER_SELL_TEXT) {
                this.addError("Symbol", "Sell order not allowed for this segment");
            }

            // Validation for Cash Market...
            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                if (Series.length == 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL27"));
                if (ExpiryDate.toString().length != 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL28"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL29"));
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL30"));
                if (isNaN(ProtPerc))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL31"));
            }

             /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Protection Percent validation for bracket order entry> **/
             if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                if ((MPPrice == 0 || MPPrice == undefined || MPPrice == '') &&
                    (ProtPerc == 0 || ProtPerc == undefined || ProtPerc == '')) {
                    this.addError("ProtPerc", 'Please Enter Protection Percent');
                }
            }


            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }
            //Series
            if (Series.length > 0) {
                var regSeries = new RegExp("([A-Za-z0-9]$)");
                if (!regSeries.test(Series))
                    this.addError("Series1", clsGlobal.dMsgMaster.getItem("NNSL40"));
            }

            // Product Type
            if (ProductType.length == 0) {
                this.addError("ProductType1", "Product Type cannot be blank");
            }

            //////////////////////// Secondary Validations ///////////////////////////
            // if (!HasErrors)
            {
                // Market lot validation...
                if (MarketLot.length == 0)
                    this.addError("MarketLot", "Market Lot cannot be empty");

                // Get the Decimal locator from the scrip if not there consider the defulat value...
                if (DecimalLocator == '' || DecimalLocator == 0)
                    DecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
                var _AllowedDecimal = DecimalLocator.toString().length - 1;

                var PriceinPaise = 0;
                var TrigPriceinPaise = 0;
                var decChkTrgPrice = 0;
                var decChkPrice = 0;
                // Lot based segment, so caption should be Lot...
                var DiscQtyCaption = "Disclosed " + clsConstants.CONST_QTY_CAPTION;
                var QtyCaption = clsConstants.CONST_QTY_CAPTION;

                // If it is eq then it is qty based segment, so caption should be qty...
                if (dcOrderDetails.getItem("SelInstrument") == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                    DiscQtyCaption = "Disclosed " + clsConstants.CONST_QTY_CAPTION;
                    QtyCaption = clsConstants.CONST_QTY_CAPTION;
                }


                //Quantity related Validations
                if (isNaN(Quantity)) {
                    this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption);
                }
                else if (!isNaN(Quantity)) {
                    if (Quantity <= 0 && (!(ModifyFlag && ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT))) {
                        this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL45"));
                    }
                    if (Quantity != 0 && Quantity != "") {
                        if (parseInt(Quantity) % parseInt(MarketLot) != 0) {
                            if (MarketLot != "999999999") {
                                if (TokenNo != "")
                                    this.addError("Quantity1", clsGlobal.dMsgMaster.getItem("NNSL46") + MarketLot);
                            }
                        }

                        // Case to check Quantity should not have decimal character
                        if (Quantity.toString().indexOf('.') != -1)
                            this.addError("Quantity2", QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));
                    }
                }
                // Quantity related Validation ends here....

                //Disclosed Quantity related Validations
                //  Case to validate Disc Qty Entered. Here case has been checked for Disc LOT as well as Disc Qty.

                if (!isNaN(DiscQty))      //If Disc Qty has some value
                {
                    if (DiscQty != 0 && DiscQty != "") {
                        if (!isNaN(Quantity))            //If Qty has some value
                        {
                            if (parseInt(DiscQty) > parseInt(Quantity))
                                this.addError("DiscQty", clsGlobal.dMsgMaster.getItem("NNSL44") + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL48") + QtyCaption);

                            /* Below here comparision is made between Disc Qty/LOT and Original Qty/LOT
                            as per Exchange/Instrument rules specified   */
                            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT)          //Case: EQUITIES
                            {
                                if (DiscQty != 0) {
                                    //For Equity Disc Qty cannot be less than 10% of Original Qty entered
                                    if ((Quantity / 10) > DiscQty)
                                        this.addError("DiscQty1", clsGlobal.dMsgMaster.getItem("NNSL49"));
                                }
                            }
                            else {
                                //For Derivative segment (FUTIDX / FUTSTK / OPTIDX / OPTSTK) Disc Qty cannot be less than 100% of Original Qty
                                if (DiscQty != 0) {
                                    if ((Quantity != DiscQty) && (DiscQty != 0))
                                        this.addError("DiscQty1", clsGlobal.dMsgMaster.getItem("NNSL51") + "Disc" + clsConstants.CONST_LOT_CAPTION + "The Disc" + clsConstants.CONST_LOT_CAPTION + clsGlobal.dMsgMaster.getItem("NNSL54") + clsConstants.CONST_LOT_CAPTION);
                                }
                            }
                        }


                        // Case to check Quantity should not have decimal character
                        if (DiscQty.toString().indexOf('.') != -1)
                            this.addError("DiscQty3", DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));

                        if (parseInt(DiscQty) % parseInt(MarketLot) != 0) {
                            if (MarketLot != "999999999") {
                                if (TokenNo != "")
                                    this.addError("DiscQty4", clsGlobal.dMsgMaster.getItem("NNSL57") + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL58") + MarketLot);
                            }
                        }
                    }
                }

                //////////////////////// disclosed qty validation ends here.....//////////////////////////////

                // Validations related to Price
                if (!isNaN(Price)) {
                    if (Price < 0) {
                        this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL59"));
                    }
                    if (Price != 0) {

                        decChkPrice = parseFloat(Price);

                        if (!(clsCommonMethods.DecDigits(decChkPrice.toString(), _AllowedDecimal)))
                            this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL61"));

                        PriceinPaise = parseInt(Math.round(parseFloat((Price * DecimalLocator).toString())).toString());

                        if (PriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                            }
                        }
                    }
                    // else {
                    //     //If price is 0 and order type selected are RL/SL --> Show error message
                    //     if (ProductType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                    //         if (OrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)
                    //             this.addError("Price", "Price cannot be zero for Limit order");
                    //     }
                    // }
                }


                // Validations of Price ends

                /* Validations to check TriggerPrice */


                if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                    OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {

                    if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                        if (Price == 0) {
                            this.addError("Price", "Price cannot be zero for Limit order");
                        }
                    }

                    if (isNaN(TriggerPrice))
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL65"));

                    if (TriggerPrice < 0) {
                        this.addError("TriggerPrice", 'Please enter valid Trigger Price. Trigger Price cannot be negative.');
                    }

                    if (!isNaN(TriggerPrice)) {
                        if (TriggerPrice == 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL66"));
                        else {
                            decChkTrgPrice = parseFloat(TriggerPrice);

                            if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL68"));

                            TrigPriceinPaise = parseInt(Math.round(parseFloat((TriggerPrice * DecimalLocator).toString())).toString());

                            if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                                }
                            }
                            if (!isNaN(Price)) {
                                /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa
                                Note: Case is viceversa only for fresh order
                                * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    if (ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag) //case for MarginPlus
                                    {
                                        if ((decChkTrgPrice < decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL70"));
                                    }
                                    else {
                                        if ((decChkTrgPrice > decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL71"));
                                    }
                                }
                                /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa
                                Note: Case is viceversa only for fresh order
                                For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                                else                //Sell side case
                                {
                                    if (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag)      //case for MarginPlus
                                    {
                                        if (decChkTrgPrice > decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL72"));
                                    }
                                    else {
                                        if (decChkTrgPrice < decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL73"));
                                    }
                                }
                            }
                        }
                    }
                }

                //Trigger Price Validations end

                // Stop loss validations ends here....

                if (Series.length > 0 && Series.toUpperCase() == "IS" && MarketSegmentId == clsConstants.C_V_OFS_IPO_BONDS) {
                    if (Price == 0) {
                        this.addError("Price", "Market order not allowed for this series");
                    }
                }
                //End

                //CR 3327
                if (clsGlobal.User.OdinCategory == 5 || clsGlobal.User.nseEqParticipantID.length > 0) {  // For Web Institutional clients RS series not allowed
                    if (Series.toUpperCase() == "RS") {
                        this.addError("Series", "RS series not allowed for this client");
                    }
                }

                var CapPriceInPaise = parseInt(Math.round(parseFloat((CapPrice * DecimalLocator).toString())).toString());
                var FloorPriceInPaise = parseInt(Math.round(parseFloat((FloorPrice * DecimalLocator).toString())).toString());

                if (IsCutOffAllowed == 1) {  //Cut Off is visible
                    if (!ChkCutOff && IsCutOffVisible) { //If cut off check box is unticked and it is visible on OE panel
                        if (Price == "" || Price == 0) {
                            this.addError("Price", "Kindly enter a valid Price or select cut Off option for Market/Cut-Off Order");
                        }
                    }
                }

                // Cut Off is unticked
                if (!ChkCutOff) {

                    if (parseInt(PriceinPaise.toString()) == 0) {
                        this.addError("Price", "Market orders allowed only for CutOff");
                    }
                    else {
                        // Price should be between floor and Cap price
                        if (parseInt(CapPriceInPaise.toString()) != 0 && parseInt(FloorPriceInPaise.toString()) != 0) {
                            if (parseInt(PriceinPaise.toString()) < parseInt(FloorPriceInPaise.toString()) || parseInt(PriceinPaise.toString()) > parseInt(CapPriceInPaise.toString())) {
                                this.addError("Price", "Kindly enter price between " + parseFloat(FloorPrice).toFixed(2) + " and " + parseFloat(CapPrice).toFixed(2));
                            }
                        }
                        // Price should not be below floor price
                        if (parseInt(CapPriceInPaise.toString()) == 0 && parseInt(FloorPriceInPaise.toString()) != 0) {
                            if (parseInt(PriceinPaise.toString()) < parseInt(FloorPriceInPaise.toString())) {
                                this.addError("Price", "Kindly enter price above " + parseFloat(FloorPrice).toFixed(2));
                            }
                        }
                        // Price should not be above cap price (Only cap price is provided, floor price is by default 5 paise)
                        if (parseInt(CapPriceInPaise.toString()) != 0 && parseInt(FloorPriceInPaise.toString()) == 0) {
                            if (parseInt(PriceinPaise.toString()) > parseInt(CapPriceInPaise.toString())) {
                                this.addError("Price", "Kindly enter price below " + parseFloat(CapPrice).toFixed(2));
                            }
                        }
                    }  //Else end

                }
                if (bAMO) {
                    if (this.getStatus(MarketSegmentId) != clsConstants.C_S_AMO_TEXT) {
                        this.addError("AMO", clsGlobal.dMsgMaster.getItem("OE201"));
                    }
                }
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateOrder', 'NSEOTS.js', '');

        }
        return this.arrError;
    }

    populateMarketStatus(sMktSegData, sMarketType, sStatusFlag, sAucSessionNo) {
        try {
            if (sMktSegData == "33") {
                if (sMarketType == "1")
                    this.sNSEOTSNormalMkt = sStatusFlag;
                else if (sMarketType == "7")
                    this.sNSEOTSAMOMkt = sStatusFlag;
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatus', 'NSEOTS.js', '');


        }
    }

    getStatus(sMktSegData) {
        try {
            var sMktStatus = '';

            if (sMktSegData == clsConstants.C_V_OFS_IPO_BONDS)
                sMktStatus = this.sNSEOTSStatus = clsGlobal.ExchManager.getMktStatusDesc(this.sNSEOTSNormalMkt, this.sNSEOTSAMOMkt, "", sMktSegData);

            return sMktStatus;
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetStatus', 'NSEOTS.js', '');


        }
    }

}
