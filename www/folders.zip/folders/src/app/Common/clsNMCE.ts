import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsTradingMethods } from './clsTradingMethods';
import { clsCommonMethods } from './clsCommonMethods';
import { IKeyedCollection, Dictionary } from './clsCustomClasses';

export class clsNMCE {

    arrInst = []; // Hash table for Holding Instruments for the selected / passed exchange (key would be ExchName and value would be list of instruments 
    arrOrderType = [];
    arrProductType = []; // 
    arrValidity = [];
    arrError = [];
    OrderType = ["RL", "SL"];
    hasSeries = false;

    dcMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();//Dictonary for Market Seg
    dcDecimalLoc: IKeyedCollection<number> = new Dictionary<number>();
    dcMapMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();
    dcEnableDisableFields: IKeyedCollection<boolean> = new Dictionary<boolean>();

    //Fields for Market Status
    sNMCEFUTNormalmkt: string = '-';
    sNMCEFUTAMOmkt: string = '-';
    sNMCEFUTStatus: string = '-';

    constructor(InstName) {
        this.arrInst = InstName.split('$');
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT, clsConstants.C_V_NMCE_DERIVATIVES);
        this.dcDecimalLoc.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), clsConstants.C_V_NORMAL_DECIMALLOCATOR);
        this.dcMapMarketSegementId.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), clsConstants.C_V_MAPPED_NMCE_DERIVATIVES);
        this.dcEnableDisableFields.Add("hasBuySell", true);
        this.dcEnableDisableFields.Add("hasExchange", true);
        this.dcEnableDisableFields.Add("hasInstrument", true);
        this.dcEnableDisableFields.Add("hasSymbol", true);
        this.dcEnableDisableFields.Add("hasOrderType", true);
        this.dcEnableDisableFields.Add("hasQty", true);
        this.dcEnableDisableFields.Add("hasPrice", true);
        this.dcEnableDisableFields.Add("hasDiscQty", true);
        this.dcEnableDisableFields.Add("hasTriggerPrice", true);
        this.dcEnableDisableFields.Add("hasProductType", true);
        this.dcEnableDisableFields.Add("hasValidity", true);
        this.dcEnableDisableFields.Add("hasDay", true);
        this.dcEnableDisableFields.Add("hasSeries", false);
        this.dcEnableDisableFields.Add("hasOptionType", false);
        this.dcEnableDisableFields.Add("hasExpire", false);
        this.dcEnableDisableFields.Add("hasProdPer", false);
        this.dcEnableDisableFields.Add("hasStrikePrice", false);
        this.dcEnableDisableFields.Add("hasCOL", false);
        this.dcEnableDisableFields.Add("hasCutOff", false);
    }

    enableDisable(InstName) {
        try {
            if (InstName == clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) {

                this.dcEnableDisableFields["hasSeries"] = false;
                this.dcEnableDisableFields["hasStrikePrice"] = false;
                this.dcEnableDisableFields["hasOptionType"] = false;
                this.dcEnableDisableFields["hasExpire"] = true;
                this.dcEnableDisableFields["hasProdPer"] = false;
                this.dcEnableDisableFields["hasDiscQty"] = false;
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'EnableDisable', 'NMCE.js', '');


        }
        return this.dcEnableDisableFields;
    }

    // Split the validity string and populate the array...
    populateValidity(Validity) {
        try {
            this.arrValidity = Validity.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateValidity', 'NMCE.js', '');


        }
    }

    // Split the Product Types string and populate teh array...
    populateProductTypes(ProductTypes) {
        try {
            this.arrProductType = ProductTypes.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateProductTypes', 'NMCE.js', '');


        }

    }

    // Split the Product Types string and populate teh array...
    populateOrderTypes(OrderTypes) {
        try {
            this.arrOrderType = OrderTypes.split('$');
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes', 'NMCE.js', '');


        }
    }

    // Get the Details for Order Type
    getDetailsForOrderType(OrderTypes) {
        try {
            if (OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
                this.dcEnableDisableFields["hasTriggerPrice"] = false;
                //   this.dcEnableDisableFields["hasDiscQty"] = true;
            }
            else if (OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                this.dcEnableDisableFields["hasTriggerPrice"] = true;
                //  this.dcEnableDisableFields["hasDiscQty"] = false;
            }
            else {
                this.dcEnableDisableFields["hasTriggerPrice"] = false;
                //  this.dcEnableDisableFields["hasDiscQty"] = true;
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForOrderType', 'NMCE.js', '');


        }
        return this.dcEnableDisableFields;
    }

    // Get the Details for Validity
    getDetailsForValidity(Validity) {
        try {
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                this.dcEnableDisableFields["hasDay"] = true;
            }
            else {
                this.dcEnableDisableFields["hasDay"] = false;
            }
            //                    if (Validity == clsConstants.C_S_VALUE_IOC) {
            //                        this.dcEnableDisableFields["hasDiscQty"] = false;
            //                    }
            //                    else {
            //                        this.dcEnableDisableFields["hasDiscQty"] = true;
            //                    }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity', 'NMCE.js', '');


        }
        return this.dcEnableDisableFields;
    }

    // Get the details of MktProtPerc, This Exchange doesn't support this functionality hence returning default values
    getDetailsForMktProtPerc(MapMarketSegmentId, Price, MarketSegmentId, MPPrice, ProdType) {
        var ProtPerc = '', ProtPercOrderPref = '';
        try {
            if ((ProdType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && MPPrice == 0)) {
                // if (clsGlobal.User.OrderPrefDic[MarketSegmentId].sPrefType == 'USER')
                //     ProtPercOrderPref = clsGlobal.User.OrderPrefDic[MarketSegmentId].nProtPerc;
                this.dcEnableDisableFields["hasProdPer"] = true;
            }
            else {
                this.dcEnableDisableFields["hasProdPer"] = false;
            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForMktProtPerc', 'NMCE.js', '');

        }
        return [this.dcEnableDisableFields, ProtPerc, ProtPercOrderPref];
    }


    // Function to Validate the scripdetails...
    validateScripDetails(dcLookupDetails) {
        this.arrError = [];
        try {
            //var clsGlobal.dMsgMaster = new fn_HashTable();
            //var Exchange = dcLookupDetails["SelExchange"] == undefined ? '' : dcLookupDetails["SelExchange"];
            var Instrument = dcLookupDetails["SelInstrument"] == undefined ? '' : dcLookupDetails["SelInstrument"];
            //var MarketSegmentId = dcLookupDetails["MarketSegmentId"] == undefined ? '' : dcLookupDetails["MarketSegmentId"];

            var Symbol = dcLookupDetails["SelSymbol"] == undefined ? '' : dcLookupDetails["SelSymbol"];
            var Series = dcLookupDetails["SelSeries"] == undefined ? '' : dcLookupDetails["SelSeries"];
            var StrikePrice = dcLookupDetails["SelStrikePrice"] == undefined ? '' : dcLookupDetails["SelStrikePrice"];
            var OptionType = dcLookupDetails["SelOptionType"] == undefined ? '' : dcLookupDetails["SelOptionType"];
            var ExpiryDate = dcLookupDetails["SelExpDate"] == undefined ? '' : dcLookupDetails["SelExpDate"];

            //var MarketLot = dcLookupDetails["SelScripMarketLot"] == undefined ? '' : dcLookupDetails["SelScripMarketLot"];
            //var DecimalLocator = dcLookupDetails["SelScripDecimalloc"] == undefined ? '' : dcLookupDetails["SelScripDecimalloc"];

            //var PriceTick = dcLookupDetails["SelScripPriceTick"] == undefined ? '' : dcLookupDetails["SelScripPriceTick"];
            //var TokenNo = dcLookupDetails["SelScripToken"] == undefined ? '' : dcLookupDetails["SelScripToken"];

            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster["NNSL26"]);
            }

            // Validation for Cash Market...
            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                if (Series.toString().length == 0)
                    this.addError("Series", clsGlobal.dMsgMaster["NNSL27"]);
                if (ExpiryDate.toString().length != 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster["NNSL28"]);
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster["NNSL29"]);
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster["NNSL30"]);
            }

            //Case for NSE FUTIDX /  NSE FUTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) {
                if (Series.toString().length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster["NNSL32"]);
                if (ExpiryDate.toString().length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster["NNSL33"]);
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster["NNSL34"]);
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster["NNSL35"]);
            }

            //Case for NSE OPTIDX / NSE OPTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT) {
                if (Series.toString().length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster["NNSL32"]);
                if (ExpiryDate.toString().length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster["NNSL33"]);
                if (StrikePrice.toString().length == 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster["NNSL34"]);
                if (OptionType.toString().length == 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster["NNSL35"]);
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster["NNSL39"]);
            }

        } catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateScripDetails', 'NMCE.js', '');


        }
        return this.arrError;
    }

    addError(sErrElement, sErrMsg) {
        this.arrError.push(sErrMsg);
    }


    // Function to Validate the orders...
    validateOrder(dcOrderDetails) {
        this.arrError = [];
        try {
            //var clsGlobal.dMsgMaster = new fn_HashTable();

            //var Exchange = dcOrderDetails["SelExchange"] == undefined ? '' : dcOrderDetails["SelExchange"];
            var Instrument = dcOrderDetails["SelInstrument"] == undefined ? '' : dcOrderDetails["SelInstrument"];
            var MarketSegmentId = dcOrderDetails["MarketSegmentId"] == undefined ? '' : dcOrderDetails["MarketSegmentId"];
            var Validity = dcOrderDetails["SelValidity"] == undefined ? '' : dcOrderDetails["SelValidity"];
            var ProductType = dcOrderDetails["SelProduct"] == undefined ? '' : dcOrderDetails["SelProduct"];

            var OrderType = dcOrderDetails["SelOrderTypes"] == undefined ? '' : dcOrderDetails["SelOrderTypes"];
            var OrderSide = dcOrderDetails["SelOperation"] == undefined ? '' : dcOrderDetails["SelOperation"];
            var Symbol = dcOrderDetails["SelSymbol"] == undefined ? '' : dcOrderDetails["SelSymbol"];
            var Series = dcOrderDetails["SelSeries"] == undefined ? '' : dcOrderDetails["SelSeries"];
            var StrikePrice = dcOrderDetails["SelStrikePrice"] == undefined ? '' : dcOrderDetails["SelStrikePrice"];

            var OptionType = dcOrderDetails["SelOptionType"] == undefined ? '' : dcOrderDetails["SelOptionType"];
            var ExpiryDate = dcOrderDetails["SelExpire"] == undefined ? '' : dcOrderDetails["SelExpire"];
            var ProtPerc = dcOrderDetails["SelProdPer"] == undefined ? '' : dcOrderDetails["SelProdPer"];
            var Quantity = dcOrderDetails["SelQty"] == undefined ? 0 : dcOrderDetails["SelQty"];
            var Price = dcOrderDetails["SelPrice"] == undefined ? '' : dcOrderDetails["SelPrice"];

            var DiscQty = dcOrderDetails["SelDiscQty"] == undefined ? '' : dcOrderDetails["SelDiscQty"];
            var TriggerPrice = dcOrderDetails["SelTriggerPrice"] == undefined ? '' : dcOrderDetails["SelTriggerPrice"];
            var Days = dcOrderDetails["SelDay"] == undefined ? '' : dcOrderDetails["SelDay"];
            //var MarketLot = dcOrderDetails["SelMarketLot"] == undefined ? '' : dcOrderDetails["SelMarketLot"];
            var DecimalLocator = dcOrderDetails["SelDecimalloc"] == undefined ? '' : dcOrderDetails["SelDecimalloc"];

            var PriceTick = dcOrderDetails["SelPriceTick"] == undefined ? '' : dcOrderDetails["SelPriceTick"];
            var TokenNo = dcOrderDetails["SelToken"] == undefined ? '' : dcOrderDetails["SelToken"];

            //var MarketStatus = dcOrderDetails["MarketStatus"] == undefined ? '' : dcOrderDetails["MarketStatus"];
            var ModifyFlag = dcOrderDetails["ModifyFlag"] == undefined ? false : dcOrderDetails["ModifyFlag"];

            var MPSuccessFailure = dcOrderDetails["MPSuccessFailure"] == undefined ? false : dcOrderDetails["MPSuccessFailure"];
            var MPLimitPriceLowRange = dcOrderDetails["MPLimitPriceLowRange"] == undefined ? '' : dcOrderDetails["MPLimitPriceLowRange"];
            var MPLimitPriceHighRange = dcOrderDetails["MPLimitPriceHighRange"] == undefined ? '' : dcOrderDetails["MPLimitPriceHighRange"];
            var MPTriggerPriceLowRange = dcOrderDetails["MPTriggerPriceLowRange"] == undefined ? '' : dcOrderDetails["MPTriggerPriceLowRange"];
            var MPTriggerPriceHighRange = dcOrderDetails["MPTriggerPriceHighRange"] == undefined ? '' : dcOrderDetails["MPTriggerPriceHighRange"];

            var MPTradingAllowed = dcOrderDetails["MPTradingAllowed"] == undefined ? '' : dcOrderDetails["MPTradingAllowed"];
            var MPOrderType = dcOrderDetails["MPOrderType"] == undefined ? '' : dcOrderDetails["MPOrderType"];
            var MPPrice = dcOrderDetails["MPPrice"] == undefined ? '' : dcOrderDetails["MPPrice"];
            var MPTriggerPrice = dcOrderDetails["MPTriggerPrice"] == undefined ? '' : dcOrderDetails["MPTriggerPrice"];

            var ProfitOrderPrice = dcOrderDetails.items["ProfitOrderPrice"] == undefined ? '' : dcOrderDetails.items["ProfitOrderPrice"];
            var TrailingSL = dcOrderDetails.items["TrailingSL"] == undefined ? '' : dcOrderDetails.items["TrailingSL"];
            var SLJumpPrice = dcOrderDetails.items["SLJumpPrice"] == undefined ? '' : dcOrderDetails.items["SLJumpPrice"];
            var LTPJumpPrice = dcOrderDetails.items["LTPJumpPrice"] == undefined ? '' : dcOrderDetails.items["LTPJumpPrice"];
            var ProfitPriceLowRange = dcOrderDetails.items["ProfitPriceLowRange"] == undefined ? '' : dcOrderDetails.items["ProfitPriceLowRange"];
            var ProfitPriceHighRange = dcOrderDetails.items["ProfitPriceHighRange"] == undefined ? '' : dcOrderDetails.items["ProfitPriceHighRange"];
            var MPLTP = dcOrderDetails.items["MPLTP"] == undefined ? '' : dcOrderDetails.items["MPLTP"];
            //var BOModifyTerms = dcOrderDetails.items["BOModifyTerms"] == undefined ? '' : dcOrderDetails.items["BOModifyTerms"];
            //var UnderlyingLTP = dcOrderDetails.items["UnderlyingLTP"] == undefined ? '' : dcOrderDetails.items["UnderlyingLTP"];
            var bAMO = dcOrderDetails["AMO"] == undefined ? false : dcOrderDetails["AMO"];
            //var OriginalOrdType = dcOrderDetails["OriginalOrderType"] == undefined ? '' : dcOrderDetails["OriginalOrderType"];
            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster["NNSL26"]);
            }

            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster["OE60"]);
                if (ExpiryDate.length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster["OE61"]);
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster["OE57"]);
                if (OptionType.length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster["OE58"]);
                if (isNaN(ProtPerc))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster["NNSL31"]);
            }

            /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Protection Percent validation for bracket order entry> **/
            if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                if ((MPPrice == 0 || MPPrice == undefined || MPPrice == '') &&
                    (ProtPerc == 0 || ProtPerc == undefined || ProtPerc == '')) {
                    this.addError("ProtPerc", 'Please Enter Protection Percent');
                }
            }


            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster["NNSL39"]);
            }
            //Series
            if (Series.length > 0) {
                var regSeries = new RegExp("([A-Za-z0-9]$)");
                if (!regSeries.test(Series))
                    this.addError("Series1", clsGlobal.dMsgMaster["NNSL40"]);
            }
            //                //ExpiryDate
            //                if (ExpiryDate.length > 0) {
            //                    var regExpDt = new RegExp("^(([1-9])|([0][1-9])|([1-2][0-9])|(30)|(31))([Jj][Aa][Nn]|[Ff][Ee][bB]|[Mm][Aa][Rr]|[Aa][Pp][Rr]|[Mm][Aa][Yy]|[Jj][Uu][Nn]|[Jj][Uu][Ll]|[aA][Uu][gG]|[Ss][eE][pP]|[oO][Cc][Tt]|[Nn][oO][Vv]|[Dd][Ee][Cc])(19|20)\d\d$");
            //                    if (!regExpDt.test(ExpiryDate))
            //                        this.addError("ExpiryDate1", clsGlobal.dMsgMaster["NNSL41"]);
            //                }
            //Option Type
            if (OptionType.length > 0) {
                var regOptType = new RegExp("([A-Za-z]$)");
                if (!regOptType.test(OptionType))
                    this.addError("OptionType1", clsGlobal.dMsgMaster["NNSL42"]);
            }
            //Days
            if (Days.length > 0) {
                //var regDays = new RegExp("([1-7]$)");
                //if (!regDays.test(Days)) commented 001-00-506746
                //    this.addError("Days1", clsGlobal.dMsgMaster["NNSL43"]); commented 001-00-506746
            }
            // Product Type
            if (ProductType.length == 0) {
                this.addError("ProductType1", "Product Type cannot be blank");
            }

            //////////////////////// Secondary Validations ///////////////////////////
            // if (!HasErrors)
            {
                //var DecLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
                var PriceinPaise = 0;
                var TrigPriceinPaise = 0;

                var decChkTrgPrice = 0;
                var decChkPrice = 0;

                DiscQty = dcOrderDetails["SelDiscQty"] == undefined ? '' : dcOrderDetails["SelDiscQty"];
                Quantity = dcOrderDetails["SelQty"] == undefined ? '' : dcOrderDetails["SelQty"];
                var DiscQtyCaption = "Disc" + clsConstants.CONST_LOT_CAPTION;
                var QtyCaption = clsConstants.CONST_LOT_CAPTION;

                if (DecimalLocator == '' || DecimalLocator == 0)
                    DecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
                var _AllowedDecimal = DecimalLocator.length - 1;


                var secondLegPriceCaption = 'Price';
                secondLegPriceCaption = ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT ? "SL Price" : secondLegPriceCaption;
                var decChkMPPrice = 0;

                //Quantity related Validations
                if (isNaN(Quantity)) {
                    this.addError("Quantity", clsGlobal.dMsgMaster["NNSL44"] + QtyCaption);
                }

                else if (!isNaN(Quantity)) {
                    if (Quantity <= 0 && (!(ModifyFlag && ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT))) {
                        this.addError("Quantity", clsGlobal.dMsgMaster["NNSL44"] + QtyCaption + clsGlobal.dMsgMaster["NNSL45"]);
                    }

                    // Case to check Quantity should not have decimal character
                    if (Quantity.toString().indexOf('.') != -1)
                        this.addError("Quantity2", QtyCaption + clsGlobal.dMsgMaster["NNSL47"]);
                }
                // Quantity validations end

                //Disclosed Quantity related Validations
                //  Case to validate Disc Qty Entered. Here case has been checked for Disc LOT as well as Disc Qty.

                if (!isNaN(DiscQty))      //If Disc Qty has some value
                {
                    if (DiscQty != 0 && DiscQty != "") {
                        if (!isNaN(Quantity))            //If Qty has some value
                        {
                            if (parseInt(DiscQty) > parseInt(Quantity))
                                this.addError("DiscQty", clsGlobal.dMsgMaster["NNSL44"] + DiscQtyCaption + clsGlobal.dMsgMaster["NNSL48"] + QtyCaption);

                            //For MCX Disc LOT cannot be less than 25% of Original LOT entered         
                            if (DiscQty != 0) {
                                if ((Quantity != DiscQty) && (DiscQty != 0))
                                    this.addError("DiscQty", clsGlobal.dMsgMaster["NNSL51"] + DiscQtyCaption + "The " + DiscQtyCaption + clsGlobal.dMsgMaster["NNSL54"] + QtyCaption);

                            }
                        }

                        //Disc Qty / Lot not allowed for IOC order
                        if (Validity == clsConstants.C_S_VALUE_IOC && (!isNaN(DiscQty)))
                            this.addError("DiscQty2", DiscQtyCaption + clsGlobal.dMsgMaster["NNSL55"]);

                        // Case to check Quantity should not have decimal character
                        if (DiscQty.toString().indexOf('.') != -1)
                            this.addError("DiscQty3", DiscQtyCaption + clsGlobal.dMsgMaster["NNSL47"]);
                    }

                }

                //////////////////////// disclosed qty validation ends here.....//////////////////////////////

                // Validations related to Price
                if (!isNaN(Price)) {
                    if (Price < 0) {
                        this.addError("Price", clsGlobal.dMsgMaster["NNSL59"]);
                    }
                    if (Price != 0) {

                        decChkPrice = parseFloat(Price);

                        if (!(clsCommonMethods.DecDigits(decChkPrice.toString(), _AllowedDecimal)))
                            this.addError("Price", clsGlobal.dMsgMaster["NNSL61"]);

                        PriceinPaise = parseInt(Math.round(parseFloat((Price * DecimalLocator).toString())).toString());

                        if (PriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("Price", clsGlobal.dMsgMaster["NNSL62"] + PriceTick + clsGlobal.dMsgMaster["NNSL63"]);
                            }
                        }
                    }
                    // else {
                    //     //If price is 0 and order type selected are RL/SL --> Show error message
                    //     if (ProductType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                    //         if (OrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)
                    //             this.addError("Price", "Price cannot be zero for Limit order");
                    //     }
                    // }
                }

                //Additional validation for margin plus as the price field for MP is different
                if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && !isNaN(MPPrice)) {
                    if (MPPrice < 0) {
                        this.addError("Price", clsTradingMethods.priceCanNotBeNegativeMsg(secondLegPriceCaption));
                    }
                    if (MPPrice != 0) {

                        decChkMPPrice = parseFloat(MPPrice);

                        if (!(clsCommonMethods.DecDigits(decChkMPPrice.toString(), _AllowedDecimal)))
                            this.addError("Price", clsTradingMethods.priceNotInDecDigitsMsg(secondLegPriceCaption, _AllowedDecimal));

                        PriceinPaise = parseInt(Math.round(parseFloat((MPPrice * DecimalLocator).toString())).toString());

                        if (PriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("Price", clsTradingMethods.priceNotInPriceTickMsg(secondLegPriceCaption, PriceTick, true));
                            }
                        }
                    }
                    if (MPTradingAllowed === 1 && MPPrice == 0) {//In case the Margin Plus Trading Allowed is 1 then Limit order is mandatory
                        this.addError("Price", clsGlobal.dMsgMaster["NNSL347"]);
                    }
                    else if (MPTradingAllowed === 3 && MPPrice != 0) {//In case the Margin Plus Trading Allowed is 3 then Market order is mandatory
                        this.addError("Price", clsGlobal.dMsgMaster["NNSL348"]);
                    }

                    if ((parseFloat(MPPrice) < parseFloat(MPLimitPriceLowRange) || parseFloat(MPPrice) > parseFloat(MPLimitPriceHighRange)) && parseFloat(MPPrice) != 0)
                        this.addError("Price", clsTradingMethods.priceOutOfRangeMsg(secondLegPriceCaption));
                }
                // Validations of Price ends

                /* Validations to check TriggerPrice */
                //First validation of trigger price for margin plus as it has separate order type else for normal order
                if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && MPOrderType === clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                    if (isNaN(MPTriggerPrice))
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL65"]);

                    if (!isNaN(MPTriggerPrice)) {
                        if (MPTriggerPrice == 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL66"]);
                        else {
                            decChkTrgPrice = parseFloat(MPTriggerPrice);

                            if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL68"]);

                            TrigPriceinPaise = parseInt(Math.round(parseFloat((MPTriggerPrice * DecimalLocator).toString())).toString());

                            if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL69"] + PriceTick + clsGlobal.dMsgMaster["NNSL63"]);
                                }
                            }

                            if (MPOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT && (parseFloat(MPTriggerPrice) < parseFloat(MPTriggerPriceLowRange) || parseFloat(MPTriggerPrice) > parseFloat(MPTriggerPriceHighRange)) && parseFloat(MPTriggerPrice) != 0)
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL217"]);

                            if (!isNaN(MPPrice)) {
                                /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    //if (!ModifyFlag) //case for MarginPlus - Fresh Order//Commented as the side flips
                                    //{
                                    if ((decChkTrgPrice < decChkMPPrice) && decChkMPPrice != 0)
                                        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL70"]);
                                    //}
                                    //else {//case for MarginPlus - Modify Order
                                    //    if ((decChkTrgPrice > decChkMPPrice) && decChkMPPrice != 0)
                                    //        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL71"]);
                                    //}
                                }
                                /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                                else//Sell side case
                                {
                                    //if (!ModifyFlag)//case for MarginPlus - Fresh Order
                                    //{
                                    if (decChkTrgPrice > decChkMPPrice && decChkMPPrice != 0)
                                        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL72"]);
                                    //}
                                    //else {//case for MarginPlus - Modify Order
                                    //    if (decChkTrgPrice < decChkMPPrice)
                                    //        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL73"]);
                                    //}
                                }

                                //For Buy Bracket Order with First Leg Limit Price,SL trigger Price sohuld be less than Limit Price
                                //For Buy Bracket Order with First Leg market Price,SL trigger Price sohuld be less than LTP
                                //For Sell Bracket Order with First Leg Limit Price,SL trigger Price sohuld be greater than Limit Price
                                //For Sell Bracket Order with First Leg market Price,SL trigger Price sohuld be greater than LTP
                                if (ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                                    if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                        if (decChkPrice != 0) {
                                            if (decChkTrgPrice > decChkPrice)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL363"].replace('{0}', 'Trigger Price'));
                                        }
                                        else {
                                            if (decChkTrgPrice > MPLTP)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL364"].replace('{0}', 'Trigger Price'));
                                        }
                                    }
                                    else {
                                        if (decChkPrice != 0) {
                                            if (decChkTrgPrice < decChkPrice)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL365"].replace('{0}', 'Trigger Price'));
                                        }
                                        else {
                                            if (decChkTrgPrice < MPLTP)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL366"].replace('{0}', 'Trigger Price'));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else {//In case of normal product type other than margin plus
                    if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                        OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {

                        if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                            if (Price == 0) {
                                this.addError("Price", "Price cannot be zero for Limit order");
                            }
                        }

                        if (isNaN(TriggerPrice))
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL65"]);

                        if (TriggerPrice < 0) {
                            this.addError("TriggerPrice", 'Please enter valid Trigger Price. Trigger Price cannot be negative.');
                        }

                        if (!isNaN(TriggerPrice)) {
                            if (TriggerPrice == 0)
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL66"]);
                            else {
                                decChkTrgPrice = parseFloat(TriggerPrice);

                                if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL68"]);

                                TrigPriceinPaise = parseInt(Math.round(parseFloat((TriggerPrice * DecimalLocator).toString())).toString());

                                if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                                    if (TokenNo != "") {
                                        this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL69"] + PriceTick + clsGlobal.dMsgMaster["NNSL63"]);
                                    }
                                }

                                if (!isNaN(Price)) {
                                    /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                                    other than Margin Plus. For Margin Plus case is vice versa  
                                    Note: Case is viceversa only for fresh order
                                    * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                                    if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                        if (ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag) //case for MarginPlus
                                        {
                                            if ((decChkTrgPrice < decChkPrice) && decChkPrice != 0)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL70"]);
                                        }
                                        else {
                                            if ((decChkTrgPrice > decChkPrice) && decChkPrice != 0)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL71"]);
                                        }
                                    }
                                    /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                                    other than Margin Plus. For Margin Plus case is vice versa  
                                    Note: Case is viceversa only for fresh order
                                    For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                                    else                //Sell side case
                                    {
                                        if (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag)      //case for MarginPlus
                                        {
                                            if (decChkTrgPrice > decChkPrice)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL72"]);
                                        }
                                        else {
                                            if (decChkTrgPrice < decChkPrice)
                                                this.addError("TriggerPrice", clsGlobal.dMsgMaster["NNSL73"]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //Trigger Price Validations end

                //Case --> Only DAY validity allowed for MarginPlus order
                if (MPOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT && (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && Validity != clsConstants.C_S_VALUE_DAY) {
                    this.addError("Validity2", clsGlobal.dMsgMaster["NNSL76"].replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT));
                }

                //Case to check Days field when Validity selected is GTD
                if (Validity == clsConstants.C_S_VALUE_GTD) {
                    if (Days.length == 0)
                        this.addError("Days", clsGlobal.dMsgMaster["NNSL77"]);
                    //if (Days.length > 0) { commented 001-00-506746
                    else {
                        var ValidExpireDays = clsCommonMethods.CalculateDays(new Date(), new Date(ExpiryDate));
                        //if (Days > ValidExpireDays || Days <= 0)
                        //if (Days > ValidExpireDays || Days < 0) //001-00-506746
                        //    this.addError("Days", clsGlobal.dMsgMaster["NNSL43"].replace('7', ValidExpireDays));
                        //if (parseInt(Days) < 1 || parseInt(Days) > 7)
                        //    this.addError("Days", clsGlobal.dMsgMaster["NNSL78"]);

                        /////////// 001-00-506746 /////////////
                        if (ValidExpireDays == 0 && Days > 0) {
                            //alert("Value of Days should be 0");
                            //return;
                            this.addError("Days", "Value of Days should be 0");
                        }
                        else if (ValidExpireDays != 0 && Days == 0) {
                            this.addError("Days", clsGlobal.dMsgMaster["NNSL43"].replace('7', ValidExpireDays));
                        }
                        else {
                            if (Days > ValidExpireDays || Days < 0) //001-00-506746
                                this.addError("Days", clsGlobal.dMsgMaster["NNSL43"].replace('7', ValidExpireDays));
                        }
                        //////////// 001-00-506746 /////////////
                    }
                }

                // Stop loss validations....
                if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_VALUE_IOC) {
                    this.addError("Validity", clsGlobal.dMsgMaster["NNSL80"]);
                }

                if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_ORDER_FOK)
                    this.addError("Validity", clsGlobal.dMsgMaster["NNSL81"]);

                ///Validations for Margin Plus
                if ((ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)) {
                    if (!MPSuccessFailure)
                        this.addError("OrderEntry", clsTradingMethods.MPNotAllowedForLTPMsg(ProductType, decChkPrice));

                    if (Validity != clsConstants.C_S_VALUE_DAY && Validity != clsConstants.C_S_VALUE_EOSESS)
                        this.addError("Validity", clsTradingMethods.MPNotAllowedForValidityMsg(ProductType));

                    if (MPOrderType === clsConstants.C_S_ORDER_REGULARLOT_TEXT && MPPrice != 0)
                        this.addError("Price", "RL Limit order not allowed for Margin Plus");
                }

                if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                    var decChkProfitOrderPrice = 0;
                    var decChkSLJumpPrice = 0;
                    var decChkLTPJumpPrice = 0;

                    if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || OrderType == clsConstants.C_S_ORDER_CALLAUCTION_TEXT)
                        this.addError("OrderType", "Bracket order not allowed for stop loss order type");

                    //if (ProtPerc == 0) {
                    //    if (decChkPrice == 0)
                    //        this.addError("Price", clsGlobal.dMsgMaster["NNSL376"]);
                    //    //else if (decChkMPPrice == 0)
                    //    //    this.addError("MPPrice", clsGlobal.dMsgMaster["NNSL377"]);
                    //}

                    if (TrailingSL) {
                        if (!isNaN(SLJumpPrice)) {
                            if (SLJumpPrice == 0) {
                                this.addError("SLJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('SL Jump Price'));
                            }
                            if (SLJumpPrice != 0) {

                                decChkSLJumpPrice = parseFloat(SLJumpPrice);

                                if (!(clsCommonMethods.DecDigits(decChkSLJumpPrice.toString(), _AllowedDecimal)))
                                    this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('SL Jump Price', _AllowedDecimal));

                                PriceinPaise = parseInt(Math.round(parseFloat((SLJumpPrice * DecimalLocator).toString())).toString());

                                if (PriceinPaise % parseInt(PriceTick) != 0) {
                                    if (TokenNo != "") {
                                        this.addError("SLJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('SL Jump Price', PriceTick, true));
                                    }
                                }
                            }
                        }

                        if (clsGlobal.isJumpBothLtpAndTrigPrice) {
                            if (!isNaN(LTPJumpPrice)) {
                                if (LTPJumpPrice == 0) {
                                    this.addError("LTPJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('LTP Jump Price'));
                                }
                                if (LTPJumpPrice != 0) {

                                    decChkLTPJumpPrice = parseFloat(LTPJumpPrice);

                                    if (!(clsCommonMethods.DecDigits(decChkLTPJumpPrice.toString(), _AllowedDecimal)))
                                        this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('LTP Jump Price', _AllowedDecimal));

                                    PriceinPaise = parseInt(Math.round(parseFloat((LTPJumpPrice * DecimalLocator).toString())).toString());

                                    if (PriceinPaise % parseInt(PriceTick) != 0) {
                                        if (TokenNo != "") {
                                            this.addError("LTPJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('LTP Jump Price', PriceTick, true));
                                        }
                                    }

                                    if (decChkSLJumpPrice > decChkLTPJumpPrice)
                                        this.addError("SLJumpPrice", clsGlobal.dMsgMaster["NNSL361"]);
                                }
                            }
                        }
                    }

                    // Validations related to ProfitOrderPrice
                    if (!isNaN(ProfitOrderPrice)) {
                        if (ProfitOrderPrice == 0) {
                            this.addError("ProfitOrderPrice", clsTradingMethods.PriceCanNotBeZeroMsg('Profit Order Price'));
                        }
                        if (ProfitOrderPrice != 0) {

                            decChkProfitOrderPrice = parseFloat(ProfitOrderPrice);

                            if (!(clsCommonMethods.DecDigits(decChkProfitOrderPrice.toString(), _AllowedDecimal)))
                                this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInDecDigitsMsg('Profit Order Price', _AllowedDecimal));

                            PriceinPaise = parseInt(Math.round(parseFloat((ProfitOrderPrice * DecimalLocator).toString())).toString());

                            if (PriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInPriceTickMsg('Profit Order Price', PriceTick, true));
                                }
                            }

                            //profit order price validation with PPR
                            if ((decChkProfitOrderPrice < ProfitPriceLowRange || decChkProfitOrderPrice > ProfitPriceHighRange))
                                this.addError("ProfitOrderPrice", clsTradingMethods.priceOutOfRangeMsg('Profit Order Price'));

                            //For Buy Bracket Order with First Leg Limit Price,Profit Order Price sohuld be greater than Limit Price
                            //For Buy Bracket Order with First Leg market Price,Profit Order Price sohuld be greater than LTP
                            //For Sell Bracket Order with First Leg Limit Price,Profit Order Price sohuld be less than Limit Price
                            //For Sell Bracket Order with First Leg market Price,Profit Order Price sohuld be less than LTP
                            if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                if (decChkPrice != 0) {
                                    if (decChkProfitOrderPrice <= decChkPrice)
                                        this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster["NNSL365"].replace('{0}', 'Profit Order Price'));
                                }
                                else {
                                    if (decChkProfitOrderPrice <= MPLTP)
                                        this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster["NNSL366"].replace('{0}', 'Profit Order Price'));
                                }
                            }
                            else {
                                if (decChkPrice != 0) {
                                    if (decChkProfitOrderPrice >= decChkPrice)
                                        this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster["NNSL363"].replace('{0}', 'Profit Order Price'));
                                }
                                else {
                                    if (decChkProfitOrderPrice >= MPLTP)
                                        this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster["NNSL364"].replace('{0}', 'Profit Order Price'));
                                }
                            }
                        }
                    }
                }
                if (bAMO) {
                    if (this.getStatus(MarketSegmentId) != clsConstants.C_S_AMO_TEXT) {
                        this.addError("AMO", clsGlobal.dMsgMaster["OE201"]);
                    }
                }

            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'ValidateOrder', 'NMCE.js', '');


        }
        return this.arrError;
    }

    populateMarketStatus(sMktSegData, sMarketType, sStatusFlag, sAucSessionNo) {
        try {
            if (sMktSegData == "18") {
                if (sMarketType == "1")
                    this.sNMCEFUTNormalmkt = sStatusFlag;
                else if (sMarketType == "7")
                    this.sNMCEFUTAMOmkt = sStatusFlag;


            }
        }
        catch (e) {

            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatus', 'NMCE.js', '');


        }
    }

    getStatus(sMktSegData) {
        try {
            var sMktStatus = '';

            if (sMktSegData == clsConstants.C_V_NMCE_DERIVATIVES)
                sMktStatus = this.sNMCEFUTStatus = clsGlobal.ExchManager.getMktStatusDesc(this.sNMCEFUTNormalmkt, this.sNMCEFUTAMOmkt, "", sMktSegData);

            return sMktStatus;
        }
        catch (e) {
            //clsGlobal.LogManager.WriteLog('Exception: ' + e.message, 'getStatus', 'DSE.js', '');
        }
    }
}