﻿import { AlertServicesProvider } from './../providers/alert-services/alert-services';
import { Dictionary } from './clsCustomClasses';
import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';


export class clsUser {

    MarketWatchPerfDetails = [];
    userId: string = '';
    password: string = '';
    userName: string = '';
    groupId: string = '';
    host: string = '';
    userCode: string = '';
    OCToken: string = '';
    sessionId: string = '';
    groupCode: string = '';
    userProduct: string = '';
    viewAllowed: any = '';
    loginAllowed: any = '';
    marginPlusAllowedVal: any = '';
    accessToken: any = '';
    //OC_BROADCAST_IP_ADDRESS: string = ''
    //OC_BROADCAST_PORT = 0;
    brodcastSocketUrl: string = '';
    pwdExpiryDays: any = 0;
    logonSuccessFlag = false;
    LoginMode: number = 0;
    SITemplateId = 'DIET';//'WAVE';
    guestTemplateId = "GUEST";
    nseEqParticipantID: string = '';
    nseDervParticipantID: string = '';
    bsePartType: string = '';
    nsxParticipantID: string = '';
    clientOrderNumber = 0;
    IsBroadcastConnected = false;
    MCXSXEQDQPerc = 0;
    MCXSXFAODQPerc = 0;
    OEProductString: any = '';
    profileList = [];
    NewsVendorId: string = '';
    NewsCategories: string = '';
    ClientFacilityTemplate: Dictionary<string> = null;
    marketProtPercList: Dictionary<string> = new Dictionary<string>();
    //isNSEFAOCOLAllowed: boolean = false;
    //isJumpBothLtpAndTrigPrice: boolean = false;
    PTNType: string = '';
    vendorId: string = '';
    SSOEnabled = false;
    OdinCategory = -1;
    ClientfacilityDic: any;
    TSLAllowed: any; //CR 4978
    AddendumData: any = [];
    bannedScriptStatus: boolean = false;
    mobile: string = '';
    address: string = '';
    bankdetails: any = [];
    email: string = '';
    PAN: string = '';
    BracketOrderAllowed: any;
    chatHistoryList: any = [];

    userIdHexaValue: string;//added by omprakash on 3 mar , to use this in One Place API calls.
    xmppConnectionObj: any;//added by vivian fernandes to store xmpp chat connection object.
    xmppConnectionSocketUrl: any;
    isxmppConnectionOn: boolean = false;
    managerVersion: string = clsConstants.C_S_MANAGER_VER_10005;
    //isChangePassword:any;
    cftAllowed: any;

    //BT-20365 : BT-20478: YOGESH KADAM :16-06-2020: NSDL & CDSL e-dis Implement in Beyond 2.0 <Start>
    POAStatus: any = true;
    managerIP: any='';
    //BT-20365 : BT-20478: YOGESH KADAM :16-06-2020: NSDL & CDSL e-dis Implement in Beyond 2.0 <End>

    GTDDays:number=0;
    DefaultGTDDays:number=0;

    lastLoginTime: string;//added by Nikhil G To display Last login time.
    watchlistFilter: any;
    isGuestUser: boolean = false;
    Holding = [];
    totalBuyingPower: any;
    HoldingScrips = [];
    userPreference:any;
    DPDetails = [];
    interopSettingDetails :any ;
    spreadScrips : any = [];
    /**
     * changes :changed method as passing loginObject //same method is used in case of change password
     * changes by : CHETAN A
     * Date : 29 MAY 2019
     * */
    managerlogin(reqObj, httpService, toastProvider, alerProvider?: AlertServicesProvider) {

        let reqLogin = {
            messageCode: reqObj.msgCode,
            userId: this.userId,
            password: reqObj.password,
            newPassword: reqObj.newPassword,
            groupId: this.groupId,
            userCode: this.userCode,
            productMode: clsConstants.C_V_PHOENIX_MOBILE,
            loginType: reqObj.loginType,
            deviceType: clsGlobal.DeviceType,
            ocToken: clsGlobal.User.OCToken
        };

        //clsGlobal.VirtualDirectory
        httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + 'v1/managerlogin', reqLogin).subscribe(resLogin => {

            if (resLogin.status == true) {
                if (resLogin.result.logonStatusCode == 10007) { // password expire
                    //alerProvider.showAlertCallbackWithSingleButton(resLogin.result.logonMessage).then((success) => {
                    alerProvider.showAlertCallbackWithSingleButton(resLogin.result.logonMessage).then((success) => {
                        if (success == true) {
                            clsGlobal.pubsub.publish('User:PwdExpired', reqLogin);
                        }
                    });
                }
                else {
                    this.processLoginResponse(resLogin);
                    toastProvider.showAtBottom(resLogin.result.logonMessage);
                }
            }
            else { // response = false
                toastProvider.showAtBottom(resLogin.errorString);
            }
        }, error => {
            toastProvider.showAtBottom(error);
        });
    }

    /**
     * changes : method for process login response
     * changes by : CHETAN A
     * Date : 27 JUN 2019
     * */
    processLoginResponse(resLogin) {
        this.pwdExpiryDays = resLogin.result.expiryDays;
        this.clientOrderNumber = parseInt(resLogin.result.maxClientOrderNo);
        this.OCToken = resLogin.result.ocToken;
        clsGlobal.User.OCToken = resLogin.result.ocToken;

        if (clsGlobal.DQPercentageList != undefined && clsGlobal.DQPercentageList != null) {
            let result = clsGlobal.DQPercentageList.filter((item) => { item.seg == clsConstants.C_V_MSX_CASH });
            this.MCXSXEQDQPerc = parseFloat(result.value);
            result = clsGlobal.DQPercentageList.filter((item) => { item.seg == clsConstants.C_V_MSX_FAO });
            this.MCXSXFAODQPerc = parseFloat(result.value);
        }

        this.marketProtPercList.Clear();
        if (clsGlobal.MktProtPerList != undefined && clsGlobal.MktProtPerList != null) {
            for (let index = 0; index < clsGlobal.MktProtPerList.length; index++) {
                const element = clsGlobal.MktProtPerList[index];
                let mapMktSegId = element.seg;//clsTradingMethods.getMappedMarketSegmentId(parseInt(element.seg));
                this.marketProtPercList.Add(mapMktSegId.toString(), element.value);
            }
        }

        for (let iPartIdx = 0; iPartIdx < resLogin.result.participantCode.length; iPartIdx++) {
            switch (resLogin.result.participantCode[iPartIdx].nMarketSegmentId) {
                case clsConstants.C_V_MAPPED_NSE_CASH:
                    this.nseEqParticipantID = resLogin.result.participantCode[iPartIdx].ParticipantCode;
                    break;
                case clsConstants.C_V_MAPPED_NSE_DERIVATIVES:
                    this.nseDervParticipantID = resLogin.result.participantCode[iPartIdx].ParticipantCode;
                    break;
                case clsConstants.C_V_MAPPED_BSE_CASH:
                    this.bsePartType = resLogin.result.participantCode[iPartIdx].ParticipantCode;
                    break;
                case clsConstants.C_V_MAPPED_NSX_DERIVATIVES:
                    this.nsxParticipantID = resLogin.result.participantCode[iPartIdx].ParticipantCode;
                    break;
            }
        }

        clsGlobal.User.loginAllowed = resLogin.result.loginAllowed;
        clsGlobal.User.BracketOrderAllowed = resLogin.result.bracketOrderAllowed;
        clsGlobal.User.TSLAllowed = resLogin.result.trailingSLAllowed;
        clsGlobal.User.viewAllowed = resLogin.result.viewAllowed;

        clsGlobal.User.OEProductString = resLogin.result.productsAllowed;

        clsGlobal.ExchManager.fillOEDictionaries();
        clsGlobal.ExchManager.fn_FillMasters();
        clsGlobal.ExchManager.init();

        clsGlobal.pubsub.publish('loadDeafaltIndices', resLogin);
        clsGlobal.pubsub.publish('pushOrderEntryOnManageLogin', resLogin);
    }
    productTypesList: any = [];
    exchangesList: any = [];
    fundsDetails: any = [];

    isLocal: boolean = false;
    isGlobal: boolean = false;

    selectedScrip: any;
    selectedArray: any = [];
    searchScrip: boolean = false;
    CalculatorType: any;


}




