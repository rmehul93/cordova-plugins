import { clsNSE } from './clsNSE';
import { clsBSE } from './clsBSE';
import { clsBSECDX } from './clsBSECDX';
import { clsMCX } from './clsMCX';
import { clsMCXSX } from './clsMCXSX';
import { clsNCDEX } from './clsNCDEX';
import { clsNMCE } from './clsNMCE';
import { clsNSEL } from './clsNSEL';
import { clsNSX } from './clsNSX';
import { clsNSEOTS } from './clsNSEOTS';
import { IKeyedCollection, Dictionary } from './clsCustomClasses';
import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsTradingMethods } from './clsTradingMethods';
import { StringBuilder } from './clsCustomClasses';
import { clsOrderEntryRequest } from './clsOrderEntryRequest';
import { clsHttpService } from './clsHTTPService';
import { clsICEX } from './clsICEX';
//import { Dictonary, IKeyedCollection } from '@angular/core';

export class clsExchManager {

    arrExch: any = [];
    arrExchSecInfo = [];
    arrExchContInfo = [];
    arrMarginDD = [];
    arrValidityForSpread = [];

    dcInst: IKeyedCollection<string> = new Dictionary<string>();
    dcProductType: IKeyedCollection<string> = new Dictionary<string>();
    dcValidity: IKeyedCollection<string> = new Dictionary<string>();
    dcOrderType: IKeyedCollection<string> = new Dictionary<string>();
    dcEnableDisableFields: IKeyedCollection<string> = new Dictionary<string>();

    objNSE: any;
    objBSE: any;
    objMCX: clsMCX;
    objNCDEX: any;

    /**
    * USD  : BT-12359
    * Date : 22/02/2020
    * Name : Nikhil Gawade
    * Description : parameter added for ICEX
    */
    objICEX: clsICEX;

    objNSEL: any;
    objMSX: any;
    objNSX: any;
    objNMCE: any;

    objDSE: any;
    objBFX: any;
    objDGCX: any;
    objUCX: any;
    objBSECDX: any;
    objNSEOTS: any;

    CurrentObj: any;

    //Master related letiables
    exchangeMaster: IKeyedCollection<string> = new Dictionary<string>();
    allowedExchangeList: any;
    exchangeAllowed: IKeyedCollection<string> = new Dictionary<string>();
    loginAllowed: IKeyedCollection<string> = new Dictionary<string>();
    marginPlusAllowed: IKeyedCollection<string> = new Dictionary<string>();
    instrumentMaster: IKeyedCollection<string> = new Dictionary<string>();
    orderTypeMaster: IKeyedCollection<string> = new Dictionary<string>();
    productTypeMaster: IKeyedCollection<string> = new Dictionary<string>();
    validityMaster: IKeyedCollection<string> = new Dictionary<string>();
    cRPAllowedDictionary: IKeyedCollection<string> = new Dictionary<string>();
    allowedSegments: IKeyedCollection<string> = new Dictionary<string>();
    instrumentTypes: IKeyedCollection<string> = new Dictionary<string>();
    exchangeAllowedWithNames: IKeyedCollection<string> = new Dictionary<string>();
    normalexchangeAllowedWithNames: IKeyedCollection<string> = new Dictionary<string>();
    exchName = '';

    //Following arrays are created only to hold ajax response callback objects for lookup   
    scripSeries: any;
    scripExpDateNOptionType: any;
    scripStrikePrice: any;

    //clsGlobal array having segment ID's for LOT related segments
    exchInLOT: any = [];
    dcMktStatus: IKeyedCollection<string> = new Dictionary<string>();

    //clsGlobal letiables to maintain Market Status
    sNSEStatus: string = '-';
    sNSEDervStatus: string = '-';
    sBSEStatus: string = '-';
    sBSESPOSStatus: string = '-';
    sBSEDervStatus: string = '-';
    sMCXStatus: string = '-';
    sNCDEXStatus: string = '-';
    /**
    * USD  : BT-12359
    * Date : 22/02/2020
    * Name : Nikhil Gawade
    * Description : parameter added for ICEX
    */
    sICEXStatus: string = "-";
    sNSELStatus: string = '-';
    sMSXStatus: string = '-';
    sNSXStatus: string = '-';
    sMCXSXEQStatus: string = '-';
    sMCXSXEQSPOSStatus: string = '-';
    sMCXSXFAOStatus: string = '-';
    sDSEEQStatus: string = '-';
    sNMCEFUTStatus: string = '-';
    sDGCXStatus: string = '-';
    sBFXStatus: string = '-';
    sUCXStatus: string = '-';
    sNSEOTSStatus: string = '-';
    sBSECDXStatus: string = '-';

    arrMktStatus: any;
    arrAuctionStatus: any;

    //For Preferences
    token = '';
    priceNumerator = 1;
    priceDenominator = 1;
    genNumerator = 1;
    genDenominator = 1;
    clsHttpService: any;
    logManager: any;

    private rejectFnc: any;
    http: clsHttpService;
    constructor(clsHttpService, LogManagerService) {
        this.http = clsHttpService;
        //this.logManager = LogManagerService;
        this.initializeExchManager();
    }

    init() {
        try {
            // _selfEM.dcInst = _selfEM.InstrumentMaster;
            this.dcInst = this.instrumentTypes;
            this.dcProductType = this.productTypeMaster;
            this.dcValidity = this.validityMaster;
            this.dcOrderType = this.orderTypeMaster;

            this.fillMktSegmentIdHavingLots();

            // Create the objects for the allowed exchanges....
            this.createExchangeObjects();
            //this.arrExch = this.ExchangeMaster.items["Exchange"];
            this.arrExch = this.exchangeMaster.getItem("LOOKUP");

            ///////////////// array for Security Info ///////////////

            ////////////////// Need to change, hard coded for time being....///////////////////
            if (this.arrExch.indexOf(clsConstants.C_S_NSE_EXCHANGE_TEXT))
                this.arrExchSecInfo.push(clsConstants.C_S_NSE_EXCHANGE_TEXT);
            if (this.arrExch.indexOf(clsConstants.C_S_BSE_EXCHANGE_TEXT))
                this.arrExchSecInfo.push(clsConstants.C_S_BSE_EXCHANGE_TEXT);
            if (this.arrExch.indexOf(clsConstants.C_S_MSX_EXCHANGE_TEXT))
                this.arrExchSecInfo.push(clsConstants.C_S_MSX_EXCHANGE_TEXT);
            if (this.arrExch.indexOf(clsConstants.C_S_OTSTXT_EXCHANGE_TEXT))
                this.arrExchSecInfo.push(clsConstants.C_S_OTSTXT_EXCHANGE_TEXT);

            ///////////// array for Contract Info //////////////////

            let _lstexchangeAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.viewAllowed);//clsGlobal.User.exchangeAllowed.split('$');

            for (let i = 0; i < this.arrExch.length; i++) {
                if (this.arrExch[i] == (clsConstants.C_S_NSE_EXCHANGE_TEXT)) {
                    if (_lstexchangeAllowedVal.indexOf(clsConstants.C_V_NSE_DERIVATIVES.toString()) != -1)
                        this.arrExchContInfo.push(this.arrExch[i]);
                }
                else if (this.arrExch[i] == (clsConstants.C_S_BSE_EXCHANGE_TEXT)) {
                    if (_lstexchangeAllowedVal.indexOf(clsConstants.C_V_BSE_DERIVATIVES.toString()) != -1)
                        this.arrExchContInfo.push(this.arrExch[i]);
                }
                else if (this.arrExch[i] == (clsConstants.C_S_MSX_EXCHANGE_TEXT)) {
                    if (_lstexchangeAllowedVal.indexOf(clsConstants.C_V_MSX_DERIVATIVES.toString()) != -1)
                        this.arrExchContInfo.push(this.arrExch[i]);
                }
                else
                    this.arrExchContInfo.push(this.arrExch[i]);
            }
        } catch (error) {
            //this.logManager.WriteLog('Exception: ' + error.message, 'Init()', 'tr_ExchManager.js', '');
        }
    }

    fillMktSegmentIdHavingLots() {
        try {
            this.exchInLOT.push(clsConstants.C_V_MCX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_NSEL_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_MSX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_NSX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_BSECDX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_DGCX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_BFX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_UCX_DERIVATIVES);
            this.exchInLOT.push(clsConstants.C_V_MSX_CASH);
            this.exchInLOT.push(clsConstants.C_V_MSX_FAO);
            /**
             * USD : BT-12359
            * Date : 22/02/2020
            * Name : Nikhil Gawade
            * Description : added for ICEX
           */
            this.exchInLOT.push(clsConstants.C_V_ICEX_DERIVATIVES);
        }
        catch (e) {
            //this.logManager.WriteLog('Exception: ' + e.message, 'fillMktSegmentIdHavingLots()', 'tr_ExchManager.js', '');
        }
    }

    /**
     * Function to be used for OrderEntry for filtering the allowed exchanges from 
     * master data
     */
    populateExchanges(_Source) {
        try {
            let _arrExchOE = [];
            let _AllowedIDXExcharr = [];
            if (_Source == clsConstants.C_V_ORDERENTRY_PAGE) {
                //_arrExchOE = $.grep(_selfEM.exchangeMaster.getItem("LOOKUP"), function (element) {
                //    return $.inarray(element, _selfEM.ExchangeMaster["Exchange"]) != -1;
                //});

                for (let i = 0; i < this.exchangeMaster.getItem("LOOKUP").length; i++) {
                    if (this.exchangeMaster["Exchange"].Contains(this.exchangeMaster.getItem("LOOKUP")[i]))
                        _arrExchOE.push(this.exchangeMaster.getItem("LOOKUP")[i]);
                }
            }
            else if (_Source == clsConstants.C_V_INDEXWATCH_PAGE) {
                _AllowedIDXExcharr = [clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_S_MCX_EXCHANGE_TEXT, clsConstants.C_S_NCDEX_EXCHANGE_TEXT, clsConstants.C_S_MSX_EXCHANGE_TEXT];
                //_arrExchOE = $.grep(_selfEM.exchangeMaster.getItem("LOOKUP"), function (element) {
                //    return $.inarray(element, _AllowedIDXExcharr) != -1;
                //});

                for (let i = 0; i < this.exchangeMaster.getItem("LOOKUP").length; i++) {
                    //if (_AllowedIDXExcharr.Contains(this.exchangeMaster.getItem("LOOKUP")[i]))
                    if (_AllowedIDXExcharr.indexOf(this.exchangeMaster.getItem("LOOKUP")[i]))
                        _arrExchOE.push(this.exchangeMaster.getItem("LOOKUP")[i]);
                }
            }
            else if (_Source == clsConstants.C_V_AUCTIONSTATUS_PAGE) {
                let _AllowedIDXExcharr = [clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_S_MCX_EXCHANGE_TEXT, clsConstants.C_S_NSEL_EXCHANGE_TEXT];
                //_arrExchOE = $.grep(_selfEM.exchangeMaster.getItem("LOOKUP"), function (element) {
                //    return $.inarray(element, _AllowedIDXExcharr) != -1;
                //});

                for (let i = 0; i < this.exchangeMaster.getItem("LOOKUP").length; i++) {
                    //if (_AllowedIDXExcharr.Contains(this.exchangeMaster.getItem("LOOKUP")[i]))
                    if (_AllowedIDXExcharr.indexOf(this.exchangeMaster.getItem("LOOKUP")[i]))
                        _arrExchOE.push(this.exchangeMaster.getItem("LOOKUP")[i]);
                }
            }
            else if (_Source == clsConstants.C_V_STOCKVIEW_PAGENO) {
                let _AllowedIDXExcharr = [clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_S_MSX_EXCHANGE_TEXT];

                for (let i = 0; i < this.exchangeMaster.getItem("LOOKUP").length; i++) {
                    //if (_AllowedIDXExcharr.Contains(this.exchangeMaster.getItem("LOOKUP")[i]))
                    if (_AllowedIDXExcharr.indexOf(this.exchangeMaster.getItem("LOOKUP")[i]))
                        _arrExchOE.push(this.exchangeMaster.getItem("LOOKUP")[i]);
                }
            }
            return _arrExchOE;
        } catch (error) {

        }
    };

    // Creating the Objects for all the allowed exchanges...
    // List of allowed instrument will be passed as the parameter to the constructor to create the object...
    createExchangeObjects() {
        try {
            for (let i = 0; i < this.exchangeMaster.getItem("LOOKUP").length; i++) {
                switch (this.exchangeMaster.getItem("LOOKUP")[i]) {
                    case clsConstants.C_S_NSE_EXCHANGE_TEXT:
                        this.objNSE = new clsNSE(this.dcInst.getItem(clsConstants.C_S_NSE_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_BSE_EXCHANGE_TEXT:
                        this.objBSE = new clsBSE(this.dcInst.getItem(clsConstants.C_S_BSE_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_MCX_EXCHANGE_TEXT:
                        this.objMCX = new clsMCX(this.dcInst.getItem(clsConstants.C_S_MCX_EXCHANGE_TEXT));
                        break;
                    //case clsConstants.C_S_DGCX_EXCHANGE_TEXT:
                    //    this.objDGCX = new fn_DGCX(this.dcInst.getItem(clsConstants.C_S_DGCX_EXCHANGE_TEXT]);
                    //    break;
                    //case clsConstants.C_S_BFX_EXCHANGE_TEXT:
                    //    this.objBFX = new fn_BFX(this.dcInst.getItem(clsConstants.C_S_BFX_EXCHANGE_TEXT]);
                    //    break;
                    case clsConstants.C_S_NCDEX_EXCHANGE_TEXT:
                        this.objNCDEX = new clsNCDEX(this.dcInst.getItem(clsConstants.C_S_NCDEX_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_NSEL_EXCHANGE_TEXT:
                        this.objNSEL = new clsNSEL(this.dcInst.getItem(clsConstants.C_S_NSEL_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_MSX_EXCHANGE_TEXT:
                        this.objMSX = new clsMCXSX(this.dcInst.getItem(clsConstants.C_S_MSX_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_NSX_EXCHANGE_TEXT:
                        this.objNSX = new clsNSX(this.dcInst.getItem(clsConstants.C_S_NSX_EXCHANGE_TEXT));
                        break;
                    case clsConstants.C_S_BSECDX_EXCHANGE_TEXT:
                        this.objBSECDX = new clsBSECDX(this.dcInst.getItem(clsConstants.C_S_BSECDX_EXCHANGE_TEXT));
                        break;
                    //case clsConstants.C_S_DSE_EXCHANGE_TEXT:
                    //    this.objDSE = new fn_DSE(this.dcInst.getItem(clsConstants.C_S_DSE_EXCHANGE_TEXT]);
                    //    break;
                    case clsConstants.C_S_NMCE_EXCHANGE_TEXT:
                        this.objNMCE = new clsNMCE(this.dcInst.getItem(clsConstants.C_S_NMCE_EXCHANGE_TEXT));
                        break;
                    //case clsConstants.C_S_UCX_EXCHANGE_TEXT:
                    //    this.objUCX = new fn_UCX(this.dcInst.getItem(clsConstants.C_S_UCX_EXCHANGE_TEXT]);
                    //    break;
                    case clsConstants.C_S_OTSTXT_EXCHANGE_TEXT:
                        this.objNSEOTS = new clsNSEOTS(this.dcInst.getItem(clsConstants.C_S_OTSTXT_EXCHANGE_TEXT));
                        break;
                    /**
                             * USD : BT-12359
                            * Date : 22/02/2020
                            * Name : Nikhil Gawade
                            * Description : condition added for ICEX
                           */
                    case clsConstants.C_S_ICEX_EXCHANGE_TEXT:
                        this.objICEX = new clsICEX(this.dcInst.getItem(clsConstants.C_S_ICEX_EXCHANGE_TEXT));
                        break;
                }
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'createExchangeObjects()', 'tr_ExchManager.js', '');

        }
    }

    // Function will be return the Exchange object based on the Exchange Name passed...
    // Once we get the Exchange object, the same object can be used to access all the functions inside the exchange class... 
    // like, populateValidity, populateOrderType etc...
    public getCurrentExchange(_ExchName) {
        try {
            let oExch: any;

            switch (_ExchName) {
                case clsConstants.C_S_NSE_EXCHANGE_TEXT:
                case clsConstants.C_S_NSE_EQ_API_NAME:
                case clsConstants.C_S_NSE_DERV_API_NAME:    
                    oExch = this.objNSE;
                    break;
                case clsConstants.C_S_BSE_EXCHANGE_TEXT:
                case clsConstants.C_S_BSE_EQ_API_NAME:
                case clsConstants.C_S_BSE_DERV_API_NAME: 
                    oExch = this.objBSE;
                    break;
                case clsConstants.C_S_MCX_EXCHANGE_TEXT:
                case clsConstants.C_S_MCX_FUTURES_API_NAME:
                    oExch = this.objMCX;
                    break;
                case clsConstants.C_S_DGCX_EXCHANGE_TEXT:
                    oExch = this.objDGCX;
                    break;
                case clsConstants.C_S_BFX_EXCHANGE_TEXT:
                    oExch = this.objBFX;
                    break;
                case clsConstants.C_S_NCDEX_EXCHANGE_TEXT:
                case clsConstants.C_S_NCDEX_FUTURES_API_NAME:
                    oExch = this.objNCDEX;
                    break;
                case clsConstants.C_S_NSEL_EXCHANGE_TEXT:
                    oExch = this.objNSEL;
                    break;
                case clsConstants.C_S_MSX_EXCHANGE_TEXT:
                    oExch = this.objMSX;
                    break;
                case clsConstants.C_S_NSX_EXCHANGE_TEXT:
                    oExch = this.objNSX;
                    break;
                case clsConstants.C_S_BSECDX_EXCHANGE_TEXT:
                    oExch = this.objBSECDX;
                    break;
                case clsConstants.C_S_DSE_EXCHANGE_TEXT:
                    oExch = this.objDSE;
                    break;
                case clsConstants.C_S_NMCE_EXCHANGE_TEXT:
                    oExch = this.objNMCE;
                    break;
                case clsConstants.C_S_UCX_EXCHANGE_TEXT:
                    oExch = this.objUCX;
                    break;
                case clsConstants.C_S_OTSTXT_EXCHANGE_TEXT:
                    oExch = this.objNSEOTS;
                    break;
                /**
    * USD : BT-12359
   * Date : 22/02/2020
   * Name : Nikhil Gawade
   * Description : condition added for ICEX
  */
                case clsConstants.C_S_ICEX_EXCHANGE_TEXT:
                    oExch = this.objICEX;
                    break;
            }

            return oExch;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'getCurrentExchange()', 'tr_ExchManager.js', '');

        }
    }

    // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
    getMarketSegmentId(_ExchName, _InstName) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);

            // return the value in the MarketSegmentId hash table for the selected instrument... 
            // coz market segment id can be fetched by using Exchange and Instrument
            return this.CurrentObj.dcMarketSegementId[_InstName];

        }
        catch (e) {

        }
    }

    // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
    getMarketSegmentIdForIndex(_ExchName) {
        try {
            let iMktSegId: number = -1;

            switch (_ExchName) {
                case clsConstants.C_S_NSE_EXCHANGE_TEXT:
                    iMktSegId = clsConstants.C_V_NSE_CASH;
                    break;
                case clsConstants.C_S_BSE_EXCHANGE_TEXT:
                    iMktSegId = clsConstants.C_V_BSE_CASH;
                    break;
                case clsConstants.C_S_MCX_EXCHANGE_TEXT:
                    iMktSegId = clsConstants.C_V_MCX_SPOT;
                    break;
                case clsConstants.C_S_NCDEX_EXCHANGE_TEXT:
                    iMktSegId = clsConstants.C_V_NCDEX_SPOT;
                    break;
                case clsConstants.C_S_MSX_EXCHANGE_TEXT:
                    iMktSegId = clsConstants.C_V_MSX_CASH;
                    break;
            }

            return iMktSegId;
        }
        catch (e) {

        }
    }

    // Fuction to Get the DiscQty based on Exchange Name and Instrument Name and marketSegId
    getDetailsForDiscQty(_ExchName, _InstName, _Qty, _MktSegID) {
        try {
            if (_MktSegID == clsConstants.C_V_NSE_CASH ||
                _MktSegID == clsConstants.C_V_NSE_DERIVATIVES) {
                if (_Qty != '')
                    return _Qty; // Disc qty should be same as qty
                else
                    return undefined;
            }
            else
                return ''; // No Condition required for Disc qty...
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'getDetailsForDiscQty()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    //Function to decide whether the DiscQty value should be filled or not. (Irrespective of the Enable/Disable property)
    getDiscQtyFillValue(marketSegID, validity, orderType, dcOrderDetails) {
        let check = false;
        try {

            if ((marketSegID == clsConstants.C_V_NSE_CASH || marketSegID == clsConstants.C_V_NSE_DERIVATIVES)) {
                //check = false;
                if (orderType != clsConstants.C_S_ORDER_CALLAUCTION_TEXT) {

                    //Change for Ticket 001-00-378950.  For NSE CASH DiscQty default value will be 0
                    //Modified by vishal on 11AUG2015 from 'undefined' to undefined
                    if (dcOrderDetails != undefined) {
                        if (!dcOrderDetails["ModifyFlag"] && marketSegID == clsConstants.C_V_NSE_CASH && (orderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT || orderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT))
                            check = false;
                        else if (marketSegID == clsConstants.C_V_NSE_CASH && (orderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || orderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT))
                            check = false;
                        else
                            if (validity == 'IOC')
                                check = false;
                            else
                                check = true;
                        //check = true;
                    }

                    //Irrespective of the market seg, DiscQty should not be filled if validity is IOC
                    //if (validity == clsConstants.C_S_VALUE_IOC) {
                    //    check = false;
                    //}
                    //else {
                    //    check = true;
                    //}
                }
            }

            else if (marketSegID == clsConstants.C_V_BSE_DERIVATIVES) {
                //Added by vishal on 11AUG2015 for CR3604 automation test case 14
                if (validity == 'IOC')
                    check = false;
                // else
                //    check = true;
            }
            else if (marketSegID == clsConstants.C_V_DGCX_DERIVATIVES || marketSegID == clsConstants.C_V_DGCX_SPOT)
                check = false;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'getDiscQtyFillValue()', 'tr_ExchManager.js', '');

        }
        return check;
    }

    // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
    orderTypeEnableDisable(SelOrderTypes, MarketSegmentId) {
        let bEnable = true;
        try {
            /**  now in new UI 'RL MKT' option provided in drop down itself, 
             *  in wave 1.0 there is no option of 'RL MKT'. 
             * so below condition was aplicable for wave 1.0 for converting RL to RL MKT.
            *
            if (SelOrderTypes == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
                if (MarketSegmentId == clsConstants.C_V_BSE_CASH ||
                    MarketSegmentId == clsConstants.C_V_MCX_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_MSX_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_NSEL_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_NMCE_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_DGCX_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_UCX_DERIVATIVES ||
                    MarketSegmentId == clsConstants.C_V_MSX_CASH ||
                    MarketSegmentId == clsConstants.C_V_MSX_FAO ||
                    MarketSegmentId == clsConstants.C_V_BSECDX_DERIVATIVES)
                    bEnable = false;
            }
            */
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'orderTypeEnableDisable()', 'tr_ExchManager.js', '');

        }
        return bEnable;
    }

    isPrimaryValidation(SelExchange, SelInstrument, MarketSegmentId, SelValidity) {
        let bEnable = false;
        try {
            if (((SelExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT && SelInstrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) || MarketSegmentId == clsConstants.C_V_BSE_DERIVATIVES ||
                (SelExchange == clsConstants.C_S_MSX_EXCHANGE_TEXT && SelInstrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) || SelExchange == clsConstants.C_S_NSX_EXCHANGE_TEXT || SelExchange == clsConstants.C_S_BSECDX_EXCHANGE_TEXT
                || SelExchange == clsConstants.C_S_DGCX_EXCHANGE_TEXT || MarketSegmentId == clsConstants.C_V_MSX_FAO) && SelValidity != clsConstants.C_S_VALUE_IOC)
                bEnable = true;
        }
        catch (e) {

        }
        return bEnable;
    }

    isSecondaryValidation(MarketSegmentId, bFlag) {
        let bEnable = false;
        try {
            if (bFlag == "1") {
                if (MarketSegmentId != clsConstants.C_V_NSX_DERIVATIVES && MarketSegmentId != clsConstants.C_V_BSECDX_DERIVATIVES && MarketSegmentId != clsConstants.C_V_MSX_CASH && MarketSegmentId != clsConstants.C_V_MSX_FAO)
                    bEnable = true;
            }
            else if (bFlag == "2") {
                if (MarketSegmentId == clsConstants.C_V_NSE_CASH || MarketSegmentId == clsConstants.C_V_NSX_DERIVATIVES || MarketSegmentId == clsConstants.C_V_BSECDX_DERIVATIVES)
                    bEnable = true;
            }
        }
        catch (e) {

        }
        return bEnable;
    }

    // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
    getMapMarketSegmentId(_ExchName, _MktSegId) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // return the value in the MarketSegmentId hash table for the selected instrument... 
            // coz market segment id can be fetched by using Exchange and Instrument
            return this.CurrentObj.dcMapMarketSegementId.getItem(_MktSegId);
        }
        catch (e) {

            //////this.logManager.WriteLog('Exception: ' + e.message, 'getMapMarketSegmentId()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Fuction to Get the Market SegmentId based on Exchange Name and Instrument Name
    getDecimalLocator(_ExchName, _SegId) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // return the value in the MarketSegmentId hash table for the selected instrument... 
            // coz market segment id can be fetched by using Exchange and Instrument
            return this.CurrentObj.dcDecimalLoc.getItem(_SegId);
        }
        catch (e) {

            //////this.logManager.WriteLog('Exception: ' + e.message, 'getDecimalLocator()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Populating the instrument list based on the exchange
    populateInstrument(_ExchName, _Source) {
        try {
            // First get the Exchange object and return the Instrument array from the exchange object...
            let _arrTempInst = [];
            if (_Source != clsConstants.C_V_ORDERENTRY_PAGE)
                _arrTempInst = (this.getCurrentExchange(_ExchName)).arrInst;
            else {
                _arrTempInst = this.instrumentMaster.getItem(_ExchName).split('$');
                //_arrTempInst = $.grep((this.getCurrentExchange(_ExchName)).arrInst, function (element) {
                //    return $.inarray(element, this.instrumentMaster.getItem(_ExchName].split('$')) != -1;
                //});
            }
            return _arrTempInst;
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'populateInstrument()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    populateValidity(_ExchName, _MktSegmentID) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            this.CurrentObj.populateValidity(this.dcValidity.getItem(_MktSegmentID));
            return this.CurrentObj.arrValidity;
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'populateValidity()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    populateProductTypes(_ExchName, _MktSegmentID, isBulkOrderEntry) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level populateproducttypes function and return the product type for the specified exchange...
            this.CurrentObj.populateProductTypes(this.dcProductType.getItem(_MktSegmentID));

            let arrProductType = [];
            if (isBulkOrderEntry) {
                for (let i = 0; i < this.CurrentObj.arrProductType.length; i++) {
                    if (this.CurrentObj.arrProductType[i] != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                        arrProductType.push(this.CurrentObj.arrProductType[i]);
                    }
                }
            }
            else
                arrProductType = this.CurrentObj.arrProductType;

            return arrProductType;
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'PopulateProductTypes()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    populateOrderTypes(_ExchName, _MktSegmentID) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level PopulateOrderTypes function and return the OrderType for the specified exchange...
            this.CurrentObj.populateOrderTypes(this.dcOrderType.getItem(_MktSegmentID));
            return this.CurrentObj.arrOrderType;
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    populateMarginDD() {
        try {

            let _strMargin = '';
            _strMargin = clsConstants.C_S_FULL_MARGIN + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_FIXED_MARGIN;
            this.arrMarginDD = _strMargin.split('$');

            return this.arrMarginDD;
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    displayMarginDD(_ExchName, _InstName) {
        try {
            if (_ExchName == clsConstants.C_S_OTSTXT_EXCHANGE_TEXT) {
                if (clsGlobal.User.OdinCategory == 5 || clsGlobal.User.nseEqParticipantID.length > 0)   // To be enabled only for institutional clients
                    return true;
                else
                    return false;
            }
            else {
                return false;
            }
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'DisplayMarginDD()', 'tr_ExchManager.js', '');

        }
    }

    // This function is used to populate the validity  on selection of Exchanges
    enableDisable(_ExchName, _InstName) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level EnableDisable function for the specified exchange...
            return this.CurrentObj.enableDisable(_InstName);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'EnableDisable()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Function to get the details whenever there is a change in the order type...
    getDetailsForOrderType(_ExchName, _OrderType, _Instrument) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level GetDetailsForOrderType function and return the details for the specified exchange...
            return this.CurrentObj.getDetailsForOrderType(_OrderType, _Instrument);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'GetDetailsForOrderType()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Function to get the details whenever there is a change in the validity...
    getDetailsForValidity(_ExchName, _Validity, _Instrument, _OrderType) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level GetDetailsForValidity function and return the details for the specified exchange...
            return this.CurrentObj.getDetailsForValidity(_Validity, _Instrument, _OrderType);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Function to get the details whenever there is a change in the validity...
    getDayValueForValidity(_ExchName, _Validity) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level GetDetailsForValidity function and return the details for the specified exchange...
            return this.CurrentObj.getDayValueForValidity(_Validity);
        }
        catch (e) {
            //<JasobNoObfs>
            ////this.logManager.WriteLog('Exception: ' + e.message, 'GetDayValueForValidity()', 'tr_ExchManager.js', '');
            //</JasobNoObfs>
            return undefined;
        }
    }

    // Function to get the details whenever there is a change in the order type...
    getDetailsForMktProtPerc(_ExchName, _MapMarketSegmentId, _Price, _MarketSegmentId, _MPPrice, _ProdType) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level GetDetailsForOrderType function and return the details for the specified exchange...
            return this.CurrentObj.getDetailsForMktProtPerc(_MapMarketSegmentId, _Price, _MarketSegmentId, _MPPrice, _ProdType);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'GetDetailsForMktProtPerc()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Function to Validate the orders...
    validateOrder(_ExchName, _dcOrderDetails) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            // Call the Exchange level ValidateOrder function and return the status...
            return this.CurrentObj.validateOrder(_dcOrderDetails);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity()', 'tr_ExchManager.js', '');

            return undefined;
        }
    }

    // Function to Validate the scrip...
    validateScripDetails(_ExchName, _dcLookupDetails) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            return this.CurrentObj.validateScripDetails(_dcLookupDetails);
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'ValidateScripDetails()', 'tr_ExchManager.js', '');

            return undefined;
        }
    };

    fillExchangeMaster() {
        try {
            let _lstSpot: any = [];
            let _lstDerivatives: any = [];

            /* To be called very first time to fill User Master dictionary which contains
            * data of exchange list categorized */
            if (clsGlobal.User.loginAllowed > 0) {
                let _lstLoginAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.loginAllowed);//clsGlobal.User.loginAllowed.split('$');

                this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSE_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSE_CASH.toString()) != -1)
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_BSE_EXCHANGE_TEXT);
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSE_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_BSE_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BSE_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MCX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_MCX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MCX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NCDEX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NCDEX_EXCHANGE_TEXT);
                }
                //Here NSEL has been Added to derivatives list as NSEL FUTCOM is to be incorporated
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSEL_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NSEL_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSEL_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_CASH.toString()) != -1)
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_FAO.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NMCE_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NMCE_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NMCE_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_DSE_CASH.toString()) != -1)
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_DSE_EXCHANGE_TEXT);
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_NSX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_BSECDX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BSECDX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_UCX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_UCX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_UCX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_DGCX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_DGCX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_DGCX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BFX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_BFX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BFX_EXCHANGE_TEXT);
                }
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_OFS_IPO_BONDS.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_OTSTXT_EXCHANGE_TEXT);
                }

                /**
             * USD : BT-12359
            * Date : 22/02/2020
            * Name : Nikhil Gawade
            * Description : condition added for ICEX
           */
                if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_ICEX_DERIVATIVES.toString()) != -1) {
                    this.fn_CategorizeExchanges(_lstSpot, clsConstants.C_S_ICEX_EXCHANGE_TEXT);
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_ICEX_EXCHANGE_TEXT);
                }

            }
            this.exchangeMaster = new Dictionary<any>();
            this.exchangeMaster.Add("Exchange", _lstSpot);
            this.exchangeMaster.Add(clsConstants.OE_PANELTYPE_DERV, _lstDerivatives);


            let _lstexchangeAllowed = this.fillAllowedExchangeList();
            this.exchangeMaster.Add("LOOKUP", _lstexchangeAllowed);

            //Added For Ticket 001-00-482446
            let _lstexchangeAllowedDerv: any = this.fillAllowedExchangeListDerv();
            this.exchangeMaster.Add(clsConstants.LOOKUP_DERV, _lstexchangeAllowedDerv);

            this.fillInstrumentTypes();
            this.fillExchangeswithMappedSegmentId();
            this.fillExchangeswithNormalSegmentId();
        }
        catch (e) {

            ////this.logManager.WriteLog('Exception: ' + e.message, 'fillExchangeMaster()', 'tr_ExchManager.js', '');

        }
    }


    /// <summary>
    /// Function to set the Allowed Exchanges of the user based on Exchanges allowed set in Login
    /// Used for Symbol LookUp
    /// </summary>
    fillAllowedExchangeList() {
        try {
            this.allowedExchangeList = [];
            if (this.exchangeAllowed.Count() > 0) {
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_BSE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_BSE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_MCX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NCDEX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NSEL_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NMCE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_DSE_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_NSX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_BSECDX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_UCX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_DGCX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_BFX_EXCHANGE_TEXT);
                if (this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_OTSTXT_EXCHANGE_TEXT);
                /**
     * USD : BT-12359
    * Date : 22/02/2020
    * Name : Nikhil Gawade
    * Description : condition added for ICEX
   */
                if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(this.allowedExchangeList, clsConstants.C_S_ICEX_EXCHANGE_TEXT);

            }
            this.fillAllowedSegments();
            return this.allowedExchangeList;
        }
        catch (e) {


        }
    }

    //Added For Ticket 001-00-482446
    /// <summary>
    /// Function to set the Allowed Exchanges of the user based on Login allowed set in Login
    /// Used for Symbol LookUp
    /// </summary>
    fillAllowedExchangeListDerv() {
        let _lstDerivatives = []
        try {

            /* To be called very first time to fill User Master dictionary which contains
            * data of exchange list categorized */
            if (this.exchangeAllowed.Count() > 0) {
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSE_EXCHANGE_TEXT);
                }

                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BSE_EXCHANGE_TEXT);

                if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MCX_EXCHANGE_TEXT);

                if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NCDEX_EXCHANGE_TEXT);
                }

                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSEL_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                }

                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_MSX_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NMCE_EXCHANGE_TEXT);
                }

                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_NSX_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BSECDX_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_UCX_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_DGCX_EXCHANGE_TEXT);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_BFX_EXCHANGE_TEXT);
                }
                /**
         * USD : BT-12359
        * Date : 22/02/2020
        * Name : Nikhil Gawade
        * Description : condition added for ICEX Segment
       */
                if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
                    this.fn_CategorizeExchanges(_lstDerivatives, clsConstants.C_S_ICEX_EXCHANGE_TEXT);
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillAllowedExchangeListDerv()', 'tr_ExchManager.js', '');

        }

        return _lstDerivatives;

    }

    /// <summary>
    /// To get the Mapped Segment Id and related Exchanges based on dynamic exchanges
    /// </summary>
    fillExchangeswithMappedSegmentId() {

        this.exchangeAllowedWithNames = new Dictionary<string>();

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NSE_CASH.toString(), clsConstants.C_S_NSE_EQ);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NSE_DERIVATIVES.toString(), clsConstants.C_S_NSE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_BSE_CASH.toString(), clsConstants.C_S_BSE_EQ);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_BSE_DERIVATIVES.toString(), clsConstants.C_S_BSE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_MCX_DERIVATIVES.toString(), clsConstants.C_S_MCX_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES.toString(), clsConstants.C_S_NCDEX_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NSEL_DERIVATIVES.toString(), clsConstants.C_S_NSEL_SPTCOM_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_MSX_DERIVATIVES.toString(), clsConstants.C_S_MCXSX_CUR);//1024

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_MSX_CASH.toString(), clsConstants.C_S_MCXSX_EQ);//512

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_MSX_FAO.toString(), clsConstants.C_S_MCXSX_FUT);//4096

        if (this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_DSE_CASH.toString(), clsConstants.C_S_DSE_EQUITIES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NMCE_DERIVATIVES.toString(), clsConstants.C_S_NMCE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_NSX_DERIVATIVES.toString(), clsConstants.C_S_NSX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES.toString(), clsConstants.C_S_BSECDX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_UCX_DERIVATIVES.toString(), clsConstants.C_S_UCX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_DGCX_DERIVATIVES.toString(), clsConstants.C_S_DGCX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_BFX_DERIVATIVES.toString(), clsConstants.C_S_BFX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_OFS_IPO_BONDS.toString(), clsConstants.C_S_IPO_DESC);

        // if (this.exchangeAllowed.getItem(clsConstants.C_V_MAPPED_DFM_CASH.toString()) == clsConstants.C_S_ON)
        //    this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_DFM_CASH, clsConstants.C_S_DFM_EQ_DESC);

        // if (this.exchangeAllowed.getItem(clsConstants.C_V_MAPPED_ADX_CASH.toString()) == clsConstants.C_S_ON)
        //    this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_ADX_CASH, clsConstants.C_S_ADX_EQ_DESC);

        /**
         * USD : BT-12359
        * Date : 22/02/2020
        * Name : Nikhil Gawade
        * Description : condition added for ICEX Segment
       */
        if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.exchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_ICEX_DERIVATIVES.toString(), clsConstants.C_S_ICEX_FAO);

    }

    fillExchangeswithNormalSegmentId() {

        this.normalexchangeAllowedWithNames = new Dictionary<string>();

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NSE_CASH.toString(), clsConstants.C_S_NSE_EQ);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), clsConstants.C_S_NSE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_BSE_CASH.toString(), clsConstants.C_S_BSE_EQ);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), clsConstants.C_S_BSE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), clsConstants.C_S_MCX_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), clsConstants.C_S_NCDEX_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), clsConstants.C_S_NSEL_SPTCOM_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), clsConstants.C_S_MCXSX_CUR);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MSX_CASH.toString(), clsConstants.C_S_MCXSX_EQ);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MSX_FAO.toString(), clsConstants.C_S_MCXSX_FUT);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_DSE_CASH.toString(), clsConstants.C_S_DSE_EQUITIES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), clsConstants.C_S_NMCE_FAO);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), clsConstants.C_S_NSX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_BSECDX_DERIVATIVES.toString(), clsConstants.C_S_BSECDX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_UCX_DERIVATIVES.toString(), clsConstants.C_S_UCX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), clsConstants.C_S_DGCX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), clsConstants.C_S_BFX_FUTURES_DESC);

        if (this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), clsConstants.C_S_IPO_DESC);

        /**
    * USD : BT-12359
   * Date : 22/02/2020
   * Name : Nikhil Gawade
   * Description : condition added for ICEX Segment
  */
        if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON)
            this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), clsConstants.C_S_ICEX_FAO);

        // if (this.exchangeAllowed.getItem(clsConstants.C_V_MAPPED_DFM_CASH.toString()) == clsConstants.C_S_ON)
        //    this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_DFM_CASH, clsConstants.C_S_DFM_EQ_DESC);

        // if (this.exchangeAllowed.getItem(clsConstants.C_V_MAPPED_ADX_CASH.toString()) == clsConstants.C_S_ON)
        //    this.normalexchangeAllowedWithNames.Add(clsConstants.C_V_MAPPED_ADX_CASH, clsConstants.C_S_ADX_EQ_DESC);
    }

    fillAllowedSegments() {
        try {
            this.allowedSegments = new Dictionary<string>();
            if (this.exchangeAllowed.Count() > 0) {
                //NSE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSE_CASH.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSE_DERIVATIVES.toString(), clsConstants.C_S_ON);
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSE_CASH.toString(), clsConstants.C_S_ON);
                }
                //BSE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BSE_CASH.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BSE_DERIVATIVES.toString(), clsConstants.C_S_ON);
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BSE_CASH.toString(), clsConstants.C_S_ON);
                }
                //MCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MCX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //NCDEX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NCDEX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //NSEL
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSEL_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSEL_SPOT.toString(), clsConstants.C_S_ON);
                }
                //MCX SX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MSX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MSX_SPOT.toString(), clsConstants.C_S_ON);
                }
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MSX_FAO.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MSX_CASH.toString(), clsConstants.C_S_ON);
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_MSX_CASH.toString(), clsConstants.C_S_ON);
                }
                //NSX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NSX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //BSECDX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BSECDX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //NMCE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_NMCE_DERIVATIVES.toString(), clsConstants.C_S_ON);
                }
                //DSE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_DSE_CASH.toString(), clsConstants.C_S_ON);
                }
                //UCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_UCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_UCX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //DGCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_DGCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_DGCX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //BFX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BFX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_BFX_SPOT.toString(), clsConstants.C_S_ON);
                }
                //NSE-OTS
                if (this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_OFS_IPO_BONDS.toString(), clsConstants.C_S_ON);
                }

                /**
            * USD : BT-12359
           * Date : 22/02/2020
           * Name : Rajendra Sirvi
           * Description : condition added for ICEX Segment
          */
                if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    this.allowedSegments.Add(clsConstants.C_V_MAPPED_ICEX_DERIVATIVES.toString(), clsConstants.C_S_ON);
                    //this.allowedSegments.Add(clsConstants.C_V_MAPPED_MCX_SPOT.toString(), clsConstants.C_S_ON);
                }
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillAllowedSegments()', 'tr_ExchManager.js', '');

        }
    }

    //Fill Instrument types
    fillInstrumentTypes() {
        try {
            let _objLstintrument = '';

            this.instrumentTypes = new Dictionary<string>();
            if (this.exchangeAllowed.Count() > 0) {
                //NSE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    // Added by Sakthi for FUTIVX
                    if (clsGlobal.dConfigMaster.getItem("VERSION_IS_SP16B_DECODED") == clsConstants.C_S_OFF)
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_NSE_EXCHANGE_TEXT, _objLstintrument);

                //BSE //.item remove in if
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_BSE_EXCHANGE_TEXT, _objLstintrument);

                //MCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    if (clsGlobal.dConfigMaster['INTEGRATED_MANAGER_B2'] == clsConstants.C_S_ON) {
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCSO_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    }
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_MCX_EXCHANGE_TEXT, _objLstintrument);
                }
                //NCDEX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_NCDEX_EXCHANGE_TEXT, _objLstintrument);
                }
                //NSEL
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_NSELSPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_MCXFUTSPT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    if (clsGlobal.dConfigMaster['INTEGRATED_MANAGER_B2'] == clsConstants.C_S_ON) {
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCSO_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    }
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_NSEL_EXCHANGE_TEXT, _objLstintrument);
                }
                //MCX SX

                if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';

                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;

                    if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRF_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        if (clsGlobal.dConfigMaster.getItem("MCXSX_FUTINT_ACTIVE") == clsConstants.C_S_ON)
                            _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTINT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        if (clsGlobal.dConfigMaster.getItem("MCXSX_OPTCUR_ACTIVE") == clsConstants.C_S_ON)
                            _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_CUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    }

                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;

                    if (this.exchangeAllowed.getItem(clsConstants.C_V_MAPPED_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRF_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        if (clsGlobal.dConfigMaster.getItem("MCXSX_FUTINT_ACTIVE") == clsConstants.C_S_ON)
                            _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTINT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        if (clsGlobal.dConfigMaster.getItem("MCXSX_OPTCUR_ACTIVE") == clsConstants.C_S_ON)
                            _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_CUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    }
                }
                else if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    if (this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_OFF &&
                        this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_OFF)
                        _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRF_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    if (clsGlobal.dConfigMaster.getItem("MCXSX_FUTINT_ACTIVE") == clsConstants.C_S_ON)
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTINT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    if (clsGlobal.dConfigMaster.getItem("MCXSX_OPTCUR_ACTIVE") == clsConstants.C_S_ON)
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_CUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_MSX_EXCHANGE_TEXT, _objLstintrument);

                //NSX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    //NSECDS FUTURES
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRD_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRC_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    //NSECDS SPOT
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_INDEX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_UNDCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_UNDIRD_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_UNDIRT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_NSX_EXCHANGE_TEXT, _objLstintrument);
                }
                //BSECDX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    //BSECDX FUTURES
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRD_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    //BSECDX SPOT
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_CUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_BSECDX_EXCHANGE_TEXT, _objLstintrument);
                }
                //NMCE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_NMCE_EXCHANGE_TEXT, _objLstintrument);
                }
                //DSE
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_DSE_EXCHANGE_TEXT, _objLstintrument);
                }
                //BFX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    //NSECDS FUTURES
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_DGCXSPOT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    //NSECDS SPOT
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_BFX_EXCHANGE_TEXT, _objLstintrument);
                }
                //DGCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    //NSECDS FUTURES
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_DGCXSPOT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_DGCX_EXCHANGE_TEXT, _objLstintrument);
                }
                //UCX
                if (this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    //NSECDS FUTURES
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_DGCXSPOT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_UCX_EXCHANGE_TEXT, _objLstintrument);
                }
                //NSE-OTS
                if (this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_OTSTXT_EXCHANGE_TEXT, _objLstintrument);
                }

                /**
             * USD : BT-12359
            * Date : 22/02/2020
            * Name : Nikhil Gawade
            * Description : condition added for ICEX Segment
           */
                if (this.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    _objLstintrument = '';
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSPT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    if (clsGlobal.dConfigMaster['INTEGRATED_MANAGER_B2'] == clsConstants.C_S_ON) {
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCSO_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    }
                    this.fn_AddDictionaryItem(this.instrumentTypes, clsConstants.C_S_ICEX_EXCHANGE_TEXT, _objLstintrument);
                }
            }
        }
        catch (e) {


        }
    }

    fn_CategorizeExchanges(_lstExch, _strExchangeName) {
        try {
            if (_lstExch.indexOf(_strExchangeName) == -1)
                _lstExch.push(_strExchangeName);
        }
        catch (e) {
            ////this.logManager.WriteLog('Exception: ' + e.message, 'CategorizeExchanges()', 'tr_ExchManager.js', '');
        }
        return _lstExch;
    }

    fn_AddDictionaryItem(_objDic, key, value) {
        try {
            if (typeof (value) != "object") {
                if (value.substring(value.length - 1, value.length) == '$')
                    value = value.substring(0, value.length - 1);
            }
            if (!_objDic.ContainsKey(key))//ContainsKey to containsKey pallavi
                _objDic.Add(key, value);//Add to Add pallavi
        }
        catch (e) {
            ////this.logManager.WriteLog('Exception: ' + e.message, 'AddDictionaryItem()', 'tr_ExchManager.js', '');
        }
        return _objDic;
    }

    fillOEDictionaries() {
        try {
            this.fillInstrumentMaster();
            this.fillOrderTypeMaster();
            //FillCRPDictionary();
            //this.fillProductMaster();
            this.fillProductTypeNewMaster();
            this.fillValidityMaster();
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'fillOEDictionaries()', 'tr_ExchManager.js', '');

        }
    }

    fillInstrumentMaster() {
        try {
            this.instrumentMaster = new Dictionary<string>();

            let _lstLoginAllowedVal;
            if (clsGlobal.User.loginAllowed > 0)
                _lstLoginAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.loginAllowed);//clsGlobal.User.loginAllowed.split('$');

            let _objLstintrument;

            //NSE
            _objLstintrument = '';
            let bIsLoginAllowed = false;
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSE_CASH.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSE_DERIVATIVES.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                // Added by Sakthi for FUTIVX changes
                if (clsGlobal.dConfigMaster.getItem("VERSION_IS_SP16B_DECODED") == clsConstants.C_S_OFF)
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }

            if (bIsLoginAllowed)
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_NSE_EXCHANGE_TEXT, _objLstintrument);

            //BSE
            _objLstintrument = '';
            bIsLoginAllowed = false;
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSE_CASH.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSE_DERIVATIVES.toString())) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (bIsLoginAllowed)
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_BSE_EXCHANGE_TEXT, _objLstintrument);

            //MCX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MCX_DERIVATIVES.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT + clsConstants.C_S_RECORD_DELIMITER;

                if (clsGlobal.dConfigMaster['INTEGRATED_MANAGER_B2'] == clsConstants.C_S_ON) {
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCSO_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT;
                }
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_MCX_EXCHANGE_TEXT, _objLstintrument);
            }

            //NCDEX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_NCDEX_EXCHANGE_TEXT, _objLstintrument);
            }

            //NSEL
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSEL_DERIVATIVES.toString()) != -1) {

                _objLstintrument += clsConstants.C_S_INSTRUMENT_NSELSPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                if (clsGlobal.dConfigMaster['INTEGRATED_MANAGER_B2'] == clsConstants.C_S_ON) {
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCSO_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                }
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_NSEL_EXCHANGE_TEXT, _objLstintrument);
            }

            //MCX SX
            _objLstintrument = '';
            bIsLoginAllowed = false;
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_CASH.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_FAO.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_MSX_DERIVATIVES.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRF_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                if (clsGlobal.dConfigMaster.getItem("MCXSX_FUTINT_ACTIVE") == clsConstants.C_S_ON)
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTINT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                if (clsGlobal.dConfigMaster.getItem("MCXSX_OPTCUR_ACTIVE") == clsConstants.C_S_ON)
                    _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_CUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                bIsLoginAllowed = true;
            }
            if (bIsLoginAllowed)
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_MSX_EXCHANGE_TEXT, _objLstintrument);

            //NSX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NSX_DERIVATIVES.toString()) != -1) {
                //NSECDS FUTURES
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRD_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRC_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;

                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_NSX_EXCHANGE_TEXT, _objLstintrument);
            }

            //BSECDX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) != -1) {
                //BSECDX FUTURES
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRD_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIRT_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;

                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_BSECDX_EXCHANGE_TEXT, _objLstintrument);
            }

            //NMCE
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_NMCE_DERIVATIVES.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_NMCE_EXCHANGE_TEXT, _objLstintrument);
            }

            //DSE
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_DSE_CASH.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_DSE_EXCHANGE_TEXT, _objLstintrument);
            }

            //BFX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_BFX_DERIVATIVES.toString()) != -1) {
                //NSECDS FUTURES
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                //NSECDS SPOT
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_BFX_EXCHANGE_TEXT, _objLstintrument);
            }

            //DGCX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_DGCX_DERIVATIVES.toString()) != -1) {
                //NSECDS FUTURES
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_DGCX_EXCHANGE_TEXT, _objLstintrument);
            }

            //UCX
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_UCX_DERIVATIVES.toString()) != -1) {
                //NSECDS FUTURES
                _objLstintrument += clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                _objLstintrument += clsConstants.C_S_INSTRUMENT_OPTCOM_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_UCX_EXCHANGE_TEXT, _objLstintrument);
            }

            //NSE-OTS
            _objLstintrument = '';
            if (_lstLoginAllowedVal.indexOf(clsConstants.C_V_OFS_IPO_BONDS.toString()) != -1) {
                _objLstintrument += clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                this.fn_AddDictionaryItem(this.instrumentMaster, clsConstants.C_S_OTSTXT_EXCHANGE_TEXT, _objLstintrument);
            }

        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'fillInstrumentMaster()', 'tr_ExchManager.js', '');

        }
    }

    fillOrderTypeMaster() {
        try {
            this.orderTypeMaster = new Dictionary<string>();

            this.orderTypeMaster.Add(clsConstants.C_V_NSE_CASH.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_CALLAUCTION_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_BSE_CASH.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_MSX_CASH.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_MSX_FAO.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_DSE_CASH.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_BSECDX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_UCX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));
            this.orderTypeMaster.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT));
            /**
           * USD : BT-12359
          * Date : 22/02/2020
          * Name : Nikhil Gawade
          * Description : condition added for ICEX Segment
         */
            this.orderTypeMaster.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), (clsConstants.C_S_ORDER_REGULARLOT_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_TEXT + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT));

        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'fillOrderTypeMaster()', 'tr_ExchManager.js', '');

        }
    }

    getExchangeIdforWebAdmin(netnetExchangeId) {
        let webAdminExchangeId = 0;

        if (netnetExchangeId == clsConstants.C_V_NSE_DERIVATIVES) { // for NSE FO = webadmin segmentid is  3
            webAdminExchangeId = 3;
        }
        else if (netnetExchangeId == clsConstants.C_V_BSE_CASH || netnetExchangeId == clsConstants.C_V_MSX_FIM) {// for BSE EQ/MCXSX CASH = webadmin segmentid is  2
            webAdminExchangeId = 2;
        }
        else if (netnetExchangeId == clsConstants.C_V_MCX_SPOT || netnetExchangeId == clsConstants.C_V_UCX_SPOT || netnetExchangeId == clsConstants.C_V_UCX_DERIVATIVES) {
            webAdminExchangeId = 5;
        }
        else if (netnetExchangeId == clsConstants.C_V_NCDEX_DERIVATIVES || netnetExchangeId == clsConstants.C_V_NCDEX_SPOT) {
            webAdminExchangeId = 6;
        }
        else if (netnetExchangeId == clsConstants.C_V_MSX_FAO || netnetExchangeId == clsConstants.C_V_MSX_SPOT
            || netnetExchangeId == clsConstants.C_V_NSX_SPOT || netnetExchangeId == clsConstants.C_V_NSX_DERIVATIVES
            || netnetExchangeId == clsConstants.C_V_BSECDX_SPOT || netnetExchangeId == clsConstants.C_V_BSECDX_DERIVATIVES) {
            webAdminExchangeId = 7;
        }
        else if (netnetExchangeId == clsConstants.C_V_MSX_CASH) {
            webAdminExchangeId = 9;
        }
        else if (netnetExchangeId == clsConstants.C_V_NMCE_DERIVATIVES) {
            webAdminExchangeId = 10;
        }
        else
            webAdminExchangeId = netnetExchangeId;

        return webAdminExchangeId;
    }

    fillProductMaster() {
        try {


            this.productTypeMaster = new Dictionary<string>();
            //alert(_selfEM.OEProductString);

            //clsGlobal.User.OEProductString = "1:MARGIN$DELIVERY;2:MARGIN$CARRYFORWARD:3:MARGIN$DELIVERY";
            if (clsGlobal.User.OEProductString.length > 0) {
                for (let index = 0; index < clsGlobal.User.OEProductString.length; index++) {
                    const element = clsGlobal.User.OEProductString[index];
                    let webAdminExchangeId = this.getExchangeIdforWebAdmin(clsTradingMethods.GetMarketSegmentID((element.nMarketSegmentId)));

                    let arrExchaProdType: any = clsGlobal.lstProductTypeSequnce.filter(prodType => {
                        return webAdminExchangeId.toString() == prodType.nExchangeId.toString();
                    });
                    let arrProdType = '';
                    if (arrExchaProdType != undefined && arrExchaProdType.length > 0) {
                        arrProdType = element.sProductType.split('$');
                        let strProductType = '';
                        for (let index = 0; index < arrExchaProdType.length; index++) {
                            const seqProductType = arrExchaProdType[index];
                            for (let index = 0; index < arrProdType.length; index++) {
                                const defProdType = arrProdType[index];
                                if (defProdType.startsWith(seqProductType.sDefaultProductType) && (!defProdType.startsWith(clsConstants.C_S_PRODUCTTYPE_MP_TEXT))) {
                                    strProductType += seqProductType.sProductType + clsConstants.C_S_RECORD_DELIMITER;
                                    break;
                                }
                            }
                        }
                        if (arrProdType.indexOf(clsConstants.C_S_PRODUCTTYPE_MP_TEXT) != -1) {
                            strProductType += clsConstants.C_S_PRODUCTTYPE_MP_TEXT + clsConstants.C_S_RECORD_DELIMITER;
                        }

                        if (arrProdType.indexOf(clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) != -1) {
                            strProductType += clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT + clsConstants.C_S_RECORD_DELIMITER;
                        }

                        strProductType = strProductType.substr(0, strProductType.length - 1);
                        arrProdType = strProductType;
                    }
                    else {
                        arrProdType = element.sProductType;
                    }

                    this.productTypeMaster.Add(clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId), arrProdType);
                }
            }
            /*
            let arrTempData = clsGlobal.User.OEProductString.split(';');
            for (let j = 0; j < arrTempData.length; j++) {
                let arrSplitData = arrTempData[j].split(':');
                // Here key will be segment Id and value will be the string of Validities for the segment
                this.productTypeMaster.Add(arrSplitData[0], arrSplitData[1]);
            }
            */
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillProductMaster()', 'tr_ExchManager.js', '');

        }
    }

    fillProductTypeNewMaster() {
        try {


            this.productTypeMaster = new Dictionary<string>();
            if (clsGlobal.User.OEProductString.length > 0) {
                for (let index = 0; index < clsGlobal.User.exchangesList.length; index++) {
                    const exchange = clsGlobal.User.exchangesList[index];
                    let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(exchange)
                    let strProdTypes = '';
                    for (let index = 0; index < clsGlobal.User.OEProductString.length; index++) {
                        const prod_type = clsGlobal.User.OEProductString[index];
                        if (mktSegId == clsConstants.C_V_NSE_CASH ||
                            mktSegId == clsConstants.C_V_BSE_CASH ||
                            mktSegId == clsConstants.C_V_MSX_CASH) {
                            if (prod_type != clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT) {
                                strProdTypes += prod_type + '$';
                            }
                        } else {
                            if (prod_type != clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT &&
                                prod_type != clsConstants.C_S_PRODUCTTYPE_SIP_TXT) {
                                strProdTypes += prod_type + '$';
                            }
                            if (prod_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                                strProdTypes += clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT + '$';
                            }
                        }
                    }

                    strProdTypes = strProdTypes.substr(0, strProdTypes.length - 1);

                    //Temp added need to remove once dev completed, for testing purpose
                    //strProdTypes = strProdTypes+ "$" + clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT; 
                    this.productTypeMaster.Add(mktSegId, strProdTypes);


                }
            }
            //clsGlobal.User.OEProductString = "1:MARGIN$DELIVERY;2:MARGIN$CARRYFORWARD:3:MARGIN$DELIVERY";

        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillProductMaster()', 'tr_ExchManager.js', '');

        }
    }


    fillValidityMaster() {
        try {
            this.validityMaster = new Dictionary<string>();

            this.validityMaster.Add(clsConstants.C_V_NSE_CASH.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD));
            this.validityMaster.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_BSE_CASH.toString(), (clsConstants.C_S_VALUE_EOSESS + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOTODY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD));
            this.validityMaster.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS));
            /**
            * USD : BT-12359
           * Date : 22/02/2020
           * Name : Rajendra Sirvi
           * Description : condition added for ICEX Segment
          */
            this.validityMaster.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));


            this.validityMaster.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            this.validityMaster.Add(clsConstants.C_V_MSX_CASH.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS));
            this.validityMaster.Add(clsConstants.C_V_MSX_FAO.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_ORDER_FOK));
            this.validityMaster.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            this.validityMaster.Add(clsConstants.C_V_DSE_CASH.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_EOS + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            this.validityMaster.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_BSECDX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC));
            this.validityMaster.Add(clsConstants.C_V_UCX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            if (clsGlobal.dConfigMaster.getItem("DGCX_CINNOBAR") == clsConstants.C_S_OFF)
                this.validityMaster.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            else
                this.validityMaster.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTT));

            this.validityMaster.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), (clsConstants.C_S_VALUE_DAY + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_IOC + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTD + clsConstants.C_S_RECORD_DELIMITER + clsConstants.C_S_VALUE_GTC));
            this.validityMaster.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), (clsConstants.C_S_VALUE_DAY));
        }
        catch (e) {


        }
    }

    fillLoginExchangeAllowedDictionary(_lstAllowedVal, _strExchLoginKey) {
        try {
            let _dcAllowed: IKeyedCollection<string> = new Dictionary<string>();
            if (_lstAllowedVal.indexOf(clsConstants.C_V_NSE_CASH.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_NSE_CASH.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_NSE_CASH.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_NSE_DERIVATIVES.toString()) != -1) {
                _dcAllowed.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), clsConstants.C_S_ON);
            }
            else
                _dcAllowed.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_BSE_CASH.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_BSE_CASH.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_BSE_CASH.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_BSE_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_BSE_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_MCX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_MCX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_NCDEX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_NSEL_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_NSEL_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_MSX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_MSX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_MSX_CASH.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_MSX_CASH.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_MSX_CASH.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_MSX_FAO.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_MSX_FAO.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_MSX_FAO.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_NMCE_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_NMCE_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_NSX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_NSX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_BSECDX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_BSECDX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_DSE_CASH.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_DSE_CASH.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_DSE_CASH.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_UCX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_UCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_UCX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_DGCX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_DGCX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

            if (_lstAllowedVal.indexOf(clsConstants.C_V_BFX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_BFX_DERIVATIVES.toString(), clsConstants.C_S_OFF);
            //NSE-OTS
            if (_lstAllowedVal.indexOf(clsConstants.C_V_OFS_IPO_BONDS.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_OFS_IPO_BONDS.toString(), clsConstants.C_S_OFF);

            if (_strExchLoginKey == clsConstants.C_S_TAG_EXCHANGEALLOWED)
                this.exchangeAllowed = _dcAllowed;
            else if (_strExchLoginKey == clsConstants.C_S_TAG_LOGINALLOWED)
                this.loginAllowed = _dcAllowed;
            else if (_strExchLoginKey == clsConstants.C_V_TAG_MARGINPLUSALLOWED.toString())
                this.marginPlusAllowed = _dcAllowed;

            /**
  * USD : BT-12359
 * Date : 22/02/2020
 * Name : Rajendra Sirvi
 * Description : condition added for ICEX Segment
*/
            if (_lstAllowedVal.indexOf(clsConstants.C_V_ICEX_DERIVATIVES.toString()) != -1)
                _dcAllowed.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), clsConstants.C_S_ON);
            else
                _dcAllowed.Add(clsConstants.C_V_ICEX_DERIVATIVES.toString(), clsConstants.C_S_OFF);

        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillValidityMaster()', 'tr_ExchManager.js', '');

        }
    }

    //Fill Order Entry object to be published via Pub Sub
    fillOrderRequest(_dcOrderDetails: Dictionary<string>) {
        try {
            //Get Order Type
            let _iOrderType = this.getOrderType(_dcOrderDetails.getItem("SelOrderTypes"), _dcOrderDetails.getItem("SelPrice"), _dcOrderDetails.getItem("SelInstrument"), _dcOrderDetails.getItem("SelProduct"), _dcOrderDetails.getItem("SelMPMFFlag"), _dcOrderDetails.getItem("IsSpread"));

            //Get ValidityValue
            let _iValidity = this.getValidityValue(_dcOrderDetails.getItem("SelValidity"));

            //Get Mkt Status
            let _sMarketStatus = _dcOrderDetails.getItem("MarketStatus");  //this.getMktStatus(_dcOrderDetails.getItem("MarketSegmentId"));

            //Added for mobile case when market status is not called and orders are sent 001-00-486696 it does not capture AMO type
            if (_sMarketStatus == '-' && clsGlobal.applicationType == clsGlobal.MOBILE) {
                //fn_MarketStatusController('', '', true);
                _sMarketStatus = _dcOrderDetails.getItem("MarketStatus");
            }

            // if (_dcOrderDetails.getItem("AMO") == "true") {
            //     //Case when AMO is ticked
            // }
            // else {
            //     //Case when AMO is unticked
            //     _sMarketStatus = "Open";
            // }

            // get product type value accepted by OdinConnect
            let _sProductType = this.getProductTypeValue(_dcOrderDetails.getItem("SelProduct"), _sMarketStatus, _dcOrderDetails.getItem("MarketSegmentId"));

            //Calculate disc qty in relation with Quantity
            let _iCalcDiscQty = this.calculateDiscQty(_dcOrderDetails.getItem("SelQty"), _dcOrderDetails.getItem("SelDiscQty"), _dcOrderDetails.getItem("SelValidity"), _dcOrderDetails.getItem("MarketSegmentId"), _dcOrderDetails.getItem("SelInstrument"));

            let _sParticipantData = this.fillParticipantId(_dcOrderDetails.getItem("ModifyFlag"), _dcOrderDetails.getItem("MarketSegmentId"), _dcOrderDetails.getItem("ParticipantID"));
            let _Temparr = _sParticipantData.split('|');

            // Update Client Order No
            let _iClientOrdNo: any;
            if (_dcOrderDetails.getItem("GatewayOrderNo") == "") {
                _iClientOrdNo = clsGlobal.User.clientOrderNumber + 1;
                clsGlobal.User.clientOrderNumber = parseInt(_iClientOrdNo);
            }
            else {
                _iClientOrdNo = _dcOrderDetails.getItem("ClientOrderNumber");
            }

            let MPDPRFlag: any = _dcOrderDetails.getItem("MPDPRFlag") === undefined ? '' : _dcOrderDetails.getItem("MPDPRFlag");
            let MPBasePrice = _dcOrderDetails.getItem("MPBasePrice") === undefined ? '' : _dcOrderDetails.getItem("MPBasePrice");
            let MPExpiryValue = _dcOrderDetails.getItem("MPExpiryValue") === undefined ? '' : _dcOrderDetails.getItem("MPExpiryValue");
            let MPStrikePriceValue = _dcOrderDetails.getItem("MPStrikePriceValue") === undefined ? '' : _dcOrderDetails.getItem("MPStrikePriceValue");
            let MPActualLowPr = _dcOrderDetails.getItem("MPActualLowPr") === undefined ? '' : _dcOrderDetails.getItem("MPActualLowPr");
            let MPActualHighPr = _dcOrderDetails.getItem("MPActualHighPr") === undefined ? '' : _dcOrderDetails.getItem("MPActualHighPr");
            let MPLTP: any = _dcOrderDetails.getItem("MPLTP") === undefined ? '' : _dcOrderDetails.getItem("MPLTP");
            let MPLowPr: any = _dcOrderDetails.getItem("MPLowPr") === undefined ? '' : _dcOrderDetails.getItem("MPLowPr");
            let MPHighPr: any = _dcOrderDetails.getItem("MPHighPr") === undefined ? '' : _dcOrderDetails.getItem("MPHighPr");
            let MPClosePrice: any = _dcOrderDetails.getItem("MPClosePrice") === undefined ? '' : _dcOrderDetails.getItem("MPClosePrice");
            //let MPOrderType = _dcOrderDetails.getItem("MPOrderType") == undefined ? '' : _dcOrderDetails.getItem("MPOrderType");
            //let MPPrice: any = _dcOrderDetails.getItem("MPPrice") == undefined ? '' : _dcOrderDetails.getItem("MPPrice");
            //let MPTriggerPrice: any = _dcOrderDetails.getItem("MPTriggerPrice") == undefined ? '' : _dcOrderDetails.getItem("MPTriggerPrice");
            let BuyPrice: any = _dcOrderDetails.getItem("BuyPrice") === undefined ? '' : _dcOrderDetails.getItem("BuyPrice");
            let SellPrice: any = _dcOrderDetails.getItem("SellPrice") === undefined ? '' : _dcOrderDetails.getItem("SellPrice");

            let objOE = new clsOrderEntryRequest();

            objOE.OrderSide = _dcOrderDetails.getItem("SelOperation");
            objOE.Exchange = _dcOrderDetails.getItem("SelExchange");
            objOE.Instrument = _dcOrderDetails.getItem("SelInstrument");
            objOE.Symbol = _dcOrderDetails.getItem("SelSymbol");
            if (_dcOrderDetails.getItem("SelSeries") != undefined)
                objOE.Series = _dcOrderDetails.getItem("SelSeries");
            if (_dcOrderDetails.getItem("SelExpire") != undefined)
                objOE.ExpDate = _dcOrderDetails.getItem("SelExpire");
            if (_dcOrderDetails.getItem("SelStrikePrice") != undefined)
                objOE.StrikePrice = _dcOrderDetails.getItem("SelStrikePrice");
            if (_dcOrderDetails.getItem("SelOptionType") != undefined)
                objOE.OptionType = _dcOrderDetails.getItem("SelOptionType");
            if (_dcOrderDetails.getItem("SelOrderTypes") != undefined)
                objOE.OrderType = _iOrderType;
            if (_dcOrderDetails.getItem("SelQty") != undefined)
                objOE.Qty = _dcOrderDetails.getItem("SelQty");
            if (_dcOrderDetails.getItem("SelPrice") != undefined)
                objOE.Price = _dcOrderDetails.getItem("SelPrice");
            //Ticket 001-00-514292
            if (objOE.Price.length == 0)//means price is coming blank from FE
                objOE.Price = 0;
            if (_dcOrderDetails.getItem("SelDiscQty") != undefined)
                objOE.DiscQty = _iCalcDiscQty;
            if (_dcOrderDetails.getItem("SelTriggerPrice") != undefined)
                objOE.TriggerPrice = _dcOrderDetails.getItem("SelTriggerPrice");
            if (_dcOrderDetails.getItem("SelProduct") != undefined)
                objOE.ProductType = _sProductType;
            if (_dcOrderDetails.getItem("SelValidity") != undefined)
                objOE.Validity = _iValidity;
            if (_dcOrderDetails.getItem("SelDay") != undefined)
                objOE.Days = _dcOrderDetails.getItem("SelDay");
            if (_dcOrderDetails.getItem("SelProdPer") != undefined)
                objOE.ProtPerc = _dcOrderDetails.getItem("SelProdPer");

            objOE.DecimalLocator = _dcOrderDetails.getItem("SelDecimalloc");
            //objOE.InstrumentID = _dcOrderDetails.getItem("");
            objOE.MapMktSegID = _dcOrderDetails.getItem("MapMarketSegmentId");
            objOE.MarketSegID = _dcOrderDetails.getItem("MarketSegmentId");
            objOE.ClientOrderNumber = _iClientOrdNo;
            objOE.MarketLot = _dcOrderDetails.getItem("SelMarketLot");
            objOE.PriceTick = _dcOrderDetails.getItem("SelPriceTick");
            objOE.TokenNo = _dcOrderDetails.getItem("SelToken");
            objOE.AMOID = _dcOrderDetails.getItem("AMOID");
            objOE.ExchangeOrderNo = _dcOrderDetails.getItem("ExchangeOrderNo");
            objOE.GatewayOrderNo = _dcOrderDetails.getItem("GatewayOrderNo");
            objOE.MapMktSegID = _dcOrderDetails.getItem("MapMarketSegmentId");

            objOE.ModifyFlag = _dcOrderDetails.getItem("ModifyFlag");
            if (_dcOrderDetails.getItem("CancelFlag") != undefined)
                objOE.CancelFlag = _dcOrderDetails.getItem("CancelFlag");
            objOE.FIILimit = _dcOrderDetails.getItem("FIILimit");
            objOE.NRILimit = _dcOrderDetails.getItem("NRILimit");
            objOE.OrderTime = _dcOrderDetails.getItem("OrderTime");
            if (_Temparr.length > 0) {
                objOE.ParticipantID = _Temparr[1];
                objOE.ParticipantIDTag = _Temparr[0];
            }
            else {
                objOE.ParticipantID = '';
                objOE.ParticipantIDTag = clsConstants.C_V_TAG_PARTICIPANTID.toString();
            }

            objOE.SPOSType = _dcOrderDetails.getItem("SPOS");

            // Setting the COL value
            let bCOL: any = false;
            if (objOE.Validity == clsConstants.C_V_ORDER_VALID_TILL_DAY.toString()) {
                // COL value to be checked only in case of DAY Validity
                bCOL = _dcOrderDetails.getItem("SelCOL");
            }
            objOE.COL = this.getCOLValue(bCOL);

            if (_sProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE || _sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
                if (_sProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE) {
                    objOE.OrderType = this.getOrderType(_dcOrderDetails.getItem("MPOrderType"), _dcOrderDetails.getItem("MPPrice"), _dcOrderDetails.getItem("SelInstrument"), _dcOrderDetails.getItem("SelProduct"), _dcOrderDetails.getItem("SelMPMFFlag"), _dcOrderDetails.getItem("IsSpread"));
                    //mapping the margin plus price/trigger price to normal price/trigger price
                    if (_dcOrderDetails.getItem("MPPrice") != '')
                        objOE.Price = _dcOrderDetails.getItem("MPPrice");

                    if (_dcOrderDetails.getItem("MPTriggerPrice") != '')
                        objOE.TriggerPrice = _dcOrderDetails.getItem("MPTriggerPrice");
                }

                var dblProtPercforBracket;
                if (_sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
                    dblProtPercforBracket = objOE.ProtPerc;
                    /*         change By shiv:CR3838
                    if (dblProtPercforBracket == '' || dblProtPercforBracket == 'undefined') //if not passed from OE then take from Pref
                        dblProtPercforBracket = clsGlobal.User.OrderPrefDic[objOE.MarketSegID].nProtPerc;*/
                    // if (dblProtPercforBracket == null || dblProtPercforBracket == 'undefined') //if not defined in pref then take default value
                    //     dblProtPercforBracket = clsGlobal.User.OrderPrefDic[objOE.MarketSegID].nDefaultProtPerc;

                    objOE.SLOrderType = this.getOrderType(_dcOrderDetails.getItem("MPOrderType"), _dcOrderDetails.getItem("MPPrice"), _dcOrderDetails.getItem("SelInstrument"), _dcOrderDetails.getItem("SelProduct"), _dcOrderDetails.getItem("SelMPMFFlag"), _dcOrderDetails.getItem("IsSpread"));

                    //mapping the margin plus price/trigger price to SL Price/trigger price
                    if (_dcOrderDetails.getItem("SLOrderPrice") != '')
                        objOE.SLOrderPrice = _dcOrderDetails.getItem("SLOrderPrice");

                    if (_dcOrderDetails.getItem("SLTriggerPrice") != '')
                        objOE.SLTriggerPrice = _dcOrderDetails.getItem("SLTriggerPrice");

                    if (_dcOrderDetails.getItem("ProfitOrderPrice") != undefined)
                        objOE.ProfitOrderPrice = _dcOrderDetails.getItem("ProfitOrderPrice");

                    if (_dcOrderDetails.getItem("TrailingSL") != undefined)
                        objOE.TrailingSL = _dcOrderDetails.getItem("TrailingSL");

                    if (_dcOrderDetails.getItem("SLJumpPrice") != undefined)
                        objOE.SLJumpPrice = _dcOrderDetails.getItem("SLJumpPrice");

                    if (_dcOrderDetails.getItem("LTPJumpPrice") != undefined)
                        objOE.LTPJumpPrice = _dcOrderDetails.getItem("LTPJumpPrice");

                    if (_dcOrderDetails.getItem("BracketOrderId") != undefined)
                        objOE.BracketOrderId = _dcOrderDetails.getItem("BracketOrderId");

                    if (_dcOrderDetails.getItem("LegIndicator") != undefined)
                        objOE.LegIndicator = _dcOrderDetails.getItem("LegIndicator");

                    if (_dcOrderDetails.getItem("BOGatewayOrderNo") != undefined)
                        objOE.BOGatewayOrderNo = _dcOrderDetails.getItem("BOGatewayOrderNo");

                    if (_dcOrderDetails.getItem("BOModifyTerms") != undefined)
                        objOE.BOModifyTerms = _dcOrderDetails.getItem("BOModifyTerms");

                    if (objOE.SLOrderPrice == 0) //SL Price is blank then send LimitPriceLowRange in it
                    {
                        //                        if (objOE.OrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                        //                            objOE.SLOrderPrice = _dcOrderDetails.getItem("MPLimitPriceLowRange");
                        //                        else
                        //                            objOE.SLOrderPrice = _dcOrderDetails.getItem("MPLimitPriceHighRange");
                        objOE.SLOrderPrice = this.deriveSLOrdPriceforBracketMarketOrder(objOE.OrderSide, objOE.SLTriggerPrice, _dcOrderDetails.getItem("MPLimitPriceLowRange"), _dcOrderDetails.getItem("MPLimitPriceHighRange"), objOE.PriceTick, objOE.DecimalLocator, dblProtPercforBracket, MPLowPr, MPHighPr);
                    }

                    if (objOE.CancelFlag) //send as mkt to calculate price
                    {
                        //square off order side will be opposite of main leg
                        let SqOfforderSide = objOE.OrderSide == clsConstants.C_S_ORDER_BUY_TEXT ? clsConstants.C_S_ORDER_SELL_TEXT : clsConstants.C_S_ORDER_BUY_TEXT;
                        objOE.MPBasePrice = this.derivePriceforMarketOrder(SqOfforderSide, clsConstants.C_V_ORDER_REGULARLOT_MARKET, objOE.TriggerPrice, objOE.PriceTick, objOE.DecimalLocator, dblProtPercforBracket, BuyPrice, SellPrice, MPLTP, MPClosePrice, MPLowPr, MPHighPr);
                    }
                }

                if (_sProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE) {

                    if (MPDPRFlag == 2)
                        objOE.MPBasePrice = MPBasePrice;
                    else
                        objOE.MPBasePrice = "0";

                    if (MPExpiryValue.length != 0)
                        objOE.MPExpiryValue = MPExpiryValue;
                    else
                        objOE.MPExpiryValue = "-1";

                    if (MPStrikePriceValue.length != 0)
                        objOE.MPStrikePriceValue = MPStrikePriceValue;
                    else
                        objOE.MPStrikePriceValue = "-1";

                    if (objOE.Price == 0 || objOE.Price == null) {
                        /* If Price filled is 0 by user, then internally fill ActualLowPrice for BUY side and
                        * ActualHighPrice for SELL side order.
                        * Also set MPMFFlag to 1 if this conversion is being made  */
                        if (!objOE.ModifyFlag) {
                            if (objOE.OrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                                objOE.Price = MPActualLowPr;
                            else
                                objOE.Price = MPActualHighPr;
                        }
                        // Case for Mdofication order (above calculation is reversed)
                        else {
                            if (objOE.OrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                                objOE.Price = MPActualHighPr;  //High
                            else
                                objOE.Price = MPActualLowPr; //Low
                        }
                        objOE.MPMFFlag = "1";
                    }
                    else {
                        objOE.Price = objOE.Price;
                        objOE.MPMFFlag = "0";
                    }

                    // To fill final Leg Price
                    if (objOE.Exchange === clsConstants.C_S_NMCE_EXCHANGE_TEXT) {
                        let dblProtPerc = parseFloat(clsGlobal.dConfigMaster.getItem("MARGINPLUS_PROTPERC")) / 100;
                        let dblBuyFirstLegPrice = MPLTP + (MPLTP * dblProtPerc);
                        let dblSellFirstLegPrice = MPLTP - (MPLTP * dblProtPerc);

                        if (objOE.OrderSide === clsConstants.C_S_ORDER_BUY_TEXT) {
                            if ((dblBuyFirstLegPrice < MPLowPr || dblBuyFirstLegPrice > MPHighPr))
                                objOE.MPFirstLegPrice = MPHighPr;
                            else
                                objOE.MPFirstLegPrice = dblBuyFirstLegPrice;
                        }
                        else {
                            if ((dblSellFirstLegPrice < MPLowPr || dblSellFirstLegPrice > MPHighPr))
                                objOE.MPFirstLegPrice = MPLowPr;
                            else
                                objOE.MPFirstLegPrice = dblSellFirstLegPrice;
                        }
                    }
                    else {
                        if (MPLTP != 0)
                            objOE.MPFirstLegPrice = MPLTP;
                        else if (MPClosePrice != 0)
                            objOE.MPFirstLegPrice = MPClosePrice;
                        else
                            objOE.MPFirstLegPrice = 0;
                    }
                }
            }

            // CR 3327
            if (objOE.Exchange == clsConstants.C_S_OTSTXT_EXCHANGE_TEXT) {
                if (_dcOrderDetails.getItem("ChkCutOff") == "true" && parseInt(_dcOrderDetails.getItem("IsCutOffAllowed")) == 1 && _dcOrderDetails.getItem("hasCutOff") == "true") {
                    // Check whether LCP or Set Price is set at admin level
                    if (parseInt(_dcOrderDetails.getItem("IsSetPrice")) == 1) {
                        objOE.Price = parseFloat(_dcOrderDetails.getItem("SetPrice"));
                    }
                }

                // Web Institutional clients
                if (clsGlobal.User.OdinCategory == 5 || clsGlobal.User.nseDervParticipantID.length > 0) {
                    if (_dcOrderDetails.getItem("SelMargin") == clsConstants.C_S_FULL_MARGIN) {
                        objOE.SelMargin = "0";
                    }
                    else
                        objOE.SelMargin = "1";
                }
            }

            if (parseFloat(objOE.Price) == 0 && objOE.Exchange != clsConstants.C_S_OTSTXT_EXCHANGE_TEXT) //derive price for market order
            {
                if (_sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE)
                    objOE.Price = this.derivePriceforBracketMarketOrder(objOE.OrderSide, MPLTP, objOE.ProfitOrderPrice, objOE.PriceTick, objOE.DecimalLocator, dblProtPercforBracket, MPLowPr, MPHighPr);
                else
                    objOE.Price = this.derivePriceforMarketOrder(objOE.OrderSide, objOE.OrderType, objOE.TriggerPrice, objOE.PriceTick, objOE.DecimalLocator, objOE.ProtPerc, BuyPrice, SellPrice, MPLTP, MPClosePrice, MPLowPr, MPHighPr);
            }

            //CR 3725
            objOE.RecoId = _dcOrderDetails.getItem("RecoId");
            //objOE.LastPendingQty = _dcOrderDetails.getItem("LastPendingQty");
            //objOE.LastTradedQty = _dcOrderDetails.getItem("LastTradedQty");

            return objOE;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillOrderRequest()', 'tr_ExchManager.js', '');

        }
    }

    //this function derive price to sent to OC for Market Order
    derivePriceforMarketOrder(_strOrderSide, _strOrderType, _strTriggerPrice, _PriceTick, _DecimalLocator, _ProtPerc, _strBuyPrice, _strSellPrice, _strLTPPrice, _strClosePrice, _strLowPrice, _strHighPrice) {
        let strPrice: any = 0;
        try {
            let dblPriceTick = parseFloat(_PriceTick) / _DecimalLocator;
            if (_strOrderType == clsConstants.C_V_ORDER_REGULARLOT_MARKET) {

                let dblPrice1 = Math.max(parseFloat(_strSellPrice), parseFloat(_strLTPPrice));
                let dblPrice2 = Math.max(dblPrice1, parseFloat(_strBuyPrice));
                strPrice = dblPrice2;

                if (strPrice <= 0)
                    strPrice = _strClosePrice;
            }
            else if (_strOrderType == clsConstants.C_V_ORDER_STOPLOSS_MARKET)
                strPrice = _strTriggerPrice;

            if (_strOrderType == clsConstants.C_V_ORDER_REGULARLOT_MARKET) {
                //(convert from percent to value(100))
                let _dblProtPerc: any = 0;
                if (_ProtPerc == '' || _ProtPerc == undefined)
                    _dblProtPerc = 0;
                else
                    _dblProtPerc = parseFloat(_ProtPerc);

                let nFinalPrice;
                if (_strOrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                    nFinalPrice = parseFloat(strPrice) * (1 + (parseFloat(_dblProtPerc) / 100));
                else
                    nFinalPrice = parseFloat(strPrice) * (1 - (parseFloat(_dblProtPerc) / 100));

                //roundoff to nearest tick
                nFinalPrice = clsTradingMethods.roundNearestPriceTick(nFinalPrice, dblPriceTick);

                let nDPRLow = parseFloat(_strLowPrice);
                let nDPRHigh = parseFloat(_strHighPrice);
                if (nFinalPrice > nDPRHigh && nDPRHigh > 0)
                    nFinalPrice = nDPRHigh;
                else if (nFinalPrice < nDPRLow && nDPRLow > 0)
                    nFinalPrice = nDPRLow;

                strPrice = nFinalPrice;
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'DerivePriceforMarketOrder()', 'tr_ExchManager.js', '');

        }
        return strPrice;
    }

    //this function derive price to sent to OC for Market Order
    derivePriceforBracketMarketOrder(_strOrderSide, _strLTPPrice, _strProfitPrice, _PriceTick, _DecimalLocator, _ProtPerc, _strLowPrice, _strHighPrice) {
        let strPrice = 0;
        let dblProtPerc: any = 0;
        try {
            //(convert from percent to value(100))
            if (_ProtPerc == "") { dblProtPerc = 0; }
            else {
                dblProtPerc = parseFloat(_ProtPerc);
            }
            let dblPriceTick = parseFloat(_PriceTick) / _DecimalLocator;

            let nFinalPrice;
            if (_strOrderSide == clsConstants.C_S_ORDER_BUY_TEXT) { //[Min (LTP+ Protection%*LTP, Profit Order Price-1 Tick)]
                nFinalPrice = parseFloat(_strLTPPrice) * (1 + (parseFloat(dblProtPerc) / 100));
                nFinalPrice = Math.min(nFinalPrice, (_strProfitPrice - dblPriceTick));
            }
            else { //[Max (LTP-Protection%*LTP, Profit Order Price + 1 Tick]
                nFinalPrice = parseFloat(_strLTPPrice) * (1 - (parseFloat(dblProtPerc) / 100));
                nFinalPrice = Math.max(nFinalPrice, (_strProfitPrice + dblPriceTick));
            }

            //roundoff to nearest tick
            nFinalPrice = clsTradingMethods.roundNearestPriceTick(nFinalPrice, dblPriceTick);

            let nDPRLow = parseFloat(_strLowPrice);
            let nDPRHigh = parseFloat(_strHighPrice);
            if (nFinalPrice > nDPRHigh && nDPRHigh > 0)
                nFinalPrice = nDPRHigh;
            else if (nFinalPrice < nDPRLow && nDPRLow > 0)
                nFinalPrice = nDPRLow;

            strPrice = nFinalPrice;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'DerivePriceforBracketMarketOrder()', 'tr_ExchManager.js', '');

        }
        return strPrice;
    }

    //this function derive price to sent to OC for Market Order
    deriveSLOrdPriceforBracketMarketOrder(_strOrderSide, _strTriggerPrice, _MPLimitPriceLowRange, _MPLimitPriceHighRange, _PriceTick, _DecimalLocator, _ProtPerc, _strLowPrice, _strHighPrice) {
        let strPrice = 0;
        try {
            //(convert from percent to value(100))
            let dblProtPerc: any = parseFloat(_ProtPerc);
            let dblPriceTick = parseFloat(_PriceTick) / _DecimalLocator;

            //Bracket Stoploss order leg will be opposite of main leg hence flip
            if (_strOrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                _strOrderSide = clsConstants.C_S_ORDER_SELL_TEXT;
            else
                _strOrderSide = clsConstants.C_S_ORDER_BUY_TEXT;

            let nFinalPrice;
            if (dblProtPerc > 0) {
                if (_strOrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                    nFinalPrice = parseFloat(_strTriggerPrice) * (1 + (parseFloat(dblProtPerc) / 100));
                }
                else
                    nFinalPrice = parseFloat(_strTriggerPrice) * (1 - (parseFloat(dblProtPerc) / 100));
                //roundoff to nearest tick
                nFinalPrice = clsTradingMethods.roundNearestPriceTick(nFinalPrice, dblPriceTick);

                //if price not in LPR range then nearest of LPR Max or LPR Min is sent
                if (nFinalPrice < parseFloat(_MPLimitPriceLowRange) || nFinalPrice > parseFloat(_MPLimitPriceHighRange)) {
                    let diffLPRMin = Math.abs(nFinalPrice - parseFloat(_MPLimitPriceLowRange));
                    let diffLPRMax = Math.abs(nFinalPrice - parseFloat(_MPLimitPriceHighRange));
                    nFinalPrice = (diffLPRMin > diffLPRMax) ? parseFloat(_MPLimitPriceHighRange) : parseFloat(_MPLimitPriceLowRange);
                }
            }
            else { //CR 3838 Changes required in Bracket Order for Stop Loss Market Order without protection percentage
                if (_strOrderSide == clsConstants.C_S_ORDER_BUY_TEXT)
                    nFinalPrice = parseFloat(_MPLimitPriceHighRange)
                else
                    nFinalPrice = parseFloat(_MPLimitPriceLowRange)
            }
            strPrice = nFinalPrice;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'DeriveSLOrdPriceforBracketMarketOrder()', 'tr_ExchManager.js', '');

        }
        return strPrice;
    }

    /// <summary>
    /// converts order type into gateway acceptable value. It basically differentiates
    /// if the order is a limit order or a market order
    /// </summary>
    getOrderType(_orderType, _dblprice, _strInstrumentName, _strProductType, _strMPMFFlag, _bIsSpread) {

        let _intOrderType: any = 0;
        try {
            switch (_orderType) {
                case clsConstants.C_S_ORDER_REGULARLOT_TEXT:
                case clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT:
                    if (_strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || _strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || _strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || _strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT) {
                        if (_strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT)
                            _intOrderType = clsConstants.C_V_AUCBI_ORDERTYPE;
                        else if (_strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT)
                            _intOrderType = clsConstants.C_V_AUCSO_ORDERTYPE;
                        else if (_strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT)
                            _intOrderType = clsConstants.C_V_AUCTBI_ORDERTYPE;
                        else if (_strInstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)
                            _intOrderType = clsConstants.C_V_AUCTSI_ORDERTYPE;
                    }
                    else {
                        if (_dblprice == 0 && _bIsSpread == "0")  // Boolean will be false for normal orders
                            _intOrderType = clsConstants.C_V_ORDER_REGULARLOT_MARKET;
                        else {
                            // For Spread Order
                            if (_bIsSpread == "1") {
                                // If price field is kept blank
                                if (isNaN(_dblprice))
                                    _intOrderType = clsConstants.C_V_ORDER_REGULARLOT_MARKET;
                                else
                                    _intOrderType = clsConstants.C_V_ORDER_REGULARLOT;
                            }
                            // For normal cases (without Spread)
                            else
                                if (isNaN(_dblprice) || _orderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
                                    _intOrderType = clsConstants.C_V_ORDER_REGULARLOT_MARKET;
                                else
                                    _intOrderType = clsConstants.C_V_ORDER_REGULARLOT;
                        }
                    }
                    break;
                case clsConstants.C_S_ORDER_STOPLOSS_TEXT:
                case clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT:
                    if (_bIsSpread == "0") {
                        if (_dblprice == 0)
                            _intOrderType = clsConstants.C_V_ORDER_STOPLOSS_MARKET;
                        else {
                            if ((_strProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT && _strMPMFFlag == "1") || _orderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)
                                _intOrderType = clsConstants.C_V_ORDER_STOPLOSS_MARKET;
                            else
                                _intOrderType = clsConstants.C_V_ORDER_STOPLOSS;
                        }
                    }
                    else if (_bIsSpread == "1") {
                        if (isNaN(_dblprice) || _orderType == clsConstants.C_V_ORDER_STOPLOSS_MARKET)
                            _intOrderType = clsConstants.C_V_ORDER_STOPLOSS_MARKET;
                        else
                            _intOrderType = clsConstants.C_V_ORDER_STOPLOSS;
                    }
                    break;
                case clsConstants.C_S_ORDER_CALLAUCTION_TEXT:
                    _intOrderType = clsConstants.C_V_ORDER_CALLAUCTION;
                    break;
            }
        }
        catch (e) {


        }
        return _intOrderType;
    }

    /// <summary>
    /// converts validity into gateway acceptible value 
    /// </summary>
    getValidityValue(_validity) {
        let _intValidity = 0;
        try {
            switch (_validity) {
                case clsConstants.C_S_VALUE_DAY:
                    _intValidity = clsConstants.C_V_ORDER_VALID_TILL_DAY;
                    break;
                case clsConstants.C_S_VALUE_IOC:
                    _intValidity = clsConstants.C_V_ORDER_IOC;
                    break;
                case clsConstants.C_S_VALUE_GTD:
                    _intValidity = clsConstants.C_V_ORDER_GTD;
                    break;
                case clsConstants.C_S_VALUE_GTC:
                    _intValidity = clsConstants.C_V_ORDER_GTC;
                    break;
                case clsConstants.C_S_VALUE_EOSESS:
                    _intValidity = clsConstants.C_V_ORDER_EOSESS;
                    break;
                case clsConstants.C_S_VALUE_EOTODY:
                    _intValidity = clsConstants.C_V_ORDER_EOTODY;
                    break;
                case clsConstants.C_S_VALUE_EOSTLM:
                    _intValidity = clsConstants.C_V_ORDER_EOSTLM;
                    break;
                case clsConstants.C_S_VALUE_EOS:
                    _intValidity = clsConstants.C_V_ORDER_EOS;
                    break;
                case clsConstants.C_S_ORDER_FOK:
                case "FILLORKILL":
                    _intValidity = clsConstants.C_V_ORDER_FOK;
                    break;
                case clsConstants.C_S_VALUE_GTT:
                    _intValidity = clsConstants.C_V_ORDER_GTT;
                    break;
            }
        }
        catch (e) {

        }

        return _intValidity;
    }

    //Returns Exchange wise Market status in text format
    getMktStatus(_intMktSegID) {
        let _strMktStatus = 'OPEN';
        try {
            switch (parseInt(_intMktSegID, 10)) {
                case clsConstants.C_V_NSE_CASH:
                    _strMktStatus = this.sNSEStatus;
                    break;
                case clsConstants.C_V_NSE_DERIVATIVES:
                    _strMktStatus = this.sNSEDervStatus;
                    break;
                case clsConstants.C_V_BSE_CASH:
                    _strMktStatus = this.sBSEStatus;
                    break;
                case clsConstants.C_V_BSE_DERIVATIVES:
                    _strMktStatus = this.sBSEDervStatus;
                    break;
                case clsConstants.C_V_MCX_DERIVATIVES:
                    _strMktStatus = this.sMCXStatus;
                    break;
                case clsConstants.C_V_NCDEX_DERIVATIVES:
                    _strMktStatus = this.sNCDEXStatus;
                    break;
                case clsConstants.C_V_NSEL_DERIVATIVES:
                    _strMktStatus = this.sNSELStatus;
                    break;
                case clsConstants.C_V_MSX_DERIVATIVES:
                    _strMktStatus = this.sMSXStatus;
                    break;
                case clsConstants.C_V_MSX_CASH:
                    _strMktStatus = this.sMCXSXEQStatus;
                    break;
                case clsConstants.C_V_MSX_FAO:
                    _strMktStatus = this.sMCXSXFAOStatus;
                    break;
                case clsConstants.C_V_DSE_CASH:
                    _strMktStatus = this.sDSEEQStatus;
                    break;
                case clsConstants.C_V_NMCE_DERIVATIVES:
                    _strMktStatus = this.sNMCEFUTStatus;
                    break;
                case clsConstants.C_V_NSX_DERIVATIVES:
                    _strMktStatus = this.sNSXStatus;
                    break;
                case clsConstants.C_V_BSECDX_DERIVATIVES:
                    _strMktStatus = this.sBSECDXStatus;
                    break;
                case clsConstants.C_V_UCX_DERIVATIVES:
                    _strMktStatus = this.sUCXStatus;
                    break;
                case clsConstants.C_V_DGCX_DERIVATIVES:
                    _strMktStatus = this.sDGCXStatus;
                    break;
                case clsConstants.C_V_BFX_DERIVATIVES:
                    _strMktStatus = this.sBFXStatus;
                    break;
                case clsConstants.C_V_OFS_IPO_BONDS:
                    _strMktStatus = this.sNSEOTSStatus;
                    break;
                     /**
        * USD : BT-12359
       * Date : 22/02/2020
       * Name : Rajendra Sirvi
       * Description : condition added for ICEX Segment
      */
                case clsConstants.C_V_ICEX_DERIVATIVES:
                    _strMktStatus = this.sICEXStatus;
                    break;
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetMktStatus()', 'tr_ExchManager.js', '');

        }
        return _strMktStatus;
    }

    // Returns Product type value in Gateway acceptable format
    getProductTypeValue(_sProductType, _sMktStatus, _iMarketsegID) {
        let _strProdType = '';
        try {
            // For AMO convert M --> AM and D --> AD
            if (_sMktStatus == clsConstants.C_S_AMO_TEXT) {
                // if product type is MARGIN, overwrite it to AMO MARGIN
                // if product type is DELIVERY, overwrite it to AMO DELIVERY
                if (_sProductType == clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT || _sProductType == clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT)
                    _sProductType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT;
                else if (_sProductType == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT || _sProductType == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT)
                    _sProductType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT;
            }


            //Added below if's by vishal on 8/8/2015 for CR3604 since carryforward & intraday are in one group & rest are in other groups they can havesame name
            //accross groups & not within. Automation testing case 16
            if (_iMarketsegID == clsConstants.C_V_NSE_CASH || _iMarketsegID == clsConstants.C_V_BSE_CASH ||
                _iMarketsegID == clsConstants.C_V_MSX_CASH || _iMarketsegID == clsConstants.C_V_DSE_CASH) {
                switch (_sProductType) {
                    case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
                        _strProdType = clsConstants.C_S_PRODUCTTYPE_MARGIN_VALUE;
                        break;
                    case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
                        _strProdType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_VALUE;
                        break;
                }

            }
            if (_iMarketsegID == clsConstants.C_V_NSE_DERIVATIVES || _iMarketsegID == clsConstants.C_V_BSE_DERIVATIVES ||
                _iMarketsegID == clsConstants.C_V_MCX_DERIVATIVES || _iMarketsegID == clsConstants.C_V_NCDEX_DERIVATIVES ||
                _iMarketsegID == clsConstants.C_V_NSEL_DERIVATIVES || _iMarketsegID == clsConstants.C_V_MSX_DERIVATIVES ||
                _iMarketsegID == clsConstants.C_V_NMCE_DERIVATIVES || _iMarketsegID == clsConstants.C_V_NSX_DERIVATIVES ||
                _iMarketsegID == clsConstants.C_V_BSECDX_DERIVATIVES || _iMarketsegID == clsConstants.C_V_UCX_DERIVATIVES ||
                _iMarketsegID == clsConstants.C_V_DGCX_DERIVATIVES || _iMarketsegID == clsConstants.C_V_BFX_DERIVATIVES) {
                switch (_sProductType) {
                    case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
                        _strProdType = clsConstants.C_S_PRODUCTTYPE_MARGIN_VALUE;
                        break;
                    case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
                        _strProdType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_VALUE;
                        break;
                }
            }


            switch (_sProductType) {
                //case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
                //case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
                case clsConstants.C_S_PRODUCTTYPE_OFS_TXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_MARGIN_VALUE;
                    break;
                //case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
                //case clsConstants.C_S_PRODUCTTYPE_CarrYFORWARD_TEXT:
                //_strProdType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_VALUE;
                //break;
                case clsConstants.C_S_PRODUCTTYPE_MTF_TEXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_MTF_VALUE;
                    break;
                case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_MP_VALUE;
                    break;
                case clsConstants.C_S_PRODUCTTYPE_PTST_TEXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_PTST_VALUE;
                    break;
                case clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT:
                case clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE;
                    break;
                case clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT:
                case clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE;
                    break;
                case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
                    _strProdType = clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE;
                    break;
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetProductTypeValue()', 'tr_ExchManager.js', '');

        }
        return _strProdType;
    }

    /// <summary>
    /// Compute disclosed quantity, w.r.t Quantity entered
    /// Used for order packet formation
    /// </summary>
    calculateDiscQty(_dblQuantity, _dblDiscQty, _strValidity, _intMktSegID, _strInstrument) {
        let _iDiscQty = 0;
        let _iQty = parseInt(_dblQuantity);
        try {
            if (_dblDiscQty != undefined && _dblDiscQty.toString().length > 0)
                _iDiscQty = parseInt(_dblDiscQty);
            else {
                //case to handle Disclosed Quantity if Quantity comes out to be blank ""
                //if (_dblDiscQty.toString().length > 0) {
                if ((_dblQuantity.toString().length > 0) && _strValidity != clsConstants.C_S_VALUE_IOC)
                    _iDiscQty = parseInt(_dblQuantity);
                else
                    _iDiscQty = 0;
                //}
            }

            switch (_intMktSegID) {
                case clsConstants.C_V_NSE_CASH:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_NSE_DERIVATIVES:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_BSE_CASH:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_BSE_DERIVATIVES:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_NCDEX_DERIVATIVES:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_NSX_DERIVATIVES:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_BSECDX_DERIVATIVES:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_MCX_DERIVATIVES:
                    if (_strInstrument.startsWith("AUC"))
                        _iDiscQty = 0;
                    else {
                        if (_iDiscQty > _iQty || _iDiscQty == 0)
                            _iDiscQty = _iQty;
                    }
                    break;
                case clsConstants.C_V_MSX_DERIVATIVES:
                case clsConstants.C_V_UCX_DERIVATIVES:
                case clsConstants.C_V_DGCX_DERIVATIVES:
                case clsConstants.C_V_BFX_DERIVATIVES:
                    if (_iDiscQty > _iQty || _iDiscQty == 0)
                        _iDiscQty = _iQty;
                    break;
                case clsConstants.C_V_NSEL_DERIVATIVES:
                    if (_strInstrument == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT ||
                        _strInstrument == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT ||
                        _strInstrument == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT ||
                        _strInstrument == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)
                        _iDiscQty = 0;
                    else {
                        if (_iDiscQty > _iQty || _iDiscQty == 0)
                            _iDiscQty = _iQty;
                    }
                    break;
                case clsConstants.C_V_MSX_CASH:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_DSE_CASH:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_MSX_FAO:
                    if (_iDiscQty >= _iQty)
                        _iDiscQty = 0;
                    break;
                case clsConstants.C_V_NMCE_DERIVATIVES:
                    if (_iDiscQty > _iQty || _iDiscQty == 0)
                        _iDiscQty = _iQty;
                    break;
                case clsConstants.C_V_OFS_IPO_BONDS:
                    _iDiscQty = 0;
                    break;
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'CalculateDiscQty()', 'tr_ExchManager.js', '');

        }
        return _iDiscQty;
    }

    fillParticipantId(bModifyFlag, _intMktSegID, _iParticipantID) {
        let _sParticipantID = '';
        try {

            if (_intMktSegID == clsConstants.C_V_BSE_CASH || _intMktSegID == clsConstants.C_V_BSE_DERIVATIVES)
                _sParticipantID = clsConstants.C_V_TAG_BSEPARTTYPE + '|' + clsGlobal.User.bsePartType;
            else if (_intMktSegID == clsConstants.C_V_NSE_CASH || _intMktSegID == clsConstants.C_V_OFS_IPO_BONDS)
                _sParticipantID = clsConstants.C_V_TAG_PARTICIPANTID + '|' + clsGlobal.User.nseEqParticipantID;
            else if (_intMktSegID == clsConstants.C_V_NSE_DERIVATIVES)
                _sParticipantID = clsConstants.C_V_TAG_PARTICIPANTID + '|' + clsGlobal.User.nseDervParticipantID;
            else if (_intMktSegID == clsConstants.C_V_NSX_DERIVATIVES) {
                if (bModifyFlag == false) {
                    _sParticipantID = clsConstants.C_V_TAG_PARTICIPANTID + '|' + clsGlobal.User.nsxParticipantID;
                }
                else
                    _sParticipantID = clsConstants.C_V_TAG_PARTICIPANTID + '|' + _iParticipantID;
            }
            else
                _sParticipantID = clsConstants.C_V_TAG_PARTICIPANTID + '|' + _iParticipantID;
        }
        catch (e) {


        }
        return _sParticipantID;
    }

    fillQuantity(_strMktSegmentId, _MarketLot) {
        let _Qty = '';
        try {
            if (this.exchInLOT.indexOf(parseInt(_strMktSegmentId.toString()) != -1))
                _Qty = "1";
            else
                _Qty = _MarketLot.toString();
        }
        catch (e) {


        }
        return _Qty;
    }

    /// <summary>
    /// converts COL into gateway acceptible value 
    /// </summary>
    getCOLValue(_COL) {
        let _intCOL = 1;
        try {
            _intCOL = (_COL == true) ? 2 : 1;
        }
        catch (e) {

        }

        return _intCOL;
    }

    setPreferences(_strExchange, _strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice, _LTP, _sClosePrice, _sSellQty, _sBuyQty, _sBuySell, QtyOpt) {
        // let _Qty = '';
        let Quantity = 0;
        try {
            ///Fetching the Additional parameters 
            let isLotSegment = false;

            if (QtyOpt == clsConstants.C_V_QTYVALUEBASED) {
                if (this.exchInLOT.indexOf(_strMktSegmentId)) {
                    isLotSegment = true;
                    if (_Instrument.startsWith("OPT"))
                        this.getScripParametersForOptions(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice);
                    else if (_Instrument.startsWith("FUT"))
                        this.getScripParametersForFutures(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice);
                    else if (_Instrument == 'EQUITIES')
                        this.getScripParametersForEquities(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice);
                }
                if (_LTP > 0 || _sClosePrice > 0) {
                    //let decDivisor = _LTP > 0 ? _LTP : _sClosePrice;
                    if (_Instrument.startsWith("OPT")) {
                        //Attention Angular
                        // Quantity = isLotSegment ?
                        // clsTradingMethods.roundDown((((clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForOptions / decDivisor) / parseInt(_MarketLot))/ ((this.priceNumerator / this.priceDenominator) * (this.genNumerator / this.genDenominator))), 1, "F0") : (clsTradingMethods.roundDown(((clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForOptions / decDivisor) / parseInt(_MarketLot)), 1, "F0") * parseInt(_MarketLot));
                    }
                    else {
                        //Attention Angular
                        //Quantity = isLotSegment ? clsTradingMethods.roundDown((((clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForFutures / decDivisor) / parseInt(_MarketLot)) / ((this.priceNumerator / this.priceDenominator) * (this.genNumerator /this.genDenominator))), 1, "F0") : clsTradingMethods.roundDown((((clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForFutures / decDivisor) / parseInt(_MarketLot))), 1, "F0") * parseInt(_MarketLot);
                    }
                }
                else
                    Quantity = 0;
            }
            else if (QtyOpt == clsConstants.C_V_QTYLOTBASED) {

                let IncrementLot = 1;
                if (!this.exchInLOT.indexOf(_strMktSegmentId.toString()))
                    IncrementLot = _MarketLot;
                // if (_Instrument.startsWith("OPT"))
                //     Quantity = clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForOptions * IncrementLot;
                // else
                //     Quantity = clsGlobal.User.OrderPrefDic[_strMktSegmentId].nQtyForFutures * IncrementLot;
            }
            else if (QtyOpt == clsConstants.C_V_QTYCOUNTERTOUCHLINEBASED) {
                if (_sBuySell == "BUY") {
                    if (!isNaN(parseInt(_sSellQty)) && parseInt(_sSellQty) > 0)
                        Quantity = _sSellQty;
                }
                else {
                    if (!isNaN(parseInt(_sBuyQty)) && parseInt(_sBuyQty) > 0)
                        Quantity = _sBuyQty;
                }
            }
        }
        catch (e) {


        }
        return Quantity;
    }

    getScripParametersForEquities(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice) {

        let data = {
            "UserID": clsGlobal.User.userId,
            "GroupID": clsGlobal.User.groupId,
            "MKtSegId": _strMktSegmentId,
            "InstNm": _Instrument,
            "Symbol": _Symbol,
            "Series": _Series,
            "UCCClientID": "",
            "UCCGroupID": ""
        }

        try {

            this.http.postJson(clsGlobal.VirtualDirectory, clsConstants.C_S_API_LOAD_SCRIP_DETAILS_FOR_EQ, data).subscribe(data => {

                let _paramCount = data.ResponseDictionary.length;

            });
        } catch (error) {
            this.rejectFnc(true);
        }
    };

    getScripParametersForOptions(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice) {
        try {
            //In case of Options    

            let data = {
                "UserID": clsGlobal.User.userId,
                "GroupID": clsGlobal.User.groupId,
                "MKtSegId": _strMktSegmentId,
                "InstNm": _Instrument,
                "Symbol": _Symbol,
                "ExpDt": _ExpiryDate,
                "StrkPrc": _StrikePrice,
                "OptType": _OptionType,
                "UCCClientID": "",
                "UCCGroupID": ""
            }

            // this.http.postJson(clsGlobal.URL_NETNETWCF, clsConstants.C_S_API_LOAD_SCRIP_DETAILS_FOR_OPTIONS, data)
            //     .subscribe((data) => {
            //         this.fn_FetchScripDetailsForOptions(data);
            //     });
        }
        catch (e) {
            this.rejectFnc(true);
        }
    };

    getScripParametersForFutures(_strMktSegmentId, _MarketLot, _Symbol, _Instrument, _Series, _ExpiryDate, _OptionType, _StrikePrice) {
        try {
            //In case of Futures
            let _sbFinalRequest = new StringBuilder();
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _strMktSegmentId + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_INSTRUMENTID + clsConstants.C_S_NAMEVALUE_DELIMITER + _Instrument + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SYMBOL + clsConstants.C_S_NAMEVALUE_DELIMITER + _Symbol + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_EXPIRYDATE + clsConstants.C_S_NAMEVALUE_DELIMITER + _ExpiryDate);
            let _strRequest = _sbFinalRequest.toString() + "/" + clsGlobal.User.OCToken;
            //clsGlobal.CommonMethods.AjaxCall(clsGlobal.URL_TRADINGWCF, 'LoadScripDetailsForFutures', _strRequest, fn_FetchScripDetailsForFutures, '', true);


            // this.clsHttpService.post(clsGlobal.URL_NETNETWCF, clsConstants.C_S_API_LOAD_SCRIP_DETAILS_FOR_FUTURES, _strRequest)
            //     .subscribe((data) => {
            //         this.fn_FetchScripDetailsForFutures(data);
            //     });

        }
        catch (e) {

        }
    };

    fn_FetchScripDetailsForEquities(_data) {
        try {
            if (_data.ResponseStatus === true && _data.ResponseString.length > 0) {
                let _Response = _data.ResponseString;
                this.fn_GetScripParams(_Response);
            }
        }
        catch (e) {


        }
    }

    fn_FetchScripDetailsForOptions(_data) {
        try {
            if (_data.ResponseStatus === true && _data.ResponseString.length > 0) {
                let _Response = _data.ResponseString;
                this.fn_GetScripParams(_Response);
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FetchScripDetailsForOptions()', 'tr_ExchangeManager.js', '');

        }
    }

    fn_FetchScripDetailsForFutures(_data) {
        try {
            if (_data.ResponseStatus === true && _data.ResponseString.length > 0) {
                let _Response = _data.ResponseString;
                this.fn_GetScripParams(_Response);
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FetchScripDetailsForFutures()', 'tr_ExchangeManager.js', '');

        }
    }

    ///<summary>
    ///Function to set the final scrip details based on parsing the response string
    ///</summary>
    fn_GetScripParams(_ScripResponseString) {
        try {

            let _arrScripDet = _ScripResponseString.split(clsConstants.C_S_FIELD_DELIMITER);
            this.token = _arrScripDet[clsConstants.ScripStoreToken];
            this.priceNumerator = _arrScripDet[clsConstants.ScripStorePriceNumerator] != '' ? _arrScripDet[clsConstants.ScripStorePriceNumerator] : 1;
            this.priceDenominator = _arrScripDet[clsConstants.ScripStorePriceDenominator] != '' ? _arrScripDet[clsConstants.ScripStorePriceDenominator] : 1;
            this.genNumerator = _arrScripDet[clsConstants.ScripStoreGenNumerator] != '' ? _arrScripDet[clsConstants.ScripStoreGenNumerator] : 1;
            this.genDenominator = _arrScripDet[clsConstants.ScripStoreGenDenominator] != '' ? _arrScripDet[clsConstants.ScripStoreGenDenominator] : 1;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetScripParams()', 'tr_ExchangeManager.js', '');

        }
    }

    getQtyLotCaption(_strMktSegmentId: any, LotSize: any, details: boolean = false) {
        let _caption = 'Qty';
        try {
            if (_strMktSegmentId != undefined && (this.exchInLOT.indexOf(_strMktSegmentId) != -1))
                _caption = details ? "Lot(1 Lot = " + LotSize + ")" : "Lot";
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetQtyLotCaption()', 'tr_ExchManager.js', '');

        }
        return _caption;
    }

    getQtyIncVal(_strMktSegmentId, _MarketLot) {
        let _step = 0;
        try {

            if (this.exchInLOT.indexOf(_strMktSegmentId) != -1) {
                _step = 1;
            }
            else {
                _step = parseInt(_MarketLot);
            }

        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetQtyIncVal()', 'tr_ExchManager.js', '');

        }
        return _step;
    }

    ///<summary>
    ///Function to return the caption for LifeTimeHigh used in case BestFive
    ///</summary>
    getLifeTimeHighCaption(_nMktSegId) {
        let _LTHCaption = '';
        try {
            if (_nMktSegId == clsConstants.C_V_NSE_CASH || _nMktSegId == clsConstants.C_V_BSE_CASH
                || _nMktSegId == clsConstants.C_V_DSE_CASH || _nMktSegId == clsConstants.C_V_MSX_CASH
                || _nMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                _LTHCaption = '52W H';
            }
            else {
                _LTHCaption = 'LT H';
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetLifeTimeHighCaption()', 'tr_ExchManager.js', '');

        }
        return _LTHCaption;
    };

    ///<summary>
    ///Function to return the caption for LifeTimeHigh used in case BestFive
    ///</summary>
    getLifeTimeLowCaption(_nMktSegId) {
        let _LTLCaption = '';
        try {
            if (_nMktSegId == clsConstants.C_V_NSE_CASH || _nMktSegId == clsConstants.C_V_BSE_CASH ||
                _nMktSegId == clsConstants.C_V_DSE_CASH || _nMktSegId == clsConstants.C_V_MSX_CASH ||
                _nMktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
                _LTLCaption = '52W L';
            }
            else {
                _LTLCaption = 'LT L';
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetLifeTimeLowCaption()', 'tr_ExchManager.js', '');

        }
        return _LTLCaption;
    };

    //----------------------------------------------Lookup changes------------------------------------------------------------//
    /// <summary>
    /// Function to fill the scripmaster array  with symbols from the scripmaster string
    /// <param> ScripMaster string with "|" delimeted string for symbol | scrip desc. Multiple scrips separated by "#"
    /// </summary>
    fillScripMaster(_strScripMaster) {
        try {
            if (_strScripMaster != "") {
                this.CurrentObj.arrScripMaster = _strScripMaster.split(clsConstants.C_S_MULTIRESP_DELIMITER);
            }
            else {
                this.CurrentObj.arrScripMaster = null;
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillScripMaster()', 'tr_ExchManager.js', '');

        }
        return this.CurrentObj.arrScripMaster;
    }

    /// <summary>
    /// Function to fetch the series for a particular scrip
    /// <param>Exchange name for setting the current exchange object</param>
    /// <params>Market segmentId, Instrument and Symbol of the selected scrip for which the series needs to be fetched</params>
    /// </summary>
    getSeries(_ExchName, _MktSegmentId, _Instrument, _Symbol) {
        try {
            this.exchName = _ExchName; //Setting the exchange name clsGlobal to be required in callback func

            let data = {
                "UserID": clsGlobal.User.userId,
                "GroupID": clsGlobal.User.groupId,
                "MKtSegId": _MktSegmentId,
                "InstNm": _Instrument,
                "Symbol": _Symbol,
                "UCCClientID": "",
                "UCCGroupID": ""
            }

            return null;// this.clsHttpService.postData(clsGlobal.URL_TRADINGWCF, clsConstants.C_S_API_LOAD_SCRIP_SERIES, data);
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetSeries()', 'tr_ExchManager.js', '');

        }
    };

    ///<summary>
    ///Callback function for ajax to fill the series based on the ajax response
    ///Parsing the response to fill the series array object
    ///<param>Response object of ajax (webgeneric response)</param>
    ///</summary>
    fillSeries(_objResponse) {
        try {
            this.scripSeries = [];
            this.scripSeries = _objResponse.ResponseObject;
            // this.scripSeries = _objResponse.ResponseString.split(clsConstants.C_S_MULTIRESP_DELIMITER);
            this.CurrentObj = this.getCurrentExchange(this.exchName);
            this.CurrentObj.arrSeries = [];
            for (let i = 0; i < this.scripSeries.length; i++) {
                this.CurrentObj.arrSeries.push(this.scripSeries[i]);
            }
            this.CurrentObj.arrSeries = this.scripSeries;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillSeries()', 'tr_ExchManager.js', '');

        }
        return this.CurrentObj.arrSeries;
    }

    /// <summary>
    /// Function to fetch the expiry dates and option type of the scrip by making an ajax call
    /// <param>Exchange name for setting the current exchange object</param>
    /// <params>Market segmentId, Instrument and Symbol of the selected scrip for which the ExpDate and OptionType needs to be fetched</params>
    /// <param>_callbackFunc is the reference of the ajax callback function passed from UI model since the ajax call needs to be made synchronous(async:false not supported from jquery1.8.1 onwards)</param>
    ///</summary>
    ///Dhiraj
    // getExpiryDatesAndoptionType(_ExchName, _MktSegmentId, _Instrument, _Symbol) {
    //     try {
    //         this.exchName = _ExchName; //Setting the exchange name clsGlobal to be required in callback func

    //         let jData = {
    //             "UserID": clsGlobal.User.userId,
    //             "GroupID": clsGlobal.User.groupId,
    //             "MKtSegId": _MktSegmentId,
    //             "InstNm": _Instrument,
    //             "Symbol": _Symbol,
    //             "UCCClientID": "",
    //             "UCCGroupID": ""
    //         }

    //         return null;// this.clsHttpService.postData(clsGlobal.URL_TRADINGWCF, clsConstants.C_S_API_LOAD_SCRIP_EXPDATE_N_OPTIONTYPE, jData);

    //     }
    //     catch (e) {

    //         //this.logManager.WriteLog('Exception: ' + e.message, 'GetExpiryDatesAndoptionType()', 'tr_ExchManager.js', '');

    //     }
    // };


    ///<summary>
    ///Function for parsing the expdate and option type and setting a json object
    ///</summary>
    fillExpDateNOptionType(_objResponse) {
        let _JExpoptionType;
        try {
            //Before setting the new array, resetting the array
            this.scripExpDateNOptionType = [];
            _JExpoptionType = { 'ED': [], 'OT': [] };
            this.CurrentObj = this.getCurrentExchange(this.exchName);
            this.CurrentObj.arrExpiryDate = [];
            this.CurrentObj.arrOptionType = [];

            this.scripExpDateNOptionType = _objResponse.ResponseString.split(clsConstants.C_S_MULTIRESP_DELIMITER);

            for (let i = 0; i < this.scripExpDateNOptionType.length; i++) {
                if (!this.CurrentObj.arrExpiryDate.indexOf(this.scripExpDateNOptionType[i].split('|')[0]))
                    this.CurrentObj.arrExpiryDate.push(this.scripExpDateNOptionType[i].split('|')[0]);
                if (!this.CurrentObj.arrOptionType.indexOf(this.scripExpDateNOptionType[i].split('|')[1]))
                    this.CurrentObj.arrOptionType.push(this.scripExpDateNOptionType[i].split('|')[1]);
            }
            _JExpoptionType = { 'ED': JSON.stringify(this.CurrentObj.arrExpiryDate), 'OT': JSON.stringify(this.CurrentObj.arrOptionType) };
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillExpDateNOptionType()', 'tr_ExchManager.js', '');

        }
        return _JExpoptionType;
    }

    ///<summary>
    ///Function for parsing the option type
    ///</summary>
    getOptionType(_ExchName, _MktSegmentId, _Instrument, _Symbol) {
        try {
            // First get the Exchange object and assign it in to current object...
            this.CurrentObj = this.getCurrentExchange(_ExchName);
            //if (CurrentObj.arrOptionType.length > 0) { CurrentObj.arrOptionType = [] };
            for (let i = 0; i < this.CurrentObj.arrScripMaster.length; i++) {
                if ((this.CurrentObj.arrScripMaster[i].split('|')[6] == _Instrument) && (this.CurrentObj.arrScripMaster[i].split('|')[1] == _Symbol)) {
                    if (!this.CurrentObj.arrOptionType.indexOf(this.CurrentObj.arrScripMaster[i].split('|')[2])) {
                        this.CurrentObj.arrOptionType.push(this.CurrentObj.arrScripMaster[i].split('|')[2]);
                    }
                }
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetOptionType()', 'tr_ExchManager.js', '');

        }
        return this.CurrentObj.arrOptionType;
    };

    /// <summary>
    /// Function to fetch the strike price of the scrip by making an ajax call
    /// <param>Exchange name for setting the current exchange object</param>
    /// <params>Market segmentId, Instrument and Symbol of the selected scrip for which the ExpDate and OptionType needs to be fetched</params>
    /// <param>_callbackFunc is the reference of the ajax callback function passed from UI model since the ajax call needs to be made synchronous(async:false not supported from jquery1.8.1 onwards)</param>
    ///</summary>
    ///Dhiraj
    // getStrikePrice(_ExchName, _MktSegmentId, _Instrument, _Symbol, _ExpiryDate) {
    //     try {
    //         let _sbFinalRequest = new StringBuilder();
    //         _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId + clsConstants.C_S_FIELD_DELIMITER);
    //         _sbFinalRequest.Append(clsConstants.C_V_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _MktSegmentId + clsConstants.C_S_FIELD_DELIMITER);
    //         _sbFinalRequest.Append(clsConstants.C_V_TAG_INSTRUMENTID + clsConstants.C_S_NAMEVALUE_DELIMITER + _Instrument + clsConstants.C_S_FIELD_DELIMITER);
    //         _sbFinalRequest.Append(clsConstants.C_V_TAG_SYMBOL + clsConstants.C_S_NAMEVALUE_DELIMITER + _Symbol + clsConstants.C_S_FIELD_DELIMITER);
    //         _sbFinalRequest.Append(clsConstants.C_V_TAG_EXPIRYDATE + clsConstants.C_S_NAMEVALUE_DELIMITER + _ExpiryDate);

    //         let jData = {
    //             "UserID": clsGlobal.User.userId,
    //             "GroupID": clsGlobal.User.groupId,
    //             "MKtSegId": _MktSegmentId,
    //             "InstNm": _Instrument,
    //             "Symbol": _Symbol,
    //             "ExpDt": _ExpiryDate,
    //             "UCCClientID": "",
    //             "UCCGroupID": ""
    //         }
    //         return null;//this.clsHttpService.postData(clsGlobal.URL_TRADINGWCF, clsConstants.C_S_API_LOAD_SCRIP_STRIKE_PRICE , jData);

    //     }
    //     catch (e) {

    //         //this.logManager.WriteLog('Exception: ' + e.message, 'GetStrikePrice()', 'tr_ExchManager.js', '');

    //     }
    //     return this.CurrentObj.arrStrikePrice;
    // };
    ///<summary>
    ///Function for parsing the string to fill the strike price array
    ///</summary>
    fillStrikePrice(_objResponse) {
        try {
            //Before setting the new array, resetting the array
            this.scripStrikePrice = [];
            this.CurrentObj = this.getCurrentExchange(this.exchName);
            this.CurrentObj.arrStrikePrice = [];
            this.scripStrikePrice = _objResponse.ResponseString.split(clsConstants.C_S_MULTIRESP_DELIMITER);

            for (let i = 0; i < this.scripStrikePrice.length; i++) {
                if (!this.CurrentObj.arrStrikePrice.indexOf(this.scripStrikePrice[i]))
                    this.CurrentObj.arrStrikePrice.push(this.scripStrikePrice[i]);
            }
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'FillStrikePrice()', 'tr_ExchManager.js', '');

        }
        return this.CurrentObj.arrStrikePrice;
    };
    //----------------------------------------------End of lookup changes-----------------------------------------------------//

    // Change for Market Status
    fillMarketStatus(_strMktSegId, sMarketType, sStatusFlag, sAucSessionNo) {
        let sExchName = clsTradingMethods.getExchangeName(parseInt(_strMktSegId, 10));
        let _CurrentObj = this.getCurrentExchange(sExchName);

        if (_CurrentObj !== undefined)
            _CurrentObj.populateMarketStatus(_strMktSegId, sMarketType, sStatusFlag, sAucSessionNo);
    }

    populateMarketStatusDictionary(_sLoginMode, _hMktStatus) {
        try {
            this.arrMktStatus = [];
            if (this.objNSE != null && this.objNSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNSEStatus = this.objNSE.sNSEStatus = _hMktStatus[clsConstants.C_V_NSE_CASH];
                else
                    this.sNSEStatus = this.objNSE.GetStatus(clsConstants.C_V_NSE_CASH);
                this.arrMktStatus.push(new fn_MktStatus("NSE CASH", this.sNSEStatus, this.getMktStatusColor(this.sNSEStatus)));
            }
            if (this.objNSE != null && this.objNSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNSEDervStatus = this.objNSE.sNSEDervStatus = _hMktStatus[clsConstants.C_V_NSE_DERIVATIVES];
                else
                    this.sNSEDervStatus = this.objNSE.GetStatus(clsConstants.C_V_NSE_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("NSE DERIVATIVES", this.sNSEDervStatus, this.getMktStatusColor(this.sNSEDervStatus)));
            }
            if (this.objBSE != null && this.objBSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sBSEStatus = this.objBSE.sBSEStatus = _hMktStatus[clsConstants.C_V_BSE_CASH];
                else
                    this.sBSEStatus = this.objBSE.GetStatus(clsConstants.C_V_BSE_CASH);
                this.arrMktStatus.push(new fn_MktStatus("BSE CASH", this.sBSEStatus, this.getMktStatusColor(this.sBSEStatus)));

                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sBSESPOSStatus = this.objBSE.sBSESPOSStatus = _hMktStatus[clsConstants.C_V_BSE_SPOS];
                else
                    this.sBSESPOSStatus = this.objBSE.GetSPOSStatus();
                this.arrMktStatus.push(new fn_MktStatus("BSE Special PreOpen", this.sBSESPOSStatus, this.getMktStatusColor(this.sBSESPOSStatus)));
            }
            if (this.objBSE != null && this.objBSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sBSEDervStatus = this.objBSE.sBSEDervStatus = _hMktStatus[clsConstants.C_V_BSE_DERIVATIVES];
                else
                    this.sBSEDervStatus = this.objBSE.getStatus(clsConstants.C_V_BSE_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("BSE DERIVATIVES", this.sBSEDervStatus, this.getMktStatusColor(this.sBSEDervStatus)));
            }
            if (this.objMCX != null && this.objMCX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sMCXStatus = this.objMCX.sMCXStatus = _hMktStatus[clsConstants.C_V_MCX_DERIVATIVES];
                else
                    this.sMCXStatus = this.objMCX.getStatus(clsConstants.C_V_MCX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("MCX DERIVATIVES", this.sMCXStatus, this.getMktStatusColor(this.sMCXStatus)));
            }
            if (this.objNCDEX != null && this.objNCDEX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNCDEXStatus = this.objNCDEX.sNCDEXStatus = _hMktStatus[clsConstants.C_V_NCDEX_DERIVATIVES];
                else
                    this.sNCDEXStatus = this.objNCDEX.getStatus(clsConstants.C_V_NCDEX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("NCDEX DERIVATIVES", this.sNCDEXStatus, this.getMktStatusColor(this.sNCDEXStatus)));
            }
            if (this.objNSEL != null && this.objNSEL != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNSELStatus = this.objNSEL.sNSELStatus = _hMktStatus[clsConstants.C_V_NSEL_DERIVATIVES];
                else
                    this.sNSELStatus = this.objNSEL.getStatus(clsConstants.C_V_NSEL_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("NSEL SPTCOM", this.sNSELStatus, this.getMktStatusColor(this.sNSELStatus)));
            }
            if (this.objMSX != null && this.objMSX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sMSXStatus = this.objMSX.sMSXStatus = _hMktStatus[clsConstants.C_V_MSX_DERIVATIVES];
                else
                    this.sMSXStatus = this.objMSX.getStatus(clsConstants.C_V_MSX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("MSE CUR", this.sMSXStatus, this.getMktStatusColor(this.sMSXStatus)));
            }
            if (this.objNSX != null && this.objNSX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNSXStatus = this.objMSX.sMSXStatus = _hMktStatus[clsConstants.C_V_NSX_DERIVATIVES];
                else
                    this.sNSXStatus = this.objNSX.GetStatus(clsConstants.C_V_NSX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("NSECDS", this.sNSXStatus, this.getMktStatusColor(this.sNSXStatus)));
            }
            if (this.objBSECDX != null && this.objBSECDX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sBSECDXStatus = this.objBSECDX.GetStatus(clsConstants.C_V_BSECDX_DERIVATIVES);
                else
                    this.sBSECDXStatus = this.objBSECDX.GetStatus(clsConstants.C_V_BSECDX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("BSECDS", this.sBSECDXStatus, this.getMktStatusColor(this.sBSECDXStatus)));
            }
            if (this.objMSX != null && this.objMSX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sMCXSXEQStatus = this.objMSX.sMCXSXEQStatus = _hMktStatus[clsConstants.C_V_MSX_CASH];
                else
                    this.sMCXSXEQStatus = this.objMSX.GetStatus(clsConstants.C_V_MSX_CASH);
                this.arrMktStatus.push(new fn_MktStatus("MSE EQ", this.sMCXSXEQStatus, this.getMktStatusColor(this.sMCXSXEQStatus)));

                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sMCXSXEQSPOSStatus = this.objMSX.sMCXSXEQSPOSStatus = _hMktStatus["92"];
                else
                    this.sMCXSXEQSPOSStatus = this.objMSX.GetSPOSStatus();

                this.arrMktStatus.push(new fn_MktStatus("MSE EQ Special PreOpen", this.sMCXSXEQSPOSStatus, this.getMktStatusColor(this.sMCXSXEQSPOSStatus)));
            }
            if (this.objMSX != null && this.objMSX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_MSX_FAO.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sMCXSXFAOStatus = this.objMSX.sMCXSXFAOStatus = _hMktStatus[clsConstants.C_V_MSX_FAO];
                else
                    this.sMCXSXFAOStatus = this.objMSX.GetStatus(clsConstants.C_V_MSX_FAO);
                this.arrMktStatus.push(new fn_MktStatus("MSE FAO", this.sMCXSXFAOStatus, this.getMktStatusColor(this.sMCXSXFAOStatus)));
            }
            if (this.objDSE != null && this.objDSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_DSE_CASH.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sDSEEQStatus = this.objDSE.sDSEEQStatus = _hMktStatus[clsConstants.C_V_DSE_CASH];
                else
                    this.sDSEEQStatus = this.objDSE.GetStatus(clsConstants.C_V_DSE_CASH);
                this.arrMktStatus.push(new fn_MktStatus("DSE EQ", this.sDSEEQStatus, this.getMktStatusColor(this.sDSEEQStatus)));
            }
            if (this.objNMCE != null && this.objNMCE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NMCE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNMCEFUTStatus = this.objNMCE.sNMCEFUTStatus = _hMktStatus[clsConstants.C_V_NMCE_DERIVATIVES];
                else
                    this.sNMCEFUTStatus = this.objNMCE.GetStatus(clsConstants.C_V_NMCE_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("NMCE FUTURES", this.sNMCEFUTStatus, this.getMktStatusColor(this.sNMCEFUTStatus)));
            }
            if (this.objDGCX != null && this.objDGCX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_DGCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sDGCXStatus = this.objDGCX.sDGCXStatus = _hMktStatus[clsConstants.C_V_DGCX_DERIVATIVES];
                else
                    this.sDGCXStatus = this.objDGCX.GetStatus(clsConstants.C_V_DGCX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("DGCX", this.sDGCXStatus, this.getMktStatusColor(this.sDGCXStatus)));
            }
            if (this.objBFX != null && this.objBFX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_BFX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sBFXStatus = this.objBFX.sBFXStatus = clsConstants.C_V_BFX_DERIVATIVES.toString();
                else
                    this.sBFXStatus = this.objBFX.GetStatus(clsConstants.C_V_BFX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("BFX", this.sBFXStatus, this.getMktStatusColor(this.sBFXStatus)));
            }
            if (this.objUCX != null && this.objUCX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_UCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sUCXStatus = this.objUCX.sUCXStatus = _hMktStatus["91"];
                else
                    this.sUCXStatus = this.objUCX.GetStatus(clsConstants.C_V_UCX_DERIVATIVES);
                this.arrMktStatus.push(new fn_MktStatus("UCX", this.sUCXStatus, this.getMktStatusColor(this.sUCXStatus)));
            }

            if (this.objNSEOTS != null && this.objNSEOTS != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_OFS_IPO_BONDS.toString()) == clsConstants.C_S_ON) {
                if (_sLoginMode == clsConstants.C_S_REFRESH_MODE)
                    this.sNSEOTSStatus = this.objNSEOTS.sNSEOTSStatus = _hMktStatus[clsConstants.C_V_OFS_IPO_BONDS];
                else
                    this.sNSEOTSStatus = this.objNSEOTS.GetStatus(clsConstants.C_V_OFS_IPO_BONDS);
                this.arrMktStatus.push(new fn_MktStatus("NSE-OTS", this.sNSEOTSStatus, this.getMktStatusColor(this.sNSEOTSStatus)));
            }

            return this.arrMktStatus;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatusDictionary()', 'tr_ExchManager.js', '');

        }
    }

    getMktStatusColor(sMktStatus) {
        try {
            let sColor = 'Exchange_tile ';
            if (sMktStatus != undefined) {
                if (sMktStatus.toUpperCase() == "OPEN" || sMktStatus.toUpperCase() == "PRE OPEN" || sMktStatus.toUpperCase() == "SPOS OPEN"
                    || sMktStatus.toUpperCase() == "MATCHING OPEN") {
                    sColor += "OPEN";
                }
                else {
                    if (sMktStatus.toUpperCase() == "CLOSE" || sMktStatus.toUpperCase() == "SPOS CLOSE" || sMktStatus.toUpperCase() == "MATCHING CLOSE" || sMktStatus.toUpperCase() == "PRE OPEN ENDED") {
                        sColor += "CLOSE";
                    }
                    else {
                        if (sMktStatus.toUpperCase() == "UNAVAILABLE" || sMktStatus.toUpperCase() == "" ||
                            sMktStatus.toUpperCase() == "-") {
                            sColor += "UNAV";
                        }
                        else {
                            if (sMktStatus.toUpperCase() == "EXTENDED MARKET") {
                                sColor += "EXTMKT";
                            }
                            else {
                                sColor += "AMO";
                            }
                        }
                    }
                }
            }

            return sColor;
        }
        catch (e) {

            //this.logManager.WriteLog('Exception: ' + e.message, 'GetMktStatusColor()', 'tr_ExchManager.js', '');

        }
    }

    getMktStatusDesc(sMkt, sAMOMkt, sExtendedMkt, sMaktSegmentId) {
        let sMarketStatus = '';
        if (sAMOMkt == "1") {
            sMarketStatus = "AMO";
        }
        else if (sExtendedMkt == "1") {
            sMarketStatus = "Extended Market";
        }
        else if (sMkt == "1") {
            sMarketStatus = "Open";
        }
        else if (sMkt == "2" || sMkt == "5") {
            sMarketStatus = "Close";
        }
        else if (sMkt == "0") {
            if (sMaktSegmentId == "1" || sMaktSegmentId == "2" || sMaktSegmentId == "3" || sMaktSegmentId == "4" || sMaktSegmentId == "15")
                sMarketStatus = "Pre Open";
            else
                sMarketStatus = "Unavailable";
        }
        else if (sMkt == "3") {
            if (sMaktSegmentId == "1" || sMaktSegmentId == "2" || sMaktSegmentId == "3" || sMaktSegmentId == "4" || sMaktSegmentId == "15")
                sMarketStatus = "Pre Open Ended";
            else
                sMarketStatus = "Unavailable";
        }
        else if (sMkt == "4") {
            sMarketStatus = "Post Closing";
        }
        else {
            sMarketStatus = "Unavailable";
        }


        return sMarketStatus;
    }

    // fetchSPOSStatusForMCXSXEQ(sMapMktSegId, sToken, _callbackFunc) {
    //     try {

    //         //Angular attention

    //         let jData = {
    //             "UserID": clsGlobal.User.userId,
    //             "GroupID": clsGlobal.User.groupId,
    //             "ScripTkn": sToken,
    //             "MktSegId": sMapMktSegId,
    //             "UCCClientID": "",
    //             "UCCGroupID": ""
    //         }


    //         // this.clsHttpService.postData(clsGlobal.URL_NETNETWCF, clsConstants.C_S_API_GET_SPOS_STATUS_FOR_MCXSXEQ , jData)
    //         //     .subscribe((data) => {
    //         //         _callbackFunc(data);
    //         //     });


    //     }
    //     catch (e) {

    //         //this.logManager.WriteLog('Exception: ' + e.message, 'FetchSPOSStatusForMCXSXEQ()', 'tr_ExchManager.js', '');

    //     }
    // };

    ///<summary>
    ///Function to set the security info details as per exchange
    ///</summary>
    getSecurityInfo(_dcSecDetails, _segId) {
        let _ExchName = clsTradingMethods.getExchangeName(parseInt(_segId));
        let _dicSecInfo = _dcSecDetails;
        _dicSecInfo.SecurityName = _dcSecDetails.sSecurityDesc;
        _dicSecInfo.Token = _dcSecDetails.nToken;
        _dicSecInfo.Instrument = _dcSecDetails.nInstrumentType;
        _dicSecInfo.ISIN = _dcSecDetails.sISINCode;
        _dicSecInfo.MarketLot = _dcSecDetails.nRegularLot;
        _dicSecInfo.PriceTick = _dcSecDetails.nPriceTick != "" ? (parseFloat(_dcSecDetails.nPriceTick) / 100).toFixed(2) : "";
        _dicSecInfo.IssuedCapital = clsTradingMethods.formatNumber(parseFloat(_dcSecDetails.nIssuedCapital), 2);

        _dicSecInfo.FaceValue = parseFloat((parseInt(_dcSecDetails.nFaceValue) / 100).toString()).toFixed(2);
        _dicSecInfo.QtyFreeze = (parseFloat(((parseInt(_dcSecDetails.nFreezePercent) / 100).toString())).toFixed(2)).toString() + "%";
        _dicSecInfo.Margin = (parseFloat((parseInt(_dcSecDetails.nMarginMultiplier) / 100).toString()).toFixed(2)).toString() + "%";
        _dicSecInfo.Multiplier = _dcSecDetails.nIntrinsicValue;

        //Pre Open 
        _dicSecInfo.PreOpen = _dcSecDetails.nNormal_SecurityStatus;

        //GSM changes
        _dicSecInfo.GSMCategory = _dcSecDetails.nIssueRate;
        _dicSecInfo.GSMConfig = _dcSecDetails.sData;

        // Special Pre Open
        if (_dcSecDetails.SPOS.toString().trim() == "12" && _dcSecDetails.SPOSTYPE.toString().trim() == "12") {
            _dicSecInfo.SPOS = "Yes";
        }
        else {
            _dicSecInfo.SPOS = "No";
        }

        //if (_ExchName === clsConstants.C_S_NSE_EXCHANGE_TEXT) {//Call Auction available only for NSE
        if (_dcSecDetails.nPriceQuotFactor.toString().trim() == "5" || _dcSecDetails.SPOSTYPE.toString().trim() == "12")
            _dicSecInfo.CallAuction = "YES";
        else
            _dicSecInfo.CallAuction = "No";
        //}
        //else
        //    _dicSecInfo.CallAuction = "";

        if (_dcSecDetails.nBookClosureStartDate.toString() == "0")
            _dicSecInfo.StartDate = "NA";
        else
            _dicSecInfo.StartDate = clsTradingMethods.convertToDate(_dcSecDetails.nBookClosureStartDate, "dd-MMM-yyyy").toUpperCase();
        if (_dcSecDetails.nBookClosureEndDate.toString() == "0")
            _dicSecInfo.EndDate = "NA";
        else
            _dicSecInfo.EndDate = clsTradingMethods.convertToDate(_dcSecDetails.nBookClosureEndDate, "dd-MMM-yyyy").toUpperCase();

        if (_ExchName === clsConstants.C_S_NSEL_EXCHANGE_TEXT) {
            _dicSecInfo.StartDate = "";
            _dicSecInfo.EndDate = "";
        }

        if (_dcSecDetails.nExDate.toString() == "0")
            _dicSecInfo.ExDate = "NA";
        else
            _dicSecInfo.ExDate = clsTradingMethods.convertToDate(_dcSecDetails.nExDate, "dd-MMM-yyyy").toUpperCase();

        //if (_segId === clsConstants.C_V_MSX_CASH) {
        //    _dicSecInfo.Purpose = "";
        //}
        //else {
        _dicSecInfo.Purpose = _dcSecDetails.sRemarks;
        //}

        return _dcSecDetails;
    };

    fn_CheckForNonMinusOne(strVerificationString) {
        let bStatus = false;
        try {
            if (parseFloat(strVerificationString).toFixed(2).toString() == "-1.00")
                bStatus = false;
            else
                bStatus = true;
        }
        catch (e) {
            bStatus = false;
        }
        return bStatus;
    }

    ///<summary>
    ///Function to set the security info details as per exchange
    ///</summary>
    getContractInfo(_dcConInfoDetails, _segId) {
        let _dicContInfo = _dcConInfoDetails;
        let decLoc, strPriceFormat;
        _dicContInfo.ContractName = _dcConInfoDetails.sSecurityDesc;
        _dicContInfo.Token = _dcConInfoDetails.nToken;
        _dicContInfo.ULAsset = _dcConInfoDetails.sAssetName;
        _dicContInfo.MarketLot = _dcConInfoDetails.nRegularLot;
        _dicContInfo.InstrumentName = _dcConInfoDetails.sInstrumentName;

        if (_dcConInfoDetails.nReferanceRate != undefined && _dcConInfoDetails.nReferanceRate != "") {
            decLoc = _dcConInfoDetails.nDecimalLocator === "0" ? "100" : _dcConInfoDetails.nDecimalLocator;
            _dcConInfoDetails.nReferanceRate = parseFloat((_dcConInfoDetails.nReferanceRate / parseInt(decLoc)).toString()).toFixed(6)
        }

        if (_dcConInfoDetails.nPriceTick != undefined && _dcConInfoDetails.nPriceTick != "") {
            decLoc = _dcConInfoDetails.nDecimalLocator === "0" ? "100" : _dcConInfoDetails.nDecimalLocator;
            strPriceFormat = clsTradingMethods.getPriceFormatterWithDLAndMksSegID(decLoc, _segId);
            _dicContInfo.PriceTick = parseFloat((_dcConInfoDetails.nPriceTick / parseInt(decLoc)).toString()).toFixed(strPriceFormat); // Prict Tick will be in Paise in Db... so convert to RS is required...
        }
        if (_segId === clsConstants.C_V_NSEL_DERIVATIVES || _segId === clsConstants.C_V_NSEL_SPOT) {
            _dicContInfo.Maturity = "";
        }
        else {
            if (_dcConInfoDetails.nIssueMaturityDate != undefined)
                _dicContInfo.Maturity = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueMaturityDate, "").toUpperCase();
        }

        if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_NSEL_SPOT)
            || (_segId === clsConstants.C_V_MCX_DERIVATIVES && _dicContInfo.InstrumentName.startsWith("AUC"))
            || (_segId === clsConstants.C_V_MSX_FAO)
            || (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)) {
            _dicContInfo.ExDate = "";
        }
        else {
            if (_dcConInfoDetails.nExpiryDate.toString() == "0")
                _dicContInfo.ExDate = "";
            else
                _dicContInfo.ExDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExpiryDate, "").toUpperCase();
        }

        if (_dicContInfo.nStrikePrice == undefined || _dicContInfo.nStrikePrice == "NA" || parseFloat(_dicContInfo.nStrikePrice) <= 0) {
            _dicContInfo.nStrikePrice = '';
        }
        else {
            if (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / 10000).toString();
            else if ((_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT) || (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_MSX_FAO))
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / parseFloat(_dicContInfo.nDecimalLocator)).toFixed(4);
            else if (_dicContInfo.nMarketSegmentId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES && _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_OPTCUR_TEXT)
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / parseFloat(_dicContInfo.nDecimalLocator)).toFixed(4);
            else
                _dicContInfo.nStrikePrice = (parseFloat(_dicContInfo.nStrikePrice) / 100).toString();
        }

        if (_dcConInfoDetails.nPriceQuotFactor.toString() != "0") {
            _dicContInfo.PriceQuote = _dcConInfoDetails.nPriceQuotFactor.toString() + "," + _dcConInfoDetails.sPriceQuotUnit.toString();
        }
        else {
            if (_dcConInfoDetails.sPriceQuotUnit.toString() == "")
                _dicContInfo.PriceQuote = "NA";
            else
                _dicContInfo.PriceQuote = _dcConInfoDetails.sPriceQuotUnit.toString();
        }

        let intMTI = _dcConInfoDetails.nMarginTypeIndicator.toString() != "" ? parseInt(_dcConInfoDetails.nMarginTypeIndicator.toString()) : 0;
        let strMarginMul = _dcConInfoDetails.nMarginMultiplier.toString();
        if (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
            intMTI = 2;
        if (intMTI == 1)
            _dicContInfo.Margin = parseFloat(strMarginMul).toFixed(2) + "%";
        else if (intMTI == 2)
            _dicContInfo.Margin = (parseFloat(strMarginMul) / 100).toFixed(2);
        else
            _dicContInfo.Margin = "NA";

        if (_segId == clsConstants.C_V_NSE_DERIVATIVES ||
            _segId == clsConstants.C_V_BSE_DERIVATIVES) {
            let dblIntVal = _dcConInfoDetails.nIntrinsicValue.toString() != "" ? parseFloat(_dcConInfoDetails.nIntrinsicValue.toString()) / 10000 : 0;
            _dicContInfo.ExMultiplier = dblIntVal.toFixed(2);
        }
        else {
            _dicContInfo.ExMultiplier = _dcConInfoDetails.nIntrinsicValue.toString();
        }

        //IP date
        if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)
            || (_segId == clsConstants.C_V_NSEL_SPOT)
            || (_segId == clsConstants.C_V_MSX_DERIVATIVES)
            || (_segId == clsConstants.C_V_NMCE_DERIVATIVES)
            || (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
            _dicContInfo.IPDate = "NA";
        else if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
            _dicContInfo.IPDate = " ";
        else if ((_segId == clsConstants.C_V_DGCX_DERIVATIVES) || (_segId == clsConstants.C_V_BFX_DERIVATIVES) || (_segId == clsConstants.C_V_UCX_DERIVATIVES)
            || (_segId == clsConstants.C_V_DGCX_SPOT) || (_segId == clsConstants.C_V_BFX_SPOT) || (_segId == clsConstants.C_V_UCX_SPOT))
            _dicContInfo.IPDate = 'NA';
        else {
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssuePDate.toString())) {
                _dicContInfo.IPDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssuePDate, "").toUpperCase();
            }
            else {
                _dicContInfo.IPDate = "NA";
            }
        }

        if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssueStartDate.toString()) && _segId != clsConstants.C_V_BSE_DERIVATIVES) {
            _dicContInfo.ContractStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueStartDate, "ddMMMyyyy HH:MM:ss").toUpperCase();
        }
        else {
            _dicContInfo.ContractStartDate = "NA";
        }
        try {
            // Contract End Date ...
            if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)
                || (_segId == clsConstants.C_V_NSEL_SPOT)
                || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT))
                || (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.ContractEndDate = "";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nIssueMaturityDate.toString()))
                _dicContInfo.ContractEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nIssueMaturityDate, "ddMMMyyyy HH:MM:ss").toUpperCase();
            else
                _dicContInfo.ContractEndDate = "NA";

            if (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
                _dicContInfo.TenderStartDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nExerciseStartDate.toString()) && _segId != clsConstants.C_V_BSE_DERIVATIVES) {
                _dicContInfo.TenderStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseStartDate, "").toUpperCase();
            }
            else
                _dicContInfo.TenderStartDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.TenderEndDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nExerciseEndDate.toString()) && (_segId != clsConstants.C_V_BSE_DERIVATIVES && _segId != clsConstants.C_V_NSEL_SPOT)) {
                if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
                    _dicContInfo.TenderEndDate = 'NA';
                else
                    _dicContInfo.TenderEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nExerciseEndDate, "").toUpperCase();
            }
            else
                _dicContInfo.TenderEndDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.DelStartDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nNoDeliveryStartDate.toString()))
                _dicContInfo.DelStartDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryStartDate, "").toUpperCase();
            else
                _dicContInfo.DelStartDate = "NA";

            if ((_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT))
                _dicContInfo.DelEndDate = " ";
            else if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails.nNoDeliveryEndDate.toString()) && (_segId != clsConstants.C_V_BSE_DERIVATIVES && _segId != clsConstants.C_V_NSEL_SPOT))
                if ((_segId === clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId === clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_OPTFUT_TEXT)))
                    _dicContInfo.DelEndDate = 'NA';
                else
                    _dicContInfo.DelEndDate = clsTradingMethods.convertToDate(_dcConInfoDetails.nNoDeliveryEndDate, "").toUpperCase();
            else
                _dicContInfo.DelEndDate = "NA";

        }
        catch (e) {

        }
        _dicContInfo.NearMonthId = 'NA';
        _dicContInfo.FarMonthId = 'NA';
        _dicContInfo.OLongMargin = 'NA';
        _dicContInfo.OShortMargin = 'NA';
        _dicContInfo.ExMargin = 'NA';
        _dicContInfo.AddPreMargin = 'NA';
        _dicContInfo.AddShortMargin = 'NA';
        _dicContInfo.SPLGCMargin = 'NA';
        _dicContInfo.AddLongMargin = 'NA';
        _dicContInfo.SPSHCMargin = 'NA';

        //MSX Information ...
        if (_segId == clsConstants.C_V_MSX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nOtherLongMargin))
                _dicContInfo.OLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nOtherLongMargin.toString());

            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nOtherLongMargin))
                _dicContInfo.OShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nOtherShortMargin.toString());
        }

        //MCX Information ...
        if (_segId == clsConstants.C_V_MCX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashLongMargin))
                _dicContInfo.OLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashLongMargin.toString());

            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashShortMargin))
                _dicContInfo.OShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashShortMargin.toString());
        }


        //NCDEX Information ...
        if (_segId == clsConstants.C_V_NCDEX_DERIVATIVES) {
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nExposureMarginAdditional.toString()))
                _dicContInfo.ExMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nExposureMarginAdditional.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nPreExpiryMargin.toString()))
                _dicContInfo.AddPreMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nPreExpiryMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nAdditionalShortMargin.toString()))
                _dicContInfo.AddShortMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nAdditionalShortMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashLongMargin.toString()))
                _dicContInfo.SPLGCMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashLongMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nAdditionalLongMargin.toString()))
                _dicContInfo.AddLongMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nAdditionalLongMargin.toString());
            if (clsTradingMethods.fn_CheckForNonMinusOne(_dcConInfoDetails.nSpecialCashShortMargin.toString()))
                _dicContInfo.SPSHCMargin = clsTradingMethods.formatToPercentage(_dcConInfoDetails.nSpecialCashShortMargin.toString());

        }

        //Margin Info
        if (_dcConInfoDetails.hasOwnProperty("Initial Margin Long")) {
            if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId == clsConstants.C_V_NSEL_SPOT) || (_segId == clsConstants.C_V_NMCE_DERIVATIVES) ||
                (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)) ||
                _segId == clsConstants.C_V_BSE_DERIVATIVES || _segId == clsConstants.C_V_DGCX_DERIVATIVES || _segId == clsConstants.C_V_BFX_DERIVATIVES ||
                _segId == clsConstants.C_V_UCX_DERIVATIVES || _segId == clsConstants.C_V_UCX_SPOT ||
                _segId == clsConstants.C_V_DGCX_SPOT || _segId == clsConstants.C_V_BFX_SPOT) {
                _dicContInfo.InLongMargin = 'NA';
                _dicContInfo.InShortMargin = 'NA';
                _dicContInfo.AppLongMargin = 'NA';
                _dicContInfo.AppShortMargin = 'NA';
            }
            else {
                _dicContInfo.InLongMargin = _dcConInfoDetails["Initial Margin Long"] != "" ? _dcConInfoDetails["Initial Margin Long"] : 'NA';
                _dicContInfo.InShortMargin = _dcConInfoDetails["Initial Margin Short"] != "" ? _dcConInfoDetails["Initial Margin Short"] : 'NA';
                _dicContInfo.AppLongMargin = _dcConInfoDetails["Total Margin Long"] != "" ? _dcConInfoDetails["Total Margin Long"] : 'NA';
                _dicContInfo.AppShortMargin = _dcConInfoDetails["Total Margin Short"] != "" ? _dcConInfoDetails["Total Margin Short"] : 'NA';
            }
        }
        else {
            if ((_segId == clsConstants.C_V_NSEL_DERIVATIVES && _dicContInfo.InstrumentName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT) || (_segId == clsConstants.C_V_NSEL_SPOT) || (_segId == clsConstants.C_V_NMCE_DERIVATIVES) ||
                (_segId == clsConstants.C_V_MCX_DERIVATIVES && (_dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCSO_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTBI_TEXT || _dicContInfo.InstrumentName == clsConstants.C_S_INSTRUMENT_AUCTSI_TEXT)) ||
                _segId == clsConstants.C_V_BSE_DERIVATIVES || _segId == clsConstants.C_V_DGCX_DERIVATIVES || _segId == clsConstants.C_V_BFX_DERIVATIVES ||
                _segId == clsConstants.C_V_UCX_DERIVATIVES || _segId == clsConstants.C_V_UCX_SPOT ||
                _segId == clsConstants.C_V_DGCX_SPOT || _segId == clsConstants.C_V_BFX_SPOT ||
                _segId == clsConstants.C_V_MSX_FAO) {
                _dicContInfo.InLongMargin = 'NA';
                _dicContInfo.InShortMargin = 'NA';
                _dicContInfo.AppLongMargin = 'NA';
                _dicContInfo.AppShortMargin = 'NA';
            }
            else {
                _dicContInfo.InLongMargin = "NA";
                _dicContInfo.InShortMargin = "NA";
                _dicContInfo.AppLongMargin = "NA";
                _dicContInfo.AppShortMargin = "NA";
            }
        }

        if (_dcConInfoDetails.hasOwnProperty("NearMonthSymbol") && _dcConInfoDetails.hasOwnProperty("NearMonthExpiry") &&
            _dcConInfoDetails.hasOwnProperty("FarMonthSymbol") && _dcConInfoDetails.hasOwnProperty("FarMonthExpiry")) {
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails["NearMonthExpiry"].toString())) {
                _dicContInfo.NearMonthId = _dcConInfoDetails["NearMonthSymbol"] + " " + clsTradingMethods.convertToDate(parseFloat(_dcConInfoDetails["NearMonthExpiry"]), "").toUpperCase();
            }
            if (clsTradingMethods.checkNonBlankNonZero(_dcConInfoDetails["FarMonthExpiry"].toString())) {
                _dicContInfo.FarMonthId = _dcConInfoDetails["FarMonthSymbol"] + " " + clsTradingMethods.convertToDate(parseFloat(_dcConInfoDetails["FarMonthExpiry"]), "").toUpperCase();
            }
        }

        _dicContInfo.LotUnit = 'NA';
        _dicContInfo.MaxOrderQty = 'NA';
        _dicContInfo.MaxOrderValue = 'NA';

        if (_segId == clsConstants.C_V_MCX_DERIVATIVES || _segId == clsConstants.C_V_NCDEX_DERIVATIVES || _segId == clsConstants.C_V_NMCE_DERIVATIVES || _segId == clsConstants.C_V_NSX_DERIVATIVES || _segId == clsConstants.C_V_NSE_DERIVATIVES) {
            if (_dcConInfoDetails.hasOwnProperty("sQtyUnit")) {
                _dicContInfo.LotUnit = _dcConInfoDetails["sQtyUnit"] != "" ? _dcConInfoDetails["sQtyUnit"] : 'NA';
            }
            if (_dcConInfoDetails.hasOwnProperty("nMaxSingleTransactionQty")) {
                _dicContInfo.MaxOrderQty = _dcConInfoDetails["nMaxSingleTransactionQty"] != "" ? _dcConInfoDetails["nMaxSingleTransactionQty"] : 'NA';
            }
            if (_dcConInfoDetails.hasOwnProperty("nMaxSingleTransactionValue")) {
                _dicContInfo.MaxOrderValue = (_dcConInfoDetails["nMaxSingleTransactionValue"] != "") ? (_dcConInfoDetails["nMaxSingleTransactionValue"] != "-1") ? _dcConInfoDetails["nMaxSingleTransactionValue"] : "Unlimited" : "NA";
            }
        }

        return _dicContInfo;
    };

    ///<summary>
    ///Function to return whether it is a SPOT segment
    ///Not just  spot segments any segment not having expiry date is considered SPOT too
    ///</summary>
    isSpotSegment(_MarketSegID, _sInstName) {
        let IsSpot = false;
        if (((_MarketSegID == clsConstants.C_V_NSEL_SPOT || _MarketSegID == clsConstants.C_V_NSEL_DERIVATIVES) && (_sInstName != clsConstants.C_S_INSTRUMENT_FUTCOM_TEXT)) ||
            ((_MarketSegID == clsConstants.C_V_MCX_DERIVATIVES) && _sInstName.startsWith("AUC")) ||
            (_MarketSegID == clsConstants.C_V_MSX_SPOT || _MarketSegID == clsConstants.C_V_NSX_SPOT || _MarketSegID == clsConstants.C_V_BSECDX_SPOT ||
                _MarketSegID == clsConstants.C_V_MCX_SPOT || _MarketSegID == clsConstants.C_V_NCDEX_SPOT ||
                _MarketSegID == clsConstants.C_V_BFX_SPOT || _MarketSegID == clsConstants.C_V_DGCX_SPOT || _MarketSegID == clsConstants.C_V_UCX_SPOT
            ) || (_sInstName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)) {
            IsSpot = true;
        }
        return IsSpot;
    }

    returnPrecisionForPrice(_MarketSegID, _Precision) {
        let sRetVal: any = '';
        if (_MarketSegID == clsConstants.C_V_NSX_DERIVATIVES || _MarketSegID == clsConstants.C_V_BSECDX_DERIVATIVES || _MarketSegID == clsConstants.C_V_NSX_SPOT || _MarketSegID == clsConstants.C_V_BSECDX_SPOT)
            sRetVal = 4;
        else
            sRetVal = _Precision;

        return sRetVal;
    }

    //Not Used
    //Function used within BulkOrderEntry
    getLoginAllowedExchangeName() {
        let arrExch = clsGlobal.User.loginAllowed.split('$');
        let arrExchName = [];

        for (let i = 0; i < arrExch.length; i++) {
            arrExchName.push(new fn_ExchangeObject(clsTradingMethods.getExchangeNameDesc(parseInt(arrExch[i], 10)), arrExch[i]));
        }

        return arrExchName;
    }

    //Not Used
    getExchangeAllowedExchangeName() {
        let arrExch = clsGlobal.User.viewAllowed.split('$');
        let arrExchName = [];

        for (let i = 0; i < arrExch.length; i++) {
            //if (clsGlobal.clsConstants.C_V_ADX_CASH == arrExch[i] || clsGlobal.clsConstants.C_V_DFM_CASH == arrExch[i])
            arrExchName.push(new fn_ExchangeObject(clsTradingMethods.getExchangeName(parseInt(arrExch[i], 10)), arrExch[i]));
        }

        return arrExchName;
    }

    //Not Used
    //Function used for Auction Status
    getAuctionData(_sExchName, _sLoginMode, objData) {
        try {
            let arrAucData = [];
            this.arrAuctionStatus = [];

            if (_sExchName == clsConstants.C_S_NSE_EXCHANGE_TEXT) {
                if (this.objNSE != null && this.objNSE != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
                    if (_sLoginMode == clsConstants.C_S_REFRESH_MODE) {
                        this.objNSE.sNSEAucSessionNo = objData[0].SessionNumber;
                        this.objNSE.sNSEAucStatus = objData[0].SessionStatus;

                        this.objNSE.sNSEAucSPOSSessionNo = objData[1].SessionNumber;
                        this.objNSE.sNSESPOSStatus = objData[1].SessionStatus;
                        arrAucData = this.objNSE.getAuctionStatusData();
                    }
                    else {
                        arrAucData = this.objNSE.getAuctionStatusData();
                    }
                }
                for (let i = 0; i < arrAucData.length; i++) {
                    this.arrAuctionStatus.push(new fn_AuctionStatus(arrAucData[i].SessionType, arrAucData[i].SessionNumber, arrAucData[i].SessionStatus));
                }
            }
            else if (_sExchName == clsConstants.C_S_MCX_EXCHANGE_TEXT) {
                if (this.objMCX != null && this.objMCX != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    if (_sLoginMode == clsConstants.C_S_REFRESH_MODE) {
                        this.objMCX.sMCXAUCBISessionNo = objData[0].SessionNumber;
                        this.objMCX.sMCXAUCBI = objData[0].SessionStatus;

                        this.objMCX.sMCXAUCSOSessionNo = objData[1].SessionNumber;
                        this.objMCX.sMCXAUCSO = objData[1].SessionStatus;

                        this.objMCX.sMCXAUCTBISessionNo = objData[2].SessionNumber;
                        this.objMCX.sMCXAUCTBI = objData[2].SessionStatus;

                        this.objMCX.sMCXAUCTSOSessionNo = objData[3].SessionNumber;
                        this.objMCX.sMCXAUCTSO = objData[3].SessionStatus;
                        arrAucData = this.objMCX.getAuctionStatusData();
                    }
                    else {
                        arrAucData = this.objMCX.getAuctionStatusData();
                    }
                }
                for (let i = 0; i < arrAucData.length; i++) {
                    this.arrAuctionStatus.push(new fn_AuctionStatus(arrAucData[i].SessionType, arrAucData[i].SessionNumber, arrAucData[i].SessionStatus));
                }
            }
            else if (_sExchName == clsConstants.C_S_NSEL_EXCHANGE_TEXT) {
                if (this.objNSEL != null && this.objNSEL != undefined && this.exchangeAllowed.getItem(clsConstants.C_V_NSEL_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
                    if (_sLoginMode == clsConstants.C_S_REFRESH_MODE) {
                        this.objNSEL.sNSELAUCBISessionNo = objData[0].SessionNumber;
                        this.objNSEL.sNSELAUCBI = objData[0].SessionStatus;

                        this.objNSEL.sNSELAUCSOSessionNo = objData[1].SessionNumber;
                        this.objNSEL.sNSELAUCSO = objData[1].SessionStatus;

                        this.objNSEL.sNSELAUCTBISessionNo = objData[2].SessionNumber;
                        this.objNSEL.sNSELAUCTBI = objData[2].SessionStatus;

                        this.objNSEL.sNSELAUCTSOSessionNo = objData[3].SessionNumber;
                        this.objNSEL.sNSELAUCTSO = objData[3].SessionStatus;
                        arrAucData = this.objNSEL.getAuctionStatusData();
                    }
                    else {
                        arrAucData = this.objNSEL.getAuctionStatusData();
                    }
                }
                for (let i = 0; i < arrAucData.length; i++) {
                    this.arrAuctionStatus.push(new fn_AuctionStatus(arrAucData[i].SessionType, arrAucData[i].SessionNumber, arrAucData[i].SessionStatus));
                }
            }
        }
        catch (e) {


        }

        return this.arrAuctionStatus;
    }

    // Initialize clsGlobal object of Exchange manager
    initializeExchManager() {
        try {
            //Attention Angular
            //clsGlobal.ExchManager = new fn_ExchManager();
            //clsGlobal.ReportManager = new fn_ReportManager();
            ////Fill up the Masters
            this.fn_FillMasters();
            //this.fn_FillUserPreference();
        }
        catch (e) {


        }
    }

    fn_FillMasters() {
        try {
            if (clsGlobal.User.loginAllowed > 0) {
                //let _lstLoginAllowedVal = clsGlobal.User.loginAllowed;//.split('$');
                let _lstLoginAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.loginAllowed);
                this.fillLoginExchangeAllowedDictionary(_lstLoginAllowedVal, clsConstants.C_S_TAG_LOGINALLOWED);
            }

            if (clsGlobal.User.viewAllowed > 0) {
                let _lstexchangeAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.viewAllowed);// clsGlobal.User.exchangeAllowed.split('$');
                this.fillLoginExchangeAllowedDictionary(_lstexchangeAllowedVal, clsConstants.C_S_TAG_EXCHANGEALLOWED);
            }

            if (clsGlobal.User.marginPlusAllowedVal > 0) {
                let _lstMarginPlusAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.marginPlusAllowedVal);//clsGlobal.User.marginPlusAllowedVal.split('$');
                this.fillLoginExchangeAllowedDictionary(_lstMarginPlusAllowedVal, clsConstants.C_V_TAG_MARGINPLUSALLOWED.toString());
            }

            //To be filled when user has successfully logged in
            if (this.loginAllowed != null && this.loginAllowed.Count() > 0) {
                this.fillExchangeMaster();
                this.fillOEDictionaries();

                //Call Init function of ExchangeManager
                this.init();
            }
        }
        catch (e) {

        }
    }

    fillLoginAllowed() {

        if (clsGlobal.User.loginAllowed > 0) {
            //let _lstLoginAllowedVal = clsGlobal.User.loginAllowed;//.split('$');
            let _lstLoginAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.loginAllowed);
            this.fillLoginExchangeAllowedDictionary(_lstLoginAllowedVal, clsConstants.C_S_TAG_LOGINALLOWED);
        }

        if (clsGlobal.User.viewAllowed > 0) {
            let _lstexchangeAllowedVal = clsTradingMethods.getAllowedSegmentList(clsGlobal.User.viewAllowed);// clsGlobal.User.exchangeAllowed.split('$');
            this.fillLoginExchangeAllowedDictionary(_lstexchangeAllowedVal, clsConstants.C_S_TAG_EXCHANGEALLOWED);
        }
    }



    ///Dhiraj
    fn_FillUserPreference() {
        let _sbRequest = new StringBuilder();
        _sbRequest.Append(clsConstants.C_V_TAG_USERCODE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.userCode + clsConstants.C_S_FIELD_DELIMITER);
        _sbRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_EQUAL_TO_STR + clsGlobal.User.SITemplateId);
        //let _strRequest = _sbRequest.toString() + '/' + clsGlobal.User.OCToken;
        //clsCommonMethods.AjaxCall(clsGlobal.URL_NETNETWCF, 'GetUserPreferencesForApp', _strRequest, fn_GetUserPreferencesForApp, objInit.SvcError, false);

    }

    populateValidityForSpread = function (_MktSegmentID,IsSpread) {
        try {
            // First get the Exchange object and assign it in to current object...
            //CurrentObj = _selfEM.GetCurrentExchange(_ExchName);
            this.arrValidityForSpread = this.getSpreadMultiLegValidity(_MktSegmentID, IsSpread);
            return this.arrValidityForSpread;
        }
        catch (e) {
            //<JasobNoObfs>
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'PopulateValidity()', 'tr_ExchManager.js', '');
            //</JasobNoObfs>
            return undefined;
        }
    }

    getSpreadMultiLegValidity = function (_MktSegmentID, _IsSpread) {
        var ArrValidity = [];

        try {
            if (_IsSpread == 1) {
                if(_MktSegmentID != clsConstants.C_V_MAPPED_MCX_DERIVATIVES)
                ArrValidity.push(clsConstants.C_S_VALUE_DAY);

                ArrValidity.push(clsConstants.C_S_VALUE_IOC);
            }
            else {
                ArrValidity.push(clsConstants.C_S_VALUE_IOC);

                if (_MktSegmentID == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES || _MktSegmentID == clsConstants.C_V_MAPPED_BSE_DERIVATIVES) {
                    ArrValidity.push(clsConstants.C_S_VALUE_AON);
                }
            }
            return ArrValidity;
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetSpreadMultiLegValidity()', 'tr_ExchManager.js', '');
            return undefined;
        }
    }

    ///Dhiraj
    // fn_GetUserPreferencesForApp(objResponse){
    //     try {
    //         if (response.status == true) {
    //             let result = JSON.parse(response.result.message);


    //             let MktPrefDet: any = {};
    //             MktPrefDet.nDefaultProfileId = result[0][0].sDefaultWatchList;
    //             //ArrMktPrefDet.push(MktPrefDet);

    //             let _dcOrderPref = new Dictionary<any>();
    //             for (let i = 0; i < result[0].length; i++) {
    //                 _dcOrderPref.Add(result[0][i].sExchangeName, result[0][i]);
    //             }

    //             clsGlobal.User.orderPrefDic = _dcOrderPref;
    //             clsGlobal.User.marketWatchPerfDetail = MktPrefDet;
    //         }
    //     } catch (error) {

    //     }
    // }
}


export class fn_ExchangeObject {
    Name: any;
    ID: any;

    constructor(name, MktSegId) {
        this.Name = name;
        this.ID = MktSegId;
    }
}


export class fn_AuctionStatus {
    SessionType: any;
    SessionNumber: any;
    SessionStatus: any;

    constructor(val1, val2, val3) {
        this.SessionType = val1;
        this.SessionNumber = val2;
        this.SessionStatus = val3;
    }

}

export class fn_MktStatus {
    Exchange: any;
    Status: any;
    Color: any;

    constructor(val1, val2, val3) {
        this.Exchange = val1;
        this.Status = val2;
        this.Color = val3;
    }

}


