import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsTradingMethods } from './clsTradingMethods';
import { clsCommonMethods } from './clsCommonMethods';
import { IKeyedCollection, Dictionary } from './clsCustomClasses';

export class clsNSE {

    arrInst = []; // Hash table for Holding Instruments for the selected / passed exchange (key would be ExchName and value would be list of instruments)
    arrOrderType = []; // List of Order Types allowed in this exchange
    arrProductType = []; // List of Product Types allowed in this exchange 
    arrValidity = []; // List of Validities allowed in this exchange
    arrError = []; //List of error messages 

    dcMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();//Dictonary for Market Seg
    dcDecimalLoc: IKeyedCollection<number> = new Dictionary<number>();
    dcMapMarketSegementId: IKeyedCollection<number> = new Dictionary<number>();
    dcEnableDisableFields: IKeyedCollection<boolean> = new Dictionary<boolean>();

    //Fields for MarketStatus
    //NSE EQ
    sNSECashnormalmkt: string = '-';
    sNSECashAMOmkt: string = '-';
    sNSESPOSStatus: string = '-';
    sNSEAucStatus: string = '-';
    sNSEAucSessionNo: string = '-';
    sNSEAucSPOSSessionNo: string = '6';
    sNSEStatus: string = '-';

    //NSE DERV
    sNSEDervNormalMkt: string = '-';
    sNSEDervAMOMkt: string = '-';
    sNSEDervExtendedMkt: string = '-';
    sNSEDervStatus: string = '-';

    //Following arrays required for lookup
    arrScripMaster = []; //array of Scrips for NSE
    arrSeries = [];
    arrExpiryDate = [];
    arrStrikePrice = [];
    arrOptionType = [];


    constructor(InstName) {
        this.arrInst = InstName.split('$'); // Split the Instrument string which is $ separated and create the instrument list...


        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT, clsConstants.C_V_NSE_CASH);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT, clsConstants.C_V_NSE_DERIVATIVES);

        // For FUTIVX - Changes
        if (clsGlobal.dConfigMaster.getItem("VERSION_IS_SP16B_DECODED") == clsConstants.C_S_OFF)
            this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT, clsConstants.C_V_NSE_DERIVATIVES);

        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT, clsConstants.C_V_NSE_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT, clsConstants.C_V_NSE_DERIVATIVES);
        this.dcMarketSegementId.Add(clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT, clsConstants.C_V_NSE_DERIVATIVES);

        this.dcDecimalLoc.Add(clsConstants.C_V_NSE_CASH.toString(), clsConstants.C_V_NORMAL_DECIMALLOCATOR);
        this.dcDecimalLoc.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), clsConstants.C_V_NORMAL_DECIMALLOCATOR);

        this.dcMapMarketSegementId.Add(clsConstants.C_V_NSE_CASH.toString(), clsConstants.C_V_MAPPED_NSE_CASH);
        this.dcMapMarketSegementId.Add(clsConstants.C_V_NSE_DERIVATIVES.toString(), clsConstants.C_V_MAPPED_NSE_DERIVATIVES);

        // Hash table for holding the enable property for all the Order Entry UI fields...

        this.dcEnableDisableFields.Add("hasBuySell", true);
        this.dcEnableDisableFields.Add("hasExchange", true);
        this.dcEnableDisableFields.Add("hasInstrument", true);
        this.dcEnableDisableFields.Add("hasSymbol", true);
        this.dcEnableDisableFields.Add("hasOrderType", true);

        this.dcEnableDisableFields.Add("hasQty", true);
        this.dcEnableDisableFields.Add("hasPrice", true);
        this.dcEnableDisableFields.Add("hasDiscQty", true);
        this.dcEnableDisableFields.Add("hasTriggerPrice", true);
        this.dcEnableDisableFields.Add("hasProductType", true);
        this.dcEnableDisableFields.Add("hasValidity", true);
        this.dcEnableDisableFields.Add("hasDay", true);

        this.dcEnableDisableFields.Add("hasSeries", true);
        this.dcEnableDisableFields.Add("hasOptionType", true);
        this.dcEnableDisableFields.Add("hasExpire", true);
        this.dcEnableDisableFields.Add("hasProdPer", true);
        this.dcEnableDisableFields.Add("hasStrikePrice", true);
        this.dcEnableDisableFields.Add("hasCOL", true);
        this.dcEnableDisableFields.Add("hasCOLEnabled", clsGlobal.isNSEFAOCOLAllowed);
        this.dcEnableDisableFields.Add("hasCutOff", false);
    }


    // Function to Enable / Disable the UI Elements property based on the the instument...
    enableDisable(InstName) {
        try {
            // Case for EQ Segment....
            if (InstName == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                // For NSE Cash Series,Day & Disc Qty will be in enabled mode
                this.dcEnableDisableFields.Add("hasSeries", true);
                // _selfNSE.dcEnableDisableFields["hasDiscQty",true;
                // _selfNSE.dcEnableDisableFields["hasDay",true;

                // The following will be in disabled mode...
                this.dcEnableDisableFields.Add("hasOptionType", false);
                this.dcEnableDisableFields.Add("hasExpire", false);
                this.dcEnableDisableFields.Add("hasProdPer", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", false);
                this.dcEnableDisableFields.Add("hasCOL", false);
            }
            // Case for Future....
            else if (InstName == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT ||
                InstName == clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT ||
                InstName == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT ||
                InstName == clsConstants.C_S_INSTRUMENT_FUTCUR_TEXT ||
                InstName == clsConstants.C_S_INSTRUMENT_FUTINT_TEXT) {

                this.dcEnableDisableFields.Add("hasExpire", true);

                // The following will be in disabled mode for NSE Future
                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasStrikePrice", false);
                this.dcEnableDisableFields.Add("hasOptionType", false);
                this.dcEnableDisableFields.Add("hasProdPer", false);
                this.dcEnableDisableFields.Add("hasDiscQty", false);
                this.dcEnableDisableFields.Add("hasDay", false);
                this.dcEnableDisableFields.Add("hasCOL", true);
            }
            // Case for Options....
            else {
                this.dcEnableDisableFields.Add("hasStrikePrice", true);
                this.dcEnableDisableFields.Add("hasOptionType", true);
                this.dcEnableDisableFields.Add("hasExpire", true);

                // The following will be in disabled mode for NSE Options...
                this.dcEnableDisableFields.Add("hasSeries", false);
                this.dcEnableDisableFields.Add("hasProdPer", false);
                this.dcEnableDisableFields.Add("hasDiscQty", false);
                this.dcEnableDisableFields.Add("hasDay", false);
                this.dcEnableDisableFields.Add("hasCOL", true);
            }
        }
        catch (e) {

        }
        // return the dictionary with the values based on the instrument...
        return this.dcEnableDisableFields;
    }

    populateValidity(Validity) {
        try {
            this.arrValidity = Validity.split('$');
        }
        catch (e) {

            //Global.LogManager.WriteLog('Exception: ' + e.message, 'PopulateValidity', 'NSE.js', '');

        }
    }

    // Split the Product Types string and populate the array...
    populateProductTypes(ProductTypes) {
        try {
            this.arrProductType = ProductTypes.split('$');
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'PopulateProductTypes', 'NSE.js', '');          
        }
    }

    // Split the Product Types string and populate teh array...
    populateOrderTypes = function (OrderTypes) {
        try {
            this.arrOrderType = OrderTypes.split('$');
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'PopulateOrderTypes', 'NSE.js', '');    
        }
    }


    // Get the details for the selected Order Type
    getDetailsForOrderType(OrderTypes, InstName) {
        try {
            if (OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_TEXT ||
                OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
                this.dcEnableDisableFields.Add("hasTriggerPrice", false);
                if (InstName == (clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT))
                    this.dcEnableDisableFields.Add("hasDiscQty", false);
                else
                    this.dcEnableDisableFields.Add("hasDiscQty", true);

                //if (OrderTypes == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
                //   this.dcEnableDisableFields.Add("hasPrice",false;
            }
            else if (OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                OrderTypes == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                this.dcEnableDisableFields.Add("hasTriggerPrice", true);
                this.dcEnableDisableFields.Add("hasDiscQty", false);
            }
            else {
                this.dcEnableDisableFields.Add("hasTriggerPrice", false);
                if (InstName == (clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT) ||
                    InstName == (clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT))
                    this.dcEnableDisableFields.Add("hasDiscQty", false);
                else
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
            }
        }
        catch (e) {

            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForOrderType', 'NSE.js', '');

        }
        return this.dcEnableDisableFields;
    }


    // Get the details for the selected Validity
    getDetailsForValidity(Validity, Instrument, OrderType) {
        try {
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                this.dcEnableDisableFields.Add("hasDay", true);
            }
            else {
                this.dcEnableDisableFields.Add("hasDay", false);
            }

            if (Validity == clsConstants.C_S_VALUE_IOC) {
                this.dcEnableDisableFields.Add("hasDiscQty", false);
            }
            else {
                if (Instrument == (clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT) ||
                    Instrument == (clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT) ||
                    Instrument == (clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) ||
                    Instrument == (clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT) ||
                    Instrument == (clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT) ||
                    (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT && (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)))
                    this.dcEnableDisableFields.Add("hasDiscQty", false);
                else
                    this.dcEnableDisableFields.Add("hasDiscQty", true);
            }

            if (Instrument == (clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT) ||
                Instrument == (clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT) ||
                Instrument == (clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) ||
                Instrument == (clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT) ||
                Instrument == (clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT)) {
                if (Validity == clsConstants.C_S_VALUE_DAY) {
                    this.dcEnableDisableFields.Add("hasCOL", true);
                }
                else {
                    this.dcEnableDisableFields.Add("hasCOL", false);
                }
            }
        }
        catch (e) {

            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForValidity', 'NSE.js', '');

        }
        return this.dcEnableDisableFields;
    }


    // Get the details of MktProtPerc, This Exchange doesn't support this functionality hence returning default values
    getDetailsForMktProtPerc(MapMarketSegmentId, Price, MarketSegmentId, MPPrice, ProdType) {
        var ProtPerc = '', ProtPercOrderPref = '';
        try {
            if ((ProdType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && MPPrice == 0)) {
                // if (clsGlobal.User.OrderPrefDic[MarketSegmentId].sPrefType == 'USER')
                //     ProtPercOrderPref = clsGlobal.User.OrderPrefDic[MarketSegmentId].nProtPerc;
                this.dcEnableDisableFields.Add("hasProdPer", true);
            }
            else {
                this.dcEnableDisableFields.Add("hasProdPer", false);
            }
        }
        catch (e) {

            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetDetailsForMktProtPerc', 'NSE.js', '');

        }
        //TODO
        return [this.dcEnableDisableFields, ProtPerc, ProtPercOrderPref];

    }


    // Function to Validate the scripdetails...
    validateScripDetails(dcLookupDetails) {
        this.arrError = [];
        try {
            //var Global.dMsgMaster = new fn_HashTable();
            // Remove the old errors...
            //var Exchange = dcLookupDetails["SelExchange"] == undefined ? '' : dcLookupDetails["SelExchange"];
            var Instrument = dcLookupDetails["SelInstrument"] == undefined ? '' : dcLookupDetails["SelInstrument"];
            //var MarketSegmentId = dcLookupDetails["MarketSegmentId"] == undefined ? '' : dcLookupDetails["MarketSegmentId"];

            var Symbol = dcLookupDetails["SelSymbol"] == undefined ? '' : dcLookupDetails["SelSymbol"];
            var Series = dcLookupDetails["SelSeries"] == undefined ? '' : dcLookupDetails["SelSeries"];
            var StrikePrice = dcLookupDetails["SelStrikePrice"] == undefined ? '' : dcLookupDetails["SelStrikePrice"];
            var OptionType = dcLookupDetails["SelOptionType"] == undefined ? '' : dcLookupDetails["SelOptionType"];
            var ExpiryDate = dcLookupDetails["SelExpDate"] == undefined ? '' : dcLookupDetails["SelExpDate"];

            //var MarketLot = dcLookupDetails["SelScripMarketLot"] == undefined ? '' : dcLookupDetails["SelScripMarketLot"];
            //var DecimalLocator = dcLookupDetails["SelScripDecimalloc"] == undefined ? '' : dcLookupDetails["SelScripDecimalloc"];

            //var PriceTick = dcLookupDetails["SelScripPriceTick"] == undefined ? '' : dcLookupDetails["SelScripPriceTick"];
            //var TokenNo = dcLookupDetails["SelScripToken"] == undefined ? '' : dcLookupDetails["SelScripToken"];

            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            // Validation for Cash Market...
            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                if (Series.length == 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL27"));
                if (ExpiryDate.length != 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL28"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL29"));
                if (OptionType.length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL30"));
            }

            //Case for NSE FUTIDX /  NSE FUTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
            }

            //Case for NSE OPTIDX / NSE OPTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().length == 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.length == 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                var regSymbol = new RegExp("([A-Za-z0-9-&*]$)");
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }

        }
        catch (e) {

            //Global.LogManager.WriteLog('Exception: ' + e.message, 'ValidateScripDetails', 'NSE.js', '');

        }
        return this.arrError;
    }

    addError(sErrElement, sErrMsg) {
        this.arrError.push(sErrMsg);
    }

    // Function to Validate the orders...
    validateOrder(dcOrderDetail) {
        // Remove the old errors...
        this.arrError = [];
        let dcOrderDetails: Dictionary<string> = dcOrderDetail as Dictionary<string>;

        try {
            //let Exchange = dcOrderDetails.getItem("SelExchange") == undefined ? '' : dcOrderDetails.getItem("SelExchange");
            let Instrument = dcOrderDetails.getItem("SelInstrument") == undefined ? '' : dcOrderDetails.getItem("SelInstrument");
            let MarketSegmentId: any = dcOrderDetails.getItem("MarketSegmentId") == undefined ? '' : dcOrderDetails.getItem("MarketSegmentId");
            let Validity = dcOrderDetails.getItem("SelValidity") == undefined ? '' : dcOrderDetails.getItem("SelValidity");
            let ProductType = dcOrderDetails.getItem("SelProduct") == undefined ? '' : dcOrderDetails.getItem("SelProduct");

            let OrderType = dcOrderDetails.getItem("SelOrderTypes") == undefined ? '' : dcOrderDetails.getItem("SelOrderTypes");
            let OrderSide = dcOrderDetails.getItem("SelOperation") == undefined ? '' : dcOrderDetails.getItem("SelOperation");
            let Symbol = dcOrderDetails.getItem("SelSymbol") == undefined ? '' : dcOrderDetails.getItem("SelSymbol");
            let Series = dcOrderDetails.getItem("SelSeries") == undefined ? '' : dcOrderDetails.getItem("SelSeries");
            let StrikePrice = dcOrderDetails.getItem("SelStrikePrice") == undefined ? '' : dcOrderDetails.getItem("SelStrikePrice");

            let OptionType = dcOrderDetails.getItem("SelOptionType") == undefined ? '' : dcOrderDetails.getItem("SelOptionType");
            let ExpiryDate = dcOrderDetails.getItem("SelExpire") == undefined ? '' : dcOrderDetails.getItem("SelExpire");
            let ProtPerc = dcOrderDetails.getItem("SelProdPer") == undefined ? '0' : dcOrderDetails.getItem("SelProdPer");
            let Quantity: any = dcOrderDetails.getItem("SelQty") == undefined ? 0 : dcOrderDetails.getItem("SelQty");
            let Price: any = dcOrderDetails.getItem("SelPrice") == undefined ? '' : dcOrderDetails.getItem("SelPrice");

            let DiscQty: any = dcOrderDetails.getItem("SelDiscQty") == undefined ? '' : dcOrderDetails.getItem("SelDiscQty");
            let TriggerPrice: any = dcOrderDetails.getItem("SelTriggerPrice") == undefined ? '' : dcOrderDetails.getItem("SelTriggerPrice");
            let Days = dcOrderDetails.getItem("SelDay") == undefined ? '' : dcOrderDetails.getItem("SelDay");
            let MarketLot = dcOrderDetails.getItem("SelMarketLot") == undefined ? '' : dcOrderDetails.getItem("SelMarketLot");
            let DecimalLocator: any = dcOrderDetails.getItem("SelDecimalloc") == undefined ? '' : dcOrderDetails.getItem("SelDecimalloc");

            let PriceTick = dcOrderDetails.getItem("SelPriceTick") == undefined ? '' : dcOrderDetails.getItem("SelPriceTick");
            let TokenNo = dcOrderDetails.getItem("SelToken") == undefined ? '' : dcOrderDetails.getItem("SelToken");

            let SPOSType = dcOrderDetails.getItem("SPOS") == undefined ? '' : dcOrderDetails.getItem("SPOS");
            let MarketStatus = dcOrderDetails.getItem("MarketStatus") == undefined ? '' : dcOrderDetails.getItem("MarketStatus");
            let ModifyFlag = dcOrderDetails.getItem("ModifyFlag") == undefined ? false : dcOrderDetails.getItem("ModifyFlag");

            let MPSuccessFailure = dcOrderDetails.getItem("MPSuccessFailure") == undefined ? false : dcOrderDetails.getItem("MPSuccessFailure");
            let MPLimitPriceLowRange = dcOrderDetails.getItem("MPLimitPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("MPLimitPriceLowRange");
            let MPLimitPriceHighRange = dcOrderDetails.getItem("MPLimitPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("MPLimitPriceHighRange");
            let MPTriggerPriceLowRange = dcOrderDetails.getItem("MPTriggerPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPriceLowRange");
            let MPTriggerPriceHighRange = dcOrderDetails.getItem("MPTriggerPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPriceHighRange");

            let MPTradingAllowed: any = dcOrderDetails.getItem("MPTradingAllowed") == undefined ? '' : dcOrderDetails.getItem("MPTradingAllowed");
            let MPOrderType = dcOrderDetails.getItem("MPOrderType") == undefined ? '' : dcOrderDetails.getItem("MPOrderType");
            let MPPrice: any = dcOrderDetails.getItem("MPPrice") == undefined ? '' : dcOrderDetails.getItem("MPPrice");
            let MPTriggerPrice: any = dcOrderDetails.getItem("MPTriggerPrice") == undefined ? '' : dcOrderDetails.getItem("MPTriggerPrice");

            let ProfitOrderPrice: any = dcOrderDetails.getItem("ProfitOrderPrice") == undefined ? '' : dcOrderDetails.getItem("ProfitOrderPrice");
            let TrailingSL = dcOrderDetails.getItem("TrailingSL") == undefined ? '' : dcOrderDetails.getItem("TrailingSL");
            let SLJumpPrice: any = dcOrderDetails.getItem("SLJumpPrice") == undefined ? '' : dcOrderDetails.getItem("SLJumpPrice");
            let LTPJumpPrice: any = dcOrderDetails.getItem("LTPJumpPrice") == undefined ? '' : dcOrderDetails.getItem("LTPJumpPrice");
            let ProfitPriceLowRange: any = dcOrderDetails.getItem("ProfitPriceLowRange") == undefined ? '' : dcOrderDetails.getItem("ProfitPriceLowRange");
            let ProfitPriceHighRange: any = dcOrderDetails.getItem("ProfitPriceHighRange") == undefined ? '' : dcOrderDetails.getItem("ProfitPriceHighRange");
            let MPLTP: any = dcOrderDetails.getItem("MPLTP") == undefined ? '' : dcOrderDetails.getItem("MPLTP");
            let BOModifyTerms: any = dcOrderDetails.getItem("BOModifyTerms") == undefined ? '' : dcOrderDetails.getItem("BOModifyTerms");
            let UnderlyingLTP: any = dcOrderDetails.getItem("UnderlyingLTP") == undefined ? '' : dcOrderDetails.getItem("UnderlyingLTP");
            //let bAMO = dcOrderDetails.getItem("AMO") == undefined ? false : dcOrderDetails.getItem("AMO");
            //let OriginalOrdType = dcOrderDetails.getItem("OriginalOrderType") == undefined ? '' : dcOrderDetails.getItem("OriginalOrderType");
            //////////////////////// Primary Validations////////////////////////////////

            // Validation for Symbol
            if (Symbol.length == 0) {
                this.addError("Symbol", clsGlobal.dMsgMaster.getItem("NNSL26"));
            }

            // Validation for Cash Market...
            if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                if (Series.length == 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL27"));
                if (ExpiryDate.toString().length != 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL28"));
                if (StrikePrice.toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL29"));
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL30"));
                if (isNaN(parseFloat(ProtPerc)))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL31"));
            }

            /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Protection Percent validation for bracket order entry> **/
            if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                if ((MPPrice == 0 || MPPrice == undefined || MPPrice == '') &&
                    (parseFloat(ProtPerc) == 0 || ProtPerc == undefined || ProtPerc == '')) {
                    this.addError("ProtPerc", 'Please Enter Protection Percent');
                }
            }

            //Case for NSE FUTIDX /  NSE FUTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_FUTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_FUTIVX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_FUTSTK_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.toString().length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().toString().length > 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.toString().length != 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
                if (isNaN(parseFloat(ProtPerc)))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL31"));
            }

            //Case for NSE OPTIDX / NSE OPTSTK 
            if (Instrument == clsConstants.C_S_INSTRUMENT_OPTIDX_TEXT ||
                Instrument == clsConstants.C_S_INSTRUMENT_OPTSTK_TEXT) {
                if (Series.length != 0)
                    this.addError("Series", clsGlobal.dMsgMaster.getItem("NNSL32"));
                if (ExpiryDate.toString().length == 0)
                    this.addError("ExpiryDate", clsGlobal.dMsgMaster.getItem("NNSL33"));
                if (StrikePrice.toString().length == 0)
                    this.addError("StrikePrice", clsGlobal.dMsgMaster.getItem("NNSL34"));
                if (OptionType.toString().length == 0)
                    this.addError("OptionType", clsGlobal.dMsgMaster.getItem("NNSL35"));
                if (isNaN(parseFloat(ProtPerc)))
                    this.addError("ProtPerc", clsGlobal.dMsgMaster.getItem("NNSL31"));
            }

            //Regex Validations
            //Symbol
            if (Symbol.length > 0) {
                let regSymbol = new RegExp('([A-Za-z0-9-&*]$)');
                if (!regSymbol.test(Symbol))
                    this.addError("Symbol1", clsGlobal.dMsgMaster.getItem("NNSL39"));
            }

            //Series
            if (Series.length > 0) {
                let regSeries = new RegExp("([A-Za-z0-9]$)");
                if (!regSeries.test(Series))
                    this.addError("Series1", clsGlobal.dMsgMaster.getItem("NNSL40"));
            }

            //Option Type
            if (OptionType.length > 0) {
                let regOptType = new RegExp("([A-Za-z]$)");
                if (!regOptType.test(OptionType))
                    this.addError("OptionType1", clsGlobal.dMsgMaster.getItem("NNSL42"));
            }

            //Days
            if (Days.length > 0) {
                let regDays = new RegExp("([1-7]$)");
                if (!regDays.test(Days))
                    this.addError("Days1", clsGlobal.dMsgMaster.getItem("NNSL43"));
            }

            // Product Type
            if (ProductType.length == 0) {
                this.addError("ProductType1", "Product Type cannot be blank");
            }

            //////////////////////// Secondary Validations ///////////////////////////
            // if (!HasErrors)

            // Market lot validation...
            if (MarketLot.length == 0)
                this.addError("MarketLot", "Market Lot cannot be empty");

            // Get the Decimal locator from the scrip if not there consider the defulat value...
            if (DecimalLocator == '' || DecimalLocator == 0)
                DecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
            let _AllowedDecimal: any = DecimalLocator.toString().length - 1;

            let PriceinPaise = 0;
            let TrigPriceinPaise = 0;
            let decChkTrgPrice: any = 0;
            let decChkPrice = 0;
            // Lot based segment, so caption should be Lot...
            let DiscQtyCaption = "Disclosed " + clsConstants.CONST_LOT_CAPTION;
            let QtyCaption = clsConstants.CONST_LOT_CAPTION;

            // If it is eq then it is qty based segment, so caption should be qty...
            if (dcOrderDetails.getItem("SelInstrument") == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                DiscQtyCaption = "Disclosed " + clsConstants.CONST_QTY_CAPTION;
                QtyCaption = clsConstants.CONST_QTY_CAPTION;
            }

            let secondLegPriceCaption = 'Price';
            secondLegPriceCaption = ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT ? "SL Price" : secondLegPriceCaption;
            let decChkMPPrice = 0;

            //Quantity related Validations
            if (isNaN(Quantity)) {
                this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption);
            }
            else if (!isNaN(Quantity)) {

                if (Quantity <= 0 && (!(ModifyFlag && ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT))) {
                    this.addError("Quantity", clsGlobal.dMsgMaster.getItem("NNSL44") + QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL45"));
                }

                if (Quantity != 0 && Quantity != "") {
                    if (parseInt(Quantity) % parseInt(MarketLot) != 0) {
                        if (MarketLot != "999999999") {
                            if (TokenNo != "")
                                this.addError("Quantity1", clsGlobal.dMsgMaster.getItem("NNSL46") + MarketLot);
                        }
                    }

                    // Case to check Quantity should not have decimal character
                    if (Quantity.toString().indexOf('.') != -1)
                        this.addError("Quantity2", QtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));
                }
            }
            // Quantity related Validation ends here....


            //Disclosed Quantity related Validations
            //  Case to validate Disc Qty Entered. Here case has been checked for Disc LOT as well as Disc Qty.
            if (!isNaN(DiscQty))      //If Disc Qty has some value
            {
                if (DiscQty != 0 && DiscQty != "") {
                    if (!isNaN(Quantity))            //If Qty has some value
                    {
                        if (parseInt(DiscQty) > parseInt(Quantity))
                            this.addError("DiscQty", clsGlobal.dMsgMaster.getItem("NNSL44") + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL48") + QtyCaption);

                        /* Below here comparision is made between Disc Qty/LOT and Original Qty/LOT
                        as per Exchange/Instrument rules specified   */
                        if (Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT)          //Case: EQUITIES
                        {
                            if (DiscQty != 0) {
                                //For Equity Disc Qty cannot be less than 10% of Original Qty entered
                                if ((Quantity / 10) > DiscQty)
                                    this.addError("DiscQty1", clsGlobal.dMsgMaster.getItem("NNSL49"));
                            }
                        }
                        else {
                            //For Derivative segment (FUTIDX / FUTSTK / OPTIDX / OPTSTK) Disc Qty cannot be less than 100% of Original Qty                           
                            if (DiscQty != 0) {
                                if ((Quantity != DiscQty) && (DiscQty != 0))
                                    this.addError("DiscQty1", clsGlobal.dMsgMaster.getItem("NNSL51") + "Disc" + clsConstants.CONST_LOT_CAPTION + "The Disc" + clsConstants.CONST_LOT_CAPTION + clsGlobal.dMsgMaster.getItem("NNSL54") + clsConstants.CONST_LOT_CAPTION);
                            }
                        }
                    }

                    //Disc Qty / Lot not allowed for IOC order
                    if (Validity == clsConstants.C_S_VALUE_IOC && (!isNaN(DiscQty)))
                        this.addError("DiscQty2", DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL55"));

                    // Case to check Quantity should not have decimal character
                    if (DiscQty.toString().indexOf('.') != -1)
                        this.addError("DiscQty3", DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL47"));

                    if (parseInt(DiscQty) % parseInt(MarketLot) != 0) {
                        if (MarketLot != "999999999") {
                            if (TokenNo != "")
                                this.addError("DiscQty4", clsGlobal.dMsgMaster.getItem("NNSL57") + DiscQtyCaption + clsGlobal.dMsgMaster.getItem("NNSL58") + MarketLot);
                        }
                    }
                }
            }
            //Disclosed Quantity validations ends here.


            // Validations related to Price
            if (!isNaN(Price)) {
                if (Price < 0) {
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL59"));
                }
                if (Price != 0) {

                    decChkPrice = parseFloat(Price);

                    if (!(clsCommonMethods.DecDigits(decChkPrice.toString(), _AllowedDecimal)))
                        this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL61"));

                    PriceinPaise = parseInt(Math.round(parseFloat((Price * DecimalLocator).toString())).toString());

                    if (PriceinPaise % parseInt(PriceTick) != 0) {
                        if (TokenNo != "") {
                            this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                        }
                    }
                }
                // else {
                //     //If price is 0 and order type selected are RL/SL --> Show error message
                //     // if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)
                //     if (ProductType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                //         if (OrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT) //ashwinee  doubt for margin plus
                //             this.addError("Price", "Price cannot be zero for Limit order");
                //     }
                // }
            }
            // Validations related to Price Ends here

            //Additional validation for margin plus as the price field for MP is different
            if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && !isNaN(MPPrice)) {
                if (MPPrice < 0) {
                    this.addError("Price", clsTradingMethods.priceCanNotBeNegativeMsg(secondLegPriceCaption));
                }
                if (MPPrice != 0) {

                    decChkMPPrice = parseFloat(MPPrice);

                    if (!(clsCommonMethods.DecDigits(decChkMPPrice.toString(), _AllowedDecimal)))
                        this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL358").replace('{0}', secondLegPriceCaption).replace('{1}', _AllowedDecimal));

                    PriceinPaise = parseInt(Math.round(parseFloat((MPPrice * DecimalLocator).toString())).toString());

                    if (PriceinPaise % parseInt(PriceTick) != 0) {
                        if (TokenNo != "") {
                            this.addError("Price", clsTradingMethods.priceNotInPriceTickMsg(secondLegPriceCaption, PriceTick, true));
                        }
                    }
                }
                if (MPTradingAllowed === 1 && MPPrice == 0) {//In case the Margin Plus Trading Allowed is 1 then Limit order is mandatory
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL347"));
                }
                else if (MPTradingAllowed === 3 && MPPrice != 0) {//In case the Margin Plus Trading Allowed is 3 then Market order is mandatory
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL348"));
                }

                if ((parseFloat(MPPrice) < parseFloat(MPLimitPriceLowRange) || parseFloat(MPPrice) > parseFloat(MPLimitPriceHighRange)) && MPPrice != 0)
                    this.addError("Price", clsTradingMethods.priceOutOfRangeMsg(secondLegPriceCaption));
            }
            //Additional validation for margin plus as the price field for MP is different Ends here


            /* Validations to check TriggerPrice */
            //First validation of trigger price for margin plus as it has separate order type else for normal order
            if ((ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && MPOrderType === clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                if (isNaN(MPTriggerPrice))
                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL65"));

                if (!isNaN(MPTriggerPrice)) {
                    if (MPTriggerPrice == 0)
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL66"));
                    else {
                        decChkTrgPrice = parseFloat(MPTriggerPrice);

                        if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL68"));

                        TrigPriceinPaise = parseInt(Math.round(parseFloat((MPTriggerPrice * DecimalLocator).toString())).toString());

                        if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                            }
                        }

                        if (MPOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT && (parseFloat(MPTriggerPrice) < parseFloat(MPTriggerPriceLowRange) || parseFloat(MPTriggerPrice) > parseFloat(MPTriggerPriceHighRange)) && parseFloat(MPTriggerPrice) != 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL217"));

                        if (!isNaN(MPPrice)) {
                            /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                            other than Margin Plus. For Margin Plus case is vice versa  
                            Note: Case is viceversa only for fresh order
                            * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                            if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                //if (!ModifyFlag) //case for MarginPlus - Fresh Order//Commented as the side flips
                                //{
                                if ((decChkTrgPrice < decChkMPPrice) && decChkMPPrice != 0)
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL70"));
                                //}
                                //else {//case for MarginPlus - Modify Order
                                //    if ((decChkTrgPrice > decChkMPPrice) && decChkMPPrice != 0)
                                //        this.addError("TriggerPrice", Global.dMsgMaster["NNSL71"));
                                //}
                            }
                            /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                            other than Margin Plus. For Margin Plus case is vice versa  
                            Note: Case is viceversa only for fresh order
                            For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                            else//Sell side case
                            {
                                //if (!ModifyFlag)//case for MarginPlus - Fresh Order
                                //{
                                if (decChkTrgPrice > decChkMPPrice && decChkMPPrice != 0)
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL72"));
                                //}
                                //else {//case for MarginPlus - Modify Order
                                //    if (decChkTrgPrice < decChkMPPrice)
                                //        this.addError("TriggerPrice", Global.dMsgMaster["NNSL73"));
                                //}
                            }

                            //For Buy Bracket Order with First Leg Limit Price,SL trigger Price sohuld be less than Limit Price
                            //For Buy Bracket Order with First Leg market Price,SL trigger Price sohuld be less than LTP
                            //For Sell Bracket Order with First Leg Limit Price,SL trigger Price sohuld be greater than Limit Price
                            //For Sell Bracket Order with First Leg market Price,SL trigger Price sohuld be greater than LTP
                            if (ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    if (decChkPrice != 0) {
                                        if (decChkTrgPrice > decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL363").replace('{0}', 'Trigger Price'));
                                    }
                                    else {
                                        if (decChkTrgPrice > MPLTP)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL364").replace('{0}', 'Trigger Price'));
                                    }
                                }
                                else {
                                    if (decChkPrice != 0) {
                                        if (decChkTrgPrice < decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL365").replace('{0}', 'Trigger Price'));
                                    }
                                    else {
                                        if (decChkTrgPrice < MPLTP)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL366").replace('{0}', 'Trigger Price'));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {//In case of normal product type other than margin plus
                if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                    OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {

                    if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
                        if (Price == 0) {
                            this.addError("Price", "Price cannot be zero for Limit order");
                        }
                    }

                    if (isNaN(TriggerPrice))
                        this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL65"));

                    if (TriggerPrice < 0) {
                        this.addError("TriggerPrice", 'Please enter valid Trigger Price. Trigger Price cannot be negative.');
                    }

                    if (!isNaN(TriggerPrice)) {
                        if (TriggerPrice == 0)
                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL66"));
                        else {
                            decChkTrgPrice = parseFloat(TriggerPrice);

                            if (!(clsCommonMethods.DecDigits(decChkTrgPrice.toString(), _AllowedDecimal)))
                                this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL68"));

                            TrigPriceinPaise = parseInt(Math.round(parseFloat((TriggerPrice * DecimalLocator).toString())).toString());

                            if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
                                }
                            }
                            if (!isNaN(Price)) {
                                /*  For BUY side order Trigger Price should be less than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                * For MarginPlus modification order use original normal formula i.e. TrigPr < OrderPrice */
                                if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                                    if (ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag) //case for MarginPlus
                                    {
                                        if ((decChkTrgPrice < decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL70"));
                                    }
                                    else {
                                        if ((decChkTrgPrice > decChkPrice) && decChkPrice != 0)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL71"));
                                    }
                                }
                                /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
                                other than Margin Plus. For Margin Plus case is vice versa  
                                Note: Case is viceversa only for fresh order
                                For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
                                else                //Sell side case
                                {
                                    if (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT && !ModifyFlag)      //case for MarginPlus
                                    {
                                        if (decChkTrgPrice > decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL72"));
                                    }
                                    else {
                                        if (decChkTrgPrice < decChkPrice)
                                            this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL73"));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Validations to check TriggerPrice Ends here

            //Validations on OrderType, ProductType and Validity
            if (OrderType == clsConstants.C_S_ORDER_CALLAUCTION_TEXT) {
                if (Validity != clsConstants.C_S_VALUE_IOC) {
                    this.addError("OrderType2", clsGlobal.dMsgMaster.getItem("NNSL75"));
                }
            }

            //Case --> Only DAY validity allowed for MarginPlus order
            if (MPOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT && (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) && Validity != clsConstants.C_S_VALUE_DAY) {
                this.addError("Validity2", clsGlobal.dMsgMaster.getItem("NNSL76").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT));
            }

            //Case to check Days field when Validity selected is GTD
            if (Validity == clsConstants.C_S_VALUE_GTD) {
                if (Days.length == 0)
                    this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL77"));
                if (Days.length > 0) {
                    if (parseInt(Days) < 1 || parseInt(Days) > 7)
                        this.addError("Days", clsGlobal.dMsgMaster.getItem("NNSL78"));
                }
            }

            // Stop loss validations....
            if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_VALUE_IOC) {
                if (parseInt(MarketSegmentId) != clsConstants.C_V_NSE_DERIVATIVES)
                    this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL80"));
            }


            if ((OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) && Validity == clsConstants.C_S_ORDER_FOK)
                this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL81"));
            // Stop loss validations ends here....

            //If order type selected is CA then series must be SM
            //if (OrderType == clsConstants.C_S_ORDER_CALLAUCTION_TEXT) {
            //    if (Series.length > 0) {
            //        if (Series.toUpperCase() != clsConstants.C_S_SERIES_SM)
            //            this.addError("OrderType", Global.dMsgMaster["NNSL87"));
            //    }
            //}

            if (Series.length > 0 && Series.toUpperCase() === clsConstants.C_S_SERIES_SM && parseInt(MarketSegmentId) == clsConstants.C_V_NSE_CASH) {
                if (ProductType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                    this.addError("ProductType", clsGlobal.dMsgMaster.getItem("NNSL88").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT));
                }
                // if (OrderType != clsConstants.C_S_ORDER_CALLAUCTION_TEXT)//If  series is SM then order type selected must be CA 
                //     this.addError("OrderType", Global.dMsgMaster["NNSL87"));
            }


            if ((MarketStatus === clsConstants.C_S_AMO_TEXT) && (ProductType == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT)) {
                this.addError("ProductType", clsGlobal.dMsgMaster.getItem("NNSL91"));
            }
            if ((MarketStatus === clsConstants.C_S_AMO_TEXT) && (ProductType == clsConstants.C_S_PRODUCTTYPE_PTST_TEXT)) {
                this.addError("ProductType", clsGlobal.dMsgMaster.getItem("NNSL92"));
            }
            if ((MarketStatus === clsConstants.C_S_AMO_TEXT) && (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT)) {
                this.addError("ProductType", clsGlobal.dMsgMaster.getItem("NNSL93").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT));
            }


            ///Validations for Margin Plus
            if ((ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT || ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)) {
                if (!MPSuccessFailure) {
                    if (Instrument.startsWith('OPT') && parseFloat(UnderlyingLTP) <= 0)
                        this.addError("OrderEntry", clsTradingMethods.MPNotAllowedForUnderlyingLTPMsg(ProductType));
                    else
                        this.addError("OrderEntry", clsTradingMethods.MPNotAllowedForLTPMsg(ProductType, decChkPrice));
                }
                if (Validity != clsConstants.C_S_VALUE_DAY && Validity != clsConstants.C_S_VALUE_EOSESS)
                    this.addError("Validity", clsTradingMethods.MPNotAllowedForValidityMsg(ProductType));

                if ((Instrument === clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) && MarketStatus === clsConstants.C_S_PREOPENMARKET_TEXT)
                    this.addError("ProductType", "Order not allowed in this session");

                if (MPOrderType === clsConstants.C_S_ORDER_REGULARLOT_TEXT && MPPrice != 0)
                    this.addError("Price", "RL Limit order not allowed for Margin Plus");
            }

            // Validations carried out for SPOS
            if (parseInt(MarketSegmentId) == clsConstants.C_V_NSE_CASH) {
                if (SPOSType == "1") {
                    if (this.sNSESPOSStatus.toUpperCase() == "OPEN") {
                        if (OrderType != clsConstants.C_S_ORDER_REGULARLOT_TEXT)
                            this.addError("OrderType", clsGlobal.dMsgMaster.getItem("NNSL315"));

                        if (Validity != clsConstants.C_S_VALUE_DAY)
                            this.addError("Validity", clsGlobal.dMsgMaster.getItem("NNSL314"));


                        if (Price == 0)
                            this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL313"));

                        if (isNaN(DiscQty) || (DiscQty == 0) || (DiscQty == Quantity)) { }
                        else
                            this.addError("DiscQty", clsGlobal.dMsgMaster.getItem("NNSL312"));

                        if (ProductType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT)
                            this.addError("ProductType", clsGlobal.dMsgMaster.getItem("NNSL308"));
                    }
                }
            }
            //Validations carried out for SPOS End

            if (ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                let decChkProfitOrderPrice = 0;
                let decChkSLJumpPrice = 0;
                let decChkLTPJumpPrice = 0;

                //if (OrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || OrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || OrderType == clsConstants.C_S_ORDER_CALLAUCTION_TEXT)
                //    this.addError("OrderType", "Bracket order not allowed for stop loss order type");

                if (ModifyFlag && BOModifyTerms === 0)
                    this.addError("Price", clsGlobal.dMsgMaster.getItem("NNSL375"));

                //if (ProtPerc == 0) {
                //    if (decChkPrice == 0)
                //        this.addError("Price", Global.dMsgMaster["NNSL376"));
                //    //else if (decChkMPPrice == 0)
                //    //    this.addError("MPPrice", Global.dMsgMaster["NNSL377"));
                //}

                if (TrailingSL) {
                    if (!isNaN(SLJumpPrice)) {
                        if (SLJumpPrice == 0) {
                            this.addError("SLJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('SL Jump Price'));
                        }
                        if (SLJumpPrice != 0) {

                            decChkSLJumpPrice = parseFloat(SLJumpPrice);

                            if (!(clsCommonMethods.DecDigits(decChkSLJumpPrice.toString(), _AllowedDecimal)))
                                this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('SL Jump Price', _AllowedDecimal));

                            PriceinPaise = parseInt(Math.round(parseFloat((SLJumpPrice * DecimalLocator).toString())).toString());

                            if (PriceinPaise % parseInt(PriceTick) != 0) {
                                if (TokenNo != "") {
                                    this.addError("SLJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('SL Jump Price', PriceTick, true));
                                }
                            }
                        }
                    }

                    if (clsGlobal.isJumpBothLtpAndTrigPrice) {
                        if (!isNaN(LTPJumpPrice)) {
                            if (LTPJumpPrice == 0) {
                                this.addError("LTPJumpPrice", clsTradingMethods.PriceCanNotBeZeroMsg('LTP Jump Price'));
                            }
                            if (LTPJumpPrice != 0) {

                                decChkLTPJumpPrice = parseFloat(LTPJumpPrice);

                                if (!(clsCommonMethods.DecDigits(decChkLTPJumpPrice.toString(), _AllowedDecimal)))
                                    this.addError("SLJumpPrice", clsTradingMethods.priceNotInDecDigitsMsg('LTP Jump Price', _AllowedDecimal));

                                PriceinPaise = parseInt(Math.round(parseFloat((LTPJumpPrice * DecimalLocator).toString())).toString());

                                if (PriceinPaise % parseInt(PriceTick) != 0) {
                                    if (TokenNo != "") {
                                        this.addError("LTPJumpPrice", clsTradingMethods.priceNotInPriceTickMsg('LTP Jump Price', PriceTick, true));
                                    }
                                }

                                if (decChkSLJumpPrice > decChkLTPJumpPrice)
                                    this.addError("SLJumpPrice", clsGlobal.dMsgMaster.getItem("NNSL361"));
                            }
                        }
                    }
                }

                // Validations related to ProfitOrderPrice
                if (!isNaN(ProfitOrderPrice)) {
                    if (ProfitOrderPrice == 0) {
                        this.addError("ProfitOrderPrice", clsTradingMethods.PriceCanNotBeZeroMsg('Profit Order Price'));
                    }
                    if (ProfitOrderPrice != 0) {

                        decChkProfitOrderPrice = parseFloat(ProfitOrderPrice);

                        if (!(clsCommonMethods.DecDigits(decChkProfitOrderPrice.toString(), _AllowedDecimal)))
                            this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInDecDigitsMsg('Profit Order Price', _AllowedDecimal));

                        PriceinPaise = parseInt(Math.round(parseFloat((ProfitOrderPrice * DecimalLocator).toString())).toString());

                        if (PriceinPaise % parseInt(PriceTick) != 0) {
                            if (TokenNo != "") {
                                this.addError("ProfitOrderPrice", clsTradingMethods.priceNotInPriceTickMsg('Profit Order Price', PriceTick, true));
                            }
                        }

                        //profit order price validation with PPR
                        if ((decChkProfitOrderPrice < ProfitPriceLowRange || decChkProfitOrderPrice > ProfitPriceHighRange))
                            this.addError("ProfitOrderPrice", clsTradingMethods.priceOutOfRangeMsg('Profit Order Price'));

                        //For Buy Bracket Order with First Leg Limit Price,Profit Order Price sohuld be greater than Limit Price
                        //For Buy Bracket Order with First Leg market Price,Profit Order Price sohuld be greater than LTP
                        //For Sell Bracket Order with First Leg Limit Price,Profit Order Price sohuld be less than Limit Price
                        //For Sell Bracket Order with First Leg market Price,Profit Order Price sohuld be less than LTP
                        if (OrderSide == clsConstants.C_S_ORDER_BUY_TEXT) {
                            if (decChkPrice != 0) {
                                if (decChkProfitOrderPrice <= decChkPrice)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL365").replace('{0}', 'Profit Order Price'));
                            }
                            else {
                                if (decChkProfitOrderPrice <= MPLTP)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL366").replace('{0}', 'Profit Order Price'));
                            }
                        }
                        else {
                            if (decChkPrice != 0) {
                                if (decChkProfitOrderPrice >= decChkPrice)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL363").replace('{0}', 'Profit Order Price'));
                            }
                            else {
                                if (decChkProfitOrderPrice >= MPLTP)
                                    this.addError("ProfitOrderPrice", clsGlobal.dMsgMaster.getItem("NNSL364").replace('{0}', 'Profit Order Price'));
                            }
                        }
                    }
                }
            }


        } catch (error) {
            console.log(error);
        }
        return this.arrError;
    }

    populateMarketStatus(sMktSegData, sMarketType, sStatusFlag, sAucSessionNo) {
        try {
            if (sMktSegData == "1") {
                if (sMarketType == "1")
                    this.sNSECashnormalmkt = sStatusFlag;
                else if (sMarketType == "7")
                    this.sNSECashAMOmkt = sStatusFlag;
                else if (sMarketType == "6") {
                    if (sStatusFlag == "1")
                        this.sNSESPOSStatus = "Open";
                    else
                        this.sNSESPOSStatus = "Close";
                }
                else if (sMarketType == "12")        //NSE Call Auction
                {
                    if (sStatusFlag == "1")
                        this.sNSEAucStatus = "Open";
                    else
                        this.sNSEAucStatus = "Close";
                    this.sNSEAucSessionNo = sAucSessionNo;
                }
            }

            if (sMktSegData == "2") {
                if (sMarketType == "1")
                    this.sNSEDervNormalMkt = sStatusFlag;
                else if (sMarketType == "7")
                    this.sNSEDervAMOMkt = sStatusFlag;
                else if (sMarketType == "2")
                    this.sNSEDervExtendedMkt = sStatusFlag;
            }
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'PopulateMarketStatus', 'NSE.js', '');            
        }
    }


    getStatus(sMktSegData) {
        try {
            let sMktStatus = '';

            if (sMktSegData == clsConstants.C_V_NSE_CASH)
                sMktStatus = this.sNSEStatus = clsGlobal.ExchManager.getMktStatusDesc(this.sNSECashnormalmkt, this.sNSECashAMOmkt, "", sMktSegData);
            else if (sMktSegData == clsConstants.C_V_NSE_DERIVATIVES)
                sMktStatus = this.sNSEDervStatus = clsGlobal.ExchManager.getMktStatusDesc(this.sNSEDervNormalMkt, this.sNSEDervAMOMkt, this.sNSEDervExtendedMkt, sMktSegData);

            return sMktStatus;
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetStatus', 'NSE.js', '');            
        }
    }


    getAuctionStatusData() {
        let jsonobj = [];
        try {
            jsonobj.push({ "SessionType": "Call Auction", "SessionNumber": this.sNSEAucSessionNo, "SessionStatus": this.sNSEAucStatus })
            jsonobj.push({ "SessionType": "Call Auction 2", "SessionNumber": this.sNSEAucSPOSSessionNo, "SessionStatus": this.sNSESPOSStatus })
        }
        catch (e) {
            //Global.LogManager.WriteLog('Exception: ' + e.message, 'GetAuctionStatusData', 'NSE.js', '');            
        }
        return jsonobj;
    }


}