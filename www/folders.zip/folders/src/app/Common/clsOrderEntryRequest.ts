import { clsConstants } from './clsConstants';
import { clsGlobal } from './clsGlobal';
import { clsTradingMethods } from './clsTradingMethods';

export class clsOrderEntryRequest {

    constructor(scripDetail?: any) {
        if (scripDetail != undefined) {
            this.Exchange = scripDetail.ExchangeName;
            this.Instrument = scripDetail.InstrumentName;
            this.Symbol = scripDetail.Symbol;
            this.Series = scripDetail.Series;
            this.ExpDate = scripDetail.ExpiryDate.replaceAll("\\s+", "");
            this.StrikePrice = scripDetail.StrikePrice;
            this.OptionType = scripDetail.OptionType;
            this.MarketLot = scripDetail.MarketLot;
            this.PriceTick = scripDetail.PriceTick;
            this.DecimalLocator = scripDetail.DecimalLocator;
            this.MarketSegID = scripDetail.ScripDet.MktSegId;
            this.MapMktSegID = clsTradingMethods.getMappedMarketSegmentId(scripDetail.ScripDet.MktSegId).toString();
            this.TokenNo = scripDetail.ScripDet.Token;
            this.SPOSType = scripDetail.SPOS;
            this.POSType = scripDetail.POS;
            this.IsSpread = scripDetail.Spread == "1" ? true : false;
            this.FIILimit = scripDetail.FIILimit;
            this.NRILimit = scripDetail.NRILimit;
        }
    }

    OrderSide = '';
    Exchange = '';
    Instrument = '';
    Symbol = '';
    Series = '';
    ExpDate = '';
    StrikePrice = '';
    OptionType = '';
    OrderType = '';
    Qty: any = '';
    Price: any;
    BuySell: any;
    BuyPrice: any;
    SellPrice: any;
    BuyQty = '';
    SellQty = '';

    DiscQty: any = '';
    TriggerPrice: any = '';
    ProductType = '';
    Validity: any = '';
    Days: any = '';
    ProtPerc: any = '';
    DecimalLocator: any = 100;
    InstrumentID = '';
    MapMktSegID: any = '';
    MarketSegID: any;
    ClientOrderNumber: any = '';
    MarketLot = '';
    PriceTick: any = '';
    TokenNo = '';
    AMOID = '';
    ExchangeOrderNo = '';
    GatewayOrderNo = '';
    OrderTime = '';
    ParticipantID = '';
    ParticipantIDTag = '';
    MarketStatus = '';
    PageSource = '';
    ModifyFlag = '';
    CancelFlag = '';
    OrderStatus = '';

    OrigQty: any = '';
    Spread: any;
    MPBasePrice = '';
    MPExpiryValue = '';
    MPStrikePriceValue = '';
    MPMFFlag = '';
    SPOSType = '';
    POSType = '';
    MPFirstLegPrice = 0;
    TimeField = '';
    IsSpread = false;
    FIILimit = '';
    NRILimit = '';
    isSOR = false;
    COL = 1;

    ProfitOrderPrice = '';
    TrailingSL: any = false;
    SLJumpPrice = '';
    LTPJumpPrice = '';
    SLOrderPrice: any;
    SLTriggerPrice = '';
    BracketOrderId = '';
    LegIndicator: any = '';
    BOGatewayOrderNo = '';
    BOModifyTerms = '';
    SLOrderType = '';
    SelMargin = '';
    RecoId = '';
    LTP = '';
    ClosePrice = '';
    BracketOrderModifyBit = '';
    OFSMargin = '';
    RecoPrice = '';
    RecoSLPrice = '';
    RecoSQPrice = '';
    isPrivateOrder: boolean = false;
    OldPrivateValue: any = '';
    DualLUT: any = '';
    SORID: any = '';

    public static populateSelectedOE(objReq) {
        var _OEJSONReq: any = [];

        var _sBuySell = '', _sExchName = '', _sInstName = '', _sSymbol = '', _sSeries = '', _sExpDate = '', _sStrikePrice = '', _sOptionType = '';
        var _sQty = '', _sMarketLot = '', _sPrice = '', _sPriceTick = '', _sDecimalLocator = '', _sMktSegID = '', _sMapMktSegID = '', _sOrderType = '';
        var _sTokenNo = '', _sPageSource = '', _sSPOSType = '', _sPOSType = '', _sSpread: any = false, _sFIILimit = '', _sNRILimit = '';
        var _sSellPrice = '', _sBuyPrice = '', _sDiscQty = '', _sTrigPrice = '', _sProductType = '', _sValidity = '', _sGTD = '';
        var _GatewayOrderNo, _ClientOrderNumber, _ExchangeOrderNo, _OrderTime, _sBuyQty, _sSellQty, _sLTP, _sClosePrice, _sCOL = '', QtyOpt: any;
        var _SLJumpPrice, _LTPJumpPrice, _SLOrderPrice, _SLTriggerPrice, _ProfitOrderPrice, _BracketOrderId, _LegIndicator, _BOGatewayOrderNo, _BracketOrderModifyBit, _SLOrderType, _ProtPerc,
            _OFSMargin;
        var _sRecoPrice = '', _sRecoSLPrice = '', _sRecoSQPrice = '', _sRecoID = '', _sLastPendingQty = '', _sLastTradedQty = '';

        _sBuySell = objReq.OrderSide;
        _sExchName = objReq.Exchange.Trim();
        _sInstName = objReq.Instrument
        _sSymbol = objReq.Symbol.Trim();
        if (objReq.Series != "undefined")
            _sSeries = objReq.Series.Trim();
        if (objReq.ExpDate != "undefined")
            _sExpDate = objReq.ExpDate.Trim();
        if (objReq.StrikePrice != "undefined")
            _sStrikePrice = objReq.StrikePrice.Trim();

        if (objReq.OptionType != "undefined") {
            if (objReq.OptionType == clsConstants.C_S_ORDER_REGULARLOT_TEXT || objReq.OptionType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT || objReq.OptionType == "RLMKT")
                _sOptionType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
            else if (objReq.OptionType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || objReq.OptionType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || objReq.OptionType == "RLMKT")
                _sOptionType = clsConstants.C_S_ORDER_STOPLOSS_TEXT;
            else
                _sOptionType = objReq.OptionType.Trim();
        }

        _sMarketLot = objReq.MarketLot;
        _sQty = objReq.Qty;
        _sPriceTick = objReq.PriceTick;
        _sSellPrice = objReq.SellPrice;
        _sBuyPrice = objReq.BuyPrice;
        _sDecimalLocator = objReq.DecimalLocator;
        _sMktSegID = objReq.MarketSegID;
        _sMapMktSegID = objReq.MapMktSegID;
        _sTokenNo = objReq.TokenNo;
        _sSPOSType = objReq.SPOSType;
        _sPOSType = objReq.POSType;
        _sSpread = objReq.IsSpread;
        _sFIILimit = objReq.FIILimit;
        _sNRILimit = objReq.NRILimit;
        _sDiscQty = objReq.DiscQty;
        _sTrigPrice = objReq.TriggerPrice;
        _sOrderType = objReq.OrderType;
        _sProductType = objReq.ProductType;
        _sValidity = objReq.Validity;

        if (objReq.Days != "undefined")
            _sGTD = objReq.Days
        _ExchangeOrderNo = objReq.ExchangeOrderNo;
        _ClientOrderNumber = objReq.ClientOrderNumber;
        _GatewayOrderNo = objReq.GatewayOrderNo;
        _OrderTime = objReq.OrderTime;
        _sBuyQty = objReq.BuyQty;
        _sSellQty = objReq.SellQty;
        _sLTP = objReq.LTP;
        _sClosePrice = objReq.ClosePrice;
        _sPageSource = objReq.PageSource;
        _sCOL = objReq.COL;

        _SLJumpPrice = objReq.SLJumpPrice;
        _LTPJumpPrice = objReq.LTPJumpPrice;
        _SLOrderPrice = objReq.SLOrderPrice;
        _SLTriggerPrice = objReq.SLTriggerPrice;
        _ProfitOrderPrice = objReq.ProfitOrderPrice;
        _BracketOrderId = objReq.ProfitOrderPrice;
        _LegIndicator = objReq.LegIndicator;
        _BOGatewayOrderNo = objReq.BOGatewayOrderNo;
        _BracketOrderModifyBit = objReq.BracketOrderModifyBit;
        _SLOrderType = objReq.SLOrderType;
        _ProtPerc = objReq.ProtPerc;
        _OFSMargin = objReq.OFSMargin;
        _sRecoPrice = objReq.RecoPrice;
        _sRecoSLPrice = objReq.RecoSLPrice;
        _sRecoSQPrice = objReq.RecoSQPrice;
        _sLastPendingQty = objReq.LastPendingQty;
        _sLastTradedQty = objReq.LastTradedQty;
        _sRecoID = objReq.RecoId;
        _sLastTradedQty = objReq.Spread;
        _sRecoID = objReq.AssetToken;

        _sMktSegID = clsGlobal.ExchManager.getCurrentExchange(_sExchName).dcMarketSegementId[_sInstName];
        _sMapMktSegID = clsGlobal.ExchManager.getCurrentExchange(_sExchName).dcMapMarketSegementId[_sMktSegID];

        if (_sDecimalLocator == "0")
            _sDecimalLocator = "100";

        //Setting Price if Page Source is MarketWatch
        if (_sPageSource == clsConstants.C_V_MARKETWATCH_PAGENO.toString() || _sPageSource == clsConstants.C_V_BESTFIVE_PAGENO.toString()
            || _sPageSource == clsConstants.C_V_ORDERBOOK_PAGENO.toString() || _sPageSource == clsConstants.C_V_BULKORDERENTRY_PAGE.toString()
            || _sPageSource == clsConstants.C_V_RECOMMENDATION_PAGE.toString()) {
            if (_sBuySell == "BUY") {
                if (_sSellPrice != null && _sSellPrice.length > 0)
                    _sPrice = _sSellPrice;
                else
                    _sPrice = "0";
            }
            else {
                if (_sBuyPrice != null && _sBuyPrice.length > 0)
                    _sPrice = _sBuyPrice;
                else
                    _sPrice = "0";
            }

            if (_sSpread == "1" || _sSpread == "2")
                _sSpread = true;

            //if (_sPageSource == Constants.C_V_MARKETWATCH_PAGENO || _sPageSource == Constants.C_V_BULKORDERENTRY_PAGE) {
            if (_sPageSource == clsConstants.C_V_MARKETWATCH_PAGENO.toString() || _sPageSource == clsConstants.C_V_RECOMMENDATION_PAGE.toString()) {
                if (clsGlobal.ExchManager.exchInLOT.Contains(_sMktSegID.toString()))
                    _sQty = "1";
                else {
                    if (_sQty != null && _sQty.length == 0)
                        _sQty = _sMarketLot;
                }
            }
            /*if (_sPageSource == clsConstants.C_V_MARKETWATCH_PAGENO.toString() || _sPageSource == clsConstants.C_V_BESTFIVE_PAGENO.toString() || _sPageSource == clsConstants.C_V_RECOMMENDATION_PAGE.toString()) {
                if (clsGlobal.User.OrderPrefDic != undefined && clsGlobal.User.OrderPrefDic != null && clsGlobal.User.OrderPrefDic.count() > 0) {
                    if (clsGlobal.User.OrderPrefDic[_sMktSegID].nPopulateQtyValue != 0) {
                        QtyOpt = clsGlobal.User.OrderPrefDic[_sMktSegID].nPopulateQtyValue;
                        _sQty = clsGlobal.ExchManager.SetPreferences(_sExchName, _sMktSegID, _sMarketLot, _sSymbol, _sInstName, _sSeries, _sExpDate, _sOptionType, _sStrikePrice, _sLTP, _sClosePrice, _sSellQty, _sBuyQty, _sBuySell, QtyOpt);
                    }

                }
            }*/


            if (_sPageSource == clsConstants.C_V_RECOMMENDATION_PAGE.toString()) {
                _sPrice = _sRecoPrice;
            }
        }

        _OEJSONReq = {
            'OEBUYSELL': JSON.stringify(_sBuySell),
            'OEEXCH': JSON.stringify(_sExchName),
            'OEINST': JSON.stringify(_sInstName),
            'OESYMBOL': JSON.stringify(_sSymbol),
            'OESERIES': JSON.stringify(_sSeries),
            'OEEXPDATE': JSON.stringify(_sExpDate),
            'OESTKPRICE': JSON.stringify(_sStrikePrice),
            'OEOPTIONTYPE': JSON.stringify(_sOptionType),
            'OEORDERTYPE': JSON.stringify(_sOrderType),
            'OEQTY': JSON.stringify(_sQty),
            'OEMKTLOT': JSON.stringify(_sMarketLot),
            'OEPRICE': JSON.stringify(_sPrice),
            'OEPRICETICK': JSON.stringify(_sPriceTick),
            'OEDECLOC': JSON.stringify(_sDecimalLocator),
            'OEDISCQTY': JSON.stringify(_sDiscQty),
            'OETRIGPRICE': JSON.stringify(_sTrigPrice),
            'OEPRODUCTTYPE': JSON.stringify(_sProductType),
            'OEVALIDITY': JSON.stringify(_sValidity),
            'OEDAY': JSON.stringify(_sGTD),
            'OEMKTSEGID': JSON.stringify(_sMktSegID),
            'OEMAPMKTSEGID': JSON.stringify(_sMapMktSegID),
            'OETOKEN': JSON.stringify(_sTokenNo),
            'OEPAGESOURCE': JSON.stringify(_sPageSource),
            'OESPOSTYPE': JSON.stringify(_sSPOSType),
            'OEPOSTYPE': JSON.stringify(_sPOSType),
            'OESPREAD': JSON.stringify(_sSpread),
            'OEFIILIMIT': JSON.stringify(_sFIILimit),
            'OENRILIMIT': JSON.stringify(_sNRILimit),
            'OEEXORNO': JSON.stringify(_ExchangeOrderNo),
            'OECLORNO': JSON.stringify(_ClientOrderNumber),
            'OEGWORNO': JSON.stringify(_GatewayOrderNo),
            'OEORDERTIME': JSON.stringify(_OrderTime),
            'OELTP': JSON.stringify(_sLTP),
            'OECOL': JSON.stringify(_sCOL),
            'OESLJUMPPRICE': JSON.stringify(_SLJumpPrice),
            'OELTPJUMPPRICE': JSON.stringify(_LTPJumpPrice),
            'OESLORDERPRICE': JSON.stringify(_SLOrderPrice),
            'OESLTRIGGERPRICE': JSON.stringify(_SLTriggerPrice),
            'OEPROFITORDERPRICE': JSON.stringify(_ProfitOrderPrice),
            'OEBRACKETORDERID': JSON.stringify(_BracketOrderId),
            'OELEGINDICATOR': JSON.stringify(_LegIndicator),
            'OEBOGATEWAYORDERNO': JSON.stringify(_BOGatewayOrderNo),
            'OEBRACKETORDERMODIFYBIT': JSON.stringify(_BracketOrderModifyBit),
            'OESLOrderType': JSON.stringify(_SLOrderType),
            'OEProtPerc': JSON.stringify(_ProtPerc),
            'OEOFSMargin': JSON.stringify(_OFSMargin),

            'OERECOPRICE': JSON.stringify(_sRecoPrice),
            'OERECOSLPRICE': JSON.stringify(_sRecoSLPrice),
            'OERECOSQPRICE': JSON.stringify(_sRecoSQPrice),
            'OELASTPENDINGQTY': JSON.stringify(_sLastPendingQty),
            'OELASTTRADEDQTY': JSON.stringify(_sLastTradedQty),
            'OERECOID': JSON.stringify(_sRecoID)
        };

        return _OEJSONReq;
    }
}