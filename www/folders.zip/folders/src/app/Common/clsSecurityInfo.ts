import { clsTradingMethods } from "./clsTradingMethods";
import { ToastServicesProvider } from "../providers/toast-services/toast.services";
import { AlertServicesProvider } from "../providers/alert-services/alert-services";
import { clsHttpService } from "./clsHTTPService";
import { clsGlobal } from "./clsGlobal";


export class clsSecurityInfo {

    constructor(public toastCtrl: ToastServicesProvider,
        public alertCtrl: AlertServicesProvider,
        public httpService: clsHttpService) {

    }
    // observables to display the security info about the scrip
    ScripSymbol = '';
    SecurityName = '';
    Token = '';
    Instrument = '';
    ISIN = '';
    MarketLot = '';
    PriceTick = '';
    IssuedCapital = '';

    FaceValue = '';
    QtyFreeze = '';
    Margin = '';
    Multiplier = '';
    PreOpen = '';
    SPOS = '';
    CallAuction = '';

    StartDate = '';
    EndDate = '';
    ExDate = '';
    Purpose = '';
    isCAVisible = false;
    isDataFetch = false;

    mktSegId: any = '';
    ContainerId = '';
    context = "";
    ReportName = "";
    MCapCallBack = null;

    PrevDayOpen = '';
    PrevDayHigh = '';
    PrevDayLow = '';
    PrevDayClose = '';

    displayDetails(marketsegid, token) {
        try {
            this.mktSegId = marketsegid;
            this.Token = token;

            let mpParamReq: any = {};
            mpParamReq.mktSegmentId = this.mktSegId;
            mpParamReq.token = token;
            mpParamReq.siTemplateId = clsGlobal.User.SITemplateId;

            this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getSecurityInfo', mpParamReq).subscribe((data => {
                if (data.status) {
                    this.setSecInfo(data);
                } else {
                    //this.toastCtrl.showAtBottom(error);
                }
            }),
                error => {
                    //this.toastCtrl.showAtBottom(error);
                });

        }
        catch (e) {
            this.toastCtrl.showAtBottom('displayDetails: ' + e.message);
        }
    };

    setSecInfo(objResponse) {
        try {

            if (objResponse.status) {

                var dcResp = objResponse.result;
                var dcDetails = clsTradingMethods.getSecurityInfo(dcResp.secInfo[0], this.mktSegId);

                this.SecurityName = (dcDetails.SecurityName);
                this.Token = (dcDetails.Token);

                this.Instrument = (dcDetails.Instrument);

                if (dcDetails.ISIN == "")
                    this.ISIN = ("NA");
                else
                    this.ISIN = (dcDetails.ISIN);

                this.MarketLot = (dcDetails.MarketLot);
                this.PriceTick = (dcDetails.PriceTick);
                this.IssuedCapital = (dcDetails.IssuedCapital);

                this.FaceValue = (dcDetails.FaceValue);
                this.QtyFreeze = (dcDetails.QtyFreeze);
                this.Margin = (dcDetails.Margin);
                this.Multiplier = (dcDetails.Multiplier);

                //Pre Open 
                this.PreOpen = (dcDetails.PreOpen);

                // Special Pre Open
                this.SPOS = (dcDetails.SPOS);

                this.CallAuction = (dcDetails.CallAuction);
                if (dcDetails.CallAuction != "")
                    this.isCAVisible = (true);
                else
                    this.isCAVisible = (false);

                this.StartDate = (dcDetails.StartDate);
                this.EndDate = (dcDetails.EndDate);

                this.ExDate = (dcDetails.ExDate);

                if (dcDetails.Purpose.trim() == "")
                    this.Purpose = ("NA");
                else
                    this.Purpose = (dcDetails.Purpose);
                
                if(dcResp.pivot.length > 0)
                {
                    this.PrevDayOpen = dcResp.pivot[0].PrevOpen;
                    this.PrevDayHigh = dcResp.pivot[0].PrevHigh;
                    this.PrevDayLow = dcResp.pivot[0].PrevLow;
                    this.PrevDayClose = dcResp.pivot[0].PrevClose;
    
                }
                dcResp = null;
                dcDetails = null;

                if (this.MCapCallBack != null) {
                    this.MCapCallBack(this.IssuedCapital)
                }
                this.isDataFetch = true;
            }
        }
        catch (e) {
            this.toastCtrl.showAtBottom('displayDetails: ' + e.message);
        }
    }

}

