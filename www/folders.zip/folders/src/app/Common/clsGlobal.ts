﻿import { Dictionary, IKeyedCollection } from './clsCustomClasses';
import { clsUser } from './clsUser';
import { clsIndexDetail } from './clsIndexDetails';
import { clsExchManager } from './clsExchManager';
import { LogServicesProvider } from '../providers/log-services/log-services';
import { clsMarketStatus } from './clsMarketStatus';
import { Events } from '../communicator/clsEvents';
//import { Events } from '@ionic/angular';

export class clsGlobal { 
 
    // public static LocalComId = 'com.wave.dev/';//"com.wave.audit/";
    // public static ComId='com.wave.dev'; 
    public static ComId="1524";//"385";//"com.nb.beyond";//'com.wave.raf';//"704"//"385/";//'com.wave.raf/';//"com.nb.beyond/";
    public static LocalComId =  "1524/";
    public static versionId = 'v1';
    public static apiKey ='*******';// this will update from app config. 
    public static URL =   'http://203.114.240.122';//'https://waveapi.odinsecureconnect.co.in';//
    public static PORT =   ':4511/';// '/';//
    //Tenant 1651 //'https://waveapi.odinsecureconnect.co.in' 
    //Tenant 1404 'https://waveapi.odinconnector.co.in'; 
    //AWS local environment 'https://wave2-uat.odinconnector.co.in';//'http://172.25.102.230';////http://203.114.240.122';//
     
    public static VirtualDirectory: string = clsGlobal.URL + clsGlobal.PORT;
    public static LanguageDirectory: string = clsGlobal.URL + '/Beyond/i18n/';
    public static URL_CDSSERVER: string = clsGlobal.URL + clsGlobal.PORT + 'cds/'; 
    public static logSequenceNo: number = 0; 


    public static S3BucketPath='https://beyond-app.s3.ap-south-1.amazonaws.com/';
    public static Authentication = 'authentication/';
    public static Nontransactional = 'nontransactional/';
    public static Transactional = 'transactional/';
    public static AnalyticsService = 'analyticsservice/';
    public static CDNService = 'CDNService/';
    public static AlertKafka='alert-nodeengine/';   
    public static dMsgMaster: IKeyedCollection<string> = new Dictionary<string>();
    public static dConfigMaster: IKeyedCollection<string> = new Dictionary<string>();
    public static dLanguageMaster: any = [];
    public static lstMenuMaster: any = []; 
    public static dcProductTypeOldNewName: Dictionary<string> = new Dictionary<string>();
    public static MANAGER_VERSION_10XPLUSCRP_LIST: IKeyedCollection<string> = new Dictionary<string>();
    public static User: clsUser = new clsUser();
    public static DESKTOP: any = 'D';
    public static TABLET: any = 'T';
    public static MOBILE: string = 'M';
    public static PlatformMode: string = 'md';
    public static applicationType: string = clsGlobal.DESKTOP;
    public static ApplicationName: string = 'BEYOND';
    public static memberShipInfo = [];
    public static ExchManager: clsExchManager;
    public static MarketStatus: clsMarketStatus;
    public static BannedScriptStatusFlag = false;
    public static DefaultSITemplate = 'NETNETINT';
    public static IsGuestUser = true;
    public static DeviceType = 'MOBILE';
    public static AppMsgBoxTitle = 'NBTRADE';
    public static IndexConstituents: IKeyedCollection<any[]> = new Dictionary<any[]>();
    //public static MWScripList: IKeyedCollection<string> = new Dictionary<string>();
    public static isCMOTEnabled = false;
    public static CMOTMode:number = 0;
    public static FreeStream = false;
    public static FreeStreamWFHId = '';
    public static pubsub: any = new Events;// null;
    public static defaultToastShowTime: number = 2000; //it is a default time for toast to display.
    public static defaultIndices: Dictionary<clsIndexDetail>;
    public static lstAllIndicesList: any = [];
    public static cdsToken = ''; //cds token for cds services authentication 
    public static isKeyBoardOpen: boolean = false;
    public static lstProductTypeSequnce = [];
    public static dateFormatter: any;
    public static isPause: boolean = false;
    public static DQPercentageList: any = [];
    public static MktProtPerList: any = [];
    public static isNSEFAOCOLAllowed: boolean = false;
    public static defaultLanguage: string = '';
    public static defaultTheme: string = 'light';
    public static isUserDBReplicate: boolean = false;
    public static userSelectedWatchlist: any = '';
    public static userHoldingForWatchlist: boolean = false;
    public static userHoldingDataForWatchlist: any = [];
    public static userSelectedFilter: any = [];
    public static marketLiveNewsUrl: string = '';
    public static marketLiveBotUrl: string = '';
    public static isBroadcastConnected: boolean = false;
    public static logManager: LogServicesProvider;
    public static currentParentId: number;
    public static scannerList: any = [];
    public static indexSectorList: any = [];
    public static archRotationCount: number = 0;
    public static archLastRotationDegree: number = 0;
    public static parentMenu: any = []; 
    public static pushOEObj: any;
    public static pushPopUpDisplay: boolean = true;
    public static IsSessionExpiredGateway: boolean = false;
    public static logoutReceived: boolean = false;
    public static isJumpBothLtpAndTrigPrice: boolean = false;
    public static nwPopupOpen: boolean = false;
    public static xmppConnectionSocketUrl: any;
    public static watchlistFirstInit:boolean=true;
    public static EventList=[];
    public static reloadWatchlist:boolean=false;
    public static lstIndicesExchange = [];
    public static cardNewsLst = [];
    public static cardNewsDetails = []; 
    public static depthNewsDetails = [];
    public static trendingNewsLst: Dictionary<any> = new Dictionary<any>();
    public static inAppNotificationDetails: any = [];
    public static lstTopicList: any = [];
    public static scripAlertsList: any = [];
    public static isNewScripAlert : boolean = false;
    public static X_API_KEY:string="";
    public static ClearGlobalObjects() {
        this.User = new clsUser();
        this.userSelectedWatchlist="";
        clsGlobal.watchlistSyncDone = false;
    }
    public static ConsoleLogging(messageType:any,functionName:any ,message:any)
    {
        console.log("WAVE2 :- "+messageType+" Function : "+functionName +" Message: "+message);
    }
    public static profileScrip: Dictionary<any> = new Dictionary<any>();
    public static EventListScrip=[];
    public static exchangeName: Dictionary<any> = new Dictionary<any>();
    public static watchlistSyncDone:boolean=false;
}
 
export class clsPluginConstants {
    // device info
    public static DeviceUDID: string = window.location.host; //UDID
    public static DeviceModel: string = "TEST";//MI A1, J5
    public static DeviceSerialNo: string = "AKCPD1111";//MI A1, J5
    public static DeviceManufacturer: string = "TEST"; // MI Motorola,
    public static DevicePlatform: string = "EMULATOR";
    public static DevicePlatformVersion: string = "1.0";

    // Application Info
    public static AppName: string = 'BeyondTest';//Beyond
    public static AppVersion: string = '1.0.0'; //1.2.0
    public static AppVersionCode: string = "1000000"; //1200024
    public static AppPackageName: string = "com.nb.beyond2"; //com.nb.beyond

    // GEO location
    public static GeoLocLatitude: number;
    public static GeoLocLongitude: number;
    // Network info
    public static NetWorkConnected: boolean = false;
    public static NetWorkType: string = ''; //2G,3G,VOLTE,E

    public static fcmRegKey: string = window.location.host;

    static GetPluginDetails() {
        let plugindetails: any = {};
        try {
            plugindetails = {
                UDID: this.DeviceUDID || window.location.host, //UDID
                DeviceModel: this.DeviceModel || '',//MI A1, J5
                DeviceSerialNo: this.DeviceSerialNo || '',//MI A1, J5
                DeviceManufacturer: this.DeviceManufacturer || '',// MI Motorola,
                DevicePlatform: this.DevicePlatform || '',//andriod ios etc.
                DevicePlatformVer: this.DevicePlatformVersion || '',// 8.0, 11.2 etc
                Longitude: this.GeoLocLongitude == undefined ? "" : this.GeoLocLongitude.toString(),
                Latitude: this.GeoLocLatitude == undefined ? "" : this.GeoLocLatitude.toString(),

                AppName: this.AppName || '',//Beyond
                AppVersion: this.AppVersion || '',//1.2.0
                AppVersionCode: this.AppVersionCode || '',//1200024
                AppPackageName: this.AppPackageName || '',//com.nb.beyond
                FCMRegKey: this.fcmRegKey || ''
            }
        } catch (error) {
            alert("error in json object plugins" + error);
            return plugindetails;
        }
        return plugindetails;

    }
}
