import { clsGlobal } from '../Common/clsGlobal';
export class clsWorkerHelper{

    public static SendMessageToUI(_evtID, _objResp) {
        try 
        {
           setTimeout((id,objResp) => {
            clsGlobal.pubsub.publish(id, objResp);
           }, 0,_evtID,_objResp); 
        }
        catch (e) 
        {

        }
    };
}