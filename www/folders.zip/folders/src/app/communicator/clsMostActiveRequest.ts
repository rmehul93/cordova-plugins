
export class clsMostActiveRequest {
    
    /// <field name="SegmentId" type="String">
    /// Market Segment Id for which this request is to be made
    /// </field>
    public SegmentId = 0;
    /// <field name="Series" type="String">
    /// Securities Series
    /// </field>
    public Series = null;
    /// <field name="NoOfRecords" type="String">
    /// No of records requested for
    /// </field>
    public NoOfRecords = 10;
    /// <field name="MarketType" type="int">
    /// Valid Market Type values
    /// </field>
    public MarketType = 0;
    /// <field name="BroadcastReqType" type="String">
    /// Broad cast request type, valid values are 1 for Gainer and 2 for Loser
    /// </field>
    public BroadcastReqType;
    /// <field name="MaxValue" type="String">
    /// Maximum LTP value 
    /// </field>
    public MaxValue = '9999999999999';
    /// <field name="MinValue" type="String">
    /// Minimum LTP value 
    /// </field>
    public MinValue = '0';
}