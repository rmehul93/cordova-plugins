﻿import { clsResponseStore } from './clsResponseStore';
import { Dictionary } from '../Common/clsCustomClasses';
import { OperationType } from '../Common/clsConstants';
import { clsScripKey, clsScripStoreItem } from '../Common/clsScripKey';
import { clsMultiTouchLineRequest } from './clsMultiTouchLineRequest';
import { clsBestFiveRequest } from './clsBestFiveRequest';
import { clsScrip } from '../Common/clsScrip';
import { clsWorkerHelper } from './clsWorkerHelper';

export class clsRequestStore {

    public static touchLineScripList: Dictionary<clsScripStoreItem> = new Dictionary<clsScripStoreItem>();
    public static Best5ScripList: Dictionary<clsScripStoreItem> = new Dictionary<clsScripStoreItem>();
    public static MoreIndicesScripList: Dictionary<number> = new Dictionary<number>();
    public static LTPTouchLineScripList: Dictionary<clsScripStoreItem> = new Dictionary<clsScripStoreItem>();
    public static IsPause: boolean = false;

    public static getTouchLineScripList(_intOperationType: OperationType, _lstScrip: clsScripKey[]): string[] {

        let lstTouchLineScripList = [];
        let lstTouchLineScripListExisting = [];
        try {

            if (_intOperationType == OperationType.ADD) {
                for (let _intScripCnt = 0; _intScripCnt < _lstScrip.length; _intScripCnt++) {

                    let scripKey = _lstScrip[_intScripCnt].toString();
                    let cntScrip = 1;
                    let scripItem: clsScripStoreItem = null;
                    if (this.touchLineScripList.ContainsKey(scripKey)) {
                        scripItem = this.touchLineScripList.getItem(scripKey);
                        cntScrip = scripItem.count;
                        cntScrip++;
                        //lstTouchLineScripListExisting.push(_lstScrip[_intScripCnt]);
                    } else {
                        scripItem = new clsScripStoreItem();
                        scripItem.count = cntScrip;
                        scripItem.key = _lstScrip[_intScripCnt];
                        lstTouchLineScripList.push(_lstScrip[_intScripCnt]);
                    }
                    this.touchLineScripList.Add(scripKey, scripItem);
                    lstTouchLineScripListExisting.push(_lstScrip[_intScripCnt]);
                }

                // This is done to handle the case when request for this scrip has already been sent
                //and continuous broadcast is not coming then we need to fatch and broadcast old packet from response store
                this.BroadcastOldTouchLineResponse(lstTouchLineScripListExisting);
            }
            else if (_intOperationType == OperationType.REMOVE) {


                for (var _intScripCnt = 0; _intScripCnt < _lstScrip.length; _intScripCnt++) {

                    let scripKey = _lstScrip[_intScripCnt].toString();
                    if (this.touchLineScripList.ContainsKey(scripKey)) {
                        let cntScrip = this.touchLineScripList.getItem(scripKey);
                        if (cntScrip.count <= 1) {
                            //remove object from touchline response store
                            //clsResponseStore.RemoveTouchLineResponseObject(scripKey);
                            lstTouchLineScripList.push(_lstScrip[_intScripCnt]);
                            this.touchLineScripList.Remove(scripKey);
                        } else {
                            cntScrip.count--;
                            this.touchLineScripList.Add(scripKey, cntScrip);
                        }
                    }
                }
            }
        }
        catch (e) {
            //WWGlobal.LogManager.WriteLog(e.message, 'GetTouchLineScripList', 'RequestStore.ts', '');
        }
        return lstTouchLineScripList;
    };

    public static BroadcastOldTouchLineResponse(lstTouchLineScripList: string[]) {
        try {

            for (var intScripCnt = 0; intScripCnt < lstTouchLineScripList.length; intScripCnt++) {
                let skScrip = lstTouchLineScripList[intScripCnt];

                //TODO:Prajyot D

                //gets the touchline object (new or existing) from response store based on ScripKey
                var objMultiTLResponse = clsResponseStore.getTouchLineResponseObject(skScrip, false);

                if (objMultiTLResponse != null)
                    clsWorkerHelper.SendMessageToUI('MTLRES', objMultiTLResponse);
                /*
                gets the TER object (new or existing) from response store based on ScripKey
                var objTERResponse = clsResponseStore.GetTERResponseObject(skScrip, true);
                if (objTERResponse != null)
                    WorkerHelper.SendMessageToUI('TERRES', objTERResponse);
                */
            }
        }
        catch (e) {
            //WWGlobal.LogManager.WriteLog(e.message, 'BroadcastOldTouchLineResponse', 'RequestStore.ts', '');
        }
    };

    public static IsScripExistinTouchLineReqList(_skScrip: string): boolean {
        let isExist = false;
        try {

            if (this.touchLineScripList.ContainsKey(_skScrip)) {
                isExist = true;
            }
        }
        catch (e) {
            // WWGlobal.LogManager.WriteLog(e.message, 'IsScripExistinTouchLineReqList', 'RequestStore.ts', '');
        }
        return isExist;
    };


    public static getLTPTouchLineScripList(_intOperationType: OperationType, _lstScrip: clsScripKey[]) {
        let lstTouchLineScripList = [];
        let lstTouchLineScripListExisting = [];
        try {
            if (_intOperationType == OperationType.ADD) {
                for (let _intScripCnt = 0; _intScripCnt < _lstScrip.length; _intScripCnt++) {

                    let scripKey = _lstScrip[_intScripCnt].toString();
                    let cntScrip = 1;
                    let scripItem: clsScripStoreItem = null;
                    if (this.LTPTouchLineScripList.ContainsKey(scripKey)) {
                        scripItem = this.LTPTouchLineScripList.getItem(scripKey);
                        cntScrip = scripItem.count;
                        cntScrip++;
                        //lstTouchLineScripListExisting.push(_lstScrip[_intScripCnt]);
                    } else {
                        scripItem = new clsScripStoreItem();
                        scripItem.count = cntScrip;
                        scripItem.key = _lstScrip[_intScripCnt];
                        lstTouchLineScripList.push(_lstScrip[_intScripCnt]);
                    }
                    this.LTPTouchLineScripList.Add(scripKey, scripItem);
                    lstTouchLineScripListExisting.push(_lstScrip[_intScripCnt]);
                }

                // This is done to handle the case when request for this scrip has already been sent
                //and continuous broadcast is not coming then we need to fatch and broadcast old packet from response store
                this.BroadcastOldLTPTouchLineResponse(lstTouchLineScripListExisting);
            }
            else if (_intOperationType == OperationType.REMOVE) {


                for (var _intScripCnt = 0; _intScripCnt < _lstScrip.length; _intScripCnt++) {

                    let scripKey = _lstScrip[_intScripCnt].toString();
                    if (this.LTPTouchLineScripList.ContainsKey(scripKey)) {
                        let cntScrip = this.LTPTouchLineScripList.getItem(scripKey);
                        if (cntScrip.count <= 1) {
                            //remove object from touchline response store
                            //clsResponseStore.RemoveLTPTouchLineResponseObject(scripKey);
                            lstTouchLineScripList.push(_lstScrip[_intScripCnt]);
                            this.LTPTouchLineScripList.Remove(scripKey);
                        } else {
                            cntScrip.count--;
                            this.LTPTouchLineScripList.Add(scripKey, cntScrip);
                        }
                    }
                }
            }
        }
        catch (e) {

        }
        return lstTouchLineScripList;
    };

    /// <summary>
    /// This gets the existing TouchLine object from response store based on Scrip key and
    /// Broadcast that packet
    /// </summary>
    /// <param name="lstTouchLineScripList" type="Object">
    /// </param>
    public static BroadcastOldLTPTouchLineResponse(lstTouchLineScripList) {

        try {
            for (let intScripCnt = 0; intScripCnt < lstTouchLineScripList.length; intScripCnt++) {
                let skScrip = lstTouchLineScripList[intScripCnt];
                //gets the touchline object (new or existing) from response store based on ScripKey
                let objMultiTLResponse = clsResponseStore.getLTPTouchLineResponseObject(skScrip, false);

                if (objMultiTLResponse != null)
                    clsWorkerHelper.SendMessageToUI('MTLRES', objMultiTLResponse);
                //TODO:
                // if (objMultiTLResponse != null)
                //     WorkerHelper.SendMessageToUI('MTLRES', objMultiTLResponse);

            }
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Fuction to check whether given scrip exist in TouchLineReqList
    /// </summary>
    public static IsScripExistinLTPTouchLineReqList(_skScrip: string): boolean {
        let isExist = false;
        try {

            if (this.LTPTouchLineScripList.ContainsKey(_skScrip)) {
                isExist = true;
            }
        }
        catch (e) {
            // WWGlobal.LogManager.WriteLog(e.message, 'IsScripExistinTouchLineReqList', 'RequestStore.ts', '');
        }
        return isExist;

    };

    /// <summary>
    /// <para>1. Adding/Removing scrips from Best Five Request dictionary</para><para>2. While Adding - If scrip is new to the dictionary, then Add the same to the Subscribe dictionary.
    /// If scrip already exists, then just increment the counter by 1</para><para>3. While Removing - If scrip already exists, then just decrement the counter by 1.
    /// If the counter value becomes 0, then delete that value from the dictionary and add it to Unsubscribe dictionary.
    /// If scrip is new to the dictionary, then just ignore the scrip</para>
    /// </summary>
    public static getBest5ScripList(intOperationType: OperationType, objScrip: clsScripKey) {

        let intB5RetVal = 0;
        try {
            let scripKey = objScrip.toString();
            if (intOperationType == OperationType.ADD) {

                //for (let intScripCnt = 0; intScripCnt < this.Best5ScripList.Count(); intScripCnt++) {
                let cntScrip = 1;
                let scripItem: clsScripStoreItem = null;
                if (this.Best5ScripList.ContainsKey(scripKey)) {
                    scripItem = this.Best5ScripList.getItem(scripKey);
                    cntScrip = scripItem.count;
                    cntScrip++;
                }
                else {
                    scripItem = new clsScripStoreItem();
                    scripItem.count = cntScrip;
                    scripItem.key = objScrip;
                    intB5RetVal = 1;
                }
                this.Best5ScripList.Add(scripKey, scripItem);
                //}
            }
            else if (intOperationType == OperationType.REMOVE) {

                if (this.Best5ScripList.ContainsKey(scripKey)) {
                    let cntScrip = this.Best5ScripList.getItem(scripKey);
                    if (cntScrip.count <= 1) {
                        //remove object from touchline response store
                        //clsResponseStore.RemoveBest5ResponseObject(scripKey);
                        this.Best5ScripList.Remove(scripKey);
                        intB5RetVal = 1;
                    } else {
                        cntScrip.count--;
                        this.Best5ScripList.Add(scripKey, cntScrip);
                    }
                }
            }
        }
        catch (e) {

        }
        return intB5RetVal;
    };

    /// <summary>
    /// Function to send the TouchLine Request when autorefresh mode is on or in case of refresh mode
    /// </summary>
    /// <param name="intOperationType" type="Number" integer="true">
    /// Operation Type for subscribe/unsubscribe
    /// </param>
    public static getLTPTouchLineRequest(intOperationType: OperationType) {

        let objTLReq: clsMultiTouchLineRequest = new clsMultiTouchLineRequest();
        objTLReq.OperationType = intOperationType;
        objTLReq.BypassRequestStore = true; // BypassRequestStore value will be true only in this case
        try {
            if (this.LTPTouchLineScripList.Count() > 0) {
                let _lstScripsArray = [];
                let arrScripKey = this.LTPTouchLineScripList.Keys();
                for (let i = 0; i < arrScripKey.length; i++) {
                    let key = arrScripKey[i];
                    _lstScripsArray.push(this.LTPTouchLineScripList.getItem(key).key);
                }
                objTLReq.ScripList = _lstScripsArray;
            }
        }
        catch (e) {

        }
        return objTLReq;
    };

    /// <summary>
    /// Function to send the TouchLine Request when autorefresh mode is on or in case of refresh mode
    /// </summary>
    /// <param name="intOperationType" type="Number" integer="true">
    /// Operation Type for subscribe/unsubscribe
    /// </param>
    public static getTouchLineRequest(intOperationType: OperationType) {

        let objTLReq: clsMultiTouchLineRequest = new clsMultiTouchLineRequest();
        objTLReq.OperationType = intOperationType;
        objTLReq.BypassRequestStore = true; // BypassRequestStore value will be true only in this case
        try {
            if (this.touchLineScripList.Count() > 0) {
                let _lstScripsArray = [];
                let arrScripKey = this.touchLineScripList.Keys();
                for (let i = 0; i < arrScripKey.length; i++) {
                    let key = arrScripKey[i];
                    _lstScripsArray.push(this.touchLineScripList.getItem(key).key);
                }
                objTLReq.ScripList = _lstScripsArray;
            }
        }
        catch (e) {

        }
        return objTLReq;
    };

    /// <summary>
    /// Function to send the BestFive Request when autorefresh mode is on or in case of refresh mode
    /// </summary>
    /// <param name="intOperationType" type="Number" integer="true">
    /// Operation Type for subscribe/unsubscribe
    /// </param>
    public static getBest5Request(intOperationType: OperationType) {

        try {
            let objB5Req: clsBestFiveRequest = null;// new BetsFiveRequest();
            if (this.Best5ScripList.Count() > 0) {
                objB5Req = new clsBestFiveRequest();
                objB5Req.OperationType = intOperationType;
                objB5Req.ByPassRequestStore = true;
                let arrScripKey = this.Best5ScripList.Keys();
                for (let i = 0; i < arrScripKey.length; i++) {
                    let scripObj: clsScrip = new clsScrip();
                    scripObj.scripDet = this.Best5ScripList.getItem(arrScripKey[i]).key;
                    objB5Req.Scrip = scripObj;//this.Best5ScripList.Keys()[i];
                }
            }
            return objB5Req;
        }
        catch (e) {

        }
    };

    // <summary>
    /// Fuction to check whether given scrip exist in TouchLineReqList
    /// </summary>
    public static IsScripExistinBest5ReqList(_skScrip: string): boolean {
        let isExist = false;
        try {

            if (this.Best5ScripList.ContainsKey(_skScrip)) {
                isExist = true;
            }
        }
        catch (e) {
            // WWGlobal.LogManager.WriteLog(e.message, 'IsScripExistinTouchLineReqList', 'RequestStore.ts', '');
        }
        return isExist;
    }

    /// <summary>
    /// Function to send all the required subscription requests when autorefresh mode is on or in case of refresh mode
    /// </summary>
    public static clearStore() {
        try {
            this.touchLineScripList.Clear();
            this.Best5ScripList.Clear();
            this.MoreIndicesScripList.Clear();
            this.LTPTouchLineScripList.Clear();
        }
        catch (e) {

        }
    }
}
