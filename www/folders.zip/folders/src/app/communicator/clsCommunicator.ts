import { clsParser } from './clsParser';
import { clsConstants, OperationType } from '../Common/clsConstants';
import { clsRequestStore } from './clsRequestStore';
import { clsOnlineResponse } from './clsOnlineResponse';
import { clsTradingMethods } from '../Common/clsTradingMethods';
import { clsResponseStore } from './clsResponseStore';
import { clsMultiTouchLineRequest } from './clsMultiTouchLineRequest';
import { clsBestFiveRequest } from './clsBestFiveRequest';
import { clsTopGainerRequest } from './clsTopGainerRequest';
import { clsMostActiveRequest } from './clsMostActiveRequest';
import { clsGlobal } from '../Common/clsGlobal';
import { clsAppConfigConstants } from '../Common/clsAppConfigConstants';

export class clsCommunicator {

    scripBatchCount: number = 15;
    socketChannelId: string = '';
    isSocketConnected: boolean = false;
    OCParser: clsParser = clsParser.Instance;
    msgCodeKeyToCheck: string = '';
    KASocketObj = null;
    keepAliveTimer: number = 0;
    //eventPub : any;

    onInitilize() {
        try {
            this.scripBatchCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SCRIPS_BATCH_COUNT));
            this.msgCodeKeyToCheck = clsConstants.C_S_FIELD_DELIMITER + clsConstants.C_S_TAG_MSGCODE + clsConstants.C_S_NAMEVALUE_DELIMITER;
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'Initilize', 'Comm.ts', '');
        }
    };

    onChannelConnected(_channelId, _Com) {
        try {
            this.loginCompleted(_channelId, _Com);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'OnChannelConnected', 'Comm.ts', '');
        }
    };

    onChannelDisconnected(_channelId) {
        try {

            let strMessage = "Socket Disconnected.";
            if (_channelId == clsConstants.C_S_CHANNEL_BROADCAST) {
                 clsGlobal.isBroadcastConnected=false;
                strMessage = clsGlobal.dMsgMaster.getItem("NNSL101");
            }
            else {
                strMessage = clsGlobal.dMsgMaster.getItem("NNSL100");
            }
            this.sendCommunicatorResponse(strMessage);
        }
        catch (e) {

            //WWclsGlobal.LogManager.WriteLog(e.message, 'OnChannelDisconnected', 'Comm.ts', '');

        }
    };

    onChannelConnectionFailed(_channelId) {
        try {
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'OnChannelConnectionFailed', 'Comm.ts', '');
        }
    };

    loginCompleted(_channelId, _Com) {
        try {
            if (_channelId == clsConstants.C_S_CHANNEL_BROADCAST) {
              clsGlobal.isBroadcastConnected=true;
                this.handleLTPTouchLineRequest(clsRequestStore.getLTPTouchLineRequest(1));
                this.handleTouchLineRequest(clsRequestStore.getTouchLineRequest(1));
                this.handleBestFiveRequest(clsRequestStore.getBest5Request(1));
                if(clsGlobal.isPause)
                {
                    this.handleAppSuspendRequest(null);
                }
            }
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'LoginCompleted', 'Comm.ts', '');
        }
    };

    sendCommunicatorResponse(_strMessage) {
        try {

            let objLoginMsg = new clsOnlineResponse;
            objLoginMsg.MsgData = _strMessage;
            let _currentTime = clsTradingMethods.GetCurrentTime(); // _date.format('H:mm:ss');
            objLoginMsg.MsgCategory = clsConstants.C_S_MSGCAT_ACK;
            objLoginMsg.MsgTime = _currentTime;
            objLoginMsg.OrderSide = clsConstants.C_S_MSGCAT_LOGIN;
            clsResponseStore.SendOnlineResponse(objLoginMsg);

        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'SendCommunicatorResponse', 'Comm.ts', '');
        }
    };

    sendMessage(_request: string) {
        throw new Error("Derive Class must implement this method: sendMessage");
    };

    manualMarketStatusRequest() {
        throw new Error("Derive Class must implement this method: manualMarketStatusRequest!!");
    }

    handleTouchLineRequest(_objMultiTLRequest: clsMultiTouchLineRequest) {
        try {

            let lstScripList = [];

            // If ByPassRequestStore value is true, then directly access the MultiTouchLineRequest scriplist
            // If the value is false, then get the updated scriplist from the Request Store
            if (_objMultiTLRequest.BypassRequestStore)
                lstScripList = _objMultiTLRequest.ScripList;
            else
                lstScripList = clsRequestStore.getTouchLineScripList(_objMultiTLRequest.OperationType, _objMultiTLRequest.ScripList);

            //In case the scriplist is blank and user is logged in refresh mode then send the new scriplist
            // if (lstScripList.length == 0 && clsGlobal.User.LoginMode ==  (clsConstants.C_S_REFRESH_MODE).toString())
            //     lstScripList = _objMultiTLRequest.ScripList;

            let intOperationType = _objMultiTLRequest.OperationType;
            if (intOperationType == OperationType.REMOVE && this.socketChannelId == clsConstants.C_S_CHANNEL_WCF) {
                return;
            }
            // If count of Scrip List is more than that of scrip batch count, then split the list into batches
            if (lstScripList.length > (this.scripBatchCount)) {
                var intCntr = 0;
                var lstScripBatch = [];
                var _req;

                for (var intScripList = 0; intScripList < lstScripList.length; intScripList++) {
                    intCntr++;
                    lstScripBatch.push(lstScripList[intScripList]);

                    if (intCntr == (this.scripBatchCount)) {
                        intCntr = 0;
                        _req = this.OCParser.createTouchLineRequest(intOperationType, lstScripBatch);
                        this.sendMessage(_req);
                        lstScripBatch = [];
                    }
                }

                // if condition for the last batch of the scrips, where the scrip list count is less than scrip batch count
                if (lstScripBatch.length > 0) {
                    _req = this.OCParser.createTouchLineRequest(intOperationType, lstScripBatch);
                    this.sendMessage(_req);
                }
            }
            else {
                if (lstScripList.length > 0) {
                    _req = this.OCParser.createTouchLineRequest(intOperationType, lstScripList);
                    this.sendMessage(_req);
                }
            }
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'HandleTouchLineRequest', 'Comm.ts', '');
        }
    };


    /// <summary>
    /// Handler for Best Five Request
    /// </summary>
    /// <param name="objBestFiveRequest">BestFiveRequest object</param>
    /// </param>
    /// <param name="_objCom" type="Com object">
    /// </param>
    handleBestFiveRequest(_objBestFiveRequest: clsBestFiveRequest) {

        try {

            let intB5Req = 1;
            // If ByPassRequestStore value is true, then let the value of intB5Req be 1 i.e send B5 request in any case
            // If the value is false, then get the value of intB5Req from the Request Store
            if (_objBestFiveRequest != null && typeof (_objBestFiveRequest.Scrip) != 'undefined') {
                if (!_objBestFiveRequest.ByPassRequestStore)
                    intB5Req = clsRequestStore.getBest5ScripList(_objBestFiveRequest.OperationType, _objBestFiveRequest.Scrip.scripDet);
                // If intB5Req is 1 then only send the request
                // If intB5Req is 0 then ignore the request as the request for this scrip has already been sent
                if (intB5Req == OperationType.ADD) {
                    let _req = this.OCParser.createBestFiveRequest(_objBestFiveRequest);
                    this.sendMessage(_req);
                }
                else {
                    // This is done to handle the case when request for this scrip has already been sent
                    //and continuous broadcast is not coming then we need to fatch and broadcast old packet from response store
                    if (_objBestFiveRequest.OperationType == OperationType.ADD)
                        this.broadcastOldBest5Response(_objBestFiveRequest);
                }
            }
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'HandleBestFiveRequest', 'Comm.ts', '');
        }
    };

    //Created by Kunal Kolhe for AppSuspend request
    handleAppSuspendRequest(_objAppSusReq) {
        try {
            let _req = this.OCParser.createAppSuspendRequest();
            this.sendMessage(_req);
        }
        catch (e) {
            // clsGlobal.LogManager.WriteLog(e.message, 'HandleAppSuspendRequest', 'Comm.js', '');
        }
    };

    //Created by Kunal Kolhe for Appresume request
    handleAppResumeRequest(_objAppResReq) {
        try {
            let _req = this.OCParser.createAppResumeRequest();
            this.sendMessage(_req);
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Handler for all LTP TouchLine Requests
    /// </summary>
    /// <param name="objMultiTLRequest" type="MultiTouchLineRequest">
    /// MultiTouchLineRequest object
    /// </param>
    /// <param name="_objCom" type="Com object">
    /// </param>
    handleLTPTouchLineRequest(_objMultiTLRequest: clsMultiTouchLineRequest) {

        try {
            let lstScripList = [];

            // If ByPassRequestStore value is true, then directly access the MultiTouchLineRequest scriplist
            // If the value is false, then get the updated scriplist from the Request Store
            if (_objMultiTLRequest.BypassRequestStore)
                lstScripList = _objMultiTLRequest.ScripList;
            else
                lstScripList = clsRequestStore.getLTPTouchLineScripList(_objMultiTLRequest.OperationType, _objMultiTLRequest.ScripList);


            let intOperationType = _objMultiTLRequest.OperationType;
            if (intOperationType == OperationType.REMOVE && this.socketChannelId == clsConstants.C_S_CHANNEL_WCF) {
                return;
            }

            let intPCntr = 0;
            // If count of Scrip List is more than that of scrip batch count, then split the list into batches
            if (lstScripList.length > this.scripBatchCount) {
                let intCntr = 0;
                let lstScripBatch = [];
                intPCntr = 0;
                for (let intScripList = 0; intScripList < lstScripList.length; intScripList++) {
                    intCntr++;
                    lstScripBatch.push(lstScripList[intScripList]);
                    if (intCntr == this.scripBatchCount) {
                        intCntr = 0;
                        let _req = this.OCParser.createLTPTouchLineRequest(intOperationType, lstScripBatch);
                        this.sendMessage(_req);
                        lstScripBatch = [];
                        while (true) {
                            if (intPCntr == 500)
                                break;
                            intPCntr++;
                        }
                        //console.log("LTP op type: " + intOperationType + ", Request: " + _req);
                    }
                }

                // if condition for the last batch of the scrips, where the scrip list count is less than scrip batch count
                if (lstScripBatch.length > 0) {
                    let _req = this.OCParser.createLTPTouchLineRequest(intOperationType, lstScripBatch);
                    this.sendMessage(_req);
                }
            }
            else {
                if (lstScripList.length > 0) {
                    let _req = this.OCParser.createLTPTouchLineRequest(intOperationType, lstScripList);
                    this.sendMessage(_req);
                }
            }
        }
        catch (e) {
        }
    };




    handleMarketStatusRequest() {
        this.manualMarketStatusRequest();
    }

    /*
    //Index Info Request
    handleMoreIndicesInfoRequest(_objIdxInfoRequest) {
        try {
            var lstScripList = [];

            // If ByPassRequestStore value is true, then directly access the MultiTouchLineRequest scriplist
            // If the value is false, then get the updated scriplist from the Request Store
            if (_objIdxInfoRequest.BypassRequestStore)
                lstScripList = _objIdxInfoRequest.ScripList;
            else
                lstScripList = clsRequestStore.getMoreIndicesScripList(_objIdxInfoRequest.OperationType, _objIdxInfoRequest.ScripList);

            var intOperationType = _objIdxInfoRequest.OperationType;

            // If count of Scrip List is more than that of scrip batch count, then split the list into batches
            if (lstScripList.length > parseInt(this.scripBatchCount)) {
                var intCntr = 0;
                var lstScripBatch = [];

                for (var intScripList = 0; intScripList < lstScripList.length; intScripList++) {
                    intCntr++;
                    lstScripBatch.push(lstScripList[intScripList]);

                    if (intCntr == parseInt(this.ScripBatchCount)) {
                        intCntr = 0;
                        var _req = _objCom.OCParser.CreateMoreIndicesInfoRequest(intOperationType, lstScripBatch);
                        _objCom.SendMessage(_req);
                        lstScripBatch = [];
                    }
                }

                // if condition for the last batch of the scrips, where the scrip list count is less than scrip batch count
                if (lstScripBatch.length > 0) {
                    var _req = _objCom.OCParser.CreateMoreIndicesInfoRequest(intOperationType, lstScripBatch);
                    _objCom.SendMessage(_req);
                }
            }
            else {
                if (lstScripList.length > 0) {
                    var _req = _objCom.OCParser.CreateMoreIndicesInfoRequest(intOperationType, lstScripList);
                    _objCom.SendMessage(_req);
                }
            }
        }
        catch (e) {
           WWclsGlobal.LogManager.WriteLog(e.message, 'HandleMoreIndicesInfoRequest', 'Comm.ts', '');
        }
    };
*/

    broadcastOldBest5Response(_objBestFiveRequest: clsBestFiveRequest) {
        /// <summary>
        /// This gets the existing Best5 object from response store based on Scrip key and
        /// Broadcast that packet
        /// </summary>
        try {

            //gets the existing Best5 object from response store based on Scrip key
            clsResponseStore.getBest5ResponseObject(_objBestFiveRequest.Scrip.scripDet.toString(), false);

            //TODO:
            // if (objBestFiveResponse != null)
            //     WorkerHelper.SendMessageToUI('B5RES', objBestFiveResponse);

            //gets the existing TER object from response store based on Scrip key
            clsResponseStore.getTERResponseObject(_objBestFiveRequest.Scrip.scripDet.toString(), true);
            // if (objTERResponse != null)
            //     WorkerHelper.SendMessageToUI('TERRES', objTERResponse);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'BroadcastOldBest5Response', 'Comm.ts', '');
        }
    };

    /// <summary>
    /// Handler for Top Gainer Request
    /// </summary>
    /// <param name="_objTopGainerRequest">TopGainerRequest object</param>
    handleTopGainerRequest(_objTopGainerRequest: clsTopGainerRequest) {

        try {
            var _req = this.OCParser.createTopGainerRequest(_objTopGainerRequest);
            this.sendMessage(_req);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'HandleTopGainerRequest', 'Comm.ts', '');

        }
    };

    /// <summary>
    /// Handler for MostActive Request
    /// </summary>
    /// <param name="_objMostActiveRequest">MostActiveRequest object</param>
    handleMostActiveRequest(_objMostActiveRequest: clsMostActiveRequest) {
        try {
            var _req = this.OCParser.createMostActiveRequest(_objMostActiveRequest);
            this.sendMessage(_req);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'HandleMostActiveRequest', 'Comm.ts', '');
        }
    }

    /// <summary>
    /// Handler for Index Details Request
    /// </summary>
    /// <param name="_objIndexDetailsRequest">Index DetailsRequest object</param>
    handleIndexDetailsRequest(_objIndexDetailsRequest, _objCom) {

        try {
            var _req = this.OCParser.createIndexDetailsRequest(_objIndexDetailsRequest);
            this.sendMessage(_req);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'HandleIndexDetailsRequest', 'Comm.ts', '');
        }
    }

    handleAutoRefresh(_channelId) {
        /// <param name="_channelId" type="String">
        /// </param>
        try {
            // send the message to frontend that socket reconnection attempt has reached the maximum limit
            clsGlobal.pubsub.publish('StartAutoRefresh', _channelId);
        }
        catch (e) {
        }
    };
}


