export class clsNewsResponse {
    public VendorCodes=[];
    public NewsId='';
    public OldToken ='';
    public Categories=[];
    public ISINs=[];
    public Active='';
    public Headline='';
    /// <summary>
    /// N - Normal News, H - Hot News
    /// </summary>
    public Type='';
    /// <summary>
    /// 1 - Popup, 2 - MsgBar, 3 - Popup and MsgBar
    /// </summary>
    public Mode='';
    public MsgCategory='';
}
