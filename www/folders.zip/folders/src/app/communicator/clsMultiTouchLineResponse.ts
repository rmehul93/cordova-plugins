import { clsScripKey } from "../Common/clsScripKey";

export class clsMultiTouchLineResponse {
    
     public Scrip: clsScripKey;
     public LUT :string = "";
     public LTP :string = "";
     public PercNetChange:string = "";
     public LTQ:any = "";
     public LTT:string = "";
     public BuyQty:any = 0;
     public BuyPrice:any = 0;
     public SellQty:any = 0;
     public SellPrice:any = 0;
     public ClosePrice:any = 0;
     public OpenPrice:any = 0;
     public HighPrice:any = 0;
     public LowPrice:any = 0;
     public OpenInt:string = "";
     public Volume:any = 0;
     public ATP:any = 0;
     public TotalBuyQty:any = 0;
     public TotalSellQty:any = 0;
     public LifeTimeHigh:any = 0;
     public LifeTimeLow:any = 0;
     public DPR:string = "";
     public NetChangeInRs:string = "";
     public DecimalLocator:number = 0
     public HighOpenInt:string = "";
     public LowOpenInt :string = "";
     public PercOpenInt = '';
     public TER :string = "";
     public PriceFormat :number = 0;
}
