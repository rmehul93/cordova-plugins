import { clsGlobal } from '../Common/clsGlobal';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants } from '../Common/clsConstants';

export class clsAPIParser {

    public static Instance: clsAPIParser = new clsAPIParser();

    /**
    * @method : Create User Login Request
    * @param objUser : Login Object
    * @returns Returns User login Object
    */
    getLoginRequest(objUser) {
        try {
            let loginReq: any = {};
            //let tdes_key = clsGlobal.dConfigMaster.getItem("APP_TRIPLEDES_KEY");
            let tdes_key ="";
            if(clsGlobal.dConfigMaster.getItem("APP_TDES_MODE")=="ON")
            {
                 tdes_key = clsGlobal.dConfigMaster.getItem("APP_TRIPLEDES_KEY");
            }
            loginReq.user_id = objUser.user_id;
            loginReq.login_type = (tdes_key) ? objUser.login_type + "_TDES" : objUser.login_type;
            loginReq.password = (tdes_key) ? clsCommonMethods.TripleDESEncrypt(objUser.password) : objUser.password;
            loginReq.second_auth = (tdes_key) ? clsCommonMethods.TripleDESEncrypt(objUser.second_auth) : objUser.second_auth;
            loginReq.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            loginReq.source = clsConstants.PRODUCT_SOURCE;
            loginReq.UDID = objUser.UDID;
            //commented as not in used ,source will be used for product mode.
            loginReq.product_mode = 21; //to be passed for wave ,loginReq.product_code is for OC direct call,
                                        // loginReq.product_mode is used for ODIN REST API call.
            return loginReq; 
        } catch (error) {
            console.log("Error + getLoginRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getLoginRequest', error);
            return null;
        }
    }

    /**
    * @method : Create Change Password Request
    * @param objPasswordChnage : Change Password Object
    * @returns Returns Change Password Object
    */
    getChangePwdRequest(objPasswordChnage) {
        try {
            let chngPasswordReq: any = {};
            let tdes_key ="";
            if(clsGlobal.dConfigMaster.getItem("APP_TDES_MODE")=="ON")
            {
                 tdes_key = clsGlobal.dConfigMaster.getItem("APP_TRIPLEDES_KEY");
            }
            
            chngPasswordReq.user_id = objPasswordChnage.user_id;
            chngPasswordReq.old_password = (tdes_key) ? clsCommonMethods.TripleDESEncrypt(objPasswordChnage.old_password) : objPasswordChnage.old_password;
            chngPasswordReq.new_password = (tdes_key) ? clsCommonMethods.TripleDESEncrypt(objPasswordChnage.new_password) : objPasswordChnage.new_password;
            chngPasswordReq.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            chngPasswordReq.source = clsConstants.PRODUCT_SOURCE;//objPasswordChnage.source;
            chngPasswordReq.type = (tdes_key) ? "TDES":"";
            chngPasswordReq.product_mode = 21; //to be passed for wave

            return chngPasswordReq;
        } catch (error) {
            console.log("Error + getChangePwdRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getChangePwdRequest', error);
             
            return null;
        }
    }

    /**
     * @method : Create Registration request for lead generation
     * @param registrationObj : User Registration Object
     * @returns Returns User Registration Object
     */
    getRegistrationRequest(registrationObj) {
        try {
            let registrationReq: any = {};
            registrationReq.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            registrationReq.user_name = registrationObj.user_name;
            registrationReq.mobile_number = registrationObj.mobile_number;
            registrationReq.state = registrationObj.state;
            registrationReq.city = registrationObj.city;
            registrationReq.email_id = registrationObj.email_id;
            registrationReq.plugin_info = registrationObj.plugin_info;
            return registrationReq;
        } catch (error) { 
            console.log("Error + getRegistrationRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getRegistrationRequest', error);
             return null;
        }
    }

    /**
     * @method : Create Forgot Mpin Otp Object request
     * @param mpinResetObj : Reset MPIN otp Object
     * @returns Returns Forgot Mpin Otp Object
     */
    getForgotMpinOtpRequest(mpinResetObj) {
        try {
            let reqOTPGenerate: any = {};
            reqOTPGenerate.user_id = mpinResetObj.user_id;
            reqOTPGenerate.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            reqOTPGenerate.source = clsConstants.PRODUCT_SOURCE;//mpinResetObj.source;
            reqOTPGenerate.hashCode = mpinResetObj.hashCode;
            return reqOTPGenerate;
        } catch (error) {
            console.log("Error + getForgotMpinOtpRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getForgotMpinOtpRequest', error);
            return null;
        }
    }

    /**
     * @method : Create Forgot Mpin Object request
     * @param mpinChangeObj : Forgot Mpin Object
     * @returns Returns Forgot Mpin Change Object
     */
    getForgotMpinChangeRequest(mpinChangeObj) {
        try {
            let reqForgetMpinReset: any = {};
            reqForgetMpinReset.user_id = mpinChangeObj.user_id;
            reqForgetMpinReset.otp = mpinChangeObj.otp;
            reqForgetMpinReset.mpin = mpinChangeObj.mpin;
            reqForgetMpinReset.mobile_udid = mpinChangeObj.mobile_udid;
            reqForgetMpinReset.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            reqForgetMpinReset.source = clsConstants.PRODUCT_SOURCE;//mpinChangeObj.source;
            return reqForgetMpinReset;
        } catch (error) {
            console.log("Error + getForgotMpinChangeRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getForgotMpinChangeRequest', error);
            return null;
        }
    }

    /**
     * @method : Create Change MPIN Object request
     * @param objRequest : Change Mpin Object
     * @returns Returns Change MPIN Object request
     */
    getChangeMPINRequest(objRequest) {
        try {
            let reqChangeMPINObj: any = {};
            reqChangeMPINObj.user_id = objRequest.user_id;
            reqChangeMPINObj.old_mpin = objRequest.old_mpin;
            reqChangeMPINObj.new_mpin = objRequest.new_mpin;
            reqChangeMPINObj.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            reqChangeMPINObj.source = clsConstants.PRODUCT_SOURCE;//"MOBILEAPI";
            return reqChangeMPINObj;
        } catch (error) {
            console.log("Error + getChangeMPINRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getChangeMPINRequest', error);
            return null;
        }
    }

    /**
    * @method : Create verify Forgot Password Otp Object request
    * @param mpinResetObj : Verify Forgot Password otp object
    * @returns Returns Forgot Password Otp Object
    */
    getForgotPasswordOtpRequest(verifyOtpObj) {
        try {
            let reqOTPGenerate: any = {};
            reqOTPGenerate.user_id = verifyOtpObj.user_id;
            reqOTPGenerate.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            reqOTPGenerate.source =clsConstants.PRODUCT_SOURCE;// verifyOtpObj.source;
            reqOTPGenerate.otp = verifyOtpObj.otp;
            reqOTPGenerate.product_mode = 21; //to be passed for wave source will be used.
            return reqOTPGenerate;
        } catch (error) {
            console.log("Error + getForgotPasswordOtpRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getForgotPasswordOtpRequest', error);
            return null;
        }
    }

    /**
    * @method : Create verify Otp Object request
    * @param mpinResetObj : Verify otp object
    * @returns Returns Otp Object
    */
    getFingerPrintEnableRequest(verifyOtpObj) {
        try {
            let reqOTPGenerate: any = {};
            reqOTPGenerate.userId = verifyOtpObj.userId;
            reqOTPGenerate.api_key = clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY");
            reqOTPGenerate.OTP = verifyOtpObj.OTP;
            reqOTPGenerate.mobileNo = verifyOtpObj.mobileNo;
            reqOTPGenerate.reqType = verifyOtpObj.reqType;
            return reqOTPGenerate;
        } catch (error) {
            console.log("Error + getFingerPrintEnableRequest"+ error);
            clsGlobal.logManager.writeErrorLog('clsAPIParser', 'getFingerPrintEnableRequest', error);
           
            return null;
        }
    }
}