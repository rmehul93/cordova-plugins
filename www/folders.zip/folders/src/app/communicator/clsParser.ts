import { clsTradingMethods } from "../Common/clsTradingMethods";
import { StringBuilder } from 'typescript-string-operations';
import { clsConstants, OperationType } from "../Common/clsConstants";
import { clsScripKey } from "../Common/clsScripKey";
import { clsOnlineResponse } from "./clsOnlineResponse";
import { clsMultiTouchLineResponse } from "./clsMultiTouchLineResponse";
import { clsResponseStore } from "./clsResponseStore";
import { clsIndexInfoResponse } from "./clsIndexInfoResponse";
import { Dictionary } from "../Common/clsCustomClasses";
import { clsBestFiveResponse } from "./clsBestFiveResponse";
import { clsTopGainerResponse, clsTopGainerScrip } from "./clsTopGainerResponse";
import { clsScrip } from "../Common/clsScrip";
import { clsMostActiveResponse, clsMostActiveScrip } from "./clsMostActiveResponse";
import { clsNewsResponse } from "./clsNewsResponse";
import { clsIndexDetailsResponse } from "./clsIndexDetailsResponse";
import { clsTERResponse } from "./clsTERResponse";
import { clsTopGainerRequest } from "./clsTopGainerRequest";
import { clsMostActiveRequest } from "./clsMostActiveRequest";
import { clsGlobal } from "../Common/clsGlobal";
import { clsBestFiveRequest } from "./clsBestFiveRequest";
import { clsOrderEntryRequest } from "../Common/clsOrderEntryRequest";

export class clsParser {

    public static Instance: clsParser = new clsParser();

    public maskMsgLength: string = '#PACKET_LENGTH#';

    /// <summary>
    /// Function to generate the Message Header which is required for every Odinconnect related requests
    /// </summary>
    createRequestMessageHeader(_messageCode): string {

        try {
            let _sbMessageHeader = new StringBuilder();
            // _sbMessageHeader.Length = 0;            
            let _currentTime = clsTradingMethods.GetCurrentTime(); //_date.toLocaleTimeString();

            if (_messageCode == clsConstants.C_V_MSGCODES_POSITION_CONVERSION_REQUEST) {
                _sbMessageHeader.Append(clsConstants.C_S_TAG_MSGVERSION + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_TAG_COMMPROTOCOL + clsConstants.C_S_FIELD_DELIMITER);
                _sbMessageHeader.Append(clsConstants.C_S_TAG_MSGCODE + clsConstants.C_S_NAMEVALUE_DELIMITER + _messageCode + clsConstants.C_S_FIELD_DELIMITER);
                _sbMessageHeader.Append(clsConstants.C_S_TAG_MSGLENGTH + clsConstants.C_S_NAMEVALUE_DELIMITER + this.maskMsgLength + clsConstants.C_S_FIELD_DELIMITER);
                _sbMessageHeader.Append(clsConstants.C_S_TAG_MSGTIME + clsConstants.C_S_NAMEVALUE_DELIMITER + _currentTime + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                _sbMessageHeader.Append(clsConstants.C_S_TAG_MSGCODE + clsConstants.C_S_NAMEVALUE_DELIMITER + _messageCode + clsConstants.C_S_FIELD_DELIMITER);
            }
            return _sbMessageHeader.ToString();

        } catch (e) {
        }
    };

    /// <summary>
    /// Function to calculate the final packet length and replace the value of length in Message length tag
    /// </summary>
    calculateMessageLength(_request) {
        try {
            let _intPktLength = _request.length;
            let _strPktLength = (_intPktLength + _intPktLength.toString().length - this.maskMsgLength.length).toString();
            return _request.replace(this.maskMsgLength, _strPktLength);
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Function to create the Login Request
    /// </summary>
    /// <returns type="String"></returns>
    createLoginRequest(channelId: string) {
        try {

            let _sbFinalRequest = new StringBuilder();
            if (channelId == clsConstants.C_S_CHANNEL_BROADCAST) {
                _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_V_MSGCODES_LOGINREQUEST));
            } else {
                _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_SOCKETLOGINREQUEST));
            }
            _sbFinalRequest.Append(clsConstants.C_S_TAG_USERID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.userId + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_PWD + clsConstants.C_S_NAMEVALUE_DELIMITER + "" + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_GROUPID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsTradingMethods.Trim(clsGlobal.User.groupId || '') + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_IWINLOGONTAG + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_NETNETLOGONTAG + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_CONNECTION_TYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_CONNECTIONTYPE + clsConstants.C_S_FIELD_DELIMITER);
            //_sbFinalRequest.Append(clsConstants.C_S_TAG_IPADDRESS + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User,ClientIPAddress);
            //console.log("Socket login "+_sbFinalRequest.ToString());
            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        } catch (e) {

        }
    }

    /// <summary>
    /// Function to create the Touch Line Request
    /// </summary>
    createTouchLineRequest(_operationType: OperationType, _lstTLRequest: clsScripKey[]) {
        try {
            if (!clsGlobal.User.isGuestUser) {
                let _sbFinalRequest = new StringBuilder();
                _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_MULTIPLE_TOUCHLINE_REQUEST));
                _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);

                for (var i = 0; i < _lstTLRequest.length; i++) {
                    _sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].MktSegId);
                    _sbFinalRequest.Append(clsConstants.C_S_RECORD_DELIMITER);
                    _sbFinalRequest.Append(clsConstants.C_S_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].token);
                    _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
                }
                
                //PrajyotD - 20-01-2021 for MTL Touchline (s)
                _sbFinalRequest.Append(clsConstants.C_S_TAG_CUMULATIVEOI + clsConstants.C_S_NAMEVALUE_DELIMITER + "1" + clsConstants.C_S_FIELD_DELIMITER);
                //PrajyotD - 20-01-2021 for MTL Touchline (e)
                _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _operationType);
                _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);

                let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
                return _strFinalRequest;
            } else {
                return _lstTLRequest;
            }
        } catch (e) {
            return "";
        }

    };

    //Created by Kunal Kolhe for AppSuspend Request
    createAppSuspendRequest() {
        try {
            let _sbFinalRequest = new StringBuilder();

            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_PAUSERESUME_REQUEST));
            _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + '1');

            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        } catch (e) {
        }
    };

    //Created by Kunal Kolhe for AppResume Request
    createAppResumeRequest() {
        try {

            let _sbFinalRequest = new StringBuilder();

            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_PAUSERESUME_REQUEST));
            _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + '2');

            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        } catch (e) {

        }
    };

    //Index Info Request
    /// <summary>
    /// Function to create the Touch Line Request
    /// </summary>
    createMoreIndicesInfoRequest(_operationType: OperationType, _lstTLRequest) {
        try {
            let _sbFinalRequest = new StringBuilder();
            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_MORE_INDICES_REQUEST));
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);

            for (var i = 0; i < _lstTLRequest.length; i++) {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].MktSegId);
                _sbFinalRequest.Append(clsConstants.C_S_RECORD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_S_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].Token);
                _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            }

            _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _operationType);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);
            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        } catch (e) {

        }

    };

    /// <summary>
    /// Function to create the Best Five Request
    /// </summary>
    createBestFiveRequest(_objBestFiveReq: clsBestFiveRequest) {
        try {
            let _sbFinalRequest = new StringBuilder();

            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_BESTFIVE_REQUEST));
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER + _objBestFiveReq.Scrip.scripDet.token);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _objBestFiveReq.Scrip.scripDet.MktSegId);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objBestFiveReq.OperationType);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);
            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        }
        catch (e) {

        }

    };

    /// <summary>
    /// Function to create the Top Gainers Losers Request
    /// </summary>
    createTopGainerRequest(_objTopGainerRequest: clsTopGainerRequest) {
        try {
            let _sbFinalRequest = new StringBuilder();
            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_TOPGAINERSLOSERS_REQUEST));
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            if (_objTopGainerRequest.BroadcastReqType == 1) {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_BCASTREQTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_GAINERS + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_BCASTREQTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_LOSERS + clsConstants.C_S_FIELD_DELIMITER);
            }
            _sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.SegmentId);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_MARKETTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.MarketType + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_SERIES + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.Series + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_S_TAG_MINVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.MinValue + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_MAXVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.MaxValue + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_S_TAG_NOOFRECORDS + clsConstants.C_S_NAMEVALUE_DELIMITER + _objTopGainerRequest.NoOfRecords);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);
            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;

        } catch (e) {

        }
    };

    /// <summary>
    /// Function to create the Most Active Request
    /// </summary>
    /// <param name="_objMostActiveRequest">MostActiveRequest object</param>
    createMostActiveRequest(_objMostActiveRequest: clsMostActiveRequest) {
        try {

            let sbFinalRequest = new StringBuilder();
            sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_MOSTACTIVE_REQUEST));
            sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            if (_objMostActiveRequest.BroadcastReqType == 1) {
                sbFinalRequest.Append(clsConstants.C_S_TAG_BCASTREQTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_BYVOLUME + clsConstants.C_S_FIELD_DELIMITER);
                sbFinalRequest.Append(clsConstants.C_S_TAG_MINVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.MinValue + clsConstants.C_S_FIELD_DELIMITER);
                sbFinalRequest.Append(clsConstants.C_S_TAG_MAXVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.MaxValue + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                sbFinalRequest.Append(clsConstants.C_S_TAG_BCASTREQTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + clsConstants.C_S_BYVALUE + clsConstants.C_S_FIELD_DELIMITER);
                sbFinalRequest.Append(clsConstants.C_S_TAG_MINVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.MinValue + clsConstants.C_S_FIELD_DELIMITER);
                sbFinalRequest.Append(clsConstants.C_S_TAG_MAXVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.MaxValue + clsConstants.C_S_FIELD_DELIMITER);
            }

            sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.SegmentId + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_S_TAG_MARKETTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.MarketType + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_S_TAG_SERIES + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.Series + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_S_TAG_NOOFRECORDS + clsConstants.C_S_NAMEVALUE_DELIMITER + _objMostActiveRequest.NoOfRecords);
            sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);

            let strFinalRequest = this.calculateMessageLength(sbFinalRequest.toString());
            return strFinalRequest;

        } catch (e) {

        }
    };

    createKeepAliveRequest() {
        try {
            let sbFinalRequest = new StringBuilder();
            sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_V_MSGCODES_KEEPALIVE_REQUEST));
            sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken);
            let strFinalRequest = this.calculateMessageLength(sbFinalRequest.ToString());
            return strFinalRequest;
        } catch (e) {

        }
    };

    /// <summary>
    /// Function to create the Index Details Request
    /// </summary>
    createIndexDetailsRequest(_objIndexDetailsRequest) {
        try {

            let sbFinalRequest = new StringBuilder();
            sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_INDEX_DETAILS_REQUEST));
            sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _objIndexDetailsRequest.SegmentId);
            sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);
            let strFinalRequest = this.calculateMessageLength(sbFinalRequest.ToString());
            return strFinalRequest;
        } catch (e) {

        }
    };


    /// <summary>
    /// Function to create the Index Details Request
    /// </summary>
    createIndexSubscriptionRequest(_objIndexDetailsRequest) {
        try {
            let sbFinalRequest = new StringBuilder();
            sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_INDEX_SUBSCRIPTION_REQUEST));
            sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.DefaultSITemplate + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(_objIndexDetailsRequest.Data);
            sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);

            let strFinalRequest = this.calculateMessageLength(sbFinalRequest.ToString());
            return strFinalRequest;
        } catch (e) {

        }
    };

    /// <summary>
    /// Function to create the Touch Line Request
    /// </summary>
    createLTPTouchLineRequest(_operationType: OperationType, _lstTLRequest: clsScripKey[]) {

        try {
            let _sbFinalRequest = new StringBuilder();
            _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_S_MSGCODE_LTP_MULTIPLE_TOUCHLINE_REQUEST));

            _sbFinalRequest.Append(clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);

            for (let i = 0; i < _lstTLRequest.length; i++) {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].MktSegId);
                _sbFinalRequest.Append(clsConstants.C_S_RECORD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_S_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER + _lstTLRequest[i].token);
                _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            }

            _sbFinalRequest.Append(clsConstants.C_S_TAG_OPERATIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _operationType);
            _sbFinalRequest.Append(clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.SITemplateId);

            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;
        } catch (e) {

        }

    };

    createMarketStatusRequest() {
        try {

            let _sbFinalRequest = new StringBuilder();
            //TODO:
            _sbFinalRequest.Append(clsConstants.C_V_TAG_MSGCODE + clsConstants.C_S_NAMEVALUE_DELIMITER +
                clsConstants.C_V_MSGCODES_MARKETSTATUS_REPONSE + clsConstants.C_S_FIELD_DELIMITER +
                clsConstants.C_S_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER
                + clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER +
                clsGlobal.User.SITemplateId);

            let _strFinalRequest = _sbFinalRequest.ToString();
            return _strFinalRequest;
        }
        catch (e) {

        }
    }

    /// <summary>
    /// Handler for Order Entry Request
    /// Whenever Order will be send via LITE mode below function will be called
    /// </summary>
    /// <param name="_orderEntryRequest" type="Object">
    /// OrderEntryRequest object
    /// </param>
    createOrderEntryRequest(_orderEntryRequest: clsOrderEntryRequest) {

        try {

            let _sbFinalRequest = new StringBuilder();

            if (_orderEntryRequest.ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) //different msgcode for bracket order
            {
                _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_V_MSGCODES_BRACKETORDER_ORDER_REQUEST));

                _sbFinalRequest.Append(clsConstants.C_S_TAG_ISSPREADSCRIP + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.LegIndicator + clsConstants.C_S_FIELD_DELIMITER);
            }
            else { //normal order case
                _sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_V_MSGCODES_ORDERENTRYMODIFYCANCEL_REQUEST));

                if (_orderEntryRequest.IsSpread)
                    _sbFinalRequest.Append(clsConstants.C_S_TAG_ISSPREADSCRIP + clsConstants.C_S_NAMEVALUE_DELIMITER + "3" + clsConstants.C_S_FIELD_DELIMITER);
                else
                    _sbFinalRequest.Append(clsConstants.C_S_TAG_ISSPREADSCRIP + clsConstants.C_S_NAMEVALUE_DELIMITER + "0" + clsConstants.C_S_FIELD_DELIMITER);
            }

            if (_orderEntryRequest.ModifyFlag && _orderEntryRequest.ProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE) {//Remapping order side for margin plus order side
                if (_orderEntryRequest.OrderSide === clsConstants.C_S_ORDER_BUY_TEXT)
                    _orderEntryRequest.OrderSide = clsConstants.C_S_ORDER_SELL_TEXT;
                else
                    _orderEntryRequest.OrderSide = clsConstants.C_S_ORDER_BUY_TEXT;
            }
            _sbFinalRequest.Append(clsConstants.C_V_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.MarketSegID + clsConstants.C_S_FIELD_DELIMITER);
            //TODO:
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.TokenNo + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDERTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.OrderType + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_BUYORSELL + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsTradingMethods.setBuySell(_orderEntryRequest.OrderSide) + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_ORIGQTY + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.Qty + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_DISCLOSEDQTY + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.DiscQty + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.Price, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);
            _sbFinalRequest.Append(clsConstants.C_V_TAG_TRIGPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.TriggerPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_VALIDITY + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.Validity + clsConstants.C_S_FIELD_DELIMITER);


            if (_orderEntryRequest.Validity == clsConstants.C_V_ORDER_GTD || _orderEntryRequest.Validity == clsConstants.C_V_ORDER_EOTODY) {
                if (_orderEntryRequest.MarketSegID == clsConstants.C_V_BSE_CASH) {
                    _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDGTD + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + "0" + clsConstants.C_S_FIELD_DELIMITER);
                }
                else {
                    _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDGTD + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + _orderEntryRequest.Days + clsConstants.C_S_FIELD_DELIMITER);
                }
            }

            //TODO:
            // if validity is GTW or GTM then only include ORDGTD tag
            // if (_orderEntryRequest.Validity == clsConstants.C_V_ORDER_GTW || _orderEntryRequest.Validity == clsConstants.C_V_ORDER_GTM) {
            //     _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDGTD + clsConstants.C_S_NAMEVALUE_DELIMITER
            //                               + _orderEntryRequest.Days + clsConstants.C_S_FIELD_DELIMITER);
            // }

            if (_orderEntryRequest.Exchange == clsConstants.C_S_DFM_EXCHANGE_TEXT ||
                _orderEntryRequest.Exchange == clsConstants.C_S_ADX_EXCHANGE_TEXT) {

                //TODO:
                // if (_orderEntryRequest.FillType == clsConstants.C_S_VALUE_AON)
                //     _sbFinalRequest.Append(clsConstants.C_V_TAG_FILLTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                //                   + "1" + clsConstants.C_S_FIELD_DELIMITER);

                // // Modified by Sakthi for CR 2115 - New Fill Types
                // else if (_orderEntryRequest.FillType == clsConstants.C_S_VALUE_ATBEST)
                //     _sbFinalRequest.Append(clsConstants.C_V_TAG_FILLTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                //                   + "2" + clsConstants.C_S_FIELD_DELIMITER);

                //Is private order for DFM
                /// Modified by Sakthi for CR 2115 - private order for ADX Exchange...
                if (_orderEntryRequest.Exchange == clsConstants.C_S_DFM_EXCHANGE_TEXT || _orderEntryRequest.Exchange == clsConstants.C_S_ADX_EXCHANGE_TEXT) {
                    var isPrivateOrder;
                    if (!_orderEntryRequest.CancelFlag) {
                        if (_orderEntryRequest.isPrivateOrder) {
                            // Changes done for Ticket No:001-00-448590
                            // Checking if it is Private order and Modify order, if yes then check the Old Private value for condition blank, 0 or 6
                            isPrivateOrder = (_orderEntryRequest.ModifyFlag ? ((_orderEntryRequest.OldPrivateValue != '' || _orderEntryRequest.OldPrivateValue == "0" || _orderEntryRequest.OldPrivateValue == "6") ? "7" : "5") : "5");
                        }
                        else if (_orderEntryRequest.ModifyFlag && (_orderEntryRequest.OldPrivateValue == "5" || _orderEntryRequest.OldPrivateValue == "7")) {
                            isPrivateOrder = "6";
                        }
                    }
                    else {
                        isPrivateOrder = _orderEntryRequest.OldPrivateValue;
                    }
                    //TODO:
                    // _sbFinalRequest.Append(clsConstants.C_V_TAG_PRIVATEORDER + clsConstants.C_S_NAMEVALUE_DELIMITER
                    //         + isPrivateOrder + clsConstants.C_S_FIELD_DELIMITER);
                }

                //TODO:
                // _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDER_VALUE + clsConstants.C_S_NAMEVALUE_DELIMITER
                //             + _orderEntryRequest.OrderValue + clsConstants.C_S_FIELD_DELIMITER);

            }

            //TODO:
            _sbFinalRequest.Append(clsConstants.C_V_TAG_CLIENTID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsGlobal.User.userId + clsConstants.C_S_FIELD_DELIMITER);

            // if its a modification or cancellation request, include exchange order no.
            if (_orderEntryRequest.ModifyFlag || _orderEntryRequest.CancelFlag)
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDEXCHORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.ExchangeOrderNo + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_PRODUCTTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.ProductType + clsConstants.C_S_FIELD_DELIMITER);

            // flag 22 should be 1 for new request, 2 for modify and 3 for cancellation...
            if (_orderEntryRequest.ModifyFlag) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDREQUEST_TYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsConstants.C_V_ORDER_REQUEST_MODIFY + clsConstants.C_S_FIELD_DELIMITER);
            }
            else if (_orderEntryRequest.CancelFlag) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDREQUEST_TYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsConstants.C_V_ORDER_REQUEST_CANCEL + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDREQUEST_TYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsConstants.C_V_ORDER_REQUEST_ENTRY + clsConstants.C_S_FIELD_DELIMITER);
            }

            // if instrument is Equity, send blank value of instrument
            if (_orderEntryRequest.Instrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT)
                _sbFinalRequest.Append(clsConstants.C_V_TAG_INSTRUMENTID + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsConstants.C_S_FIELD_DELIMITER);
            else
                _sbFinalRequest.Append(clsConstants.C_V_TAG_INSTRUMENTID + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.Instrument + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_SYMBOL + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.Symbol.toUpperCase() + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_SERIES + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.Series.toUpperCase() + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_EXPIRYDATE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.ExpDate.toUpperCase() + clsConstants.C_S_FIELD_DELIMITER);

            if (_orderEntryRequest.StrikePrice.length > 0)
                _sbFinalRequest.Append(clsConstants.C_V_TAG_STRIKEPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.StrikePrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER)
            else
                _sbFinalRequest.Append(clsConstants.C_V_TAG_STRIKEPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + "0" + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_OPTIONTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.OptionType.toUpperCase() + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_MARKETLOT + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.MarketLot + clsConstants.C_S_FIELD_DELIMITER);

            _sbFinalRequest.Append(clsConstants.C_V_TAG_PRICETICK + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _orderEntryRequest.PriceTick + clsConstants.C_S_FIELD_DELIMITER);

            if (!_orderEntryRequest.ModifyFlag && !_orderEntryRequest.CancelFlag)
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDERTIME + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + "0" + clsConstants.C_S_FIELD_DELIMITER);
            else
                _sbFinalRequest.Append(clsConstants.C_V_TAG_ORDERTIME + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.OrderTime + clsConstants.C_S_FIELD_DELIMITER);

            // Participant ID code
            if (_orderEntryRequest.ParticipantIDTag != "")
                _sbFinalRequest.Append(_orderEntryRequest.ParticipantIDTag + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.ParticipantID + clsConstants.C_S_FIELD_DELIMITER);

            if (!_orderEntryRequest.ModifyFlag && !_orderEntryRequest.CancelFlag) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_CLIENTORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.ClientOrderNumber + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_GATEWAYORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.GatewayOrderNo + clsConstants.C_S_FIELD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_V_TAG_CLIENTORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.ClientOrderNumber + clsConstants.C_S_FIELD_DELIMITER);
            }


            if (_orderEntryRequest.ProductType == clsConstants.C_S_PRODUCTTYPE_MP_VALUE || _orderEntryRequest.ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_MARGINPLUS_EXPIRYVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.MPExpiryValue + clsConstants.C_S_FIELD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_S_TAG_MARGINPLUS_STRIKEPRICEVALUE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.MPStrikePriceValue + clsConstants.C_S_FIELD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_S_TAG_MARGINPLUS_BASEPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.MPBasePrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);


                _sbFinalRequest.Append(clsConstants.C_S_TAG_MARGINPLUS_MFFLAG + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.MPMFFlag + clsConstants.C_S_FIELD_DELIMITER);

                _sbFinalRequest.Append(clsConstants.C_S_TAG_MARGINPLUSPROTPERC + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.MPFirstLegPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                if (_orderEntryRequest.ProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
                    _sbFinalRequest.Append(clsConstants.C_V_TAG_BO_SLORDERTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.SLOrderType + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_SLORDERPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.SLOrderPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_SLTRIGGERPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.SLTriggerPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_PROFITORDERPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.ProfitOrderPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_SLJUMPPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.SLJumpPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_LTPJUMPPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER
                        + clsTradingMethods.calculateFinalPrice(_orderEntryRequest.LTPJumpPrice, _orderEntryRequest.DecimalLocator) + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_BRACKETORDERID + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.BracketOrderId + clsConstants.C_S_FIELD_DELIMITER);

                    //for 2/3 legs of bracket order Main leg Gateway order no will be passed
                    if (_orderEntryRequest.LegIndicator == clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR)
                        _sbFinalRequest.Append(clsConstants.C_V_TAG_BO_GATEWAYORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.GatewayOrderNo + clsConstants.C_S_FIELD_DELIMITER);
                    else
                        _sbFinalRequest.Append(clsConstants.C_V_TAG_BO_GATEWAYORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.BOGatewayOrderNo + clsConstants.C_S_FIELD_DELIMITER);

                    _sbFinalRequest.Append(clsConstants.C_V_TAG_BO_MODIFYTERMS + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.BOModifyTerms + clsConstants.C_S_FIELD_DELIMITER);



                }
            }

            //added for Special Pre Open
            if (_orderEntryRequest.SPOSType == "2" || _orderEntryRequest.SPOSType == "12") {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_SPOSFLAG + clsConstants.C_S_NAMEVALUE_DELIMITER +
                    "1" + clsConstants.C_S_FIELD_DELIMITER);
            }
            else {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_SPOSFLAG + clsConstants.C_S_NAMEVALUE_DELIMITER +
                    "0" + clsConstants.C_S_FIELD_DELIMITER);
            }

            //            //added for Special Pre Open
            //            if (!_orderEntryRequest.CancelFlag) {
            //                _sbFinalRequest.Append(clsConstants.C_S_TAG_SPOSFLAG + clsConstants.C_S_NAMEVALUE_DELIMITER +
            //                    _orderEntryRequest.SPOSType + clsConstants.C_S_FIELD_DELIMITER);
            //            }


            if (_orderEntryRequest.IsSpread) {
                _sbFinalRequest.Append(clsConstants.C_S_TAG_FIRST_LEGPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER +
                    _orderEntryRequest.FIILimit + clsConstants.C_S_FIELD_DELIMITER);

                _sbFinalRequest.Append(clsConstants.C_S_TAG_SECOND_LEGPRICE + clsConstants.C_S_NAMEVALUE_DELIMITER +
                    _orderEntryRequest.NRILimit + clsConstants.C_S_FIELD_DELIMITER);
            }

            /*  changes made for SOR functionality
            *  Two additional tags added
            *  First Tag --> Send Dual LUT
            *  Second Tag --> SORID (uniquely generated at client end) */
            if (_orderEntryRequest.isSOR) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_DUALLUT + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.DualLUT + clsConstants.C_S_FIELD_DELIMITER);
                _sbFinalRequest.Append(clsConstants.C_V_TAG_SORID + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.SORID + clsConstants.C_S_FIELD_DELIMITER);
            }

            // if (dConfigMaster.DGCX_CINNOBAR == clsConstants.C_S_ON) {
            //     if (_orderEntryRequest.Validity == 7)
            //         _sbFinalRequest.Append(clsConstants.C_S_TAG_GTT_TIMEFIELD + clsConstants.C_S_NAMEVALUE_DELIMITER +
            //             _orderEntryRequest.TimeField + clsConstants.C_S_FIELD_DELIMITER);
            // }

            _sbFinalRequest.Append(clsConstants.C_V_TAG_MKT_PROT + clsConstants.C_S_NAMEVALUE_DELIMITER +
                clsTradingMethods.calculateFinalProtPerc(_orderEntryRequest.ProtPerc) + clsConstants.C_S_FIELD_DELIMITER);

            //CR 2221 -- Add following tag only for below segments
            if ((_orderEntryRequest.MarketSegID == clsConstants.C_V_NSE_DERIVATIVES || _orderEntryRequest.MarketSegID == clsConstants.C_V_NSX_DERIVATIVES
                || _orderEntryRequest.MarketSegID == clsConstants.C_V_BSECDX_DERIVATIVES) && (_orderEntryRequest.Validity == clsConstants.C_V_ORDER_VALID_TILL_DAY)) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_COL + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + _orderEntryRequest.COL + clsConstants.C_S_FIELD_DELIMITER);
            }

            if (_orderEntryRequest.MarketSegID == clsConstants.C_V_OFS_IPO_BONDS) {
                _sbFinalRequest.Append(clsConstants.C_V_TAG_OFSMARGIN + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.SelMargin + clsConstants.C_S_FIELD_DELIMITER);
            }

            //CR 3725
            if (_orderEntryRequest.RecoId != undefined || _orderEntryRequest.RecoId != null) {
                if (_orderEntryRequest.RecoId.length > 0) {
                    _sbFinalRequest.Append(clsConstants.C_V_TAG_RECOMMENDATIONID + clsConstants.C_S_NAMEVALUE_DELIMITER + _orderEntryRequest.RecoId + clsConstants.C_S_FIELD_DELIMITER);
                }
            }

            //TODO:
            _sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER +
                clsGlobal.User.SITemplateId);

            let _strFinalRequest = this.calculateMessageLength(_sbFinalRequest.ToString());
            return _strFinalRequest;

        } catch (e) {

        }
    }



    /// <summary>
    /// Function to create the Position Conversion Request
    /// </summary>
    /// <param name="objOrderEntryRequest">OrderEntryRequest object</param>
    createPositionConvRequest(objPosConvRequest) {

        let sbFinalRequest = new StringBuilder();
        try {
            //TODO:
            let _iClientOrdNo = clsGlobal.User.clientOrderNumber;

            sbFinalRequest.Append(this.createRequestMessageHeader(clsConstants.C_V_MSGCODES_POSITION_CONVERSION_REQUEST.toString()));

            sbFinalRequest.Append(clsConstants.C_V_TAG_SESSIONID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsGlobal.User.OCToken + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_MKTSEGID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.MktSegID + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.Token + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SYMBOL + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.Symbol.trim() + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SERIES + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.Series.trim() + clsConstants.C_S_FIELD_DELIMITER);

            _iClientOrdNo += 1;
            clsGlobal.User.clientOrderNumber = _iClientOrdNo;
            sbFinalRequest.Append(clsConstants.C_V_TAG_CLIENTORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _iClientOrdNo + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_GATEWAYORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                + _iClientOrdNo + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_BUYORSELL + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.BuySell + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_ORIGQTY + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.Quantity + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_CLIENTID + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsGlobal.User.userId + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_USERMARKS + clsConstants.C_S_NAMEVALUE_DELIMITER
                + '' + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_ORDREQUEST_TYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + clsConstants.C_V_MSGCODES_POSITION_CONVERSION_ENTRY + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_PRODUCTTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.ProductType + clsConstants.C_S_FIELD_DELIMITER);
            sbFinalRequest.Append(clsConstants.C_V_TAG_SOURCEPRODTYPE + clsConstants.C_S_NAMEVALUE_DELIMITER
                + objPosConvRequest.SourceProductType + clsConstants.C_S_FIELD_DELIMITER);

            if (objPosConvRequest.SourceProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE) {
                sbFinalRequest.Append(clsConstants.C_S_TAG_ISSPREADSCRIP + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + objPosConvRequest.LegIndicator + clsConstants.C_S_FIELD_DELIMITER);
                sbFinalRequest.Append(clsConstants.C_V_TAG_BO_GATEWAYORDERNO + clsConstants.C_S_NAMEVALUE_DELIMITER
                    + objPosConvRequest.BOGatewayOrderNo + clsConstants.C_S_FIELD_DELIMITER);
            }
            sbFinalRequest.Append(clsConstants.C_V_TAG_SI_TEMPLATEID + clsConstants.C_S_NAMEVALUE_DELIMITER +
                clsGlobal.User.SITemplateId);
        }
        catch (e) {

        }

        let strFinalRequest = this.calculateMessageLength(sbFinalRequest.ToString());
        return strFinalRequest;
    }

    /// <summary>
    /// Function to process the Logon Response
    /// </summary>
    processLogonResponse(_responsePacket: string, _channelId: string): clsOnlineResponse {

        let objResp: clsOnlineResponse = null;
        let _strLoginResponse = '';
        let _sMsgCode = '';
        let _sAuthCode = '';
        try {
            objResp = new clsOnlineResponse();
            _sMsgCode = clsTradingMethods.FindValue(_responsePacket, clsConstants.C_S_TAG_MSGCODE);
            let _resArray = clsTradingMethods.LookUp(_responsePacket);

            _sAuthCode = _resArray[clsConstants.C_S_TAG_AUTHCODE];
            if (_sAuthCode !== '') {
                //TODO:
                _strLoginResponse = " " + _channelId + " " + clsGlobal.dMsgMaster.getItem("NNSL98");
                objResp.MsgCode = _sMsgCode;
                objResp.MsgData = _strLoginResponse;
                objResp.MsgTime = clsTradingMethods.GetCurrentTime();
                objResp.MsgCategory = clsConstants.C_S_MSGCAT_ACK;
                objResp.OrderSide = clsConstants.C_S_MSGCAT_LOGIN;    //For color purpose
            }

            return objResp;
        } catch (e) {

        }
    }

    /// <summary>
    /// Function to process the Multi TouchLine Response
    /// Multi TouchLine Response string
    /// </summary>
    processMultiTouchLineResponse(_responsePacket: string): clsMultiTouchLineResponse {

        let _objMultiTLResponse: clsMultiTouchLineResponse = null;
        try {
            let lstResponse = clsTradingMethods.LookUp(_responsePacket);
            let skScrip: clsScripKey = new clsScripKey();
            skScrip.MktSegId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID));
            skScrip.token = lstResponse.getItem(clsConstants.C_S_TAG_SCRIPTOKEN);
            _objMultiTLResponse = clsResponseStore.getTouchLineResponseObject(skScrip.toString(), true);
            //if response received for scrip which is removed from request store then return null
            if (_objMultiTLResponse == null) {
                return _objMultiTLResponse;
            }

            _objMultiTLResponse.Scrip = skScrip;
            _objMultiTLResponse.LUT = lstResponse.getItem(clsConstants.C_S_TAG_LUT);

            let intDecimalLocator = 100;

            if (lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "" || lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "0")
                intDecimalLocator = 100;
            else
                intDecimalLocator = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR));

            let _strPriceFormat = clsTradingMethods.getPriceFormatter(intDecimalLocator.toString(), skScrip.MapMktSegId);

            _objMultiTLResponse.PriceFormat = _strPriceFormat;
            _objMultiTLResponse.DecimalLocator = intDecimalLocator;
            //these tags will always be present in touchline Response whether CCast On or OFF so directly accessing value from list
            _objMultiTLResponse.LTP = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_LTP), intDecimalLocator, _strPriceFormat);
            if (_objMultiTLResponse.LTP == '')
                _objMultiTLResponse.LTP = "0.00";

            _objMultiTLResponse.PercNetChange = (parseFloat(lstResponse.getItem(clsConstants.C_S_TAG_NETCHANGEFROMPREVCLOSE))).toFixed(2);

            _objMultiTLResponse.LTQ = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_LTQ), 0);
            _objMultiTLResponse.LTT = lstResponse.getItem(clsConstants.C_S_TAG_LTT);

            _objMultiTLResponse.BuyQty = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_BUYQTY), 0);
            _objMultiTLResponse.BuyPrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_BUYPRICE), intDecimalLocator, _strPriceFormat);

            _objMultiTLResponse.SellQty = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_SELLQTY), 0);
            _objMultiTLResponse.SellPrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_SELLPRICE), intDecimalLocator, _strPriceFormat);

            _objMultiTLResponse.Volume = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_VOLUME), 0);
            _objMultiTLResponse.ClosePrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_CLOSEPRICE), intDecimalLocator, _strPriceFormat);
            _objMultiTLResponse.ATP = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_ATP), intDecimalLocator, _strPriceFormat);

            // belows tags will not be present in CCast touchline response so first checking existance then accessing value
            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_NETCHANGEINRS))
                _objMultiTLResponse.NetChangeInRs = lstResponse.getItem(clsConstants.C_S_TAG_NETCHANGEINRS);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_OPENPRICE))
                _objMultiTLResponse.OpenPrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_OPENPRICE), intDecimalLocator, _strPriceFormat);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_HIGHPRICE))
                _objMultiTLResponse.HighPrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_HIGHPRICE), intDecimalLocator, _strPriceFormat);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_LOWPRICE))
                _objMultiTLResponse.LowPrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_LOWPRICE), intDecimalLocator, _strPriceFormat);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_OPENINTEREST))
                _objMultiTLResponse.OpenInt = lstResponse.getItem(clsConstants.C_S_TAG_OPENINTEREST);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_TOTBUYQTY)) {
                // changed to double as for index token in TotalBuyQty MktCapitalization will be received
                try {
                    _objMultiTLResponse.TotalBuyQty = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_TOTBUYQTY), 1);
                }
                catch (e) {

                };
            }

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_TOTSELLQTY))
                _objMultiTLResponse.TotalSellQty = this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_TOTSELLQTY), 0);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_LIFETIMEHIGH))
                _objMultiTLResponse.LifeTimeHigh = (parseFloat(lstResponse.getItem(clsConstants.C_S_TAG_LIFETIMEHIGH)) / intDecimalLocator).toFixed(_strPriceFormat);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_LIFETIMELOW))
                _objMultiTLResponse.LifeTimeLow = (parseFloat(lstResponse.getItem(clsConstants.C_S_TAG_LIFETIMELOW)) / intDecimalLocator).toFixed(_strPriceFormat);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_DPR))
                _objMultiTLResponse.DPR = lstResponse.getItem(clsConstants.C_S_TAG_DPR);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_PERC_OPENINTEREST))
                _objMultiTLResponse.PercOpenInt = lstResponse.getItem(clsConstants.C_S_TAG_PERC_OPENINTEREST);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_HIGH_OPENINTEREST))
                _objMultiTLResponse.HighOpenInt = lstResponse.getItem(clsConstants.C_S_TAG_HIGH_OPENINTEREST);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_LOW_OPENINTEREST))
                _objMultiTLResponse.LowOpenInt = lstResponse.getItem(clsConstants.C_S_TAG_LOW_OPENINTEREST);

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE))
                _objMultiTLResponse.TER = clsTradingMethods.ParseTER(skScrip.MktSegId, lstResponse.getItem(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE));

            lstResponse = null;
            skScrip = null;
            _responsePacket = null;

            return _objMultiTLResponse;
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Function to process the Multi TouchLine Response
    /// Multi TouchLine Response string
    /// </summary>
    processLTPMultiTouchLineResponse(_responsePacket) {

        let _objMultiTLResponse: clsMultiTouchLineResponse = null;
        try {
            let lstResponse = clsTradingMethods.LookUp(_responsePacket);
            let skScrip: clsScripKey = new clsScripKey();
            skScrip.MktSegId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID));
            skScrip.token = lstResponse.getItem(clsConstants.C_S_TAG_SCRIPTOKEN);

            //gets the touchline object (new or existing) from response store based on clsScripKey
            _objMultiTLResponse = clsResponseStore.getLTPTouchLineResponseObject(skScrip.toString(), true); //TODO

            //if response received for scrip which is removed from request store then return null
            if (_objMultiTLResponse == null) {
                lstResponse = null;
                skScrip = null;
                return _objMultiTLResponse;
            }

            _objMultiTLResponse.Scrip = skScrip;
            _objMultiTLResponse.LUT = lstResponse.getItem(clsConstants.C_S_TAG_LUT);

            let intDecimalLocator = 100;

            if (lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "" || lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "0")
                intDecimalLocator = 100;
            else
                intDecimalLocator = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR));

            let _strPriceFormat = clsTradingMethods.getPriceFormatter(intDecimalLocator.toString(), skScrip.MapMktSegId);

            _objMultiTLResponse.PriceFormat = _strPriceFormat;
            _objMultiTLResponse.DecimalLocator = intDecimalLocator;

            //these tags will always be present in touchline Response whether CCast On or OFF so directly accessing value from list
            _objMultiTLResponse.LTP = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_LTP), intDecimalLocator, _strPriceFormat);

            let blankLTP = 0;
            if (_objMultiTLResponse.LTP == '')
                _objMultiTLResponse.LTP = blankLTP.toFixed(_strPriceFormat);
            _objMultiTLResponse.ClosePrice = this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_CLOSEPRICE), intDecimalLocator, _strPriceFormat);

            lstResponse = null;
            skScrip = null;

            return _objMultiTLResponse;
        }
        catch (e) {

        }
    };

    //PrajyotD - 20-01-2021 for MTL Touchline (s)
    /// <summary>
        /// Function to process the Multi TouchLine Response
        /// Multi TouchLine Response string
        /// </summary>
        /// <param name="_responsePacket" type="String" >
        /// </param>
        /// <returns type="MultiTouchLineResponse"></returns>
    processMultiMTLResponse (_responsePacket) {
        
        var _objMultiTLResponse = null;
        try {
            let _respData = _responsePacket.split('|');
            //let lstResponse = JSON.parse(_respData[2].split('=')[1]);
            let lstResponse = _responsePacket.substr(_responsePacket.indexOf('|50=')+4);//(_respData[2].split('=')[1]);
            let _data = new ArrayBuffer(lstResponse.length);
            let dataActual = new Uint8Array(lstResponse.length);
            for (let i = 0; i < lstResponse.length; i += 1) {
                //_data[i] = lstResponse.charCodeAt(i);
                dataActual[i] = lstResponse.charCodeAt(i);
            }

            let dvData = new DataView(_data);
            dataActual.forEach(function (b, i) {
                dvData.setUint8(i, b);
            });

            //var dstData = new Uint8Array(4);
            let skScrip: clsScripKey= new clsScripKey() ;
            skScrip.MktSegId = dvData.getUint32(0,true);
            skScrip.token = dvData.getUint32(4, true).toString();
            //skScrip.MapMktSegId = WWTradingMethods.GetMappedMarketSegmentId(skScrip.MktSegId);
            //console.log("MTL Data: " + JSON.parse(MTLData[1]));
            //gets the touchline object (new or existing) from response store based on ScripKey
            _objMultiTLResponse = clsResponseStore.getTouchLineResponseObject(skScrip.toString(), true); 
            
            //if response received for scrip which is removed from request store then return null
            if (_objMultiTLResponse == null) {
                
                return _objMultiTLResponse;
            }

            _objMultiTLResponse.Scrip = skScrip;
            _objMultiTLResponse.LUT = clsTradingMethods.getDateTime(dvData.getUint32(8, true));//WWTradingMethods.getDateTime(parseInt(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_LUT]));

            var intDecimalLocator = 100;

            if (lstResponse[clsConstants.C_S_OFFSET_MTL_RESPONSE_DECLOC] == "" ||
                lstResponse[clsConstants.C_S_OFFSET_MTL_RESPONSE_DECLOC] == "0")
                intDecimalLocator = 100;
            else
                intDecimalLocator = dvData.getUint32(52, true);//parseInt(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_DECLOC]);
           
            let _strPriceFormat = clsTradingMethods.getPriceFormatter(intDecimalLocator.toString(), skScrip.MapMktSegId);
            

            _objMultiTLResponse.PriceFormat = _strPriceFormat;

            _objMultiTLResponse.DecimalLocator = intDecimalLocator;

            //these tags will always be present in touchline Response whether CCast On or OFF so directly accessing value from list
            _objMultiTLResponse.LTP = this.priceFormatter(dvData.getUint32(16, true), intDecimalLocator, _strPriceFormat); //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_LTP], intDecimalLocator, _strPriceFormat);
            if (_objMultiTLResponse.LTP == '')
                _objMultiTLResponse.LTP = "0.00";

            //_objMultiTLResponse.PercNetChange = (parseFloat(lstResponse[Global.Constants.C_S_TAG_NETCHANGEFROMPREVCLOSE])).toFixed(2);

            //_objMultiTLResponse.LTQ = this.qtyFormatter(lstResponse[Global.Constants.C_S_TAG_LTQ], 0);
            _objMultiTLResponse.LTT = clsTradingMethods.getDateTime(dvData.getUint32(12, true)); //WWTradingMethods.getDateTime(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_LTT]);

            _objMultiTLResponse.BuyQty = this.qtyFormatter(dvData.getUint32(20, true),0);//this.qtyFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_BQTY], 0);
            _objMultiTLResponse.BuyPrice = this.priceFormatter(dvData.getUint32(24, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_BPRICE], intDecimalLocator, _strPriceFormat);

            _objMultiTLResponse.SellQty = this.qtyFormatter(dvData.getUint32(28, true), 0);; //this.qtyFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_SQTY], 0);
            _objMultiTLResponse.SellPrice = this.priceFormatter(dvData.getUint32(32, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_SPRICE], intDecimalLocator, _strPriceFormat);

            //_objMultiTLResponse.Volume = this.qtyFormatter(lstResponse[Global.Constants.C_S_TAG_VOLUME], 0);
            _objMultiTLResponse.ClosePrice = this.priceFormatter(dvData.getUint32(48, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_CLOSE], intDecimalLocator, _strPriceFormat);
            //_objMultiTLResponse.ATP = this.priceFormatter(lstResponse[Global.Constants.C_S_TAG_ATP], intDecimalLocator, _strPriceFormat);
           
            _objMultiTLResponse.OpenPrice = this.priceFormatter(dvData.getUint32(36, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_OPEN], intDecimalLocator, _strPriceFormat);
            _objMultiTLResponse.HighPrice = this.priceFormatter(dvData.getUint32(40, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_HIGH], intDecimalLocator, _strPriceFormat);
            _objMultiTLResponse.LowPrice = this.priceFormatter(dvData.getUint32(44, true), intDecimalLocator, _strPriceFormat);; //this.priceFormatter(lstResponse[Global.Constants.C_S_OFFSET_MTL_RESPONSE_LOW], intDecimalLocator, _strPriceFormat);

            lstResponse = null;
            skScrip = null;
            _responsePacket = null;

            //console.log('Response MTL: ',_objMultiTLResponse);

            return _objMultiTLResponse;
        }
        catch (e) {
            //<JasobNoObfs>
            clsGlobal.logManager.writeErrorLog(e.message, 'ProcessMultiTouchLineResponse', 'OCParser');
            //</JasobNoObfs> 
        }
    };
   //PrajyotD - 20-01-2021 for MTL Touchline (e)

    /// <summary>
    /// Function to process the Multi TouchLine Response
    /// Multi TouchLine Response string
    /// </summary>
    processCMOTTouchLineResponse(_responsePacket) {

        let _objMultiTLResponse: clsMultiTouchLineResponse = null;
        try {
            
            if (_responsePacket.resp.ResponseObject.type == "success") {

                let lstResponse = _responsePacket.resp.ResponseObject.resultset[0];

                let req = _responsePacket.req.split('/');
                let skScrip: clsScripKey = new clsScripKey();
                skScrip.MktSegId = clsTradingMethods.getMktSegFromApiExchangeName(req[1]);
                skScrip.token = req[2];

                //gets the touchline object (new or existing) from response store based on clsScripKey
                _objMultiTLResponse = clsResponseStore.getLTPTouchLineResponseObject(skScrip.toString(), true);

                //if response received for scrip which is removed from request store then return null
                if (_objMultiTLResponse == null) {
                    lstResponse = null;
                    skScrip = null;
                    return _objMultiTLResponse;
                }



                _objMultiTLResponse.Scrip = skScrip;
                _objMultiTLResponse.LUT = lstResponse.UpdateTime;

                let intDecimalLocator = 100;
                let _strPriceFormat = clsTradingMethods.getPriceFormatter(intDecimalLocator.toString(), skScrip.MapMktSegId);

                _objMultiTLResponse.PriceFormat = _strPriceFormat;
                _objMultiTLResponse.DecimalLocator = intDecimalLocator;

                //these tags will always be present in touchline Response whether CCast On or OFF so directly accessing value from list
                _objMultiTLResponse.LTP = lstResponse.Price;

                let blankLTP = 0;
                if (_objMultiTLResponse.LTP == '')
                    _objMultiTLResponse.LTP = blankLTP.toFixed(_strPriceFormat);

                _objMultiTLResponse.PercNetChange = parseFloat(lstResponse.Change).toFixed(2);

                _objMultiTLResponse.BuyQty = this.qtyFormatter(lstResponse.BestBuyQuantity, 0);
                _objMultiTLResponse.BuyPrice = lstResponse.BestBuyPrice;// this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_BUYPRICE), intDecimalLocator, _strPriceFormat);

                _objMultiTLResponse.SellQty = this.qtyFormatter(lstResponse.BestBuyQuantity, 0);
                _objMultiTLResponse.SellPrice = lstResponse.BestSellPrice;

                _objMultiTLResponse.Volume = lstResponse.Volume;// this.qtyFormatter(lstResponse.getItem(clsConstants.C_S_TAG_VOLUME), 0);
                _objMultiTLResponse.ClosePrice = lstResponse.OldPrice;
                //_objMultiTLResponse.ATP = lstResponse.this.priceFormatter(lstResponse.getItem(clsConstants.C_S_TAG_ATP), intDecimalLocator, _strPriceFormat);

                _objMultiTLResponse.NetChangeInRs = parseFloat(lstResponse.PriceDifference).toFixed(2);
                _objMultiTLResponse.OpenPrice = lstResponse.OpenPrice;
                _objMultiTLResponse.HighPrice = lstResponse.HighPrice;
                _objMultiTLResponse.LowPrice = lstResponse.LowPrice;

                _objMultiTLResponse.LifeTimeHigh = lstResponse.FiftyTwoWeekHigh;
                _objMultiTLResponse.LifeTimeLow = lstResponse.FiftyTwoWeekLow;

                lstResponse = null;
                skScrip = null;
                _responsePacket = null;
            }

            return _objMultiTLResponse;
        }
        catch (e) {

        }
    };

    /// <summary>
    /// function to format the price if value is 0 or negative, spread related handling is also done here
    /// </summary>
    priceFormatter(_sPriceVal, _intDecLoc, _strPriceFormat) {
        let _decPrc = parseFloat(_sPriceVal);
        return ((_decPrc <= 0) ? "" : ((_decPrc / _intDecLoc).toFixed(_strPriceFormat))); // Spread related check implementation is pending
    }

    /// <summary>
    /// function to format the Qty if value is 0 or negative
    /// </summary>
    qtyFormatter(_sQtyVal, _intValueIn) {

        if (_intValueIn == 0)
            return (parseInt(_sQtyVal) <= 0) ? "" : parseInt(_sQtyVal);
        else if (_intValueIn == 1)
            return (parseFloat(_sQtyVal) <= 0) ? "" : parseFloat(_sQtyVal);
    }

    processIndexInfoResponse(_responsePacket) {
        let _objclsIndexInfoResponse: clsIndexInfoResponse = null;
        try {
            let lstResponse = clsTradingMethods.LookUp(_responsePacket);
            _objclsIndexInfoResponse = new clsIndexInfoResponse();
            _objclsIndexInfoResponse.IndexType = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_INDEXTYPE), 10);

            let skScrip: clsScripKey = new clsScripKey();
            if (_objclsIndexInfoResponse.IndexType == clsConstants.C_V_MORE_INDEX_NSE)
                skScrip.MktSegId = clsConstants.C_V_NSE_CASH;
            else if (_objclsIndexInfoResponse.IndexType == clsConstants.C_V_MORE_INDEX_BSE)
                skScrip.MktSegId = clsConstants.C_V_BSE_CASH;
            else if (_objclsIndexInfoResponse.IndexType == clsConstants.C_V_MORE_INDEX_MCX)
                skScrip.MktSegId = clsConstants.C_V_MCX_SPOT;
            else if (_objclsIndexInfoResponse.IndexType == clsConstants.C_V_MORE_INDEX_NCDEX)
                skScrip.MktSegId = clsConstants.C_V_NCDEX_SPOT;
            else if (_objclsIndexInfoResponse.IndexType == clsConstants.C_V_GLOBAL_INDEX)
                skScrip.MktSegId = clsConstants.C_V_NSE_DERIVATIVES;

            if (_responsePacket.indexOf(clsConstants.C_S_FIELD_DELIMITER + clsConstants.C_S_TAG_SCRIPTOKEN + clsConstants.C_S_NAMEVALUE_DELIMITER) !== -1)
                skScrip.token = lstResponse.getItem(clsConstants.C_S_TAG_SCRIPTOKEN);
            else
                skScrip.token = "0";

            let intDecLoc = 100;
            if (skScrip.token == "26017") {
                // Condition handled for INDIAVIX
                intDecLoc = 10000;
            }

            _objclsIndexInfoResponse.Scrip = skScrip;
            _objclsIndexInfoResponse.IndexValue = (parseFloat(lstResponse.getItem(clsConstants.C_S_TAG_INDEXVALUE)) / intDecLoc).toFixed(intDecLoc.toString().length - 1);
            _objclsIndexInfoResponse.ClosingIndexValue = parseFloat(lstResponse.getItem(clsConstants.C_S_TAG_CLOSING_INDEX_VALUE)) / intDecLoc;

            if (_objclsIndexInfoResponse.IndexValue > _objclsIndexInfoResponse.ClosingIndexValue)
                _objclsIndexInfoResponse.Trend = "+";
            else if (_objclsIndexInfoResponse.IndexValue < _objclsIndexInfoResponse.ClosingIndexValue)
                _objclsIndexInfoResponse.Trend = "-";
            else
                _objclsIndexInfoResponse.Trend = "=";

            _objclsIndexInfoResponse.LUT = lstResponse.getItem(clsConstants.C_S_TAG_MSGTIME);

            if (lstResponse.getItem(clsConstants.C_V_TAG_OPENPRICE.toString()) != '')
                _objclsIndexInfoResponse.OpenIndex = parseFloat(lstResponse.getItem(clsConstants.C_V_TAG_OPENPRICE.toString())) / intDecLoc;
            if (lstResponse.getItem(clsConstants.C_V_TAG_HIGHPRICE.toString()) != '')
                _objclsIndexInfoResponse.HighIndex = parseFloat(lstResponse.getItem(clsConstants.C_V_TAG_HIGHPRICE.toString())) / intDecLoc;
            if (lstResponse.getItem(clsConstants.C_V_TAG_LOWPRICE.toString()) != '')
                _objclsIndexInfoResponse.LowIndex = parseFloat(lstResponse.getItem(clsConstants.C_V_TAG_LOWPRICE.toString())) / intDecLoc;

            lstResponse = null;
            skScrip = null;
            _responsePacket = null;

            return _objclsIndexInfoResponse;
        }
        catch (e) {

        }
    };

    /// <summary>
    /// This takes Best5 response,append first row of buy & sell side data in Main response,
    /// then process main response by Touchline process function and returns Touchline response
    /// </summary>
    // processBestFiveResponseForMW(_responsePacket) {

    //     let _objMultiTLResponse = null;
    //     let strRespData;
    //     try {

    //         _responsePacket = _responsePacket.replace(/\|12/g, '&12');
    //         strRespData = _responsePacket.split('|');
    //         let dicBuyData: Dictionary<string> = new Dictionary<string>();
    //         let dicSellData: Dictionary<string> = new Dictionary<string>();

    //         let B5 = "";
    //         let S5 = "";
    //         for (let i = 0; i < strRespData.length; i++) {
    //             if (strRespData[i].length > 0) {
    //                 if (strRespData[i].indexOf("&") == -1) {
    //                     let sdata = strRespData[i].split('=');
    //                 }
    //                 else {
    //                     if (strRespData[i].StartsWith("11=1"))
    //                         B5 = strRespData[i];
    //                     if (strRespData[i].StartsWith("11=2"))
    //                         S5 = strRespData[i];
    //                 }
    //             }
    //         }

    //         /* First Split entire Buy and Sell data with respect to &
    //         * We will have length of array equal to 6  */
    //         let strBuyData = B5.split('&');
    //         let strSellData = S5.split('&');

    //         let strB1: any = "";
    //         let strS1: any = "";

    //         /* Taking first Depth details from 1st index, since 0th index has BUY and Sell indication only
    //         /* Split individual data w.r.t. $ */
    //         if (strBuyData[1] !== undefined)
    //             strB1 = strBuyData[1].split('$');
    //         if (strSellData[1] !== undefined)
    //             strS1 = strSellData[1].split('$');

    //         // Further Split Buy data record w.r.t '=' to segregate No of Buyers, Price, Quantity
    //         for (let j = 0; j < strB1.length; j++) {
    //             let sdataB = strB1[j].split('=');
    //             dicBuyData[sdataB[0]] = sdataB[1];
    //         }

    //         // Further Split Sell data record w.r.t '=' to segregate No of Sellers, Price, Quantity
    //         for (let k = 0; k < strS1.length; k++) {
    //             let sdataS = strS1[k].split('=');
    //             dicSellData[sdataS[0]] = sdataS[1];
    //         }

    //         //if buy side data exists then append it to response string
    //         if (strB1.length > 0)
    //             _responsePacket = _responsePacket + "|" + clsConstants.C_V_TAG_BUYPRICE + "=" + dicBuyData[clsConstants.C_S_TAG_ORDPRICE] + "|" + clsConstants.C_V_TAG_BUYQTY + "=" + dicBuyData[clsConstants.C_S_TAG_ORIGQTY];

    //         //if sell side data exists then append it to response string
    //         if (strS1.length > 0)
    //             _responsePacket = _responsePacket + "|" + clsConstants.C_V_TAG_SELLPRICE + "=" + dicSellData[clsConstants.C_S_TAG_ORDPRICE] + "|" + clsConstants.C_V_TAG_SELLQTY + "=" + dicSellData[clsConstants.C_S_TAG_ORIGQTY];

    //         //Clear the dictionary
    //         dicBuyData = null;
    //         dicSellData = null;

    //         //called tocuchline process function to get MultiTL response
    //         _objMultiTLResponse = this.processMultiTouchLineResponse(_responsePacket);

    //         _responsePacket = null;
    //         strRespData = null;

    //         return _objMultiTLResponse;
    //     }
    //     catch (e) {

    //     }
    // };

    /// <summary>
    /// Function to process the Multi TouchLine Response
    /// Multi TouchLine Response string
    /// </summary>
    /// <param name="_responsePacket" type="String" >
    /// </param>
    /// <returns type="BestFiveResponse"></returns>
    processBestFiveResponse(_responsePacket) {
        let _objBestFiveResponse: clsBestFiveResponse = null;
        try {

            let strRespData = [];
            let iLResp = clsTradingMethods.LookUp(_responsePacket);
            let strSegmentId = iLResp.getItem(clsConstants.C_S_TAG_MKTSEGID);
            let strToken = iLResp.getItem(clsConstants.C_S_TAG_SCRIPTOKEN);
            //var objScrip = {};
            //objScrip.ScripDet = {};
            let objScrip: clsScripKey = new clsScripKey();
            objScrip.MktSegId = strSegmentId != "" ? parseInt(strSegmentId) : -1;
            objScrip.token = strToken;

            //gets the Best5 object (new or existing) from response store based on Scrip key
            _objBestFiveResponse = clsResponseStore.getBest5ResponseObject(objScrip.toString(), true);
            //if Best 5 response received for scrip which is removed from request store then return null
            if (_objBestFiveResponse == null) {
                objScrip = null;
                iLResp = null;
                strRespData = null;
                return _objBestFiveResponse;
            }

            _objBestFiveResponse.Scrip = objScrip;
            let intDecimalLocator = 100;
            let decDecLocator = 100;
            if (iLResp.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "" || iLResp.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "0" || iLResp.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR) == "100.00")
                intDecimalLocator = 100;
            else {
                decDecLocator = parseFloat(iLResp.getItem(clsConstants.C_S_TAG_DECIMALLOCATOR)); //Used decimal variable to handle the case of MCXSX where the Decimal locator was "10000.00"
                intDecimalLocator = decDecLocator;
            }

            let _strPriceFormat = clsTradingMethods.getPriceFormatter(intDecimalLocator.toString(), objScrip.MapMktSegId); //intDecimalLocator.toString().length - 1;

            let strVolume = iLResp.getItem(clsConstants.C_S_TAG_VOLUME);
            let strOpenPrice = iLResp.getItem(clsConstants.C_S_TAG_OPENPRICE);
            let strClosePrice = iLResp.getItem(clsConstants.C_S_TAG_CLOSEPRICE);

            let strPerChg = iLResp.getItem(clsConstants.C_S_TAG_NETCHANGEFROMPREVCLOSE);
            let strTBQ = iLResp.getItem(clsConstants.C_S_TAG_TOTBUYQTY);
            let strDPR = iLResp.getItem(clsConstants.C_S_TAG_DPR);
            let strLTT = iLResp.getItem(clsConstants.C_S_TAG_LTT);
            let strLUT = iLResp.getItem(clsConstants.C_S_TAG_LUT);

            let strHighPrice = iLResp.getItem(clsConstants.C_S_TAG_HIGHPRICE);
            let strLowPrice = iLResp.getItem(clsConstants.C_S_TAG_LOWPRICE);
            let strLTQ = iLResp.getItem(clsConstants.C_S_TAG_LTQ);
            let strLTP = iLResp.getItem(clsConstants.C_S_TAG_LTP);

            let strYearHighPrice = iLResp.getItem(clsConstants.C_S_TAG_LIFETIMEHIGH);
            let strYearLowPrice = iLResp.getItem(clsConstants.C_S_TAG_LIFETIMELOW);

            let strTSQ = iLResp.getItem(clsConstants.C_S_TAG_TOTSELLQTY);
            let strATP = iLResp.getItem(clsConstants.C_S_TAG_ATP);

            _responsePacket = _responsePacket.replace(/\|12/g, '&12');
            strRespData = _responsePacket.split('|');

            let B5 = "";
            let S5 = "";
            for (let i = 0; i < strRespData.length; i++) {
                if (strRespData[i].length > 0) {
                    if (strRespData[i].indexOf("&") == -1) {
                        //dont know what have been done here find out later
                        //let sdata = strRespData[i].split('=');
                        continue;
                    }
                    else {
                        if (strRespData[i].startsWith("11=1"))
                            B5 = strRespData[i];
                        if (strRespData[i].startsWith("11=2"))
                            S5 = strRespData[i];
                    }
                }
            }

            /* First Split entire Buy and Sell data with respect to &
            * We will have length of array equal to 6  */
            let strBuyData = B5.split('&');
            let strSellData = S5.split('&');

            /* Iterate through above Buy and Sell data arrays
            * starting from 1st index, since 0th index has BUY and Sell indication only
            * NOTE: Here Length of strBuyData and strSellData will be same hence use any one array length */
            let strB1: any = "";
            let strS1: any = "";
            for (var i = 1; i < strBuyData.length; i++) {
                /* Split individual data w.r.t. $ */
                if (strBuyData[i] !== undefined)
                    strB1 = strBuyData[i].split('$');
                if (strSellData[i] !== undefined)
                    strS1 = strSellData[i].split('$');

                let dicBuyData: Dictionary<string> = new Dictionary<string>();
                let dicSellData: Dictionary<string> = new Dictionary<string>();
                // Further Split Buy data record w.r.t '=' to segregate No of Buyers, Price, Quantity
                for (let j = 0; j < strB1.length; j++) {
                    let sdataB = strB1[j].split('=');
                    dicBuyData.Add(sdataB[0], sdataB[1]);
                }

                // Further Split Sell data record w.r.t '=' to segregate No of Sellers, Price, Quantity
                for (let k = 0; k < strS1.length; k++) {
                    let sdataS = strS1[k].split('=');
                    dicSellData.Add(sdataS[0], sdataS[1]);
                }

                // Fill properties of B5DetailData (Buy and Sell data together as single row)
                //Normal case
                if (!_objBestFiveResponse.IsSpread) {
                    _objBestFiveResponse.BestFiveData[i - 1].sBid = dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE) != "" && parseFloat(dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE)) > 0 ? clsTradingMethods.getPreciseValue((parseFloat(dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE)) / intDecimalLocator).toFixed(_strPriceFormat), parseInt(strSegmentId), intDecimalLocator) : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sBidQty = dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY) != "" ? parseInt(dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY)) > 0 ? dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sBuyers = dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) != "" ? parseInt(dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS)) > 0 ? dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sAsk = dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE) != "" && parseFloat(dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE)) > 0 ? clsTradingMethods.getPreciseValue((parseFloat(dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE)) / intDecimalLocator).toFixed(_strPriceFormat), parseInt(strSegmentId), intDecimalLocator) : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sAskQty = dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY) != "" ? parseInt(dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY)) > 0 ? dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sSellers = dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) != "" ? parseInt(dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS)) > 0 ? dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) : "-" : "-";
                }
                else {
                    _objBestFiveResponse.BestFiveData[i - 1].sBid = dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE) != "" && parseFloat(dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE)) > 0 ? clsTradingMethods.getPreciseValue((parseFloat(dicBuyData.getItem(clsConstants.C_S_TAG_ORDPRICE)) / intDecimalLocator).toFixed(_strPriceFormat), parseInt(strSegmentId), intDecimalLocator) : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sBidQty = dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY) != "" ? parseInt(dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY)) > 0 ? dicBuyData.getItem(clsConstants.C_S_TAG_ORIGQTY) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sBuyers = dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) != "" ? parseInt(dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS)) > 0 ? dicBuyData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sAsk = dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE) != "" && parseFloat(dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE)) > 0 ? clsTradingMethods.getPreciseValue((parseFloat(dicSellData.getItem(clsConstants.C_S_TAG_ORDPRICE)) / intDecimalLocator).toFixed(_strPriceFormat), parseInt(strSegmentId), intDecimalLocator) : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sAskQty = dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY) != "" ? parseInt(dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY)) > 0 ? dicSellData.getItem(clsConstants.C_S_TAG_ORIGQTY) : "-" : "-";
                    _objBestFiveResponse.BestFiveData[i - 1].sSellers = dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) != "" ? parseInt(dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS)) > 0 ? dicSellData.getItem(clsConstants.C_S_TAG_BEST5NOOFORDERS) : "-" : "-";
                }

                //Clear the dictionary to facilitate its filling on next iteration
                dicBuyData = null;
                dicSellData = null;
            }
            _objBestFiveResponse.DecimalLocator = intDecimalLocator;
            _objBestFiveResponse.LUT = strLUT;
            _objBestFiveResponse.Volume = strVolume != "" ? parseInt(strVolume) > 0 ? strVolume : "" : "";

            // Normal Case
            if (!_objBestFiveResponse.IsSpread) {
                _objBestFiveResponse.OpenPrc = strOpenPrice != "" ? parseFloat(strOpenPrice) > 0 ? (parseFloat(strOpenPrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";
                _objBestFiveResponse.ClosePrc = strClosePrice != "" ? parseFloat(strClosePrice) > 0 ? (parseFloat(strClosePrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";
                _objBestFiveResponse.HighPrc = strHighPrice != "" ? parseFloat(strHighPrice) > 0 ? (parseFloat(strHighPrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";
                _objBestFiveResponse.LowPrc = strLowPrice != "" ? parseFloat(strLowPrice) > 0 ? (parseFloat(strLowPrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";
                _objBestFiveResponse.LTP = strLTP != "" ? parseFloat(strLTP) > 0 ? (parseFloat(strLTP) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";

            }
            else {
                _objBestFiveResponse.OpenPrc = strOpenPrice != "" ? strOpenPrice != "0" ? (parseFloat(strOpenPrice) / intDecimalLocator).toString() : "" : "";
                _objBestFiveResponse.ClosePrc = strClosePrice != "" ? strClosePrice != "0" ? (parseFloat(strClosePrice) / intDecimalLocator).toString() : "" : "";
                _objBestFiveResponse.HighPrc = strHighPrice != "" ? strHighPrice != "0" ? (parseFloat(strHighPrice) / intDecimalLocator).toString() : "" : "";
                _objBestFiveResponse.LowPrc = strLowPrice != "" ? strLowPrice != "0" ? (parseFloat(strLowPrice) / intDecimalLocator).toString() : "" : "";
                _objBestFiveResponse.LTP = strLTP != "" ? strLTP != "0" ? (parseFloat(strLTP) / intDecimalLocator).toString() : "" : "";

            }

            if (clsTradingMethods.Trim(strPerChg) == "-100" || clsTradingMethods.Trim(strPerChg) == "-100.00")//Condition handled for preopen
                strPerChg = "";
            _objBestFiveResponse.PercNetChg = strPerChg;
            _objBestFiveResponse.TotBuyQty = strTBQ != "" ? parseInt(strTBQ) > 0 ? strTBQ : "" : "";
            _objBestFiveResponse.DPR = strDPR;
            _objBestFiveResponse.LTT = clsTradingMethods.getDateTimePart(strLTT);
            _objBestFiveResponse.LUT = clsTradingMethods.getDateTimePart(strLUT);

            _objBestFiveResponse.LTQ = strLTQ != "" ? parseInt(strLTQ) > 0 ? strLTQ : "" : "";
            _objBestFiveResponse.PercNetChg = _objBestFiveResponse.LTP != "" ? strPerChg : ""; //If LTP is present then display Percentage change else blank
            _objBestFiveResponse.YrHighPrc = strYearHighPrice != "" ? parseFloat(strYearHighPrice) > 0 ? (parseFloat(strYearHighPrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";
            _objBestFiveResponse.YrLowPrc = strYearLowPrice != "" ? parseFloat(strYearLowPrice) > 0 ? (parseFloat(strYearLowPrice) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";

            _objBestFiveResponse.TotSellQty = strTSQ != "" ? parseInt(strTSQ) > 0 ? strTSQ : "" : "";
            _objBestFiveResponse.ATPPrc = strATP != "" ? parseFloat(strATP) > 0 ? (parseFloat(strATP) / intDecimalLocator).toFixed(_strPriceFormat) : "" : "";

            _objBestFiveResponse.TER = clsTradingMethods.ParseTER(objScrip.MktSegId, iLResp.getItem(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE));
            //_objBestFiveResponse.TER = clsTradingMethods.ParseTER(objScrip.ScripDet.MktSegId, iLResp.getItem(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE]);

            if (iLResp.ContainsKey(clsConstants.C_S_TAG_PERC_OPENINTEREST))
                _objBestFiveResponse.OI = iLResp.getItem(clsConstants.C_V_TAG_OPENINTEREST.toString());

            if (iLResp.ContainsKey(clsConstants.C_S_TAG_PERC_OPENINTEREST))
                _objBestFiveResponse.PercOpenInt = iLResp.getItem(clsConstants.C_S_TAG_PERC_OPENINTEREST);

            if (iLResp.ContainsKey(clsConstants.C_S_TAG_HIGH_OPENINTEREST))
                _objBestFiveResponse.HighOpenInt = iLResp.getItem(clsConstants.C_S_TAG_HIGH_OPENINTEREST);

            if (iLResp.ContainsKey(clsConstants.C_S_TAG_LOW_OPENINTEREST))
                _objBestFiveResponse.LowOpenInt = iLResp.getItem(clsConstants.C_S_TAG_LOW_OPENINTEREST);

            let NetChangeInRs: any = '';
            if (_objBestFiveResponse.LTP != '' && _objBestFiveResponse.ClosePrc != '')
                NetChangeInRs = parseFloat(_objBestFiveResponse.LTP) - parseFloat(_objBestFiveResponse.ClosePrc);

            _objBestFiveResponse.NetChangeInRs = NetChangeInRs != '' ? NetChangeInRs.toFixed(_strPriceFormat) : '';
            _objBestFiveResponse.PriceFormat = _strPriceFormat;

            iLResp = null;
            objScrip = null;
            _responsePacket = null;
            strRespData = null;

            return _objBestFiveResponse;

        } catch (e) {

        }
    };

    /// <summary>
    /// Function to process the Order Response
    /// </summary>
    /// <returns type="String"></returns>
    processOrdResp(sResponseData, iOrderType) {

        try {
            let sFieldData, sMktSegId, sInstrumentId, sBuySell, sMsgCode, sGWOrdNo, sExchOrderNo, sToken, sSymbol;
            let sSeries, sTime = "", sExpiryDate, sOptionType, sStrikePrice, sRequestType, sOrderPrice, sTriggerPrice, sDiscqty;
            let sTotalQty, sOrderStatus, sValidity, sOrderType = "", sError = "", sProductType, sDecimalLocator, sExchangeName, sInstrumentName;
            let iIterator, sFormatTriggerPr, sFormatOrderPrice, sOrdMsgTime = "", sFormatTime = "", sBSText, sOrderNo, sScripDesc, sFinalMessage = "";
            let sFormatOrderType = "", sValidityDesc, sTradeNo, sTradeValue, sPOS = "", sSORID = "", sIStrikePrice = "", sLegindicator = "";
            let sSLOrderPrice = '', sSLTriggerPrice = '', sSLJumpPrice = '0', sLTPJumpPrice = '0', sProfitOrderPrice = '', sBOModifyTerms = '', sFillType = '';
            //This variable has been initialised as it will be used in Trade response in same format
            let sTradeText = "Trade ", sPrivateOrder = '', sTimeField = '', sDayField = '';
            let aOrderRespData, aFieldData, aTime;
            sOrderPrice = 0.00;
            let bMktOrder = false;

            //Splitting incoming packet by "|"
            aOrderRespData = sResponseData.split(clsConstants.C_S_FIELD_DELIMITER);
            for (iIterator = 0; iIterator < aOrderRespData.length; iIterator++) {
                sFieldData = aOrderRespData[iIterator];
                //splitting individual record by "="
                aFieldData = sFieldData.split(clsConstants.C_S_NAMEVALUE_DELIMITER);
                switch (parseInt(aFieldData[0])) {
                    case (clsConstants.C_V_TAG_MKTSEGID):
                        sMktSegId = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_INSTRUMENTID):
                        sInstrumentId = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_BUYORSELL):
                        sBuySell = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_MSGCODE):
                        sMsgCode = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_GATEWAYORDERNO):
                        sGWOrdNo = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDEXCHORDERNO):
                        sExchOrderNo = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SCRIPTOKEN):
                        sToken = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SYMBOL):
                        sSymbol = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SERIES):
                        sSeries = aFieldData[1];
                        break;
                    //case parseInt(clsConstants.C_V_TAG_TIME):
                    //Change Tag to 66 from 71 for time sync issue
                    case (clsConstants.C_V_TAG_MSGTIME):
                        sTime = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_EXPIRYDATE):
                        sExpiryDate = aFieldData[1].toUpperCase();
                        break;
                    case (clsConstants.C_V_TAG_OPTIONTYPE):
                        sOptionType = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_STRIKEPRICE):
                        sIStrikePrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDRESPONSE_TYPE):
                        sRequestType = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDPRICE):
                        sOrderPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_TRIGPRICE):
                        sTriggerPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_DISCLOSEDQTY):
                        sDiscqty = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORIGQTY):
                        sTotalQty = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDSTATUS):
                        sOrderStatus = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_VALIDITY):
                        sValidity = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDERTYPE):
                        sOrderType = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDERRORSTRING):
                        sError = clsTradingMethods.getErrorMessage(sFieldData);
                        break;
                    case (clsConstants.C_V_TAG_PRODUCTTYPE):
                        sProductType = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_DECIMALLOCATOR):
                        sDecimalLocator = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_TRADENO):
                        sTradeNo = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_CONSTTRADEVALUE):
                        sTradeValue = aFieldData[1];
                        break;
                    case (clsConstants.C_V_POSINDICATOR):
                        sPOS = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SORID):
                        sSORID = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_MKTORDER):
                        bMktOrder = true;
                        break;
                    case parseInt(clsConstants.C_S_TAG_ISSPREADSCRIP):
                        sLegindicator = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SLJUMPPRICE):
                        sSLJumpPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_LTPJUMPPRICE):
                        sLTPJumpPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SLORDERPRICE):
                        sSLOrderPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_SLTRIGGERPRICE):
                        sSLTriggerPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_PROFITORDERPRICE):
                        sProfitOrderPrice = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_BO_MODIFYTERMS):
                        sBOModifyTerms = aFieldData[1];
                        break;
                    // case parseInt(clsConstants.C_S_TAG_FILLTYPE):
                    //     sFillType = aFieldData[1];
                    //     break;
                    // case (clsConstants.C_V_TAG_PRIVATEORDER):
                    //     sPrivateOrder = aFieldData[1];
                    //     break;
                    // case parseInt(clsConstants.C_S_TAG_GTT_TIMEFIELD):
                    //     sTimeField = aFieldData[1];
                    //     break;
                    // case parseInt(clsConstants.C_S_TAG_ORDGTD):
                    //     sDayField = aFieldData[1];
                    //     break;
                }
            }

            //if Mkt Order Tag found in Response then ingore it.
            ///this is done to solve condition when OC sends 2 response in request of Mkt Order Order Entry request.
            if (bMktOrder == true)
                return;

            //Get Exchange name based on MktsegID passed
            sExchangeName = clsTradingMethods.getExchangeName(sMktSegId);

            //Get Instrument name based on InstrumentID passed
            // If Segment is NSE EQ / BSE EQ --> directly assign EEQUITIES text as instrument type
            if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH ||
                sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH ||
                sMktSegId == clsConstants.C_V_OFS_IPO_BONDS
                || sMktSegId == clsConstants.C_V_ADX_CASH || sMktSegId == clsConstants.C_V_DFM_CASH)
                sInstrumentName = clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT;
            else
                sInstrumentName = clsTradingMethods.getInstrumentName(sInstrumentId);

            //Setting Order Type text
            sFormatOrderType = clsTradingMethods.getOrderType(sOrderType, sExchangeName);

            // Formatting Strike Price
            sStrikePrice = clsTradingMethods.ConvertToRsDL(sIStrikePrice, sDecimalLocator, sMktSegId);
            /*Formatting incoming Trigger price and order price (which is in paise) to Rupees depending upon Exchange
            of which resopnse is received and decimal locator value received in the packet    */
            sFormatTriggerPr = clsTradingMethods.ConvertToRsDL(sTriggerPrice, sDecimalLocator, sMktSegId);
            sFormatOrderPrice = clsTradingMethods.ConvertToRsDL(sOrderPrice, sDecimalLocator, sMktSegId);

            //Formatting and displaying OrderTime received in packet in hh:mm:ss format
            if (sTime != "undefined" && sTime != null && sTime != "" && sTime != "0") {
                aTime = sTime.split(" ");
                sOrdMsgTime = aTime[1];
                sFormatTime = sOrdMsgTime.substring(0, 2) + ":" + sOrdMsgTime.substring(2, 4) + ":" + sOrdMsgTime.substring(4, 6);

                //Need to check...
                sFormatTime = clsTradingMethods.AddOCDiffToOCTime(sFormatTime);
            }
            if (sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE && parseInt(sLegindicator) == clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR) {
                sSLOrderPrice = clsTradingMethods.ConvertToRsDL(sSLOrderPrice, sDecimalLocator, sMktSegId);
                sSLTriggerPrice = clsTradingMethods.ConvertToRsDL(sSLTriggerPrice, sDecimalLocator, sMktSegId);
                sSLJumpPrice = clsTradingMethods.ConvertToRsDL(sSLJumpPrice, sDecimalLocator, sMktSegId);
                sLTPJumpPrice = clsTradingMethods.ConvertToRsDL(sLTPJumpPrice, sDecimalLocator, sMktSegId);
                sProfitOrderPrice = clsTradingMethods.ConvertToRsDL(sProfitOrderPrice, sDecimalLocator, sMktSegId);
            }

            /* Based on the "iOrderType" flag passed we identify the response received is for normal order or trade response */
            // For New, Modify, Cancel order   / SL Trigger order response
            if (iOrderType == "2" || iOrderType == "6") {
                if (sBuySell == clsConstants.C_V_ORDER_SELL)
                    sBSText = clsConstants.C_S_ORDER_SELL_TEXT;
                else
                    sBSText = clsConstants.C_S_ORDER_BUY_TEXT;
            }

            //For Trade response
            else {
                if (sBuySell == clsConstants.C_V_ORDER_SELL)
                    sBSText = " SOLD ";
                else
                    sBSText = " BOUGHT ";
            }

            // Appending data depending upon Msgocde recd which can be acknowledgement or normal / trade order
            sOrderNo = "";
            if (sMsgCode == clsConstants.C_V_MSGCODES_ORDER_ACKNOWLEDGEMENT)
                sOrderNo = "Ref no " + sGWOrdNo;
            else {
                if (sExchOrderNo != undefined)
                    sOrderNo = "Order no " + sExchOrderNo;
            }

            // Formatting scrip description depending upon Exchange for which packet is received
            sScripDesc = clsTradingMethods.getScripDesc(sMktSegId, sExchangeName, sInstrumentName, sSymbol, sSeries, sExpiryDate, sStrikePrice, sOptionType, sToken)

            // Again we append data as per order type and msg code recd
            sRequestType = clsTradingMethods.getRequestType(sRequestType, sMsgCode);

            /* Based on the "iOrderType" flag passed we identify the response received is for normal order or trade
            response            */
            // For New, Modify, Cancel order   /   SL trigger order
            if (iOrderType == "2" || iOrderType == "6") {
                sFinalMessage = sFinalMessage + sRequestType;
                // Checking the exchange
                if (sMktSegId == clsConstants.C_V_NSE_CASH || sMktSegId == clsConstants.C_V_BSE_CASH || sMktSegId == clsConstants.C_V_NSE_DERIVATIVES || sMktSegId == clsConstants.C_V_BSE_DERIVATIVES
                    || sMktSegId == clsConstants.C_V_NSEL_DERIVATIVES || sMktSegId == clsConstants.C_V_NSEL_SPOT || sMktSegId == clsConstants.C_V_MSX_CASH || sMktSegId == clsConstants.C_V_DSE_CASH
                    || sMktSegId == clsConstants.C_V_OFS_IPO_BONDS
                    || sMktSegId == clsConstants.C_V_ADX_CASH || sMktSegId == clsConstants.C_V_DFM_CASH)    //NSE derv and BSe DERV can be taken here
                {
                    sFinalMessage += sFormatTime + " " + sScripDesc + " " + sBSText + " " + sTotalQty + " at Rs. " + sFormatOrderPrice + " " + sFormatOrderType;
                    if (sSORID.length > 0 && sSORID != "0")
                        sFinalMessage += " SORID: " + sSORID;

                    if (sMktSegId == clsConstants.C_V_MSX_CASH) {
                        if (sPOS.length != 0) {
                            if (sPOS != clsConstants.C_V_POLMT && sPOS != clsConstants.C_V_POMKT)
                                sFinalMessage += " Normal " + sOrderNo + " " + "Disc Lot:" + sDiscqty;
                            else
                                sFinalMessage += " Normal " + sOrderNo + " "
                        }
                        else {
                            sFinalMessage += " Normal " + sOrderNo + " " + "Disc Lot:" + sDiscqty;
                        }
                    }
                    else
                        sFinalMessage += " Normal " + sOrderNo + " " + "Disc Qty:" + sDiscqty;

                    // Mapping the Validity recd with the corresponding text
                    sValidityDesc = clsTradingMethods.getValdDesc(sMktSegId, sValidity);

                    //TODO:
                    // if (sValidityDesc == clsConstants.C_S_VALUE_GTD || sValidityDesc == clsConstants.C_S_VALUE_GTW || sValidityDesc == clsConstants.C_S_VALUE_GTM) {
                    //     sTimeField = "Days: " + sDayField;
                    // }
                    // else {
                    //     sTimeField = '';
                    // }

                    // Formatting the string depending upon OrderType recd which can be RL / RL MKT/ SL / SL MKT
                    if (sFormatOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || sFormatOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                        if (sMktSegId == clsConstants.C_V_BFX_DERIVATIVES || sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES)
                            sFinalMessage += " Trig Price:" + clsConstants.CONST_CURRENCY + " " + sFormatTriggerPr + " " + sTimeField;
                        else
                            sFinalMessage += " Trig Price:Rs. " + sFormatTriggerPr + " " + sTimeField;

                    }

                    if (sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE && parseInt(sLegindicator) == clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR) {
                        sFinalMessage += " SL Price:Rs. " + sSLOrderPrice + " SL Trigger Price:Rs." + sSLTriggerPrice + " SL Jump Price:Rs." + sSLJumpPrice
                            + " LTP Jump Price:Rs." + sLTPJumpPrice + " Profit Order Price:Rs." + sProfitOrderPrice + " " + sTimeField;
                    }

                    if (sValidityDesc != undefined && sValidityDesc != '')
                        sFinalMessage += " Validity: " + sValidityDesc + " " + sTimeField;

                    //TODO:
                    // if (sFillType != undefined && sFillType == "1") {
                    //     sFinalMessage += " Fill: " + clsConstants.C_S_VALUE_AON;
                    // }
                    // Modified by Sakthi for CR 2115 - New Fill Type
                    // else if (sFillType != undefined && sFillType == "2") {
                    //     sFinalMessage += " Fill: " + clsConstants.C_S_VALUE_ATBEST;
                    // }
                    // else if (parseInt(sValidity) == clsConstants.C_V_ORDER_FOK || parseInt(sValidity) == clsConstants.C_V_ORDER_FAK) {
                    //     sFinalMessage += " Fill: " + clsTradingMethods.GetFillDesc(sMktSegId, sValidity);
                    // }

                    if ((sMktSegId == clsConstants.C_V_ADX_CASH || sMktSegId == clsConstants.C_V_DFM_CASH)
                        && sPrivateOrder != undefined && sPrivateOrder != "") {
                        switch (sPrivateOrder) {
                            case "5":
                            case "7":
                                sFinalMessage += " Private Order";
                                break;
                            case "6":
                                sFinalMessage += " Public Order";
                                break;
                        }

                    }

                }

                // Checking the exchange
                else if (sMktSegId == clsConstants.C_V_MCX_DERIVATIVES || sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_UCX_DERIVATIVES ||
                    sMktSegId == clsConstants.C_V_BFX_DERIVATIVES || sMktSegId == clsConstants.C_V_MSX_SPOT || sMktSegId == clsConstants.C_V_NCDEX_DERIVATIVES ||
                    sMktSegId == clsConstants.C_V_NCDEX_SPOT || sMktSegId == clsConstants.C_V_MSX_DERIVATIVES || sMktSegId == clsConstants.C_V_MSX_FAO ||
                    sMktSegId == clsConstants.C_V_NSX_DERIVATIVES || sMktSegId == clsConstants.C_V_NSX_SPOT || sMktSegId == clsConstants.C_V_NMCE_DERIVATIVES ||
                    sMktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || sMktSegId == clsConstants.C_V_BSECDX_SPOT) {
                    if (sMktSegId == clsConstants.C_V_NMCE_DERIVATIVES)
                        sFinalMessage += sFormatTime + " " + sScripDesc + " " + sBSText + " " + sTotalQty + " at Rs. " + sFormatOrderPrice + " " + sFormatOrderType + " Normal " + sOrderNo;
                    //sFinalMessage += sFormatTime + " " + sScripDesc + " " + sBSText + " " + sTotalQty + " at " + sFormatOrderPrice + " " + sFormatOrderType + " Normal " + sOrderNo;
                    else if (sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BFX_DERIVATIVES)
                        sFinalMessage += sFormatTime + " " + sScripDesc + " " + sBSText + " " + sTotalQty + " at " + clsConstants.CONST_CURRENCY + " " + sFormatOrderPrice + " " + sFormatOrderType + " Normal " + sOrderNo + " " + " Disc Lot: " + sDiscqty;
                    else
                        sFinalMessage += sFormatTime + " " + sScripDesc + " " + sBSText + " " + sTotalQty + " at Rs. " + sFormatOrderPrice + " " + sFormatOrderType + " Normal " + sOrderNo + " " + " Disc Lot: " + sDiscqty;

                    // Mapping the Validity recd with the corresponding text
                    sValidityDesc = clsTradingMethods.getValdDesc(sMktSegId, sValidity);

                    // Formatting the string depending upon OrderType recd which can be RL / RL MKT/ SL / SL MKT
                    if (sFormatOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT || sFormatOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {

                        if (sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BFX_DERIVATIVES)
                            sFinalMessage += " Trig Price: " + clsConstants.CONST_CURRENCY + " " + sFormatTriggerPr;
                        else
                            sFinalMessage += " Trig Price:Rs. " + sFormatTriggerPr;
                    }

                    if (sProductType == clsConstants.C_S_PRODUCTTYPE_BRACKET_VALUE && parseInt(sLegindicator) == clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR) {
                        sFinalMessage += " SL Price:Rs. " + sSLOrderPrice + " SL Trigger Price:Rs." + sSLTriggerPrice + " SL Jump Price:Rs." + sSLJumpPrice
                            + " LTP Jump Price:Rs." + sLTPJumpPrice + " Profit Order Price:Rs." + sProfitOrderPrice;
                    }

                    sFinalMessage += " Validity: " + sValidityDesc;
                }

                // Appending the Product type text mapped from the Product Type value recd
                sFinalMessage += clsTradingMethods.getProductType(sProductType, sMktSegId);
                sFinalMessage += clsTradingMethods.getLegIndicatorText(sProductType, sLegindicator);

                // Appending order status of the order
                sFinalMessage += clsTradingMethods.formReqType(sMsgCode, sOrderStatus, sError);
                if (sBOModifyTerms == "1") //when sBOModifyTerms is 1 then its a modify
                    sFinalMessage += " ORDER TERMS MODIFIED";

                // Added only in case of trigger order response
                if (iOrderType == "6")
                    sFinalMessage += " STOP LOSS TRIGGERED";
            }
            // Trade response formation
            else if (iOrderType == "3") {
                if (sMktSegId == clsConstants.C_V_DGCX_DERIVATIVES || sMktSegId == clsConstants.C_V_BFX_DERIVATIVES) {

                    sFinalMessage = sTradeText + " " + sFormatTime + " " + sScripDesc + " " + sBSText + " against " + sExchOrderNo + " " + sFormatOrderType + " " + "Normal, " + sTotalQty + " at " + clsConstants.CONST_CURRENCY + " " + sFormatOrderPrice + " Amount " + clsConstants.CONST_CURRENCY + " " + sTradeValue;
                }
                else
                    sFinalMessage = sTradeText + " " + sFormatTime + " " + sScripDesc + " " + sBSText + " against " + sExchOrderNo + " " + sFormatOrderType + " " + "Normal, " + sTotalQty + " at Rs." + sFormatOrderPrice + " Amount Rs. " + sTradeValue;
                if (sSORID.length > 0 && sSORID != "0")
                    sFinalMessage += " SORID: " + sSORID;

                sFinalMessage += " Trade No " + sTradeNo;
            }
            var objResp: clsOnlineResponse = new clsOnlineResponse();
            objResp.MsgCode = sMsgCode;
            objResp.MsgData = sFinalMessage;
            objResp.MsgTime = sFormatTime;

            if (sMsgCode == clsConstants.C_V_MSGCODES_TRADE_RESPONSE)
                objResp.MsgCategory = clsConstants.C_S_MSGCAT_TRADE;
            else {
                objResp.MsgCategory = clsConstants.C_S_MSGCAT_ORDER;
                objResp.SubMsgCategory = sOrderStatus;
            }

            if (sBuySell == clsConstants.C_V_ORDER_BUY.toString())
                objResp.OrderSide = clsConstants.C_S_ORDER_BUY_TEXT;
            else
                objResp.OrderSide = clsConstants.C_S_ORDER_SELL_TEXT;

            objResp.MsgCategory = objResp.MsgCategory + objResp.OrderSide;

            return objResp;
        }
        catch (e) {

        }
    };

    processOrderAck(sOrderResponse) {
        try {
            let iIterator, sExchOrdNo, sErrStr = "", sTime, sMsgTime, sOrderStatus, sResponseType, sMsgCode, sGWOrdNo = "";
            let sRequestType, sFieldData, sFormatTime = "", sOrdMsgTime = "", sMessage;
            let aOrderRespData, aFieldData, aTime, sRefCaption;
            //Splitting incoming packet by "|"
            aOrderRespData = sOrderResponse.split(clsConstants.C_S_FIELD_DELIMITER);
            for (iIterator = 0; iIterator < aOrderRespData.length; iIterator++) {
                sFieldData = aOrderRespData[iIterator];
                //splitting individual record by "="
                aFieldData = sFieldData.split(clsConstants.C_S_NAMEVALUE_DELIMITER);

                switch (parseInt(aFieldData[0])) {
                    case (clsConstants.C_V_TAG_ORDEXCHORDERNO):
                        sExchOrdNo = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDERRORSTRING):
                        sErrStr = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_TIME):
                        sTime = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_MSGTIME):
                        sMsgTime = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDSTATUS):
                        sOrderStatus = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDRESPONSE_TYPE):
                        sResponseType = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_MSGCODE):
                        sMsgCode = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_GATEWAYORDERNO):
                        sGWOrdNo = aFieldData[1];
                        break;
                    case (clsConstants.C_V_TAG_ORDREQUEST_TYPE):
                        sRequestType = aFieldData[1];
                        break;
                }
            }
            //Formatting and displaying OrderTime received in packet in hh:mm:ss format
            if (sMsgTime != "undefined" && sMsgTime != null && sMsgTime != "") {
                aTime = sMsgTime.split(" ");
                sOrdMsgTime = aTime[1];
                sFormatTime = sOrdMsgTime.substring(0, 2) + ":" + sOrdMsgTime.substring(2, 4) + ":" + sOrdMsgTime.substring(4, 6);

                sFormatTime = clsTradingMethods.AddOCDiffToOCTime(sFormatTime)
            }

            /*  AMO case to be added  here  */

            if (sGWOrdNo != "")
                sRefCaption = " Ref no ";
            else
                sRefCaption = "";

            //Checking for Order request type which can be New Order, Modify Order, Cancel Order
            if (sRequestType == clsConstants.C_V_ORDER_REQUEST_ENTRY) {
                if (sErrStr == "")
                    sMessage = "New Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + clsConstants.C_S_ORDERSTATUS_GATEWAYXMITTED_TEXT; 		//chUI_Ordstatus_GatewayXmitted_Text;
                else
                    sMessage = "New Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + "Gateway Error:" + sErrStr;
            }
            else if (sRequestType == clsConstants.C_V_ORDER_REQUEST_MODIFY) {
                if (sErrStr == "")
                    sMessage = "Modify Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + clsConstants.C_S_ORDERSTATUS_GATEWAYXMITTED_TEXT; 			//chUI_Ordstatus_GatewayXmitted_Text;
                else
                    sMessage = "Modify Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + "Gateway Error:" + sErrStr;
            }
            else if (sRequestType == clsConstants.C_V_ORDER_REQUEST_CANCEL) {
                if (sErrStr == "")
                    sMessage = "Cancel Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + clsConstants.C_S_ORDERSTATUS_GATEWAYXMITTED_TEXT; 		//chUI_Ordstatus_GatewayXmitted_Text;
                else
                    sMessage = "Cancel Order Ack " + sFormatTime + sRefCaption + sGWOrdNo + " " + "Gateway Error:" + sErrStr;
            }
            let objResp: clsOnlineResponse = new clsOnlineResponse();
            objResp.MsgCode = clsConstants.C_V_MSGCODES_ORDER_ACKNOWLEDGEMENT;
            objResp.MsgData = sMessage;
            objResp.MsgTime = sFormatTime;
            objResp.MsgCategory = clsConstants.C_S_MSGCAT_ACK;

            return objResp;
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Function to process the Top Gainer Response
    /// Top Gainer Response string
    /// </summary>
    /// <param name="_responsePacket" type="String" >
    /// </param>
    /// <returns type="TopGainerResponse"></returns>
    processTopGainerResponse(_responsePacket) {

        let objTopGainerResponse: clsTopGainerResponse = null;
        try {
            objTopGainerResponse = new clsTopGainerResponse();

            //takes only first 7 tag-value pairs as later on there are individual records
            let lstResponse = clsTradingMethods.LookUp(_responsePacket);

            //fill the top gainer response partly
            //objTopGainerResponse.SegmentId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID),10);
            objTopGainerResponse.MarketType = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MARKETTYPE));
            objTopGainerResponse.NoOfRecords = lstResponse.getItem(clsConstants.C_S_TAG_NOOFRECORDS);

            objTopGainerResponse.TopGainerData = [];

            //extract the string which has only the scrip data. this is done using the C_S_TAG_NOOFRECORDS tag
            //and assuming that this tag will always come before the scrip records
            let strTGLData = _responsePacket.substring(_responsePacket.indexOf("|" + clsConstants.C_S_TAG_NOOFRECORDS) + 1);
            strTGLData = strTGLData.substring(strTGLData.indexOf(clsConstants.C_S_FIELD_DELIMITER) + 1);
            strTGLData = strTGLData.split(clsConstants.C_S_FIELD_DELIMITER);
            let lstDataResponse;
            let tglScrip: clsTopGainerScrip = null;
            let skScrip: clsScripKey = null;
            let scScrip: clsScrip = null;
            let _strPriceFormat;
            // for each scrip create a TopGainerLoser object, fill it with data and add it to objTopGainerResponse
            for (let j = 0; j < strTGLData.length; j++) {
                lstDataResponse = clsTradingMethods.RecordDelimitLookUp(strTGLData[j]);
                tglScrip = new clsTopGainerScrip();
                skScrip = new clsScripKey();
                skScrip.MktSegId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID));
                skScrip.token = lstDataResponse[clsConstants.C_S_TAG_SCRIPTOKEN];

                //Check for token undefined -- if undefined then continue
                if (skScrip.token == undefined)
                    continue;

                scScrip = new clsScrip();
                scScrip.scripDet = skScrip;
                scScrip.symbol = lstDataResponse[clsConstants.C_S_TAG_SYMBOL];

                scScrip.Series = lstDataResponse[clsConstants.C_S_TAG_SERIES];
                scScrip.InstrumentName = lstDataResponse[clsConstants.C_S_TAG_INSTRUMENTID];
                scScrip.ExpiryDate = lstDataResponse[clsConstants.C_S_TAG_EXPIRYDATE];
                scScrip.OptionType = lstDataResponse[clsConstants.C_S_TAG_OPTIONTYPE];

                let strDecimalLocator = lstDataResponse[clsConstants.C_S_TAG_DECIMALLOCATOR];
                if (strDecimalLocator == '' || strDecimalLocator == null || strDecimalLocator == "0") {
                    scScrip.DecimalLocator = "100";
                }
                else if (skScrip.MktSegId == clsConstants.C_V_NSX_DERIVATIVES || skScrip.MktSegId == clsConstants.C_V_NSX_SPOT ||
                    skScrip.MktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || skScrip.MktSegId == clsConstants.C_V_BSECDX_SPOT) {
                    scScrip.DecimalLocator = "10000000";
                }
                else {
                    scScrip.DecimalLocator = strDecimalLocator;
                }

                let intDecimalLocator = parseInt(scScrip.DecimalLocator, 10);
                //var intDecimalLocator = (scScrip.DecimalLocator);

                _strPriceFormat = clsTradingMethods.getPriceFormatter(scScrip.DecimalLocator.toString(), skScrip.MapMktSegId); //scScrip.DecimalLocator.length - 1;

                scScrip.StrikePrice = (parseFloat(lstDataResponse[clsConstants.C_S_TAG_STRIKEPRICE]) / intDecimalLocator).toFixed(_strPriceFormat);

                tglScrip.ScripDetail = scScrip;

                tglScrip.TradedPrice = (parseFloat(lstDataResponse[clsConstants.C_S_TAG_LTP]) / intDecimalLocator).toFixed(_strPriceFormat);

                tglScrip.PrevClosePrice = (parseFloat(lstDataResponse[clsConstants.C_S_TAG_PREVCLOSEPRICE]) / intDecimalLocator).toFixed(_strPriceFormat);
                tglScrip.ChangeMarketIndicator = lstDataResponse[clsConstants.C_S_TAG_CHANGEINDICATOR];
                tglScrip.PercentChanged = tglScrip.ChangeMarketIndicator + " " + parseFloat(lstDataResponse[clsConstants.C_S_TAG_PERCENTAGECHANGE]).toFixed(2);

                tglScrip.NetChangeInRs = '(' + tglScrip.ChangeMarketIndicator + Math.abs(parseFloat(tglScrip.TradedPrice) - parseFloat(tglScrip.PrevClosePrice)).toFixed(2) + ')';

                objTopGainerResponse.TopGainerData.push(tglScrip);
                if (j == 0)//Setting the response type based on the indicator to identify "TopGainerResponse" and "TopLosersReponse"
                {
                    objTopGainerResponse.ResponseType = tglScrip.ChangeMarketIndicator == "-" ? clsConstants.C_S_LOSERS : clsConstants.C_S_GAINERS;
                }
            }

        } catch (e) {

        }
        return objTopGainerResponse;
    };

    /// <summary>
    /// Function to process the Most Active Security Response
    /// Most Active Response string
    /// </summary>
    processMostActiveResponse(_responsePacket) {
        let objMostActiveResponse: clsMostActiveResponse = null;
        try {
            objMostActiveResponse = new clsMostActiveResponse();

            //takes only first 7 tag-value pairs as later on there are individual records
            var lstResponse = clsTradingMethods.LookUp(_responsePacket);

            //fill the most active security response partly
            //objMostActiveResponse.SegmentId = lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID];
            objMostActiveResponse.MarketType = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MARKETTYPE));
            objMostActiveResponse.NoOfRecords = lstResponse.getItem(clsConstants.C_S_TAG_NOOFRECORDS);
            objMostActiveResponse.Mode = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_BCASTREQTYPE));

            objMostActiveResponse.MostActiveData = [];

            //extract the string which has only the securities data. this is done using the C_S_TAG_NOOFRECORDS tag
            //and assuming that this tag will always come before the scrip records
            let strMASData = _responsePacket.substring(_responsePacket.indexOf(clsConstants.C_S_TAG_NOOFRECORDS));
            strMASData = strMASData.substring(strMASData.indexOf(clsConstants.C_S_FIELD_DELIMITER) + 1);

            strMASData = _responsePacket.substring(_responsePacket.indexOf("|" + clsConstants.C_S_TAG_NOOFRECORDS) + 1);
            strMASData = strMASData.substring(strMASData.indexOf(clsConstants.C_S_FIELD_DELIMITER) + 1);
            strMASData = strMASData.split(clsConstants.C_S_FIELD_DELIMITER);
            let lstDataResponse;
            let maScrip: clsMostActiveScrip = null;
            let skScrip: clsScripKey;
            let scScrip: clsScrip = null;
            var _strPriceFormat;
            //for each scrip create a MostActiveScrip object, fill it with data and add it to objMostActiveResponse
            for (var j = 0; j < strMASData.length; j++) {
                lstDataResponse = clsTradingMethods.RecordDelimitLookUp(strMASData[j]);
                maScrip = new clsMostActiveScrip();
                skScrip = new clsScripKey();
                skScrip.MktSegId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID));
                skScrip.token = lstDataResponse[clsConstants.C_S_TAG_SCRIPTOKEN];

                //Check for token undefined -- if undefined then continue
                if (skScrip.token == undefined)
                    continue;

                scScrip = new clsScrip();
                scScrip.scripDet = skScrip;
                scScrip.symbol = lstDataResponse[clsConstants.C_S_TAG_SYMBOL];

                scScrip.Series = lstDataResponse[clsConstants.C_S_TAG_SERIES];
                scScrip.InstrumentName = lstDataResponse[clsConstants.C_S_TAG_INSTRUMENTID];
                scScrip.ExpiryDate = lstDataResponse[clsConstants.C_S_TAG_EXPIRYDATE];
                scScrip.OptionType = lstDataResponse[clsConstants.C_S_TAG_OPTIONTYPE];

                let strDecimalLocator = lstDataResponse[clsConstants.C_S_TAG_DECIMALLOCATOR];
                if (strDecimalLocator == '' || strDecimalLocator == null || strDecimalLocator == "0") {
                    scScrip.DecimalLocator = "100";
                }
                else {
                    scScrip.DecimalLocator = strDecimalLocator;
                    if (skScrip.MktSegId == clsConstants.C_V_MSX_DERIVATIVES ||
                        skScrip.MktSegId == clsConstants.C_V_BFX_DERIVATIVES ||
                        skScrip.MktSegId == clsConstants.C_V_MSX_FAO) {
                        scScrip.DecimalLocator = strDecimalLocator;
                    }
                    else if (skScrip.MktSegId == clsConstants.C_V_NSX_DERIVATIVES || skScrip.MktSegId == clsConstants.C_V_NSX_SPOT ||
                        skScrip.MktSegId == clsConstants.C_V_BSECDX_DERIVATIVES || skScrip.MktSegId == clsConstants.C_V_BSECDX_SPOT) {
                        scScrip.DecimalLocator = "10000000";
                    }
                    else {
                        scScrip.DecimalLocator = "100";
                    }
                }
                let intDecimalLocator = parseInt(scScrip.DecimalLocator);

                _strPriceFormat = clsTradingMethods.getPriceFormatter(scScrip.DecimalLocator.toString(), skScrip.MapMktSegId); //scScrip.DecimalLocator.length - 1;

                scScrip.StrikePrice = (parseFloat(lstDataResponse[clsConstants.C_S_TAG_STRIKEPRICE]) / intDecimalLocator).toFixed(_strPriceFormat);

                maScrip.ScripDetail = scScrip;
                //maScrip.TradedPrice = (parseFloat(lstDataResponse[clsConstants.C_S_TAG_LTP]) / intDecimalLocator).toFixed(_strPriceFormat);
                maScrip.Value = lstDataResponse[clsConstants.C_V_TAG_VALUE];
                maScrip.Volume = lstDataResponse[clsConstants.C_V_TAG_VOLUME];

                if (isNaN(maScrip.Value) || maScrip.Value == '')
                    maScrip.Value = 0;
                if (isNaN(maScrip.Volume) || maScrip.Volume == '')
                    maScrip.Volume = 0;

                maScrip.Value = parseFloat(maScrip.Value).toFixed(2);
                maScrip.Volume = parseFloat(maScrip.Volume).toFixed(2);

                objMostActiveResponse.MostActiveData.push(maScrip);

            }

        } catch (e) {

        }
        return objMostActiveResponse;
    };

    processPosConvResp(strOrderResp) {
        let objResp: clsOnlineResponse = null;
        try {
            objResp = new clsOnlineResponse();
            let dcPosResp = clsTradingMethods.LookUp(strOrderResp);

            let sError = '', sMsgTime = '', sMktSegmentId = '', sScripToken = '',
                sSymbol = '', sSeries = '', sQuantity = '', sOrderStatus = '',
                sProdType = '', sInstName = '', sExpDate = '', sStrikePrice = '', sOptiontype = '';
            let sExchangeName = '', sProductType = '', strFormatTime = '',
                sDescription = '', sFinalMessage = '', sMsgCode = '', sDecimalLoc = '';

            if (dcPosResp[clsConstants.C_V_TAG_MSGCODE] !== undefined)
                sMsgCode = dcPosResp[clsConstants.C_V_TAG_MSGCODE.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_ORDERRORSTRING] !== undefined)
                sError = clsTradingMethods.getErrorMsg(dcPosResp[clsConstants.C_V_TAG_ORDERRORSTRING.toString()]);

            if (dcPosResp[clsConstants.C_V_TAG_MSGTIME] !== undefined)
                sMsgTime = dcPosResp[clsConstants.C_V_TAG_MSGTIME.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_MKTSEGID] !== undefined)
                sMktSegmentId = dcPosResp[clsConstants.C_V_TAG_MKTSEGID.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_SCRIPTOKEN] !== undefined)
                sScripToken = dcPosResp[clsConstants.C_V_TAG_SCRIPTOKEN.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_SYMBOL] !== undefined)
                sSymbol = dcPosResp[clsConstants.C_V_TAG_SYMBOL.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_SERIES] !== undefined) {
                if (dcPosResp[clsConstants.C_V_TAG_SERIES.toString()] != "XX")
                    sSeries = dcPosResp[clsConstants.C_V_TAG_SERIES.toString()];
            }

            if (dcPosResp[clsConstants.C_V_TAG_ORIGQTY] !== undefined)
                sQuantity = dcPosResp[clsConstants.C_V_TAG_ORIGQTY.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_ORDSTATUS] !== undefined)
                sOrderStatus = dcPosResp[clsConstants.C_V_TAG_ORDSTATUS.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_PRODUCTTYPE] !== undefined)
                sProdType = dcPosResp[clsConstants.C_V_TAG_PRODUCTTYPE.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_INSTRUMENTID] !== undefined) {
                sInstName = dcPosResp[clsConstants.C_V_TAG_INSTRUMENTID.toString()];
                if (sInstName.length == 0)
                    sInstName = clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT;
            }
            if (dcPosResp[clsConstants.C_V_TAG_EXPIRYDATE] !== undefined) {
                if (sMktSegmentId == clsConstants.C_V_MSX_CASH.toString() || sInstName == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
                    sExpDate = '';
                else
                    sExpDate = dcPosResp[clsConstants.C_V_TAG_EXPIRYDATE.toString()].toUpperCase();
            }
            if (dcPosResp[clsConstants.C_V_TAG_STRIKEPRICE] !== undefined)
                sStrikePrice = dcPosResp[clsConstants.C_V_TAG_STRIKEPRICE.toString()];

            if (dcPosResp[clsConstants.C_V_TAG_OPTIONTYPE] !== undefined) {
                if (dcPosResp[clsConstants.C_V_TAG_OPTIONTYPE.toString()] != "XX")
                    sOptiontype = dcPosResp[clsConstants.C_V_TAG_OPTIONTYPE.toString()];
            }

            if (dcPosResp[clsConstants.C_V_TAG_DECIMALLOCATOR] !== undefined)
                sDecimalLoc = dcPosResp[clsConstants.C_V_TAG_DECIMALLOCATOR.toString()];

            if (sMktSegmentId.length > 0)
                sExchangeName = clsTradingMethods.getExchangeName(parseInt(sMktSegmentId));

            if (sStrikePrice.length > 0 && parseFloat(sStrikePrice) > 0) {
                if (sMktSegmentId == clsConstants.C_V_NSX_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_MSX_DERIVATIVES.toString() ||
                    sMktSegmentId == clsConstants.C_V_BSECDX_DERIVATIVES.toString())
                    sStrikePrice = (parseFloat(sStrikePrice) / parseFloat(sDecimalLoc)).toFixed(4);
                else
                    sStrikePrice = (parseFloat(sStrikePrice) / 100).toFixed(2);
            }
            else
                sStrikePrice = '';

            if (sMsgCode == clsConstants.C_V_MSGCODES_POSITION_CONVERSION_RESPONSE)
                sProductType = clsTradingMethods.getProductType(sProdType, parseInt(sMktSegmentId));

            //Formatting and displaying OrderTime received in packet in hh:mm:ss format
            if (sMsgTime.length > 0) {
                let strarr = sMsgTime.split(' ');
                strFormatTime = strarr[1].substring(0, 2) + ":" + strarr[1].substring(2, 4) + ":" + strarr[1].substring(4);
                strFormatTime = clsTradingMethods.AddOCDiffToOCTime(strFormatTime)
            }

            sDescription = sExchangeName + " " + sInstName + " " + sSymbol + " " + sSeries + " " + sExpDate + " " + sStrikePrice + " " + sOptiontype;
            // Position Conversion acknowledgement
            if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_OMSXMITTED)
                sFinalMessage = " Position Conversion: " + clsConstants.C_S_ORDERSTATUS_OMSXMITTED_TEXT;
            // Position Conversion Final response
            else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_PENDING || sOrderStatus == clsConstants.C_V_ORDERSTATUS_BOCONVERTED) {
                if (sMktSegmentId == clsConstants.C_V_MCX_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_MCX_SPOT.toString() ||
                    sMktSegmentId == clsConstants.C_V_MSX_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_MSX_SPOT.toString() ||
                    sMktSegmentId == clsConstants.C_V_NSX_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_NSX_SPOT.toString() ||
                    sMktSegmentId == clsConstants.C_V_NMCE_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_MSX_FAO.toString() ||
                    sMktSegmentId == clsConstants.C_V_BSECDX_DERIVATIVES.toString() || sMktSegmentId == clsConstants.C_V_BSECDX_SPOT.toString())
                    sFinalMessage = " Position Converted: " + sDescription + " Lot = " + sQuantity + " converted to " + sProductType;
                else
                    sFinalMessage = " Position Converted: " + sDescription + " Quantity = " + sQuantity + " converted to " + sProductType;
            }
            // Position Conversion Rejection message
            else if (sOrderStatus == clsConstants.C_S_ORDERSTATUS_GATEWAYREJECT || sOrderStatus == clsConstants.C_S_ORDERSTATUS_OMSREJECT) {
                if (sError.length > 0) {
                    if (clsTradingMethods.Trim(sScripToken).length > 0)
                        sFinalMessage = " Position Conversion Rejected for " + sDescription + " " + sScripToken + " " + sError;
                    else
                        sFinalMessage = " Position Conversion Rejected: " + sError;
                }
            }

            objResp.MsgCode = sMsgCode;
            objResp.MsgData = sFinalMessage;
            objResp.MsgTime = strFormatTime;//User.OdinMgrTime;
            objResp.MsgCategory = clsConstants.C_S_MSGCAT_ACK;
        }
        catch (e) {

        }
        return objResp;
    };

    processAlerts(strAlertResp): clsOnlineResponse {
        let objResp: clsOnlineResponse = null;
        let strAdminMesg = "", strSubject = "", strErrorCode = "",
            sMsgCode = "", sMsgTime = "", sAlertCondition = "",
            strFormatTime = "";

        try {

            objResp = new clsOnlineResponse();
            let dcAResp = clsTradingMethods.LookUp(strAlertResp);

            if (dcAResp[clsConstants.C_V_TAG_MSGCODE.toString()] !== undefined)
                sMsgCode = dcAResp[clsConstants.C_V_TAG_MSGCODE.toString()];
            if (dcAResp[clsConstants.C_V_TAG_MSGTIME.toString()] !== undefined)
                sMsgTime = dcAResp[clsConstants.C_V_TAG_MSGTIME.toString()];
            if (dcAResp[clsConstants.C_V_TAG_ORDERRORSTRING.toString()] !== undefined)
                strAdminMesg = clsTradingMethods.getErrorMsg(dcAResp[clsConstants.C_V_TAG_ORDERRORSTRING.toString()]);
            if (dcAResp[clsConstants.C_S_TAG_ALERT_SUBJECT] !== undefined)
                strSubject = clsTradingMethods.getErrorMsg(dcAResp[clsConstants.C_S_TAG_ALERT_SUBJECT]);
            if (dcAResp[clsConstants.C_S_TAG_ALERTERRORCODE] !== undefined)
                strErrorCode = clsTradingMethods.getErrorMsg(dcAResp[clsConstants.C_S_TAG_ALERTERRORCODE]);

            //In case of Nesper Alert = also comes in Value part of tag 19 so manually need to extract tag 19 data
            //and assign to strAdminMesg
            if (strSubject.toUpperCase() == "NESPERALERT") {
                let lsAResp = strAlertResp.split('|');
                let aFieldData = "";

                for (let i = 0; i < lsAResp.length; i++) {
                    aFieldData = lsAResp[i].split('=')[0];
                    switch (parseInt(aFieldData)) {
                        case clsConstants.C_V_TAG_ORDERRORSTRING:
                            strAdminMesg = clsTradingMethods.getErrorMsg(lsAResp[i]);
                            break;
                    }
                }
            }

            // If AdminMsg or Subject contains (|) pipe wich is special character, then OC replaces it with (/~^) and sends to NetNet,
            // so, (/~^) is replaced with (|) pipe in NetNet
            if (strAdminMesg.indexOf("/~^") != -1)
                strAdminMesg = strAdminMesg.replace("/~^", "|");
            if (strSubject.indexOf("/~^") != -1)
                strSubject = strSubject.replace("/~^", "|");

            if (strAdminMesg.indexOf("@^") != -1)
                strAdminMesg = strAdminMesg.replace(/@\^/gi, "=");

            //Formatting and displaying OrderTime received in packet in hh:mm:ss format
            if (sMsgTime.length > 0) {
                let strarr = sMsgTime.split(' ');
                strFormatTime = strarr[1].substring(0, 2) + ":" + strarr[1].substring(2, 4) + ":" + strarr[1].substring(4);
                strFormatTime = clsTradingMethods.AddOCDiffToOCTime(strFormatTime)
            }

            if (strErrorCode == clsConstants.C_V_ALERTERRORCODEVALUE) {
                //do nothing
            }
            else if (strSubject.toUpperCase() == "NESPERALERT") {

                let lstAdminMsg = [];
                lstAdminMsg = strAdminMesg.split('@');
                sAlertCondition = lstAdminMsg[0];
                let preDefinedId;
                objResp.MsgCode = sMsgCode;
                if (lstAdminMsg.length > 1)
                    preDefinedId = lstAdminMsg[2];
                objResp.AlertTriggerCondition = preDefinedId;
                objResp.MsgData = sAlertCondition;
                objResp.MsgTime = strFormatTime; //User.OdinMgrTime;
                objResp.MsgCategory = clsConstants.C_S_MSGCAT_ALERT;
                objResp.OrderSide = clsConstants.C_S_MSGCAT_ALERT;

                objResp.SubMsgCategory = clsConstants.C_S_MSGCAT_SCRIPALERT;
                objResp.AlertMode = parseInt(lstAdminMsg[1]);
                objResp.AlertSubject = strAdminMesg;

            }
            else {
                objResp.MsgCode = sMsgCode;
                objResp.MsgData = "Subject: " + strSubject + "\r\n" + "Message: " + strAdminMesg;
                objResp.AlertMsgData = "Subject: " + strSubject + "<br/>" + "Message: " + strAdminMesg;
                objResp.MsgTime = strFormatTime; // User.OdinMgrTime;
                //objResp.MsgTime = strFormatTime;
                objResp.MsgCategory = clsConstants.C_S_MSGCAT_ALERT + "BKR";
                objResp.OrderSide = clsConstants.C_S_MSGCAT_ALERT;
            }
        }
        catch (e) {

        }

        return objResp;
    };

    processNewsResponse(strNewsResponse): clsNewsResponse {
        let objNewsResponse: clsNewsResponse = null;
        try {
            //TODO:
            //if (User.NewsVendorId !== '' && User.NewsCategories !== '') {
            objNewsResponse = new clsNewsResponse();

            objNewsResponse.Active = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_ACTIVEFLAG);
            if (objNewsResponse.Active == "N")
                return null;

            let arrVendors = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_VENDORCODE).split(clsConstants.C_S_COMMA_DELIMITER);
            //TODO:
            let arrUserNewsVendors = [];//User.NewsVendorId.split(clsConstants.C_S_COMMA_DELIMITER);
            let bVendorExist = false;
            for (let i = 0; i < arrUserNewsVendors.length; i++) {
                if (arrVendors.indexOf(arrUserNewsVendors[i]) !== -1) {
                    bVendorExist = true;
                    break;
                }

            }

            if (!bVendorExist) {
                return null;
            }
            else {
                objNewsResponse.VendorCodes = [];
                if (arrVendors !== null && arrVendors.length > 0)
                    objNewsResponse.VendorCodes = arrVendors;
            }

            objNewsResponse.NewsId = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWSID);
            objNewsResponse.OldToken = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_OLDTOKEN);

            let arrCategories = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_CATEGORIES).split(clsConstants.C_S_COMMA_DELIMITER);
            //TODO:
            let arrUserNewsVendorCategories = [];//User.NewsCategories.split(clsConstants.C_S_COMMA_DELIMITER);
            let bCategoryExist = false;

            for (let i = 0; i < arrUserNewsVendorCategories.length; i++) {
                if (arrCategories.indexOf(arrUserNewsVendorCategories[i]) !== -1) {
                    bCategoryExist = true;
                    break;
                }
            }

            if (!bCategoryExist) {
                return null;
            }
            else {
                objNewsResponse.Categories = [];
                if (arrCategories !== null && arrCategories.length > 0)
                    objNewsResponse.Categories = arrCategories;
            }


            objNewsResponse.ISINs = [];
            let arrISINs = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_ISIN_NO).split(clsConstants.C_S_COMMA_DELIMITER);
            if (arrISINs !== null && arrISINs.length > 0)
                objNewsResponse.ISINs = arrISINs;

            objNewsResponse.Headline = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_HEADLINE);
            objNewsResponse.Type = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWSTYPE);
            objNewsResponse.Mode = clsTradingMethods.FindValue(strNewsResponse, clsConstants.C_S_TAG_NEWS_ERRORCODE);
            objNewsResponse.MsgCategory = "NEWS";
        }
        //}
        catch (e) {

        }
        return objNewsResponse;
    }

    /// <summary>
    /// Function to process the index Details Response
    /// index Details string
    /// </summary>
    processIndexDetailsResponse(_responsePacket) {

        let objIndexDetailsResponse: clsIndexDetailsResponse = null;
        try {

            objIndexDetailsResponse = new clsIndexDetailsResponse();
            objIndexDetailsResponse.SegmentId = clsTradingMethods.FindValue(_responsePacket, clsConstants.C_S_TAG_MKTSEGID);
            let arrResponse = _responsePacket.split(clsConstants.C_S_FIELD_DELIMITER);
            let RecordDelimitString = arrResponse[arrResponse.length - 1];
            let lstResponse = clsTradingMethods.RecordDelimitLookUp(RecordDelimitString);

            objIndexDetailsResponse.IndexName = lstResponse.getItem(clsConstants.C_S_TAG_INDEXNAME);
            objIndexDetailsResponse.IndexValue = lstResponse.getItem(clsConstants.C_S_TAG_INDEXVALUE);
            objIndexDetailsResponse.OpenPrice = lstResponse.getItem(clsConstants.C_S_TAG_OPENPRICE);
            objIndexDetailsResponse.HighPrice = lstResponse.getItem(clsConstants.C_S_TAG_HIGHPRICE);
            objIndexDetailsResponse.LowPrice = lstResponse.getItem(clsConstants.C_S_TAG_LOWPRICE);
            objIndexDetailsResponse.ClosePrice = lstResponse.getItem(clsConstants.C_S_TAG_CLOSEPRICE);
            objIndexDetailsResponse.LifeTimeHighPrice = lstResponse.getItem(clsConstants.C_V_TAG_LIFETIMEHIGH.toString());
            objIndexDetailsResponse.LifeTimeLowPrice = lstResponse.getItem(clsConstants.C_V_TAG_LIFETIMELOW.toString());
            objIndexDetailsResponse.MarketCapitalizationInLacs = lstResponse.getItem(clsConstants.C_S_TAG_MKTCAPITALIZATION.toString());
            objIndexDetailsResponse.PercNetChange = lstResponse.getItem(clsConstants.C_V_TAG_PERCENTAGECHANGE.toString());
        }
        catch (e) {

        }
        return objIndexDetailsResponse;
    }

    processTERResponse(_responsePacket) {
        let objTERResponse: clsTERResponse = null;
        try {
            let lstResponse = clsTradingMethods.LookUp(_responsePacket);
            let skScrip: clsScripKey = new clsScripKey();
            skScrip.MktSegId = parseInt(lstResponse.getItem(clsConstants.C_S_TAG_MKTSEGID));
            skScrip.token = lstResponse.getItem(clsConstants.C_S_TAG_SCRIPTOKEN);
            //gets the touchline object (new or existing) from response store based on clsScripKey
            objTERResponse = clsResponseStore.getTERResponseObject(skScrip.toString(), true); //TODO

            //if response received for scrip which is removed from request store then return null
            if (objTERResponse == null)
                return objTERResponse;

            objTERResponse.Scrip = skScrip;

            if (lstResponse.ContainsKey(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE))
                objTERResponse.TER = clsTradingMethods.ParseTER(skScrip.MktSegId, lstResponse.getItem(clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE));

            return objTERResponse;
        }
        catch (e) {

        }
    }
};
