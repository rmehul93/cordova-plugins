

export class clsMarketStatusResponse {
    public ResponseString: string = "";
    public ResponseFlag: string = "";
}
