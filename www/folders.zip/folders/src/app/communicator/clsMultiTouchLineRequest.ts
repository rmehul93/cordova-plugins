

export class clsMultiTouchLineRequest {
    /// <summary>
    /// Request Type would be 1 for Subscribe and 2 for Unsubscribe
    /// </summary>
    OperationType = 0;

    /// <summary>
    /// Scrip List will contain list of type Scrip, and each Scrip will have MarketSegment Id and Token associated with it
    /// </summary>
    ScripList: any = [];

    /// <summary>
    /// This flag is kept to bypass the request store in case of autorefresh mode, so that the counters of the dictionary list doesn't increase. 
    /// By default the value will be false. 
    /// If the value is set to true, then that means it will bypass the Request Store dictionary and will not increase the counter of the dictionary
    /// </summary>
    BypassRequestStore = false;
}