declare var Zlib: any;
import { clsCommunicator } from "./clsCommunicator";
import { clsConstants } from "../Common/clsConstants";
import { clsTradingMethods } from "../Common/clsTradingMethods";
import { clsResponseStore } from "./clsResponseStore";
import { clsMarketStatusResponse } from './clsMarketStatusResponse';
import { clsOnlineResponse } from "./clsOnlineResponse";
import { clsPluginConstants, clsGlobal } from "../Common/clsGlobal";
import { clsWorkerHelper } from "./clsWorkerHelper";
import { clsAppConfigConstants } from "../Common/clsAppConfigConstants";
import { clsRequestStore } from "./clsRequestStore";


export class clsWebSocket extends clsCommunicator {

    //private socketHostAddress: string;
    //private socketPort: number = 0;
    private socketUrl: string;
    private reconnectCntr: number = 0;
    private reconnectSocket: boolean = true;
    private reconnectTimer: any = null;
    private reconnectInterval: any = null;
    private compressStatus: string = clsConstants.C_S_ON;

    private NetNetWS: any = {
        WsClient: null
    };

    //OCParser: any;
    private sKeepAliveReq: string = "";
    public keepAliveTimer: number = 0;
    private timerId: any;
    private baOldData: any;

    private _HeaderLength: number = 6;
    private IsUncompress: boolean = false;
    private LogOffReceived: boolean = false;
    private isFirstMktStatusResponse = true;
    private isNWDisconnected: boolean = false;
    private connectInProgress: boolean = false;
    
    constructor() {
        super();
        //this.eventPub = Events;
    }

    Initilize(_socketUrl: string, _channelId: string, _IsSBSBinaryMode: boolean) {

        try {
            this.onInitilize();
            //this.socketHostAddress = _hostName;
            //this.socketPort = _port;
            //_socketUrl = "ws://172.25.92.67:4516";
            this.socketUrl = _socketUrl;
            this.socketChannelId = _channelId;
            this.socketConnect();
        }
        catch (e) {

            // WWclsGlobal.LogManager.WriteLog(e.message, 'Initilize', 'SocketCom.ts', '');

        }
    };

    socketConnect() {
        try {
            //let wsProtocol = clsGlobal.SecurePort.Protocol;

            //let WSURI = wsProtocol + '://' + this.socketHostAddress + ':' + this.socketPort;
            this.connectInProgress = true;
            let WSURI = this.socketUrl;
            this.NetNetWS.WsClient = new WebSocket(WSURI);
            this.NetNetWS.WsClient.binaryType = 'arraybuffer';
            this.NetNetWS.WsClient.onopen = this.onSocketConnectCompleted.bind(this);
            this.NetNetWS.WsClient.onmessage = this.onSocketDataReceive.bind(this);
            this.NetNetWS.WsClient.onerror = this.onSocketConnectionFailure.bind(this);
            this.NetNetWS.WsClient.onclose = this.onSocketDisconnected.bind(this);
        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'SocketConnect', 'SocketCom.ts', '');
        }
    };

    onSocketConnectCompleted(_event) {
        try {

            this.connectInProgress = false;
            this.isSocketConnected = true;
            this.isNWDisconnected = false;
            this.handleLoginRequest();
            this.onChannelConnected(this.socketChannelId, this);
            this.reconnectCntr = 0;
            this.reconnectInterval = null;

            if (this.reconnectTimer != null) {
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = null;
            }

            this.reconnectSocket = true;
            this.LogOffReceived = false;

        }
        catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'OnSocketConnectCompleted', 'SocketCom.ts', '');
        }
    }

    fn_SendKeepAlive() {
        if (this.isSocketConnected) {
            this.sendMessage(this.sKeepAliveReq);
            this.timerId = setTimeout(this.fn_SendKeepAlive, Number(this.keepAliveTimer));
        }
    }

    /// <summary>
    /// Event is called when successful aysnchronous data is received
    /// </summary>
    /// <param name="_event" type="event Object">
    onSocketDataReceive(_event) {
        try {
            let fullMsg = this.defragPacket(_event.data);

            if (fullMsg != undefined && fullMsg.length > 0) {

                while (fullMsg.length > 0) {

                    let msg = fullMsg.pop();
                    let _response = String.fromCharCode.apply(null, msg);
                    //remove End of response char
                    if (_response.indexOf('|50=') == -1) {
                        let intTmtrIndex = _response.indexOf(clsConstants.C_S_CHAR0);
                        if (intTmtrIndex != -1) {
                            _response = _response.substr(0, intTmtrIndex);
                        }
                    }

                    //split multi response packet with Start of response char C_S_CHAR2
                    
                    let arrData = [];
                    if (_response.indexOf('|50=') == -1) {
                        arrData = _response.split(clsConstants.C_S_CHAR2);
                    } else {
                        //console.log(_response);
                        arrData = this.parseMessage(_response);// _response.split('|64=');
                    }
                    let intDataCount = arrData.length;
                    //console.log('Split count: ',intDataCount);
                    for (let intDataCntr = 0; intDataCntr < intDataCount; intDataCntr++) {
                        if (arrData[intDataCntr] != "") {
                            //console.log('Split: ',arrData[intDataCntr]);
                            this.ProcessPacketString(arrData[intDataCntr]);
                        }
                    }
                }
            }
        }
        catch (e) {
            console.log("SocketDataReceive: ", e);
        }
    };

    parseMessage(strMessage) {
        try {
            let arrMsg = [];
            if (strMessage != undefined) {
                let index = 0;
                while (true) {

                    let strMsgLen = (strMessage.substr(0, 6));
                    let msgLen   = parseInt(strMsgLen.substr(1));
                    index += 6;
                    let strNewMsg = strMessage.substr(index, msgLen);
                    //console.log('New Message: ', strNewMsg);
                    strMessage = strMessage.substr((msgLen+6));
                    if(strMessage.length > 0){
                        //console.log('Rem Message: ', strMessage);
                    }
                    //index += msgLen;
                    index = 0;
                    //strMessage = strMessage.substr(index, msgLen);
                    arrMsg.push(strNewMsg);
                    if (strMessage == '' || strMessage == undefined) {
                        break;
                    }
                }
            }
            return arrMsg;

        } catch (error) {
            console.log('Error parsing message: ', error.message);
            return [];
        }
    }


    onSocketDataReceive2(_event) {
        /// <summary>
        /// Event is called when successful aysnchronous data is received
        /// </summary>
        /// <param name="_event" type="event Object">
        try {
            var baProcessData = null;
            var intRawPktLen;
            var intCompLen = 0;
            var _response, isBroken = false;
            var totalPacketLength = 0;

            if (_event.data instanceof ArrayBuffer) {

                var dataReceived = null;
                var dataPacketLengthList = [];
                if (this.baOldData == null)
                    dataReceived = new Uint8Array(_event.data);
                else {
                    dataReceived = this.appendOrCopyBuffer(this.baOldData, _event.data);
                    this.baOldData = null;
                }

                intRawPktLen = dataReceived.byteLength;

                var i = 0;
                if (intRawPktLen > 5) {
                    while (i < intRawPktLen) {
                        if (dataReceived[i] == 5 || dataReceived[i] == 2) {
                            var strPacketLength = String.fromCharCode.apply(null, dataReceived.subarray(i + 1, i + 6));
                            if (strPacketLength.length == 5) {
                                var packetLength = parseInt(strPacketLength, 10);
                                dataPacketLengthList.push(packetLength + 6);
                                totalPacketLength += packetLength + 6;
                                i = i + 6 + packetLength;
                            }
                            else {
                                this.baOldData = dataReceived.subarray(i, intRawPktLen);
                                isBroken = true;
                                break;
                            }
                        }
                        else
                            alert();
                    }
                }
                else
                    this.baOldData = dataReceived;

                if (intRawPktLen == totalPacketLength) {
                    // split and pass to zlib to uncompress
                    for (var i = 0, j = 0, k = dataPacketLengthList[0], len = dataPacketLengthList.length; i < len; i++) {

                        var uncompData = dataReceived.subarray(j, k);
                        this.ProcessSocketMessage(uncompData);

                        j = k;
                        k = k + dataPacketLengthList[i + 1];
                    }
                    this.baOldData = null;
                }
                else {
                    var i = 0, j = 0;
                    var k = (dataPacketLengthList.length > 0 ? dataPacketLengthList[0] : 0);

                    if (!isBroken) {
                        for (var len = dataPacketLengthList.length; i < len - 1; i++) {
                            var uncompData = dataReceived.subarray(j, k);
                            this.ProcessSocketMessage(uncompData);

                            j = k;
                            k = k + dataPacketLengthList[i + 1];
                        }

                        if (i == dataPacketLengthList.length - 1) {

                            // if (dataReceived.subarray(j, k)[0] != 5) 
                            //     alert();

                            this.baOldData = null;
                            this.baOldData = dataReceived.subarray(j, k);

                        }
                        else {
                            //alert();
                        }

                    }
                    else {
                        for (let len = dataPacketLengthList.length; i < len; i++) {
                            let uncompData = dataReceived.subarray(j, k);
                            this.ProcessSocketMessage(uncompData);

                            j = k;
                            k = k + dataPacketLengthList[i + 1];
                        }
                        isBroken = false;
                    }
                }
            }
            else
                this.ProcessPacketString(_event.data);

        }
        catch (e) {

        }
    };

    defragPacket(data) {

        if (data.byteLength == 0) {
            return null;
        }

        let dataReceived = null;
        let FullMessages = [];

        if (this.baOldData == null)
            dataReceived = new Uint8Array(data);
        else {
            dataReceived = this.appendOrCopyBuffer(this.baOldData, data);
            this.baOldData = null;
        }


        let IsDone = true;
        let MsgLength = 0;
        while (IsDone) {

            if (dataReceived.byteLength < this._HeaderLength) {
                this.baOldData = dataReceived;
                return FullMessages;
            }

            MsgLength = this.getMessageLength(dataReceived);
            if (MsgLength <= 0) {
                return null;
            }

            if (dataReceived.byteLength < (MsgLength + this._HeaderLength)) {
                this.baOldData = dataReceived;
                return FullMessages;
            }
            else {
                this.baOldData = null;
            }

            let CompressedMessage = new Uint8Array(dataReceived.subarray(this._HeaderLength, MsgLength + this._HeaderLength));
            let UnCompressedByteMessage = this.getUncompressedMessage(CompressedMessage);
            if (UnCompressedByteMessage == null) {
                IsDone = false;
                break;
            }

            FullMessages.push(UnCompressedByteMessage);

            if (dataReceived.byteLength == (MsgLength + this._HeaderLength)) {
                IsDone = false;
                CompressedMessage = null;
                break;
            }

            let NewMessage = new Uint8Array(dataReceived.subarray(MsgLength + this._HeaderLength, dataReceived.byteLength));
            dataReceived = NewMessage;

        } //end of while IsDone

        dataReceived = null;
        data = null;

        return FullMessages;

    }

    ProcessSocketMessage(uncompData) {
        let _response = this.DeCompressData(uncompData);

        if (_response == undefined) {
            console.log(_response);
            return;
        }

        //remove End of response char
        if (_response.indexOf('|50=') == -1) {
            var intTmtrIndex = _response.indexOf(clsConstants.C_S_CHAR0);
            if (intTmtrIndex != -1) {
                _response = _response.substr(0, intTmtrIndex);
            }
        }

        //split multi response packet with Start of response char C_S_CHAR2  
        var arrData = _response.split(clsConstants.C_S_CHAR2);
        var intDataCount = arrData.length;

        for (var intDataCntr = 0; intDataCntr < intDataCount; intDataCntr++) {
            if (arrData[intDataCntr] != "") {
                this.ProcessPacketString(arrData[intDataCntr]);
            }
        }
    }

    DeCompressData(_pktData) {
        /// <summary>
        /// Function to decompress the packet string using ZLib
        /// </summary>
        /// <param name="_pktData" type="Array" elementType="Number" elementInteger="true">
        /// Compressed packet byte[] as received on the socket
        /// </param>
        /// <returns type="String"></returns>
        try {
            var _compData = new Uint8Array(_pktData);
            //first 6 bytes will be special char and length of data
            //so need to take after it
            _compData = _compData.subarray(6, _compData.length);
            var _uncompData = Zlib.uncompress(new Uint8Array(_compData));
            var _sResp = [];
            for (let i = 0, len = _uncompData.length; i < len; i += 1) {
                _sResp.push(String.fromCharCode(_uncompData[i]));
            }
            return _sResp.join('');
        }
        catch (e) {
            console.log('Error De Compress Data: ', e.message || e);
        }
    };

    getMessageLength(message) {
        if (message[0] == 5) {
            this.IsUncompress = false;
        }
        else {
            this.IsUncompress = true;
        }

        try {
            let strPacketLength = String.fromCharCode.apply(null, message.subarray(1, this._HeaderLength));
            return parseInt(strPacketLength, 10);
        }
        catch (e) {
            return 0;
        }

    }

    // 5931 streaming broadcast for guest.
    // this method will update flags for streaming guest users. which will be used in overall application
    freeSocketStatus(bStatus) {
        // 5931 Streaming Broadcast data changes.
        if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_FREE_STREAMING) == clsConstants.C_S_ON) {
            //clsGlobal.IsFreeBroadcastSocketConnected = bStatus;
            clsGlobal.FreeStream = bStatus;
        }
        else {
            //clsGlobal.IsFreeBroadcastSocketConnected = false;
            clsGlobal.FreeStream = false;
        }
    }


    onSocketDisconnected(_event) {
        /// <summary>
        /// this function is called when SocketAsyncEventArgs gives a Socket Error status other than Success i.e Connection Reset
        /// </summary>
        /// <param name="_event" type="event Object">
        try {

            if (this.isNWDisconnected) {
                this.isNWDisconnected = false;
                return;
            }

            // 5931 Update Free guest user Socket Status.
            if (this.NetNetWS.WsClient != undefined && this.NetNetWS.WsClient != null) {
                this.NetNetWS.WsClient.onmessage = null;
                this.NetNetWS.WsClient.onerror = null;
                this.NetNetWS.WsClient.onclose = null;
            }
            this.NetNetWS.WsClient = null;

            this.isSocketConnected = false;
            this.connectInProgress = false;
            this.onChannelDisconnected(this.socketChannelId);
            this.handleSocketReconnection();
            let obj = { "messsage": { "socketChannelId": this.socketChannelId, "pluginData": clsPluginConstants.GetPluginDetails() } };
            //clsGlobal.logManager.writeErrorLog('clsWebSocket', 'onSocketDisconnected', obj);
            console.log("Socket disconnect : " + obj);
        }
        catch (e) {
            clsGlobal.logManager.writeErrorLog('clsWebSocket', 'onSocketDisconnected', e.message);
        }

    };

    /// <summary>
    /// this function is called when SocketAsyncEventArgs gives a Socket Error status other than Success i.e Error
    /// </summary>
    /// <param name="_event" type="event Object">
    onSocketConnectionFailure(_event) {
        try {

            if (this.isNWDisconnected) {
                this.isNWDisconnected = false;
                return;
            }

            // 5931 Update Free guest user Socket Status.
            if (this.NetNetWS.WsClient != undefined && this.NetNetWS.WsClient != null) {
                this.NetNetWS.WsClient.onmessage = null;
                this.NetNetWS.WsClient.onerror = null;
                this.NetNetWS.WsClient.onclose = null;
            }
            this.NetNetWS.WsClient = null;
            this.isSocketConnected = false;
            this.connectInProgress = false;
            let obj = { "messsage": { "socketChannelId": this.socketChannelId, "pluginData": clsPluginConstants.GetPluginDetails() } };
            clsGlobal.logManager.writeErrorLog('clsWebSocket', 'onSocketConnectionFailure', obj);

            //if true then only reconnect
            if (this.reconnectSocket) {
                this.handleSocketReconnection();
            }
        }
        catch (e) {
        }
        finally {
            // if (IonicclsGlobal.RootScope.$$phase != '$apply' && IonicclsGlobal.RootScope.$$phase != '$digest')
            //     IonicclsGlobal.RootScope.$digest();
        }
    };

    handleSocketReconnection() {
        /// <summary>
        /// If socket gets disconnected then HandleSocketReconnection function is called for socket reconnection
        /// </summary>
        try {

            if (this.LogOffReceived == false) {

                let callBackFunc = this.socketReconnectTimer.bind(this);
                if (this.reconnectCntr != 0) {
                    this.reconnectTimer = setTimeout(callBackFunc, parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_RECONNECTION_TIME_VALUE)));
                } else {
                    //this.socketReconnectTimer();
                    setTimeout(callBackFunc, 2000);//after 5 sec.
                }

            }
        }
        catch (ex) {

        }
    };

    socketReconnectTimer() {
        /// <summary>
        /// Start Times to reconnect socket and after max attempts trigger auto refresh event
        /// </summary>
        /// <param name="_state" type="Object">
        /// </param>
        try {

            if (clsPluginConstants.NetWorkConnected && !clsGlobal.IsSessionExpiredGateway) {

                if (!this.isSocketConnected) {

                    if (this.connectInProgress) return;
                    
                    this.reconnectCntr++;
                    let retryCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_RECONNECTION_RETRY_COUNT));
                   
                    if (retryCount == -1) {
                        this.socketConnect();
                    } else {

                        if (this.reconnectCntr < retryCount) {
                            this.socketConnect();
                        }
                        else {
                            // If the reconnect attempt exceeds the max attempt, then switch to Auto-Refresh mode
                            this.handleAutoRefresh(this.socketChannelId);
                            this.disposeTimer();

                            if (this.socketChannelId == clsConstants.C_S_CHANNEL_BROADCAST) {
                                clsGlobal.FreeStream = false;
                            }
                        }
                    }
                }
                else {
                    this.disposeTimer();
                }
            }
            /*
            else {

                let callBackFunc = this.socketReconnectTimer.bind(this);
                //TODO: need to add in couch for configuration.
                let reconnectTimerValue = 1000;
                this.reconnectTimer = setTimeout(callBackFunc, reconnectTimerValue);
            }
            */
        }
        catch (ex) {

        }
    };

    //USD: 6507 : by PrajyotD on 20 Sep 2018 :Logoff Message handling.(start)
    socketReconnectAfterSessionCheck() {
        try {

            this.reconnectCntr++;
            // 5931 Free streaming, If Free socket is not connected condition added
            if (!this.isSocketConnected) {
                // Check for the max allowed reconnect attempt
                if (this.reconnectCntr < parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_RECONNECTION_RETRY_COUNT))) {
                    this.socketConnect();
                }
                else {

                    // If the reconnect attempt exceeds the max attempt, then switch to Auto-Refresh mode
                    this.handleAutoRefresh(this.socketChannelId);
                    this.disposeTimer();

                    if (this.socketChannelId == clsConstants.C_S_CHANNEL_BROADCAST) {
                        clsGlobal.FreeStream = false;
                    }

                    if (this.socketChannelId == clsConstants.C_S_CHANNEL_INTERACTIVE) {
                        clsGlobal.pubsub.publish('StartSessionCheck', this.socketChannelId);
                    }
                }
            }
            else {
                this.disposeTimer();
            }

        }
        catch (e) {

        }
    }
    //USD: 6507 : by PrajyotD on 20 Sep 2018 :Logoff Message handling.(end)

    /// <summary>
    /// Function to handle compressed data and send it to respective parser function for publishing it
    /// </summary>
    /// <param name="_rawData" type="Array" elementType="Number" elementInteger="true">
    /// packet byte[] as received on socket
    /// </param>
    handleCompressedData(_rawData) {

        try {
            let _data = new ArrayBuffer(_rawData.length);
            let _uint8buf = new Uint8Array(_data);
            for (let i = 0; i < _rawData.length; i += 1) {
                _uint8buf[i] = _rawData.charCodeAt(i) & 0xFF;
            }
            //alert('CompressData');
            let _compData = Zlib.compress(new Uint8Array(_data), 6);
            //alert('CompressData - After Compress' );
            return _compData;
        }
        catch (e) {
            console.log(e.message);
        }
    };


    getUncompressedMessage(compressedMessage) {
        let uncompressedBytes = null;
        if (!this.IsUncompress) {
            let bytDecomp = null;
            bytDecomp = Zlib.uncompress(compressedMessage);
            uncompressedBytes = bytDecomp;
        }
        else {
            uncompressedBytes = new Uint8Array(compressedMessage);
        }
        return uncompressedBytes;
    }

    appendOrCopyBuffer(buffer1, buffer2) {
        let tmp = new Uint8Array(buffer1.byteLength + buffer2.byteLength);
        tmp.set(new Uint8Array(buffer1), 0);
        tmp.set(new Uint8Array(buffer2), buffer1.byteLength);
        return tmp;
    }

    /// <summary>
    /// Function to process each packet string according to their respective message codes and then publish the message to the subscibers
    /// </summary>
    /// <param name="_responsePacket" type="String">
    /// Socket response string
    /// </param>
    ProcessPacketString(_responsePacket: string) {
        try {

            //console.log("RESP: " + _responsePacket);
            let strMessageCode = '';
            let _bSendToParser = false;
            if (_responsePacket.indexOf(this.msgCodeKeyToCheck) != -1) {
                strMessageCode = clsTradingMethods.FindValue(_responsePacket, clsConstants.C_S_TAG_MSGCODE);
                _bSendToParser = true;
            }

            if (_bSendToParser) {
                _responsePacket = clsTradingMethods.RemoveFieldDelimiter(_responsePacket);

                switch (strMessageCode) {
                    case clsConstants.C_S_MSGCODE_SOCKETLOGONRESPONSE:
                        //OnChannelConnected(this.ChannelId);
                        let _objChnlLogResp = this.OCParser.processLogonResponse(_responsePacket, this.socketChannelId);
                        clsResponseStore.SendOnlineResponse(_objChnlLogResp);

                        // Login response coming in WebWorker also contains Market Status response
                        // Hence need to split the response
                        let sData = _responsePacket.split(clsConstants.C_S_FIELD_DELIMITER + '63=FT3.0');
                        if (sData.length > 1) {
                            _responsePacket = '63=FT3.0' + sData[1];
                            let objMktStatusResp = _responsePacket;
                            if (objMktStatusResp !== null) {
                                let _objMktStatusResp: clsMarketStatusResponse = new clsMarketStatusResponse();
                                _objMktStatusResp.ResponseString = objMktStatusResp;
                                _objMktStatusResp.ResponseFlag = (clsConstants.C_S_STREAMING_MODE).toString();
                                clsWorkerHelper.SendMessageToUI('MKTSTATUSRES', _objMktStatusResp);
                            }
                        }
                        break;
                    case clsConstants.C_S_MSGCODE_MULTIPLE_TOUCHLINE_RESPONSE:
                        let _objMultiTLResp = this.OCParser.processMultiTouchLineResponse(_responsePacket);
                        if (_objMultiTLResp !== null)
                            clsWorkerHelper.SendMessageToUI('MTLRES', _objMultiTLResp);
                        break;
                    case clsConstants.C_S_MSGCODE_MOSTACTIVE_RESPONSE:
                        let objMostActiveResponse = this.OCParser.processMostActiveResponse(_responsePacket);
                        clsWorkerHelper.SendMessageToUI('MASRES', objMostActiveResponse);
                        break;
                    case clsConstants.C_S_MSGCODE_TOPGAINERSLOSERS_RESPONSE:
                        let objTopGainerResponse = this.OCParser.processTopGainerResponse(_responsePacket);
                        clsWorkerHelper.SendMessageToUI('TGLRES', objTopGainerResponse);
                        break;
                    // Below message will be used for Alerts and Broker message
                    case clsConstants.C_V_MSGCODES_ADMINMESSAGE:
                        let objOnlineBrkMsgResp = this.OCParser.processAlerts(_responsePacket);
                        clsResponseStore.SendOnlineResponse(objOnlineBrkMsgResp);
                        break;

                    case clsConstants.C_S_MSGCODES_NEWS_RESPONSE:
                        let objNewsResponse = this.OCParser.processNewsResponse(_responsePacket);
                        if (objNewsResponse !== null)
                            clsWorkerHelper.SendMessageToUI('NEWSRES', objNewsResponse);
                        break;

                    case clsConstants.C_V_MSGCODES_ORDER_ACKNOWLEDGEMENT:
                    case clsConstants.C_V_MSGCODES_BRACKETORDER_ORDER_ACKNOWLEDGEMENT:
                        let objOnlineAckResp = this.OCParser.processOrderAck(_responsePacket);
                        clsResponseStore.SendOnlineResponse(objOnlineAckResp);
                        break;
                    case clsConstants.C_V_MSGCODES_ORDER_RESPONSE:
                    case clsConstants.C_V_MSGCODES_BRACKETORDER_ORDER_RESPONSE:
                        //Order type 3 --> Trade order response
                        let objOnlineOrdResp = this.OCParser.processOrdResp(_responsePacket, 2);
                        if (objOnlineOrdResp != null)
                            clsResponseStore.SendOnlineResponse(objOnlineOrdResp);
                        break;
                    case clsConstants.C_V_MSGCODES_TRADE_RESPONSE:
                        let objOnlineTradeResp = this.OCParser.processOrdResp(_responsePacket, 3);
                        if (objOnlineTradeResp != null)
                            clsResponseStore.SendOnlineResponse(objOnlineTradeResp);
                        break;
                    case clsConstants.C_V_MSGCODES_POSITION_CONVERSION_ACK:
                        let objOnlinePosAckResp = this.OCParser.processPosConvResp(_responsePacket);
                        if (objOnlinePosAckResp != null)
                            clsResponseStore.SendOnlineResponse(objOnlinePosAckResp);
                        break;
                    case clsConstants.C_V_MSGCODES_POSITION_CONVERSION_RESPONSE:
                        let objOnlinePosConResp = this.OCParser.processPosConvResp(_responsePacket);
                        if (objOnlinePosConResp != null)
                            clsResponseStore.SendOnlineResponse(objOnlinePosConResp);
                        break;
                    case clsConstants.C_V_MSGCODES_SLTRIGGER_RESPONSE:
                        let objOnlineSLResp = this.OCParser.processOrdResp(_responsePacket, 6);
                        if (objOnlineSLResp != null)
                            clsResponseStore.SendOnlineResponse(objOnlineSLResp);
                        break;
                    case clsConstants.C_S_MSGCODE_BESTFIVE_RESPONSE:
                        let objB5Response = this.OCParser.processBestFiveResponse(_responsePacket);
                        if (objB5Response != null)
                            clsWorkerHelper.SendMessageToUI('B5RES', objB5Response);
                        //In case of SBS for selected Best5 scrip touchline response will not be received,at a time only one will be served by SBS
                        //So processing the Best5 response and triggered TouchLine Response
                        // if (WWclsGlobal.User.MULTIOC == clsConstants.C_S_ON) {
                        //     let objMultiTLRespB5 = this.OCParser.processBestFiveResponseForMW(_responsePacket);
                        //     if (objMultiTLRespB5 != null)
                        //         clsWorkerHelper.SendMessageToUI('MTLRES', objMultiTLRespB5);
                        // }
                        break;
                    case clsConstants.C_S_MSGCODE_LOGOFF_RESPONSE:
                        // User forcefully disconnected
                        this.isSocketConnected = false;
                        this.LogOffReceived = true;
                        if (this.NetNetWS.WsClient != null && this.NetNetWS.WsClient.readyState == 1) {
                            this.NetNetWS.WsClient.close();
                        }

                        let objLogOff = new clsOnlineResponse();
                        // Assign OC logoff response To objLogOff object. This will be used in ctrl_menu for autologin
                        //USD: 6507 : by PrajyotD on 03 Sep 2018 :Logoff Message handling.
                        //Tag 451 will be send to UI to take action based on error code.
                        //objLogOff.MsgData = WWTradingMethods.FindValue(_responsePacket, clsGlobal.clsConstants.C_S_SOCKET_ERROR_RESPONSE);
                        objLogOff.MsgData = clsTradingMethods.FindValue(_responsePacket, clsConstants.C_S_TAG_ALERTERRORCODE);
                        // USD: 6507 : by PrajyotD on 03 Sep 2018 :Logoff Message handling.(end)
                        objLogOff.MsgCode = clsConstants.C_S_MSGCODE_LOGOFF_RESPONSE;
                        clsWorkerHelper.SendMessageToUI('OLRES', objLogOff);
                        break;

                    case clsConstants.C_V_MSGCODES_MARKETSTATUS_REPONSE:
                        let objMktStatusResp = _responsePacket;
                        if (objMktStatusResp !== null) {
                            let _objMktStatusResp = new clsMarketStatusResponse();
                            _objMktStatusResp.ResponseString = objMktStatusResp;
                            _objMktStatusResp.ResponseFlag = clsConstants.C_S_STREAMING_MODE.toString();
                            if (this.isFirstMktStatusResponse) {
                                setTimeout(function () { clsWorkerHelper.SendMessageToUI('MKTSTATUSRES', _objMktStatusResp); }, 5000);
                                this.isFirstMktStatusResponse = false;
                            }
                            else {
                                clsWorkerHelper.SendMessageToUI('MKTSTATUSRES', _objMktStatusResp);
                            }
                        }
                        break;
                    case clsConstants.C_S_MSGCODE_INDEX_DETAILS_RESPONSE:
                        let objIndexDetailsResponse = this.OCParser.processIndexDetailsResponse(_responsePacket);
                        clsWorkerHelper.SendMessageToUI('INDEXDETAILSRES', objIndexDetailsResponse);
                        break;
                    case clsConstants.C_S_MSGCODE_INDEX_SUBSCRIPTION_RESPONSE:
                        let _objIndexInfoResp = this.OCParser.processIndexInfoResponse(_responsePacket);
                        if (_objIndexInfoResp !== null)
                            clsWorkerHelper.SendMessageToUI('INDEXINFORES', _objIndexInfoResp);
                        break;
                    case clsConstants.C_S_TAG_TRADE_EXECUTION_RANGE_RESPONSE:
                        let objTERResponse = this.OCParser.processTERResponse(_responsePacket);
                        if (objTERResponse !== null)
                            clsWorkerHelper.SendMessageToUI('TERRES', objTERResponse);
                        break;
                    case clsConstants.C_S_MSGCODE_LTP_MULTIPLE_TOUCHLINE_RESPONSE:
                        let _objLTPMultiTLResp = this.OCParser.processLTPMultiTouchLineResponse(_responsePacket);
                        if (_objLTPMultiTLResp !== null)
                            clsWorkerHelper.SendMessageToUI('MTLRES', _objLTPMultiTLResp);
                        break;
                    case clsConstants.C_S_MARK_FOR_DELETION: // CR 6053 start MDaas Changes
                        //this.ReconnectMDaaSSocket();
                        break; // CR 6053 end
                    //PrajyotD - 20-01-2020 for MTL Touchline (s)
                    case clsConstants.C_S_MSGCODE_MTL_MULTIPLE_TOUCHLINE_RESPONSE:
                        let _objMultiMTLResp = this.OCParser.processMultiMTLResponse(_responsePacket);
                        if (_objMultiMTLResp !== null)
                            clsWorkerHelper.SendMessageToUI('MTLRES', _objMultiMTLResp);
                        break;
                    //PrajyotD - 20-01-2020 for MTL Touchline (e)
                    default:
                        break;
                }
            }
        }
        catch (e) {
            console.log("ProcessPacketString: " + e.message);
        }
    };

    handleLoginRequest() {
        try {
            this.sendMessage(this.OCParser.createLoginRequest(this.socketChannelId));
        }
        catch (e) {

        }
    };

    sendMessage(_request: string) {
        /// <summary>
        /// Function to be called whenever request message is to be sent on Channel
        /// </summary>
        /// <param name="_request" type="Array" >
        /// </param>
        try {

            if (this.NetNetWS.WsClient != null && this.NetNetWS.WsClient.readyState == 1) {
                //console.log("REQ: "+ _request);
                this.NetNetWS.WsClient.send(this.addHTTPHeader(_request));
            } else {
                //this.disposeTimer();
                //this.onSocketDisconnected(null);
            }

        } catch (e) {

        }
    };

    /// <summary>
    /// Function to add the HTTP header and tail to the data packet
    /// </summary>
    /// <param name="_requestPacket" type="String">
    /// Request Packet string to be sent over the socket
    /// </param>
    /// <returns type="Array" elementType="Number" elementInteger="true"></returns>
    addHTTPHeader(_requestPacket) {
        try {

            if (typeof (ArrayBuffer) == "undefined") {
                if (this.socketChannelId !== clsConstants.C_S_CHANNEL_INTERACTIVE) {
                    let strHead = String.fromCharCode(2);
                    let length = _requestPacket.length;
                    let lenLength = length.toString().length;
                    let LengthString = "";
                    for (let i = 0; i < (5 - lenLength); i++) {
                        LengthString += "0";
                    }
                    LengthString += length.toString();
                    _requestPacket = strHead + LengthString + _requestPacket;
                    return _requestPacket;
                }
                else {
                    // to do
                    let strHead = String.fromCharCode(2);
                    _requestPacket = strHead + _requestPacket;
                    return _requestPacket;
                }
            }
            else {
                let _strHead = String.fromCharCode(2); //No compression
                if (this.compressStatus == clsConstants.C_S_ON)
                    _strHead = String.fromCharCode(5); //5 comprression char

                let i;
                let _data = new ArrayBuffer(_strHead.length);
                let _headerBytes = new Uint8Array(_data);

                for (i = 0; i < _strHead.length; i += 1) {
                    _headerBytes[i] = _strHead.charCodeAt(i);
                }
                let _baRequest;
                if (this.compressStatus == clsConstants.C_S_ON) {
                    _baRequest = this.handleCompressedData(_requestPacket);
                }
                else {
                    _baRequest = null;//this.handleConvertToByteArray(_requestPacket);
                }

                let _length = _baRequest.length;
                if (this.socketChannelId !== clsConstants.C_S_CHANNEL_INTERACTIVE)
                    _length += 4;
                let _lenLength = _length.toString().length;
                let _lengthString = "";

                for (i = 0; i < (5 - _lenLength); i++) {
                    _lengthString += "0";
                }

                _lengthString += _length.toString();

                _data = new ArrayBuffer(_lengthString.length);
                let _lenBytes = new Uint8Array(_data);

                for (i = 0; i < _lengthString.length; i += 1) {
                    _lenBytes[i] = _lengthString.charCodeAt(i);
                }

                let _baActualSend = new Uint8Array(5 + _length);
                _baActualSend.set(_lenBytes);
                _baActualSend.set(_baRequest, 5);

                let _outputStream = new Uint8Array(_headerBytes.length + _baActualSend.length);
                _outputStream.set(_headerBytes);
                _outputStream.set(_baActualSend, 1);
                return _outputStream.buffer;
            }
        }
        catch (e) {
            console.log(e.message);
        }
    };

    disposeTimer() {
        try {
            if (this.reconnectTimer != null) {
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = null;
            }

            if (this.reconnectInterval != null) {
                clearInterval(this.reconnectInterval);
                this.reconnectInterval = null;
            }

            // this.reconnectSocket = false;
            this.reconnectCntr = 0;
        }
        catch (e) {

        }
    };

    deInitilize() {
        /// <summary>
        /// Function to be called whenever logout is done from NetNet, inorder to stop the socket data
        /// </summary>
        // this.disposeTimer();
        // if (this.NetNetWS.WsClient != null) {
        //     this.NetNetWS.WsClient.close();
        //     this.NetNetWS.WsClient.onmessage = null;
        //     this.NetNetWS.WsClient.onerror = null;
        //     this.NetNetWS.WsClient.onclose = null;
        // }
        // this.NetNetWS.WsClient = null;
        // clearTimeout(this.timerId);
        this.clearObjects();
        clsRequestStore.clearStore();
    }

    onNWSwitch(status) {
        try {
            if (status) {
                this.socketReconnectTimer();
                this.isNWDisconnected = true;
            } else {


                this.clearObjects();
                // if (this.NetNetWS.WsClient != null) {
                //     this.NetNetWS.WsClient.close();
                //     this.NetNetWS.WsClient.onmessage = null;
                //     this.NetNetWS.WsClient.onerror = null;
                //     this.NetNetWS.WsClient.onclose = null;
                //     this.NetNetWS.WsClient = null;
                // }
                // this.isNWDisconnected = false;
                // this.isSocketConnected = false;
                // this.disposeTimer();
            }

        } catch (e) {

        }

    }

    clearObjects() {
        
        this.disposeTimer();
        if (this.NetNetWS.WsClient != null) {
            this.NetNetWS.WsClient.close();
            this.NetNetWS.WsClient.onmessage = null;
            this.NetNetWS.WsClient.onerror = null;
            this.NetNetWS.WsClient.onclose = null;
        }
        this.NetNetWS.WsClient = null;
        this.connectInProgress = false;
        this.isSocketConnected = false;
        this.isNWDisconnected = false;
        clearTimeout(this.timerId);
    }

}
