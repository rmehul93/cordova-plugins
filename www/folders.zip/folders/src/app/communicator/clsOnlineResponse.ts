﻿
export class clsOnlineResponse {
     public MsgCode : string;
     public MsgData :string = "";
     public MsgTime :string = "";
     public MsgCategory :string = "";
     public OrderSide :string = "";
     //BrokerCalls_Caption = WWGlobal.dConfigMaster["BROKERCALL_CAPTION"];        //WWGlobal.dConfigMaster["BROKERCALL_CAPTION"];
     public SubMsgCategory :string = "";
     public AlertMode = 0;
     public AlertSubject :string = "";
     public AlertMsgData :string = "";
     public AlertTriggerCondition = "";
     public OrderType = 0;
     constructor()
     { }
}
