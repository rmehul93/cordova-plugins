import { clsScripKey } from "../Common/clsScripKey";


export class clsIndexInfoResponse {
    public Scrip: clsScripKey;
    public IndexType :any = 0;
    public IndexValue:any = 0;
    public ClosingIndexValue :any = 0;
    public Trend :any = 0;
    public NetChangeInRs :any = 0;
    public PercNetChange :any = 0;
    public LUT :any = 0;
    public OpenIndex :any = 0;
    public HighIndex :any = 0;
    public LowIndex :any = 0;
}
