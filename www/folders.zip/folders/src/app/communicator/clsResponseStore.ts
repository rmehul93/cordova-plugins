import { Dictionary } from "../Common/clsCustomClasses";
import { clsTradingMethods } from "../Common/clsTradingMethods";
import { clsRequestStore } from "./clsRequestStore";
import { clsMultiTouchLineResponse } from "./clsMultiTouchLineResponse";
import { clsOnlineResponse } from "./clsOnlineResponse";
import { clsBestFiveResponse } from "./clsBestFiveResponse";
import { clsTERResponse } from "./clsTERResponse";
import { clsWorkerHelper } from "./clsWorkerHelper";
import { clsGlobal } from "../Common/clsGlobal";

export class clsResponseStore{
   
   public static touchLineResponseList : Dictionary<clsMultiTouchLineResponse> = new Dictionary<clsMultiTouchLineResponse>();
   public static OnlineList : clsOnlineResponse[];
   public static Best5ResponseList : Dictionary<clsBestFiveResponse> = new Dictionary<clsBestFiveResponse>();
   public static TERResponseList : Dictionary<clsTERResponse> = new Dictionary<clsTERResponse>();
   public static LTPTouchLineResponseList : Dictionary<clsMultiTouchLineResponse> = new Dictionary<clsMultiTouchLineResponse>();

   private static AddToList(_onlineResp) {
        try 
        {
            return  this.OnlineList.push(_onlineResp);
        } 
        catch (e) 
        {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'AddToList', 'ResponseStore.js', ''); 
        }
   }

   public static SendOnlineResponse(_response:clsOnlineResponse):void {
        try {

            let objMsg = null;
            for (let i = 0; i < this.OnlineList.length; i++) {
                let _onlineMsg = this.OnlineList[i];
                if (clsTradingMethods.Trim(_response.MsgData) == clsTradingMethods.Trim(_onlineMsg.MsgData) && clsTradingMethods.Trim(_response.MsgTime) == clsTradingMethods.Trim(_onlineMsg.MsgTime))
                {
                    objMsg = _onlineMsg;
                    break;
                }
            }
            // If object is not null, then it is a duplicate message, hence ignore this message
            if (objMsg == null)
            {
                this.AddToList(_response);
                clsWorkerHelper.SendMessageToUI('OLRES', _response);
            }

        } catch (e) {
           // WWclsGlobal.LogManager.WriteLog(e.message, 'SendOnlineResponse', 'ResponseStore.js', ''); 
        }
    };

     public static getTouchLineResponseObject(scripKey:string, _isResponse:boolean) {
        let objMultiTLResponse :clsMultiTouchLineResponse =null;
        try {

          if (this.touchLineResponseList.ContainsKey(scripKey)) {
            objMultiTLResponse = this.touchLineResponseList.getItem(scripKey);
          }
          else {
            if (_isResponse)
            {
                if (clsRequestStore.IsScripExistinTouchLineReqList(scripKey)|| 
                clsRequestStore.IsScripExistinLTPTouchLineReqList(scripKey)||
                    clsGlobal.IsGuestUser)
                {
                    objMultiTLResponse = new clsMultiTouchLineResponse();
                    this.touchLineResponseList.Add(scripKey, objMultiTLResponse);
                }
            }
          }
        } catch (e) {
            //WWclsGlobal.LogManager.WriteLog(e.message, 'GetTouchLineResponseObject', 'ResponseStore.js', ''); 
        }
        return objMultiTLResponse;
    };

     public static RemoveTouchLineResponseObject(scripKey:string) {
        try {
            if (this.touchLineResponseList.ContainsKey(scripKey)) {
                this.touchLineResponseList.Remove(scripKey);
              }
        } catch (e) {
            // WWclsGlobal.LogManager.WriteLog(e.message, 'RemoveTouchLineResponseObject', 'ResponseStore.js', ''); 
        }
    };

    /// <summary>
    /// function to get touchline response object from dictionary list,
    /// Based on scripkey it search in dictionary and return existing obejct
    /// else it creates new object and return the same
    /// </summary>
    public static getLTPTouchLineResponseObject(scripKey:string, _isResponse:boolean) {
       
        let objMultiTLResponse :clsMultiTouchLineResponse =null;
        try {

            if (this.LTPTouchLineResponseList.ContainsKey(scripKey)) {
                objMultiTLResponse = this.LTPTouchLineResponseList.getItem(scripKey);
              }
              else{
                //if method called from OCParser then create new object
                if (_isResponse) {
                    //check if scrip exist then only create and add obect in list
                    if (clsRequestStore.IsScripExistinLTPTouchLineReqList(scripKey) || 
                        clsGlobal.IsGuestUser) {
                        objMultiTLResponse = new clsMultiTouchLineResponse;
                        this.LTPTouchLineResponseList.Add(scripKey,objMultiTLResponse);
                    }
                }
                //change as bug found , if new script added to watchlist its broadcast not reflect in ui.
                //by omprakash D 6 Dec 2017
                else {
                        if (clsGlobal.User.OCToken != "" || clsGlobal.FreeStream) {
                            objMultiTLResponse = this.getTouchLineResponseObject(scripKey, _isResponse);
                        }
                    }
              }
        } catch (e) {

        }
        return objMultiTLResponse;
    };

    /// <summary>
    /// Function to remove touchline response object from dictionary
    /// </summary>
    public static RemoveLTPTouchLineResponseObject(scripKey:string) {
    try {
            if (this.LTPTouchLineResponseList.ContainsKey(scripKey)) {
                this.LTPTouchLineResponseList.Remove(scripKey);
              }
        } catch (e) {

        }
    };

    /// <summary>
    /// function to get Best5 response object from dictionary list
    /// Based on Scrip key it search in dictionary and return existing obejct
    /// else it creates new object and return the same
    /// </summary>
    public static getBest5ResponseObject(scripKey:string, _reCreateDepthobj:boolean) {
        let objBestFiveResponse :clsBestFiveResponse = null;
        try {

            if (this.Best5ResponseList.ContainsKey(scripKey)) {
                objBestFiveResponse = this.Best5ResponseList.getItem(scripKey);
              }
            
                if (objBestFiveResponse != null)
                {
                    if (_reCreateDepthobj)
                    {
                        //new list need to created else it wont update depth details
                        let b1 : any = {};
                         b1.sBuyers="";
                         b1.sBidQty="";
                         b1.sBid="";
                         b1.sSellers="";
                         b1.sAskQty="";
                         b1.sAsk = "";
                         b1.RowIndex = 0;

                         let b2 : any = {};
                         b2.sBuyers = "";
                         b2.sBidQty = "";
                         b2.sBid = "";
                         b2.sSellers = "";
                         b2.sAskQty = "";
                         b2.sAsk = "";
                         b2.RowIndex = 1;
                         let b3 : any = {};
                         b3.sBuyers = "";
                         b3.sBidQty = "";
                         b3.sBid = "";
                         b3.sSellers = "";
                         b3.sAskQty = "";
                         b3.sAsk = "";
                         b3.RowIndex = 2;
                         let b4 : any = {};
                         b4.sBuyers = "";
                         b4.sBidQty = "";
                         b4.sBid = "";
                         b4.sSellers = "";
                         b4.sAskQty = "";
                         b4.sAsk = "";
                         b4.RowIndex = 3;
                         let b5 : any = {};
                         b5.sBuyers = "";
                         b5.sBidQty = "";
                         b5.sBid = "";
                         b5.sSellers = "";
                         b5.sAskQty = "";
                         b5.sAsk = "";
                         b5.RowIndex = 4;
                         objBestFiveResponse.BestFiveData = null;
                        objBestFiveResponse.BestFiveData = [];
                        objBestFiveResponse.BestFiveData.push(b1);
                        objBestFiveResponse.BestFiveData.push(b2);
                        objBestFiveResponse.BestFiveData.push(b3);
                        objBestFiveResponse.BestFiveData.push(b4);
                        objBestFiveResponse.BestFiveData.push(b5);
                    }
                }
                else
                {
                    //check if scrip exist then only create and add obect in list
                    if (clsRequestStore.IsScripExistinBest5ReqList(scripKey) || clsGlobal.IsGuestUser)
                    {
                        objBestFiveResponse = new clsBestFiveResponse();

                        let b1 : any = {};
                        b1.sBuyers = "";
                        b1.sBidQty = "";
                        b1.sBid = "";
                        b1.sSellers = "";
                        b1.sAskQty = "";
                        b1.sAsk = "";
                        b1.RowIndex = 0;

                        let b2 : any = {};
                        b2.sBuyers = "";
                        b2.sBidQty = "";
                        b2.sBid = "";
                        b2.sSellers = "";
                        b2.sAskQty = "";
                        b2.sAsk = "";
                        b2.RowIndex = 1;
                        let b3 : any = {};
                        b3.sBuyers = "";
                        b3.sBidQty = "";
                        b3.sBid = "";
                        b3.sSellers = "";
                        b3.sAskQty = "";
                        b3.sAsk = "";
                        b3.RowIndex = 2;
                        let b4 : any = {};
                        b4.sBuyers = "";
                        b4.sBidQty = "";
                        b4.sBid = "";
                        b4.sSellers = "";
                        b4.sAskQty = "";
                        b4.sAsk = "";
                        b4.RowIndex = 3;
                        let b5 : any = {};
                        b5.sBuyers = "";
                        b5.sBidQty = "";
                        b5.sBid = "";
                        b5.sSellers = "";
                        b5.sAskQty = "";
                        b5.sAsk = "";
                        b5.RowIndex = 4;
                        objBestFiveResponse.BestFiveData = [];
                        objBestFiveResponse.BestFiveData.push(b1);
                        objBestFiveResponse.BestFiveData.push(b2);
                        objBestFiveResponse.BestFiveData.push(b3);
                        objBestFiveResponse.BestFiveData.push(b4);
                        objBestFiveResponse.BestFiveData.push(b5);

                        // if (_scrip.Spread == "1" || _scrip.Spread == "2")
                        //     objBestFiveResponse.IsSpread = true;

                        this.Best5ResponseList.Add(scripKey, objBestFiveResponse)
                    }
                }
        } catch (e) {

        }
        return objBestFiveResponse;
    };

    /// <summary>
    /// Function to remove Best5 response object from dictionary
    /// </summary>
    public static RemoveBest5ResponseObject(scripKey) {
       try {
            if (this.Best5ResponseList.ContainsKey(scripKey)) {
                this.Best5ResponseList.Remove(scripKey);
              }
        } catch (e) {

        }
    };

    public static getTERResponseObject(scripKey, _isResponse:boolean):clsTERResponse {
        
        try {
            let objTERResponse:clsTERResponse = null;

            if (this.TERResponseList.ContainsKey(scripKey)) {
                objTERResponse = this.LTPTouchLineResponseList.getItem(scripKey);
            }
            else {
                //if method called from OCParser then create new object
                if (_isResponse) {
                    //check if scrip exist then only create and add obect in list
                    objTERResponse = new clsTERResponse();
                    this.TERResponseList.Add(scripKey,objTERResponse);
                }
            }
            return objTERResponse;
        } catch (e) {

        }
    };
}
