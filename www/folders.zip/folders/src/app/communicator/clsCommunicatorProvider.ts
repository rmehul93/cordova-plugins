import { Injectable } from '@angular/core';
import { clsWebSocket } from './clsWebSocket';
import { clsConstants } from '../Common/clsConstants';
import { clsWCFComm } from './clsWCFCom';
import { clsHttpService } from '../Common/clsHTTPService';
// import { Events } from '@ionic/angular';
import { clsGlobal } from '../Common/clsGlobal';
import { CDSServicesProvider } from '../providers/cds-services/cds.services';
@Injectable({ providedIn: 'root' })
export class clsCommunicatorProvider {
  private BcastComm: clsWebSocket = null;
  private WCFComm: clsWCFComm = null;
  constructor(public objHttpService: clsHttpService,
    public objCDSService: CDSServicesProvider
    //public events: Events
  ) {
    //if (clsGlobal.pubsub == null)
    // clsGlobal.pubsub = events;
    this.doRequestRegister();
    //this.loadCommunicator();
  }
  loadCommunicator() {
    try {
      if (this.WCFComm == null) {
        this.WCFComm = new clsWCFComm(this.objHttpService, this.objCDSService);
        this.WCFComm.Initilize(clsConstants.C_S_CHANNEL_WCF);
      }
      if (clsGlobal.User.sessionId == null || clsGlobal.User.sessionId.length == 0) {
        if (clsGlobal.FreeStream) {
          if (this.BcastComm == null) {
            this.BcastComm = new clsWebSocket();
            //this.BcastComm.eventPub = this.events;
            this.BcastComm.Initilize(clsGlobal.User.brodcastSocketUrl, clsConstants.C_S_CHANNEL_BROADCAST, false);
          }
        } else {
          this.WCFComm.handleAutoRefreshMode();
        }
      }
      else {
        if (!clsGlobal.User.isGuestUser) {
          if (this.BcastComm == null) {
            this.BcastComm = new clsWebSocket();
            //this.BcastComm.eventPub = this.events;
            this.BcastComm.Initilize(clsGlobal.User.brodcastSocketUrl, clsConstants.C_S_CHANNEL_BROADCAST, false);
          }
        } else {
          this.WCFComm.handleAutoRefreshMode();
        }
      }
    }
    catch (ex) {
    }
  };
  private doRequestRegister() {
    try {
      clsGlobal.pubsub.subscribe('OEREQ', data => this.WCFComm.handleOrderEntryRequest(data));
      clsGlobal.pubsub.subscribe('LTLREQ', data => {
        if (clsGlobal.User.sessionId == null || clsGlobal.User.sessionId.length == 0) {
          if (clsGlobal.FreeStream) {
            this.BcastComm.handleLTPTouchLineRequest(data)
          }
          else {
            this.WCFComm.handleLTPTouchLineRequest(data)
          }
        }
        else {
          if (!clsGlobal.User.isGuestUser) {
            this.BcastComm.handleLTPTouchLineRequest(data)
          } else {
            this.WCFComm.handleLTPTouchLineRequest(data)
          }
        }
      });
      clsGlobal.pubsub.subscribe('MTLREQ', data => {
        if (clsGlobal.User.sessionId == null || clsGlobal.User.sessionId.length == 0) {
          if (clsGlobal.FreeStream) {
            this.BcastComm.handleTouchLineRequest(data)
          }
          else {
            if (this.WCFComm != null && this.WCFComm != undefined)
              this.WCFComm.handleTouchLineRequest(data)
          }
        }
        else {
          if (!clsGlobal.User.isGuestUser) {
            if (this.BcastComm != null && this.BcastComm != undefined)
              this.BcastComm.handleTouchLineRequest(data)
          } else {
            if (this.WCFComm == null) {
              this.WCFComm = new clsWCFComm(this.objHttpService, this.objCDSService);
              this.WCFComm.Initilize(clsConstants.C_S_CHANNEL_WCF);
            }
            this.WCFComm.handleTouchLineRequest(data)
          }
        }
      });
      clsGlobal.pubsub.subscribe('B5REQ', data => {
        if (clsGlobal.User.sessionId == null || clsGlobal.User.sessionId.length == 0) {
          if (clsGlobal.FreeStream) {
            this.BcastComm.handleBestFiveRequest(data)
          }
          else {
            this.WCFComm.handleBestFiveRequest(data)
          }
        }
        else {
          this.BcastComm.handleBestFiveRequest(data)
        }
      });
      clsGlobal.pubsub.subscribe('TGLREQ', data => {
        if (!clsGlobal.isCMOTEnabled) {
          this.WCFComm.handleTopGainerRequest(data)
        }
        else {
          //TODO
          //this.WCFComm.handleBestFiveRequest(data)
        }
      });
      clsGlobal.pubsub.subscribe('MASREQ', data => {
        if (!clsGlobal.isCMOTEnabled) {
          this.WCFComm.handleMostActiveRequest(data)
        }
        else {
          //TODO
          //this.WCFComm.handleBestFiveRequest(data)
        }
      });
      clsGlobal.pubsub.subscribe('POSCONVREQ', data => this.WCFComm.handlePositionConversionRequest(data));
      clsGlobal.pubsub.subscribe('MKTSTATUSREQ', data => this.WCFComm.manualMarketStatusRequest());
      clsGlobal.pubsub.subscribe('SOCKETDISCONNECT', () => {
        if (clsGlobal.User.sessionId == null || clsGlobal.User.sessionId.length == 0) {
          if (clsGlobal.FreeStream) {
            this.BcastComm.deInitilize();
          }
        }
        else {
          this.BcastComm.deInitilize();
        }
      });
      clsGlobal.pubsub.subscribe('APPSUSPEND', data => {
        this.BcastComm.handleAppSuspendRequest(data)
      });
      clsGlobal.pubsub.subscribe('APPRESUME', data => {

        if (this.BcastComm != undefined) {
          if(this.BcastComm.isSocketConnected){
          this.BcastComm.handleAppResumeRequest(data);
          }else{
            this.BcastComm.clearObjects();
            this.BcastComm.handleSocketReconnection();
          }
        }
        
      });
      clsGlobal.pubsub.subscribe('StartAutoRefresh', () => {
        this.WCFComm.handleAutoRefreshMode()
      });
      clsGlobal.pubsub.subscribe('StopAutoRefresh', () => {
        this.WCFComm.stopAutoRefreshTimer()
      });
      clsGlobal.pubsub.subscribe('NW:SWITCH', (status) => {
        if (clsGlobal.User.OCToken.length == 0) return;
        if (this.BcastComm != null)
          this.BcastComm.onNWSwitch(status);
      });
    }
    catch (e) {
      console.log("doRequestRegister: " + e);
    }
  };
  disConnectBroadcast() {
    if (this.BcastComm != undefined) {
      this.BcastComm.deInitilize();
    }
    this.BcastComm = null;
  }
}
