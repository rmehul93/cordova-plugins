﻿import { clsScripKey } from "../Common/clsScripKey";

export class clsTERResponse {
   public Scrip:clsScripKey = null;
   public TER = null;
};
