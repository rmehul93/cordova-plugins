import { NgModule,ModuleWithProviders  } from '@angular/core';
import{clsCommunicatorProvider } from './clsCommunicatorProvider'

@NgModule({
  declarations: [
    //SocketServiceProvider
  ],
  imports: [
    
  ],
  //providers:[ SocketServiceProvider ]
})
export class CommunicatorPageModule {
  static forRoot(): ModuleWithProviders<CommunicatorPageModule> {
    return {
      ngModule: CommunicatorPageModule,
      providers: [clsCommunicatorProvider]
    };
  }
}
