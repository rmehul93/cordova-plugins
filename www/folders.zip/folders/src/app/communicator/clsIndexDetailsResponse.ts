
export class clsIndexDetailsResponse {
     public SegmentId;
     public IndexName;
     public IndexValue;
     public HighPrice;
     public LowPrice;
     public OpenPrice;
     public ClosePrice;
     public LifeTimeHighPrice;
     public LifeTimeLowPrice;
     public MarketCapitalizationInLacs;
     public PercNetChange;
}
