import { clsScrip } from "../Common/clsScrip";

export class clsMostActiveResponse {
    //public SegmentId;
    public  NoOfRecords;
    public MarketType:number;
    public MostActiveData = [];
    public MostActiveDataVolume =[];
    public Mode;
}

export class clsMostActiveScrip {
    public ScripDetail :clsScrip;
    public Volume;
    public Value;
    public TradedPrice;
}
