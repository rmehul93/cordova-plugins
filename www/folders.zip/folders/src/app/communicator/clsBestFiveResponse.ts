import { clsScripKey } from "../Common/clsScripKey";

export class clsBestFiveResponse {
    public Scrip: clsScripKey;
    public LTP = null;
    public PercNetChg = null;
    public ClosePrc = null;
    public OpenPrc = null;
    public LowPrc = null;
    public HighPrc = null;
    public LTQ = null;
    public LUT = null;
    public LTT = null;
    public Volume = null;
    public TotBuyQty = null;
    public TotSellQty = null;
    public ATPPrc = null;
    public YrLowPrc = null;
    public YrHighPrc = null;
    public DPR = null;
    public BestFiveData = [];
    public DecimalLocator = null;
    public IsSpread = null;
    public TER = null;
    public OI = null;
    public PercOpenInt = null;
    public HighOpenInt = null;
    public LowOpenInt = null;
    public NetChangeInRs = null;
    public PriceFormat = 2;
}
