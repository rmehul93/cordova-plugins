import { clsScrip } from "../Common/clsScrip";

export class clsTopGainerResponse {
     //public SegmentId:number;
     public NoOfRecords:any;
     public MarketType:number;
     public TopGainerData:any = [];
     public ResponseType:any;
}

export class clsTopGainerScrip {
    public ScripDetail :clsScrip;
    public ChangeMarketIndicator:any;
    public PrevClosePrice:any;
    public PercentChanged:any;
    public TradedPrice:any;
    public NetChangeInRs:any;
}
