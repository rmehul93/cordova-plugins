import { clsCommunicator } from './clsCommunicator';
import { clsConstants } from '../Common/clsConstants';
import { clsMarketStatusResponse } from './clsMarketStatusResponse';
import { clsTradingMethods } from '../Common/clsTradingMethods';
import { clsOnlineResponse } from './clsOnlineResponse';
import { clsHttpService } from '../Common/clsHTTPService';
import { clsGlobal } from '../Common/clsGlobal';
import { clsRequestStore } from './clsRequestStore';
import { clsWorkerHelper } from './clsWorkerHelper';
import { clsCommonMethods } from '../Common/clsCommonMethods';
import { clsAppConfigConstants } from '../Common/clsAppConfigConstants';
import { CDSServicesProvider } from '../providers/cds-services/cds.services';


export class clsWCFComm extends clsCommunicator {

    private autoRefreshTime: number = 0;

    constructor(public objHttpService: clsHttpService,
        public objCDSService: CDSServicesProvider) {
        super();
    }

    /// <param name="_strChannelId" type="String">
    /// Channel Id i.e WCF
    /// </param>
    Initilize(_strChannelId) {

        try {
            this.onInitilize();
            this.socketChannelId = _strChannelId;
            //this.OCParser = new Parser();
        }
        catch (e) {
            //WWLogManager.WriteLog(e.message, 'Initilize', 'WCFComm.ts', '');
        }
    };

    /// <summary>
    /// Function to be called whenever request message is to be sent on Channel
    /// </summary>
    /// <param name="_request" type="Array">
    /// </param>
    sendMessage(_request) {
        try {

            for (var i = 0; i < _request.length; i++) {
                let reqString = "/" + clsTradingMethods.getApiExchangeName(_request[i].MktSegId) + "/" +  _request[i].token
                
                this.objCDSService.getCdsBroadcast(reqString).then((respBcast:any) =>{
                    console.log("BCAST RESPONSE: ", respBcast);
                    this.handleLTPTouchLineResponse(respBcast);
                })
            }

        }
        catch (e) {

            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');

        }
    };
    /// <summary>
    /// Handler for Order Entry Request
    /// Whenever Order will be send via LITE mode below function will be called
    /// </summary>
    /// <param name="_orderEntryRequest" type="Object">
    /// OrderEntryRequest object
    /// </param>
    handleOrderEntryRequest(_orderEntryRequest) {

        try {
            let _request = this.OCParser.createOrderEntryRequest(_orderEntryRequest);
            //this.sendMessage(re);
            //let strRequest = clsCommonMethods.UrlEncoding(_request);
            let OERequest: any = {};
            OERequest.OEData = _request;

            // this.objHttpService.postJson("http://172.25.100.174:9902/",
            //    clsGlobal.Transactional + clsGlobal.LocalComId + "v1/placeOrder"
            //     , OERequest).subscribe(objResponse => {
            //         this.onRequestCompleted(objResponse);
            //     }, error => {
            //         console.log(error);
            //     });

            this.objHttpService.postJson(clsGlobal.VirtualDirectory,
                clsGlobal.Transactional + clsGlobal.LocalComId + "v1/placeOrder"
                , OERequest).subscribe((objResponse: any) => {
                    clsGlobal.pubsub.publish('OERES', objResponse);
                }, error => {
                    let objResponse: any = {}
                    objResponse.status = false;
                    objResponse.result = { ordMsg: error };
                    clsGlobal.pubsub.publish('OERES', objResponse);
                });
        }
        catch (e) {

            let objResponse: any = {}
            objResponse.status = false;
            objResponse.result = { ordMsg: e.message };
            clsGlobal.pubsub.publish('OERES', objResponse);


        }
    };

    manualMarketStatusRequest() {
        try {
            var re = this.OCParser.createMarketStatusRequest();
            this.sendMessage(re);
        }
        catch (e) {

            // WWLogManager.WriteLog(e.message, 'ManualMarketStatusRequest', 'WCFComm.ts', '');

        }
    }

    /// <summary>
    /// Callback function for the service call on success call
    /// </summary>
    /// <param name="obj1" type="Object">
    /// Request object
    /// </param>
    /// <param name="obj2" type="Object">
    /// </param>
    onRequestCompleted(obj1) {

        this.ProcessPacketString(obj1);
    }

    formatMktStatusResponse(_responsePacket) {
        var resp = _responsePacket.ResponseObject.objJSONData;
        var strFormattedStatus = '';

        var strNSEEQStatus, strNSEDERVStatus, strBSEEQStatus, strBSEDERVStatus, strMCXStatus, strNCDEXStatus,
            strNSELStatus, strMCXSXStatus, strNSXStatus, strMCXSXEQStatus, strMCXSXFAOStatus, strDSEEQStatus, strNMCEFUTStatus,
            strBSESPOSStatus, strDGCXStatus, strBFXStatus, strUCXStatus, strIPOStatus, strDFMEQStatus, strADXEQStatus, strMSXFIMStatus, strGBOTStatus;

        strNSEEQStatus = resp.Table1[0][clsConstants.C_V_NSE_CASH];
        strNSEDERVStatus = resp.Table1[0][clsConstants.C_V_NSE_DERIVATIVES];
        strBSEEQStatus = resp.Table1[0][clsConstants.C_V_BSE_CASH];
        strBSESPOSStatus = resp.Table1[0][clsConstants.C_V_BSE_SPOS];
        strBSEDERVStatus = resp.Table1[0][clsConstants.C_V_BSE_DERIVATIVES];
        strMCXStatus = resp.Table1[0][clsConstants.C_V_MCX_DERIVATIVES];
        strNCDEXStatus = resp.Table1[0][clsConstants.C_V_NCDEX_DERIVATIVES];
        strNSELStatus = resp.Table1[0][clsConstants.C_V_NSEL_DERIVATIVES];
        strMCXSXStatus = resp.Table1[0][clsConstants.C_V_MSX_DERIVATIVES];
        strNSXStatus = resp.Table1[0][clsConstants.C_V_NSX_DERIVATIVES];
        strMCXSXEQStatus = resp.Table1[0][clsConstants.C_V_MSX_CASH];
        strMCXSXFAOStatus = resp.Table1[0][clsConstants.C_V_MSX_FAO];
        strDSEEQStatus = resp.Table1[0][clsConstants.C_V_DSE_CASH];
        strNMCEFUTStatus = resp.Table1[0][clsConstants.C_V_NMCE_DERIVATIVES];
        strDGCXStatus = resp.Table1[0][clsConstants.C_V_DGCX_DERIVATIVES];
        strBFXStatus = resp.Table1[0][clsConstants.C_V_BFX_DERIVATIVES];
        strDFMEQStatus = resp.Table1[0][clsConstants.C_V_DFM_CASH];
        strADXEQStatus = resp.Table1[0][clsConstants.C_V_ADX_CASH];
        strUCXStatus = resp.Table1[0][91];
        strIPOStatus = resp.Table1[0][clsConstants.C_V_OFS_IPO_BONDS];
        strMSXFIMStatus = resp.Table1[0][clsConstants.C_V_MSX_FIM];
        strGBOTStatus = resp.Table1[0][clsConstants.C_V_GBOT_DERIVATIVES];

        strFormattedStatus = clsConstants.C_V_NSE_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNSEEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_NSE_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNSEDERVStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_BSE_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strBSEEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_BSE_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strBSEDERVStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_MCX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strMCXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_NCDEX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNCDEXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_NSEL_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNSELStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_MSX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strMCXSXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_NSX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNSXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_MSX_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strMCXSXEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_MSX_FAO.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strMCXSXFAOStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_MSX_FIM.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strMSXFIMStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_DSE_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strDSEEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_NMCE_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strNMCEFUTStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_BSE_SPOS.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strBSESPOSStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_DGCX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strDGCXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_BFX_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strBFXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_DFM_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strDFMEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_ADX_CASH.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strADXEQStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_GBOT_DERIVATIVES.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strGBOTStatus + clsConstants.C_S_FIELD_DELIMITER +
            //clsConstants.C_V_UCX_DERIVATIVES.ToString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strUCXStatus;
            //91 has been hard coded here since Tag# 19 has already been used by BSE SPOS and will cause clash 
            //in SL layer
            "91" + clsConstants.C_S_NAMEVALUE_DELIMITER + strUCXStatus + clsConstants.C_S_FIELD_DELIMITER +
            clsConstants.C_V_OFS_IPO_BONDS.toString() + clsConstants.C_S_NAMEVALUE_DELIMITER + strIPOStatus;

        return strFormattedStatus;
    }

    /// <summary>
    /// Function to process each packet string recvd from the wcf call according to their respective message codes and then publish the message to the subscibers
    /// </summary>
    /// <param name="_responsePacket" type="String">
    ///  response string
    /// </param>
    ProcessPacketString(_responsePacket) {

        try {
            if (_responsePacket == null || _responsePacket == '')
                return;
            //_responsePacket = JSON.parse(_responsePacket);
            _responsePacket = _responsePacket.ResponseString;
            let strMessageCode = clsTradingMethods.FindValue(_responsePacket, clsConstants.C_S_TAG_MSGCODE);
            switch (strMessageCode) {
                case clsConstants.C_V_MSGCODES_MARKETSTATUS_REPONSE:
                    let _objMktStatusResp = new clsMarketStatusResponse;
                    _objMktStatusResp.ResponseString = this.formatMktStatusResponse(_responsePacket);
                    _objMktStatusResp.ResponseFlag = (clsConstants.C_S_REFRESH_MODE).toString();
                    clsWorkerHelper.SendMessageToUI('MKTSTATUSRES', _objMktStatusResp)
                    break;
                case clsConstants.C_V_MSGCODES_ORDERENTRYMODIFYCANCEL_REQUEST:
                    let objOnlineOrdSubmitted = this.handleOrderResponse(_responsePacket);
                    clsWorkerHelper.SendMessageToUI('OLRES', objOnlineOrdSubmitted)
                    break;
                case clsConstants.C_S_MSGCODE_MULTIPLE_TOUCHLINE_RESPONSE:
                    this.handleTouchLineResponse(_responsePacket);
                    break;
                case clsConstants.C_S_MSGCODE_INDEX_SUBSCRIPTION_RESPONSE:
                    this.handleIndexInfoResponse(_responsePacket);
                    break;
                case clsConstants.C_S_MSGCODE_BESTFIVE_RESPONSE:
                    let objBF5Response = this.OCParser.processBestFiveResponse(_responsePacket);
                    clsWorkerHelper.SendMessageToUI('B5RES', objBF5Response);
                    break;

                case clsConstants.C_V_MSGCODES_TOPGAINERSLOSERSRESPONSENEW.toString():
                    let objTGLResponse = this.OCParser.processTopGainerResponse(_responsePacket);
                    clsWorkerHelper.SendMessageToUI('B5RES', objTGLResponse);
                    break;
                case clsConstants.C_V_MSGCODES_MOSTACTIVERESPONSENEW.toString():
                    let objMASResponse = this.OCParser.processMostActiveResponse(_responsePacket);
                    //For Refresh user temporary commented need to change later
                    clsWorkerHelper.SendMessageToUI('MASRES', objMASResponse);
                    break;
                case clsConstants.C_S_MSGCODE_LTP_MULTIPLE_TOUCHLINE_RESPONSE:
                    this.handleLTPTouchLineResponse(_responsePacket);
                    break;
            }
        }
        catch (e) {

            //WWLogManager.WriteLog(e.message, 'ProcessPacketString', 'WCFComm.ts', '');

        }
    };

    handleTouchLineResponse(_strResponse: string) {
        try {
            if (_strResponse.endsWith(clsConstants.C_S_MULTIRESP_DELIMITER))
                _strResponse = _strResponse.substring(0, _strResponse.length - 1);

            let arrMultiTLResp = _strResponse.split(clsConstants.C_S_MULTIRESP_DELIMITER);

            for (let intTLArr = 0; intTLArr < arrMultiTLResp.length; intTLArr++) {
                let objMultiTLResp = this.OCParser.processMultiTouchLineResponse(arrMultiTLResp[intTLArr]);
                clsWorkerHelper.SendMessageToUI('MTLRES', objMultiTLResp);
            }
        }
        catch (error) {

        }
    }

    /// <summary>
    /// Handler for Order Response
    /// </summary>
    /// <param name="_strResponse">Response string</param>
    handleOrderResponse(_strResponse: string) {
        try {
            let strOrdMsg = clsTradingMethods.FindValue(_strResponse, clsConstants.C_V_TAG_ORDERSUBMITSTATUS.toString());
            let objResp: clsOnlineResponse = new clsOnlineResponse();
            objResp.MsgCode = clsConstants.C_V_MSGCODES_ORDERENTRYMODIFYCANCEL_REQUEST;
            objResp.MsgData = strOrdMsg;
            objResp.MsgTime = "";
            objResp.MsgCategory = clsConstants.C_S_MSGCAT_ACK;
            return objResp;
        }
        catch (e) {

        }
    };

    /// <summary>
    /// Handler for Index Info Response
    /// </summary>
    /// <param name="_response" type="String">
    /// Response string
    /// </param>
    handleIndexInfoResponse(_responsePacket: string) {
        try {

            if (_responsePacket.endsWith(clsConstants.C_S_MULTIRESP_DELIMITER))
                _responsePacket = _responsePacket.substr(0, _responsePacket.length - 1);
            let arrMultiTLResp = _responsePacket.split(clsConstants.C_S_MULTIRESP_DELIMITER);

            for (let intTLArr = 0; intTLArr < arrMultiTLResp.length; intTLArr++) {
                let _objIndexInfoResponse = this.OCParser.processIndexInfoResponse(arrMultiTLResp[intTLArr]);
                clsWorkerHelper.SendMessageToUI('INDEXINFORES', _objIndexInfoResponse);
            }
        } catch (e) {

        }
    };

    /// <summary>
    /// Handler for TouchLine Response
    /// </summary>
    /// <param name="_strResponse">Response string</param>
    handleLTPTouchLineResponse = function (_strResponse: String) {
        try {

            let objMultiTLResp = this.OCParser.processCMOTTouchLineResponse(_strResponse);
            clsWorkerHelper.SendMessageToUI('MTLRES', objMultiTLResp);
            
        }
        catch (e) {

        }
    };


    /// <summary>
    /// Handler for Position Conversion Request
    /// Whenever Order will be send via LITE mode below function will be called
    /// </summary>
    /// <param name="_posConvRequest" type="Object">
    /// </param>
    handlePositionConversionRequest(_posConvRequest) {

        try {
            let _request = this.OCParser.createPositionConvRequest(_posConvRequest);

            let OERequest: any = {};
            OERequest.OEData = _request;

            this.objHttpService.postJson(clsGlobal.VirtualDirectory,
                clsGlobal.Transactional + clsGlobal.LocalComId + "v1/placeOrder"
                , OERequest).subscribe((objResponse: any) => {
                    clsGlobal.pubsub.publish('OERES', objResponse);
                }, error => {
                    let objResponse: any = {}
                    objResponse.status = false;
                    objResponse.errorCode = { ordMsg: error };
                    clsGlobal.pubsub.publish('OERES', objResponse);
                });
        }
        catch (e) {

            let objResponse: any = {}
            objResponse.status = false;
            objResponse.errorCode = { ordMsg: e.message };
            clsGlobal.pubsub.publish('OERES', objResponse);

        }
    };

    /// <summary>
    /// Function to swtich to AutoRefresh mode if the autorefresh mode flag is ON else behave as normal Refresh mode
    /// If the reconnect attempt exceeds the max attempt, then switch to Auto-Refresh mode
    /// </summary>
    /// <param name="_channelId" type="String">
    /// </param>
    handleAutoRefreshMode() {
        try {

            this.startAutoRefreshTimer();
        }
        catch (e) {
        }
    };


    /// <summary>
    /// Start the Timer in case of AutoRefresh mode and keeps calling the AutoRefreshCallbackEvent after a specific interval
    /// </summary>
    private startAutoRefreshTimer() {
        try {

            // let interval = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_AUTOREFRESH_TIMER_VALUE));
            // let SocketAutoRefreshTimer = (interval != undefined && !isNaN(interval)) ? interval : 20000;

            // if (this.autoRefreshTime == null || this.autoRefreshTime == 0) {
            //     let callbackFunc = this.autoRefreshCallbackEvent.bind(this);
            //     this.autoRefreshTime =setInterval(callbackFunc, SocketAutoRefreshTimer,null);
            //     this.autoRefreshCallbackEvent();
            // }
        }
        catch (e) {
        }
    };

    stopAutoRefreshTimer() {
        try {

            if (this.autoRefreshTime != null) {
                clearInterval(this.autoRefreshTime);
            }

            /*    
            for (var i = 0; i < _selfCom.ArrToken.length; i++) {
                clsGlobal.pubsub.unsubscribe(_selfCom.ArrToken[i]);
            }
            _selfCom.ArrToken = [];
            _selfCom.OCInteractiveComm = null;
            _selfCom.OCBcastComm = null;
            _selfCom.JSComm = null;
            _selfCom.WCFComm = null;

            */
        }
        catch (e) {

        }

    }

    private autoRefreshCallbackEvent() {
        /// <param name="_state" type="Object">
        /// </param>
        try {

            this.handleLTPTouchLineRequest(clsRequestStore.getLTPTouchLineRequest(1));
            this.handleTouchLineRequest(clsRequestStore.getTouchLineRequest(1));
            this.handleBestFiveRequest(clsRequestStore.getBest5Request(1));

        }
        catch (e) {

        }
    };

};

