import { AlertEngineService } from 'src/app/providers/alert-engine.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NavController, Platform } from '@ionic/angular';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { NavParamService } from 'src/app/providers/nav-param.service';
//import xml2json from 'xml2json';
import * as xml2js from 'xml2js';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';



@Component({
  selector: 'app-recommendation',
  templateUrl: './recommendation.page.html',
})
export class RecommendationPage implements OnInit {

  constructor(public navCtrl: NavController,
    private navParams: NavParamService,
    public http: clsHttpService,
    public objCDSService: CDSServicesProvider,
    private alertEngineService: AlertEngineService,
    private toastCtrl: ToastServicesProvider,
    public speechRecognition: SpeechRecognition,
    public loadingCtrl: LoaderServicesProvider,
    public platform: Platform
  ) { }
  mode: string = 'reco';
  recopopupShow: boolean = false;
  recoFilterPopup: boolean = false;
  showSelectpopup: boolean = false;
  showOEPopUp: boolean = false;
  recoCount: number;
  depthRecoNewsDetails: any = [];
  otherNews: any = [];
  details: any;
  heading: any;
  date: any;
  recoData: any = [];
  filterRecoData: any = [];
  data: boolean = false;
  recoFilterObject: any = {};
  isFilterApply : boolean = false;

  searchTextReco:any  = '';
  searchTextChangedReco = new Subject<string>();
  searchTextEnteredReco:any='';
  showSearchReco:boolean = false;
  recoSearchData:any = [];
  subscriptionReco :any;

  @ViewChild('divRecoFilter', { static: false }) divRecoFilter: ElementRef;
  showExpandedRecoFilter: boolean = false;
  recoFilterPane: any;



  scripAlertData : any = [];
  allTransactionType : any = [];
  allRecoTags : any = [];
  scripAlertpopupShow: boolean = false;
  scripAlertFilterPopup: boolean = false;
  scripAlertFilterObject : any = {}
  filterScripAlertData: any = [];
  searchTextScripAlert:any  = '';
  searchTextChangedScripAlert = new Subject<string>();
  searchTextEnteredScripAlert:any='';
  showSearchScripAlert:boolean = false;
  scripAlertSearchData:any = [];
  subscriptionScripAlert :any;

  scripAlertKeys : any = [];
  bcastHandler:any ;
  
  @ViewChild('divScripAlertFilter', { static: false }) divScripAlertFilter: ElementRef;
  showExpandedScripAlertFilter: boolean = false;
  scripAlertFilterPane: any;
 
  scripRecoKeys : any = [];
  graphRecoObject :any = [];
  countGraph = 0;

  recoFollowUp : boolean = false;
  noDataFoundReco: boolean = false;
  recoLoader : boolean = false;
  noDataFoundRecoSearch : boolean = false;
  recoLoaderSearch : boolean = false;
  //speech recognition
  showSegments: boolean = false;
  isBracketAllowed : boolean = false;
  isCoverAllowed : boolean = false;
  isGuestUser: boolean = false;


  ngOnInit() {
    try{
      clsGlobal.logManager.writeUserAnalytics("RecommendationPage", "", "VISIT", ""); 
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      this.subscriptionReco = this.searchTextChangedReco.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValuesReco(search));

      this.subscriptionScripAlert = this.searchTextChangedScripAlert.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValuesScripAlert(search));
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'ngOnInit', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }

  }
  ionViewDidLoad(){
    clsGlobal.logManager.writeUserAnalytics("RecommendationPage","","VISIT",""); 
  }
  ionViewWillEnter() {
    try{
      this.isGuestUser = clsGlobal.User.isGuestUser;
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      this.getRecommendation();
      this.getScripAlerts();
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'ionViewWillEnter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }     
  }

  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.scripAlertKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.scripRecoKeys);
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'ionViewWillLeave', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goBack() {
    try{
      this.navCtrl.pop();
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'goBack', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'goBack',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  login(){
    this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
  }

  segmentChanged(event) {
    try{
      this.mode = event.detail.value;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'segmentChanged', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'segmentChanged',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  recoPopupClose() {
    try{
      this.recopopupShow = false;
    }catch(error){
      // clsGlobal.logManager.writeErrorLog('RecommendationPage', 'recoPopupClose', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'recoPopupClose',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  recoPopup(item) {
    setTimeout(() => {this.data = true;}, 3000);
    try{
      this.recopopupShow = true;
      this.otherNews = [];
      this.heading = item.heading;
      this.details = item.details;
      this.date = item.date;

      for (let count = 0; count < this.depthRecoNewsDetails.length; count++) {
        if ((item.CompanyCode == this.depthRecoNewsDetails[count].CompanyCode) && (item.Count != this.depthRecoNewsDetails[count].Count)) {
          this.otherNews.push(this.depthRecoNewsDetails[count]);
        }
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'recoPopup', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'recoPopupClose',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  selectPopup() {
    try{
      this.showSelectpopup = !this.showSelectpopup;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'selectPopup', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'selectPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closeSelectPopup(){
     try{
      this.showSelectpopup = false; //!this.showSelectpopup;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'closeSelectPopup', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'closeSelectPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  openOrderEntryScripAlert(selectedScripItem) {
    try { 
      let currScrip: clsScrip = new clsScrip();
      currScrip = clsCommonMethods.getScripObject(selectedScripItem.scripObj).scripDetail;
    
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
      objOEFormDetail.orderPrice = selectedScripItem.LTP;
      objOEFormDetail.scripDetl = currScrip;
      objOEFormDetail.pageSource = clsConstants.C_V_RECOMMENDATION_PAGE;
      this.navParams.myParam = objOEFormDetail;
      this.navCtrl.navigateForward('orderentry');
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'openOrderEntryScripAlert', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'openOrderEntryScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveMessage($event) {
    try{
      this.showOEPopUp = !$event.closePopUp;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'receiveMessage', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'receiveMessage',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showManageAlerts() {
    try{
      if(this.scripAlertData.filter((alert:any)=> { return alert.triggered ==0}).length > 0){
        this.navParams.myParam = this.scripAlertData.filter((alert:any)=> { return alert.triggered ==0});
        this.navCtrl.navigateForward('managealerts');
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showManageAlerts', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showManageAlerts',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getActiveAlertCount(){
    return     this.scripAlertData.filter((alert:any)=> { return alert.triggered ==0}).length;
  }

  getRecommendation() {
    try {
      this.recoLoader = true;
      let recmParamReq: any = {};
      recmParamReq.mktSegId = null;
      recmParamReq.token = null;
      // this.recoCount = 5;
      recmParamReq.allowedNewsCat = clsGlobal.User.NewsCategories;//'25045';//"25037, 25034, 25000, -1, ";
      this.recoData =[];
      this.noDataFoundReco = false;
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getRecommendation', recmParamReq).subscribe(resRec => {
        this.recoLoader = false;
        if (resRec.status == true) {
         // this.noDataFoundReco = false;
          let recdata: any = resRec.result;
          this.recoCount = recdata.length;
          if (recdata.length > 0) {
            this.noDataFoundReco = false;
            for (let i = 0; i < recdata.length; i++) {
              let mktSegId = clsTradingMethods.GetMarketSegmentID(recdata[i].nMarketSegmentId);
              let exchangeName = clsTradingMethods.getExchangeName(mktSegId);
              let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
              recdata[i].exchange = exchange;
              recdata[i].exchangeName = exchangeName;
              recdata[i].sRecoDetails = this.convertXmlToJson(recdata[i].sRecoDetails);
              recdata[i].sRecoType = ((recdata[i].sRecoDetails[0].sLongShort == "L") ? "Long Term" : "Short Term");
              recdata[i].detailsVisible = false;
              let scrip = recdata[i].sScripDesc.split(" ")
              recdata[i].buyExit = recdata[i].sRecoDetails[0].nBuySell;// == 'Buy' ? 'Buy' : 'Exit';
              //recdata[i].sScripName = recdata[i].buyExit + ' ' + scrip[2];
             //recdata[i].sScripName = recdata[i].sRecoDetails[0].nBuySell + ' ' + scrip[2];
              recdata[i].transaction_type = recdata[i].sRecoDetails[0].nBuySell.toUpperCase();
              //recdata[i].product_type = recdata[i].sRecoType.toUpperCase();
              recdata[i].scripNews = [];
              recdata[i].date = recdata[i].sRecoDetails[0].dEnteredTime;
              recdata[i].dEndTime = clsCommonMethods.getRecoDateTime(recdata[i].dEndTime);
              let scriptime = recdata[i].sRecoDetails[0].dEnteredTime.split(' ');
              recdata[i].dEnteredTime = scriptime[scriptime.length-1];
              for(let j = 0; j < recdata[i].sRecoDetails.length; j++){
                
                let scripTime = recdata[i].sRecoDetails[j].dEnteredTime.replace(/\s+/g,' ').trim().split(' ');
                recdata[i].sRecoDetails[j].followTime = scripTime[1] +" "+scripTime[0] +" '"+scripTime[2].slice(2,4) +" "+ scripTime[scripTime.length-1];
              }
             // recdata[i].sRecoDetails[0].followTime = scripTime[1] +" "+scripTime[0] +" '"+scripTime[2].slice(2,4) +" "+ scripTime[scripTime.length-1];
             if( recdata[i].sRecoDetails[0].sURL){
              recdata[i].showRecoAttachment = true;
             }else{
              recdata[i].showRecoAttachment = false;
             }
             recdata[i].hots = [];
              recdata[i].ltp = "0.00";
              recdata[i].selctedReco = false;
              recdata[i].expiry= "";
              recdata[i].strikeprice='';
              recdata[i].sOptionType = "";
              recdata[i].scripObj ={};
              //recdata[i].sRecoTag = recdata[i].sRecoDetails[0].sRecoTag;
              recdata[i].scripObj.symbol='';//resp.result[index].sSymbol;
              recdata[i].scripObj.ExpiryDate = 'NA'; //resp.result[index].nExpiryDate1;
              recdata[i].scripObj.StrikePrice = 'NA';//resp.result[index].nStrikePrice1;
              recdata[i].scripObj.OptionType = 'NA';//resp.result[index].sOptionType;
              recdata[i].scripObj.InstrumentName='';
              let recoEntryPrice =  parseFloat(recdata[i].sRecoDetails[0].EnteredPrice);
              let calSLPrice = recoEntryPrice - ((recoEntryPrice*10)/100);
              let calSQPrice = recoEntryPrice + ((recoEntryPrice*10)/100);
              let recoSLPrice =recdata[i].sRecoDetails[0].SLPrice == '' ? calSLPrice : parseFloat(recdata[i].sRecoDetails[0].SLPrice);
              let recoSQPrice = recdata[i].sRecoDetails[0].SQPrice == '' ? calSQPrice : parseFloat(recdata[i].sRecoDetails[0].SQPrice);
              let recoLTP =  parseFloat(recdata[i].ltp);
              recdata[i].recoEntryPrice = recoEntryPrice;
              recdata[i].recoSLPrice = recoSLPrice;
              recdata[i].recoSQPrice = recoSQPrice;
              //recdata[i].recoLTP = recoLTP;
              if(recdata[i].sRecoDetails[0].sFormattedReco == "Recommendation Withdrawn"){
                recdata[i].buySellDisabled = true;
              }
              else{
                recdata[i].buySellDisabled = false;
              }

              recdata[i].graphValue = [
                {
                  "value": recoEntryPrice,
                  "color": "A",
                  "lable": "EntyrPrice"},
                  {
                  "value": recoSLPrice,
                  "color": "A",
                  "lable": "SLPrice"
                  },
                  {
                  "value": recoSQPrice,
                  "color": "A",
                  "lable": "TargetPrice"
                  },
                  {
                  "value": recoLTP,
                  "color": "A",
                  "lable": "LTP"
                }].sort((n1,n2) => n1.value - n2.value);
              recdata[i].dualKnob ={lower : recdata[i].graphValue[1].value  , upper : recdata[i].graphValue[2].value};
              recdata[i].minValue = recdata[i].graphValue[0].value;// == 0 ? 'ND' : recdata[i].graphValue[0].value;== 0 ? 'ND' :recdata[i].graphValue[2].value
              recdata[i].maxValue = recdata[i].graphValue[3].value;// == 0 ? 'ND' :recdata[i].graphValue[3].value;== 0 ? 'ND' : recdata[i].graphValue[1].value
              recdata[i].newsAllow = this.checkMarketSegmentForNews(recdata[i].nMarketSegmentId);
             
              
              this.recoData.push(recdata[i]);
            }
            this.allTransactionType = [...new Set(this.recoData.map(element=> element.transaction_type))]; 
            this.allRecoTags = [...new Set(this.recoData.flatMap(element=>element.sRecoTag!= "" ?element.sRecoTag: []))];
            let newreco : any = [];
            newreco =this.recoData.sort((a,b)=>{ return (b.date) - (a.date);});
            this.loadScripDetails();
            // Events binding after array creation.
            //this.recoData
            // this.filterRecoData = this.recoData;
            if (clsGlobal.EventList.length > 0) {
              for (let index = 0; index < clsGlobal.EventList.length; index++) {
                const element = clsGlobal.EventList[index];
                // let scripKey: clsScripKey = new clsScripKey();
                // scripKey.MktSegId = parseInt(element.mktid);
                // scripKey.token = (element.token); 
                for (let index = 0; index < this.recoData.length; index++) {
                  if (this.recoData[index].nMarketSegmentId == element.mktid && element.token == this.recoData[index].nToken) {
                    if(element.event != "Reco"){
                      this.recoData[index].hots.push(element.event);
                    }
                  }
                }
              }
            }
            //this.loadScripDetails();
            let uniqueTokenList: Dictionary<string> = new Dictionary<string>();
            for (let i = 0; i < this.recoData.length; i++) {
              let _key = this.recoData[i].nMarketSegmentId + "$" + this.recoData[i].nToken;
              if (!uniqueTokenList.ContainsKey(_key)) {
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = this.recoData[i].nToken;
                objScrpKey.MktSegId = this.recoData[i].nMarketSegmentId;
                this.scripRecoKeys.push(objScrpKey);
                if (this.recoData[i].newsAllow) {
                  uniqueTokenList.Add(_key, "exists");
                  let _MktSegId = clsTradingMethods.GetMarketSegmentID(this.recoData[i].nMarketSegmentId);
                  this.getScripNews(_MktSegId, this.recoData[i].nToken, 3, this.recoData[i].sRecoId);
                }
              }
            }
            this.sendTouchlineRequest(OperationType.ADD,this.scripRecoKeys);
            clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
            this.filterRecoData = this.recoData;
           } else {
            this.noDataFoundReco = true;
          }
        }
        else {
          this.noDataFoundReco = true;
        }
        
      }, error => {
        this.noDataFoundReco = true;
        this.recoLoader = false;
        //clsGlobal.logManager.writeErrorLog('researchcall', 'getRecommendation_1', error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getRecommendation_1',error.Message,undefined,error.stack,undefined,undefined));
      })

    } catch (error) {
      this.noDataFoundReco = true;
      this.recoLoader = false;
      //clsGlobal.logManager.writeErrorLog('researchcall', 'getRecommendation_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getRecommendation_2',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  getScripAlerts() {
    try{
      this.alertEngineService.getScripAlerts().then((alertsResponse: any) => {
        if (alertsResponse.status = 'success') {
          this.scripAlertData = alertsResponse.data;
          this.loadScripDetailsForAlerts ()
          this.createScripAlertsData();
          this.createBroadcastforscripAlerts()
        }
      }, error => {
        console.log(error)
      })
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getScripAlerts', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getScripAlerts',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async loadScripDetailsForAlerts(){
    try{
      let scripdetail = {
        scrips: []
      }

    await this.scripAlertData.forEach(element => {
      element.createDate = clsCommonMethods.getAlertsDateTime(element.createDate);
      element.token = element.condition[0].operand1.token;
      element.mktSegId = clsTradingMethods.GetMarketSegmentID(element.condition[0].operand1.marketsegment);
      element.exchange = clsTradingMethods.getApiExchangeName(element.mktSegId);
      element.displayExchange = clsTradingMethods.getExchangeName(element.mktSegId);
      scripdetail.scrips.push({
        mkt: element.exchange,
        token: element.token
      });
    });

    await clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
      if (resp.status) {
       if(resp.result.length > 0 ){
            resp.result.forEach(scrip => {
              this.scripAlertData.forEach(scripAlert => {
                if(scripAlert.mktSegId == scrip.nMarketSegmentId  &&  scripAlert.token == scrip.nToken){
                  scripAlert.scripObj = scrip;
                  scripAlert.displayScripDesc = clsTradingMethods.formatScripDesc(scrip.nExpiryDate , scrip.sInstrumentName, scrip.sOptionType  , scrip.nStrikePrice )
                }
              });
            });
        }
      } else {
        
      }
    })
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'loadScripDetailsForAlerts', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'loadScripDetailsForAlerts',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createScripAlertsData() {
    try{
      this.filterScripAlertData = this.scripAlertData.filter((alert:any)=> { return alert.triggered ==1}); 
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'createScripAlertsData', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'createScripAlertsData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createBroadcastforscripAlerts() {
    try{
      this.sendTouchlineRequest(OperationType.REMOVE, this.scripAlertKeys);
      for (let index = 0; index < this.scripAlertData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.scripAlertData[index].token;
        objScrpKey.MktSegId = this.scripAlertData[index].mktSegId;

        this.scripAlertKeys.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.scripAlertKeys);
       clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.scripAlertKeys);
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'createBroadcastforscripAlerts', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'createBroadcastforscripAlerts',error.Message,undefined,error.stack,undefined,undefined));
    }
   
  }


  loadScripDetails() {
    try {

      //let iCnt = 0;
      let arrScrip = [];
      let uniqueTokenList: Dictionary<string> = new Dictionary<string>();
      for (let index = 0; index < this.recoData.length; index++) {
         let _key = this.recoData[index].nMarketSegmentId + "$" + this.recoData[index].nToken;
        if (!uniqueTokenList.ContainsKey(_key)) {
          uniqueTokenList.Add(_key, "exists");
          const element = this.recoData[index];
          let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId);
          let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
          arrScrip.push({ "mkt": exchange, "token": element.nToken });
          // let scripdetail = {
          //   scrips: [{
          //     mkt: exchange, //clsTradingMethods.getApiExchangeName(this.marketsegmentid),
          //     token: element.nToken
          //   }]
        }
      } 
          
        if (arrScrip.length > 0) {

          let req = { scrips: arrScrip };
            clsTradingMethods.getScripInfoElasticSearch(req, this.http).then((resp: any) => {
              if (resp.status == true) {
                if (resp != undefined && resp.result.length > 0) { 
                  for (let index = 0; index < resp.result.length; index++) {  
                    let scripObject: any;
                    let element =resp.result[index];// data.ResponseObject.resultset[0];
                    let token: string = "", mktSegId: number;
                  // if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
                      token = element.nToken;//ScripData_NSE.ODINCode;
                      mktSegId = element.nMarketSegmentId;//ScripData_NSE.MarketSegmentId;
                      let objScrpKey: clsScripKey = new clsScripKey();
                      objScrpKey.MktSegId = mktSegId;//clsTradingMethods.GetMarketSegmentID(mktSegId);
                      objScrpKey.token = token;
                      scripObject = this.recoData.filter(x => x.nMarketSegmentId == objScrpKey.MktSegId && x.nToken == objScrpKey.token);
                    //}
                      if(scripObject != undefined){

                        scripObject.forEach(elementScrip => {
                          //element.scripNews.push(newsDetail);
                          elementScrip.scripObj = resp.result[index];
                          elementScrip.scripObj.symbol=resp.result[index].sSymbol;
                          elementScrip.scripObj.ExpiryDate =  resp.result[index].nExpiryDate1 == ''? 'NA' :  resp.result[index].nExpiryDate1 ;
                          elementScrip.scripObj.StrikePrice = resp.result[index].nStrikePrice1 == ''? 'NA' : resp.result[index].nStrikePrice1;
                          elementScrip.scripObj.InstrumentName=resp.result[index].sInstrumentName;
                          elementScrip.scripObj.OptionType = resp.result[index].sOptionType == ''? 'NA' : resp.result[index].sOptionType ;
                          elementScrip.expiry= resp.result[index].nExpiryDate1 ==0? "" :resp.result[index].nExpiryDate1;
                          elementScrip.strikeprice = resp.result[index].nStrikePrice1;// == 0 ? '':resp.result[0].nStrikePrice1;
                          elementScrip.sOptionType = resp.result[index].sOptionType;

                        });
                        // this.recoData[index].scripObj = resp.result[0];
                        // this.recoData[index].expiry= resp.result[0].nExpiryDate1 ==0? "" :resp.result[0].nExpiryDate1;
                        // this.recoData[index].strikeprice = resp.result[0].nStrikePrice1;
                        // this.recoData[index].sOptionType = resp.result[0].sOptionType;
                      }
                  }    
                }
              }
            }).catch(error => {
              //this.toastCtrl.showAtBottom("Unable to open Order Entry");
              //clsGlobal.logManager.writeErrorLog('recommendationPage', 'loadProfileDetails', error.message);
              clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'loadProfileDetails',error.Message,undefined,error.stack,undefined,undefined));
              
            });
        } 
       
      
      
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('recommendationPage', 'loadProfileDetails', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'loadProfileDetails2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showOrderEntry(item){
    try { 
      /**
       
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = item.scripObj.nMarketSegmentId;//key.MktSegId;
      currScrip.scripDet.token = item.scripObj.nToken;//key.token;
      currScrip.symbol = item.scripObj.sSymbol;
      currScrip.Series = item.scripObj.sSeries; 
      currScrip.InstrumentName = item.scripObj.sInstrumentName;
      currScrip.ExpiryDate = item.scripObj.nExpiryDate1;
      currScrip.StrikePrice = item.scripObj.nStrikePrice1 || "-1";
      currScrip.OptionType = item.scripObj.sOptionType || "NA";
      currScrip.MarketLot = item.scripObj.nRegularLot || 1;
      currScrip.PriceTick = item.scripObj.nPriceTick || 1;
      * 
       */
      let currScrip = clsCommonMethods.getScripObject(item.scripObj).scripDetail;
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      
      for(let index = 1 ; index < clsGlobal.User.productTypesList.length; index++){
        if(clsGlobal.User.productTypesList[index] == "BRACKET"){
          this.isBracketAllowed = true;
        }
        if(clsGlobal.User.productTypesList[index] == "COVER"){
          this.isCoverAllowed = true;
        }
      }

      if (item.sRecoDetails[0].nBuySell.toUpperCase() == clsConstants.C_S_ORDER_BUY_TEXT) {
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyPrice = item.sRecoDetails[0].EnteredPrice;
      
      }
      else {
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.sellPrice = item.sRecoDetails[0].EnteredPrice;
      }
      objOEFormDetail.orderPrice = item.sRecoDetails[0].EnteredPrice;
      let  productType = clsGlobal.User.userPreference == undefined || clsGlobal.User.userPreference.sOrder == null || clsGlobal.User.userPreference.sOrder == undefined ? "INTRADAY": JSON.parse(clsGlobal.User.userPreference.sOrder).productType;//orderPref;//"intraday";// added by sonali
      
      if(item.sRecoDetails[0].SLPrice!= "" && item.sRecoDetails[0].SQPrice == ""){
        objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;//clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT//"sl-mkt";//cover
        objOEFormDetail.recoSQprice =0; //item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = item.sRecoDetails[0].SLPrice;
        if( this.isCoverAllowed){
          objOEFormDetail.productType = "COVER";
        }else{
          objOEFormDetail.productType = productType;
        } 
      }
      else if(item.sRecoDetails[0].SLPrice!= "" && item.sRecoDetails[0].SQPrice != ""){
        if(item.sRecoDetails[0].EnteredPrice != "0"){
          objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;//C_S_ORDER_REGULARLOT_TEXT;//"rl";//bracket 
        }
        else{
          objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
        }
          objOEFormDetail.recoSQprice = item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = item.sRecoDetails[0].SLPrice;
        if( this.isBracketAllowed){
          objOEFormDetail.productType = "BRACKET";
        }else{
          objOEFormDetail.productType = productType;
        }
      }
      else {
        objOEFormDetail.recoSQprice = 0;//item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = 0;//item.sRecoDetails[0].SLPrice;
        objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT; //"rl";//normal
      
        if(productType == "DELIVERY" && (item.exchange == clsConstants.C_S_NSE_DERV_API || item.exchange == clsConstants.C_S_BSE_DERV_API 
          || item.exchange == clsConstants.C_S_MCX_DERV_API || item.exchange == clsConstants. C_S_ICEX_DERV_API 
          || item.exchange == clsConstants.C_S_NCDEX_DERV_API) ){
            objOEFormDetail.productType = "CARRYFORWARD";
          }
          else{
            objOEFormDetail.productType = productType;
          }
      }
      
      

      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;
      //objOEFormDetail.
     
      objOEFormDetail.scripDetl = currScrip;
      objOEFormDetail.pageSource = clsConstants.C_V_RECOMMENDATION_PAGE;
      objOEFormDetail.recoId = item.sRecoDetails[0].sRecoId;
      this.navParams.myParam = objOEFormDetail;
      this.navCtrl.navigateForward('orderentry');
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to open order entry, kindly contact administrator.");
      //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showOrderEntry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkMarketSegmentForNews(mktSegId: any) {
    try{
      let _isEquity = false;
      try {
        switch (parseInt(mktSegId)) {
          case clsConstants.C_V_MAPPED_NSE_CASH:
          case clsConstants.C_V_MAPPED_BSE_CASH:
            _isEquity = true;
            break;
          default:
            break
        }
      }
      catch (erro) {

      }
      finally {
        return _isEquity;
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'checkMarketSegmentForNews', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'checkMarketSegmentForNews',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getScripNews(mktSegId: any, token: any, count: any, recoId: any) {
    try {

      let exchangeName = clsTradingMethods.getApiExchangeName(mktSegId);;
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {

          //for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
          let trendingScrip: any;
          let element = data.ResponseObject.resultset[0];
          let token: string = "", mktSegId: number;
          if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
            token = element.ScripData_NSE.ODINCode;
            mktSegId = element.ScripData_NSE.MarketSegmentId;
            let objScrpKey: clsScripKey = new clsScripKey();
            objScrpKey.MktSegId = mktSegId;//clsTradingMethods.GetMarketSegmentID(mktSegId);
            objScrpKey.token = token;
            trendingScrip = this.recoData.filter(x => x.nMarketSegmentId == objScrpKey.MktSegId && x.nToken == objScrpKey.token && x.scripNews.length == 0);
          } 
          if ((trendingScrip == null || trendingScrip == undefined || trendingScrip.length == 0) && (element.ScripData_BSE != undefined && element.ScripData_BSE != "-")) {
            token = element.ScripData_BSE.ODINCode;
            mktSegId = element.ScripData_BSE.MarketSegmentId;
            let objScrpKey: clsScripKey = new clsScripKey();
            objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
            objScrpKey.token = token;
            trendingScrip = this.recoData.filter(x => x.nMarketSegmentId == objScrpKey.MktSegId && x.nToken == objScrpKey.token && x.scripNews.length == 0);
          }

          //if (this.recoData.scripObj.ContainsKey(objScrpKey.toString())) {
          //trendingScrip = this.recoData.filter(x => x.scropObj.scripDetail.scripDet.MktSegId == objScrpKey.MktSegId && x.scropObj.scripDetail.scripDet.token == objScrpKey.token);
          if (trendingScrip != undefined) {
            for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
              let newsDetail: any = {};
              let element = data.ResponseObject.resultset[index];
              newsDetail.heading = element.Heading.trim();
              //console.log("newsDetail.heading.length"+ index+"  " +newsDetail.heading.length);
              newsDetail.details = element.ArtText.trim();
              newsDetail.CompanyCode = element.CompanyCode.trim();
             // newsDetail.date = element.Date.trim();
              let dateTimeValue = element.Date.trim();//item.date;
              
              let dateValue = new Date(dateTimeValue).toDateString().split(' ');
              let timeValue = new Date(dateTimeValue).toLocaleTimeString().split(' ');
              let timeMinHr = timeValue[0].split(":");
              newsDetail.date = dateValue[2] + " " + dateValue[1] + ", " + timeMinHr[0]+"."+timeMinHr[1] + " " +timeValue[1].toLowerCase();
              newsDetail.Count = index;
              this.depthRecoNewsDetails.push(newsDetail);
              trendingScrip.forEach(element => {
                element.scripNews.push(newsDetail);
              });
            }
          }
        }
      }).catch(error => {
        //clsGlobal.logManager.writeErrorLog('recommendation', 'getScripNews_1', error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getScripNews_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('recommendation', 'getScripNews_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getScripNews_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getScripObject(MktSegId, token) {
    try{
      let objScrpKey = new clsScripKey();
      objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(MktSegId);
      objScrpKey.token = token;
      let objScrip = new clsScrip();
      objScrip.scripDet = objScrpKey;
      objScrip.symbol = "";
      objScrip.MarketLot = 1; 
      objScrip.PriceTick = 1;
      objScrip.DecimalLocator = "100";
      objScrip.formatScripDisplayName();
      let idData = new clsIndexDetail();
      idData.scripDetail = objScrip;
      return idData;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getScripObject', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getScripObject',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  convertXmlToJson(sRecoDetails) {
    try{
      let json = [];

      xml2js.parseString(sRecoDetails, function (err, result) {
        for (let i = 0; i < result.RecoDetails.RecoChild.length; i++) {
          let data: any = result.RecoDetails.RecoChild[i].$
          
          data.nBuySell = data.nBuySell == "1" ? "Buy" : "Sell";
          data.targetPrice =  data.SQPrice == '' ? 'ND' : parseFloat(data.SQPrice); 
          data.SLprice = data.SLPrice == '' ? 'ND' : parseFloat(data.SLPrice);
          data.buyExit = data.nBuySell;// == 'Buy' ? 'Buy' : 'Exit';
          let str1 = data.sSubTypes;
          let m = str1.search("Long");
          if(m != -1){
            data.subTypes = str1.replace("Long", "Buy");
          }
          
          let str2 = data.sSubTypes;
          let n = str2.search("Short");
          if(n != -1){
            data.subTypes = str2.replace("Short", "Sell");
          }
          json.push(data);
        }

      });
      return json;
    }catch(error){
      // clsGlobal.logManager.writeErrorLog('RecommendationPage', 'convertXmlToJson', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'convertXmlToJson',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

//Alert Scrip  filter and Search START 

  getAlertFiltersCount() {
    try{
      return Object.keys(this.scripAlertFilterObject).length;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getAlertFiltersCount', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getAlertFiltersCount',error.Message,undefined,error.stack,undefined,undefined));
       
    }
  }

  showScripAlertFilter() {
    try{
      this.scripAlertFilterPopup = true;
      this.checkForAlertScripFilterPopupUpElementRendrer();
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showScripAlertFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showScripAlertFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setAlertScripFilter(filterName: any, filterValue: any) {
    try{
      switch (filterName) {
        case 'category':
          this.scripAlertFilterObject.category = filterValue;
          break;
        case 'alertType':
          this.scripAlertFilterObject.alertType = filterValue;
          break;
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'setAlertScripFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'setAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getAlertScripFiltersCount() {
    try{
      return Object.keys(this.scripAlertFilterObject).length;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getAlertScripFiltersCount', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getAlertScripFiltersCount',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  removeAlertScripFilter(filterName: any) {
    try{
      switch (filterName) {
        case 'category':
          delete this.scripAlertFilterObject.category
          break;
        case 'alertType':
          delete this.scripAlertFilterObject.alertType;
          break;
      }

      console.log(this.scripAlertFilterObject)

      if (this.getAlertScripFiltersCount() == 0) {
        this.clearScripAlertFilter();
      } else {
        this.applyAlertScripFilter();
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'removeAlertScripFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'removeAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForAlertScripFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divScripAlertFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForAlertScripFilterPopupUpElementRendrer();
        }, 100);
      } else {

        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divScripAlertFilterPopup');
          this.alertScripFilterPopupBottomToTop(divElement);
        }, 200);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'checkForAlertScripFilterPopupUpElementRendrer', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'checkForAlertScripFilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
      }
  }

  alertScripFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (320), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop:true, //added by om on 26 th jan for backdrop display.
        onDidPresent: () => {
          //console.log("onDidPresent")
        }, 
        onDrag: () => {
          //  //console.log("onDrag");
        },
        onDragEnd: () => {

          //console.log("onDragEnd");
          let topDiv = this.divScripAlertFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedScripAlertFilter = true;
          } else {
            this.showExpandedScripAlertFilter = false;
          } 
        }, 
        onBackdropTap: ()=>{
          //added by omprakash on 24 th jan for backdrop click
          this.closeAlertScripFilterPopup();
        }
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends"); 
        //   //console.log("onTransitionEnd")
        // }
      }
      this.scripAlertFilterPane = new CupertinoPane(myElementRef, setting);
      this.scripAlertFilterPane.enableDrag();
      this.scripAlertFilterPane.present({ animate: true });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "alertScripFilterPopupBottomToTop", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'alertScripFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollAlertFilterDetails(event)
  {
    if (event.target.scrollTop > 20) {
      this.scripAlertFilterPane.moveToBreak('top');
      this.showExpandedScripAlertFilter  = true;
    }
  }  


  applyAlertScripFilter() {
    try{
      this.scripAlertFilterPopup = false;
      this.showExpandedScripAlertFilter = false;
      this.createScripAlertsData();
      if (this.filterScripAlertData.length > 0) {
        if (this.scripAlertFilterObject.alertType) {
          this.filterScripAlertData = this.filterScripAlertData
            .filter(x => x.data.alertType == this.scripAlertFilterObject.alertType)
        }
        if (this.scripAlertFilterObject.category) {
          this.filterScripAlertData = this.filterScripAlertData
            .filter(x => x.data.category == this.scripAlertFilterObject.category)
        }
      }
      this.createBroadcastforscripAlerts();
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'applyAlertScripFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'applyAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closeAlertScripFilterPopup() {
    try{
      this.scripAlertFilterPopup = false;
      this.showExpandedScripAlertFilter = false;
      this.scripAlertFilterPane.destroy({ animate: true });
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'closeAlertScripFilterPopup', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'closeAlertScripFilterPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearScripAlertFilter() {
    try {
  
      this.scripAlertFilterPopup = false;
      this.scripAlertFilterObject = {};
      this.showExpandedScripAlertFilter = false;
      this.createScripAlertsData();
      this.createBroadcastforscripAlerts();
      } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "clearScripAlertFilter", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'clearScripAlertFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
   
  showSearchPopupScripAlert() {
    try{
      this.searchTextScripAlert = '';
      this.showSearchScripAlert = true;
      this.scripAlertSearchData = [];
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showSearchPopupScripAlert', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showSearchPopupScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  hideSearchPopupScripAlert() {
    try{
      this.showSearchScripAlert = false;
      this.searchTextScripAlert = '';
      this.scripAlertSearchData = [];
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'hideSearchPopupScripAlert', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'hideSearchPopupScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  searchScripAlert($event) {
    try{
      if ($event) {
        this.searchTextScripAlert = $event.toUpperCase();
        this.searchTextChangedScripAlert.next($event);
      } else {
        this.scripAlertSearchData = [];
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'searchScripAlert', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'searchScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getValuesScripAlert(search) {
    try {

      this.scripAlertSearchData = [];

      if (search.length < 1) {
        this.searchTextEnteredScripAlert = '';
        return;
      }
      this.searchTextEnteredScripAlert = search.toUpperCase();
      //console.log(this.searchTextEnteredScripAlert)

      this.scripAlertSearchData = this.scripAlertData
        .filter((alert:any)=>  ( alert.triggered ==1 && alert.data.symbol.toUpperCase().trim().includes(this.searchTextEnteredScripAlert)));
        console.log(this.scripAlertSearchData)
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getValuesScripAlert', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getValuesScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchScripAlert() {
    try{
      this.searchTextScripAlert = '';
      this.scripAlertSearchData = [];
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'clearSearchScripAlert', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'clearSearchScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  
  convertPriceToRupee(rPrice, intMktSegId){
    return clsTradingMethods.convertToRupees(rPrice, intMktSegId,0)
  }

  //Alert Scrip  filter and Search END 
//Reco Filter And Search START 


  
  //Reco Filter And Search START 


  showRecoFilter() {
    try{
      this.recoFilterPopup = !this.recoFilterPopup;
      this.checkForRecoFilterPopupUpElementRendrer();
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showRecoFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showRecoFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //class select filter
  setRecoFilter(filterName: any, filterValue: any) {
    try{
      switch (filterName) {
        case 'transactionType':
          this.recoFilterObject.transactionType = filterValue;
          break;
        case 'recoTags':
          this.recoFilterObject.recoTags = filterValue;
          break;
        // case 'productType':
        //   this.recoFilterObject.productType = filterValue;
        //   break;
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'setRecoFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'setRecoFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getrecoFiltersCount() {
    return Object.keys(this.recoFilterObject).length;
  }

  removeRecoFilter(filterName: any) {
    try{
      switch (filterName) {
        case 'transactionType':
          delete this.recoFilterObject.transactionType
          break;
        case 'recoTags':
          delete this.recoFilterObject.recoTags 
          break;
        // case 'productType':
        //   delete this.recoFilterObject.productType;
        //   break;
      }

      if (this.getrecoFiltersCount() == 0) {
        this.clearRecoFilter();
      } else {
        this.applyRecoSortFilter();
      }
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'removeRecoFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'removeRecoFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForRecoFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divRecoFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForRecoFilterPopupUpElementRendrer();
        }, 100);
      } else {

        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divRecoFilterPopup');
          this.recoFilterPopupBottomToTop(divElement);
        }, 200);
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "checkForRecoFilterPopupUpElementRendrer", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'checkForRecoFilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  recoFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (320), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop:true, //added by om on 26 th jan for backdrop display.
        onDidPresent: () => {
          //console.log("onDidPresent")
        }, 
        onDrag: () => {
          //  //console.log("onDrag");
        },
        onDragEnd: () => {

          //console.log("onDragEnd");
          let topDiv = this.divRecoFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedRecoFilter = true;
          } else {
            this.showExpandedRecoFilter = false;
          } 
        }, 
        onBackdropTap: ()=>{
          //added by omprakash on 24 th jan for backdrop click
          this.closeRecoFilterPopup();
        } 
      }
      this.recoFilterPane = new CupertinoPane(myElementRef, setting);
      this.recoFilterPane.enableDrag();
      this.recoFilterPane.present({ animate: true });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "recoFilterPopupBottomToTop", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'recoFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

   //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollRecoFilterDetails(event)
  {
    if (event.target.scrollTop > 20) {
      this.recoFilterPane.moveToBreak('top');
      this.showExpandedRecoFilter  = true;
    }
  }

  applyRecoSortFilter() {
    try{
      this.isFilterApply = true;
      this.recoFilterPopup = false;
      //this.recoData = this.filterRecoData;
      this.filterRecoData =this.recoData;
      if (this.recoData.length > 0) {
        if (this.recoFilterObject.transactionType) {
          this.filterRecoData = this.filterRecoData
            .filter(x => x.transaction_type == this.recoFilterObject.transactionType)
        }
        if (this.recoFilterObject.recoTags) {
          this.filterRecoData = this.filterRecoData
            .filter(x => x.sRecoTag == this.recoFilterObject.recoTags)
        }
        // if (this.recoFilterObject.productType) {
        //   this.filterRecoData = this.filterRecoData
        //     .filter(x => x.product_type == this.recoFilterObject.productType)
        // }
      }
      this.recoCount = this.filterRecoData.length;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'applyRecoSortFilter', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'applyRecoSortFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closeRecoFilterPopup() {
    try{
      this.recoFilterPopup = false;
      this.showExpandedRecoFilter = false;
      this.recoFilterPane.destroy({ animate: true });
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'closeRecoFilterPopup', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'closeRecoFilterPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearRecoFilter() {
    try {
      this.isFilterApply = false;
      this.recoFilterPopup = false;
      this.recoFilterObject = {};
      this.showExpandedRecoFilter = false;
      this.filterRecoData= this.recoData; 
      this.recoCount = this.filterRecoData.length;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "clearRecoFilter", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'clearRecoFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  
  showSearchPopupReco() {
    try{
      this.searchTextReco = '';
      this.showSearchReco = true;
      this.recoSearchData = [];//this.recoData; //[];
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showSearchPopupReco', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showSearchPopupReco',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  searchTextEnter(){
    if(this.searchTextReco.length > 0 ){
      this.showSegments = true;
    }else{
      this.showSegments = false;
    }
  }

  hideSearchPopupReco() {
    try{
      this.showSearchReco = false;
      this.searchTextReco = '';
      this.recoSearchData = [];
      this.showSegments = false;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'hideSearchPopupReco', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'hideSearchPopupReco',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  searchReco(event) {
    try{
      if (event) {
        this.searchTextReco = event.toUpperCase();
       // this.searchTextChangedReco.next(event);
       } 
      this.searchTextChangedReco.next(event);
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'searchReco', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'searchReco',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getValuesReco(search) {
    try {
     
      if(search == '')
      {
        this.clearSearchReco();
        return; 
      }
      
      if (search.length < 1) {
        this.searchTextEnteredReco = '';
        return;
      }
      this.searchTextEnteredReco = search.toUpperCase();
       let recoSearchList = [];
      for (let counter = 0; counter < this.recoData.length; counter++) {
        if(this.recoData[counter].scripObj){
          let Symbol = this.recoData[counter].scripObj.sSymbol.toUpperCase().trim();
          if (Symbol.startsWith(this.searchTextEnteredReco)) {
            recoSearchList.push(this.recoData[counter]);
          }
        }  
      }
      this.recoSearchData = recoSearchList;
      // this.recoSearchData = this.recoData.filter(x => ( x.scripObj.sSymbol.toUpperCase().trim().startsWith(this.searchTextEnteredReco)));
      if(this.recoSearchData.length == 0)
      { 
        this.noDataFoundRecoSearch = true;
        this.recoSearchData = []
        return;
      }
      //this.recoSearchData = recoSearchList;
      this.showSegments = true;
      

    }catch(error){
      
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getValuesReco', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'getValuesReco',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchReco() {
    try{
      this.searchTextReco = '';
      this.recoSearchData = [];//this.recoData;//[];
      this.showSegments = false;
      this.noDataFoundRecoSearch = false;
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'clearSearchReco', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'clearSearchReco',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



  

  //Reco Filter And Search  END 

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('RecommedationPage', 'sendTouchlineRequest', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
     
      let nFormat = 2;
      if (objMultiTLResp != null) {

        if (this.filterScripAlertData.length > 0) {
          this.filterScripAlertData.forEach(scripAlertItem => {
            if (scripAlertItem.token == objMultiTLResp.Scrip.token && scripAlertItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = 2;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              scripAlertItem.LTP = objMultiTLResp.LTP
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              scripAlertItem.NetChangeInRs = arrNetChange[0];
              scripAlertItem.PercNetChange = arrNetChange[1];
              scripAlertItem.LTPTrend = arrNetChange[2];
              scripAlertItem.arrowTrend = arrNetChange[3];}
          });
        }

        if (this.scripAlertSearchData.length > 0) {
          this.scripAlertSearchData.forEach(scripAlertItem => {
            if (scripAlertItem.token == objMultiTLResp.Scrip.token && scripAlertItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = 2;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              scripAlertItem.LTP = objMultiTLResp.LTP
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              scripAlertItem.NetChangeInRs = arrNetChange[0];
              scripAlertItem.PercNetChange = arrNetChange[1];
              scripAlertItem.LTPTrend = arrNetChange[2];
              scripAlertItem.arrowTrend = arrNetChange[3];}
          });
        }

      
        
        if(this.filterRecoData.length > 0){
         let ltpScrip: any;
          this.filterRecoData.forEach(scripRecoItem =>{
            if(scripRecoItem.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId && scripRecoItem.nToken == parseFloat(objMultiTLResp.Scrip.token)){
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              scripRecoItem.ltp = parseFloat(objMultiTLResp.LTP);
              let recoEntryPrice =  parseFloat(scripRecoItem.sRecoDetails[0].EnteredPrice);
              let calSLPrice = recoEntryPrice - ((recoEntryPrice*10)/100);
              let calSQPrice = recoEntryPrice + ((recoEntryPrice*10)/100);
              let recoSLPrice =scripRecoItem.sRecoDetails[0].SLPrice == '' ? calSLPrice : parseFloat(scripRecoItem.sRecoDetails[0].SLPrice);
              let recoSQPrice = scripRecoItem.sRecoDetails[0].SQPrice == '' ? calSQPrice : parseFloat(scripRecoItem.sRecoDetails[0].SQPrice);
              let recoLTP =  parseFloat(scripRecoItem.ltp);

              scripRecoItem.graphValue =[              
              {
                "value": recoEntryPrice,
                "color": "A",
                "lable": "EntyrPrice"},
                {
                "value": recoSLPrice,
                "color": "A",
                "lable": "SLPrice"
                },
                {
                "value": recoSQPrice,
                "color": "A",
                "lable": "TargetPrice"
                },
                {
                "value": recoLTP,
                "color": "A",
                "lable": "LTP"
              }].sort((n1,n2) => n1.value - n2.value) 
              
              scripRecoItem.dualKnob ={lower :scripRecoItem.graphValue[1].value  , upper : scripRecoItem.graphValue[2].value };
              scripRecoItem.minValue = scripRecoItem.graphValue[0].value; //== 0 ? 'ND' : scripRecoItem.graphValue[0].value;== 0 ? 'ND' :scripRecoItem.graphValue[1].value
              scripRecoItem.maxValue = scripRecoItem.graphValue[3].value; //== 0 ? 'ND' :scripRecoItem.graphValue[3].value; == 0 ? 'ND' :scripRecoItem.graphValue[2].value

            }
          }) 
         //this.filterRecoData = this.recoData;
        }

        if(this.recoSearchData.length > 0){
         // let ltpScrip: any;
            this.recoSearchData.forEach(scripRecoItem =>{
              if(scripRecoItem.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId && scripRecoItem.nToken == parseFloat(objMultiTLResp.Scrip.token)){
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                scripRecoItem.ltp = parseFloat(objMultiTLResp.LTP);
                let recoEntryPrice =  parseFloat(scripRecoItem.sRecoDetails[0].EnteredPrice);
                let calSLPrice = recoEntryPrice - ((recoEntryPrice*10)/100);
                let calSQPrice = recoEntryPrice + ((recoEntryPrice*10)/100);
                let recoSLPrice =scripRecoItem.sRecoDetails[0].SLPrice == '' ? calSLPrice : parseFloat(scripRecoItem.sRecoDetails[0].SLPrice);
                let recoSQPrice = scripRecoItem.sRecoDetails[0].SQPrice == '' ? calSQPrice : parseFloat(scripRecoItem.sRecoDetails[0].SQPrice);
                let recoLTP =  parseFloat(scripRecoItem.ltp);

                scripRecoItem.graphValue =[              
                {
                  "value": recoEntryPrice,
                  "color": "A",
                  "lable": "EntyrPrice"},
                  {
                  "value": recoSLPrice,
                  "color": "A",
                  "lable": "SLPrice"
                  },
                  {
                  "value": recoSQPrice,
                  "color": "A",
                  "lable": "TargetPrice"
                  },
                  {
                  "value": recoLTP,
                  "color": "A",
                  "lable": "LTP"
                }].sort((n1,n2) => n1.value - n2.value) 
                
                scripRecoItem.dualKnob ={lower :scripRecoItem.graphValue[1].value  , upper : scripRecoItem.graphValue[2].value };
                scripRecoItem.minValue = scripRecoItem.graphValue[0].value; //== 0 ? 'ND' : scripRecoItem.graphValue[0].value;== 0 ? 'ND' :scripRecoItem.graphValue[1].value
                scripRecoItem.maxValue = scripRecoItem.graphValue[3].value; //== 0 ? 'ND' :scripRecoItem.graphValue[3].value; == 0 ? 'ND' :scripRecoItem.graphValue[2].value

              }
            }) 
         //this.filterRecoData = this.recoData;
        }
        
      }
    
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'receiveTouchlineResponse', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  openSettingPage(){
    try{
      this.showSelectpopup = false;
      this.navCtrl.navigateForward('settings');
    }catch(error){
       //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'openSettingPage', error.message);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'openSettingPage',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

 

  recoFollowUpShow(index,data){
   try{
    //this.recoData[index].selctedReco = true;
    if(data=='filter'){
      this.filterRecoData[index].selctedReco = true;
    }
    if(data== "search"){
      this.recoSearchData[index].selctedReco = true;
    }
   }
   catch(error){
    //clsGlobal.logManager.writeErrorLog('RecommedationPage', 'recoFollowUpShow', error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'recoFollowUpShow',error.Message,undefined,error.stack,undefined,undefined));
   }
  }

  recoFollowUpHide(index,data){
    try{
      //this.recoData[index].selctedReco = false;
      if(data=='filter'){
        this.filterRecoData[index].selctedReco = false;
      }
      if(data== "search"){
        this.recoSearchData[index].selctedReco = false;
      }
    }
    catch(error){
      //clsGlobal.logManager.writeErrorLog('RecommedationPage', 'recoFollowUpHide', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'recoFollowUpHide',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showRecoFile(url){
    try{
      window.open(url);
     
    }
    catch(error){
      //clsGlobal.logManager.writeErrorLog('RecommedationPage', 'showRecoFile', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RecommendationPage', 'showRecoFile',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //reco voice serach

  checkVoiceString: any;
  ShowVoiceModel() {
    this.searchTextReco = '';

    this.checkVoiceString = '';
    this.speechRecognition.isRecognitionAvailable().then((available: boolean) => {
      if (available) {
        this.speechRecognition.hasPermission()
          .then((hasPermission: boolean) => {
            if (hasPermission)
              this.VoiceStartListening();
            else {
              this.speechRecognition.requestPermission()
                .then(
                  () => {
                    console.log('Granted');
                    this.VoiceStartListening();
                  },
                  () => {
                    console.log('Denied');
                    this.toastCtrl.showAtBottom("you need to give permission for voice.");
                  }
                )


            }
          });
      }
      else {
        this.toastCtrl.showAtBottom("microphone not available.");
      }
    });
  }

  VoiceStartListening() {
    if (this.platform.is('android')) {
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            this.searchReco(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            console.log("Error" + onerror);
          }
        );
    }
    else {
      this.loadingCtrl.showLoaderforText();
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            //alert("String "+matches[0].toString())
            this.loadingCtrl.hideLoaderforText();
            this.checkVoiceString = matches[0].toString();
            this.searchReco(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //alert("Error "+onerror)
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            this.loadingCtrl.hideLoaderforText();
            console.log("Error" + onerror);
          }
        );
      setTimeout(() => {
        this.loadingCtrl.hideLoaderforText();
        this.speechRecognition.stopListening();
        setTimeout(() => {
          if (this.checkVoiceString == '' || this.checkVoiceString == undefined) {
            this.toastCtrl.showAtBottom("Voice not captured. Try saying something again")
          }
        }, 1000)
      }, 3000);
    }

  }

  // searchVoiceText(text) {
  //   if (text != undefined || text != '') {
  //     this.searchTextReco = text.toUpperCase().trim();
  //     this.searchTextChangedReco.next(this.searchTextReco);
  //     // this.recentlySearched = false;
  //     // this.showTrending = false;
  //     // this.showRecommendations = false;
  //   } else {
  //     this.loadRecentScripts();
  //     this.getHotpursuitData();
  //   }
  // }
  VoiceHasPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        return hasPermission;
      });
  }

  voiceSearchMaching(text: any) {
    var _text = text.toString().toUpperCase().trim();
    _text = _text.replace("JANUARY", "JAN").
      replace("FEBRUARY", "FEB").
      replace("MARCH", "MAR").
      replace("APRIL", "APR").
      replace("JUNE", "JUN").
      replace("JULY", "JUL").
      replace("AUGUST", "AUG").
      replace("SEPTEMBER", "SEP").
      replace("OCTOBER", "OCT").
      replace("NOVEMBER", "NOV").
      replace("DECEMBER", "DEC").
      replace("FUTURES", "FUT").
      replace("FUTURE", "FUT").
      replace("OPTIONS", "OPT").
      replace("OPTION", "OPT");
    return _text.toUpperCase();
  }
}
