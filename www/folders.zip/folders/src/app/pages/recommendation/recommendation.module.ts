import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecommendationPageRoutingModule } from './recommendation-routing.module';

import { RecommendationPage } from './recommendation.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,ComponentsModule,
    RecommendationPageRoutingModule
  ],
  declarations: [RecommendationPage]
})
export class RecommendationPageModule {}
