import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EDISPermissionPageRoutingModule } from './e-dis-permission-routing.module';

import { EDISPermissionPage } from './e-dis-permission.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EDISPermissionPageRoutingModule,
    ComponentsModule
  ],
  declarations: [EDISPermissionPage]
})
export class EDISPermissionPageModule {}
