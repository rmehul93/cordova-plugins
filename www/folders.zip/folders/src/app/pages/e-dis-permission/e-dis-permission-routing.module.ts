import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EDISPermissionPage } from './e-dis-permission.page';

const routes: Routes = [
  {
    path: '',
    component: EDISPermissionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EDISPermissionPageRoutingModule {}
