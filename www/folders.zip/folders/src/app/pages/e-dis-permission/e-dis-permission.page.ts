import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-e-dis-permission',
  templateUrl: './e-dis-permission.page.html',
  styleUrls: ['./e-dis-permission.page.scss'],
})
export class EDISPermissionPage implements OnInit {

  constructor(private alertProvider: AlertServicesProvider,
    private navCtrl: NavController,
    private toastCtrl: ToastServicesProvider) { }

  ngOnInit() {
    
  }

  

}
