import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalController, NavController, PopoverController } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { WatchlistloaderPage } from '../watchlistloader/watchlistloader.page';

@Component({
  selector: 'app-watchlist-remove-reorder',
  templateUrl: './watchlist-remove-reorder.page.html',
  //styleUrls: ['./watchlist-remove-reorder.page.scss'],
})
export class WatchlistRemoveReorderPage implements OnInit {

  profileData: any;
  profileScrips = [];
  profileListScrip = [];
  sProfileName = "";
  removeScripCnt = 0;
  selProfileName = "";
  opType = "";
  isRemove = false;
  showExpandHeader: boolean = false;
  constructor(private navCtrl: NavController,
    public popoverController: PopoverController,
    private route: ActivatedRoute,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService,
    public alertCtrl: AlertServicesProvider,
    public toastProvider: ToastServicesProvider,
    public modalController: ModalController,
    private objHttpService: clsHttpService,
    public dateFormatter: DatePipe) {

  }
  ngOnInit() {
    this.profileData = this.route.snapshot.queryParams.profile || '';
    this.sProfileName = this.profileData.sWatchListName;
    //this.profileScrips = route.snapshot.queryParams.scripList;
    this.opType = this.route.snapshot.queryParams.type;
    this.isRemove = this.opType == 'REMOVE';
  }

  ionViewWillEnter() {
  try{
    this.watchlistServ.getWatchlistProfileScrip(this.profileData.nWatchListId, this.profileData.sCreatedBy).then((profileScripData: any) => {
      if (profileScripData != undefined) {
        this.profileScrips = profileScripData;
        this.loadProfileDetails();
      }
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'ionViewWillEnter', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  doReorder(ev: any) {

    //console.log('Dragged from index', ev.detail.from, 'to', ev.detail.to);
    this.profileListScrip = ev.detail.complete(this.profileListScrip);
    ev.detail.complete();
  }

  loadProfileDetails() {
    try {

      //let req;
      //let arrScrip = [];

      for (let index = 0; index < this.profileScrips.length; index++) {

        const element = this.profileScrips[index];

        this.profileListScrip.push({
          scripDetail: element,
          added: true
        });

        // let Token = element.nToken;
        // let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId || element.nMarketSegmentId)
        // let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

        // arrScrip.push({ "mkt": exchange, "token": Token });

        // this.dbService.getScripByToken(exchange, Token, element.nMarketSegmentId).then(scrip => {
        //   //console.log("Scrip Found: ", scrip);
        //   if (scrip[0] != undefined) {
        //     this.profileListScrip.push({
        //       scripDetail: scrip[0],
        //       added: true
        //     });
        //   }
        //   iCnt++;

        // }, error => {
        //   console.log("unable to find scrip: ", Token, " ", exchange);
        // });
      }

      /*
      req = { scrips: arrScrip };
      if (req != undefined) {
        clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

          if (scripData.status == true) {
            if (scripData != undefined && scripData.result.length > 0) {

              for (let index = 0; index < this.profileScrips.length; index++) {

                const element = this.profileScrips[index];
                let Token = element.nToken;
                let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId || element.nMarketSegmentId)
                let scripItem = scripData.result.filter(item => {
                  return mktSegId == clsTradingMethods.GetMarketSegmentID(parseInt(item.nMarketSegmentId)) &&
                    Token == item.nToken;
                })

                if (scripItem.length > 0) {
                  let selectedScripObj = clsCommonMethods.getScripObject(scripItem[0]).scripDetail;
                  if (selectedScripObj != undefined) {
                    this.profileListScrip.push({
                      scripDetail: selectedScripObj,
                      added: true
                    });
                  }
                }
              }
              // for (let index = 0; index < scripData.result.length; index++) {
              //   const element = scripData.result[index];
              //   //item.scripDetail = clsCommonMethods.getScripObject(element).scripDetail;
              //   this.profileListScrip.push({
              //     scripDetail: clsCommonMethods.getScripObject(element).scripDetail,
              //     added: true
              //   });
              // }
            }
          } else {
            //console.log("Unable to fetch scrip details: ", Token, " ", exchange);
            //return;
          }

        });
      }
      */
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'loadProfileDetails', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  removeScrip(scripItem, index) {
    try {

      scripItem.added = !scripItem.added;
      if (!scripItem.added)
        this.removeScripCnt++;
      else {
        this.removeScripCnt--;
      }

      if (this.removeScripCnt == this.profileListScrip.length) {
        this.toastProvider.showAtBottom("Cannot remove all scrip from profile.");
        scripItem.added = !scripItem.added;
        this.removeScripCnt--;
      }

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'removeScrip', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  async saveWatchlist() {
    try {

      if (this.removeScripCnt > 0) {

        let buttons: any = ['Yes', 'No']
        this.alertCtrl.showAlertConfirmWithButtons("Watchlist", "Are you sure you want to delete the selected scrip (s) ?", buttons,
        async () => {
            try {

              let statusUpdate = new BehaviorSubject("2");
              const modal = await this.modalController.create({
                component: WatchlistloaderPage,
                //cssClass: 'my-custom-class',
                componentProps: {
                  'status': statusUpdate,
                }
              });
              await modal.present();
              statusUpdate.next("2");

              let addedScrip = this.profileListScrip.filter(scrip => {
                return !scrip.added;
              });

              let selScrip = [];
              for (let index = 0; index < addedScrip.length; index++) {
                const element = addedScrip[index];
                selScrip.push({ MktSegId: parseInt(element.scripDetail.scripDet.MktSegId), Token: element.scripDetail.scripDet.token, SeqNo: (index + 1) });
              }

              let watclistObj: any = {};
              watclistObj.name = this.sProfileName;
              watclistObj.isFromTopPicks = false;
              watclistObj.profileId = this.profileData.nWatchListId;
              watclistObj.scrip = selScrip;
              watclistObj.source = "WAVE";

              let watchScrip = [];
              for (let index = 0; index < watclistObj.scrip.length; index++) {
                const element = watclistObj.scrip[index];
                watchScrip.push({
                  nWatchListId: this.profileData.nWatchListId,
                  nMarketSegmentId: clsTradingMethods.getMappedMarketSegmentId(element.MktSegId),
                  nToken: element.Token,
                  nSequenceNo: element.SeqNo,
                  sCreatedBy: this.profileData.sCreatedBy
                })
              }

              this.watchlistServ.deleteWatchlistScrip(watchScrip).then((data) => {

                statusUpdate.next("3");
                setTimeout(() => {
                  modal.dismiss().then(value => {
                    clsGlobal.reloadWatchlist = true;
                    this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                  });
                }, 500);

                //clsGlobal.reloadWatchlist = true;
                //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
              }, (error) => {
                //modal.dismiss()
              });

            } catch (error) {
              clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'saveWatchlist', error.Message, undefined, error.stack, undefined, undefined));
            }
          }, error => {
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'saveWatchlist2', error.Message, undefined, error.stack, undefined, undefined));
          });

      } else {

        let selScrip = [];
        for (let index = 0; index < this.profileListScrip.length; index++) {
          const element = this.profileListScrip[index];
          selScrip.push({ MktSegId: parseInt(element.scripDetail.scripDet.MktSegId), Token: element.scripDetail.scripDet.token, SeqNo: (index + 1) });
        }

        let watclistObj: any = {};
        watclistObj.name = this.sProfileName;
        watclistObj.isFromTopPicks = false;
        watclistObj.profileId = this.profileData.nWatchListId;
        watclistObj.scrip = selScrip;
        watclistObj.source = "WAVE";

        let watchScrip = [];
        for (let index = 0; index < watclistObj.scrip.length; index++) {
          const element = watclistObj.scrip[index];
          watchScrip.push({
            nWatchListId: this.profileData.nWatchListId,
            nMarketSegmentId: clsTradingMethods.getMappedMarketSegmentId(element.MktSegId),
            nToken: element.Token,
            nSequenceNo: element.SeqNo,
            sCreatedBy: this.profileData.sCreatedBy
          })
        }

        this.watchlistServ.reorderWatchListScrip(this.profileData.nWatchListId, watchScrip).then((data) => {
          clsGlobal.reloadWatchlist = true;
          this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);

        }, (error) => {
          //modal.dismiss()
        });
      }

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'saveWatchlist3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  goBack() {
    this.navCtrl.pop();
  }
  scrollContent(event) {
    try{
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    console.log(event);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistRemoveReorderPage', 'scrollContent', error.Message, undefined, error.stack, undefined, undefined));
  }
  }
  
}
