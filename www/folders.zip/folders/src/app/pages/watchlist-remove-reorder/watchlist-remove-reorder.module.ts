import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { WatchlistRemoveReorderPageRoutingModule } from './watchlist-remove-reorder-routing.module';

import { WatchlistRemoveReorderPage } from './watchlist-remove-reorder.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WatchlistRemoveReorderPageRoutingModule
  ],
  declarations: [WatchlistRemoveReorderPage]
})
export class WatchlistRemoveReorderPageModule {}
