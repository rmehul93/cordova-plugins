import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { clsTradingMethods } from './../../Common/clsTradingMethods';
import { Component, OnInit } from '@angular/core';
import { NavController, Platform } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from '../../Common/clsLocalStorageService';
import { clsConstants } from '../../Common/clsConstants';
//import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { AlertServicesProvider } from '../../providers/alert-services/alert-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { AppState } from 'src/app/app.global';  

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
})
export class SettingsPage implements OnInit {
  selExchange: string;
  confirmFingerPrint: any;
  callbackChnInProgress: boolean = false;
  isFingerAuthAvailable: boolean = false;
  fingetPrintStatus: boolean = false;
  fingetPrintStatusOriginal: boolean = false;
  mobile: string = '';
  mobileDisaply: any = '********';
  disableGenerate: boolean = true;
  showOtp: boolean = false;
  timerId: any;
  enableGenerate: boolean = false;
  generateOtpText = 'Generate OTP';
  userID: any;
  otp: any;
  maxInvalidOTPAttempt: number = 3;
  invalidOTPCnt: number = 0;
  disableSubmit: boolean = false;
  isFirstTime: boolean = false;
  emailId: string = '';
  timerStarted: boolean = false;
  timerValue: number = 0;
  isAndroid: boolean = false;
  ShowOTPConfirm: boolean = false;
  enterManualOTP: boolean = false;
  otpVerified: boolean = false;
  enableSubmit: boolean = false;
  enableVerifyOtp: boolean = false;
  otpErr: any = '';
  isFingerPrintSelected: boolean = false;
  mobile_udid: any = '';
  type: any;
  groupId: string = '';
  initDone: boolean = false;
  pageSource: string = "";
  currentTheme: any;
  exchangeAllowedArry: any = [];
  fcmTopicListPref: any;
  profilePicPref: any;
  inAppNotificationPref: any;
  orderPref: any;
  defaultType: any = "INTRADAY";
  protectionPerc: any = 0;


  constructor(private navCtrl: NavController,
    private clsLocalStorage: clsLocalStorageService,
    private alertObj: AlertServicesProvider,
    private toastCtrl: ToastServicesProvider,
    //private faio: FingerprintAIO,
    private http: clsHttpService,
    private authService: AuthenticationService,
    private paramService: NavParamService,
    private platform: Platform,
    private global: AppState,
    private appSync: AppsyncDbService) {

  }
  ngOnInit() {
    try {
      clsGlobal.logManager.writeUserAnalytics("SettingsPage", "", "VISIT", "");
      this.getExchange();
      this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_THEME)
        .then((item: any) => {
          if (item != undefined && item != 'undefined') {
            //const theme: any = JSON.parse(item);
            this.currentTheme = item;
          } else {
            this.currentTheme = clsGlobal.defaultTheme;
          }
        }, error => {
        // console.log('Error in getting local storage theme.' + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
        });
      this.userID = clsGlobal.User.userId;
      this.groupId = clsGlobal.User.groupId;
      //this.verifyFingerPrintAvalOnDevice();
    } catch (error) {
      //console.log('Error in getting local storage theme.' + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ngOnInit2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillEnter() {
    try {
      this.pageSource = this.paramService.myParam;
      this.verifyFingerPrintAvalOnDevice();
      if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != "" && clsGlobal.User.userPreference != null) {
        this.orderPref = clsGlobal.User.userPreference.sOrder;
        this.fcmTopicListPref = clsGlobal.User.userPreference.sNotification;
        this.profilePicPref = clsGlobal.User.userPreference.sProfilePicPath;
        this.inAppNotificationPref = clsGlobal.User.userPreference.sInAppNotification
        if (clsGlobal.User.userPreference.sOrder != "" && clsGlobal.User.userPreference.sOrder != undefined && clsGlobal.User.userPreference.sOrder != null) {
          this.protectionPerc = JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc == "" ? 0.00 : JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc;
          this.defaultType = JSON.parse(clsGlobal.User.userPreference.sOrder).productType == "" ? this.defaultType : JSON.parse(clsGlobal.User.userPreference.sOrder).productType;
        }
        if (clsGlobal.User.userPreference.sExchange != null || clsGlobal.User.userPreference.sExchange != undefined || clsGlobal.User.userPreference.sExchange != "") {
          let userPref = JSON.parse(clsGlobal.User.userPreference.sExchange);
          this.exchangeAllowedArry.filter(x => {
            if (x.exchangeDesc == userPref.exchangeDesc) {
              x.selected = userPref.selected;
            }
          })
        }
      } else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            this.orderPref = res[0].sOrder;
            this.fcmTopicListPref = res[0].sNotification;
            this.profilePicPref = res[0].sProfilePicPath;
            this.inAppNotificationPref = res[0].sInAppNotification;
            if (this.orderPref != null && this.orderPref != "" && this.orderPref != undefined) {
              this.protectionPerc = JSON.parse(res[0].sOrder).protectionPerc == "" ? 0.00 : JSON.parse(res[0].sOrder).protectionPerc;
              this.defaultType = JSON.parse(res[0].sOrder).productType == "" ? this.defaultType : JSON.parse(res[0].sOrder).productType;
            }
            if (res[0].sExchange != null || res[0].sExchange != undefined || res[0].sExchange != "") {
              let userPref = JSON.parse(res[0].sExchange);
              this.exchangeAllowedArry.filter(x => {
                if (x.exchangeDesc == userPref.exchangeDesc) {
                  x.selected = userPref.selected;
                }
              })
            }
          }
        }).catch(error => {
          //console.log("Error in getting user preference : " + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
        })
      }
    } catch (error) {
      //console.log("Error in ionViewWillEnter.." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ionViewWillEnter2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillLeave() {
    try {
      this.paramService.myParam = "";
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SettingsPage', 'ionViewWillLeave', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goBack() {
    clsGlobal.pubsub.publish("MENU_THEME");
    this.navCtrl.pop();
  }
  showWidgetsSetting() {
    this.navCtrl.navigateForward('widgets');
  }
  changeMpin() {
    this.navCtrl.navigateForward('changempin');
  }
  changePassword() {
    let pageSource = "settingChangePass";
    this.paramService.myParam = pageSource;
    this.navCtrl.navigateForward('changepassword');
  }

  verifyFingerPrintAvalOnDevice() {
    try {
      //enable disable finger print toggle.
      if (this.platform.is('cordova')) {
        try {
        } catch (error) {
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'verifyFingerPrintAvalOnDevice',error.Message,undefined,error.stack,undefined,undefined));
        }
      }
      else {
        this.isFingerAuthAvailable = true;//TEMP
        //this.alertObj.showAlert("Error in fingerprint checking.3");
      }

      //to get status of fingerprint.
      this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
        .then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item); 
            this.fingetPrintStatus = objMPIN.Fingerprint == 'Y' ? true : false;
            this.fingetPrintStatusOriginal = this.fingetPrintStatus; //this is used between toggle.
            //this.alertObj.showAlert("Finger Print status."+this.fingetPrintStatus);
            this.userID = objMPIN.userId; 
            this.getUserDetails(); 
          }
          else {
            //user details not found
             this.alertObj.showAlert("User Details not found!");
          }
        }).catch((error) => {
          //this.alertObj.showAlert("Verify finger print available in device or not.4  " + JSON.stringify(error));
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'verifyFingerPrintAvalOnDevice2',error.Message,undefined,error.stack,undefined,undefined));
        });
    } catch (error) {
      //console.log("Verify finger print available in device or not. " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'verifyFingerPrintAvalOnDevice3',error.Message,undefined,error.stack,undefined,undefined));
     //this.alertObj.showAlert("Verify finger print available in device or not.2  " + error.message);
      this.isFingerAuthAvailable = false;
    }
  }

  onFingerPrintChange(evnt) {
    //this.alertObj.showAlert("Event status "+ evnt.detail.checked +" Original Status" +this.fingetPrintStatusOriginal);
    try {
      let fingerPrintRequest: any = {};
      // if (!this.initDone || this.pageSource == 'goback') {
      //   this.pageSource = '';
      //   return;
      // }
      //in case fingerprint is already true and user want to disable it.
      //show confirmation.
      if (evnt.detail.checked == false && this.fingetPrintStatusOriginal == true) {
        let buttons: any = ["Yes", "No"];
        this.alertObj.showAlertConfirmWithButtons("Finger Print", "Do you want to disable fingerprint?", buttons,
          () => {
            clsGlobal.logManager.writeUserAnalytics("SettingPage", "Finger Print Disable", "FingerPrintChange", "");
            this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
              .then((item: any) => {
                if (item != undefined) {
                  let objMPIN: any = JSON.parse(item);
                  this.groupId = objMPIN.groupId;
                  this.type = 'fng';
                  fingerPrintRequest.Udid = null;
                  objMPIN.Fingerprint = 'N';//USD #13324 set flag
                  this.getLoginRequestObjectForFingerPrint(this.type, fingerPrintRequest.Udid);
                  this.clsLocalStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
                  this.fingetPrintStatus = false;
                  this.fingetPrintStatusOriginal = false;
                  //this.alertObj.showAlert("Inside confirm "+this.fingetPrintStatusOriginal);
                }
              });
          }, () => {
            //set it to original.
            this.fingetPrintStatus = this.fingetPrintStatusOriginal;
          });
      }
      else if (evnt.detail.checked == true && this.fingetPrintStatusOriginal == false) {
        //this.alertObj.showAlert("Fingerprint checked true when original it is false.");
        this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_FINGERPRINT_ENABLE);
      }
      else {
        //this.alertObj.showAlert("Event status1 "+ evnt.detail.checked +" Original Status" +this.fingetPrintStatusOriginal);
        return;
      }
      // if (evnt.detail.checked) {
      //   this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_FINGERPRINT_ENABLE);
      // } else {
      //   this.alertObj.showAlertWithCallback("Do you want to disable fingerprint ?").then((result) => {
      //     if (result) {
      //       clsGlobal.logManager.writeUserAnalytics("SettingPage", "Finger Print Disable", "FingerPrintChange", "");
      //       this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
      //         .then((item: any) => {
      //           if (item != undefined) {
      //             let objMPIN: any = JSON.parse(item);
      //             this.groupId = objMPIN.groupId;
      //             this.type = 'fng';
      //             fingerPrintRequest.Udid = null;
      //             objMPIN.Fingerprint = 'N';//  USD #13324 set flag
      //             this.getLoginRequestObjectForFingerPrint(this.type, fingerPrintRequest.Udid);
      //             this.clsLocalStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
      //             this.fingetPrintStatus = false;
      //           }
      //         });
      //     } else {
      //       this.fingetPrintStatus = !result;
      //       this.pageSource = 'goback';
      //     }
      //   });
      // }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SettingPage', 'onFingerPrintChange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'onFingerPrintChange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
  * @param opttype : to set operation type in service type:fng
  * @param udid : send udid in request
  */

  getLoginRequestObjectForFingerPrint(opttype: any, udid: string) {
    try {
      let fingerPrintRequest: any = {};
      // let MPIN = this.newMPIN;// this.pin1 + this.pin2 + this.pin3 + this.pin4;
      fingerPrintRequest.groupId = this.groupId;
      fingerPrintRequest.userId = this.userID;
      fingerPrintRequest.deviceType = clsGlobal.DeviceType;
      fingerPrintRequest.loginType = 'fingerprint';
      fingerPrintRequest.type = opttype;
      fingerPrintRequest.udid = udid;
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + 'v1/setMPIN', fingerPrintRequest)
        .subscribe((response: any) => {
          console.log(response);
        });
      //return mpinRequest;
    } catch (error) {
     // console.log("Error in Login request object" + error);
      //clsGlobal.logManager.writeErrorLog('SettingsPage', 'getLoginRequestObjectForFingerPrint', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getLoginRequestObjectForFingerPrint',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getUserDetails() {
    try {

      if (clsGlobal.User.userId != "") {
        this.mobile = clsGlobal.User.mobile;
        this.mobileDisaply += this.mobile.substr(7, 3);
        this.emailId = clsGlobal.User.email;
        this.enableSubmit = true;
        this.initDone = true;
      }
      else {
        this.authService.getUserInfo(this.userID).then((resp: any) => {
          console.log(resp);
          if (resp.status == true) {
            let userDetails = resp['result'];
            this.mobile = clsCommonMethods.TripleDESDecrypt(userDetails.mobile);
            this.mobileDisaply += this.mobile.substr(7, 3);
            this.emailId = clsCommonMethods.TripleDESDecrypt(userDetails.email);
            this.enableSubmit = true;
            this.initDone = true;
          }
        }).catch(error => {
          this.initDone = true;
          this.toastCtrl.showAtBottom(error);
          //this.loaderCtrl.hideLoader();
          //clsGlobal.logManager.writeErrorLog('SettingsPage', 'getUserDetails_1', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getUserDetails_1',error.Message,undefined,error.stack,undefined,undefined));
        })
      }
    } catch (error) {
      this.initDone = true;
      //clsGlobal.logManager.writeErrorLog('SettingsPage', 'getUserDetails_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getUserDetails_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ThemeToggleChange(event) {
    try {
      console.log(this.currentTheme);
      let isChecked: boolean = false;
      if (event.detail.value == 'light') {
        this.currentTheme = 'light';
        clsGlobal.defaultTheme = this.currentTheme;
        //clsGlobal.defaultTheme = this.currentTheme;
        isChecked = false;
      }
      else {
        this.currentTheme = 'dark'
        clsGlobal.defaultTheme = this.currentTheme;;
        //clsGlobal.defaultTheme = this.currentTheme;
        isChecked = true;
      }
      this.global.set(clsConstants.LOCAL_STORAGE_THEME, this.currentTheme);
      this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_THEME, this.currentTheme);
      const toggle = document.querySelector('#themeToggle');
      document.body.classList.toggle('dark', isChecked);
      // clsGlobal.pubsub.publish("MENU_THEME");
      clsGlobal.logManager.writeUserAnalytics("SettingsPage", "", "themeChanged", clsGlobal.defaultTheme);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("SettingsPage", "themeChanged", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ThemeToggleChange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  pushNotification() {
    this.navCtrl.navigateForward('push-notifications');
  }

  inAppNotification() {
    this.navCtrl.navigateForward('in-app-notifications');
  }

  orderProductType() {
    this.navCtrl.navigateForward('order-product-type');
  }

  orderProtection() {
    this.navCtrl.navigateForward('order-protection');
  }

  /**
   * @method : Set & Update Exchange in userpreference table in SQLite
   * @param item Exchange Object
   */
  setExchange(item) {
    try {
      item.selected = true;
      let exchangePref = item;
      let userPrefObj = {
        sExchange: JSON.stringify(exchangePref),
        sInAppNotification: this.inAppNotificationPref,
        sNotification: this.fcmTopicListPref == null ? JSON.stringify(clsGlobal.lstTopicList) : this.fcmTopicListPref,
        sOrder: this.orderPref,
        sProfilePicPath: this.profilePicPref,
        sTheme: clsGlobal.defaultTheme,
      }
      this.exchangeAllowedArry.filter(x => {
        if (x.selected) {
          x.selected = false;
        }
      })
      // Save User Preference in AppSync
      this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
        clsGlobal.User.userPreference = userPrefObj;
        console.log("Exchange User Preference Added successfully");
      }).catch(err => {
        console.log("Error in adding exchange user preference : " + err);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'setExchange',err.Message,undefined,err.stack,undefined,undefined));
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SettingsPage', 'setExchange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'setExchange2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Get exchange from global exchangesList array
   */
  getExchange() {
    try {
      // let count = 0;
      // let count2 = 0;
      // for (let i = 0; i < clsGlobal.User.exchangesList.length; i++) {
      //   if (clsGlobal.User.exchangesList[i] == 'NSE_EQ' || clsGlobal.User.exchangesList[i] == 'NSE_CUR' || clsGlobal.User.exchangesList[i] == 'NSE_FO') {
      //     count++;
      //     if (count == 1) {
      //       this.exchangeAllowedArry.push({ exchangeDesc: 'NSE', selected: false });
      //     }
      //   } else if (clsGlobal.User.exchangesList[i] == 'BSE_CUR' || clsGlobal.User.exchangesList[i] == 'BSE_EQ') {
      //     count2++;
      //     if (count2 == 1) {
      //       this.exchangeAllowedArry.push({ exchangeDesc: 'BSE', selected: false });
      //     }
      //   } else if (clsGlobal.User.exchangesList[i] == 'MCX_FO') {
      //     this.exchangeAllowedArry.push({ exchangeDesc: 'MCX', selected: false });
      //   } else if (clsGlobal.User.exchangesList[i] == 'NCDEX_FO') {
      //     this.exchangeAllowedArry.push({ exchangeDesc: 'NCDEX', selected: false });
      //   } else if (clsGlobal.User.exchangesList[i] == 'ICEX_FO') {
      //     this.exchangeAllowedArry.push({ exchangeDesc: 'ICEX', selected: false });
      //   }
      // }
      let exchangeArry = clsGlobal.User.exchangesList;
      exchangeArry.forEach(element => {
        let mktSegId = this.getSegmentId(element)
        this.exchangeAllowedArry.push({ MarketSegmentId: mktSegId, exchangeDesc: clsTradingMethods.getExchangeNameDesc(parseInt(mktSegId)), selected: false });
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SettingsPage', 'getExchange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getExchange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Returns Market segment Id as per exchange name provided
   * @param exchangename : Exchange Name
   */
  getSegmentId(exchangename) {
    let strExName = exchangename.toUpperCase();
    let intMktSegId;

    switch (strExName) {
      case clsConstants.C_S_NSE_EQ:
      case clsConstants.C_S_NSE_EQ_API_NAME:
        intMktSegId = clsConstants.C_V_NSE_CASH;
        break;
      case clsConstants.C_S_NSE_DERV:
        intMktSegId = clsConstants.C_V_NSE_DERIVATIVES;
        break;
      case clsConstants.C_S_BSE_EQ:
      case clsConstants.C_S_BSE_EQ_API_NAME:
        intMktSegId = clsConstants.C_V_BSE_CASH;
        break;
      case clsConstants.C_S_BSE_DERV:
        intMktSegId = clsConstants.C_V_BSE_DERIVATIVES;
        break;
      case clsConstants.C_S_MCX_DERV:
        intMktSegId = clsConstants.C_V_MCX_DERIVATIVES;
        break;
      case clsConstants.C_S_MCX_SPOT:
        intMktSegId = clsConstants.C_V_MCX_SPOT;
        break;
      case clsConstants.C_S_ICEX_DERV:
        intMktSegId = clsConstants.C_V_ICEX_DERIVATIVES;
        break;
      // case clsConstants.C_S_BSE_COMM:
      //   intMktSegId = clsConstants.C_V_BSECOMM_DERIVATIVES;
      //   break;
      // case clsConstants.C_S_NSE_COMM:
      //   intMktSegId = clsConstants.C_V_NSECOMM_DERIVATIVES;
      //   break;
      // case clsConstants.C_S_BSECOMM_SPOT:
      //   intMktSegId = clsConstants.C_V_BSECOMM_SPOT;
      //   break;
      // case clsConstants.C_S_NSECOMM_SPOT:
      //   intMktSegId = clsConstants.C_V_NSECOMM_SPOT;
      //   break;
      case clsConstants.C_S_NCDEX_DERV:
        intMktSegId = clsConstants.C_V_NCDEX_DERIVATIVES;
        break;
      case clsConstants.C_S_NCDEX_SPOT:
        intMktSegId = clsConstants.C_V_NCDEX_SPOT;
        break;
      case clsConstants.C_S_MCXSX_CURR:
        intMktSegId = clsConstants.C_V_MSX_DERIVATIVES;
        break;
      case clsConstants.C_S_MCXSX_EQ:
        intMktSegId = clsConstants.C_V_MSX_CASH;
        break;
      case clsConstants.C_S_MCXSX_DERV:
        intMktSegId = clsConstants.C_V_MSX_FAO;
        break;
      case clsConstants.C_S_MCXSX_SPOT:
        strExName = clsConstants.C_V_MSX_SPOT;
        break;
      case clsConstants.C_S_NSX_DERV:
        intMktSegId = clsConstants.C_V_NSX_DERIVATIVES;
        break;
      case clsConstants.C_S_NSX_SPOT:
        intMktSegId = clsConstants.C_V_NSX_SPOT;
        break;
      case clsConstants.C_S_BSECDX_DERV:
        intMktSegId = clsConstants.C_V_BSECDX_DERIVATIVES;
        break;
      case clsConstants.C_S_BSECDX_SPOT:
        intMktSegId = clsConstants.C_V_BSECDX_SPOT;
        break;
      case clsConstants.C_S_NSE_OTS:
        intMktSegId = clsConstants.C_V_OFS_IPO_BONDS;
        break;
    }

    return intMktSegId;
  }
}
