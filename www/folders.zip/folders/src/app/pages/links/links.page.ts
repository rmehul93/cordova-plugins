import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { BrowserServicesProvider } from 'src/app/providers/browser-services/browser-services';

@Component({
  selector: 'app-links',
  templateUrl: './links.page.html',
  styleUrls: ['./links.page.scss'],
})
export class LinksPage implements OnInit {
  exchangesData: any = [];
  noDataFound: boolean = false;
  showLoader: boolean = false;
  constructor(public navCtrl: NavController, private iab: BrowserServicesProvider, public http: clsHttpService) { }

  ngOnInit() {
    this.showLoader = true;
    this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getExchangeLinks").subscribe((respData: any) => {
      try {
        if (respData.status) {
          this.showLoader = false;
          this.noDataFound = false;
          this.exchangesData = respData.result;
        } else {
          this.showLoader = false;
          this.noDataFound = true;
        }
      } catch (error) {
        this.showLoader = false;
        this.noDataFound = true;
        // clsGlobal.logManager.writeErrorLog('LinksPage', 'ngOnInit_1', error);
        // clsGlobal.ConsoleLogging("Error", "ngOnInit_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LinksPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
      }
    },
      error => {
        this.showLoader = false;
        this.noDataFound = true;
        // clsGlobal.logManager.writeErrorLog('LinksPage', 'ngOnInit_2', error);
        // clsGlobal.ConsoleLogging("Error", "ngOnInit_2", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LinksPage', 'ngOnInit2',error.Message,undefined,error.stack,undefined,undefined));
      }
    );
  }

  goToPage(item) {
    try{
    this.iab.openBrowser(item.sLinkTitle, item.sLinkAddress, item.cOpenMode);
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LinksPage', 'goToPage',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

}
