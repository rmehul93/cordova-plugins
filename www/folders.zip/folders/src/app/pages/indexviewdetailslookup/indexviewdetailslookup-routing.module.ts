import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IndexviewdetailslookupPage } from './indexviewdetailslookup.page';

const routes: Routes = [
  {
    path: '',
    component: IndexviewdetailslookupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IndexviewdetailslookupPageRoutingModule {}
