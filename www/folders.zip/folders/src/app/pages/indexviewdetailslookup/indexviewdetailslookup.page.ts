import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonInput, Platform } from '@ionic/angular';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ActivatedRoute } from '@angular/router';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';

@Component({
  selector: 'app-indexviewdetailslookup',
  templateUrl: './indexviewdetailslookup.page.html'
})
export class IndexviewdetailslookupPage implements OnInit {
  @ViewChild('inputId',{static : false}) inputId : IonInput;
  indexConstituentList : any = [];
  showSegments: boolean = false;
  searchTextIVDL:any  = '';
  IVDLSearchData:any = [];
  searchTextChangedIVDL = new Subject<string>();
  subscriptionIVDL :any;
  searchTextEnteredIVDL:any='';
  IDVLAlertKeys : any = [];
  bcastHandler:any ;
  showPopUpOE: boolean = false;
  selectedScripObj : any;
  selectedScrip : any;
  showFullMode:boolean =false;
  indexDetails : any;
  showNoDataFound : boolean = false;
  constructor(
    private paramService: NavParamService,
    public navCtrl: NavController,
    public alertCtrl: AlertServicesProvider,
    public http: clsHttpService,
    private activatedRoute: ActivatedRoute,
    public toastCtrl: ToastServicesProvider,
    public speechRecognition: SpeechRecognition,
    public platform: Platform,
    public loadingCtrl: LoaderServicesProvider,
  ) {
    this.indexConstituentList = this.paramService.myParam;
    this.IVDLSearchData = '';
   }

  ngOnInit() {
    this.indexDetails =this.activatedRoute.snapshot.queryParams["data"] != undefined ? this.activatedRoute.snapshot.queryParams["data"] : '';
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
  } 

  setFocusOnInput(){
    this.inputId.setFocus();
  }

  ionViewWillEnter() {
    try{
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.createBroadcastforSearchIDVL();
      this.setFocusOnInput();
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'ionViewWillEnter', error.message);
    } 
  }

  ionViewWillLeave() {
    try {
      this.sendTouchlineRequest(OperationType.REMOVE, this.IDVLAlertKeys);
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);      
      
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'ionViewWillLeave', error.message);
    }
  }

  goBack(){
    this.navCtrl.pop();
  }

  hideSearchPopupIndexViewDetailsLookup() {
    try{
      
      this.searchTextIVDL = '';
      this.IVDLSearchData = [];
      this.showSegments = false;
      this.navCtrl.pop();
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'hideSearchPopupIndexViewDetailsLookup', error.message);
    }
  }

  searchIndexViewDetailsLookup(event) {
    try{
      if(event == '')
      {
        this.clearSearchIndexViewDetailsLookup();
        return;
      }
      this.showNoDataFound = false;
      let search = event.toUpperCase();
      this.searchTextIVDL =  event.toUpperCase();
      let tempList = [];
      for (let counter = 0; counter < this.indexConstituentList.length; counter++) {
        let Symbol = this.indexConstituentList[counter].Symbol;
        if (Symbol.includes(search)) {
          tempList.push(this.indexConstituentList[counter]);
        }
      }
      if(tempList.length == 0)
      { 
        this.IVDLSearchData = [];
        this.showNoDataFound = true;
        return;
      }
      this.IVDLSearchData = tempList;
      this.showSegments = true;
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'searchIndexViewDetailsLookup', error.message);
    }
  }

  clearSearchIndexViewDetailsLookup() {
    try{
      this.searchTextIVDL = '';
      this.IVDLSearchData = '';
      this.showSegments = false;
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'clearSearchIndexViewDetailsLookup', error.message);
    }
  }

  getValuesIndexViewDetailsLookup(event) {
    try {

      this.IVDLSearchData = [];
      let search = event.trim();
      if (search.length < 1) {
        this.searchTextEnteredIVDL = '';
        return;
      }
      if(search.length == 0)
      {
        this.clearSearchIndexViewDetailsLookup()
      }
      this.searchTextEnteredIVDL = search.toUpperCase();
      
      this.showSegments = true;
      this.IVDLSearchData = this.indexConstituentList.filter(x => (x.Symbol.toUpperCase().trim().startsWith(this.searchTextEnteredIVDL)));
    }catch(error){
      
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'getValuesIndexViewDetailsLookup', error.message);
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'sendTouchlineRequest', error);
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        
        for (let count = 0; count < this.IVDLSearchData.length; count++) {
          if (this.IVDLSearchData[count].nToken.toString() == objMultiTLResp.Scrip.token &&
            this.IVDLSearchData[count].nMarketSegmentId  == objMultiTLResp.Scrip.MktSegId) {
            this.IVDLSearchData[count].LTP = objMultiTLResp.LTP;

            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.IVDLSearchData[count].NetChangeInRs = arrNetChange[0];
            this.IVDLSearchData[count].PercNetChange = arrNetChange[1];
            this.IVDLSearchData[count].colorTrend = arrNetChange[2];
            this.IVDLSearchData[count].percentage = arrNetChange[3];
            if(this.IVDLSearchData[count].colorTrend == 'color-positive')
            {
              this.IVDLSearchData[count].colorcontrast = 'background-positive-contrast'
            }
            else if(this.IVDLSearchData[count].colorTrend == 'color-negative')
            {
              this.IVDLSearchData[count].colorcontrast = 'background-negative-contrast'
            }
          }
        }

      }
    }
    catch (error) {
      console.log('indexviewdetailslookup', 'receiveTouchlineResponse', error);
    }

  }

  createBroadcastforSearchIDVL(){
    try{
      this.IDVLAlertKeys = [];
      for (let index = 0; index < this.IVDLSearchData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.IVDLSearchData[index].nToken;
        objScrpKey.MktSegId = this.IVDLSearchData[index].nMarketSegmentId;
        this.IDVLAlertKeys.push(objScrpKey);
      }
      this.sendTouchlineRequest(OperationType.ADD, this.IDVLAlertKeys);
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'createBroadcastforSearchIDVL', error.message);
    }
  }

  scripClick(scripobj) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(scripobj.nMarketSegmentId),
          token: scripobj.nToken
        }]
      }
       clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let objScrpKey = new clsScripKey();

        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        objScrpKey.token = this.selectedScripObj.nToken;
    
        let scripInfo: clsScrip = new clsScrip();
        scripInfo.scripDet = objScrpKey;
        scripInfo.symbol = this.selectedScripObj.sSymbol.trim();
        scripInfo.Series = this.selectedScripObj.sSeries;
        scripInfo.DecimalLocator = this.selectedScripObj.DecimalLocator == "0" ? "100" : this.selectedScripObj.DecimalLocator;
        scripInfo.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        scripInfo.ExpiryDate = (this.selectedScripObj.nExpiryDate1 != null && this.selectedScripObj.nExpiryDate1.toString() != "" && this.selectedScripObj.nExpiryDate1.toString() != "0") ? this.selectedScripObj.nExpiryDate1 : "0";
        scripInfo.OptionType = this.selectedScripObj.sOptionType;
        scripInfo.MarketLot = this.selectedScripObj.nRegularLot;
        scripInfo.PriceTick = this.selectedScripObj.nPriceTick;
        scripInfo.SecurityDesc = this.selectedScripObj.sSecurityDesc;
        scripInfo.MWSecurityDesc = this.selectedScripObj.MWSecurityDesc;
        scripInfo.StrikePrice = this.selectedScripObj.nStrikePrice1.toString();
        scripInfo.ISIN = this.selectedScripObj.sISINCode;
        scripInfo.SPOS = "";
        scripInfo.POS = "";
        scripInfo.AssetToken = this.selectedScripObj.nAssetToken;
        scripInfo.FIILimit = this.selectedScripObj.nFIILimit;
        scripInfo.NRILimit = this.selectedScripObj.nNRILimit;
        scripInfo.MarginTypeIndicator = this.selectedScripObj.nMarginTypeIndicator;
        if (this.selectedScripObj.sInstrumentName.indexOf('IDX') != -1) {
          scripInfo.isIndex = true;
        }
        else {
          scripInfo.isIndex = false;
        }
    
        scripInfo.formatScripDisplayName()
    
        let idData = new clsIndexDetail();
         idData.scripDetail = scripInfo;

         this.paramService.myParam = idData.scripDetail;
         this.navCtrl.navigateForward(["/scripinfo"]);
            
      }).catch(error => {
        this.toastCtrl.showAtBottom("Unable to get Scrip Info");
        clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'scripClick', error);
      });
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to get Scrip Info")
      console.log(error);
    }
  }

  showPopUpOrderEntry(item) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(item.nMarketSegmentId),
          token: item.nToken
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let SegmentId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
          this.alertCtrl.showAlert(
            "You are currently not allowed to place/modify/cancel order in this segment",
            "Order Error!"
          );
          return;
        }
    
        this.showPopUpOE = !this.showPopUpOE;
        let currScrip: clsScrip = new clsScrip();
        currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        currScrip.scripDet.token = this.selectedScripObj.nToken;
        currScrip.symbol = this.selectedScripObj.sSymbol.trim();
        currScrip.Series = this.selectedScripObj.sSeries;
        currScrip.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        currScrip.ExpiryDate = this.selectedScripObj.nExpiryDate1;
        currScrip.StrikePrice = this.selectedScripObj.nStrikePrice1 || "-1";
        currScrip.OptionType = this.selectedScripObj.sOptionType || "NA";
        currScrip.MarketLot = this.selectedScripObj.nRegularLot || 1;
        currScrip.PriceTick = this.selectedScripObj.nPriceTick || 1;
        //this.selectedScrip = currScrip;
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
        // objOEFormDetail.buyPrice = this.selBidPrice;
        // objOEFormDetail.sellPrice = this.selAskPrice;
        // objOEFormDetail.closePrice = this.closePrice;
        // objOEFormDetail.ltp = this.scripLTP;
        objOEFormDetail.scripDetl = currScrip;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.selectedScrip = objOEFormDetail;
      }).catch(error => {
        this.toastCtrl.showAtBottom("Unable to open Order Entry");
        clsGlobal.logManager.writeErrorLog('IndexviewdetailslookupPage', 'showPopUpOrderEntry', error);
      });      
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to open Order Entry");
      console.log(error);
    }
  }

  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode=false;
  }

  onFocus(event){
    this.showFullMode=true;
  }

  checkVoiceString: any;
  ShowVoiceModel() {
    this.searchTextIVDL = '';

    this.checkVoiceString = '';
    this.speechRecognition.isRecognitionAvailable().then((available: boolean) => {
      if (available) {
        this.speechRecognition.hasPermission()
          .then((hasPermission: boolean) => {
            if (hasPermission)
              this.VoiceStartListening();
            else {
              this.speechRecognition.requestPermission()
                .then(
                  () => {
                    console.log('Granted');
                    this.VoiceStartListening();
                  },
                  () => {
                    console.log('Denied');
                    this.toastCtrl.showAtBottom("you need to give permission for voice.");
                  }
                )


            }
          });
      }
      else {
        this.toastCtrl.showAtBottom("microphone not available.");
      }
    });
  }

  VoiceStartListening() {
    if (this.platform.is('android')) {
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            this.searchIndexViewDetailsLookup(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            console.log("Error" + onerror);
          }
        );
    }
    else {
      this.loadingCtrl.showLoaderforText();
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            //alert("String "+matches[0].toString())
            this.loadingCtrl.hideLoaderforText();
            this.checkVoiceString = matches[0].toString();
            this.searchIndexViewDetailsLookup(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //alert("Error "+onerror)
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            this.loadingCtrl.hideLoaderforText();
            console.log("Error" + onerror);
          }
        );
      setTimeout(() => {
        this.loadingCtrl.hideLoaderforText();
        this.speechRecognition.stopListening();
        setTimeout(() => {
          if (this.checkVoiceString == '' || this.checkVoiceString == undefined) {
            this.toastCtrl.showAtBottom("Voice not captured. Try saying something again")
          }
        }, 1000)
      }, 3000);
    }

  }

  // searchVoiceText(text) {
  //   if (text != undefined || text != '') {
  //     this.searchText = text.toUpperCase().trim();
  //     this.searchTextChanged.next(this.searchText);
  //     this.recentlySearched = false;
  //     this.showTrending = false;
  //     this.showRecommendations = false;
  //   } else {
  //     this.loadRecentScripts();
  //     this.getHotpursuitData();
  //   }
  // }

  VoiceHasPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        return hasPermission;
      });
  }

  voiceSearchMaching(text: any) {
    var _text = text.toString().toUpperCase().trim();
    _text = _text.replace("JANUARY", "JAN").
      replace("FEBRUARY", "FEB").
      replace("MARCH", "MAR").
      replace("APRIL", "APR").
      replace("JUNE", "JUN").
      replace("JULY", "JUL").
      replace("AUGUST", "AUG").
      replace("SEPTEMBER", "SEP").
      replace("OCTOBER", "OCT").
      replace("NOVEMBER", "NOV").
      replace("DECEMBER", "DEC").
      replace("FUTURES", "FUT").
      replace("FUTURE", "FUT").
      replace("OPTIONS", "OPT").
      replace("OPTION", "OPT");
    return _text.toUpperCase();
  }

}
