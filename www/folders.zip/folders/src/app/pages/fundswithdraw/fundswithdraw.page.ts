import { clsGlobal } from './../../Common/clsGlobal';
import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';

@Component({
  selector: 'app-fundswithdraw',
  templateUrl: './fundswithdraw.page.html',
})
export class FundswithdrawPage implements OnInit {
  showResult: boolean = false;
  showAccounts: boolean = false;
  addAmount: number;
  selectedFundsItem: any;
  productWisefundsDetails: any = [];
  selectedBank: any;
  bankList: any = [];
  numberortell: any = "tel";
  pendingAmt = 0;
  constructor(private navCtrl: NavController,
    private navParamService: NavParamService,
    private transactionService: TransactionService,
    private loaderCtrl:LoaderServicesProvider,
    private toastCtrl: ToastServicesProvider,) {
    this.selectedFundsItem = navParamService.myParam;
  }

  ngOnInit() {
    try {
      this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;
      
      for (let index = 0; index < this.productWisefundsDetails.length; index++) {
        this.productWisefundsDetails[index].balanceAmountDisplay =
        clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
      }

      if (!this.selectedFundsItem) { 
        this.selectedFundsItem = this.productWisefundsDetails[0];
      }

      this.pendingAmt = this.selectedFundsItem.balanceAmount;

      this.getBankList();
    } catch (error) {
      console.log(error);
    }
  }
  goBack() {
    this.navCtrl.navigateBack('fundsmain');
  }
  closeResult() {
    this.showResult = false;
  }


  onAmtChanged(evt) {
    if (this.addAmount != 0)
      this.pendingAmt = parseFloat((this.selectedFundsItem.balanceAmount - this.addAmount).toFixed(2));

      if (this.addAmount.toString() == ''){
        this.pendingAmt = this.selectedFundsItem.balanceAmount;
      }
  }

  requestForWithdrawal() {
    try {

      if (!this.addAmount) {
        this.toastCtrl.showAtBottom("Please add amount ")
        return;
      }

      if(this.pendingAmt <= 0){
        this.toastCtrl.showAtBottom("Amount not available to withdraw.")
        return;
      }

      if (!this.selectedBank) {
        this.toastCtrl.showAtBottom("Please select bank account ")
      } else {

        let reqBody = {
          "amount": this.addAmount,
          "productId": this.selectedFundsItem.sProductId,
          "bankId": this.selectedBank.sBankId,
          "accNo": this.selectedBank.sAccountNo
        }
        this.loaderCtrl.showLoader(true);
        this.transactionService.withdrawFunds(reqBody).then((response: any) => {
          
          if (response.status == 'success') {
            this.showResult = true;
          } else {

          }
          this.loaderCtrl.hideLoader();
        }, err => {
          console.log(err);
          this.loaderCtrl.hideLoader();
        });

      }
    } catch (error) {
      console.log(error);
      this.loaderCtrl.hideLoader();
    }
  }
  clickAccounts() {
    this.showAccounts = !this.showAccounts;
  }

  getBankList() {
    try {
      this.selectedBank = null;
      this.transactionService.getBankListForselectedProduct(this.selectedFundsItem.sProductId,'').then((response: any) => {
        if (response.status == 'success') {
          this.bankList = response.data;
          if (this.bankList.length > 0) {
            this.selectedBank = this.bankList[0]
          }
        } else {
          this.bankList = [];
        }
      }, err => {
        console.log(err);
        this.bankList = [];
      })
    } catch (error) {
      console.log(error);
    }
  }

  setFundSelection(fundsItem) {
    this.showAccounts = !this.showAccounts;
    this.selectedFundsItem = fundsItem;
    this.getBankList();
  }

}
