import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FundswithdrawPage } from './fundswithdraw.page';

const routes: Routes = [
  {
    path: '',
    component: FundswithdrawPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FundswithdrawPageRoutingModule {}
