import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-app-notifications',
  templateUrl: './in-app-notifications.page.html',
  styleUrls: ['./in-app-notifications.page.scss'],
})
export class InAppNotificationsPage implements OnInit {
  brokerMsgToggeld: boolean = false;
  orderMsgToggeld: boolean = false;
  exchangeMsgToggeld: boolean = false;
  recommendations: boolean = false;
  alerts: boolean = false;
  marketNews: boolean = false;
  topics: any = [];
  exchangePref: any;
  fcmTopicPref: any;
  profilePicPref: any;
  orderPref: any;
  param = {
    recommendations: false,
    alerts: false,
    order_message: false,
    broker_message: false,
    exchange_message: false,
    market_news: false
  }

  constructor(private navCtrl: NavController,
    private appSync: AppsyncDbService) { }

  ngOnInit() {
    try {
      if (clsGlobal.User.userPreference != undefined || clsGlobal.User.userPreference != "") {
        this.exchangePref = clsGlobal.User.userPreference.sExchange;
        this.fcmTopicPref = clsGlobal.User.userPreference.sNotification;
        this.profilePicPref = clsGlobal.User.userPreference.sProfilePicPath;
        this.orderPref = clsGlobal.User.userPreference.sOrder;
        if (clsGlobal.User.userPreference.sInAppNotification != "" || clsGlobal.User.userPreference.sInAppNotification != undefined) {
          let userPref = JSON.parse(clsGlobal.User.userPreference.sInAppNotification);
          this.param = userPref;
          Object.keys(this.param).forEach(item => {
            if (item == 'order_message')
              this.orderMsgToggeld = this.param[item];
            if (item == 'broker_message')
              this.brokerMsgToggeld = this.param[item];
            if (item == 'exchange_message')
              this.exchangeMsgToggeld = this.param[item];
            if (item == 'market_news')
              this.marketNews = this.param[item];
            if (item == 'recommendations')
              this.recommendations = this.param[item];
            if (item == 'alerts')
              this.alerts = this.param[item];
          })
        }
      } else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            this.exchangePref = res[0].sExchange;
            this.fcmTopicPref = res[0].sNotification;
            this.profilePicPref = res[0].sProfilePicPath;
            this.orderPref = res[0].sOrder;
            if (res[0].sInAppNotification != null && res[0].sInAppNotification != undefined) {
              let userPref = JSON.parse(res[0].sInAppNotification);
              this.param = userPref;
              Object.keys(this.param).forEach(item => {
                if (item == 'order_message')
                  this.orderMsgToggeld = this.param[item];
                if (item == 'broker_message')
                  this.brokerMsgToggeld = this.param[item];
                if (item == 'exchange_message')
                  this.exchangeMsgToggeld = this.param[item];
                if (item == 'market_news')
                  this.marketNews = this.param[item];
                if (item == 'recommendations')
                  this.recommendations = this.param[item];
                if (item == 'alerts')
                  this.alerts = this.param[item];
              })
            }
          }
        }).catch(error => {
          console.log("Error in getting user preference : " + error);
        })
      }
    } catch (error) {
      console.log("Error + ngOnInit"+ error);
      clsGlobal.logManager.writeErrorLog('in-app-notification', 'ngOnInit', error); 
    }
  } 

  /**
   * @method : Navigate to previous page
   */
  goBack() {
    this.navCtrl.pop();
  }

  /**
   * @method Create User preference settings for inAppNotification for App Sync Database
   * @param event : event object of toggle for status true/false
   * @param type : Notification type
   */
  toggleMessages(event, type) {
    try {
      Object.keys(this.param).forEach(item => {
        if (item == type) {
          this.param[item] = event.detail.checked;
        }
      })
    } catch (error) {
      console.log("Error + toggleMessages"+ error); 
    }
  }

  /**
   * @method Save User preference settings when leaving page
   */
  ionViewWillLeave() {
    try {
      let userPrefObj = {
        sExchange: this.exchangePref,
        sInAppNotification: JSON.stringify(this.param),
        sNotification: this.fcmTopicPref == null ? JSON.stringify(clsGlobal.lstTopicList) : this.fcmTopicPref,
        sOrder: this.orderPref,
        sProfilePicPath: this.profilePicPref,
        sTheme: clsGlobal.defaultTheme,
      }
      this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
        clsGlobal.User.userPreference = userPrefObj;
        console.log("In App Notification preference added successfully");
      }).catch(err => {
        console.log("Error + ionViewWillLeave_1", err);
      })
    } catch (error) {
      console.log("Error + ionViewWillLeave_2", error);
    }
  }
}
