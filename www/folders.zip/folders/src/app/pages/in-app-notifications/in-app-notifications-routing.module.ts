import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InAppNotificationsPage } from './in-app-notifications.page';

const routes: Routes = [
  {
    path: '',
    component: InAppNotificationsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InAppNotificationsPageRoutingModule {}
