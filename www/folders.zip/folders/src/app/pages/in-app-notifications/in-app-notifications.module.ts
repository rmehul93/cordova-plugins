import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InAppNotificationsPageRoutingModule } from './in-app-notifications-routing.module';

import { InAppNotificationsPage } from './in-app-notifications.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InAppNotificationsPageRoutingModule
  ],
  declarations: [InAppNotificationsPage]
})
export class InAppNotificationsPageModule {}
