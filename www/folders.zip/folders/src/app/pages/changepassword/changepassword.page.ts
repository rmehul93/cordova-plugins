import { Component, OnInit } from '@angular/core';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TranslateService } from '@ngx-translate/core';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { ModalController, NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.page.html',
  styleUrls: ['./changepassword.page.scss'],
})
export class ChangepasswordPage implements OnInit {
  userId: any;

  /*
  * Change password varible declaration
  */
  oldPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';

  passwordType: string = 'password';
  newPasswordType: string = 'password';
  confirmPasswordType: string = 'password';

  passwordIcon: string = "eye-off-icon";
  newPasswordIcon: string = "eye-off-icon";
  confirmPasswordIcon: string = "eye-off-icon";

  showPassword: boolean = false;
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  minPasswordLength: number = 6;
  maxPasswordLength: number = 12;

  username: string = '';
  groupId: string = "";
  cnhgPwdForm: FormGroup;
  appName: any = "Beyond";
  appVersion: any = "-";
  userName: any = "-";
  lastLogonTime: any = "-";
  userID: string = "";
  pageSource: string = ";"

  oldPassError: any;
  newPassError: any;
  confirmPassError: any;
  otp: any;
  mobile: any;
  pageTitle :any;
  showpassExpireError: boolean = false;
  changeMpinLoader: boolean = false;

  passwordRule1:boolean=false;
  passwordRule2:boolean=false;
  passwordRule3:boolean=false;

  /*end*/
  constructor(
    public translate: TranslateService,
    public alertObj: AlertServicesProvider,
    public httpService: clsHttpService,
    public toastCtrl: ToastServicesProvider,
    private formBldr: FormBuilder,
    public modalCtrl: ModalController,
    private authService: AuthenticationService,
    private paramService: NavParamService,
    // private loadingCtrl: LoaderServicesProvider,
    public http: clsHttpService,
    public clsLocalStorage: clsLocalStorageService,
    public navCtrl: NavController) {

  }

  ngOnInit() {
    try {
      this.pageSource = this.paramService.myParam;
      this.otp = this.paramService.otp;
      this.mobile = this.paramService.mobile;
      if (this.pageSource == 'forgotPass') {
        this.cnhgPwdForm = this.formBldr.group({
          //oldPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
          newPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
          cnfrmNewPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
        });
      }
      else {
        this.cnhgPwdForm = this.formBldr.group({
          oldPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
          newPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
          cnfrmNewPwdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(parseInt('6')), Validators.maxLength(parseInt('12'))])],
        });
      }

      if(this.pageSource == 'forgotPass' || this.pageSource == 'settingChangePass'){
        this.showpassExpireError = false;
            this.pageTitle = 'Change Password';
      }else{
        this.showpassExpireError = true;
        this.pageTitle = 'Set a new Password';
      }
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      this.minPasswordLength = 6; //Number.parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MIN_PASSWORD_LENGTH));
      this.maxPasswordLength = 12; // Number.parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_PASSWORD_LENGTH));
      this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
        .then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            if(objMPIN.userId.toUpperCase().trim() == clsGlobal.User.userId.toUpperCase().trim())
            {
              this.userID = objMPIN.userId.toUpperCase().trim();
            }
            else
            {
              this.userID = objMPIN.userId.toUpperCase().trim();
            }
          }
          else {
            this.userID = clsGlobal.User.userId.toUpperCase().trim();
          }
        }, error => {
          console.log('Error while retrieving local storage details.');
        });

    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangepasswordPage', 'ngOnInit', error);
    }
  }


  /**
   * Description: To clear password
   * Developer : Megha Phate
   * Date : 13 Aug 2020
   */
  onCancelPasswordRequest() {
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmPassword = '';
  }

  /**
   * Description: To validate password 
   * Developer : Megha Phate
   * Date : 13 Aug 2020
  */
  verifypassword() {
    try {
      let regexSpeciaChr = "^(?=.*[0-9a-zA-Z]+.*)[0-9a-zA-Z<>'`,._:;~!@#$%^&*()+-{}=\"|/\\\\]{" + this.minPasswordLength + "," + this.maxPasswordLength + "}$";
      let regExpSpc = new RegExp(regexSpeciaChr);
      if (this.oldPassword == '' && this.pageSource != "forgotPass") {
        // this.alertObj.showAlert('<span class="error">kindly enter old password</span>');
        this.oldPassError = "kindly enter old password";
        return false;
      }

      if (this.newPassword == '') {
        // this.alertObj.showAlert('<span class="error">kindly enter new password</span>');
        this.newPassError = "kindly enter new password";
        return false;
      }

      if (this.confirmPassword == '') {
        // this.alertObj.showAlert('<span class="error">kindly enter confirm new password</span>');
        this.confirmPassError = "kindly enter confirm new password";
        return false;
      }

      if ((this.oldPassword.length < this.minPasswordLength && this.pageSource != "forgotPass") || this.newPassword.length < this.minPasswordLength || this.confirmPassword.length < this.minPasswordLength) {
        // this.alertObj.showAlert('<span class="error">Password should have minimum' + this.minPasswordLength + ' characters');
        this.oldPassError = "Password should have minimum" + this.minPasswordLength + "characters";
        return false;
      }

      if (!regExpSpc.test(this.oldPassword) && this.pageSource != "forgotPass") {
        // this.alertObj.showAlert('<span class="error">Password does not meet the policy requirement or cannot be blank</span>');
        this.oldPassError = "Password does not meet the policy requirement or cannot be blank";
        return false;
      }

      if (!regExpSpc.test(this.newPassword)) {
        // this.alertObj.showAlert('<span class="error">New Password does not meet the policy requirement or cannot be blank</span>');
        this.newPassError = 'New Password does not meet the policy requirement or cannot be blank';
        return false;
      }

      if (this.newPassword != this.confirmPassword) {
        // this.alertObj.showAlert('<span class="error">Your new password and confirm password do not match</span>');
        this.confirmPassError = "Your new password and confirm password do not match.";
        return false;
      }

      if (this.oldPassword == this.newPassword) {
        //this.alertObj.showAlert('<span class="error">Your password should not be same as previous password</span>');
        // this.alertObj.showAlert('<span class="error">Your old password and new password can not be same</span>');
        this.confirmPassError = "Your password should not be same as previous password";
        return false;
      }

      if (this.newPassword == clsGlobal.User.userId) {
        // this.alertObj.showAlert('<span class="error">Password should not be same as User Id</span>');
        this.newPassError = "Your username & password cannot be same. Try using different words";
        return false;
      }

      return true;
    } catch (error) {
      console.log(error);
    }
  } 
  passwordStrength:any=""; 
  //Added by omprakash 
  //to check all 3 rules
  verifyNewPasswordKeyUp()
  { 
    this.oldPassError = '';
    this.newPassError = '';
    this.confirmPassError = '';
    this.passwordStrength="";
    let regExAlphabat = "^(?=.*[a-z])(?=.*[A-Z]).*$";
    let regExpAlp = new RegExp(regExAlphabat);

    let regExNumbers = "^(?=.*\\d).*$";
    let regExpNo = new RegExp(regExNumbers);
     
    let regExSpecial = "^(?=.*[-+_!@#$%^&*., ?]).*$";
    let regExpSpc = new RegExp(regExSpecial);

    if (regExpAlp.test(this.newPassword)) {
      this.passwordRule1 = true; 
    }
    else {
      this.passwordRule1 = false; 
    }
    if (regExpNo.test(this.newPassword)) {
      this.passwordRule2 = true; 
    }
    else {
      this.passwordRule2 = false;
    }
    if (regExpSpc.test(this.newPassword)) {
      this.passwordRule3 = true; 
    }
    else {
      this.passwordRule3 = false;
    } 
    if (this.passwordRule1 && this.passwordRule2 && this.passwordRule3) {
      this.passwordStrength = "Strong"
    }
    else if ((this.passwordRule1 && this.passwordRule2) ||
      (this.passwordRule1 && this.passwordRule3) ||
      (this.passwordRule2 && this.passwordRule3)) {
      this.passwordStrength = "Medium";
    }

    else {
      this.passwordStrength = "Weak";
    }
  }
  /**
  * Description: method for process change password request
  * Developer : Megha Phate
  * Date : 13 Aug 2020
  */
  processChangePassword() {
    try {
      let reqChangePass = {
        user_id: this.userID.toUpperCase().trim(),
        old_password: this.oldPassword.trim(),
        new_password: this.newPassword.trim(),
        source: "WEBAPI",
        api_key: clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY")
      };

      this.authService.changePassword(reqChangePass).then((response: any) => {
        if (response.status == "success") {
          if (response.code == "s-101") {
            this.changeMpinLoader = !this.changeMpinLoader;
            clsGlobal.User.sessionId = '';
            this.onCancelPasswordRequest();

            this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
              .then((item: any) => {
                if (item != undefined && item != "") {
                  let objMPIN: any = JSON.parse(item);
                  if (objMPIN.MPINEnable == 'Y' || objMPIN.Fingerprint == 'Y') {
                   
                    setTimeout(()=>{
                      this.navCtrl.navigateRoot('mpinlogin');
                     },3000)
                  } else {
                    this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SETMPIN);
                  }
                }
                else {
                   setTimeout(()=>{
                    this.navCtrl.navigateRoot('signin');
                     },3000)
                }
              });
          }
        }
      }).catch(error => {
        if (error == "1|Password already used") {
          this.alertObj.showAlertCallbackWithSingleButton("Your password should not be same as previous password").then((success) => {
            this.newPassword = '';
            this.confirmPassword = '';
          });
        } else if (error == "Invalid client Id or password") {
          this.alertObj.showAlertCallbackWithSingleButton("Invalid client Id or password").then((success) => {
            this.oldPassword = '';
            this.newPassword = '';
            this.confirmPassword = '';
          });
        }         
        else {
          this.alertObj.showAlertCallbackWithSingleButton(error).then((success) => {
            this.oldPassword = '';
            this.newPassword = '';
            this.confirmPassword = '';
            if(error == "Your account has been locked due to repeated failures.Please contact the administrator")
            {
              this.navCtrl.navigateRoot('signin');
            }
          });          
        }
      })
    } catch (error) {
      console.log("Error + processChangePassword ", error);
      clsGlobal.logManager.writeErrorLog('ChangepasswordPage', 'processChangePassword', error);
    }
  }

  /**
   * Description: method for change password
   * Developer : Megha Phate
   * Date : 13 Aug 2020
  **/
  changePassword() {
    try {
      if (this.verifypassword()) {
        if (this.newPassword == 'ftodin1' || this.newPassword == 'FTODIN1')
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL280"));
        else if (this.newPassword != this.confirmPassword)
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL16"));
        else if (this.pageSource == "forgotPass")
          this.processChangeForgetPassword();
        else
          this.processChangePassword()
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangepasswordPage', 'changePassword', error);
    }
  }

  /**
   * Desc: show password click on eye icon
   * Developer : Megha Phate
   * Date : 13 Aug 2020
 */
  hideShowPassword() {
    this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
    this.passwordIcon = this.passwordIcon === 'eye-off-icon' ? 'eye-icon' : 'eye-off-icon';
    this.showPassword = this.passwordType == 'text' ? true : false;

  }

  hideShowNewPassword() {
    this.newPasswordType = this.newPasswordType === 'text' ? 'password' : 'text';
    this.newPasswordIcon = this.newPasswordIcon === 'eye-off-icon' ? 'eye-icon' : 'eye-off-icon';
    this.showNewPassword = this.newPasswordType == 'text' ? true : false;

  }

  hideShowConfirmPassword() {
    this.confirmPasswordType = this.confirmPasswordType === 'text' ? 'password' : 'text';
    this.confirmPasswordIcon = this.confirmPasswordIcon === 'eye-off-icon' ? 'eye-icon' : 'eye-off-icon';
    this.showConfirmPassword = this.confirmPasswordType == 'text' ? true : false;
  }
  showPasswordPolicy() {
    try {
     // this.httpService.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_PASSWORD_POLICY_FILE).subscribe((respData: string) => {
     //change for cloud front hosting.
      this.httpService.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_PASSWORD_POLICY_FILE).subscribe((respData: string) => {
     //let PasswordPolicyData = respData;
        // let profileModal = this.modalCtrl.create('PasswordPolicyPage', { data: PasswordPolicyData }, { enableBackdropDismiss: true, cssClass: clsGlobal.defaultTheme });
        // profileModal.present();
      }, error => {
        //      this.toastCtrl.showAtBottom("Unable to show password policy");
        //        clsGlobal.logManager.writeErrorLog('SettingPage', 'showPasswordPolicy', error);
      });
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to show password policy");
      clsGlobal.logManager.writeErrorLog('ChangepasswordPage', 'showPasswordPolicy', error);
    }
  }

  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.oldPassError = '';
      this.newPassError = '';
      this.confirmPassError = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangepasswordPage', 'onKeyUp', error);
    }
  }

  processChangeForgetPassword() {
    try {
      let encryptNewPassword = clsCommonMethods.TripleDESEncrypt(this.newPassword.trim());

      let reqLogin = {        
        otp: this.otp,
        messageCode: clsConstants.C_V_MSGCODE_FORCELOGIN,
        userId: this.userID,
        groupId: clsGlobal.User.groupId.toUpperCase(),
        newPassword: encryptNewPassword,
        productMode: clsConstants.C_V_PHOENIX_MOBILE,
        mobileNo: this.mobile,
        loginType: '',
        deviceType: clsGlobal.DeviceType,
        ocToken: clsGlobal.User.OCToken
      };

      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + clsGlobal.versionId+ '/forgetChangePass', reqLogin).subscribe(resLogin => {
        try {
          if (resLogin.status == true) {
            if (resLogin.result.logonStatusCode == 10013) { // password already used.
              //resLogin.result.logonMessage.split('|')[1]
              this.alertObj.showAlertCallbackWithSingleButton("Your password should not be same as previous password").then((success) => {
                this.newPassword = '';
                this.confirmPassword = '';
                let pageSource = "forgotIncorrectPass";
                this.paramService.myParam = pageSource;
                this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
              });
            }
            else if (resLogin.result.logonStatusCode == 10002) { // Invalid client Id or password
              this.alertObj.showAlertCallbackWithSingleButton(resLogin.result.logonMessage).then((success) => {
                //this.oldPassword = '';
                this.newPassword = '';
                this.confirmPassword = '';
                let pageSource = "forgotIncorrectPass";
                this.paramService.myParam = pageSource;
                this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
              });
            }
            else if (resLogin.result.logonStatusCode == 10005) {
              // UserAcoount is locked.
              this.alertObj.showAlertCallbackWithSingleButton(clsGlobal.dMsgMaster.getItem("NNSL280")).then((success) => {
                //this.oldPassword = '';
                this.newPassword = '';
                this.confirmPassword = '';
                let pageSource = "forgotIncorrectPass";
                this.paramService.myParam = pageSource;
                this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
              });
            }
            else {
             // this.toastCtrl.showAtBottom('Password Changed Successfully');
             this.changeMpinLoader = !this.changeMpinLoader;
             setTimeout(()=>{
              this.onCancelPasswordRequest();
              this.navCtrl.navigateRoot('signin');
             },3000)
             
            }
          }
          else if (resLogin.status == false) {
            if(resLogin.errorCode == 1020)
            {
              this.toastCtrl.showAtBottom(resLogin.errorString);
              let pageSource = "forgotOTPPass";
              this.paramService.myParam = pageSource;
              this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
            }
            else
            {
              let pageSource = "forgotIncorrectPass";
              this.paramService.myParam = pageSource;
              this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
              this.alertObj.showAlertCallbackWithSingleButton(resLogin.errorString);
            }
          }
          else {
            this.toastCtrl.showAtBottom('Error Occured while changing the password');
          }
        } catch (error) {
          console.log(error);
        }
      }, error => {
        //this.loadingCtrl.hideLoader();
        clsGlobal.logManager.writeErrorLog('ChangePasswordPage', 'processChangePassword', error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  goBack() {
    this.navCtrl.pop();
  }
}
