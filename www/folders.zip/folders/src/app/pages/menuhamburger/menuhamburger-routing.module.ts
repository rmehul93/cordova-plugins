import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MenuhamburgerPage } from './menuhamburger.page';

const routes: Routes = [
  {
    path: '',
    component: MenuhamburgerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MenuhamburgerPageRoutingModule {}
