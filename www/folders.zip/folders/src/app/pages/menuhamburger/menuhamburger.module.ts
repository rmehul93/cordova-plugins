import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MenuhamburgerPageRoutingModule } from './menuhamburger-routing.module';

import { MenuhamburgerPage } from './menuhamburger.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MenuhamburgerPageRoutingModule
  ],
  declarations: [MenuhamburgerPage]
})
export class MenuhamburgerPageModule {}
