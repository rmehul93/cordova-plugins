import { Component, OnInit } from '@angular/core';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-menuhamburger',
  templateUrl: './menuhamburger.page.html', 
})
export class MenuhamburgerPage implements OnInit {

  userName :string ="";
  email : string ="";
  
  constructor(private httpService: clsHttpService,
    private toastProvider: ToastServicesProvider,) { 
    
  }

  ngOnInit() {
    this.getProfileData();
  }

  /**
   * Sonali Dongare
   * Desc : To get user profile data
   */
  async getProfileData(){
    try{

      if(clsGlobal.User.bankdetails.length > 0 && clsGlobal.User.bankdetails!=null){
        this.userName = clsGlobal.User.userName ;       
        this.email = clsGlobal.User.email;
      }
      else{ 
      this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication+"/v1/user/profile").subscribe(data=>{

        let profileDetails : any = data;
      
        if(profileDetails.status == "success"){
            this.userName = clsGlobal.User.userName = profileDetails.data.user_name;
            this.email = clsGlobal.User.email= profileDetails.data.email;
            clsGlobal.User.mobile= profileDetails.data.mobile_no;
            clsGlobal.User.PAN= profileDetails.data.pan;
            clsGlobal.User.address= profileDetails.data.address;
            clsGlobal.User.bankdetails=profileDetails.data.bank_details
            
        }
        else {
          this.toastProvider.showAtBottom("Error in getting profile data");
          
        }
      }, error =>{
        //clsGlobal.logManager.writeErrorLog("MenuhamburgerPage", "getProfileData_1", error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getProfileData',error.Message,undefined,error.stack,undefined,undefined));
        this.toastProvider.showAtBottom("Error in getting profile data");
      })
      }
    }catch(error){
      //clsGlobal.logManager.writeErrorLog("MenuhamburgerPage", "getProfileData_2", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getProfileData2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  showProfile(){
    
  }

  showSettings(){

  }

  showRecommendation(){

  }

}
