import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CalculatorsFairvaluePage } from './calculators-fairvalue.page';

const routes: Routes = [
  {
    path: '',
    component: CalculatorsFairvaluePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CalculatorsFairvaluePageRoutingModule {}
