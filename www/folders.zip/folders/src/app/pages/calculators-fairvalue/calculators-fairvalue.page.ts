import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonInput } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsScrip } from 'src/app/Common/clsScrip';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-calculators-fairvalue',
  templateUrl: './calculators-fairvalue.page.html', 
})
export class CalculatorsFairvaluePage implements OnInit {

  constructor(public navCtrl: NavController,
    public http: clsHttpService,
    public alertCtrl: AlertServicesProvider,
    private toastCtrl: ToastServicesProvider,) { }

  @ViewChild('inputId',{static : false}) inputId : IonInput;
  popupContractDays:boolean=false;
  sSymbol : any = '';
  searchcomplete : boolean = false;
  scripArrayList : any = [];
  expiryDate : any = '';
  currentDate : any;
  difference : any = '';
  LTP : any = '';
  dividend : any = '';
  interestrate : any = '';
  instrumentName : any;
  exchange : any;
  description : any;
  checked : boolean = true;
  calculateFair : boolean = false;
  fairValue : any;
  selectedScripObj : any;
  token : any;
  marketsegmentid : any;
  showPopUpOE: boolean = false;
  selectedScrip : any;
  originalList : any = [];
  showFullMode:boolean =false;
  scripexpiry : any;
  scripprice : any;
  disableFair : boolean = true;
  tempexpirylist : any = [];
  expiryDayDiffList : any = [];

  ngOnInit() {
    this.currentDate = new Date();
  }

  ionViewDidEnter(){
    try {
      clsGlobal.User.CalculatorType = 'FUTURE';      
      if(clsGlobal.User.searchScrip){
        this.dividend = '';
        this.interestrate = '';
        this.calculateFair = false;
        this.popupContractDays = false;
        this.disableFair = true;
        this.expiryDate = '';
        this.difference = ''
        this.scripArrayList = [];
        this.originalList = [];
        this.expiryDayDiffList = [];
        this.tempexpirylist = [];
        this.sSymbol = clsGlobal.User.selectedScrip._source.sSymbol;
        this.LTP = clsGlobal.User.selectedScrip._source.LTP;
        this.instrumentName = clsGlobal.User.selectedScrip._source.sInstrumentName.substring(0,3);
        this.exchange = clsGlobal.User.selectedScrip._source.sExchange;
        this.description = clsGlobal.User.selectedScrip._source.sDerivitiveDesc.split('--')[0];
        this.searchcomplete = true;      
        this.scripArrayList = clsGlobal.User.selectedArray;
        this.token = clsGlobal.User.selectedScrip._source.nToken;
        this.marketsegmentid = clsGlobal.User.selectedScrip._source.nMarketSegmentId;
        for(let count = 0 ; count < this.scripArrayList.length; count++)
        {
          if(this.tempexpirylist.indexOf(this.scripArrayList[count]._source.nExpiryDate1) == -1)
          {
            if(this.scripArrayList[count]._source.nExpiryDate1 != '' && this.scripArrayList[count]._source.nExpiryDate1 != undefined)
            {
              this.tempexpirylist.push(this.scripArrayList[count]._source.nExpiryDate1);
              this.expiryDayDiffList.push({daysDifference : this.dateDiffernece(this.scripArrayList[count]._source.nExpiryDate1),
                Day : new Date(this.scripArrayList[count]._source.nExpiryDate1).getDate(),
                Month : (new Date(this.scripArrayList[count]._source.nExpiryDate1).toLocaleString('default',{month : 'short'})).toUpperCase(),
                Year : new Date(this.scripArrayList[count]._source.nExpiryDate1).getFullYear().toString().substr(-2),
                Date : new Date(this.scripArrayList[count]._source.nExpiryDate1).getDate()+' '+(new Date(this.scripArrayList[count]._source.nExpiryDate1).toLocaleString('default',{month : 'short'})).toUpperCase()+' '+"'"+new Date(this.scripArrayList[count]._source.nExpiryDate1).getFullYear().toString().substr(-2),
                selected : false
              });
            }
          }
        }

        if(clsGlobal.User.selectedScrip._source.sInstrumentName == 'EQUITIES' || clsGlobal.User.selectedScrip._source.sInstrumentName == '')
        {
          if(this.expiryDayDiffList.length > 0)
          {
          this.dateFormation(this.expiryDayDiffList[0].Date);
          this.difference = this.dateDiffernece(this.expiryDayDiffList[0].Date);
          }
        }
        else
        {
          this.dateFormation(clsGlobal.User.selectedScrip._source.nExpiryDate1);
          this.difference = this.dateDiffernece(clsGlobal.User.selectedScrip._source.nExpiryDate1);
        }
        this.originalList = this.expiryDayDiffList;
        clsGlobal.User.selectedArray = [];
        clsGlobal.User.selectedScrip = ''
        clsGlobal.User.searchScrip = false;
      }      
    } catch (error) {
     console.log(error); 
    }
  }
  
  goBack()
  {
    this.navCtrl.pop();
  }

  showContractDays()
  {
    this.popupContractDays = true;
    this.setFocusOnInput();
  }

  setFocusOnInput(){
    this.inputId.setFocus();
  }

  hideContractDays(){
    this.popupContractDays = false;
    this.removeFocusOnInput();
    this.expiryDayDiffList = this.originalList;
  }

  removeFocusOnInput(){
    this.inputId.getInputElement().then(
      inputElement => inputElement.blur()
    );
  }

  showLookUp()
  {
    this.navCtrl.navigateForward('/calculator-lookup');
  } 

  /** <Norwin Dcruz> <05/01/2021> <Toselect contract days and expiry date> **/
  selectedItem(item) {
    try {
        this.difference = item.daysDifference;
        this.expiryDate = item.Day + ' ' + item.Month + ' ' + "'" + item.Year;
        this.exchange = item.sExchange;
        this.expiryDayDiffList = this.originalList;
        this.checkFairValue(this.expiryDate,'expiryDate');
        this.hideContractDays();
    } catch (error) {
      console.log(error);
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To format date according to UI> **/
  dateFormation(inputdate)
  {
    try {
      let dateformat = new Date(inputdate)
      let sDate = dateformat.getDate();
      let sMonth = (dateformat.toLocaleString('default',{month : 'short'})).toUpperCase();
      let nYear = dateformat.getFullYear().toString().substr(-2);
      this.expiryDate = sDate+' '+sMonth+' '+"'"+nYear;      
    } catch (error) {
      console.log(error);
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To get day from current date to expiry date> **/
  dateDiffernece(inputdate)
  {
    let nextdate : any = new Date(inputdate);
    let diffTime = Math.abs(nextdate - this.currentDate);
    let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24 ));
    return diffDays;
  }

  /** <Norwin Dcruz> <05/01/2021> <To add or subtract from interest rate field> **/
  plusminus(item, type) {
    try {
      if (type == 'interest') {
        if (this.interestrate == '' || this.interestrate == null)
          this.interestrate = 0;
        if (item == 'plus') {
          this.interestrate = parseFloat(this.interestrate) + 1;
        }
        else if (item == 'minus') {
          if (parseFloat(this.interestrate) <= 0) {
            this.checkFairValue(this.interestrate,'interestrate');
            return;
          }
          this.interestrate = parseFloat(this.interestrate) - 1;
        }
        this.checkFairValue(this.interestrate,'interestrate');
      }
      else if (type == 'contract') {
        if(this.difference == '' || this.difference == null)
        this.difference = 0;
        this.popupContractDays = false;
        if (item == 'plus') {
          this.difference = parseFloat(this.difference) + 1;
        }
        else if (item == 'minus') {
          if (parseFloat(this.difference) <= 0)
          {
            this.checkFairValue(this.difference,'difference');
            return;
          }
          this.difference = parseFloat(this.difference) - 1;
        }
        this.checkFairValue(this.difference,'difference');
      }
    } catch (error) {
      console.log(error);
    }
  }

  /** <Norwin Dcruz> <06/01/2021> <To clear fields> **/
  clearFields(){
    this.hideContractDays();
    this.LTP = '';
    this.expiryDate = '';
    this.instrumentName = '';
    this.searchcomplete = false;
    this.sSymbol = '';
    this.scripArrayList = [];
    this.expiryDayDiffList = [];
    this.tempexpirylist = [];
    this.originalList = [];
    this.difference = '';
    this.dividend = '';
    this.interestrate = '';
    this.exchange = '';
    this.description = '';
    this.calculateFair = false;
    this.popupContractDays = false;
    this.disableFair = true;
  }

  calculateFairValue()
  {
    this.hideContractDays();
    try {
      if(this.validateFairValues())
      {
        this.calculateFair = true;
        let dblIndex = parseFloat(this.LTP);
        let dblInterest = parseFloat(this.interestrate);
        let dblDividend = parseFloat(this.dividend);
        let dblContractDays = parseFloat(this.difference);
        this.scripexpiry = this.expiryDate;
        this.scripprice = parseFloat(this.LTP).toFixed(2);
        this.fairValue = this.CalcFairValue(dblIndex,dblInterest,dblDividend,dblContractDays);
      }      
    } catch (error) {
      console.log(error)
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To validate fields> **/
  validateFairValues() {
    try {

      if (this.LTP == undefined || this.LTP == '' || this.LTP == null || parseFloat(this.LTP) == 0) {
        this.alertCtrl.showAlert('Scrip Price is not valid');
        return false;
      }

      if (parseFloat(this.LTP) < 0.0001 || parseFloat(this.LTP) > 99999.9999) {
        this.alertCtrl.showAlert("Please enter Price between 0.0001 and 99999.9999");
        return false;
      }

      if (this.difference == undefined || this.difference == '' || this.difference == null || parseFloat(this.difference) == 0) {
        this.alertCtrl.showAlert('Contract Days is not valid');
        return false;
      }

      if (parseFloat(this.difference) < 0 || parseFloat(this.difference) > 9999) {
        this.alertCtrl.showAlert('Please enter Contract Days between 0 and 9999');
        return false;
      }

      // Validations for Interest Rates ...
      if ((this.interestrate) == null) {
        this.alertCtrl.showAlert('Please enter Interest Rate');
        return false;
      }

      if (parseFloat(this.interestrate) < 0 || parseFloat(this.interestrate) > 99.99) {
        this.alertCtrl.showAlert('Please enter Interest Rate between 0 and  99.99');
        return false;
      }

      if (isNaN(parseFloat(this.interestrate))) {
        this.alertCtrl.showAlert('Please Enter Valid Interest Rate');
        return false;
      }

      // Validations for Dividend ...
      if ((this.dividend) == null) {
        this.alertCtrl.showAlert('Please enter Dividend');
        return false;
      }

      if (parseFloat(this.dividend) < 0 || parseFloat(this.dividend) > 999.99) {
        this.alertCtrl.showAlert('Please enter Dividend between 0.00 and 999.99');
        return false;
      }

      if (isNaN(parseFloat(this.dividend))) {
        this.alertCtrl.showAlert('Please Enter Valid Dividend');
        return false;
      }

      if(this.originalList.length > 0)
      {
        let expirypresent = false;
        for (let counter = 0; counter < this.originalList.length; counter++) {
          if (this.originalList[counter].Date == this.expiryDate) {
            expirypresent = true;
          }
        }
  
        if(!expirypresent)
        {
          this.alertCtrl.showAlert('Enter Proper Expiry in Contract Days');
          return false;
        }
      }

      return true;

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('CalculatorsFairvaluePage', 'validateFairValues', error);
    }
  }

  checkFairValue(event,type){
    if(type == 'LTP'){
      this.LTP = event;
    }
    else if(type == 'dividend'){
      this.dividend = event;
    }
    else if(type == 'interestrate'){
      this.interestrate = event;
    }
    else if(type == 'difference'){
      this.difference = event;
    } else if(type == 'expiryDate'){
      this.expiryDate = event;
    }

    if(this.interestrate == null)
    this.interestrate = '';

    if(this.difference == null)
    this.difference = '';

    if(this.dividend == null)
    this.dividend = '';

    let tempInterestRate = this.interestrate.toString();
    let tempDifference = this.difference.toString();

    this.dividend = this.dividend.toString();

    if(this.expiryDayDiffList.length == 0)
    {
      if((this.LTP == '' || this.LTP == undefined || this.dividend == '' || tempInterestRate == '' || tempDifference == '' || this.sSymbol == '')){
        this.disableFair = true;
      }
      else
      {
        this.disableFair = false;
      }
    }
    else
    {
      if((this.LTP == '' || this.LTP == undefined || this.dividend == '' || tempInterestRate == '' || tempDifference == '' || this.sSymbol == '' || this.expiryDate == '')){
        this.disableFair = true;
      }
      else
      {
        this.disableFair = false;
      }
    }

  }

  /** <Norwin Dcruz> <06/01/2021> <To calculate fair value for future scrip> **/
  CalcFairValue(indexprice,interestprice,dividend,contractdays){
    let FairValue:any;
    try {
      let dblExpo = Math.pow(2.71, ((interestprice / 100) * (contractdays / 365)));
      FairValue = (((indexprice * dblExpo) - dividend)).toFixed(4);
      FairValue = clsTradingMethods.formatNumber(parseFloat(FairValue), 4);
    } catch (error) {
      FairValue = '';
      clsGlobal.logManager.writeErrorLog('CalculatorsFairvaluePage', 'CalcFairValue', error);
    }
    return FairValue

  }

  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode=false;
  }

  onFocus(event){
    this.showFullMode=true;
  }

  /** <Norwin Dcruz> <05/01/2021> <To open Order Entry Popup> **/
  showPopUpOrderEntry() {
    try {
      if (clsGlobal.User.isGuestUser) {
        this.alertCtrl.showAlert(
          "Register now to access this feature!",
          "Order Error!"
        );
        return;
      }
      let expiry = new Date(this.expiryDate).getDate()+(new Date(this.expiryDate).toLocaleString('default',{month : 'short'})).toUpperCase()+new Date(this.expiryDate).getFullYear();
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getScripFromInstrumentAndExchange/" + 'FUT' + "/" + expiry + "/" + this.sSymbol).subscribe(resp => {
        let response : any = resp;
        this.selectedScripObj = response.result.hits.hits[0]._source;
        let SegmentId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
          this.alertCtrl.showAlert(
            "You are currently not allowed to place/modify/cancel order in this segment",
            "Order Error!"
          );
          return;
        }
    
        this.showPopUpOE = !this.showPopUpOE;
        let currScrip: clsScrip = new clsScrip();
        currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        currScrip.scripDet.token = this.selectedScripObj.nToken;
        currScrip.symbol = this.selectedScripObj.sSymbol.trim();
        currScrip.Series = this.selectedScripObj.sSeries;
        currScrip.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        currScrip.ExpiryDate = this.selectedScripObj.nExpiryDate1;
        currScrip.StrikePrice = this.selectedScripObj.nStrikePrice1 || "-1";
        currScrip.OptionType = this.selectedScripObj.sOptionType || "NA";
        currScrip.MarketLot = this.selectedScripObj.nRegularLot || 1;
        currScrip.PriceTick = this.selectedScripObj.nPriceTick || 1;
        //this.selectedScrip = currScrip;
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
        // objOEFormDetail.buyPrice = this.selBidPrice;
        // objOEFormDetail.sellPrice = this.selAskPrice;
        // objOEFormDetail.closePrice = this.closePrice;
        // objOEFormDetail.ltp = this.scripLTP;
        objOEFormDetail.scripDetl = currScrip;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.selectedScrip = objOEFormDetail;
      }, error => {
        this.toastCtrl.showAtBottom("Unable to open Order Entry");
        clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'showPopUpOrderEntry', error);
      });
    
    } catch (error) {
      console.log(error);
    }
  }

  searchContract(event){
    this.popupContractDays = true;
    if(event == '')
    {
      this.expiryDayDiffList = this.originalList;
      this.checkFairValue(event,'expiryDate');
      return;
    }
    let search = event.toUpperCase();
    this.checkFairValue(event,'expiryDate');
    let tempList = [];
    for (let counter = 0; counter < this.originalList.length; counter++) {
      let Date = this.originalList[counter].Date;
      if (Date.includes(search)) {
        tempList.push(this.originalList[counter]);
      }
    }
    this.expiryDayDiffList = tempList;
  }
}
