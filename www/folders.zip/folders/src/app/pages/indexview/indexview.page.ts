import { clsHttpService } from './../../Common/clsHTTPService';
import { CDSServicesProvider } from './../../providers/cds-services/cds.services';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { NavigationExtras } from '@angular/router';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-indexview',
  templateUrl: './indexview.page.html', 
  styleUrls: ['./indexview.scss'],
})
export class IndexviewPage implements OnInit {
  showSelectpopup: boolean = false; 
  selectedTab:any="FAVOURITES";
  bcastHandler: any;
  templocalIndicesScripts: Dictionary<any> = new Dictionary<any>();
  localScripKey: any = [];
  //localIndices : any =  [];
  globalIndices :any = [];
  currentExchange : any;
  listExchange : any = [];
  localIndexDetailsList : any = [];
  favouriteDetails : any = [];
  tempFavIndices : any = [];
  filterObject: any = {};
  tempGlobalList : any = [];
  isFilterApply : boolean = false;
  @ViewChild('divIndexFilter', { static: false }) divIndexFilter: ElementRef;
  showExpandedIndexFilter: boolean = false;
  indexFilterPane: any;
  showFilterPopup: boolean = false;
  disableApply : boolean = false;
  dateExpression = /(\d{4})-(\d{2})-(\d{2}) (\d{2})(\d{2})(\d{2})/;
  cmotMode:any;
  constructor(private navCtrl: NavController,
    private cdsService : CDSServicesProvider,
    private httpService: clsHttpService,    
    public objStorage: clsLocalStorageService,
    public dateFormatter: DatePipe, ) { }

  ngOnInit() {
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.cmotMode = clsGlobal.CMOTMode;
  }

  /** <Norwin Dcruz> <02/12/2020> <To get data from LOCAL Storage> **/
  async ionViewWillEnter() {
    try {
      this.favouriteDetails = [];
      if(Object.keys(this.filterObject).length == 0)
      {
        this.disableApply = true;
      }
      else
      {
        this.disableApply = false;
      }
      await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES)
        .then((item: any) => {
          clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
          this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);          
          this.localScripKey = [];
          if(item != null && item != undefined && item != '')
          {
            this.favouriteDetails = JSON.parse(item);
            this.tempFavIndices = this.favouriteDetails;
            for(let i = 0 ; i < this.favouriteDetails.length ; i++){
              if(this.favouriteDetails[i].Global != true)
              {
                this.favouriteDetails[i].LTP = "0.00";
                this.favouriteDetails[i].NetChangeInRs = "0.00";
                this.favouriteDetails[i].LTPTrend = '';
                this.favouriteDetails[i].colorTrend = '';
                this.favouriteDetails[i].PercNetChange = "0.00";
                this.favouriteDetails[i].percentage = "0.00";
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token =  this.favouriteDetails[i].nToken;
                objScrpKey.MktSegId =this.favouriteDetails[i].nMarketSegmentId
                this.localScripKey.push(objScrpKey);
              }
            }
            if(this.selectedTab.toUpperCase() == 'FAVOURITES')
            {
              this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
            }            
          }          
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if(this.selectedTab.toUpperCase() == 'LOCAL'){
        this.localScripKey = [];
        this.getAllDomesticIndices(); 
      }
      else if(this.selectedTab.toUpperCase() == 'GLOBAL')
      {
        this.localScripKey = [];
        this.getWorldIndicesData();
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewPage', 'ionViewWillEnter', error);
    }
  }

  /** <Norwin Dcruz> <22/01/2021> <To filter index constituents based on selection provided> **/
  setIndexFilter(filterName: any, filterValue: any) {
    try {
      this.filterObject = {};
      switch (filterName) {
        case 'sortalpha':
          this.filterObject.sortalpha = filterValue;
          break;
        case 'pricesort':
          this.filterObject.pricesort = filterValue;
          break;
        case 'percentagesort':
          this.filterObject.percentagesort = filterValue;
          break;
        }  
        if(Object.keys(this.filterObject).length == 0)
        {
          this.disableApply = true;
        }
        else
        {
          this.disableApply = false;
        }  
    } catch (error) {
      console.log(error);
    }
  }

  applySortFilter() {
    this.isFilterApply = true;
    this.showFilterPopup = false;

    if(this.selectedTab.toUpperCase() == 'FAVOURITES')
    {
      if (this.favouriteDetails.length > 0) {
        if (this.filterObject.sortalpha == 'asc') {
          this.favouriteDetails.sort((a, b) => {
            return a.sIndexDesc.localeCompare(b.sIndexDesc);
          })
        } else if (this.filterObject.sortalpha == 'desc') {
          this.favouriteDetails.sort((a, b) => {
            return b.sIndexDesc.localeCompare(a.sIndexDesc);
          })
        }
  
        if (this.filterObject.pricesort == 'asc') {
          this.favouriteDetails.sort((a, b) => {
            return parseFloat(a.LTP) > parseFloat(b.LTP) ? 1 : -1;
          })
        } else if (this.filterObject.pricesort == 'desc') {
          this.favouriteDetails.sort((a, b) => {
            return parseFloat(a.LTP) < parseFloat(b.LTP) ? 1 : -1;
          })
        }

        if (this.filterObject.percentagesort == 'asc') {
          this.favouriteDetails.sort((a, b) => {
            return parseFloat(a.percentage) > parseFloat(b.percentage) ? 1 : -1;
          })
        } else if (this.filterObject.percentagesort == 'desc') {
          this.favouriteDetails.sort((a, b) => {
            return parseFloat(a.percentage) < parseFloat(b.percentage) ? 1 : -1;
          })
        }
      }
    }
    else if(this.selectedTab.toUpperCase() == 'LOCAL')
    {
      if (this.localIndexDetailsList.length > 0) {
        if (this.filterObject.sortalpha == 'asc') {
          this.localIndexDetailsList.sort((a, b) => {
            return a.sIndexDesc.localeCompare(b.sIndexDesc);
          })
        } else if (this.filterObject.sortalpha == 'desc') {
          this.localIndexDetailsList.sort((a, b) => {
            return b.sIndexDesc.localeCompare(a.sIndexDesc);
          })
        }
  
        if (this.filterObject.pricesort == 'asc') {
          this.localIndexDetailsList.sort((a, b) => {
            return parseFloat(a.LTP) > parseFloat(b.LTP) ? 1 : -1;
          })
        } else if (this.filterObject.pricesort == 'desc') {
          this.localIndexDetailsList.sort((a, b) => {
            return parseFloat(a.LTP) < parseFloat(b.LTP) ? 1 : -1;
          })
        }

        if (this.filterObject.percentagesort == 'asc') {
          this.localIndexDetailsList.sort((a, b) => {
            return parseFloat(a.percentage) > parseFloat(b.percentage) ? 1 : -1;
          })
        } else if (this.filterObject.percentagesort == 'desc') {
          this.localIndexDetailsList.sort((a, b) => {
            return parseFloat(a.percentage) < parseFloat(b.percentage) ? 1 : -1;
          })
        }
      }
    }
    else if(this.selectedTab.toUpperCase() == 'GLOBAL')
    {
      if (this.tempGlobalList.length > 0) {
        if (this.filterObject.sortalpha == 'asc') {
          this.tempGlobalList.sort((a, b) => {
            return a.sIndexDesc.localeCompare(b.sIndexDesc);
          })
        } else if (this.filterObject.sortalpha == 'desc') {
          this.tempGlobalList.sort((a, b) => {
            return b.sIndexDesc.localeCompare(a.sIndexDesc);
          })
        }
  
        if (this.filterObject.pricesort == 'asc') {
          this.tempGlobalList.sort((a, b) => {
            return parseFloat(a.LTP) > parseFloat(b.LTP) ? 1 : -1;
          })
        } else if (this.filterObject.pricesort == 'desc') {
          this.tempGlobalList.sort((a, b) => {
            return parseFloat(a.LTP) < parseFloat(b.LTP) ? 1 : -1;
          })
        }

        if (this.filterObject.percentagesort == 'asc') {
          this.tempGlobalList.sort((a, b) => {
            return parseFloat(a.percentage) > parseFloat(b.percentage) ? 1 : -1;
          })
        } else if (this.filterObject.percentagesort == 'desc') {
          this.tempGlobalList.sort((a, b) => {
            return parseFloat(a.percentage) < parseFloat(b.percentage) ? 1 : -1;
          })
        }

        this.globalIndices = [];
        let allCountry = this.tempGlobalList.map(item=>item.IndexCountry).filter((value,index,self)=>{return self.indexOf(value)==index});
        Object.values(allCountry).forEach((country:any) => {
          this.globalIndices.push({key : country , value: this.tempGlobalList.filter(index=>{ return index.IndexCountry ==country  })})
        });
      }
    }
  }

  getIndexFiltersCount() {
    return Object.keys(this.filterObject).length;
  }

  /** <Norwin Dcruz> <11/12/2020> <To remove filter> **/
  removeFilter(filterName){
    try {
      switch (filterName) {
        case 'sortalpha':
          delete this.filterObject.sortalpha
          break;
        case 'pricesort':
          delete this.filterObject.pricesort
          break;
        case 'percentagesort':
          delete this.filterObject.percentagesort;
          break;
      }
  
      if (this.getIndexFiltersCount() == 0) {
        this.clearFilter();
      } else {
        this.applySortFilter();
      }     
    } catch (error) {
     console.log(error); 
    }
  }

  clearFilter() {
    this.isFilterApply = false;
    this.filterObject = {};
    if(Object.keys(this.filterObject).length == 0)
    {
      this.disableApply = true;
    }
    else
    {
      this.disableApply = false;
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  selectPopup(){
    this.showSelectpopup = !this.showSelectpopup;
  }

  closePopup(){
    this.showSelectpopup = false;
  } 

  /** <Norwin Dcruz> <01/12/2020> <Tab Selection for Favourite,LOCAL and GLOBAL> **/
  async tabSelection(event){
    this.selectedTab = event.detail.value;
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.localScripKey = [];
    if(this.selectedTab.toUpperCase() == 'FAVOURITES')
    {
      await this.ionViewWillEnter();
      if (this.isFilterApply) {
        this.applySortFilter();
      }
    }
    else if(this.selectedTab.toUpperCase() == 'LOCAL')
    {
      await this.getAllDomesticIndices();
      if (this.isFilterApply) {
        this.applySortFilter();
      }     
    }
    else if(this.selectedTab.toUpperCase() == 'GLOBAL')
    {
      await this.getWorldIndicesData();
      if (this.isFilterApply) {
        this.applySortFilter();
      }
    }
  }

  /** <Norwin Dcruz> <01/12/2020> <To get details based on exchange> **/
  exchangeSelect(item){
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.localScripKey = [];
    this.localIndexDetailsList = [];
    this.currentExchange = item;
    this.getIndexOnExchange();
    this.selectPopup();
    this.applySortFilter();
  }

  /** <Norwin Dcruz> <01/12/2020> <To Favourite and Unfavourite Indices> **/
  favUnFavIndices(item){
    try {
      if(item.Favourite == false)
      {
        item.Favourite = true;
        //clsGlobal.lstAllIndicesList[item.Count].Favourite = true;
        this.tempFavIndices.push(item);
        this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES , JSON.stringify(this.tempFavIndices));
      }
      else
      {
        item.Favourite = false;
        //clsGlobal.lstAllIndicesList[item.Count].Favourite = false;
  
        if(item.Global) 
        {
          for (let i = 0; i < this.tempFavIndices.length; i++) {
            if(this.tempFavIndices[i].IndexID == item.IndexID)
            {
              this.tempFavIndices.splice(i, 1);
            }
          }  
          clsGlobal.User.isGlobal = true;      
        } 
        else
        {
          for (let i = 0; i < this.tempFavIndices.length; i++) {
  
            if (this.tempFavIndices[i].nMarketSegmentId == item.nMarketSegmentId &&
              this.tempFavIndices[i].nToken == item.nToken) {
              this.tempFavIndices.splice(i, 1);
            }
          }
          clsGlobal.User.isLocal = true;
        }  
  
        this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES , JSON.stringify(this.tempFavIndices));
        this.favouriteDetails = this.tempFavIndices;
      }            
    } catch (error) {
      console.log(error);
    }    
  }

  /** <Norwin Dcruz> <01/12/2020> <To navigate to index details page with details object> **/
  showIndexDetails(indexDetails)
  {
    if(indexDetails.Global == true){
      return;
    }
    let navigationData : NavigationExtras = {
      queryParams: {
        data : JSON.stringify(indexDetails)
      }
    }
   this.navCtrl.navigateForward(['indexviewdetails'], navigationData);
  }

  /** <Norwin Dcruz & Yogesh K> <01/12/2020> <To get World Indices> **/
  async getWorldIndicesData(){
    try {      
      if(clsGlobal.User.isGlobal == true){
        this.globalIndices = [];
        clsGlobal.User.isGlobal = false;
      }
      if(this.globalIndices.length == 0){
        await this.cdsService.getWorldIndices().then((res:any)=>{
          if(res.ResponseObject.type=='success'){
            let resultArray = res.ResponseObject.resultset;
            for(let i = 0; i < resultArray.length; i++)
            {
              if((resultArray[i].IndexID == '7') ||
              (resultArray[i].IndexID == '6'))
              {
                resultArray[i].hidefavourite = false;
              }
              else
              {
                resultArray[i].hidefavourite = true;
              }
              resultArray[i].Date = clsTradingMethods.getDateandTime(resultArray[i].Date);              
              resultArray[i].Favourite = false;
              resultArray[i].Global = true;
              resultArray[i].sIndexDesc = resultArray[i].IndexName;
              resultArray[i].LTP = resultArray[i].ClosePrice;
              if (parseFloat(resultArray[i].Change) > 0) {
                resultArray[i].NetChangeInRs = ('+' + Math.abs(parseFloat(resultArray[i].Change)).toFixed(2));
                resultArray[i].PercNetChange = ("(+" + Math.abs(parseFloat(resultArray[i].PercentageChange)).toFixed(2) + "%)");
                resultArray[i].colorTrend = 'color-positive';
                resultArray[i].percentage = resultArray[i].PercentageChange;
            } 
            else if (parseFloat(resultArray[i].Change) < 0) {
              resultArray[i].NetChangeInRs = ('-' + Math.abs(parseFloat(resultArray[i].Change)).toFixed(2));
              resultArray[i].PercNetChange = ("(-" + Math.abs(parseFloat(resultArray[i].PercentageChange)).toFixed(2) + "%)");
              resultArray[i].colorTrend = 'color-negative';
              resultArray[i].percentage = resultArray[i].PercentageChange;
            } else {
              resultArray[i].NetChangeInRs = (Math.abs(parseFloat(resultArray[i].Change)).toFixed(2));
              resultArray[i].PercNetChange = (Math.abs(parseFloat(resultArray[i].PercentageChange)).toFixed(2));
              resultArray[i].colorTrend = '';
              resultArray[i].percentage = "0.00";
            }
            if(parseFloat(resultArray[i].PercentageChange) > 0 && parseFloat(resultArray[i].PercentageChange) < 1)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-6';
            }
            else if(parseFloat(resultArray[i].PercentageChange) > 1 && parseFloat(resultArray[i].PercentageChange) < 2)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-5';
            }
            else if(parseFloat(resultArray[i].PercentageChange) > 2 && parseFloat(resultArray[i].PercentageChange) < 5)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-4';
            }
            else if(parseFloat(resultArray[i].PercentageChange) > 5 && parseFloat(resultArray[i].PercentageChange) < 7.5)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-3';
            }
            else if(parseFloat(resultArray[i].PercentageChange) > 7.5 && parseFloat(resultArray[i].PercentageChange) < 10)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-2';
            }
            else if(parseFloat(resultArray[i].PercentageChange) > 10)
            {
              resultArray[i].LTPTrend = 'background-hitmap-mild-1';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < 0 && parseFloat(resultArray[i].PercentageChange) > -1)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-6';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < -1 && parseFloat(resultArray[i].PercentageChange) > -2)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-5';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < -2 && parseFloat(resultArray[i].PercentageChange) > -5)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-4';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < -5 && parseFloat(resultArray[i].PercentageChange) > -7.5)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-3';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < -7.5 && parseFloat(resultArray[i].PercentageChange) > -10)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-2';
            }
            else if(parseFloat(resultArray[i].PercentageChange) < -10)
            {
              resultArray[i].LTPTrend = 'background-hitmap-hot-1';
            }
            else
            {
              resultArray[i].LTPTrend = '';
            }
  
            }
            if(this.favouriteDetails.length > 0)
            {
              for( let i = 0 ; i < this.favouriteDetails.length ; i++){
                for( let j = 0 ; j < resultArray.length ; j++){
                  if(this.favouriteDetails[i].IndexID == resultArray[j].IndexID)
                    {
                      resultArray[j].Favourite = this.favouriteDetails[i].Favourite;
                      break;
                    }
                }
              }
            }
            this.tempGlobalList = resultArray;
            let allCountry = resultArray.map(item=>item.IndexCountry).filter((value,index,self)=>{return self.indexOf(value)==index});
            Object.values(allCountry).forEach((country:any) => {
              this.globalIndices.push({key : country , value: resultArray.filter(index=>{ return index.IndexCountry ==country  })})
            });
          }
      },err=>{
        clsGlobal.logManager.writeErrorLog('IndexviewPage', 'getWorldIndicesData1', err);
      }); 
      }     
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewPage', 'getWorldIndicesData2', error);      
    }
  }

  /** <Norwin Dcruz> <01/12/2020> <To get Domestic Indices> **/
  async getAllDomesticIndices() {
    try {
      if(clsGlobal.User.isLocal == true){
        clsGlobal.lstAllIndicesList = [];
        clsGlobal.User.isLocal = false;
      }
      this.localIndexDetailsList = [];
      if(clsGlobal.lstAllIndicesList.length > 0)
      {
        for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {
  
          let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
          let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);
  
          if(clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1)
          {
            clsGlobal.lstIndicesExchange.push(exchangeName);
          }
  
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
          objScrpKey.MktSegId = marketSegmentId
  
          let indexScrip: any = {};
          indexScrip = {};
          indexScrip.nToken =  clsGlobal.lstAllIndicesList[index].nToken;
          indexScrip.nMarketSegmentId = marketSegmentId;
          indexScrip.Exchange = exchangeName;
          indexScrip.LTP = "0.00";
          indexScrip.NetChangeInRs = "0.00";
          indexScrip.LTPTrend = '';
          indexScrip.colorTrend = '';
          indexScrip.PercNetChange = "0.00";
          indexScrip.percentage = "0.00";
          indexScrip.sIndexDesc =  clsGlobal.lstAllIndicesList[index].sIndexDesc;

          if((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '1') ||
          (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '8'))
          {
            indexScrip.hidefavourite = false;
          }
          else
          {
            indexScrip.hidefavourite = true;
          }          
          
          indexScrip.Favourite = (clsGlobal.lstAllIndicesList[index].Favourite == undefined ? false : clsGlobal.lstAllIndicesList[index].Favourite);
          indexScrip.Count = index;
          indexScrip.Global = false;
          indexScrip.Date = '';
  
          this.templocalIndicesScripts.Add(objScrpKey.toString(), indexScrip);
        }
        if(this.currentExchange == '' || this.currentExchange == undefined)
        this.currentExchange = clsGlobal.lstIndicesExchange[0];
        this.listExchange = clsGlobal.lstIndicesExchange;
        this.getIndexOnExchange();
      }
      else
      {
        await this.httpService.getJson(clsGlobal.VirtualDirectory,clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId +"/getIndexDetails").subscribe((respData: any) => {
          try {
            if (respData.status) {
             clsGlobal.lstAllIndicesList = respData.result;
  
              for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {
  
                let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
                let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);
  
                if(clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1)
                {
                  clsGlobal.lstIndicesExchange.push(exchangeName)
                }
  
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
                objScrpKey.MktSegId = marketSegmentId
        
                let indexScrip: any = {};
                indexScrip = {};
                indexScrip.nToken =  clsGlobal.lstAllIndicesList[index].nToken;
                indexScrip.nMarketSegmentId = marketSegmentId;
                indexScrip.Exchange = exchangeName;
                indexScrip.LTP = "0.00";
                indexScrip.NetChangeInRs = "0.00";
                indexScrip.LTPTrend = '';
                indexScrip.colorTrend = '';
                indexScrip.percentage = "0.00";
                indexScrip.PercNetChange = "0.00";
                indexScrip.sIndexDesc =  clsGlobal.lstAllIndicesList[index].sIndexDesc;

                if((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '1') ||
                (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '8'))
                {
                  indexScrip.hidefavourite = false;
                }
                else
                {
                  indexScrip.hidefavourite = true;
                }  

                indexScrip.Favourite = false;
                indexScrip.Count = index;
                indexScrip.Global = false;
                indexScrip.Date = '';
        
                this.templocalIndicesScripts.Add(objScrpKey.toString(), indexScrip);
              }
              if(this.currentExchange == '' || this.currentExchange == undefined)
              this.currentExchange = clsGlobal.lstIndicesExchange[0];
              this.listExchange = clsGlobal.lstIndicesExchange;
              this.getIndexOnExchange();
            }
          } catch (error) {
            console.log(error);
          }
        },
        error => {
          clsGlobal.logManager.writeErrorLog('IndexviewPage', 'getAllDomesticIndices', error);
        }
      );
      }      
    } catch (error) {
      console.log(error);      
    }
  }

  /** <Norwin Dcruz> <01/12/2020> <To get Index Details based on exchange selected> **/
  getIndexOnExchange(){
    try {
      let tempindices = this.templocalIndicesScripts.Values(); 
      for( let count = 0; count < tempindices.length; count++)
      {
        if(this.currentExchange == tempindices[count].Exchange)
        {
          this.localIndexDetailsList.push(tempindices[count]);
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = tempindices[count].nToken;
          objScrpKey.MktSegId = tempindices[count].nMarketSegmentId
          this.localScripKey.push(objScrpKey);
        }
      }    
      this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
      if(this.favouriteDetails.length > 0)
      {
        for( let i = 0 ; i < this.favouriteDetails.length ; i++){
          for( let j = 0 ; j < this.localIndexDetailsList.length ; j++){
            if(this.favouriteDetails[i].nToken == this.localIndexDetailsList[j].nToken
              && this.favouriteDetails[i].nMarketSegmentId == this.localIndexDetailsList[j].nMarketSegmentId)
              {
                this.localIndexDetailsList[j].Favourite = this.favouriteDetails[i].Favourite;
                break;
              }
          }
        }
      }      
    } catch (error) {
      console.log(error);      
    }
  }

   /**
   * send request for broadcast
   * @param opType
   * @param scripList
   */
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewPage', 'sendTouchlineRequest', error);
    }
  }
  
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

   // console.log("obj", objMultiTLResp)
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        if(this.selectedTab.toUpperCase() == 'FAVOURITES')
        {
          for(let i = 0; i < this.favouriteDetails.length ; i++){
            if(this.favouriteDetails[i].nToken == objMultiTLResp.Scrip.token && 
              this.favouriteDetails[i].nMarketSegmentId == objMultiTLResp.Scrip.MktSegId)
              {
                this.favouriteDetails[i].LTP =  objMultiTLResp.LTP;

                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
                this.favouriteDetails[i].NetChangeInRs = arrNetChange[0];
                this.favouriteDetails[i].PercNetChange = arrNetChange[1];
                this.favouriteDetails[i].colorTrend = arrNetChange[2];
                this.favouriteDetails[i].percentage = arrNetChange[3];
      
                this.favouriteDetails[i].Date = this.formatDisplayDate(objMultiTLResp.LUT,this.dateExpression,undefined);
                
                if(parseFloat(arrNetChange[3]) > 0 && parseFloat(arrNetChange[3]) < 1)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-6';
                }
                else if(parseFloat(arrNetChange[3]) > 1 && parseFloat(arrNetChange[3]) < 2)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-5';
                }
                else if(parseFloat(arrNetChange[3]) > 2 && parseFloat(arrNetChange[3]) < 5)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-4';
                }
                else if(parseFloat(arrNetChange[3]) > 5 && parseFloat(arrNetChange[3]) < 7.5)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-3';
                }
                else if(parseFloat(arrNetChange[3]) > 7.5 && parseFloat(arrNetChange[3]) < 10)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-2';
                }
                else if(parseFloat(arrNetChange[3]) > 10)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-1';
                }
                else if(parseFloat(arrNetChange[3]) < 0 && parseFloat(arrNetChange[3]) > -1)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-6';
                }
                else if(parseFloat(arrNetChange[3]) < -1 && parseFloat(arrNetChange[3]) > -2)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-5';
                }
                else if(parseFloat(arrNetChange[3]) < -2 && parseFloat(arrNetChange[3]) > -5)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-4';
                }
                else if(parseFloat(arrNetChange[3]) < -5 && parseFloat(arrNetChange[3]) > -7.5)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-3';
                }
                else if(parseFloat(arrNetChange[3]) < -7.5 && parseFloat(arrNetChange[3]) > -10)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-2';
                }
                else if(parseFloat(arrNetChange[3]) < -10)
                {
                  this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-1';
                }
                else
                {
                  this.favouriteDetails[i].LTPTrend = '';
                }      
              }
          }
        }
        else if(this.selectedTab.toUpperCase() == 'LOCAL')
        {
        let rScrip = this.templocalIndicesScripts.getItem(objMultiTLResp.Scrip.toString())
        if (rScrip != undefined && rScrip.nToken.toString() == objMultiTLResp.Scrip.token
          && rScrip.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
          nFormat = 2;
          rScrip.LTP = objMultiTLResp.LTP;

          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
          rScrip.NetChangeInRs = arrNetChange[0];
          rScrip.PercNetChange = arrNetChange[1];
          rScrip.colorTrend = arrNetChange[2];
          rScrip.percentage = arrNetChange[3];

          rScrip.Date = this.formatDisplayDate(objMultiTLResp.LUT,this.dateExpression,undefined);

          if(parseFloat(arrNetChange[3]) > 0 && parseFloat(arrNetChange[3]) < 1)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-6';
          }
          else if(parseFloat(arrNetChange[3]) > 1 && parseFloat(arrNetChange[3]) < 2)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-5';
          }
          else if(parseFloat(arrNetChange[3]) > 2 && parseFloat(arrNetChange[3]) < 5)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-4';
          }
          else if(parseFloat(arrNetChange[3]) > 5 && parseFloat(arrNetChange[3]) < 7.5)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-3';
          }
          else if(parseFloat(arrNetChange[3]) > 7.5 && parseFloat(arrNetChange[3]) < 10)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-2';
          }
          else if(parseFloat(arrNetChange[3]) > 10)
          {
            rScrip.LTPTrend = 'background-hitmap-mild-1';
          }
          else if(parseFloat(arrNetChange[3]) < 0 && parseFloat(arrNetChange[3]) > -1)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-6';
          }
          else if(parseFloat(arrNetChange[3]) < -1 && parseFloat(arrNetChange[3]) > -2)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-5';
          }
          else if(parseFloat(arrNetChange[3]) < -2 && parseFloat(arrNetChange[3]) > -5)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-4';
          }
          else if(parseFloat(arrNetChange[3]) < -5 && parseFloat(arrNetChange[3]) > -7.5)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-3';
          }
          else if(parseFloat(arrNetChange[3]) < -7.5 && parseFloat(arrNetChange[3]) > -10)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-2';
          }
          else if(parseFloat(arrNetChange[3]) < -10)
          {
            rScrip.LTPTrend = 'background-hitmap-hot-1';
          }
          else
          {
            rScrip.LTPTrend = '';
          }
        }
      }
      }
    }
    catch (error) {
      console.log('IndexviewPage', 'receiveTouchlineResponse', error);
    }

  }

  formatDisplayDate(sDate, expression, sFormat) {
    let _FormattedDate = "";
    try {
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[1],
          +dateArray[2] - 1, // Careful, month starts at 0!
          +dateArray[3],
          +dateArray[4],
          +dateArray[5],
          +dateArray[6]
        );
        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "MM/dd/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
        let hrFormatDate = clsTradingMethods.getDateandTime(_FormattedDate)
        return hrFormatDate;
      }
    }
    catch (e) {
      //this.toastCtrl.showAtBottom(": " + e.message);
    }
  }

  ionViewWillLeave() {
    clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
  }

  showIndexFilterPopup() {
    this.showFilterPopup = true;
    this.checkForIndexFilterPopupUpElementRendrer();
  }

  checkForIndexFilterPopupUpElementRendrer() {
    const divElement: HTMLElement = document.getElementById('divIndexFilterPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForIndexFilterPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divIndexFilterPopup');
        this.indexFilterPopupBottomToTop(divElement);
      }, 200);
    }
  }

  indexFilterPopupBottomToTop(myElementRef) {
     try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop:true, //added by om on 24 th jan for backdrop display.
        onDidPresent: () => {
          ////console.log("onDidPresent")
        },
  
        // onDrag: () => {
        //   //  //console.log("onDrag");
        // },
        // onDragEnd: () => { 
        //   //console.log("onDragEnd"); 
        // },
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        onTransitionEnd: () => { 
          let topDiv = this.divIndexFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedIndexFilter = true;
          } else {
            this.showExpandedIndexFilter = false;
          }
        },
        onBackdropTap: ()=>{
          //added by omprakash on 24 th jan for backdrop click
          this.closeIndexFilterPopup();
        }
      }
      this.indexFilterPane = new CupertinoPane(myElementRef, setting);
      this.indexFilterPane.enableDrag();
      this.indexFilterPane.present({ animate: true });
     } catch (error) {
       console.log("Error in filter page display "+error);
     }
  }
 
  //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollFilterDetails(event)
  {
    if (event.target.scrollTop > 10) {
      this.indexFilterPane.moveToBreak('top');
      this.showExpandedIndexFilter  = true;
    }
  } 
  closeIndexFilterPopup() {
    this.showFilterPopup = false;
    this.showExpandedIndexFilter = false;
    this.indexFilterPane.destroy({ animate: true });
  }
  exchangeClose(){
    this.showSelectpopup = false;
  }
}
