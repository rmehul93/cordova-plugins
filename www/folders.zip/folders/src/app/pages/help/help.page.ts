import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-help',
  templateUrl: './help.page.html', 
})
export class HelpPage implements OnInit {

  constructor(private navCtrl:NavController) { }

  ngOnInit() {

  }

  goBack()
  {
    this.navCtrl.pop();
  }
}
