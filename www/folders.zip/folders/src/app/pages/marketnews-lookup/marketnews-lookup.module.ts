import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarketnewsLookupPageRoutingModule } from './marketnews-lookup-routing.module';

import { MarketnewsLookupPage } from './marketnews-lookup.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarketnewsLookupPageRoutingModule
  ],
  declarations: [MarketnewsLookupPage]
})
export class MarketnewsLookupPageModule {}
