import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { clsConstants } from 'src/app/Common/clsConstants';
import { Subject } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { OperationType } from 'src/app/Common/clsConstants';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { NavController, IonInput } from '@ionic/angular';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { NavParamService } from 'src/app/providers/nav-param.service';

@Component({
  selector: 'app-marketnews-lookup',
  templateUrl: './marketnews-lookup.page.html'
})
export class MarketnewsLookupPage implements OnInit {
  cardNews: any = [];
  dcTrendingScrip: Dictionary<any> = new Dictionary<any>();
  bcastHandler: any;
  lstScripKey: any = [];
  cardNewsDetails: any = [];
  depthNewsDetails: any = [];
  otherNews: any = [];
  whatshotlist: any = [];
  searchTextNews: any;
  trendingNews: any = [];
  filterHoldingList: any = [];
  filterTrendList: any = [];
  cardOrNewsDetails: any;
  heading: any;
  details: any;
  date: any;
  NewsdetailsPopup: boolean = false;
  showMoreLessScrip: boolean = false;
  whatsHotNewsDetails: any = [];
  @ViewChild('inputId', { static: false }) inputId: IonInput;
  selectedScripObj: any = [];
  showNoDataFound: boolean = false;

  statusMode: any = "";
  showLoader: boolean = false;
  sectorDetailsPopup: boolean = false;
  pageSize: any = 10;
  iPageNo: any = clsConstants.CDS_PAGE_NO;
  noDataFound: boolean = false;
  selectedSector: any = "";
  sectorNewsDescription: any = '';
  sectorHeading: any = '';
  sectorDate: any = '';
  visibleIndex = -1;
  newsData: any = [];
  newsSearchData: any = [];
  tempAnnouncementData: any = [];

  constructor(public navCtrl: NavController,
    public objCDSService: CDSServicesProvider,
    public objHttpService: clsHttpService,
    public objToast: ToastServicesProvider,
    private paramService: NavParamService) { }

  ngOnInit() {
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.statusMode = this.paramService.myParam;
    this.newsData = this.paramService.pageData;
  }

  setFocusOnInput() {
    this.inputId.setFocus();
  }

  ionViewWillEnter() {
    this.cardNews = clsGlobal.cardNewsLst;
    this.dcTrendingScrip = clsGlobal.trendingNewsLst;
    this.cardNewsDetails = clsGlobal.cardNewsDetails;
    this.depthNewsDetails = clsGlobal.depthNewsDetails;
    this.whatshotlist = clsGlobal.EventListScrip;
    for (let counter = 0; counter < this.whatshotlist.length; counter++) {
      this.whatshotlist[counter].LTP = "0.00";
      this.whatshotlist[counter].NetChangeInRs = "0.00";
      this.whatshotlist[counter].PercNetChange = "0.00";
      this.whatshotlist[counter].LTPTrend = "";
    }
    this.trendingNews = this.dcTrendingScrip.Values();
    for (let count = 0; count < this.trendingNews.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.MktSegId = this.trendingNews[count].scripKey._MktSegId;
      objScrpKey.token = this.trendingNews[count].scripKey.token;
      this.lstScripKey.push(objScrpKey);
    }
    for (let count = 0; count < this.whatshotlist.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.MktSegId = this.whatshotlist[count].scripDet._MktSegId;
      objScrpKey.token = this.whatshotlist[count].scripDet.token;
      this.lstScripKey.push(objScrpKey);
    }
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
    this.setFocusOnInput();
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  searchNewsLookup(event) {
    try {
      if (event == '') {
        this.clearSearchNewsLookup();
        return;
      }
      this.showNoDataFound = false;
      let search = event.toUpperCase();
      this.searchTextNews = event.toUpperCase();
      let tempHoldingList = [];
      let tempTrendList = [];
      if (this.statusMode == 'HotPursuit') {
        for (let counter = 0; counter < this.cardNews.length; counter++) {
          let Heading = this.cardNews[counter].Heading.toUpperCase();
          if (Heading.includes(search)) {
            tempHoldingList.push(this.cardNews[counter]);
          }
        }

        for (let counter = 0; counter < this.trendingNews.length; counter++) {
          let Heading = this.trendingNews[counter].scripNews[0].Heading.toUpperCase();
          if (Heading.includes(search)) {
            tempTrendList.push(this.trendingNews[counter]);
          }
        }

        if (tempTrendList.length == 0) {
          for (let counter = 0; counter < this.trendingNews.length; counter++) {
            let Heading = this.trendingNews[counter].symbol.toUpperCase();
            if (Heading.includes(search)) {
              tempTrendList.push(this.trendingNews[counter]);
            }
          }
        }

        this.filterHoldingList = tempHoldingList;
        this.filterTrendList = tempTrendList;

        if (tempHoldingList.length == 0) {
          this.filterHoldingList = [];
        }

        if (tempTrendList.length == 0) {
          this.filterTrendList = [];
        }

        if (this.filterHoldingList.length == 0 && this.filterTrendList.length == 0) {
          this.showNoDataFound = true;
        }
      } else if (this.statusMode == 'News') {
        this.newsSearchData = this.newsData
          .filter(x => (x.Heading.toUpperCase().includes(this.searchTextNews)));
        if (this.newsSearchData.length == 0) {
          this.showNoDataFound = true;
        }
      } else if (this.statusMode == 'Announcement') {
        this.tempAnnouncementData = this.newsData
          .filter(x => (x.Caption.toUpperCase().includes(this.searchTextNews)));
        if (this.tempAnnouncementData.length == 0) {
          this.showNoDataFound = true;
        }
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'searchNewsLookup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'searchNewsLookup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchNewsLookup() {
    try {
      this.searchTextNews = '';
      this.filterTrendList = [];
      this.filterHoldingList = [];
      this.tempAnnouncementData = [];
      this.newsSearchData = [];
      //this.trendingNews = [];
      //this.showSegments = false;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'clearSearchNewsLookup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'clearSearchNewsLookup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        for (let counter = 0; counter < this.trendingNews.length; counter++) {
          if (this.trendingNews[counter].scripKey._MktSegId == objMultiTLResp.Scrip.MktSegId &&
            this.trendingNews[counter].scripKey.token == objMultiTLResp.Scrip.token) {
            this.trendingNews[counter].LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');

            this.trendingNews[counter].NetChangeInRs = arrNetChange[0];
            this.trendingNews[counter].PercNetChange = arrNetChange[1];
            this.trendingNews[counter].LTPTrend = arrNetChange[2];
            this.trendingNews[counter].arrowTrend = arrNetChange[3];
          }
        }

        for (let counter = 0; counter < this.whatshotlist.length; counter++) {
          if (this.whatshotlist[counter].scripDet._MktSegId == objMultiTLResp.Scrip.MktSegId &&
            this.whatshotlist[counter].scripDet.token == objMultiTLResp.Scrip.token) {
            this.whatshotlist[counter].LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');

            this.whatshotlist[counter].NetChangeInRs = arrNetChange[0];
            this.whatshotlist[counter].PercNetChange = arrNetChange[1];
            this.whatshotlist[counter].LTPTrend = arrNetChange[2];
          }
        }

      }
    }
    catch (error) {
      //console.log('MarketNewsPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  ionViewWillLeave() {
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
  }

  showdetailsCardNews(item) {
    try{
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'card'

    for (let count = 0; count < this.cardNewsDetails.length; count++) {
      if ((item.CompanyCode == this.cardNewsDetails[count].CompanyCode) && (item.SNo != this.cardNewsDetails[count].SNo)) {
        this.otherNews.push(this.cardNewsDetails[count]);
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'showdetailsCardNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  showdetailsNews(item) {
    try{
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'news'

    for (let count = 0; count < this.depthNewsDetails.length; count++) {
      if ((item.CompanyCode == this.depthNewsDetails[count].CompanyCode) && (item.Count != this.depthNewsDetails[count].Count)) {
        this.otherNews.push(this.depthNewsDetails[count]);
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'showdetailsNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeNews() {
    this.NewsdetailsPopup = false;
    this.showMoreLessScrip = false;
  }

  showmoreLess() {
    this.showMoreLessScrip = !this.showMoreLessScrip;
  }

  showdetailsWhatsHotNews(item) {
    try{
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'whatshot';

    for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
      if ((item.CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (item.Count != this.whatsHotNewsDetails[count].Count)) {
        this.otherNews.push(this.whatsHotNewsDetails[count]);
      }
    }
  }
    catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'showdetailsWhatsHotNews',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  whatsHotNews(item) {
    this.getWhatsHotScripNews(item.scripDet._MktSegId, item.scripDet.token, 10)
  }

  getWhatsHotScripNews(mktSegId: any, token: any, count: any) {
    try {
      let exchangeName = clsTradingMethods.getApiExchangeName(mktSegId);;
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {
          this.whatsHotNewsDetails = [];
          for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
            let element = data.ResponseObject.resultset[index];
            let newsDetail: any = {};
            newsDetail.Heading = element.Heading.trim();
            newsDetail.ArtText = element.ArtText.trim();
            newsDetail.Date = element.Date.trim();
            newsDetail.CompanyCode = element.CompanyCode.trim();
            newsDetail.Count = index;

            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
            this.whatsHotNewsDetails.push(newsDetail);
          }
          this.NewsdetailsPopup = true;
          this.otherNews = [];
          this.heading = this.whatsHotNewsDetails[0].Heading;
          this.details = this.whatsHotNewsDetails[0].ArtText;
          this.date = this.whatsHotNewsDetails[0].Date;
          this.cardOrNewsDetails = 'whatshot';

          for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
            if ((this.whatsHotNewsDetails[0].CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (this.whatsHotNewsDetails[0].Count != this.whatsHotNewsDetails[count].Count)) {
              this.otherNews.push(this.whatsHotNewsDetails[count]);
            }
          }
        }
      }).catch(error => {
        //clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'getScripNews1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'getScripNews1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'getWhatsHotScripNews2', error);
      // console.log("Error + MarketNewsLookup_getWhatsHotScripNews2 ", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'getScripNews2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  scripInfo(scripobj) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(scripobj.scripKey.MktSegId),
          token: scripobj.scripKey.token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let objScrpKey = new clsScripKey();

        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        objScrpKey.token = this.selectedScripObj.nToken;

        let scripInfo: clsScrip = new clsScrip();
        scripInfo.scripDet = objScrpKey;
        scripInfo.symbol = this.selectedScripObj.sSymbol.trim();
        scripInfo.Series = this.selectedScripObj.sSeries;
        scripInfo.DecimalLocator = this.selectedScripObj.DecimalLocator == "0" ? "100" : this.selectedScripObj.DecimalLocator;
        scripInfo.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        scripInfo.ExpiryDate = (this.selectedScripObj.nExpiryDate1 != null && this.selectedScripObj.nExpiryDate1.toString() != "" && this.selectedScripObj.nExpiryDate1.toString() != "0") ? this.selectedScripObj.nExpiryDate1 : "0";
        scripInfo.OptionType = this.selectedScripObj.sOptionType;
        scripInfo.MarketLot = this.selectedScripObj.nRegularLot;
        scripInfo.PriceTick = this.selectedScripObj.nPriceTick;
        scripInfo.SecurityDesc = this.selectedScripObj.sSecurityDesc;
        scripInfo.MWSecurityDesc = this.selectedScripObj.MWSecurityDesc;
        scripInfo.StrikePrice = this.selectedScripObj.nStrikePrice1.toString();
        scripInfo.ISIN = this.selectedScripObj.sISINCode;
        scripInfo.SPOS = "";
        scripInfo.POS = "";
        scripInfo.AssetToken = this.selectedScripObj.nAssetToken;
        scripInfo.FIILimit = this.selectedScripObj.nFIILimit;
        scripInfo.NRILimit = this.selectedScripObj.nNRILimit;
        scripInfo.MarginTypeIndicator = this.selectedScripObj.nMarginTypeIndicator;
        if (this.selectedScripObj.sInstrumentName.indexOf('IDX') != -1) {
          scripInfo.isIndex = true;
        }
        else {
          scripInfo.isIndex = false;
        }

        scripInfo.formatScripDisplayName()

        let idData = new clsIndexDetail();
        idData.scripDetail = scripInfo;

        this.paramService.myParam = idData.scripDetail;
        this.navCtrl.navigateForward(["/scripinfo"]);

      }).catch(error => {
        this.objToast.showAtBottom("Unable to get Scrip Info");
        //clsGlobal.logManager.writeErrorLog('MarketnewsLookupPage', 'scripInfo', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'scripInfo',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.objToast.showAtBottom("Unable to get Scrip Info")
      //console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'scripInfo2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
  * Api call to get description of sector specific news.
  */
  getSectorNewsDescription(sNo: any) {
    this.showLoader = true;
    let requestString = sNo + "/";
    this.objCDSService.getSectorWiseNewsDetails(requestString).then((resp: any) => {
      try {
        if (resp.ResponseObject.type.toUpperCase() == "SUCCESS" && resp.ResponseObject.recordcount > 0) {
          this.sectorNewsDescription = resp.ResponseObject.resultset[0].ArtText;
          this.sectorHeading = resp.ResponseObject.resultset[0].Heading;
          let date = resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[0] + "/" + clsCommonMethods.getNumericMonth(resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[1].toUpperCase()) + "/" + resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[2] + " " + this.getTimeFormat(resp.ResponseObject.resultset[0].Time)
          this.sectorDate = date;
          this.showLoader = false;
          this.noDataFound = false;
        }
        else {
          this.noDataFound = true;
          this.showLoader = false;
        }
      } catch (error) {
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'getSectorNewsDescription',error.Message,undefined,error.stack,undefined,undefined));
      }

    }).catch(error => {
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'getSectorNewsDescription2',error.Message,undefined,error.stack,undefined,undefined));
      this.showLoader = false;
    });

  }

  showSectorDescription(sector) {
    this.sectorDetailsPopup = !this.sectorDetailsPopup;
    this.getSectorNewsDescription(sector.SNo);
  }

  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Convert time into PM and AM format .
*/
  getTimeFormat(time: any) {
    try{
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time + ' PM';
    } else {
      retTime = time + ' AM';
    }
    return retTime;
  }catch(error)
  {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'getTimeFormat',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeSectorNews() {
    try{
    this.NewsdetailsPopup = false;
    this.sectorDetailsPopup = false;
    this.sectorNewsDescription = '';
    this.sectorHeading = '';
    this.sectorDate = '';
  }catch(error)
  {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketnewsLookupPage', 'closeSectorNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }


  showAnnouncement(i) {
    if (this.visibleIndex === i)
      this.visibleIndex = -1;
    else
      this.visibleIndex = i;
  }
  
}
