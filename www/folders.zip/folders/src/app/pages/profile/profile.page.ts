import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { AlertServicesProvider } from './../../providers/alert-services/alert-services';
import { clsAppConfigConstants } from './../../Common/clsAppConfigConstants';
import { DomSanitizer } from '@angular/platform-browser';
import { LoaderServicesProvider } from './../../providers/loader-services/loader-services';
import { AuthenticationService } from './../../providers/authentication.service';
import { Component, OnInit } from '@angular/core';
import { NavController, MenuController, ActionSheetController, Platform } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsConstants } from 'src/app/Common/clsConstants';
import { BrowserServicesProvider } from 'src/app/providers/browser-services/browser-services';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { FileTransferObject, FileTransfer, FileUploadOptions } from '@ionic-native/file-transfer/ngx';
import { async } from 'rxjs/internal/scheduler/async';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
})
export class ProfilePage implements OnInit {
  editprofile: boolean = false;
  userName: string = "";
  userId: string = "";
  email: string = "";
  mobile: string = "";
  bankDetails = [];
  userAcronym: string = "";
  profilePic: any = "";
  exchangePref: any;
  fcmTopicPref: any;
  inAppNotificationPref: any;
  kycUrl: string = "";
  orderPref: any;
  constructor(private navCtrl: NavController,
    private menutCtrl: MenuController,
    private toastProvider: ToastServicesProvider,
    private authServide: AuthenticationService,
    private localstorageservice: clsLocalStorageService,
    private iab: BrowserServicesProvider,
    public cameraObj: Camera,
    private transfer: FileTransfer,
    private loadingCtrl: LoaderServicesProvider,
    private sanitizer: DomSanitizer,
    public actionSheetCtrl: ActionSheetController,
    private platform: Platform,
    public alertObj: AlertServicesProvider,
    private appSync: AppsyncDbService
  ) { }

  ngOnInit() {
    try {
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_DOWNLOAD_KYC_URL).toString().length > 0) {
        this.kycUrl = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_DOWNLOAD_KYC_URL);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ProfilePage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'ngOnInit', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  ionViewWillEnter() {
    try {
      this.menutCtrl.enable(true);
      this.getUserProfileData();
      if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != "" && clsGlobal.User.userPreference != null) {
        this.exchangePref = clsGlobal.User.userPreference.sExchange;
        this.fcmTopicPref = clsGlobal.User.userPreference.sNotification;
        this.orderPref = clsGlobal.User.userPreference.sOrder;
        this.inAppNotificationPref = clsGlobal.User.userPreference.sInAppNotification
        if (clsGlobal.User.userPreference.sProfilePicPath != undefined && clsGlobal.User.userPreference.sProfilePicPath != null) {
          this.profilePic = clsGlobal.User.userPreference.sProfilePicPath;
        }
      } else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            this.exchangePref = res[0].sExchange;
            this.fcmTopicPref = res[0].sNotification;
            this.orderPref = res[0].sOrder;
            this.inAppNotificationPref = res[0].sInAppNotification;
            if (res[0].sProfilePicPath != null && res[0].sProfilePicPath != undefined) {
              this.profilePic = res[0].sProfilePicPath;
            }
          }
        }).catch(error => {
          //console.log("Error in getting user preference : " + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'ionViewWillEnter2', error.Message, undefined, error.stack, undefined, undefined));
        })
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'ionViewWillEnter2', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method Navigate back to previous page
   */
  goBack() {
    try {
      this.navCtrl.pop();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "goBack", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'goBack', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method Opens User details change form pop up
   */
  editPopUp() {
    try {
      this.editprofile = !this.editprofile;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "editPopUp", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'editPopUp', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * Sonali Dongare
   * Desc : To get user profile data
   */

  getUserProfileData() {
    try {
      // try {
      //   this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {
      //     if (item != undefined) {
      //       let objUserDetails: any = JSON.parse(item);
      //       this.userId = objUserDetails.userId;
      //       this.userName = objUserDetails.userName;
      //       this.userAcronym = this.getAcronymUserName(objUserDetails.userName);
      //     }
      //   }, error => {
      //     //console.log(error);
      //     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ProfilePage', 'getUserProfileData',error.Message,undefined,error.stack,undefined,undefined));
      //   });
      // }
      // catch (error) {
      //   //alert("Error in LocalstorageReading" + error.message);
      //   clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ProfilePage', 'getUserProfileData2',error.Message,undefined,error.stack,undefined,undefined));
      // }
      if (clsGlobal.User.bankdetails.length > 0 && clsGlobal.User.bankdetails != null) {
        this.userId = clsGlobal.User.userId;
        this.userName = clsGlobal.User.userName;
        this.userAcronym = this.getAcronymUserName(this.userName);
        this.email = clsGlobal.User.email;
        this.mobile = clsGlobal.User.mobile;
        this.bankDetails = clsGlobal.User.bankdetails;
        for (var i = 0; i < this.bankDetails.length; i++) {
          this.bankDetails[i].account_no = this.maskNumber(this.bankDetails[i].account_no, "********")
        }
      }
      else {
        this.authServide.getUserProfile().then((data: any) => {
          let profileDetails: any = data;
          if (profileDetails.status == "success") {
            this.userId = clsGlobal.User.userId;
            this.userName = clsGlobal.User.userName = profileDetails.data.user_name;
            this.userAcronym = this.getAcronymUserName(this.userName);
            this.email = clsGlobal.User.email = profileDetails.data.email;
            this.mobile = clsGlobal.User.mobile = profileDetails.data.mobile_no;
            this.mobile = "+91" + this.mobile;
            clsGlobal.User.address = profileDetails.data.address;
            clsGlobal.User.bankdetails = profileDetails.data.bank_details
            this.bankDetails = profileDetails.data.bank_details;
            for (var i = 0; i < this.bankDetails.length; i++) {
              this.bankDetails[i].account_no = this.maskNumber(this.bankDetails[i].account_no, "********")
            }
          }
          else {
            this.toastProvider.showAtBottom("Error in getting profile data");
          }
        }).catch(error => {
          // clsGlobal.logManager.writeErrorLog("profile", "getUserProfileData_1", error.message);
          // clsGlobal.ConsoleLogging("Error", "getUserProfileData_1", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'getUserProfileData3', error.Message, undefined, error.stack, undefined, undefined));
        })
      }
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog("profile", "getUserProfileData_2", error.message);
      // clsGlobal.ConsoleLogging("Error", "getUserProfileData_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'getUserProfileData4', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method : Returns Acronym as first letter in word of username 
   * @param userName User Name
   */
  getAcronymUserName(userName: any) {
    try {
      let userAcronym = '';
      let name = userName.match(/\b(\w)/g);
      userAcronym = name.join('');
      return userAcronym;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "getAcronymUserName", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'getAcronymUserName', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  maskEmail(myemailId) {
    try {
      var maskid = "";
      var prefix = myemailId.substring(0, myemailId.lastIndexOf("@"));
      var postfix = myemailId.substring(myemailId.lastIndexOf("@"));

      for (var i = 0; i < prefix.length; i++) {
        if (i == 0 || i == prefix.length - 1) {   ////////
          maskid = maskid + prefix[i].toString();
        }
        else {
          maskid = maskid + "*";
        }
      }
      this.email = maskid + postfix;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'maskEmail', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  maskNumber(number, string) {
    try {
      let num = number
      let substringToBeReplaced = number.substring(2, number.length - 2); //4512345    
      num = num.replace(substringToBeReplaced, string); //result will be +923*******67
      return num;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'maskNumber', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method Open an link in Browser to download form
   */
  downloadForm() {
    try {
      this.iab.openBrowser("E-Kyc", this.kycUrl, 1);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'downloadForm', error.Message, undefined, error.stack, undefined, undefined));
    }
  }



  async changeProfilePic() {
    try {
      const actionSheet = await this.actionSheetCtrl.create({
        header: 'Profile picture Setting',
        cssClass: 'profile-menu',
        buttons: [
          {
            text: 'Gallery',
            handler: () => {
              this.openGallery();
            }
          },
          {
            text: 'Camera',
            handler: () => {
              this.openCamera();
            }
          },
          {
            text: 'Remove Profile.',
            handler: () => {

              let buttons: any = ["Yes", "No"];
              this.alertObj.showAlertConfirmWithButtons("Profile", "Are you sure you want to remove profile pic?", buttons,
                () => {
                  this.localstorageservice.setItem("PROFILE_PICTURE", "");
                  let userPrefObj = {
                    sExchange: this.exchangePref,
                    sInAppNotification: this.inAppNotificationPref,
                    sNotification: this.fcmTopicPref,
                    sOrder: this.orderPref,
                    sProfilePicPath: "",
                    sTheme: clsGlobal.defaultTheme,
                  }
                  this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
                    clsGlobal.User.userPreference = userPrefObj;
                    console.log("Profile Picture preference added successfully");
                  }).catch(err => {
                    console.log("Error in adding User Preference " + err);
                  })
                  this.profilePic = "";
                  clsGlobal.pubsub.publish("MENU_PROFILE");
                }, () => {
                  //fail No or cancel click //do nothing.
                });
            }
          }
          , {
            text: 'Close',
            role: 'close',
            handler: () => {
              console.log('Close action sheet');
            }
          }
        ]
      });
      await actionSheet.present();
    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'changeProfilePic', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  /**
   * @method : Open Gallery on device
   */
  openGallery() {
    try {
      const options: CameraOptions = {
        quality: 50,
        targetWidth: 600,
        targetHeight: 600,
        sourceType: this.cameraObj.PictureSourceType.PHOTOLIBRARY,
        destinationType: this.cameraObj.DestinationType.FILE_URI,
        encodingType: this.cameraObj.EncodingType.JPEG,
        mediaType: this.cameraObj.MediaType.PICTURE
      }
      this.getPicture(options);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'openGallery', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method : Open Camera in device
   */
  openCamera() {
    try {
      const options: CameraOptions = {
        quality: 50,
        allowEdit: true,
        targetWidth: 600,
        targetHeight: 600,
        sourceType: this.cameraObj.PictureSourceType.CAMERA,
        destinationType: this.cameraObj.DestinationType.FILE_URI,
        encodingType: this.cameraObj.EncodingType.JPEG,
        cameraDirection: this.cameraObj.Direction.FRONT,
        mediaType: this.cameraObj.MediaType.PICTURE
      }
      this.getPicture(options);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'openCamera', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
   * @method : Take picture from camera or Gallary and return path 
   * @param options Camera settings options
   */
  getPicture(options: CameraOptions) {
    this.cameraObj.cleanup();
    this.cameraObj.getPicture(options).then((imagedata) => {
      try {
        let _imagePath = imagedata.substr(0, imagedata.lastIndexOf('/') + 1);
        let _imageName = "";
        if (imagedata.lastIndexOf('?') > 0) {
          _imageName = imagedata.substr(imagedata.lastIndexOf('/') + 1, imagedata.lastIndexOf('?'));
          _imageName = _imageName.substr(0, _imageName.lastIndexOf('?'));
        }
        else {
          _imageName = imagedata.substr(imagedata.lastIndexOf('/') + 1);
        }
        this.uploadImage(_imagePath, _imageName);
      } catch (error) {
        //clsGlobal.logManager.writeErrorLog('ProfilePage', 'getPicture', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'getPicture', error.Message, undefined, error.stack, undefined, undefined));
      }
    });
  }

  /**
   *@method upload file to server.
   * @param {string} imagePath  Filesystem URL representing the file on the device or a data URI. For backwards compatibility, this can also be the full path of the file on the device.
   * @param {string} imageName  Image name.
   *
   * */
  public uploadImage(imagePath, imageName) {
    try {
      var url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + "CDNService.svc" + '/uploadprofilepic';
      // File for Upload
      var targetPath = imagePath + imageName;
      // Use the FileTransfer to upload the image
      const fileTransfer: FileTransferObject = this.transfer.create();
      var options = {
        fileKey: "file",
        fileName: imageName,
        chunkedMode: false,
        mimeType: "multipart/form-data",
        params: {
          tenantId: clsGlobal.LocalComId,
          userId: clsGlobal.User.userId
        }
      };

      fileTransfer.upload(targetPath, url, options).then(data => {
        if (JSON.parse(data.response).status == true) {
          this.toastProvider.showAtBottom("Profile Picture update successfully.");
          let profilePicPathTemp = JSON.parse(data.response).profilePath.split('\\').join('/')
          let profilePicPath: string = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + profilePicPathTemp + "?" + (new Date().getTime()).toString();

          this.localstorageservice.setItem("PROFILE_PICTURE", profilePicPath);
          let userPrefObj = {
            sExchange: this.exchangePref,
            sInAppNotification: this.inAppNotificationPref,
            sNotification: this.fcmTopicPref,
            sOrder: this.orderPref,
            sProfilePicPath: profilePicPath,
            sTheme: clsGlobal.defaultTheme,
          }
          this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
            clsGlobal.User.userPreference = userPrefObj;
            console.log("Profile Picture preference added successfully");
          }).catch(err => {
            console.log("Error in adding User Preference " + err);
          })
          this.profilePic = profilePicPath;
          clsGlobal.pubsub.publish("MENU_PROFILE");
          // this.profilePic = this.sanitizer.bypassSecurityTrustUrl(profilePicPath);
        }
      }, err => {
        //clsGlobal.logManager.writeErrorLog('ProfilePage', 'uploadImage_1', err);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'uploadImage_1', err.Message, undefined, err.stack, undefined, undefined));
      });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ProfilePage', 'uploadImage_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ProfilePage', 'uploadImage_2', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

}
