import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetalertsPageRoutingModule } from './setalerts-routing.module';

import { SetalertsPage } from './setalerts.page';
import { DirectiveSharedModule } from '../../directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetalertsPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [SetalertsPage]
})
export class SetalertsPageModule {}
