import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { AlertEngineService } from 'src/app/providers/alert-engine.service';
import { Component, OnInit } from '@angular/core';
import { NavController, Platform, ToastController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsBestFiveResponse } from 'src/app/communicator/clsBestFiveResponse';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { DatePipe } from '@angular/common';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsPivotPoint } from 'src/app/Common/clsPivotPoint';
import { clsSecurityInfo } from 'src/app/Common/clsSecurityInfo';
import { clsContractInfo } from 'src/app/Common/clsContractInfo';
@Component({
  selector: 'app-setalerts',
  templateUrl: './setalerts.page.html',
})
export class SetalertsPage implements OnInit {
  setAlertPricePopUp: boolean = false;
  selectedScrip: any;
  queryParam: string = '';
  sSymbol: string = '';
  sExchange: string = '';
  ltp: any;
  perChange: any;
  operator: any = "above";
  selectedPrice: any = 0;
  B5Data = [];
  bcastHandler: any;
  totalBidQty = "";
  totalAskQty = "";
  totalBidQtyPer: any = "-";
  totalAskQtyPer: any = "-";
  LUT = "-";
  LTT = "-";

  LTQ = "0";
  ATP = "0.00";
  openPrice = "-";
  highPrice = "-";
  lowPrice = "-";
  closePrice: any = "-";
  scripLTP: any = "0.00";
  DPR = "-";
  dateExpression = /(\d{2}):(\d{2}):(\d{2}) (\d{4})-(\d{2})-(\d{2})/;
  DPRLow = "-";
  TER = "-";
  lifeTimeHighCaption = "52W H";
  lifeTimeLowCaption = "52W L";
  lifeTimeHighPrice = "-";
  lifeTimeLowPrice = "-";
  zeroVal: number = 0;
  OI = "-";
  percOpenInt = "-";
  LTPTrend = "";
  arrowTrend = "";
  netChangeInRs: any = "0.00";
  percNetChange: any = "0.00";
  Volume = "-";
  Value: any = "-";
  selBidQty: any = "";
  selBidPrice: any = "";
  selAskQty: any = "";
  selAskPrice: any = "";
  selectedB5Data: any = null;
  spotScripKey: clsScripKey = null;
  spotPrice: any = "-";
  emptyBestFiveData = [];
  isPriceAlertSet: boolean = false;
  is52HighSet: boolean = false;
  is52LowSet: boolean = false;
  isHoldingExist: boolean = false; 
  selectedScripAlerts: any[];
  triggeredPriceAlerts :any = [];
  triggered52WHAlerts :any = [];
  triggered52WLAlerts :any = [];
  showPivotpopup: boolean = false;
  PPPoint: clsPivotPoint = new clsPivotPoint();
  securityInfo: any;
  isSecurityInfo: boolean = false;
  contractInfo: any;
  issuedCapital: any;
  priceFormat: number;
  pivotPoints : any = [];
  selectedPivotPoint :any ; 
  pivotPointselected : boolean = false;
  numberortell: any;
  constructor(
    private navCtrl: NavController,
    public platform: Platform,
    public activatedRoute: ActivatedRoute,
    private toastServicesProvider: ToastServicesProvider,
    private paramService: NavParamService,
    public dateFormatter: DatePipe,
    private alertEngineService: AlertEngineService,
    private alertProvider: AlertServicesProvider,
    public http: clsHttpService) {
      this.securityInfo = new clsSecurityInfo(this.toastServicesProvider, this.alertProvider, this.http);
      this.contractInfo = new clsContractInfo(this.toastServicesProvider, this.alertProvider, this.http);
      this.PPPoint.calculatePP();
     }

  ngOnInit() {

    if (this.platform.is('android')) {
      this.numberortell = 'tel';
    }
    else {
      this.numberortell = 'number';
    }
    this.securityInfo.MCapCallBack = this.setSecurityInfo.bind(this);
    this.contractInfo.MCapCallBack = this.calculateMarketCap.bind(this);

    this.selectedScrip=this.paramService.myParam;
    if (this.selectedScrip.scripDet.MktSegId == clsConstants.C_V_NSE_CASH ||
      this.selectedScrip.scripDet.MktSegId == clsConstants.C_V_BSE_CASH ||
      this.selectedScrip.scripDet.MktSegId == clsConstants.C_V_MSX_CASH
    ) {
      this.isSecurityInfo  = true;
        this.securityInfo.displayDetails(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token);
      
    }else{
      this.contractInfo.displayDetails(this.selectedScrip);
    }
    this.priceFormat = clsTradingMethods.getPriceFormatter(this.selectedScrip.DecimalLocator, this.selectedScrip.scripDet.MktSegId);
    
  }
  

  initializeQuote() {
    try {
      this.clearFields();
      this.sendTouchlineRequest(OperationType.ADD, this.selectedScrip.scripDet);
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "initializeQuote", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'initializeQuote',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async inizializeUI() {
      try {
      await  this.alertEngineService.getScripAlerts().then((alertsResponse: any) => {
           if (alertsResponse.status = 'success') {
             clsGlobal.scripAlertsList = alertsResponse.data;
             this.selectedScripAlerts = clsGlobal.scripAlertsList;
           }
         }, error => {
           console.log(error)
         })
       } catch (error) {
      //   clsGlobal.logManager.writeErrorLog('SetAlertPage', 'getScripAlerts', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'inizializeUI',error.Message,undefined,error.stack,undefined,undefined));
       }
    this.selectedScripAlerts = clsGlobal.scripAlertsList.filter((alert: any) => { return (alert.data.symbol == this.selectedScrip.symbol && clsTradingMethods.GetMarketSegmentID(alert.condition[0].operand1.marketsegment) == this.selectedScrip.scripDet._MktSegId ) && (alert.triggered == 0) });
    console.log(this.selectedScripAlerts)
    this.isPriceAlertSet = this.selectedScripAlerts.filter((alert: any) => { return alert.data.alertType=="PRICE"}).length > 0 ? true : false;
    this.is52HighSet = this.selectedScripAlerts.filter((alert: any) =>{ return alert.data.alertType=="52WH"}).length > 0 ? true : false;
    this.is52LowSet = this.selectedScripAlerts.filter((alert: any) =>{ return alert.data.alertType=="52WL"}).length > 0 ? true : false;
    let selectedScripTriggeredAlerts = clsGlobal.scripAlertsList.filter((alert: any) => { return (alert.data.symbol == this.selectedScrip.symbol && clsTradingMethods.GetMarketSegmentID(alert.condition[0].operand1.marketsegment) == this.selectedScrip.scripDet._MktSegId ) && (alert.triggered == 1) });
   
    if(selectedScripTriggeredAlerts.length > 0 ){
      selectedScripTriggeredAlerts.forEach(alert => {
        alert.triggeredTime = clsCommonMethods.getAlertsDateTime(alert.condition[0].triggeredTime)
      });
    }
    this.triggeredPriceAlerts = selectedScripTriggeredAlerts.filter((alert: any) => { return alert.data.alertType=="PRICE"});;
    this.triggered52WHAlerts =  selectedScripTriggeredAlerts.filter((alert: any) =>{ return alert.data.alertType=="52WH"})
    this.triggered52WLAlerts =  selectedScripTriggeredAlerts.filter((alert: any) =>{ return alert.data.alertType=="52WL"})
   

    if(this.isPriceAlertSet){
      let priceAlert = this.selectedScripAlerts.filter((alert: any) => { return alert.data.alertType=="PRICE"});
      if(priceAlert){
        this.selectedPrice = clsTradingMethods.convertToRupees(priceAlert[0].condition[0].operand2.value , priceAlert[0].condition[0].operand1.marketsegment , 0);
        this.operator =  priceAlert[0].condition[0].operator == '>'? "above" :"below";

      }else{
        this.selectedPrice = 0;
        this.operator = "above"
      }
     
    }
  }

  ionViewWillEnter() {
    try {
      this.selectedScrip = this.paramService.myParam;
      if (this.selectedScrip != undefined) {
        if (clsGlobal.User.Holding != undefined && clsGlobal.User.Holding.length > 0) {
          let holdingScrip = clsGlobal.User.Holding.filter(item => {
            return item.nMarketSegmentId == this.selectedScrip.scripDet.MapMktSegId &&
              item.nToken == this.selectedScrip.scripDet.token;
          });
          if (holdingScrip.length > 0) {
            this.isHoldingExist = true;
            this.selectedScrip.holding = holdingScrip[0];
          }
        }
        this.inizializeUI();
      }

      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.initializeQuote();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.selectedScrip.scripDet);
    }
    catch (e) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'ionViewWillLeave',e.Message,undefined,e.stack,undefined,undefined));
    }
  }
  setSecurityInfo(IssuedCapital) {
    this.calculateMarketCap(IssuedCapital);
  }

  calculateMarketCap(IssuedCapital) {
    this.issuedCapital = IssuedCapital;
    
   if (this.isSecurityInfo == true) {
      if (
        this.securityInfo.PrevDayLow != undefined &&
        this.securityInfo.PrevDayHigh != undefined &&
        this.securityInfo.PrevDayClose != undefined
      ) {
        this.PPPoint.prevDayOpen = this.securityInfo.PrevDayOpen;
        this.PPPoint.prevDayHigh = this.securityInfo.PrevDayHigh;
        this.PPPoint.prevDayLow = this.securityInfo.PrevDayLow;
        this.PPPoint.prevDayClose = this.securityInfo.PrevDayClose;
        this.PPPoint.PriceFormat = this.priceFormat;
        if (
          this.securityInfo.PrevDayLow != "" &&
          this.securityInfo.PrevDayHigh != "" &&
          this.securityInfo.PrevDayClose != ""
        ) {
          this.PPPoint.calculatePP();
          this.loadPivotPoints()
        }
      }
    } else {
      
      if (
        this.contractInfo.PrevDayOpen != undefined &&
        this.contractInfo.PrevDayHigh != undefined &&
        this.contractInfo.PrevDayClose != undefined
      ) {
        this.PPPoint.prevDayOpen = this.contractInfo.PrevDayOpen;
        this.PPPoint.prevDayHigh = this.contractInfo.PrevDayHigh;
        this.PPPoint.prevDayLow = this.contractInfo.PrevDayLow;
        this.PPPoint.prevDayClose = this.contractInfo.PrevDayClose;
        this.PPPoint.PriceFormat = this.priceFormat;

        if (
          this.contractInfo.PrevDayLow != "" &&
          this.contractInfo.PrevDayHigh != "" &&
          this.contractInfo.PrevDayClose != ""
        ) {
          this.PPPoint.calculatePP();
          this.loadPivotPoints()
        }
      }
    }
  }

  loadPivotPoints(){
      this.pivotPoints.push({ point  : "S1" , value : this.PPPoint.support1})
      this.pivotPoints.push({ point  : "S2" , value : this.PPPoint.support2})
      this.pivotPoints.push({ point  : "S3" , value : this.PPPoint.support3})
      this.pivotPoints.push({ point  : "Pivot" , value : this.PPPoint.pivotPoint});
      this.pivotPoints.push({ point  : "R1" , value : this.PPPoint.resistance1})
      this.pivotPoints.push({ point  : "R2" , value : this.PPPoint.resistance2})
      this.pivotPoints.push({ point  : "R3" , value : this.PPPoint.resistance3});
      this.selectedPivotPoint = this.pivotPoints[0]; 
  }

  selectPivotPoint(pivotPoint){
    this.showPivotpopup = false;
    this.selectedPivotPoint = pivotPoint;
    this.selectedPrice = pivotPoint.value;
    this.pivotPointselected = true;
  }

  set52Low() {
    if (this.is52LowSet) {

      let buttons = ['yes', "no"]; 

      this.alertProvider.showAlertConfirmWithButtons("Alert", "Are you sure you want to delete alert?", buttons,
        () => {
          let alertItem = this.selectedScripAlerts.filter(alert => { return alert.data.alertType == "52WL" });


          this.alertEngineService.deleteAlert(alertItem[0].serverAlertId).then((response: any) => {
            if (response.status = 'success') {
              this.is52LowSet = false;
              setTimeout(()=>{
                this.inizializeUI();
              },2000)
              this.toastServicesProvider.showAtBottom('52 week low alert has been deleted');
            }
          }, error => {
            this.is52LowSet = true;
            //clsGlobal.logManager.writeErrorLog('ManageAlertsPage', 'enableDisableAlert', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'set52Low',error.Message,undefined,error.stack,undefined,undefined));
            this.toastServicesProvider.showAtBottom('Alert has been not deleted');
          })
        },
        () => {
          this.is52LowSet = true;
        });


    } else {
      let expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 1);
      expiryDate.setHours(11,59);
      let alertRequest = {
        "condition": [{
          "operand1": {
            "marketsegment": clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId),
            "token": this.selectedScrip.scripDet.token,
            "field": "LastTradedPrice"
          },
          "operand2": {
            "marketsegment": clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId),
            "token": this.selectedScrip.scripDet.token,
            "field": "LifeTimeLow"
          },
          "operator": '<',
        }],
        "data": {
          "remarks": this.selectedScrip.symbol + " 52 WL alert",
          "userid": clsGlobal.User.userId,
          "tenantid": clsGlobal.ComId,
          "symbol": this.selectedScrip.symbol,
          "alertType": "52WL",
          "category": this.selectedScrip._Series == 'EQ' ? 'EQ' : 'FAO'
        },
        "expiration": -1,
        "createDate": new Date()
      }

      this.alertEngineService.setScripAlert(alertRequest).then((scripAlertResponse) => {
        this.is52LowSet = true;
        setTimeout(()=>{
          // this.getScripAlerts();
          this.inizializeUI();
        },2000)
        this.toastServicesProvider.showAtBottom("You will be alerted when the price reaches 52 week low")
      }, error => {
        this.is52LowSet = false;
        this.toastServicesProvider.showAtBottom("Unable to set alert ")
       // clsGlobal.ConsoleLogging("Error", "set52Low", error);
       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'set52Low2',error.Message,undefined,error.stack,undefined,undefined));
      })
    }

  }

  set52High() {
    if (this.is52HighSet) {

      let buttons = ['yes', "no"];
      this.alertProvider.showAlertConfirmWithButtons("Alert", "Are you sure you want to delete alert?", buttons,
        () => {
          let alertItem = this.selectedScripAlerts.filter(alert => { return alert.data.alertType == "52WH" });


          this.alertEngineService.deleteAlert(alertItem[0].serverAlertId).then((response: any) => {
            if (response.status = 'success') {
              this.is52HighSet = false;
              setTimeout(()=>{
               // this.getScripAlerts();
                this.inizializeUI();
              },2000)
              this.toastServicesProvider.showAtBottom('52 week hign alert has been deleted');
            }
          }, error => {
            this.is52HighSet = true;
            //clsGlobal.logManager.writeErrorLog('ManageAlertsPage', 'enableDisableAlert', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'set52High',error.Message,undefined,error.stack,undefined,undefined));
            this.toastServicesProvider.showAtBottom('Alert has been not deleted');
          })
        },
        () => {
          this.is52HighSet = true;
        });



    } else {
      let expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 1);
      expiryDate.setHours(11,59);
      let alertRequest = {
        "condition": [{
          "operand1": {
            "marketsegment": clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId) ,
            "token": this.selectedScrip.scripDet.token,
            "field": "LastTradedPrice"
          },
          "operand2": {
            "marketsegment": clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId),
            "token": this.selectedScrip.scripDet.token,
            "field": "LifeTimeHigh"
          },
          "operator": '>',
        }],
        "data": {
          "remarks": this.selectedScrip.symbol + " 52 WH alert",
          "userid": clsGlobal.User.userId,
          "tenantid": clsGlobal.ComId,
          "symbol": this.selectedScrip.symbol,
          "alertType": "52WH",
          "category": this.selectedScrip._Series == 'EQ' ? 'EQ' : 'FAO'
        },
        "expiration": -1,
        "createDate": new Date()
      }

      this.alertEngineService.setScripAlert(alertRequest).then((scripAlertResponse) => {
        this.is52HighSet = true;
        setTimeout(()=>{
         // this.getScripAlerts();
          this.inizializeUI();
        },2000)
        this.toastServicesProvider.showAtBottom("You will be alerted when the price reaches 52 week high")
      }, error => {
        this.is52HighSet = false;
        this.toastServicesProvider.showAtBottom("Unable to set alert ")
        //clsGlobal.ConsoleLogging("Error", "set52High", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'set52High2',error.Message,undefined,error.stack,undefined,undefined));
      })
    }
  }

  showPriceAlert() {
    if (this.isPriceAlertSet) {

      let buttons = ['yes', "no"];
      this.alertProvider.showAlertConfirmWithButtons("Alert", "Are you sure you want to delete alert?", buttons,
        () => {
          let alertItem = this.selectedScripAlerts.filter(alert => { return alert.data.alertType == "PRICE" });

          this.alertEngineService.deleteAlert(alertItem[0].serverAlertId).then((response: any) => {
            if (response.status = 'success') {
              this.isPriceAlertSet = false;
              setTimeout(()=>{
               // this.getScripAlerts();
                this.inizializeUI();
              },2000)
              this.toastServicesProvider.showAtBottom('Price alert has been deleted');
            }
          }, error => {
            this.isPriceAlertSet = true;
            //clsGlobal.logManager.writeErrorLog('ManageAlertsPage', 'showPriceAlert', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'showPriceAlert',error.Message,undefined,error.stack,undefined,undefined));
            this.toastServicesProvider.showAtBottom('Alert has been not deleted');
          })
        },
        () => {
          this.isPriceAlertSet = true;
        });



    } else {
      this.isPriceAlertSet = false;
      this.setAlertPricePopUp = true;
    }
  }
  setPrice(event) {
    try {
      if (event != undefined && event.detail.checked) {
        this.setAlertPricePopUp = true;
        this.isPriceAlertSet = true;
      }
      else
        this.setAlertPricePopUp = false;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "setPrice", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'setPrice',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  segmentChanged(event) {
    try {
      if (event.detail.value != undefined) {
        this.operator = event.detail.value
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "segmentChanged", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'segmentChanged',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showEditAlert() {
    if (this.isPriceAlertSet) {
      this.setAlertPricePopUp = true;
    }
  }

  setAlert() {
    let alertItem = this.selectedScripAlerts.filter(alert => { return alert.data.alertType == "PRICE" });
    if (alertItem[0]) {
      let expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 1);
      expiryDate.setHours(11,59);
      let alertRequest = {
        "condition": [{
          "operand1": {
            "marketsegment": alertItem[0].condition[0].operand1.marketsegment,
            "token": alertItem[0].condition[0].operand1.token,
            "field": "LastTradedPrice"
          },
          "operand2": {
            "marketsegment": alertItem[0].condition[0].operand2.marketsegment,
            "token": alertItem[0].condition[0].operand2.token,
            "field": "USE_VALUE",
            "value": clsTradingMethods.convertRupeesToPaisa(this.selectedPrice, alertItem[0].condition[0].operand1.marketsegment , 0)
          },
          "operator": this.operator == "above" ? '>' : '<',
        }],
        "data": {
          "remarks": alertItem[0].data.symbol + " alert",
          "userid": clsGlobal.User.userId,
          "tenantid": clsGlobal.ComId,
          "symbol": alertItem[0].data.symbol,
          "alertType": "PRICE",
          "category": alertItem[0].data.category == 'EQ' ? 'EQ' : 'FAO'
        },
        "expiration": -1,
        "createDate": new Date(),
        "serverAlertId" :alertItem[0].serverAlertId
      }

      this.alertEngineService.updateScripAlert(alertRequest).then((response: any) => {
        
        if (response.status = 'success') {
          this.setAlertPricePopUp = false;
          this.toastServicesProvider.showAtBottom("You will be alerted when the Price goes " + this.operator + " " + this.selectedPrice);
          setTimeout(()=>{
            this.inizializeUI();
          },2000)
        }
      }, error => {
        this.setAlertPricePopUp = false;
        this.toastServicesProvider.showAtBottom('Failed to update price alert');
      });
    } else {
      if (this.selectedPrice) {
        let expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 1);
        expiryDate.setHours(11,59);
        let alertRequest = {
          "condition": [{
            "operand1": {
              "marketsegment":clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId) ,
              "token": this.selectedScrip.scripDet.token,
              "field": "LastTradedPrice"
            },
            "operand2": {
              "marketsegment":clsTradingMethods.getMappedMarketSegmentId(this.selectedScrip.scripDet.MktSegId),
              "token": this.selectedScrip.scripDet.token,
              "field": "USE_VALUE",
              "value": clsTradingMethods.convertRupeesToPaisa(this.selectedPrice, this.selectedScrip.scripDet.MktSegId , 0)
            },
            "operator": this.operator == "above" ? '>' : '<',
          }],
          "data": {
            "remarks": this.selectedScrip.symbol + " Price alert",
            "userid": clsGlobal.User.userId,
            "tenantid": clsGlobal.ComId,
            "symbol": this.selectedScrip.symbol,
            "alertType": "PRICE",
            "category": this.selectedScrip._Series == 'EQ' ? 'EQ' : 'FAO'
          },
          "expiration": -1,
          "createDate": new Date()
        }

        this.alertEngineService.setScripAlert(alertRequest).then((scripAlertResponse) => {
          this.setAlertPricePopUp = false;
          setTimeout(()=>{
           // this.getScripAlerts();
            this.inizializeUI();
          },2000)
          
          this.toastServicesProvider.showAtBottom("You will be alerted when the Avg. Price goes " + this.operator + " " + this.selectedPrice);
        }, error => {
          this.setAlertPricePopUp = false;
          this.isPriceAlertSet = false
          this.toastServicesProvider.showAtBottom("Unable to set alert ")
          //clsGlobal.ConsoleLogging("Error", "setAlert", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'setAlert',error.Message,undefined,error.stack,undefined,undefined));
        })
      } else {
        this.toastServicesProvider.showAtBottom("Alert price must be provided")
      }
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList != undefined) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList.push(scripList);
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
    * Receive broadcast and bind to html
    * @param objMultiTLResp
    */
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      if (objMultiTLResp != null && this.selectedScrip != undefined) {
        if (this.selectedScrip.scripDet.MktSegId == objMultiTLResp.Scrip.MktSegId &&
          this.selectedScrip.scripDet.token == objMultiTLResp.Scrip.token) {
          if (this.selectedScrip.LTP > objMultiTLResp.LTP) {
            this.selectedScrip.LTPChangeCss = "sell-ltp-change";
          }
          else if (this.selectedScrip.LTP < objMultiTLResp.LTP) {
            this.selectedScrip.LTPChangeCss = "buy-ltp-change";
          }
          else {
            this.selectedScrip.LTPChangeCss = "";
          }
          this.selectedScrip.LTP = objMultiTLResp.LTP;
          
          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');

          this.selectedScrip.NetChangeInRs = arrNetChange[0];
          this.selectedScrip.PercNetChange = arrNetChange[1];
          this.selectedScrip.LTPTrend = arrNetChange[2];
          this.selectedScrip.PercNetChangeRaw = arrNetChange[3];

          this.selectedScrip.BuyPrice = objMultiTLResp.BuyPrice;
          this.selectedScrip.BuyQty = objMultiTLResp.BuyQty;
          this.selectedScrip.SellPrice = objMultiTLResp.SellPrice;
          this.selectedScrip.SellQty = objMultiTLResp.SellQty;
        }
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearFields() {
    try {
      this.B5Data = this.getEmptyBestFiveData();
      this.totalBidQty = "";
      this.totalAskQty = "";
      this.LUT = "";
      this.LTT = "-";
      this.LTQ = "-";
      this.ATP = "-";
      this.openPrice = "-";
      this.highPrice = "-";
      this.lowPrice = "-";
      this.closePrice = "-";
      //Setting the 52Week High/Low and LifeTime High/Low caption based on the exchange segmentid through exchange manager
      this.lifeTimeHighCaption = "52W H";
      this.lifeTimeLowCaption = "52W L";

      this.lifeTimeHighPrice = "-";
      this.lifeTimeLowPrice = "-";
      this.Volume = "-";
      this.scripLTP = "0.00";
      this.percNetChange = "0.00";
      this.LTPTrend = "";
      this.arrowTrend = "";
      this.netChangeInRs = "0.00";

      this.DPR = "-";
      this.DPRLow = "-";
      this.selBidQty = "";
      this.selBidPrice = "";
      this.selAskQty = "";
      this.selAskPrice = "";
      this.selectedB5Data = null;
      this.TER = "-";

      this.spotPrice = "-";
      this.spotScripKey = new clsScripKey();

    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "clearFields", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'clearFields',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getEmptyBestFiveData() {
    try {
      let b1: any = {};
      b1.sBuyers = "-";
      b1.sBidQty = "-";
      b1.sBid = "-";
      b1.sSellers = "-";
      b1.sAskQty = "-";
      b1.sAsk = "-";
      b1.RowIndex = 0;
      b1.SelectedB5Class = "ht03";

      let b2: any = {};
      b2.sBuyers = "-";
      b2.sBidQty = "-";
      b2.sBid = "-";
      b2.sSellers = "-";
      b2.sAskQty = "-";
      b2.sAsk = "-";
      b2.RowIndex = 1;
      b2.SelectedB5Class = "ht03"; //ko.observable('ht03');

      let b3: any = {};
      b3.sBuyers = "-";
      b3.sBidQty = "-";
      b3.sBid = "-";
      b3.sSellers = "-";
      b3.sAskQty = "-";
      b3.sAsk = "-";
      b3.RowIndex = 2;
      b3.SelectedB5Class = "ht03";

      let b4: any = {};
      b4.sBuyers = "-";
      b4.sBidQty = "-";
      b4.sBid = "-";
      b4.sSellers = "-";
      b4.sAskQty = "-";
      b4.sAsk = "-";
      b4.RowIndex = 3;
      b4.SelectedB5Class = "ht03";

      let b5: any = {};
      b5.sBuyers = "-";
      b5.sBidQty = "-";
      b5.sBid = "-";
      b5.sSellers = "-";
      b5.sAskQty = "-";
      b5.sAsk = "-";
      b5.RowIndex = 4;
      b5.SelectedB5Class = "ht03"; //ko.observable('ht03');

      this.emptyBestFiveData = null;
      this.emptyBestFiveData = [];
      this.emptyBestFiveData.push(b1);
      this.emptyBestFiveData.push(b2);
      this.emptyBestFiveData.push(b3);
      this.emptyBestFiveData.push(b4);
      this.emptyBestFiveData.push(b5);
      return this.emptyBestFiveData;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "getEmptyBestFiveData", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'getEmptyBestFiveData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getMktSegmentId() {
    try {
      return this.selectedScrip.scripDet.MktSegId;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "getMktSegmentId", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'getMktSegmentId',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  gettoken() {
    try {
      return this.selectedScrip.scripDet.token;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "gettoken", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'gettoken',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  processBestFiveResponse(_objB5Response: clsBestFiveResponse) {
    try {
      for (let i = 0, len = this.B5Data.length; i < len; i++) {
        if (
          this.B5Data[i].RowIndex == _objB5Response.BestFiveData[i].RowIndex
        ) {
          this.B5Data[i].sBuyers = _objB5Response.BestFiveData[i].sBuyers;
          this.B5Data[i].sBidQty = _objB5Response.BestFiveData[i].sBidQty;
          this.B5Data[i].sBid = _objB5Response.BestFiveData[i].sBid;
          this.B5Data[i].sSellers = _objB5Response.BestFiveData[i].sSellers;
          this.B5Data[i].sAskQty = _objB5Response.BestFiveData[i].sAskQty;
          this.B5Data[i].sAsk = _objB5Response.BestFiveData[i].sAsk;
        }
      }
      //this.B5Data.valueHasMutated();
      this.totalBidQty = (_objB5Response.TotBuyQty == '' ? '-' : _objB5Response.TotBuyQty);
      this.totalAskQty = (_objB5Response.TotSellQty == '' ? '-' : _objB5Response.TotSellQty);
      if (this.totalAskQty != '-' && this.totalBidQty != '-') {
        let _totalQty = parseInt(this.totalAskQty) + parseInt(this.totalBidQty);
        this.totalBidQtyPer = ((parseInt(this.totalBidQty) / _totalQty) * 100).toFixed(2);
        this.totalAskQtyPer = ((parseInt(this.totalAskQty) / _totalQty) * 100).toFixed(2);
        //we will calculate qty percent 
      }
      this.LUT = this.formatDisplayDate(
        _objB5Response.LUT,
        this.dateExpression,
        "HH:mm:ss"
      );
      this.LTT = this.formatDisplayDate(
        _objB5Response.LTT,
        this.dateExpression,
        "HH:mm:ss"
      );
      this.LTQ = _objB5Response.LTQ == "" ? 0 : _objB5Response.LTQ;
      this.ATP = _objB5Response.ATPPrc == "" ? this.zeroVal.toFixed(_objB5Response.PriceFormat) : _objB5Response.ATPPrc;
      this.openPrice = _objB5Response.OpenPrc == "" ? "-" : _objB5Response.OpenPrc;
      this.highPrice = _objB5Response.HighPrc == "" ? "-" : _objB5Response.HighPrc; //_objB5Response.HighPrc;
      this.lowPrice = _objB5Response.LowPrc == "" ? "-" : _objB5Response.LowPrc; //_objB5Response.LowPrc;
      this.closePrice = _objB5Response.ClosePrc == "" ? "-" : _objB5Response.ClosePrc;
      //TO DO
      // if (!this.isMarketCapCalculated) {
      //   //this.calculateMarketCap(this.issuedCapital);
      // }
      // //Setting the 52Week High/Low and LifeTime High/Low caption based on the exchange segmentid through exchange manager
      this.lifeTimeHighCaption = clsTradingMethods.getLifeTimeHighCaption(this.getMktSegmentId());
      this.lifeTimeLowCaption = clsTradingMethods.getLifeTimeLowCaption(this.getMktSegmentId());
      this.lifeTimeHighPrice = _objB5Response.YrHighPrc == "" ? "-" : _objB5Response.YrHighPrc; //_objB5Response.YrHighPrc;
      this.lifeTimeLowPrice = _objB5Response.YrLowPrc == "" ? "-" : _objB5Response.YrLowPrc; // _objB5Response.YrLowPrc;
      this.Volume = _objB5Response.Volume == "" || _objB5Response.Volume == undefined ? 0 : this.numbertoString(_objB5Response.Volume);
      this.Value = (parseInt(this.Volume) * parseFloat(this.ATP)).toFixed(2);

      this.scripLTP = _objB5Response.LTP == "" || _objB5Response.LTP == undefined ? this.zeroVal.toFixed(_objB5Response.PriceFormat) : _objB5Response.LTP;
      let arrNetChange = clsTradingMethods.getChangeInRs(_objB5Response.LTP, _objB5Response.ClosePrc, _objB5Response.PriceFormat, false, "arrowround");
      this.netChangeInRs = arrNetChange[0];
      this.percNetChange = arrNetChange[1];
      this.LTPTrend = arrNetChange[2] == 'sell' ? '-' : '+';
      this.arrowTrend = arrNetChange[3];
      // this.selectedScrip.netChangeInRs = arrNetChange[0];
      // this.selectedScrip.percNetChange = arrNetChange[1];
      // this.selectedScrip.LTPTrend = arrNetChange[2];
      // this.selectedScrip.arrowTrend = arrNetChange[3];
      this.DPR = _objB5Response.DPR;
      let arrDPR;
      if (_objB5Response.DPR != undefined && _objB5Response.DPR != "") {
        //comment for Spread DPR in negative
        arrDPR = _objB5Response.DPR.split("-");
        this.DPR = arrDPR[1] == "" ? "-" : arrDPR[1];
        this.DPRLow = arrDPR[0] == "" ? "-" : arrDPR[0];
      }
      if (clsGlobal.User.LoginMode == clsConstants.C_S_REFRESH_MODE)
        this.TER = _objB5Response.TER;
      this.percOpenInt = _objB5Response.PercOpenInt;
      this.OI =
        _objB5Response.OI == "" || _objB5Response.OI == undefined
          ? 0
          : _objB5Response.OI;
      if (
        this.percOpenInt == undefined ||
        this.percOpenInt == "0.00" ||
        this.percOpenInt == ""
      ) {
        //this.OIPerctVisible = false;
      } else {
        //this.OIPerctVisible = true;
      }
      //this.priceFormat = _objB5Response.PriceFormat;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "receiveBestFiveResponse", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'receiveBestFiveResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  formatDisplayDate(sDate, expression, sFormat) {
    try {
      let _FormattedDate = "";
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[4],
          +dateArray[5] - 1, // Careful, month starts at 0!
          +dateArray[6],
          +dateArray[1],
          +dateArray[2],
          +dateArray[3]
        );
        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "dd/MM/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
      }
      return _FormattedDate;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "formatDisplayDate", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'formatDisplayDate',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  numbertoString(number) {
    try {
      if (number == undefined || number == "") return "-";
      let words: any = "";
      let Mcap = 0;
      let Val = parseInt(number);
      if (Val.toString().length > 7) {
        Mcap = number / 10000000;
        words = Mcap.toFixed(2) + " Cr";
      } else if (Val.toString().length <= 7 && Val.toString().length > 5) {
        Mcap = number / 100000;
        words = Mcap.toFixed(2) + " L";
      } else {
        words = parseFloat(number); //.toFixed(2); Solved by om on 14 jul for volume decimal in case of 3 or 4 digit values.
      }
      return words;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "numbertoString", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SetalertsPage', 'numbertoString',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closePriceAlert() {
    this.setAlertPricePopUp = false
    let alertItem = this.selectedScripAlerts.filter(alert => { return alert.data.alertType == "PRICE" });
    if (!alertItem[0]) {
      this.isPriceAlertSet = false
    }
  }
  clickPivot(){
    this.showPivotpopup = !this.showPivotpopup;
  }
}
