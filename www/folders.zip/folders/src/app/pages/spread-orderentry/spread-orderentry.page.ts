import { Component, OnInit, ViewChild } from '@angular/core';
import { SpreadOrderEntryComponent } from 'src/app/components/spread-order-entry/spread-order-entry.component';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavController, ModalController, Platform } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-spread-orderentry',
  templateUrl: './spread-orderentry.page.html'
})
export class SpreadOrderentryPage implements OnInit {
  objOEDetail: clsOEFormDetl;

  @ViewChild('spreadOE') spreadentry: SpreadOrderEntryComponent;

  constructor(public navCtrl: NavController,
    private paramService: NavParamService,) {
    this.objOEDetail = this.paramService.myParam;
   }

  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      //clsGlobal.User.exchangesList = res.data.product_types;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SpreadOrderentryPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad(){
    clsGlobal.logManager.writeUserAnalytics("SpreadOrderentryPage","","VISIT",""); 
  }
  /**
   * @method : Send Best five subscription request Order Entry
   */
  ionViewWillEnter() {
    try {
      //this.objOEDetail = this.paramService.myParam;
      this.spreadentry.sendSubscritionRequest();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SpreadOrderentryPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillLeave() {
    try {
      //this.objOEDetail = this.paramService.myParam;
      this.spreadentry.ionViewWillLeave();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillLeave", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SpreadOrderentryPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveSpreadMessage($event) {
    try {
      this.closeOrderEntry();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "receiveSpreadMessage", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SpreadOrderentryPage', 'receiveSpreadMessage',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method : close Order Entry pop up and go back to previous page
   */
  closeOrderEntry() {
    try {
      this.navCtrl.pop();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "closeOrderEntry", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SpreadOrderentryPage', 'closeOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
