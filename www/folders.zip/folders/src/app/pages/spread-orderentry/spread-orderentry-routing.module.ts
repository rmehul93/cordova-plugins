import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SpreadOrderentryPage } from './spread-orderentry.page';

const routes: Routes = [
  {
    path: '',
    component: SpreadOrderentryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SpreadOrderentryPageRoutingModule {}
