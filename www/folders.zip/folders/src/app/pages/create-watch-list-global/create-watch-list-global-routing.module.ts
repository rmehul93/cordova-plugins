import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateWatchListGlobalPage } from './create-watch-list-global.page';

const routes: Routes = [
  {
    path: '',
    component: CreateWatchListGlobalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateWatchListGlobalPageRoutingModule {}
