import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalController, NavController, PopoverController } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { WatchlistloaderPage } from '../watchlistloader/watchlistloader.page';


@Component({
  selector: 'app-create-watch-list-global',
  templateUrl: './create-watch-list-global.page.html',
})
export class CreateWatchListGlobalPage implements OnInit {

  profileData: any;
  profileScrips = [];
  profileListScrip = [];
  sProfileName = "";
  removeScripCnt = 0;
  showRename = false;
  selProfileName = "";
  isRenameMode = false;
  constructor(private navCtrl: NavController,
    public popoverController: PopoverController,
    private route: ActivatedRoute,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService,
    public alertCtrl: AlertServicesProvider,
    public toastProvider: ToastServicesProvider,
    public modalController: ModalController,
    private objHttpService: clsHttpService,
    public dateFormatter: DatePipe) {
    this.profileData = route.snapshot.queryParams.profile || '';
    this.sProfileName = this.profileData.sWatchListName;
    this.isRenameMode = route.snapshot.queryParams.type == "RENAME";
    this.showRename = this.isRenameMode;
    this.selProfileName = this.sProfileName;
  }

  ngOnInit() {
    try {
      this.watchlistServ.getWatchlistProfileScrip(this.profileData.nWatchListId, this.profileData.sCreatedBy).then((profileScripData: any) => {
        if (profileScripData != undefined) {
          this.profileScrips = profileScripData;
          this.loadProfileDetails();
        }
      });
    } catch (error) {
      console.log(error);
    }
  }

  loadProfileDetails() {
    try {

      //let iCnt = 0;
      this.profileListScrip = [];
      //let req;
      //let arrScrip = [];
      for (let index = 0; index < this.profileScrips.length; index++) {

        const element = this.profileScrips[index];
        this.profileListScrip.push({
          scripDetail: element,
          added: true
        });

        // let Token = element.nToken;
        // let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId || element.nMarketSegmetId);
        // let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
        // arrScrip.push({ "mkt": exchange, "token": Token });
        // this.dbService.getScripByToken(exchange, Token, element.nMarketSegmentId).then(scrip => {
        //   //console.log("Scrip Found: ", scrip);
        //   this.profileListScrip.push({
        //     scripDetail: scrip[0],
        //     added: true
        //   });
        //   iCnt++;

        // }, error => {
        //   console.log("unable to find scrip: ", Token, " ", exchange);
        // });
      }

      // req = { scrips: arrScrip };
      // if (req != undefined) {
      //   clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

      //     if (scripData.status == true) {
      //       if (scripData != undefined && scripData.result.length > 0) {
      //         for (let index = 0; index < scripData.result.length; index++) {
      //           const element = scripData.result[index];
      //           //item.scripDetail = clsCommonMethods.getScripObject(element).scripDetail;
      //           this.profileListScrip.push({
      //             scripDetail: clsCommonMethods.getScripObject(element).scripDetail,
      //             added: true
      //           });
      //         }
      //       }
      //     } else {
      //       //console.log("Unable to fetch scrip details: ", Token, " ", exchange);
      //       //return;
      //     }

      //   });
      // }
    } catch (error) {
      console.log(error);
    }
  }

  removeScrip(scripItem, index) {
    try {
      scripItem.added = !scripItem.added;
      if (!scripItem.added)
        this.removeScripCnt++;
      else {
        this.removeScripCnt--;
      }
    } catch (error) {
      console.log(error);
    }
  }


  done() {
    try {

      let removedScrip = this.profileListScrip.filter(scrip => {
        return !scrip.added;
      });


      if (this.profileData.bIsPrivate.toString() == "false" &&
        removedScrip.length > 0 &&
        //this.profileScrips.length != this.profileListScrip.length &&
        this.profileData.sWatchListName == this.sProfileName
      ) {
        this.toastProvider.showAtBottom("modification not allowed for predefined watch list kindly provide new name.");
        this.showRename = true;
        return;
      }

      let addedScrip = this.profileListScrip.filter(scrip => {
        return scrip.added;
      });

      if (addedScrip.length == 0) {
        this.toastProvider.showAtBottom("You have to add at least one scrip to save your watchlist!");
        return;
      }


      this.saveWatchlist();

    } catch (error) {
      console.log(error);
    }
  }

  closeProfileRename() {
    if (!this.isRenameMode)
      this.showRename = !this.showRename;
    else {
      this.goBack();
    }
  }

  saveWatchlist() {
    try {

      if (this.selProfileName == '') {
        this.toastProvider.showAtBottom("Name is required to create the watchlist");
        return;
      }

      if (this.isRenameMode) {
        this.updateProfileName();
      }
      else {

        let isTopPickProfChange = true;

        let removedScrip = this.profileListScrip.filter(scrip => {
          return !scrip.added;
        });

        // if (this.profileData.bIsPrivate.toString() == "false" && removedScrip.length == 0) {
        //   isTopPickProfChange = false;
        // } else {
        //   isTopPickProfChange = true;
        // }
        isTopPickProfChange = true;

        this.watchlistServ.getWatchlistProfile().then(async (profList: any) => {

          if (profList != undefined) {
            let isProfileExist = profList.filter(item => {
              return item.sWatchListName.toUpperCase() == this.selProfileName.toUpperCase() && (item.sUserId == clsGlobal.User.userId || item.sUserId == "CHIEF");
            });

            if (isProfileExist.length != 0) {
              this.toastProvider.showAtBottom("Looks like this watchlist already exists. Try using a different name.");
              return;
            }
          }

          if (this.selProfileName == 'My Holdings' || this.selProfileName == "Don't Miss") {
            this.toastProvider.showAtBottom("Watchlist name cannot rename as system name.");
            return;
          }

          let maxProfile = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10')
          if (profList != undefined && profList.length > maxProfile) {
            // this.toastProvider.showAtBottom("Maximum " + maxProfile + " watchlist allowed.");
            this.toastProvider.showAtBottom("Watchlist limit reached! Try reviewing your watchlists!");

            return;
          }


          let watclistObj: any = {};
          if (isTopPickProfChange) {

            let addedScrip = this.profileListScrip.filter(scrip => {
              return scrip.added;
            });

            let selScrip = [];
            for (let index = 0; index < addedScrip.length; index++) {
              const element = addedScrip[index];
              selScrip.push({ MktSegId: parseInt(element.scripDetail.scripDet.MapMktSegId), Token: element.scripDetail.scripDet.token });
            }

            watclistObj.name = this.selProfileName;
            watclistObj.scrip = selScrip;
            watclistObj.source = "WAVE";
          } else {

            watclistObj.name = this.sProfileName;
            watclistObj.isFromTopPicks = true;
            watclistObj.profileId = this.profileData.nWatchListId;
            watclistObj.source = "WAVE";
          }

          let statusUpdate = new BehaviorSubject("0");
          const modal = await this.modalController.create({
            component: WatchlistloaderPage,
            //cssClass: 'my-custom-class',
            componentProps: {
              'status': statusUpdate,
            }
          });
          await modal.present();
          statusUpdate.next("0");

          setTimeout(() => {

            let watchProfile = {
              nWatchListId: isTopPickProfChange ? (Math.floor(Math.random() * 200) + 1) : this.profileData.nWatchListId,
              sWatchListName: watclistObj.name,
              //bIsPrivate: isTopPickProfChange ? true : false,
              bIsPrivate: true,
              bIsDefault: false,
              sCreatedBy: clsGlobal.User.userId,
              //nTenantId: isTopPickProfChange ? clsGlobal.ComId : '0'
              nTenantId: clsGlobal.ComId
            };

            this.watchlistServ.addNewWatchlist(watchProfile).then((data) => {

              if (isTopPickProfChange) {

                let watchScrip = [];

                for (let index = 0; index < watclistObj.scrip.length; index++) {
                  const element = watclistObj.scrip[index];
                  watchScrip.push({
                    nWatchListId: watchProfile.nWatchListId,
                    nMarketSegmentId: element.MktSegId,
                    nToken: element.Token,
                    nSequenceNo: (index + 1)
                  })
                }

                this.watchlistServ.addWatchlistScrip(watchProfile, watchScrip).then((data) => {
                  statusUpdate.next("1");

                  setTimeout(() => {
                    modal.dismiss().then(value => {
                      //this.navCtrl.getViews()
                      clsGlobal.reloadWatchlist = true;
                      clsGlobal.userSelectedWatchlist = watchProfile;
                      //this.navCtrl.navigateBack
                      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                    });
                  }, 1000);
                  
                });

              } else {

                statusUpdate.next("1");

                setTimeout(() => {
                  modal.dismiss().then(value => {
                    //this.navCtrl.getViews()
                    clsGlobal.reloadWatchlist = true;
                    //this.navCtrl.navigateBack
                    clsGlobal.userSelectedWatchlist = watchProfile;
                    this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                  });
                }, 1000);
                

              }

            }, (error) => {
              modal.dismiss()
            });
          }, 1000);

          //this.navCtrl.navigateForward('watchlist');

        }, (error) => {

        });
      }
    } catch (error) {
      console.log(error);
    }
  }

  updateProfileName() {
    try {
      let watclistObj: any = {};
      watclistObj.profileId = this.profileData.nWatchListId;
      watclistObj.profileName = this.selProfileName;
      this.watchlistServ.updatProfileName(watclistObj).then((data) => {
        clsGlobal.reloadWatchlist = true;
        this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
      }, (error) => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  goBack() {
    this.navCtrl.pop();
    // this.navCtrl.navigateForward('watchlist');
  }

  getScripCount(){
    let addedScrip = this.profileListScrip.filter(scrip => {
      return scrip.added;
    });

    return addedScrip.length;
  }
}
