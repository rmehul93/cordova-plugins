import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { CreateWatchListGlobalPageRoutingModule } from './create-watch-list-global-routing.module';
import { CreateWatchListGlobalPage } from './create-watch-list-global.page'; 

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateWatchListGlobalPageRoutingModule
  ],
  declarations: [CreateWatchListGlobalPage]
   
})
export class CreateWatchListGlobalPageModule {}
