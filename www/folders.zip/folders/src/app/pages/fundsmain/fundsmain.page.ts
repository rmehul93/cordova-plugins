import { TransactionService } from 'src/app/providers/transaction.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MenuController, NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { CupertinoPane, CupertinoSettings } from 'cupertino-pane';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-fundsmain',
  templateUrl: './fundsmain.page.html',
})
export class FundsmainPage implements OnInit {

  fundsTransactions = [];
  @ViewChild('divTransaction', { static: false }) divTransaction: ElementRef;
  showExpandedNetposition: boolean = false;
  transactionPane: any;
  showAccounts: boolean = false;
  showContext = false;
  totalPurchasingPower: any = 0;
  totalAvailable: any = 0;
  totalUtilised: any = 0;
  totalMargin: any = 0;
  periodicityWisefundsDetails: any = [];
  productWisefundsDetails: any = [];
  selProduct: any;
  arrProductPeriodicites = [];
  selPeriodicity: any;
  selPeriodicityId: any;
  showPeriodicity: boolean = false;
  showPeriodicitySelection: boolean = false;

  constructor(private navCtrl: NavController,
    public alertservice: AlertServicesProvider,
    private transactionService: TransactionService,
    public toastProvider: ToastServicesProvider,
    private navParamService: NavParamService,
    private menutCtrl: MenuController) { }

  ngOnInit() {
    this.menutCtrl.enable(true);
  }

  ionViewDidEnter() {
    try {
      if (clsGlobal.User.fundsDetails && clsGlobal.User.fundsDetails.periodicityWisefundsDetails && clsGlobal.User.fundsDetails.productWisefundsDetails) {
        this.periodicityWisefundsDetails = clsGlobal.User.fundsDetails.periodicityWisefundsDetails;
        this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;
        this.setProductPeriodicities();
        this.calculateFunds();
        for (let index = 0; index < this.productWisefundsDetails.length; index++) {
          this.productWisefundsDetails[index].balanceAmountDisplay =
            clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
        }
      } else {
        this.getBalanceInfo();

      }
      //this.getBalanceInfo();
      // if (this.transactionPane != undefined) {
      //   this.transactionPane.moveToBreak('bottom');
      // } else {
      //   this.checkForTransactionElementRendrer();
      // }
      this.checkForTransactionElementRendrer();
      this.getTransactionReport();
    } catch (error) {
      console.log(error);
    }
  }

  cancelRequest(item) {
    try {

      let reqBody = {
        "productId": item.sProductId,
        "amount": item.nAmount,
        "TxnRefNo": item.nTxnRefNo
      }

      this.alertservice.showAlertConfirmWithButtons("Withdraw Cancel", "Are you sure you want to cancel request?", ["Yes", "No"], () => {

        this.transactionService.cancelWithdraw(reqBody).then((response: any) => {
          if (response.status == 'success') {
            //this.fundsTransactions = response.data;
            this.getTransactionReport();
          } else {
            this.toastProvider.showAtBottom(response.errorString);
          }
        }, err => {
          console.log(err);

        });
      }, () => {

      })

    } catch (error) {

    }

  }

  getBalanceInfo() {
    try {

      this.transactionService.getPeridiocityWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {
          this.periodicityWisefundsDetails = balanceData.data;
          clsGlobal.User.fundsDetails.periodicityWisefundsDetails = this.periodicityWisefundsDetails;
          //this.calculateFunds();

          this.transactionService.getProductWiseBalanceInfo().then((balanceData: any) => {
            if (balanceData.status == 'success') {
              this.productWisefundsDetails = balanceData.data;
              for (let index = 0; index < this.productWisefundsDetails.length; index++) {
                this.productWisefundsDetails[index].balanceAmountDisplay =
                  clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
              }
              clsGlobal.User.fundsDetails.productWisefundsDetails = this.productWisefundsDetails;
              this.setProductPeriodicities();
            }

          }, error => {
            console.log(error)
          });

        }

      }, error => {
        console.log(error)
      });


    } catch (error) {
      console.log(error);
    }
  }

  setProductPeriodicities() {
    try {

      if (this.productWisefundsDetails.length > 0) {
        this.selProduct = this.productWisefundsDetails[0];
        //this.arrProductPeriodicites = this.selProduct.periodicities;
        this.fillPeriodicity();
      }
    } catch (error) {

    }
  }

  fillPeriodicity() {
    try {

      this.arrProductPeriodicites = [];
      this.selPeriodicityId = -1;
      
      this.totalPurchasingPower = 0.00;
      this.totalAvailable = 0.00;
      this.totalUtilised = 0.00;
      this.totalMargin = 0.00;

      for (let index = 0; index < this.selProduct.periodicities.length; index++) {

        const element = this.selProduct.periodicities[index];
        let perdDetl = this.periodicityWisefundsDetails.filter(perd => {
          return element == perd.id;
        });

        if (perdDetl.length > 0) {
          this.arrProductPeriodicites.push(perdDetl[0]);
          //this.selPeriodicityDetl = perdDetl[0];
        }

      }

      if (this.arrProductPeriodicites.length > 0) {
        this.selPeriodicity = this.arrProductPeriodicites[0];
        this.selPeriodicityId =  this.selPeriodicity.id;
        this.calculateFunds();
      }
    } catch (error) {

    }
  }

  getPeriodicityDetails(selPerd) {
    try {
      //this.selPeriodicityDetl = null;
      this.selPeriodicity = selPerd;

    } catch (error) {

    }
  }

  setPeriodicity(perodicity) {
    try {
      // let perdDetl = this.periodicityWisefundsDetails.filter(perd => {
      //   return perodicity == perd.id;
      // });
      this.selPeriodicityId = perodicity.id;
      this.selPeriodicity = perodicity;
      this.calculateFunds();
      // if (perdDetl.length > 0) {
      //   this.selPeriodicity = perdDetl[0];
      //   this.selPeriodicityId =  this.selPeriodicity.id;
      //   this.calculateFunds();
      // }
    } catch (error) {

    }
  }

  calculateFunds() {
    try {

      this.totalPurchasingPower = 0.00;
      this.totalAvailable = 0.00;
      this.totalUtilised = 0.00;
      this.totalMargin = 0.00;

      // this.periodicityWisefundsDetails.forEach(element => {
      //   this.totalPurchasingPower += parseFloat(element.total_available[0].nTotal);
      //   this.totalAvailable += parseFloat(element.available.cash[0].nTotal);
      //   this.totalUtilised += parseFloat(element.available.collateral[0].nTotal);

      // });
      this.totalPurchasingPower = parseFloat(this.selPeriodicity.data.filter(x=>x.sDescription == 'Total Trading Power Limit')[0].nTotal).toFixed(2);
      this.totalAvailable = parseFloat(this.selPeriodicity.data.filter(x=>x.sDescription == 'Total Trading Power Limit')[0].nTotal).toFixed(2);
      this.totalUtilised = parseFloat(this.selPeriodicity.data.filter(x=>x.sDescription == 'Total Utilization')[0].nTotal).toFixed(2);
      // this.totalMargin = ((parseFloat(this.totalPurchasingPower) - parseFloat(this.totalAvailable) - parseFloat(this.totalUtilised)));
      // this.totalMargin = parseFloat(this.totalMargin).toFixed(2);

      //To display as per UI.
      this.totalPurchasingPower = clsCommonMethods.kFormatter(this.totalPurchasingPower);
      this.totalAvailable = clsCommonMethods.kFormatter(this.totalAvailable);
      this.totalUtilised = clsCommonMethods.kFormatter(this.totalUtilised);
      //this.totalMargin = clsCommonMethods.kFormatter(this.totalMargin);

    } catch (error) {
      console.log("Error in calculate funds " + error);
    }
  }

  getTransactionReport() {
    try {
      let strFromDate = this.getDate();
      let strToDate = this.getDate();

      let reqBody = {
        "FromDate": strFromDate,
        "ToDate": strToDate,
        "Status": 2,
        "bankId": "",
        "fund_type" :''
      }
      this.transactionService.recentTransaction(reqBody).then((response: any) => {
        if (response.status == 'success') {
          this.fundsTransactions = response.data;
        } else {
          this.toastProvider.showAtBottom(response.errorString);
        }

      }, err => {
        console.log(err);

      });
    } catch (error) {

    }
  }

  clickAccounts() {
    this.showAccounts = !this.showAccounts;
  }

  goBack() {
    this.navCtrl.pop();
  }

  addFunds(productWisefundsItem: any) {
    this.showContext = false;
    if (productWisefundsItem) {
      this.navParamService.myParam = productWisefundsItem;
    }
    this.navCtrl.navigateForward('fundsadd');
  }

  showContextMenu() {
    this.showContext = !this.showContext;
  }

  availableFunds() {
    this.showContext = false;
    //this.navCtrl.navigateForward('fundsavailable');
    let navParam: NavigationExtras = {
      queryParams: { periodicity: this.selPeriodicity }
    }
    this.navCtrl.navigateForward('fundsavailable', navParam);
  }

  withddrawFunds() {
    this.showContext = false;
    this.navCtrl.navigateForward('fundswithdraw');
  }

  transferFunds(productWisefundsItem: any) {
    this.showContext = false;
    if (productWisefundsItem) {
      this.navParamService.myParam = productWisefundsItem;
    }
    this.navCtrl.navigateForward('fundstransfer');
  }

  recentTransaction() {
    this.showContext = false;
    this.navCtrl.navigateForward('fundstransaction');
  }

  clickPeriodicity() {

    this.showPeriodicitySelection = true;
    this.showPeriodicity = true;

  }

  closePeriodicity() {
    this.showPeriodicity = false;
    this.showPeriodicitySelection = false;
  }

  showProductPeriodicity(product) {

    try {

      // this.arrProductPeriodicites = [];
      // this.selPeriodicity = null;
      // this.totalPurchasingPower = 0.00;
      // this.totalAvailable = 0.00;
      // this.totalUtilised = 0.00;
      // this.totalMargin = 0.00;
      // const element = product.periodicities;

      // let perdDetl = this.periodicityWisefundsDetails.filter(perd => {
      //   return element == perd.id;
      // });

      // if (perdDetl.length > 0) {
      //   this.arrProductPeriodicites.push(perdDetl[0]);
      // }

      // if (this.arrProductPeriodicites.length > 0) {
      //   this.selPeriodicity = this.arrProductPeriodicites[0];
      //   this.calculateFunds();
      // }
     
      this.showPeriodicity = true;
      this.showPeriodicitySelection = false;


    } catch (error) {
      console.log("Error in product peridicity set: ", error.message);
    }

  }

  populatePeriodicity(product){
    try {

      

      this.selProduct = product;
      this.fillPeriodicity();

      this.showPeriodicity = false;
      this.showPeriodicitySelection = false;


    } catch (error) {
      console.log("Error in product peridicity set: ", error.message);
    }
  }


  checkForTransactionElementRendrer() {
    const divElement: HTMLElement = document.getElementById('divTransactionPop');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForTransactionElementRendrer();
      }, 100);
    } else {
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divTransactionPop');

        this.transactionPopupBottomToTop(divElement);
      }, 200);
    }
  }


  transactionPopupBottomToTop(myElementRef) {
    let setting: CupertinoSettings = {
      breaks: {
        top: { // Topper point that pane can reach
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight, // Pane breakpoint height
          bounce: false // Bounce pane on transition
        }
        , middle: {
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight - (250), // Pane breakpoint height
          bounce: false // Bounce pane on transition 
        },
        bottom: {
          enabled: true, // Enable or disable breakpoint 
          height: window.innerHeight - (window.innerHeight * 60 / 100), // Pane breakpoint height
        }
      },
      fastSwipeClose: false,
      dragBy: ['.bottom-card-wrap .pane .draggable'],
      initialBreak: 'bottom',
      bottomClose: false,
      animationType: "ease",
      animationDuration: 300,
      buttonClose: false,
      backdrop: false,
      freeMode: true,
      onDrag: () => {
        let topDiv = this.divTransaction.nativeElement.getBoundingClientRect().top;
        //console.log("onDragEnd" ,topDiv );
        if (topDiv < 250) {
          this.recentTransaction();
        } else {
          //this.showExpandedNetposition = false;
        }
      },
      // onBackdropTap: () => {
      //   //added by omprakash on 24 th jan for backdrop click
      //   //this.hideNetpositionPopup();
      // }
    }
    ///myElementRef.style.visibility = "hidden";
    this.transactionPane = new CupertinoPane(myElementRef, setting);
    this.transactionPane.enableDrag();
    this.transactionPane.present({ animate: true });
    this.divTransaction.nativeElement.style["visibility"] = "visible";
  }

  getDate() {
    try {

      let dateObj = new Date();
      let day = ("0" + dateObj.getDate()).slice(-2);
      let month = ("0" + (dateObj.getMonth() + 1)).slice(-2);
      let year = dateObj.getFullYear();

      let strDate = month + "-" + day + "-" + year;
      return strDate;

    } catch (error) {

    }
  }

  kFormatter(num) {
    return clsCommonMethods.kFormatter(num);
  }

  ionViewWillLeave() {
    if (this.transactionPane != undefined) {
      this.transactionPane.destroy();
    }
  }

}