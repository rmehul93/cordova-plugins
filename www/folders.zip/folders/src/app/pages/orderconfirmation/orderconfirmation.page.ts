import { clsGlobal } from 'src/app/Common/clsGlobal';
import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsConstants } from 'src/app/Common/clsConstants';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-orderconfirmation',
  templateUrl: './orderconfirmation.page.html'
})
export class OrderconfirmationPage implements OnInit {

  dataOE: any = null;
  confirmTxt: any = " You have placed an order to Buy 100 shares of AXISBANK @ Market";
  orderID: any = "NB5784724832;"
  isSLOrder = false;

  constructor(private navCtrl: NavController,
    public modalController: ModalController,
    private paramService: NavParamService) {
    if (this.paramService.myParam) {
      this.modalController.dismiss();
      this.dataOE = this.paramService.myParam;
      this.isSLOrder = (this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_TEXT);
      let symbol = '';
      let Lot :any = '';

      if (this.dataOE.reqBody.scrip_info.expiry_date != undefined &&
        this.dataOE.reqBody.scrip_info.expiry_date != '') {
        let expiry = this.dataOE.reqBody.scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataOE.reqBody.scrip_info.expiry_date.substr(2, 3);

        if (this.dataOE.reqBody.scrip_info.strike_price != '') {
          symbol = this.dataOE.reqBody.scrip_info.symbol + ' ' + expiry + ' OPT ' + this.dataOE.reqBody.scrip_info.strike_price + ' ' + this.dataOE.reqBody.scrip_info.option_type;
        } else {
          symbol = this.dataOE.reqBody.scrip_info.symbol + ' ' + expiry + ' FUT';
        }
      } else {
        symbol = this.dataOE.reqBody.scrip_info.symbol;
      }

      if (!this.dataOE.reqBody.main_leg) {

        if (this.dataOE.reqBody.scrip_info.exchange == clsConstants.C_S_NSE_DERV_API) {

          Lot = this.dataOE.reqBody.quantity / this.dataOE.reqBody.marketLot;
          Lot += " Lot (" + this.dataOE.reqBody.quantity +") ";

        } else {
          
          Lot = this.dataOE.reqBody.quantity;
          if (this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_NSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_BSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_MCXSX_EQ_API ) {
              Lot += " Lot";
          }
        }

        this.confirmTxt = " You have placed an " + (this.isSLOrder ? "SL" : "") + " order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + ((this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT || this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) ? 'Market Price' : this.dataOE.reqBody.price);
        if (this.isSLOrder && this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
          this.confirmTxt += " With SL Trigger @" + this.dataOE.reqBody.trigger_price;
        }
      }
      else {

        if (this.dataOE.reqBody.scrip_info.exchange == clsConstants.C_S_NSE_DERV_API) {
          Lot = this.dataOE.reqBody.main_leg.quantity / this.dataOE.reqBody.marketLot;
          Lot += " Lot";
        } else {
          Lot = this.dataOE.reqBody.main_leg.quantity;
          if (this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_NSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_BSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_MCXSX_EQ_API ) {
              Lot += " Lot";
          }
        }

        let order_price = !this.dataOE.reqBody.trail ? 'Market Price' : (this.dataOE.reqBody.main_leg.price == 0 ? 'Market Price' : this.dataOE.reqBody.main_leg.price);
        if (!this.dataOE.reqBody.profit_leg) {
          this.confirmTxt = " You have placed an Intraday(CO) order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + order_price;
          this.confirmTxt += " with SL Trigger @" + this.dataOE.reqBody.stoploss_leg.legs[0].trigger_price + " , SL @" + this.dataOE.reqBody.stoploss_leg.legs[0].price;
        } else {
          this.confirmTxt = " You have placed an Intraday(BO) order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + order_price;
          this.confirmTxt += " with SL Trigger @" + this.dataOE.reqBody.stoploss_leg.legs[0].trigger_price + " , SL @" + this.dataOE.reqBody.stoploss_leg.legs[0].price;
          this.confirmTxt += " , Trailing SL @" + this.dataOE.reqBody.stoploss_leg.trail.stoploss_jump_price + " and Book Profit @" + this.dataOE.reqBody.profit_leg.legs[0].price;
        }

      }
      this.orderID = this.dataOE.response.data.orderId;
    }
  }
  _setVar;
  ngOnInit() {
   try {
     //auto close this page after 5 sec if user has not click.
   this._setVar=  setTimeout(() => {
      this.closeConfirmation(); 
    }, 5000); 
   } catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderconfirmationPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
   }
  }

  ionViewDidLeave(){
     //prevent settimeout to execute if user close the confirmation box.
    clearTimeout(this._setVar);
  }
  /**
   * @method : Close Order Confirmation box and route to watchlist
   */
  closeConfirmation() {
    try {
      this.navCtrl.pop().then(() => this.navCtrl.pop());
      //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderconfirmationPage', 'closeConfirmation',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method : Route to Transaction page
   */
  gotoTransaction() {
    try {
      this.paramService.myParam.mode = 'open';
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "gotoTransaction", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderconfirmationPage', 'gotoTransaction',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
