import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ScreenerMainPage } from './screener-main.page';

const routes: Routes = [
  {
    path: '',
    component: ScreenerMainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ScreenerMainPageRoutingModule {}
