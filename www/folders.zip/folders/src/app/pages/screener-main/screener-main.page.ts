import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsConstants } from '../../Common/clsConstants';
import { clsHttpService } from '../../Common/clsHTTPService';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { clsTradingMethods } from '../../Common/clsTradingMethods';
import { clsLocalStorageService } from '../../Common/clsLocalStorageService';
import { TranslateService } from '@ngx-translate/core';
import { NavParamService } from 'src/app/providers/nav-param.service';

@Component({
  selector: 'app-screener-main',
  templateUrl: './screener-main.page.html',
})
export class ScreenerMainPage implements OnInit {
  showNewscreener: boolean = false;
  hideMe = false;
  isEqAllowed: boolean = false;
  isDerAllowed: boolean = false;
  isCurrencyAllowed: boolean = false;
  isCommAllowed: boolean = false;
  ExchangeToDisplay: any = [];
  segmentSelected: any = "1";
  dropDownData: any = [];
  scannerList: any = [];
  indexListObject: any = [];
  IndexList: any = [];
  selectedExchange: any = '';
  globalScannerList: any = [];
  selectedIndex: any = '';
  segmentselectfirsttime: boolean = true;
  count: any = 0;
  segmenthide: boolean = false;
  bIsLoggedIn: boolean = false;
  aPriceBasedScannerList: any = [];
  aVolumeBasedScannerList: any = [];
  aOIBasedScannerList: any = [];
  //aTechnicalBasedScannerList: any = [];
  //aFundamentalBasedScannerList: any = [];
  myFavouritesScannerList: any = [];
  showFav: boolean = false;
  showPriceBased: boolean = true;
  favScreeners: any = [];
  dsplyTabsLst: any = {
    tb1: 'My Favourites',
    tb2: 'Price Based',
    tb3: 'Volume Based',
    /*tb4: 'Technical',
    tb5: 'Fundamental',*/
    tb6: 'Market Diary',
    tb7: 'OI Based'
  };
  tabName: string = this.dsplyTabsLst.tb1;//'My Favourites';
  labelSelected: string = this.dsplyTabsLst.tb1;
  aReportsList: any = [];

  constructor(private navCtrl: NavController, public objHttpService: clsHttpService, private objStorage: clsLocalStorageService,
    public objToast: ToastServicesProvider, public translate: TranslateService, private paramService: NavParamService,
  ) { }

  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
    }
    catch (e) { }
    try {
      // this.objStorage.getItem('isLoggedInUser')
      // .then((res: any) => {
      //if (res != null && res != undefined) {
      if (clsGlobal.User.sessionId) {
        this.bIsLoggedIn = true;
      }
      else {
        this.bIsLoggedIn = false;
      }
      // }
      // else {
      //     this.bIsLoggedIn = false;
      // }
      //});

    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("ScreenerMainPage", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }

    this.isEqAllowed = false;
    this.isDerAllowed = false;
    this.isCommAllowed = false;
    this.isCurrencyAllowed = false;
    this.ExchangeToDisplay = [];

    clsGlobal.logManager.writeUserAnalytics("ScreenersPage", "", "VISIT", "");

    // if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MSX_CASH.toString()) == clsConstants.C_S_ON) {
    this.isEqAllowed = true;
    this.count++;
    //}

    // if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
    this.isDerAllowed = true;
    this.count++;
    //}

    // if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
    this.isCommAllowed = true;
    this.count++;
    //}

    // if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON ||
    //   clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
    this.isCurrencyAllowed = true;
    this.count++;
    //}

    if (this.count == 1) {
      this.segmenthide = true;
    }

    if (this.segmentselectfirsttime == true) {
      if (this.isEqAllowed) {
        this.segmentSelected = '1';
      }
      else if (this.isDerAllowed) {
        this.segmentSelected = '2';
      }
      else if (this.isCommAllowed) {
        this.segmentSelected = '3';
      }
      else if (this.isCurrencyAllowed) {
        this.segmentSelected = '4';
      }
      this.segmentselectfirsttime = false;
    }


    this.getSegmentExchanges();
    this.getScannerList();
    this.getAllIndexSectorList();
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("ScreenerMainPage", "", "VISIT", "");
  }
  ionViewWillEnter() {
    this.fetchFavScreeners();
  }

  newScreener() {
    this.showNewscreener = !this.showNewscreener;
  }
  showScreenerView() {
    this.navCtrl.navigateForward('screener-view');
  }
  goBack() {
    this.navCtrl.pop();
  }
  //Added by Vivian F start

  segmentTypeSelected(event) {
    this.segmentSelected = event.value;
    this.populateScreener();
  }
  switchTab(event) {
    this.labelSelected = event;
    this.tabName = event;
    //this.myFavouritesScannerList = this.scannerList;
    if (this.labelSelected == 'My Favourites') {
      this.scannerList = this.favScreeners;
    }
    else if (this.labelSelected == 'Price Based') {
      this.scannerList = this.aPriceBasedScannerList;
    }
    else if (this.labelSelected == 'Volume Based') {
      this.scannerList = this.aVolumeBasedScannerList;
    }
    /*else if (this.labelSelected == 'Technical') {
      this.scannerList = this.aTechnicalBasedScannerList;
    }
    else if (this.labelSelected == 'Fundamental') {
      this.scannerList = this.aFundamentalBasedScannerList;
    }*/
    else if (this.labelSelected == 'OI Based') {
      this.scannerList = this.aOIBasedScannerList;
    }
    else if (this.labelSelected == 'Market Diary') {
      this.scannerList = this.aReportsList;
    }
    //this.getSegmentExchanges()
    this.filterIndexDropDown(this.selectedExchange);
  }

  listItemClick(item) {
    let segSlctd = this.segmentSelected;
    if (item.GroupName.toUpperCase() == 'FUTURE OI GAINERS/LOSERS' || item.GroupName.toUpperCase() == 'MOST ACTIVE INDEX/STOCKS OPTIONS') {
      segSlctd = 2;
    }

    let objScanner: any = {
      segSelcted: segSlctd,
      eqAllowed: this.isEqAllowed,
      dervAllowed: this.isDerAllowed,
      commAllowed: this.isCommAllowed,
      currAllowed: this.isCurrencyAllowed,
      scannerItem: item,
      //tabsList: tabsList,
      //hdrName: hdrName 
    };
    this.segmentselectfirsttime = true;
    this.paramService.myParam = objScanner;
    if (item.GroupName.toUpperCase() == 'FII/DII/MF ACTIVITY') {
      this.navCtrl.navigateForward('fii-dii-mf');
    } else if (item.GroupName.toUpperCase() == 'BULK/BLOCK DEALS') {
      this.navCtrl.navigateForward('bulk-block-deals');
    } else if (item.GroupName.toUpperCase() == 'MERGER & ACQUISITION') {
      this.navCtrl.navigateForward('merger-demerger-details');
    } else if (item.GroupName.toUpperCase() == "PREMIUM / DISCOUNT") {
      this.navCtrl.navigateForward('premium-discount');
    }
    else {
      this.navCtrl.navigateForward('screener-view');
    }
  }

  getSegmentExchanges() {

    let ddItem = null;
    try {
      if (this.segmentSelected == 1) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_CASH);
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_CASH);
        //}
      }
      else if (this.segmentSelected == 2) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_DERIVATIVES);
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_DERIVATIVES);
        //}

      }
      else if (this.segmentSelected == 3) {
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_MCX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_MCX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        let valueAll2: any = {};
        valueAll2.exchName = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        valueAll2.exchID = clsConstants.C_V_NCDEX_DERIVATIVES;
        ddItem.Value = valueAll2;
        //ddItem.Value = clsConstants.C_V_NCDEX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
      }
      else if (this.segmentSelected == 4) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_NSX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_NSX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        let valueAll: any = {};
        valueAll.exchName = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        valueAll.exchID = clsConstants.C_V_BSECDX_DERIVATIVES;
        ddItem.Value = valueAll;
        //ddItem.Value = clsConstants.C_V_BSECDX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

      }

      this.selectedExchange = this.dropDownData[0].Name;

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'getSegmentExchanges',error.Message,undefined,error.stack,undefined,undefined));
      this.objToast.showAtBottom(error);
    }
  }

  addExchange(exchange, value) {

    let valueAll: any = {};

    valueAll.exchName = exchange;
    valueAll.exchID = value;
    valueAll.flagIndexSector = 0;

    let valueIndex: any = {};
    valueIndex.exchName = exchange;
    valueIndex.exchID = value;
    valueIndex.flagIndexSector = 1;

    let valueSector: any = {};
    valueSector.exchName = exchange;
    valueSector.exchID = value;
    valueSector.flagIndexSector = 2;

    let ddItem: any = {};
    ddItem.Name = exchange + " All";
    ddItem.Value = valueAll;
    if (this.dropDownData.length > 0) {
      this.dropDownData.splice(1, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;

    ddItem = {};
    ddItem.Name = exchange + " Index";
    ddItem.Value = valueIndex;
    if (this.dropDownData.length > 2) {
      this.dropDownData.splice(3, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;

    ddItem = {};
    ddItem.Name = exchange + " Sector";
    ddItem.Value = valueSector;
    if (this.dropDownData.length > 4) {
      this.dropDownData.splice(5, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;

  }

  getScannerList() {

    if (clsGlobal.scannerList == undefined || clsGlobal.scannerList.length == 0) {
      //"http://172.25.100.174:8161/"
      this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + 'v1/getAppWaveScannerDetails')
        .subscribe((respData: any) => {
          this.scannerList = [];
          if (respData.status) {
            this.globalScannerList = respData.result;
            clsGlobal.scannerList = this.globalScannerList;
            this.populateScreener();
          }
        }, error => {

        });
    } else {

      this.globalScannerList = clsGlobal.scannerList;
      this.populateScreener();
    }
  }

  populateScreener() {
    try {

      this.scannerList = [];
      // for (let i = 0; i < this.globalScannerList.length; i++) {

      //   if ((this.segmentSelected == 1 && this.globalScannerList[i].EqAllowed == true)
      //     || (this.segmentSelected == 2 && this.globalScannerList[i].DervAllowed == true)
      //     || (this.segmentSelected == 3 && this.globalScannerList[i].CommAllowed == true)
      //     || (this.segmentSelected == 4 && this.globalScannerList[i].CurrAllowed == true)) {
      //     //IsLoggedIn &&
      //     if (this.globalScannerList[i].FundamentalTechnical == 'T' &&
      //       (this.globalScannerList[i].IsEnabled == 1 ||
      //         (this.globalScannerList[i].IsEnabled > 1))) {
      //       this.scannerList.push(this.globalScannerList[i]);
      //     }
      //   }
      // }


      this.aPriceBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Price Based";
      });
      this.aVolumeBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Volume Based";
      });
      /*this.aTechnicalBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Technical Based";
      });*/
      this.aOIBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "OI Based";
      });
      /*this.aFundamentalBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Fundamental Based";
      });*/
      this.aReportsList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Market Diary";
      });

      //this.scannerList = this.favScreeners;;


    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'populateScreener',error.Message,undefined,error.stack,undefined,undefined));
      this.objToast.showAtBottom(error);
    }
  }

  getAllIndexSectorList() {

    if (clsGlobal.indexSectorList == undefined || clsGlobal.indexSectorList.length == 0) {
      //"http://172.25.100.174:8161/"
      this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + 'v1/getIndexSectorList')
        .subscribe((respData: any) => {
          if (respData.status) {

            this.indexListObject = [];

            for (let i = 0; i < respData.result.length; i++) {
              const indexObj = respData.result[i];

              for (let index = 0; index < indexObj.length; index++) {
                const element = indexObj[index];
                let indexDetail: any = {};
                indexDetail.nIndex = element.Name;
                indexDetail.nFlag = element.Flag;
                indexDetail.nMapMarketSegmentId = element.nMktSegId;
                indexDetail.nMarketSegmentId = clsTradingMethods.GetMarketSegmentID(parseInt(indexObj.nMktSegId));
                indexDetail.nExchange = element.Exchange;
                indexDetail.nCode = element.Code;
                indexDetail.DisplayName = element.Exchange + ' - ' + element.Name;
                indexDetail.ProfileId = '900';
                this.indexListObject.push(indexDetail);
              }

              //Global.IndexListObject.push(indexDetail);
            }

            clsGlobal.indexSectorList = this.indexListObject;
            //this.filterIndexDropDown(this.selectedExchange);
          }
        }, error => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'getAllIndexSectorList',error.Message,undefined,error.stack,undefined,undefined));
        });
    } else {
      this.indexListObject = clsGlobal.indexSectorList;
    }
  }

  filterIndexDropDown(selitem) {

    this.IndexList = [];
    let selectedItem = this.dropDownData.filter((element, index, array) => {
      return element.Name == selitem;
    });

    if (selectedItem[0].Value.flagIndexSector == 0) {
      this.IndexList = [{ "Name": "All", "Value": "All" },];
      //IndexSectorDisable = false;
    }
    else {
      for (var i = 0; i < this.indexListObject.length; i++) {
        if (this.indexListObject[i].nExchange == selectedItem[0].Value.exchName &&
          this.indexListObject[i].nFlag == selectedItem[0].Value.flagIndexSector) {
          let ddItem: any = {};
          ddItem.Name = this.indexListObject[i].nIndex;
          ddItem.Value = this.indexListObject[i];
          this.IndexList.push(ddItem);
          ddItem = null;
        }
      }
    }

    if (this.IndexList.length > 0)
      this.selectedIndex = this.IndexList[0].Name;
  }

  async fetchFavScreeners() {
    try {
      await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          this.favScreeners = [];
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.favScreeners = obj;
            //this.scannerList = this.favScreeners;
          }
          this.switchTab(this.labelSelected);

        }, error => {
          //console.log('Error while retrieving local storage details.' + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'fetchFavScreeners',error.Message,undefined,error.stack,undefined,undefined));
        });
    } catch (error) {
      //console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerMainPage', 'fetchFavScreeners2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //end

}
