import { AppsyncDbService } from './../../providers/appsync-db.service';
import { clsGlobal } from './../../Common/clsGlobal';
import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods'; 
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-order-product-type',
  templateUrl: './order-product-type.page.html', 
})
export class OrderProductTypePage implements OnInit {
  productTypes: any = [];
  defaultType: string = "INTRADAY";
  exchangePref: any;
  fcmTopicPref: any;
  profilePicPref: any;
  inAppNotificationPref: any;
  orderParam = {
    productType: '',
    protectionPerc: ''
  }
  showProductType:boolean = false;
  showExchange:boolean = false;
  exchangeAllowedArry: any = [];
  selExchange: any;
  selMarketSegId : any;
  selSelected : boolean = false;
  selProductType: any;
  selProtection : any= 0.00;
  prevProductType : any;
  ExchangeArrayList: any = [];
  isProductTypeChange : boolean = false;
  isProtectionChange : boolean = false;
  isGoBack :  boolean = false;
  isProtectionAvailable : boolean = false;
  disableSaveBtn : boolean = false;
  defaultProductTypeText :any = "Select Product Type";
  constructor(private navCtrl: NavController, 
    private alertProvider: AlertServicesProvider,
    private appSync: AppsyncDbService,
    public toastProvider: ToastServicesProvider) { }

  ngOnInit() {
    try {
      this.getExchange();
      if (clsGlobal.User.userPreference.sExchange != undefined && clsGlobal.User.userPreference.sExchange != "" && clsGlobal.User.userPreference.sExchange != null && clsGlobal.User.userPreference.sExchange.length != 0 && clsGlobal.User.userPreference.sExchange !="[]" && JSON.parse(clsGlobal.User.userPreference.sExchange).length != undefined) {
        let exchange = JSON.parse(clsGlobal.User.userPreference.sExchange);
        this.loadProductTypeAsPerExchange(exchange[0].marketSegmentId)
      } else {
        if(clsGlobal.User.productTypesList != '' && clsGlobal.User.productTypesList != undefined && clsGlobal.User.productTypesList !=null){
          for (let i = 0; i < clsGlobal.User.productTypesList.length; i++) {
          if (clsGlobal.User.productTypesList[i] != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
            clsGlobal.User.productTypesList[i] != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
            this.productTypes.push(clsGlobal.User.productTypesList[i]);
          }
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'ngOnInit', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillEnter() {
    try {
      if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != "") {
        this.exchangePref = clsGlobal.User.userPreference.sExchange;
        this.fcmTopicPref = clsGlobal.User.userPreference.sNotification;
        this.profilePicPref = clsGlobal.User.userPreference.sProfilePicPath;
        this.inAppNotificationPref = clsGlobal.User.userPreference.sInAppNotification
        if (clsGlobal.User.userPreference.sExchange != undefined && clsGlobal.User.userPreference.sExchange != "" && clsGlobal.User.userPreference.sExchange != null){
          let exchProd = JSON.parse(clsGlobal.User.userPreference.sExchange); 
          
          if(exchProd.length >0 ){
            this.ExchangeArrayList = exchProd;
            this.selExchange = exchProd[0].exchange == '' || exchProd[0].exchange == undefined || exchProd[0].exchange == '""' ?  this.exchangeAllowedArry[0].exchangeDesc: exchProd[0].exchange;
            this.selProductType =  exchProd[0].productType == "" || exchProd[0].productType == undefined ? this.defaultProductTypeText: exchProd[0].productType;
            this.selMarketSegId = exchProd[0].marketSegmentId  == "" || exchProd[0].marketSegmentId == undefined  ? clsTradingMethods.getMktSegFromApiExchangeName(clsGlobal.User.exchangesList[0]) : exchProd[0].marketSegmentId; 
            this.selProtection = exchProd[0].protection == "NaN" ? 0.00 : exchProd[0].protection;
            this.checkProtectionAvailable(this.selExchange);
          }else {
            this.selExchange = this.exchangeAllowedArry[0].exchangeDesc;
            this.selProductType = this.defaultProductTypeText; //this.productTypes[0];
            this.selMarketSegId =  clsTradingMethods.getMktSegFromApiExchangeName(clsGlobal.User.exchangesList[0]); 
            this.checkProtectionAvailable(this.selExchange);
          }
          this.exchangeAllowedArry.filter(x => {
            if (x.exchangeDesc == this.selExchange ) {
              x.selected = true;
              this.selSelected = true;
            }
          })
        }
      } else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            this.exchangePref = res[0].sExchange;
            this.fcmTopicPref = res[0].sNotification;
            this.profilePicPref = res[0].sProfilePicPath;
            this.inAppNotificationPref = res[0].sInAppNotification;
            if(res[0].sExchange != null && res[0].sExchange != undefined && res[0].sExchange != ''){
              let exchProd = JSON.parse(res[0].sExchange); 
              this.ExchangeArrayList = exchProd;
              if(exchProd.length >0 ){
                this.selExchange = exchProd[0].exchange == '' || exchProd[0].exchange == undefined ||  exchProd[0].exchange == '""'?  this.exchangeAllowedArry[0].exchangeDesc: exchProd[0].exchange;
                this.selProductType =  exchProd[0].productType == "" || exchProd[0].productType == undefined ? this.defaultProductTypeText: exchProd[0].productType;
                this.selMarketSegId = exchProd[0].marketSegmentId  == "" || exchProd[0].marketSegmentId == undefined  ? clsTradingMethods.getMktSegFromApiExchangeName(clsGlobal.User.exchangesList[0]) : exchProd[0].marketSegmentId; 
                this.selProtection = exchProd[0].protection == "NaN" ? 0.00 : exchProd[0].protection;
                this.checkProtectionAvailable(this.selExchange);
              }else {
                this.selExchange = this.exchangeAllowedArry[0].exchangeDesc;
                this.selProductType = this.defaultProductTypeText; //this.productTypes[0];
                this.selMarketSegId =  clsTradingMethods.getMktSegFromApiExchangeName(clsGlobal.User.exchangesList[0]); 
                this.checkProtectionAvailable(this.selExchange);
              }
              this.exchangeAllowedArry.filter(x => {
                if (x.exchangeDesc == this.selExchange ) {
                  x.selected = true;
                  this.selSelected = true;
                }
              })
            }
          }
        }).catch(error => {
          console.log("Error in getting user preference : " + error.message);
          //clsGlobal.logManager.writeErrorLog('order-product-type', 'ionViewWillEnter_1', error.message);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
        })
      }
    } catch (error) {
      console.log("Error ionViewWillEnter" + error);
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'ionViewWillEnter_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'ionViewWillEnter2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
  * @method Navigate to previous page
  */
   goBack() {
    try {
      this.isGoBack = true;
      if(this.isProductTypeChange || this.isProtectionChange){
         this.showPopup('');
      }
      else{
        this.isGoBack = false;
        this.navCtrl.pop();

      }  
    } catch (error) {
      this.navCtrl.pop();
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'goBack_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'goBack',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
  * @method Save Load Exchange as per selected exchange
  */
  loadProductTypeAsPerExchange(MarketSegmentId) {
    try {
      let productTypeArry = clsGlobal.ExchManager.dcProductType.getItem(MarketSegmentId)
      if (productTypeArry != "") {
        this.productTypes = productTypeArry.split('$');
        let tempProductTypeArray = [];
        for (let index = 0; index < this.productTypes.length; index++) {
          const element = this.productTypes[index];
          
          if (element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
            element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT){
            if(element == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT || element == clsConstants.C_S_PRODUCTTYPE_PTST_TEXT){
              if(MarketSegmentId == 1 || MarketSegmentId == 3|| MarketSegmentId == 15){
                tempProductTypeArray.push(element);
              }
            }
            else{
              tempProductTypeArray.push(element);
            }
            
          }  
        }
        if(tempProductTypeArray.length != 0){
          this.productTypes = tempProductTypeArray;
        }
        else{
          if(clsGlobal.User.productTypesList != '' && clsGlobal.User.productTypesList != undefined && clsGlobal.User.productTypesList !=null){
            for (let i = 0; i < clsGlobal.User.productTypesList.length; i++) {
              if (clsGlobal.User.productTypesList[i] != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
                clsGlobal.User.productTypesList[i] != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT){
                if(clsGlobal.User.productTypesList[i] == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT || clsGlobal.User.productTypesList[i] == clsConstants.C_S_PRODUCTTYPE_PTST_TEXT){
                  if(MarketSegmentId == 1 || MarketSegmentId == 3|| MarketSegmentId == 15){
                    tempProductTypeArray.push(clsGlobal.User.productTypesList[i]);
                  }
                }
                else{
                  tempProductTypeArray.push(clsGlobal.User.productTypesList[i]);
                }
              }
            }
          }
          this.productTypes = tempProductTypeArray;
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'loadProductTypeAsPerExchange', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'loadProductTypeAsPerExchange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ProductTypePopup(){
    try{
      this.showProductType = !this.showProductType;
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'ProductTypePopup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'ProductTypePopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ExchangePopup(){
    try{
      this.showExchange = !this.showExchange;
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'ExchangePopup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'ExchangePopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  plusminus(value){
    try {
      if (value == 'plus') {
        if (parseFloat(this.selProtection) >= 99.99) {
          return;
        }
        this.selProtection = (parseFloat(this.selProtection) + 1).toFixed(2);
      }
      else if (value == 'minus') {
        if (parseFloat(this.selProtection) <= 0) {
          return;
        }
        this.selProtection = (parseFloat(this.selProtection) - 1).toFixed(2);
      }
      this.onProtectionPercChange(this.selProtection);
    } catch (error) {
      console.log(error);
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'plusminus', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'plusminus',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getExchange(){
    try{
      let exchangeArry = clsGlobal.User.exchangesList;
        exchangeArry.forEach(element => {
          let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element);
          if(mktSegId != undefined && mktSegId != '' && mktSegId != null){
            this.exchangeAllowedArry.push({ MarketSegmentId: mktSegId, exchangeDesc: clsTradingMethods.getExchangeNameDesc(parseInt(mktSegId)), selected: false });
          }
          });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'getExchange', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'getExchange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onExchangeChange(item: any) {
    try {
      if(this.isProductTypeChange || this.isProtectionChange){
        this.showPopup(item);
      }else{
        this.changeExchangeData(item);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'onExchangeChange', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'onExchangeChange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onProductTypeChange() {
    try{
      this.isProductTypeChange = true;
      if(this.isProductTypeChange){
        this.disableSaveBtn = true;
      }
      console.log(this.selProductType);
    }
    catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'onProductTypeChange', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'onProductTypeChange',error.Message,undefined,error.stack,undefined,undefined));
    }  
   
  }

  onProtectionPercChange(event){
    try{
      console.log(event);
      this.isProductTypeChange = true;
      if( this.isProductTypeChange){
        this.disableSaveBtn = true;
      }
      this.selProtection = event;
    }
    catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'onProtectionPercChange', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'onProtectionPercChange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showPopup(item){
    try{
      let buttons: any = ["Save", "Discard"];
      this.alertProvider.showAlertConfirmWithButtons( "Wave 2", "Do you want to save changes?", buttons,
      (response) => {
        // not a lazzy load page.
        console.log(response);
        this.saveUpdatedOrderPreference(item);
      }, (error) => {
        //fail No or cancel click //do nothing.
        this.isProductTypeChange = false;
        this.isProtectionChange = false;
        this.disableSaveBtn = false;
      
         if(this.isGoBack){
          this.navCtrl.pop();
        }else{
          if(item){
            this.changeExchangeData(item);
          }
        }
        //clsGlobal.logManager.writeErrorLog('order-product-type', 'showPopup_1', error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'showPopup_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'showPopup_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'showPopup_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  saveUpdatedOrderPreference(item){
    try{
      this.isProductTypeChange = false;
      this.isProtectionChange = false;
      this.disableSaveBtn = false;
      let isExchangeAvailable = false;
      //this.isSettingChange  =true ; 
      for (let i = 0; i < this.ExchangeArrayList.length; i++) {
        if (this.ExchangeArrayList[i].exchange == this.selExchange) {
          this.ExchangeArrayList[i].protection = this.selProtection;
          this.ExchangeArrayList[i].productType = this.selProductType;
          isExchangeAvailable = true;
          break;
        }
      }

      if (!isExchangeAvailable) {
        this.ExchangeArrayList.push(
          {
            "exchange": this.selExchange,
            "productType": this.selProductType,
            "marketSegmentId" : this.selMarketSegId,
            "selected" : this.selSelected,
            "protection" : this.selProtection
          }
        )
      }
      if(this.ExchangeArrayList != undefined){
        let userPrefObj = {
          sExchange: JSON.stringify(this.ExchangeArrayList),
          sInAppNotification: this.inAppNotificationPref,
          sNotification: this.fcmTopicPref == null ? JSON.stringify(clsGlobal.lstTopicList) : this.fcmTopicPref,
          //sOrder: this.orderPref,
          sProfilePicPath: this.profilePicPref,
          sTheme: clsGlobal.defaultTheme,
        }

        this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
          clsGlobal.User.userPreference = userPrefObj;
          this.toastProvider.showAtBottom("Your preferences saved succesfully.");
          if(this.isGoBack){
            this.navCtrl.pop();
          }else{
            if(item){
              this.changeExchangeData(item);
            }
          }
        }).catch(error => {
          if(this.isGoBack){
            this.navCtrl.pop();
          }
          //clsGlobal.logManager.writeErrorLog('order-product-type', 'saveUpdatedOrderPreference_1', error.message);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'saveUpdatedOrderPreference_1',error.Message,undefined,error.stack,undefined,undefined));
        })
      }
      
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'saveUpdatedOrderPreference_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'saveUpdatedOrderPreference_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  changeExchangeData(item){
    try{
      if(item != ''){
        let productAvailable = false;
        this.productTypes = [];
        item.selected = true;
        this.selExchange = item.exchangeDesc;
        this.selMarketSegId = item.MarketSegmentId;
        this.selSelected = item.selected;
        this.checkProtectionAvailable(this.selExchange);
        this.loadProductTypeAsPerExchange(this.selMarketSegId);
          for (let i = 0; i < this.ExchangeArrayList.length; i++) {
            if (this.ExchangeArrayList[i].exchange == this.selExchange) { 
              this.selProductType = this.ExchangeArrayList[i].productType;
              this.selProtection = this.ExchangeArrayList[i].protection;
              productAvailable = true;
              break;
            }
          }
          if(!productAvailable){
            this.selProductType = this.defaultProductTypeText; //this.productTypes[0];
            this.selProtection = 0.00;
            // this.isProductTypeChange = false;
            // this.isProtectionChange = false;
          }

        this.exchangeAllowedArry.filter(x => {
              if (x.selected) {
                x.selected = false;
              }
        })
      }
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('order-product-type', 'changeExchangeData', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProductTypePage', 'changeExchangeData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkProtectionAvailable(exchange){
    if(exchange == "BSE CASH" || exchange == "MCX FUTURES" || exchange == "MCXSX_FIM" || exchange == "BSECDS" || exchange == "BSE COMM" ){
      this.isProtectionAvailable = true;
    }
    else{
      this.isProtectionAvailable = false;
    }
  }
}

