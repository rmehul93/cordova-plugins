import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OrderProductTypePage } from './order-product-type.page';

const routes: Routes = [
  {
    path: '',
    component: OrderProductTypePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderProductTypePageRoutingModule {}
