import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OrderProductTypePageRoutingModule } from './order-product-type-routing.module';

import { OrderProductTypePage } from './order-product-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OrderProductTypePageRoutingModule
  ],
  declarations: [OrderProductTypePage]
})
export class OrderProductTypePageModule {}
