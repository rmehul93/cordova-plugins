import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { OrderProductTypePage } from './order-product-type.page';

describe('OrderProductTypePage', () => {
  let component: OrderProductTypePage;
  let fixture: ComponentFixture<OrderProductTypePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderProductTypePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OrderProductTypePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
