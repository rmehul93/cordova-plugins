import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal'; 
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
@Component({
  selector: 'app-network-error',
  templateUrl: './network-error.page.html', 
})
export class NetworkErrorPage implements OnInit {

  isUATEnvironment:boolean=false;
  constructor( private navCtrl : NavController, 
    private localstorageservice: clsLocalStorageService,
    private navParam: NavParamService, 
    private appSync : AppsyncDbService,
    private toastservice: ToastServicesProvider
    ) { }

  ngOnInit() {
  this.isUATEnvironment=  this.navParam.myParam;
  }

  networkReferesh()
  {
    try{
   if (clsPluginConstants.NetWorkConnected) {
      if (this.isUATEnvironment) {
        this.localstorageservice.getItem("IS_UAT_SET").then((envset: any) => {
          if (envset == null) {
            this.navCtrl.navigateRoot('uatenvionment-setting');
          }
          else {
            clsGlobal.ComId = envset.ComId
            clsGlobal.LocalComId = envset.LocalComId;
            clsGlobal.URL = envset.URL;
            clsGlobal.PORT = envset.PORT;
            clsGlobal.VirtualDirectory = clsGlobal.URL + clsGlobal.PORT;
            clsGlobal.URL_CDSSERVER = clsGlobal.URL + clsGlobal.PORT + 'cds/';
            this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
          }
        }).catch((error) => {
        });
      }
      else {
        //changes for Welcome text display on Init screen.
        this.appSync.getAppInfoKeyValue(clsAppConfigConstants.APP_INIT_SCREEN_TEXT).then((data) => {
          let _welcomeText = null;
          if (data != null) {
            data.forEach(element => {
              _welcomeText = element.sParamValue;
              if (element.sTenantId == clsGlobal.ComId) {
                return;
              }
            });
          }
          this.navParam.myParam = _welcomeText || null;
          this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
        }).catch((error) => {
          this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
        });
      }
    }
    else {
      this.toastservice.showAtBottom('No Internet. Please Check your internet connection.');
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('NetworkErrorPage', 'networkReferesh',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
}
