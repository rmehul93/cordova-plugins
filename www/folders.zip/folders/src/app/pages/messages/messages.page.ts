import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsConstants } from './../../Common/clsConstants';
import { Component, OnInit } from '@angular/core';
import { Platform , NavController } from '@ionic/angular';
import { clsHttpService } from '../../Common/clsHTTPService';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { DatePipe } from '@angular/common';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.page.html',
})
export class MessagesPage implements OnInit {
  filterPopup = false;
  showContextMenu = false;
  iPageNo: number = clsConstants.CDS_PAGE_NO;
  iPageNo_exchMsg: number = clsConstants.CDS_PAGE_NO;
  iPageNo_brokMsg: number = clsConstants.CDS_PAGE_NO;
  exchMsgList: any = [];
  orderMsgList: any = [];
  brokerMsgList: any = [];
  noofhrs: any = "1";
  showExchange: boolean = false;
  statusmode: any = "BROKERMESSAGE";

  exchangeAllowedArry: any = [];
  selectedValue: string = "";
  selectedExch: any;
  infiniteScroll: any;
  loadMoreData: boolean = false;

  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = "";
  messageSearchData = []
  showSearch: boolean = false;
  refresherInstance: any;
  showLoader: boolean = false;
  disableloaderonrefresh: boolean = false;
  noDataFound: boolean = false;

  notificationtoggle: any = 'ALL';
  notificationselection: any = 'ALL'
  recoCnt: number = 10;
  notifydataAllData: any=[];
  tempNotifyAllData:any=[];
  tempNotifyMyData:any=[];
  notifydataMyData: any=[];
  //refresherInstance: any;
  //noDataFound:boolean =false;
  showNotifPopUp: boolean = false;
  notifArry = [ "All","My"];
  selectedNotifType:any = "All";

  constructor(private navCtrl: NavController,
    private httpService: clsHttpService,
    public dateFormatter: DatePipe,
    public toastCtrl: ToastServicesProvider,
    public platform: Platform,) { }

  ngOnInit() {
    try {
      clsGlobal.logManager.writeUserAnalytics("MessagesPage", "", "VISIT", "");
      //this.getBrokerMessages();
      this.getNotification();
      this.getExchange();
      //this.getNotif();
      this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValues(search));
      console.log("Message...");
    } catch (error) {
      console.log("Error ngOnInit " + error);
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("MessagesPage", "", "VISIT", "");
  }

  /**
   * @author : Rajendra Sirvi
   * @date : 21/12/2020
   * @USD : BT-37759
   * @description : Go back to previous page.
   */
  goBack() {
    this.navCtrl.pop();
  }

  /**
 * @author : Rajendra Sirvi
 * @date : 21/12/2020
 * @USD : BT-37759
 * @description : Open Filter popup.
 */
  showfilter() {
    this.filterPopup = !this.filterPopup;
  }

  showContext() {
    this.showContextMenu = !this.showContextMenu;
  }

  /**
   * @method : Toggling event between broker, orders and exchanges tab
   */
  eventChanged(event, fromRefresh: boolean) {
    try {
      this.statusmode = fromRefresh == true ? event : event.detail.value;
      this.showExchange = false;
      this.noDataFound = false;
      this.loadMoreData = false;
      if (this.refresherInstance != undefined) {
        this.refresherInstance.target.complete();
      }
      if (this.statusmode == "ORDERMESSAGE") {
        this.showLoader = true;
        if (this.orderMsgList.length > 0) {
          this.showLoader = false;
          return;
        }
        else {
          this.orderMsgList = [];
          this.iPageNo = clsConstants.CDS_PAGE_NO;
          this.getOrderMessages();
        }
      }
      else if (this.statusmode == "EXCHANGEMESSAGE") {
        // this.showLoader = true;
        if (this.exchMsgList.length > 0) {
          this.showLoader = false;
          return;
        }
        else {
          this.exchMsgList = [];
          this.iPageNo_exchMsg = clsConstants.CDS_PAGE_NO;
          this.getExchangeMessages(this.selectedExch);
        }

      }
      else if (this.statusmode == "BROKERMESSAGE") {
        this.showLoader = true;
        if (this.brokerMsgList.length > 0 && !fromRefresh) {
          this.showLoader = false;
          return;
        }
        else {
          this.brokerMsgList = [];
          this.iPageNo_brokMsg = clsConstants.CDS_PAGE_NO;
          this.getNotification();
          //this.getBrokerMessages();
        }

      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'eventChanged', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'eventChanged',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getExchange() {
    try {
      let exchangeArry = clsGlobal.User.exchangesList;
      exchangeArry.forEach(element => {
        let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element);
        if(mktSegId != undefined && mktSegId != '' && mktSegId != null){
          this.exchangeAllowedArry.push({ MarketSegmentId: mktSegId, ExchangeDesc: clsTradingMethods.getExchangeNameDesc(parseInt(mktSegId)) });
        }
        });
      this.selectedExch = this.exchangeAllowedArry[0];
      // this.getExchangeMessages();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'getExchange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getExchange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
    * @method Get exchange images path as per segment id
    * @param marketSegmentId : Market Segment Id
    */
  setExchangeImages(marketSegmentId: any) {
    try {
      let imageUrl = '../../assets/img/light/extra-img/';
      let imagePath = "";
      if (marketSegmentId == '1' || marketSegmentId == '2' || marketSegmentId == '13') {
        imagePath = imageUrl + 'NSE-logo.png';
      } else if (marketSegmentId == '3' || marketSegmentId == '38') {
        imagePath = imageUrl + 'BSE-logo.png';
      } else if (marketSegmentId == '5') {
        imagePath = imageUrl + 'MSE-logo.png';
      } else if (marketSegmentId == '7') {
        imagePath = imageUrl + 'NCDEX-logo.png';
      } else if (marketSegmentId == '34') {
        imagePath = imageUrl + 'ICEX-logo.png';
      }
      return imagePath;
    } catch (error) { 
      console.log("Error setExchangeImages " + error);
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'setExchangeImages', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'setExchangeImages',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setValue(item: any) {
    this.selectedExch = item;
    this.showExchange = false;
    this.exchMsgList = [];
    this.iPageNo_exchMsg = 1;
    this.showLoader = true;
    this.getExchangeMessages(this.selectedExch);
  }

 
  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Get Exchange messages.
*/
  getExchangeMessages(selectedExch) {
    try {
      if (this.selectedExch == undefined || this.selectedExch.length < 0) {
        this.noDataFound = true;
        this.showLoader = false;
        return;
      }

      this.noDataFound = false;

      if (this.infiniteScroll == undefined && this.disableloaderonrefresh == false)
        this.showLoader = true;

      let options = {
        userId: clsGlobal.User.userId,
        groupId: clsGlobal.User.groupId,
        userCode: clsGlobal.User.userCode,
        segmentId: selectedExch.MarketSegmentId,
        noofhrs: this.noofhrs,
        pageNo: this.iPageNo_exchMsg,
        pageSize: 10
      };

      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + '/' + "getExchangeMessages", options).subscribe((respData: any) => {
        if (respData.status) {
          if (this.infiniteScroll != undefined)
            this.infiniteScroll.target.complete();

          if (respData.result.length == 0) {
            if (this.iPageNo_exchMsg == 1) {
              this.noDataFound = true;
            }
            this.loadMoreData = false;
            this.showLoader = false;
            return;
          }

          if (respData.result.length > 0) {
            for (let i = 0; i < respData.result.length; i++) {
              this.exchMsgList.push({
                SegmentId: respData.result[i].SegmentId,
                Messages: respData.result[i].Messages,
                Time: this.getExchangeDateFormat(respData.result[i].Time),
                ImagePath: this.setExchangeImages(this.selectedExch.MarketSegmentId)
              });
            }
          }
          this.loadMoreData = true;
          this.showLoader = false;
        }
        else {
          this.noDataFound = true;

        }
      }, error => {
        this.showLoader = false;
        this.disableloaderonrefresh = false;
        this.loadMoreData = false;

       // console.log("Error getExchangeMessages_1 " + error);
        //clsGlobal.logManager.writeErrorLog('MessagesPage', 'getExchangeMessages_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getExchangeMessages',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.showLoader = false;
      this.disableloaderonrefresh = false;
      this.loadMoreData = false;
      this.exchMsgList = [];
      if (this.infiniteScroll != undefined)
        this.infiniteScroll.target.complete();

      // console.log("Error getExchangeMessages_2 " + error);
      // clsGlobal.logManager.writeErrorLog('MessagesPage', 'getExchangeMessages_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getExchangeMessages2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Get Order messages.
*/
  getOrderMessages() {
    try {
      if (this.infiniteScroll == undefined && this.disableloaderonrefresh == false)
        this.showLoader = true;

      let options = {
        userId: clsGlobal.User.userId,
        groupId: clsGlobal.User.groupId,
        userCode: '-',
        pageNo: this.iPageNo,
        pageSize: 10
      };
      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + '/' + "getOrderMessages", options).subscribe((respData: any) => {
        if (respData.status) {
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
          if (this.infiniteScroll != undefined)
            this.infiniteScroll.target.complete();

          if (respData.result.length == 0) {
            if (this.iPageNo == 1) {
              this.noDataFound = true;
            }
            this.loadMoreData = false;
            this.disableloaderonrefresh = false;
            this.showLoader = false;
            return;
          }
          if (respData.result.length > 0) {
            for (let i = 0; i < respData.result.length; i++) {
              let time = this.getTimeFormat(respData.result[i].time);
              let date = respData.result[i].date.split('/')[0] + " " + respData.result[i].date.split('/')[1] + "' " + respData.result[i].date.split('/')[2]
              let formatted_date_time = date + ' ' + time;
              this.orderMsgList.push({
                Time: formatted_date_time,
                cliOrdNo: respData.result[i].cliOrdNo,
                Messages: respData.result[i].msg,
                mktSegId: respData.result[i].mktSegId
              });
            }
          }
          this.disableloaderonrefresh = false;
          this.showLoader = false;
          this.loadMoreData = true;
        }
        else {
          this.noDataFound = true;
          this.showLoader = false;
          this.orderMsgList = [];
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
        }
      }, error => {
        this.showLoader = false;
        this.disableloaderonrefresh = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        //console.log("Error getOrderMessages_1 " + error);
        //clsGlobal.logManager.writeErrorLog('MessagesPage', 'getOrderMessages_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getOrderMessages',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.showLoader = false;
      this.disableloaderonrefresh = false;
      if (this.refresherInstance != undefined)
        this.refresherInstance.target.complete();
      if (this.infiniteScroll != undefined)
        this.infiniteScroll.target.complete();
      //console.log("Error getOrderMessages_2 " + error);
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'getOrderMessages_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getOrderMessages2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Get Brokers messages.
*/
  getBrokerMessages() {
    try {
      // if (this.infiniteScroll == undefined && this.disableloaderonrefresh == false)
      //   this.showLoader = true;

      let options = {
        userId: clsGlobal.User.userId,
        groupId: clsGlobal.User.groupId,
        userCode: clsGlobal.User.userId,
        pageNo: this.iPageNo_brokMsg,
        pageSize: 10
      };
      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + '/' + "getBrokerMessages", options).subscribe((respData: any) => {
        if (respData.status) {
          // if (this.refresherInstance != undefined) {
          //   this.refresherInstance.target.complete();
          // }
          // if (this.infiniteScroll != undefined)
          //   this.infiniteScroll.target.complete();

          if (respData.result.length == 0) {
            if (this.iPageNo_brokMsg == 1 && this.brokerMsgList.length == 0) {
              this.noDataFound = true;
            }
            this.loadMoreData = false;
            this.disableloaderonrefresh = false;
            this.showLoader = false;
            return;
          }

          if (respData.result.length > 0) {
            for (let i = 0; i < respData.result.length; i++) {
              let month = respData.result[i].SendMsgTime.split('-')[1];
              month = clsCommonMethods.getAlphaMonth(month - 1);
              let year = respData.result[i].SendMsgTime.substring(2, 4);
              let date = respData.result[i].SendMsgTime.substring(8, 10);
              let formatted_date = date + " " + month + "' " + year;
              let time = respData.result[i].SendMsgTime.split(' ')[1].substring(0, 5);
              let formatted_time = this.getTimeFormat(time);
              let formatted_date_time = formatted_date + " " + formatted_time;
              this.brokerMsgList.push({
                MsgSrNo: respData.result[i].MsgSrNo,
                Time: formatted_date_time,
                Subject: respData.result[i].Subject,
                Messages: respData.result[i].Message,
                MsgType: respData.result[i].MsgType
              });
            }
          }
          this.loadMoreData = true;
          this.disableloaderonrefresh = false;
          this.showLoader = false;

        }
        else {
          this.brokerMsgList = [];
          if(this.brokerMsgList.length == 0)
            this.noDataFound = true;
          this.showLoader = false;
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
        }

      }, error => {
        this.showLoader = false;
        if(this.brokerMsgList.length == 0)
            this.noDataFound = true;
        this.disableloaderonrefresh = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        //console.log("Error getBrokerMessages_1 " + error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getBrokerMessages1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.showLoader = false;
      if(this.brokerMsgList.length == 0)
        this.noDataFound = true;
      this.disableloaderonrefresh = false;
      if (this.refresherInstance != undefined)
        this.refresherInstance.target.complete();
      if (this.infiniteScroll != undefined)
        this.infiniteScroll.target.complete();
      // console.log("Error getBrokerMessages_2" + error);
      // clsGlobal.logManager.writeErrorLog('MessagesPage', 'getBrokerMessages', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getBrokerMessages2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
  * @author : Rajendra Sirvi
  * @date : 21/12/2020
  * @USD : BT-37759
  * @description : Convert time into PM and AM format .
  */
  getTimeFormat(time: any) {
    try{
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time + 'PM';
    } else {
      retTime = time + 'AM';
    }
    return retTime;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getTimeFormat',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getExchangeDateFormat(msgTime: any) {
    try{
    let retDateTime = '';
    let current_date = new Date();
    let day = current_date.getDate();
    let month = clsCommonMethods.getAlphaMonth(current_date.getMonth());
    let year = (current_date.getFullYear()).toString().substring(2, 4);
    let formatted_date = day + " " + month + "'" + " " + year;
    let time = msgTime.split(':')[0] + ':' + msgTime.split(':')[1]
    let formatted_time = this.getTimeFormat(time);
    retDateTime = formatted_date + ' ' + formatted_time;
    return retDateTime;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getExchangeDateFormat',error.Message,undefined,error.stack,undefined,undefined));
  }
}

  showExchangePopUp() {
    this.showExchange = !this.showExchange;
  }

  showAllNotifPopUp() {
    this.showNotifPopUp = !this.showNotifPopUp;
  }

  doRefresh(refresher) {
    try{
    this.refresherInstance = refresher;
    this.showLoader = false;
    this.disableloaderonrefresh = true;
    this.noDataFound = false;
    // if (this.statusmode == 'BROKERMESSAGE') {
    //   this.getBrokerMessages();
    // } else if (this.statusmode == 'ORDERMESSAGE') {
    //   this.getOrderMessages();
    // }
    this.eventChanged(this.statusmode, true);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doRefresh',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  doInfinite(event) {
    try{
    setTimeout(() => {
      event.target.complete();
      this.infiniteScroll = event;
      this.fetchDetails(true);
    }, 500);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  fetchDetails(fromScrolling: boolean = false) {
    try {
      if (this.statusmode == "ORDERMESSAGE") {
        if (this.orderMsgList.length <= 0 || fromScrolling) {
          this.iPageNo += 1;
          if (this.iPageNo >= 2) {
            this.iPageNo = this.iPageNo;
          }
          else {
            this.iPageNo = clsConstants.CDS_PAGE_NO;
          }
          this.getOrderMessages();
        }
      }
      else if (this.statusmode == "EXCHANGEMESSAGE") {
        if (this.exchMsgList.length <= 0 || fromScrolling) {
          this.iPageNo_exchMsg += 1;
          if (this.iPageNo_exchMsg >= 2) {
            this.iPageNo_exchMsg = this.iPageNo_exchMsg;
          }
          else {
            this.iPageNo_exchMsg = clsConstants.CDS_PAGE_NO;
          }
          this.getExchangeMessages(this.selectedExch);
        }
      }
      else if (this.statusmode == "BROKERMESSAGE") {
        if (this.brokerMsgList.length <= 0 || fromScrolling) {
          this.iPageNo_brokMsg += 1;
          if (this.iPageNo_brokMsg >= 2) {
            this.iPageNo_brokMsg = this.iPageNo_brokMsg;
          }
          else {
            this.iPageNo_brokMsg = clsConstants.CDS_PAGE_NO;
          }
          this.getBrokerMessages();
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MessagesPage', 'fetchDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'fetchDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  search($event) {
    if ($event) {
      this.searchText = $event.toUpperCase();
      this.searchTextChanged.next($event);
    } else {
      this.messageSearchData = [];
    }
  }


  getValues(search) {
    try {
      this.messageSearchData = [];
      if (search.length < 1) {
        this.searchTextEntered = '';
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      if (this.statusmode == 'BROKERMESSAGE') {
        this.messageSearchData = this.brokerMsgList
          .filter(x => (x.Messages.toUpperCase().includes(this.searchTextEntered)));
      } else if (this.statusmode == 'ORDERMESSAGE') {
        this.messageSearchData = this.orderMsgList
          .filter(x => (x.Messages.toUpperCase().includes(this.searchTextEntered)));
        console.log(this.messageSearchData)
      } else if (this.statusmode == 'EXCHANGEMESSAGE') {
        this.messageSearchData = this.exchMsgList
          .filter(x => (x.Messages.toUpperCase().includes(this.searchTextEntered)));
        console.log(this.messageSearchData)
      }
      //  else if (this.statusmode == 'NOTIFICATION') {
      //   this.messageSearchData = this.notifydataAllData
      //     .filter(x => (x.Message.toUpperCase().includes(this.searchTextEntered)));
      //   console.log(this.messageSearchData)
      // }

    } catch (error) {
      //console.log(error)
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearch() {
    this.searchText = '';
    this.messageSearchData = [];
    this.searchTextEntered = '';
  }

  showSearchPopup() {
    this.searchText = '';
    this.showSearch = true;
    this.messageSearchData = [];
  }

  hideSearchPopup() {
    this.showSearch = false;
    this.searchText = '';
    this.messageSearchData = [];
  }

  async getNotification() {
    try {
      if (this.infiniteScroll == undefined && this.disableloaderonrefresh == false)
        this.showLoader = true;
      let recoDetails: any = {};
      recoDetails.userId = clsGlobal.User.userId;
      recoDetails.groupId = clsGlobal.User.groupId;
      recoDetails.userType = 'R';
      recoDetails.deviceType = this.platform.is('android') ? 'android' : 'ios';
      recoDetails.siTemplate = clsGlobal.User.SITemplateId;
      recoDetails.recordCount = this.recoCnt;

     // await new Promise((resolve, reject)  => {
        this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getFCMNotification', recoDetails).subscribe(respData => {

          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
          if (this.infiniteScroll != undefined)
            this.infiniteScroll.target.complete();

          if (respData.status == true) {
            if (respData.result.length > 0) {

              let notificationData: any = respData.result;
              for (var i = 0; i < notificationData.length; i++) {
                this.brokerMsgList.push({
                MsgSrNo: "",//respData.result[i].MsgSrNo,
                Time: this.GetTimeFormate(notificationData[i].MessageSendDateTime),
                Subject: notificationData[i].MessageTitle,//respData.result[i].Subject,
                Messages: notificationData[i].sMessage,
                MsgType: "",//respData.result[i].MsgType
                });
              }
            }
          }
          this.getBrokerMessages();

        }, error => {
          //this.toastCtrl.showAtBottom("Unable to fetch data.");
          this.showLoader = false;
          this.brokerMsgList = [];
          this.noDataFound = true;
          if (this.refresherInstance != undefined)
          this.refresherInstance.complete();
          //clsGlobal.logManager.writeErrorLog('NotificationsPage', 'getNotification1', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getNotification1',error.Message,undefined,error.stack,undefined,undefined));
        });
      //});

    } catch (error) {
      this.showLoader = false;
      this.brokerMsgList = [];
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog('NotificationsPage', 'getNotification2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'getNotification2',error.Message,undefined,error.stack,undefined,undefined));
      if (this.refresherInstance != undefined)
      this.refresherInstance.complete();
    }
  }

  GetTimeFormate(a) {
    try{
    var s = a.replace(/[ :]/g, "-").split("-"),
    d = new Date(s[0], s[1] - 1, s[2], s[3], s[4], s[5]);
    return this.dateFormatter.transform(
      d,
      "h:mm a"
    );
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'GetTimeFormate',error.Message,undefined,error.stack,undefined,undefined));
    }

}
}
