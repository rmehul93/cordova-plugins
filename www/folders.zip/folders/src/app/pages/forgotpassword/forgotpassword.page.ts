import { AuthenticationService } from 'src/app/providers/authentication.service';
import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";
import { Router } from '@angular/router';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsGlobal } from '../../Common/clsGlobal';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { AlertServicesProvider } from '../../providers/alert-services/alert-services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { Platform } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { NavParamService } from 'src/app/providers/nav-param.service';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.page.html',
  //providers: [DatePipe]
})
export class ForgotpasswordPage implements OnInit {
  mobile: string = '';
  disableGenerate: boolean = true;
  showOtp: boolean = false;
  timerId: any;
  enableGenerate: boolean = false;
  generateOtpText = 'Generate OTP';
  userID: any;
  otp: any;
  maxInvalidOTPAttempt: number = 3;
  invalidOTPCnt: number = 0;
  disableSubmit: boolean = false;
  mobileDisaply: any = '*******';
  isFirstTime: boolean = false;
  emailId: string = '';
  timerStarted: boolean = false;
  timerValue: number = 0;
  isAndroid: boolean = false;
  ShowOTPConfirm: boolean = false;
  enterManualOTP: boolean = false;
  otpVerified: boolean = false;
  enableSubmit: boolean = false;
  enableVerifyOtp: boolean = false;
  otpErr: any = '';
  isFingerPrintSelected: boolean = false;
  mobile_udid: any = '';
  page: string = "";
  mobilenumber: any;
  constructor(private navCtrl: NavController,
    public http: clsHttpService,
    private toastCtrl: ToastServicesProvider,
    public alertservice: AlertServicesProvider,
    private loaderCtrl: LoaderServicesProvider,
    public objStorage: clsLocalStorageService,
    public platform: Platform,
    public router: Router,
    private paramService: NavParamService,
    private authService: AuthenticationService) { }

  ngOnInit() {
    try {
      this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length > 0) {
        this.maxInvalidOTPAttempt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT));
      }
      this.isAndroid = this.platform.is('android');
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'ngOnInit', e);
    }
  }

  ionViewWillEnter() {
    try {
      this.page = this.paramService.myParam;
      if(this.page == 'forgotIncorrectPass')
      {
        this.ShowOTPConfirm = false;
        this.enterManualOTP = false;
        this.otpVerified = false;
      }
      else if(this.page == 'forgotOTPPass')
      {
        this.ShowOTPConfirm = true;
        this.enterManualOTP = true;
      }
      this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
      .then((item: any) => {
        if (item != undefined) {
          let objMPIN: any = JSON.parse(item);
          if(objMPIN.userId.toUpperCase().trim() == clsGlobal.User.userId.toUpperCase().trim())
          {
            this.userID = objMPIN.userId.toUpperCase().trim();
            this.isFingerPrintSelected = objMPIN.Fingerprint == 'Y' ? true : false;
          }
          else
          {
            this.userID = clsGlobal.User.userId.toUpperCase().trim();
          }
        }
        else {
          this.userID = clsGlobal.User.userId.toUpperCase().trim();
        }
        this.getUserDetails();
      }, error => {
        this.loaderCtrl.hideLoader();
        clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'ionViewWillEnter', error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  getUserDetails() {
    try {
      if(clsGlobal.User.userId!="" &&  clsGlobal.User.mobile!="" &&  clsGlobal.User.mobile!=undefined)
      {
        this.mobile = clsGlobal.User.mobile;
        this.mobilenumber = this.mobile.substr(0,2)+this.mobileDisaply+ this.mobile.substr(8, 2);
        this.emailId = clsGlobal.User.email;
        this.enableSubmit = true; 
      }
      else{
        this.authService.getUserInfo(this.userID.toUpperCase()).then((resp: any) => {
          console.log(resp);
          if (resp.status == true) {
            let userDetails = resp['result'];
            this.mobile = clsCommonMethods.TripleDESDecrypt(userDetails.mobile);
            this.mobilenumber = this.mobile.substr(0,2)+this.mobileDisaply+ this.mobile.substr(8, 2);
            this.emailId = clsCommonMethods.TripleDESDecrypt(userDetails.email);
            this.enableSubmit = true;
          }
          else
          {
            this.toastCtrl.showWithButton(resp.errorString);
          }
        }).catch(error => {
          this.toastCtrl.showAtBottom(error);
          this.loaderCtrl.hideLoader();
          clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'getUserDetails_1', error);
        })
       }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'getUserDetails_2', error);
    }
  }

  RegenerateOTP() {
    this.ShowOTPConfirm = !this.ShowOTPConfirm;
    this.sendOTP();
  }

  sendOTP()//Reset MPIN Request send for OTP generation.
  {
    try {
      this.ShowOTPConfirm = !this.ShowOTPConfirm;
      if (this.isAndroid) {
        this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
        this.startTimer();
      }
      let reqOTPGenerate = {
        user_id: this.userID.toUpperCase(),
        api_key: clsGlobal.apiKey,
        source: "WEBAPI"
      };
      this.authService.resetPasswordOtpGenerate(reqOTPGenerate).then((resp: any) => {
        if (resp.status == "success") {
          this.enableGenerate = false;
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'sendOTP', error);
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'sendOTP', error);
    }
  }

  EnterManualOTP() {
    this.enterManualOTP = !this.enterManualOTP;
    this.otp = '';
  }

  startTimer() {
    try {
      this.timerStarted = true;
      this.timerId = setTimeout(function () {
        if (this.timerValue == 0) {
          // this.generateOtpText = 'Regenerate OTP';
          this.enableGenerate = true;
          this.otp = '';
          // this.showOtp = false;
          // this.disableSubmit = true;
          // this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));
          this.timerStarted = false;
        }
        else {
          this.timerValue--;
          this.startTimer();
        }
      }.bind(this), 1000);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'startTimer', error);
    }
  }

  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.otpErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotPasswordPage', 'onKeyUp', error);
    }
  }

  checkOTPEnter(event) {
    try {
      this.enableVerifyOtp = event.target.value.trim().length == 6 ? true : false;
      this.otpErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("ForgotPasswordPage", "checkOTPEnter", error.message);
    }
  }
  
  verifyOTPRestAPI() // send Reset password request for OTP verification and new password creation.
  {
    this.enterManualOTP = !this.enterManualOTP;
    this.ShowOTPConfirm = !this.ShowOTPConfirm;
    try {
      let reqSetPasswordObj = {
        user_id: this.userID.toUpperCase(),
        otp: this.otp,
        api_key: clsGlobal.apiKey,
        source: "WEBAPI"
      }
      this.authService.forgotPasswordChange(reqSetPasswordObj).then((resp: any) => {
        if (resp.status == "success") {
          if (resp.code == "s-101") {
            this.otpVerified = !this.otpVerified;
            setTimeout(() => {
              let pageSource = "forgotPass";
              this.paramService.myParam = pageSource;
              this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_CHANGEPASSWORD);
            }, 2000);
          }
        }
      }).catch(error => {
        console.log(error)        
        if (error == "Incorrect OTP." || error=="OTP should be numeric only.") {
          this.otp = '';
          this.otpErr = error;
          this.ShowOTPConfirm = true;
          this.enterManualOTP = true;
        }
        else{
          this.toastCtrl.showAtBottom(error);
        }
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangePasswordPage', 'verifyOTPRestAPI', error);
    }
  }

  gotoChangePassword(){
    let pageSource = "forgotPass";
    this.paramService.myParam = pageSource;
    this.paramService.otp = this.otp;
    this.paramService.mobile = this.mobile;
    this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_CHANGEPASSWORD);
  }

  goBack() {
    this.navCtrl.pop();
  }
}
