import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultilegLookupPageRoutingModule } from './multileg-lookup-routing.module';

import { MultilegLookupPage } from './multileg-lookup.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultilegLookupPageRoutingModule
  ],
  declarations: [MultilegLookupPage]
})
export class MultilegLookupPageModule {}
