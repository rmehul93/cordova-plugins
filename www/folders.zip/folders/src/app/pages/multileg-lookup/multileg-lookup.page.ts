import { Component, OnInit, ViewChild } from '@angular/core';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { GlobalEventsService } from 'src/app/providers/global-events.service';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { IonContent, NavController, NavParams, ModalController, IonInput } from '@ionic/angular';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { Subject } from 'rxjs/Subject';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-multileg-lookup',
  templateUrl: './multileg-lookup.page.html'
})
export class MultilegLookupPage implements OnInit {
  @ViewChild(IonContent, { static: false }) content: IonContent;
  @ViewChild('inputId',{static : false}) inputId : IonInput;
  legsDetails : any;
  scripdetails : any = 'FUT';
  equNSEDetails : any;
  equBSEDetails : any;
  equDetails : any;
  selectedExchange: any;
  sEquSymbol : any;
  sEquExchange : any;
  eventList : any = [];
  hots : any = [];
  equLTP: any = "0.00";
  equNetChangeInRs: any = "0.00";
  equPercNetChange: any = "0.00";
  equColorTrend = "";
  bcastHandler: any;
  localScripKey : any = [];
  holdingData : any = [];
  holding : any = [];
  PNLTrend : any;
  PNL : any;
  PNLPer : any;
  showExchange : boolean = false;
  exchangelist : any = [];
  //FUT
  futData : any = [];
  futNSEData : any = [];
  futBSEData : any = [];
  futOptScripKey : any = [];
  noFutDataFound : boolean = false;
  futTotalData : any = [];
  //OPT
  showOptLoadersearch : boolean = false;
  noOptDataFound : any = "";
  selectedOptionContractData = [];
  distinctOptExpiryDate = [];
  selectedIdxOptnChain: number = 0;
  selectedOptionContract = [];
  showFutLoadersearch : boolean = false;
  optNSEData : any = [];
  optBSEData : any = [];
  optTotalData : any = [];
  //MCX
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = '';
  noDataFound : boolean = false;
  showHide : boolean = true;
  futureOption : boolean = false;
  lookupData: any = [];
  showLoadersearch : boolean = false;

  constructor(public http: clsHttpService,
    private paramService: NavParamService,
    public navParam: NavParams,
    private glbEvtService: GlobalEventsService,
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    private toastCtrl: ToastServicesProvider,) {
      let details = this.navParam.get("scrip");
      this.legsDetails = details.legdetails;
      this.sEquSymbol = details.symbol;
      this.selectedExchange = details.exchange;
     }

  async ngOnInit() {
    try{
    this.bcastHandler = this.receiveTouchlineResponse.bind(this); 
    //this.legsDetails = this.paramService.multileg;
    if(this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT || this.selectedExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT)
    {
      await this.getEquLookupDetails();
    }
    else
    {
      this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValues(search)); 
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  setFocusOnInput(){
    this.inputId.setFocus();
  }

  async ionViewWillEnter(){
    try{
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    if(this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT || this.selectedExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT)
    {
      this.holdingData = clsGlobal.User.Holding; 
      this.glbEvtService.fetchEvents().then(data => {
  
        try {
          this.eventList = clsGlobal.EventList;
  
        } catch (error) {
          clsGlobal.logManager.writeErrorLog('WatchlistPage', 'fetchEventList Response', error);
        }
      }, error => {
        console.log("Error in Fetch Event: " + error);
      })
      await this.getFutLookupDetails();
    }
    else
    {
      this.setFocusOnInput();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Scrip for Equities> **/
  async getEquLookupDetails(){
    try{
    await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId+"/getScripFromInstrumentAndExchange/" + 'EQU' + "/" + null + "/" + this.sEquSymbol).subscribe(response => {
      try {
        //TODO
        let _response: any = response;
        if (_response.status) {
          if (_response.result.hits != undefined && _response.result.hits.hits.length != 0) {
            for(let count = 0; count < _response.result.hits.hits.length; count++)
            {
              if(_response.result.hits.hits[count]._source.sExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT && _response.result.hits.hits[count]._source.sSymbol == this.sEquSymbol){
                this.equNSEDetails = (_response.result.hits.hits[count]._source);
              }
              else if(_response.result.hits.hits[count]._source.sExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT && _response.result.hits.hits[count]._source.sSymbol == this.sEquSymbol){
                this.equBSEDetails = (_response.result.hits.hits[count]._source);
              }
              this.exchangelist.push(_response.result.hits.hits[count]._source.sExchange);
            }
            this.equDetails = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.equNSEDetails : this.equBSEDetails;
            //this.sEquSymbol =  this.equDetails.sSymbol;
            this.sEquExchange = this.equDetails.sExchange;
            this.applyEvent();
            this.applyHolding();
            let objScrpKey = new clsScripKey();
            objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.equDetails.nMarketSegmentId);            
            objScrpKey.token = this.equDetails.nToken;
            this.localScripKey.push(objScrpKey);
            this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
          }
          else {

          }
        }
        else {
          //no option data found.
        }
        //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
      } catch (error) {
        console.log(error);
      }
    }, error => {
      console.log(error.error.message);
      //this.toastProvider.showAtBottom(error.error.message);
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'getEquLookupDetails',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Scrip for Futures> **/
  async getFutLookupDetails(){
    this.showFutLoadersearch = true;
    await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId+"/getScripFromInstrumentAndExchange/" + 'FUT' + "/" + null + "/" + this.sEquSymbol).subscribe(response => {
      try {
        //TODO
        this.showFutLoadersearch = false;
        let _response: any = response;
        if (_response.status) {
          if (_response.result.hits != undefined && _response.result.hits.hits.length != 0) {
            this.noFutDataFound = false;
            this.futOptScripKey = [];
            for(let count = 0; count <  _response.result.hits.hits.length; count++)
            {
              if(_response.result.hits.hits[count]._source.nSpread != 1)
              {
                this.futTotalData.push(_response.result.hits.hits[count]);
              }
            }
            for(let count = 0; count < this.futTotalData.length; count++){
              if(this.futTotalData[count]._source.sExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT){
                this.futNSEData.push(this.futTotalData[count]);
              }
              else if(this.futTotalData[count]._source.sExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT){
                this.futBSEData.push(this.futTotalData[count]);
              }
            }
            this.futData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.futNSEData : this.futBSEData;
            for(let count = 0; count < this.futData.length; count++){
              this.futData[count]._source.LTP = "0.00";
              this.futData[count]._source.PercNetChange = "0.00";
              this.futData[count]._source.NetChangeInRs = "0.00";
              this.futData[count]._source.colorTrend = '';
              this.futData[count]._source.PremiumDiscount = "0.00";
              let objScrpKey: clsScripKey = new clsScripKey();
              objScrpKey.token = this.futData[count]._source.nToken;
              objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.futData[count]._source.nMarketSegmentId);
              this.futOptScripKey.push(objScrpKey);
            }
            this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);
          }
          else {
            this.noFutDataFound = true;
            this.showFutLoadersearch = false;
          }
        }
        else {
          this.noFutDataFound = true;
          this.showFutLoadersearch = false;
        }
        //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
      } catch (error) {
        this.noFutDataFound = true;
        this.showFutLoadersearch = false;
        console.log(error);
      }
    }, error => {
      this.noFutDataFound = true;
      this.showFutLoadersearch = false;
      console.log(error.error.message);
      //this.toastProvider.showAtBottom(error.error.message);
    });
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Scrip for Options> **/
  async getOptLookupDetails() {  
    try{
    this.showOptLoadersearch = true;
    await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId+"/getScripFromInstrumentAndExchange/" + 'OPT' + "/" + null + "/" + this.sEquSymbol)
    .subscribe(data => {
      try {
        let _response: any = data;
        if (_response.status && _response.result.hits != undefined && _response.result.hits.total.value > 0) {
          this.noOptDataFound = "false";
          for(let count = 0; count <  _response.result.hits.hits.length; count++)
          {
            if(_response.result.hits.hits[count]._source.nSpread != 1)
            {
              this.optTotalData.push(_response.result.hits.hits[count]);
            }
          }
          for(let count = 0; count < this.optTotalData.length; count++){
            if(this.optTotalData[count]._source.sExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT){
              this.optNSEData.push(this.optTotalData[count]);
            }
            else if(this.optTotalData[count]._source.sExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT){
              this.optBSEData.push(this.optTotalData[count]);
            }
          }
          this.selectedOptionContractData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.optNSEData : this.optBSEData;
          if(this.selectedOptionContractData.length == 0)
          {
            this.showOptLoadersearch = false;
            this.noOptDataFound = "true";
          }
          this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
          this.ShowOptionChain(this.distinctOptExpiryDate[0], 0);
        }
        else
        {
          this.noOptDataFound = "true";
          this.showOptLoadersearch = false;
        }            
      } catch (error) {
        this.noOptDataFound = "true";
        this.showOptLoadersearch = false;
        console.log(error);
      }
    }, error => {
      this.noOptDataFound = "true";
      this.showOptLoadersearch = false;
      console.log("unable to find scrip: ", 'OPT', this.equDetails.nToken);
      clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'getOptLookupDetails', error);
    });  
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'getOptLookupDetails',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /** <Norwin Dcruz> <27/04/2021> <Apply for Whats Hot event> **/
  applyEvent() {
    try {
      this.eventList.forEach(eventItem => {
          if (clsTradingMethods.GetMarketSegmentID(this.equDetails.nMarketSegmentId) == (parseInt(eventItem.mktid)) && this.equDetails.nToken == parseInt(eventItem.token)) {
            if (!this.hots.includes(eventItem.event))
              this.hots.push(eventItem);
          }
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'applyEventToIndices', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'applyEventToIndices',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Holding data> **/
  applyHolding() {
    try {
      this.holdingData.forEach(item => {
          if (clsTradingMethods.GetMarketSegmentID(this.equDetails.nMarketSegmentId) == (parseInt(item.mktid)) && this.equDetails.nToken == parseInt(item.token)) {
              this.holding = (item.TOTALFREEQUANTITY);
              this.PNLTrend = item.PNLTrend;
              this.PNL = item.PNL;
              this.PNLPer = item.PNLPer;
          }
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'applyHolding', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'applyHolding',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Broadcast> **/
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        if(this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT  || this.selectedExchange == clsConstants.C_S_BSE_EXCHANGE_TEXT)
        {
          if (this.equDetails != undefined && this.equDetails.nToken == objMultiTLResp.Scrip.token &&
            clsTradingMethods.GetMarketSegmentID(this.equDetails.nMarketSegmentId) == objMultiTLResp.Scrip.MktSegId) {
            this.equLTP = objMultiTLResp.LTP;
  
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.equNetChangeInRs = arrNetChange[0];
            this.equPercNetChange = arrNetChange[1];
            this.equColorTrend = arrNetChange[2];
          }
  
          for (let count = 0; count < this.futData.length; count++) {
            if (this.futData.length > 0 && this.futData[count]._source.nToken == objMultiTLResp.Scrip.token &&
              clsTradingMethods.GetMarketSegmentID(this.futData[count]._source.nMarketSegmentId) == objMultiTLResp.Scrip.MktSegId) {
              this.futData[count]._source.LTP = objMultiTLResp.LTP;
  
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
              this.futData[count]._source.NetChangeInRs = arrNetChange[0];
              this.futData[count]._source.PercNetChange = arrNetChange[1];
              this.futData[count]._source.colorTrend = arrNetChange[2];
              this.futData[count]._source.percentage = arrNetChange[3];
              this.futData[count]._source.PremiumDiscount =  (parseFloat(this.equLTP) - parseFloat(this.futData[count]._source.LTP)).toFixed(2) ;
            }
          }
  
          if (this.scripdetails == "OPT") {
            if (this.selectedOptionContract.length > 0) {
              for (let i = 0; i < this.selectedOptionContract.length; i++) {
    
                if (this.selectedOptionContract[i].ceData.Money == "call-add-money") {
                  this.selectedOptionContract[i].ceData._source.nStrikePrice1 = this.equLTP;
                }
                if (this.selectedOptionContract[i].peData.Money == "put-add-money") {
                  this.selectedOptionContract[i].peData._source.nStrikePrice1 = this.equLTP;
                }
    
    
                if (parseFloat(this.equLTP) > parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1)) {
                  if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                    this.selectedOptionContract[i].ceData.Money = "call-background";
                  }
    
                }
                else {
                  if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                    this.selectedOptionContract[i].ceData.Money = "put-background";
                  }
    
                }
    
                if (parseFloat(this.equLTP) < parseFloat(this.selectedOptionContract[i].peData._source.nStrikePrice1)) {
                  if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                    this.selectedOptionContract[i].peData.Money = "call-background";
                  }
    
                }
                else {
                  if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                    this.selectedOptionContract[i].peData.Money = "put-background";
                  }
    
                }
    
                if (this.selectedOptionContract != undefined &&
                  clsTradingMethods.GetMarketSegmentID(this.selectedOptionContract[i].ceData._source.nMarketSegmentId) == objMultiTLResp.Scrip.MktSegId &&
                  this.selectedOptionContract[i].ceData._source.nToken == objMultiTLResp.Scrip.token) {
                  this.selectedOptionContract[i].ceData.LTP = objMultiTLResp.LTP;
                  let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, 2, false, 'arrow');
                  this.selectedOptionContract[i].ceData.NetChangeInRs = arrNetChange[0];
                  this.selectedOptionContract[i].ceData.PercNetChange = arrNetChange[1];
                  this.selectedOptionContract[i].ceData.LTPTrend = arrNetChange[2];
                  this.selectedOptionContract[i].ceData.arrowTrend = arrNetChange[3];
                  this.selectedOptionContract[i].ceData.OI =  objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;
                  this.selectedOptionContract[i].ceData.PercOI = objMultiTLResp.PercOpenInt == "" ? "(0.00)" : objMultiTLResp.PercOpenInt;
                  if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) > 0) {
                    this.selectedOptionContract[i].ceData.colorOITrend = "color-positive";
                  }
                  else if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) < 0) {
                    this.selectedOptionContract[i].ceData.colorOITrend = "color-negative";
                  }
                  else {
                    this.selectedOptionContract[i].ceData.colorOITrend = "";
                  }
                  let ImpVoltality:any = clsCommonMethods.ImpliedVolatility(parseFloat(this.equLTP),
                  parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1),4,
                  this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1),objMultiTLResp.LTP,"CALL");
                  this.selectedOptionContract[i].ceData.IV = parseFloat(ImpVoltality).toFixed(4);
                  break;
                }
                else if (this.selectedOptionContract != undefined &&
                  clsTradingMethods.GetMarketSegmentID(this.selectedOptionContract[i].peData._source.nMarketSegmentId) == objMultiTLResp.Scrip.MktSegId &&
                  this.selectedOptionContract[i].peData._source.nToken == objMultiTLResp.Scrip.token) {
                  this.selectedOptionContract[i].peData.LTP = objMultiTLResp.LTP;
                  let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, 2, false, 'arrow');
                  this.selectedOptionContract[i].peData.NetChangeInRs = arrNetChange[0];
                  this.selectedOptionContract[i].peData.PercNetChange = arrNetChange[1];
                  this.selectedOptionContract[i].peData.LTPTrend = arrNetChange[2];
                  this.selectedOptionContract[i].peData.arrowTrend = arrNetChange[3];
                  this.selectedOptionContract[i].peData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;
                  this.selectedOptionContract[i].peData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;
                  if (parseFloat(this.selectedOptionContract[i].peData.PercOI) > 0) {
                    this.selectedOptionContract[i].peData.colorOITrend = "color-positive";
                  }
                  else if (parseFloat(this.selectedOptionContract[i].peData.PercOI) < 0) {
                    this.selectedOptionContract[i].peData.colorOITrend = "color-negative";
                  }
                  else {
                    this.selectedOptionContract[i].peData.colorOITrend = "";
                  }
                  let ImpVoltality:any = clsCommonMethods.ImpliedVolatility(parseFloat(this.equLTP),
                  parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1),4,
                  this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1),objMultiTLResp.LTP,"PUT");
                  this.selectedOptionContract[i].peData.IV = parseFloat(ImpVoltality).toFixed(4);;
                  //console.log(ImpVoltality)
                  break;
                }
              }
            }
            this.selectedOptionContract.sort((a, b) => (parseFloat(a.ceData._source.nStrikePrice1) < parseFloat(b.ceData._source.nStrikePrice1)) ? -1 : 1)
          }
        }

        if(this.selectedExchange != clsConstants.C_S_NSE_EXCHANGE_TEXT  && this.selectedExchange != clsConstants.C_S_BSE_EXCHANGE_TEXT){
          for (let i = 0; i < this.lookupData.length; i++) {
            if (this.lookupData != undefined &&
              clsTradingMethods.GetMarketSegmentID(this.lookupData[i]._source.nMarketSegmentId) == objMultiTLResp.Scrip.MktSegId &&
              this.lookupData[i]._source.nToken == objMultiTLResp.Scrip.token) {
              this.lookupData[i]._source.LTP = objMultiTLResp.LTP;
              break;
            }
          }
        }
      }
    }
    catch (error) {
      //console.log('MultilegLookupPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get distinct expiry for options> **/
  getDistinctExpiryDate(array) {
    try {
      let distinct = [...new Set(array.map(item => item._source.nExpiryDate1))];
      return distinct;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'getDistinctExpiryDate1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'getDistinctExpiryDate1',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To get Options Data and filter it> **/
  ShowOptionChain(expiryDate, idx) {
    try {
      this.showOptLoadersearch = true;
      this.selectedIdxOptnChain = idx;
      this.selectedOptionContract = [];
      let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      optData.push({ _source: { nStrikePrice1: this.equLTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" })
      optData.push({ _source: { nStrikePrice1: this.equLTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" })
      optData.sort((a, b) => (parseFloat(a._source.nStrikePrice1) > parseFloat(b._source.nStrikePrice1)) ? -1 : 1)
      let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      for (let i = 0; i < optCEData.length; i++) {
        let obj;
        optCEData[i].LTP = "0.00";
        optCEData[i].NetChangeInRs = "0.00";
        optCEData[i].PercNetChange = "(0.00)";
        optCEData[i].OI = "0.00";
        optCEData[i].PercOI = "(0.00)";
        optCEData[i].IV = "0";

        optPEData[i].LTP = "0.00";
        optPEData[i].NetChangeInRs = "0.00";
        optPEData[i].PercNetChange = "(0.00)";
        optPEData[i].OI = "0.00";
        optPEData[i].PercOI = "(0.00)";
        optPEData[i].IV = "0";

        let ceData = optCEData[i]
        let peData = optPEData[i]
        obj = { "ceData": ceData, "peData": peData }
        this.selectedOptionContract.push(obj)
      }
      this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
      this.showOptLoadersearch = false;
      this.scrollToLabel();

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'ShowOptionChain1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'ShowOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <Scroll to ATM> **/
  scrollToLabel() {
    try {
      let titleELe = document.getElementById("call-put-add-money");
      if (titleELe == null) {
        setTimeout(() => {
        this.scrollToLabel();
      }, 300);
      }
      else {
        setTimeout(() => {
        let titleELe = document.getElementById("call-put-add-money");
        this.content.scrollToPoint(0, titleELe.offsetTop, 1000);
      }, 200);
      }

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'scrollToLabel',error.Message,undefined,error.stack,undefined,undefined));
    }
  } 

  /** <Norwin Dcruz> <27/04/2021> <Send broadcast to options> **/
  sendBroadcastReqForOptionChain(selectedData) {
    try {
      this.futOptScripKey = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
      for (let i = 0; i < selectedData.length; i++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = selectedData[i].ceData._source.nToken;
        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(selectedData[i].ceData._source.nMarketSegmentId);
        this.futOptScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[i].peData._source.nToken;
        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(selectedData[i].peData._source.nMarketSegmentId);
        this.futOptScripKey.push(objScrpKey);
      }
      this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'sendBroadcastReqForOptionChain', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'sendBroadcastReqForOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <Tab selection for futute and option tab> **/
  tabSelection(event) {
    try{
    this.content.scrollToPoint(0,0,0);  
    this.scripdetails = event.detail.value.toUpperCase();
    this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
    this.futOptScripKey = [];
    this.noOptDataFound = "";
    this.noFutDataFound = false;
    this.showFutLoadersearch = false;
    this.showOptLoadersearch = false;

    if (this.scripdetails == 'FUT') {
      if (this.futTotalData.length == 0) {
        this.getFutLookupDetails();
      }
      else {
        this.futData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.futNSEData : this.futBSEData;
        if(this.futData.length == 0)
        {
          this.noFutDataFound = true;
          return;
        }
        for (let count = 0; count < this.futData.length; count++) {
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = this.futData[count]._source.nToken;
          objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.futData[count]._source.nMarketSegmentId);
          this.futOptScripKey.push(objScrpKey);
        }
        this.noFutDataFound = false;
        this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);
      }
    }
    else if (this.scripdetails == 'OPT') {
      if (this.selectedOptionContract.length == 0) {
        this.getOptLookupDetails();
        this.scrollToLabel();

      }
      else {
        this.selectedOptionContractData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.optNSEData : this.optBSEData;
        if(this.selectedOptionContractData.length == 0)
        {
          this.noOptDataFound = "true";
          return;
        }
        this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
        this.ShowOptionChain(this.distinctOptExpiryDate[0], 0);
        this.noOptDataFound = "false";
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'tabSelection',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  ionViewWillLeave() {
    try{
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  dateDiffernece(inputdate)
  {
    try {
      let nextdate : any = new Date(inputdate);
      let curruntData:any =  new Date()
      let diffTime = Math.abs(nextdate - curruntData);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24 ));
      return diffDays;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'dateDiffernece',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To add scrip to order entry> **/
  addScrip(item){
    try{
    for(let count = 0; count < this.legsDetails.length; count++)
    {
      if(this.legsDetails[count].legmktsegid == clsTradingMethods.GetMarketSegmentID(item._source.nMarketSegmentId) && this.legsDetails[count].legToken == item._source.nToken)
      {
        this.toastCtrl.showAtBottom("Scrip already selected, Kindly select another Scrip");
        return;
      }
    }
    this.modalCtrl.dismiss(item);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'addScrip',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  search($event) {
    try{
    if ($event) {
      this.searchText =  $event.toUpperCase().trim();
      //this.searchText.toUpperCase().trim();
      this.searchTextChanged.next(this.searchText);
    } else {
      this.noDataFound = false;
      this.futureOption = false;
      this.showHide = true;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'search',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  goBack(){
    this.modalCtrl.dismiss();
  }

  /** <Norwin Dcruz> <27/04/2021> <To get search values> **/
  async getValues(search) {
    try {
      if (search.length < 2) {
        this.searchTextEntered = '';
        this.lookupData = [];
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      this.lookupData = [];
      this.noDataFound = false;
      this.showLoadersearch = true;
      let _viewAllowed=clsGlobal.User.loginAllowed || -1;
      await this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getScripLookUp/", this.searchTextEntered + '%20' + this.selectedExchange + '%20' + this.scripdetails + "/"+_viewAllowed)
        .subscribe(data => {
          try {
            this.futureOption = true;
            this.showLoadersearch = false;
            let _response: any = data
            if (_response.status && _response.result.hits != undefined && _response.result.hits.total.value > 0) {
              this.localScripKey = [];
              for(let count = 0; count <  _response.result.hits.hits.length; count++)
              {
                if(_response.result.hits.hits[count]._source.nSpread != 1)
                {
                  this.lookupData.push(_response.result.hits.hits[count]);
                }
              }
              for (let i = 0; i < this.lookupData.length; i++) {
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = this.lookupData[i]._source.nToken;
                objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.lookupData[i]._source.nMarketSegmentId);
                this.localScripKey.push(objScrpKey);
              }
              this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
              this.showHide = false;
              this.noDataFound = false;
            }
            else {
              this.showHide = false;
              this.noDataFound = true;
            }
          } catch (error) {
            console.log(error);
          }
        }, error => {
          //clsGlobal.logManager.writeErrorLog('MultilegLookupPage', 'getValues', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
          console.log(error);
          this.showHide = false;
          this.noDataFound = true;
          this.showLoadersearch = false;
        });
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'getValues2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <27/04/2021> <To change segment from future or options for span margin> **/
  segmentChanged(event) {
    this.scripdetails = event.detail.value;
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.getValues(this.searchTextEntered)
  }

  /** <Norwin Dcruz> <27/04/2021> <To clear search fields and variables> **/
  clearSearch() {
    try {
      this.searchText = "";
      this.scripdetails = 'FUT';
      this.showHide = true;
      this.noDataFound = false;
      this.lookupData = [];
      this.futureOption = false;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'clearSearch',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showExchangePopUp(){
    if(this.exchangelist.length == 0)
    return;
    this.showExchange = !this.showExchange;
  }

  toggleExchange(item){
    try{
    this.selectedExchange = item;
    this.equLTP = "0.00";
    this.equNetChangeInRs = "0.00";
    this.equPercNetChange = "0.00";
    this.equColorTrend = "";
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.localScripKey = [];
    this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
    this.futOptScripKey = [];

    this.equDetails = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.equNSEDetails : this.equBSEDetails;
    let objScrpKey = new clsScripKey();
    objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.equDetails.nMarketSegmentId);            
    objScrpKey.token = this.equDetails.nToken;
    this.localScripKey.push(objScrpKey);
    this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);

    if(this.scripdetails == 'FUT')
    {
      this.showFutLoadersearch = true;
      this.futData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.futNSEData : this.futBSEData;
      for(let count = 0; count < this.futData.length; count++)
      {
        this.futData[count]._source.LTP = "0.00";
        this.futData[count]._source.PercNetChange = "0.00";
        this.futData[count]._source.NetChangeInRs = "0.00";
        this.futData[count]._source.colorTrend = '';
        this.futData[count]._source.PremiumDiscount = "0.00";
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.futData[count]._source.nToken;
        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.futData[count]._source.nMarketSegmentId);
        this.futOptScripKey.push(objScrpKey);
      }
      if(this.futData.length == 0)
      {
        this.noFutDataFound = true;
      }
      else
      {
        this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);
        this.noFutDataFound = false;
      }
    }
    else if(this.scripdetails == 'OPT')
    {
      this.selectedOptionContractData = this.selectedExchange == clsConstants.C_S_NSE_EXCHANGE_TEXT ? this.optNSEData : this.optBSEData;
      if (this.selectedOptionContractData.length == 0)
      {
        this.noOptDataFound = "true";
      }
      else{
        this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
        this.ShowOptionChain(this.distinctOptExpiryDate[0], 0);
        this.noOptDataFound = "false";
      }
    }
    this.showExchangePopUp()
    this.showFutLoadersearch = false;
  }
  catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegLookupPage', 'toggleExchange',error.Message,undefined,error.stack,undefined,undefined));
  }
}
}
