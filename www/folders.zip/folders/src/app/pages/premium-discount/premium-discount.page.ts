import { clsOEFormDetl } from './../../Common/clsOrderEntryFormDetl';
import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { clsHttpService } from './../../Common/clsHTTPService';
import { clsTradingMethods } from './../../Common/clsTradingMethods';
import { clsGlobal } from './../../Common/clsGlobal';
import { NavParamService } from './../../providers/nav-param.service';
import { clsLocalStorageService } from './../../Common/clsLocalStorageService';
import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { CDSServicesProvider } from './../../providers/cds-services/cds.services';
import { clsConstants } from 'src/app/Common/clsConstants';
import { IonContent, NavController, AlertController } from '@ionic/angular';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';

@Component({
  selector: 'app-premium-discount',
  templateUrl: './premium-discount.page.html', 
})
export class PremiumDiscountPage implements OnInit {

  @ViewChild(IonContent, { static: false }) content: IonContent;
  showExpandHeader: boolean = false;
  statusMode: any = 'premium';
  noDataFound: boolean = false;
  showLoader: boolean = false;
  premiumData: any = [];
  discountData: any = [];
  pageSize: any = 10;
  iPageNo: number = 1;
  hdrName: string = "";
  objScannerData: any = {};
  selectedScrip: any;
  showPopUpOE = false;
  showFullMode: boolean = false; // change by om on 3 feb21 new variable to display Popup order entry in full mode.
  loadMoreData: boolean = false;
  infiniteScroll: any;
  tempFavScreeners: any = [];


  constructor(public objCDSService: CDSServicesProvider,
    public navCtrl: NavController,
    public objToast: ToastServicesProvider,
    public clsLocalStorage: clsLocalStorageService,
    private paramService: NavParamService,
    private objHttpService: clsHttpService,
    private alertCtrl: AlertServicesProvider) {
    this.objScannerData = this.paramService.myParam;
    this.hdrName = this.objScannerData.scannerItem.GroupName;
  }
  ngOnInit() {
    this.getPremiumDiscountData();
  }

  eventChanged(event) {
    try{
    this.statusMode = event.detail.value;
    this.loadMoreData = false;
    this.noDataFound = false;
    if (this.statusMode == "premium") {
      this.showLoader = true;
      if (this.premiumData.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.premiumData = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getPremiumDiscountData();
      }
    } else if (this.statusMode == "discount") {
      this.showLoader = true;
      if (this.discountData.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.discountData = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getPremiumDiscountData();
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'eventChanged',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getPremiumDiscountData() {
    this.showLoader = true;
    let instrumentType = "-";
    let requestString = this.statusMode + "/" + instrumentType + "/" + this.iPageNo + "/" + this.pageSize + "/"
    this.objCDSService
      .getPremiumDiscount(requestString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS && objresponse.ResponseObject.recordcount > 0) {
            this.showLoader = false;
            this.noDataFound = false;
            if (this.statusMode == "premium") {
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                let element: any = {};
                element.ExpiryDate = objresponse.ResponseObject.resultset[i].ExpiryDate;
                element.FAOChange = objresponse.ResponseObject.resultset[i].FAOChange;
                element.FAOPercChange = objresponse.ResponseObject.resultset[i].FAOPercChange;
                element.FAOValue = objresponse.ResponseObject.resultset[i].FAOValue;
                element.HighPrice = objresponse.ResponseObject.resultset[i].HighPrice;
                element.LTP = objresponse.ResponseObject.resultset[i].LTP;
                element.InstName = objresponse.ResponseObject.resultset[i].InstName;
                element.LowPrice = objresponse.ResponseObject.resultset[i].LowPrice;
                element.OpenInterest = objresponse.ResponseObject.resultset[i].OpenInterest;
                element.OpenPrice = objresponse.ResponseObject.resultset[i].OpenPrice;
                element.Optiontype = objresponse.ResponseObject.resultset[i].Optiontype;
                element.Premium = parseFloat(objresponse.ResponseObject.resultset[i].Premium).toFixed(2);
                element.PrevClose = objresponse.ResponseObject.resultset[i].PrevClose;
                element.ScripData_BSE = objresponse.ResponseObject.resultset[i].ScripData_BSE;
                element.ScripData_NSE = objresponse.ResponseObject.resultset[i].ScripData_NSE;
                element.StrikePrice = objresponse.ResponseObject.resultset[i].StrikePrice;
                element.Symbol = objresponse.ResponseObject.resultset[i].Symbol.trim().toUpperCase();
                element.TotalTradedQty = objresponse.ResponseObject.resultset[i].TotalTradedQty;
                element.UpdateTime = objresponse.ResponseObject.resultset[i].UpdateTime;
                element.Volume = objresponse.ResponseObject.resultset[i].Volume;
                element.hots = [];
                if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
                  element.Exchange = clsTradingMethods.getExchangeName(element.ScripData_NSE.MarketSegmentId);
                }
                else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
                  element.Exchange = clsTradingMethods.getExchangeName(element.ScripData_BSE.MarketSegmentId);
                }
                this.premiumData.push(element);
              }
              this.fetchEventList();
            }
            else {
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                let element: any = {};
                element.ExpiryDate = objresponse.ResponseObject.resultset[i].ExpiryDate;
                element.FAOChange = objresponse.ResponseObject.resultset[i].FAOChange;
                element.FAOPercChange = objresponse.ResponseObject.resultset[i].FAOPercChange;
                element.FAOValue = objresponse.ResponseObject.resultset[i].FAOValue;
                element.HighPrice = objresponse.ResponseObject.resultset[i].HighPrice;
                element.LTP = objresponse.ResponseObject.resultset[i].LTP;
                element.InstName = objresponse.ResponseObject.resultset[i].InstName;
                element.LowPrice = objresponse.ResponseObject.resultset[i].LowPrice;
                element.OpenInterest = objresponse.ResponseObject.resultset[i].OpenInterest;
                element.OpenPrice = objresponse.ResponseObject.resultset[i].OpenPrice;
                element.Optiontype = objresponse.ResponseObject.resultset[i].Optiontype;
                element.Discount = parseFloat(objresponse.ResponseObject.resultset[i].Discount).toFixed(2);
                element.PrevClose = objresponse.ResponseObject.resultset[i].PrevClose;
                element.ScripData_BSE = objresponse.ResponseObject.resultset[i].ScripData_BSE;
                element.ScripData_NSE = objresponse.ResponseObject.resultset[i].ScripData_NSE;
                element.StrikePrice = objresponse.ResponseObject.resultset[i].StrikePrice;
                element.Symbol = objresponse.ResponseObject.resultset[i].Symbol.trim().toUpperCase();
                element.TotalTradedQty = objresponse.ResponseObject.resultset[i].TotalTradedQty;
                element.UpdateTime = objresponse.ResponseObject.resultset[i].UpdateTime;
                element.Volume = objresponse.ResponseObject.resultset[i].Volume;
                element.hots = [];
                if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
                  element.Exchange = clsTradingMethods.getExchangeName(element.ScripData_NSE.MarketSegmentId);
                }
                else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
                  element.Exchange = clsTradingMethods.getExchangeName(element.ScripData_BSE.MarketSegmentId);
                }
                this.discountData.push(element);
              }
              this.fetchEventList();
            }
            this.loadMoreData = true;
          } else {
            this.noDataFound = true;
            this.showLoader = false;
            this.loadMoreData = false;
          }
        } catch (error) {
          //clsGlobal.logManager.writeErrorLog("PremiumDiscountPage", "getPremiumDiscountData_1", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'getPremiumDiscountData_1',error.Message,undefined,error.stack,undefined,undefined));
          this.showLoader = false;
          this.noDataFound = true;
          this.loadMoreData = false;
        }
      })
      .catch(error => {
        this.showLoader = false;
        this.noDataFound = true;
        this.loadMoreData = false;
        //clsGlobal.logManager.writeErrorLog("PremiumDiscountPage", "getPremiumDiscountData_2", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'getPremiumDiscountData_2',error.Message,undefined,error.stack,undefined,undefined));
      });
  }



  receiveMessage($event) {
    try{
    this.showPopUpOE = !$event.closePopUp;
    this.showFullMode = false;
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'receiveMessage',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  onFocus(event) {
    this.showFullMode = true;
  }

  scrollContent(event) {
    try{
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'scrollContent',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  goBack() {
    this.navCtrl.pop();
  }

  doInfinite(event) {
    try{
    setTimeout(() => {
      event.target.complete();
      this.infiniteScroll = event;
      this.fetchDetails(true);
    }, 500);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  fetchDetails(fromScrolling: boolean = false) {
    try{
    if (this.statusMode == "premium") {
      if (this.premiumData.length <= 0 || fromScrolling) {
        this.iPageNo += 1;
        if (this.iPageNo >= 2)
          this.iPageNo = this.iPageNo;
        else
          this.iPageNo = clsConstants.CDS_PAGE_NO;
      }
    }
    else if (this.statusMode == "discount") {
      if (this.discountData.length <= 0 || fromScrolling) {
        this.iPageNo += 1;
        if (this.iPageNo >= 2) {
          this.iPageNo = this.iPageNo;
        }
        else {
          this.iPageNo = clsConstants.CDS_PAGE_NO;
        }
      }
    }
    this.getPremiumDiscountData();
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'fetchDetails',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  applyEventToScannerList() {
    try {
      let segmentId: any;
      let token: any;
      clsGlobal.EventList.forEach(eventItem => {
        this.premiumData.forEach(element => {
          if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
            segmentId = element.ScripData_NSE.MarketSegmentId;
            token = element.ScripData_NSE.ODINCode;
          }
          else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
            segmentId = element.ScripData_BSE.MarketSegmentId;
            token = element.ScripData_BSE.ODINCode;
          }
          if (clsTradingMethods.getMappedMarketSegmentId(segmentId) == eventItem.mktid && parseInt(token) == eventItem.token) {
            if (!element.hots.includes(eventItem))
              element.hots.push(eventItem);
          }
        });
      });
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'applyEventToScannerList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async fetchEventList() {
    await this.applyEventToScannerList();
  }

  async favUnFavScreeners(item) {
    try {
      await this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.tempFavScreeners = obj;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if (!item.scannerItem.Favourite || item.scannerItem.Favourite == false) {
        item.scannerItem.Favourite = true;
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = true;
        });
        this.tempFavScreeners.push(item.scannerItem);
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
      else {
        if (this.tempFavScreeners.length == 5)
          return this.objToast.showAtBottom("There should be atleast 5 Screeners in My Favourite Screeners.");
        item.scannerItem.Favourite = false;
        this.tempFavScreeners = this.tempFavScreeners.filter((element, index, array) => {
          return element.GroupName != this.hdrName;
        });
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = false;
        });
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'fetchEventList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showPopUpOrderEntry(item) {
    try {
      let segmentId: any;
      let token: any;
      if (clsGlobal.User.isGuestUser) {
        this.alertCtrl.showAlert(
          "Register now to access this feature!",
          "Order Error!"
        );
        return;
      }
      if (item.ScripData_NSE != undefined && item.ScripData_NSE != "-") {
        segmentId = item.ScripData_NSE.MarketSegmentId;
        token = item.ScripData_NSE.ODINCode;
      }
      else if (item.ScripData_BSE != undefined && item.ScripData_BSE != "-") {
        segmentId = item.ScripData_BSE.MarketSegmentId;
        token = item.ScripData_BSE.ODINCode;
      }

      if (!clsCommonMethods.isLoginAllowed(segmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(parseInt(segmentId)),
          token: token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
        let res = resp.result[0];
        if (!res) {
          this.objToast.showAtBottom("Unable to open Order Entry.");
          return;
        }
        let selectedScripObj = clsCommonMethods.getScripObject(resp.result[0]).scripDetail;
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
        objOEFormDetail.scripDetl = selectedScripObj;
        this.selectedScrip = objOEFormDetail;
        //Uncomment Below to open order entry popup, in same page
        this.showPopUpOE = !this.showPopUpOE;

      }).catch(error => {
        this.objToast.showAtBottom("Unable to open Order Entry.");
        clsGlobal.logManager.writeErrorLog('PremiumDiscountPage', 'showPopUpOrderEntry', error);
      });
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog('PremiumDiscountPage', 'showPopUpOrderEntry', error);
      // clsGlobal.ConsoleLogging("Error : " + error, "Unable to open Order Entry", "showPopUpOrderEntry");
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'showPopUpOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  scripInfo(item) {
    try{
    let segmentId: any;
    let token: any;
    if (clsGlobal.User.isGuestUser) {
      this.alertCtrl.showAlert(
        "Register now to access this feature!",
        "Order Error!"
      );
      return;
    }
    if (item.ScripData_NSE != undefined && item.ScripData_NSE != "-") {
      segmentId = item.ScripData_NSE.MarketSegmentId;
      token = item.ScripData_NSE.ODINCode;
    }
    else if (item.ScripData_BSE != undefined && item.ScripData_BSE != "-") {
      segmentId = item.ScripData_BSE.MarketSegmentId;
      token = item.ScripData_BSE.ODINCode;
    }

    if (!clsCommonMethods.isLoginAllowed(segmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }

    let scripdetail = {
      scrips: [{
        mkt: clsTradingMethods.getApiExchangeName(parseInt(segmentId)),
        token: token
      }]
    }

    clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
      let res = resp.result[0];
      if (!res) {
        this.objToast.showAtBottom("Unable to open Scrip Info.");
        return;
      }
      let selectedScripObj = clsCommonMethods.getScripObject(resp.result[0]).scripDetail;
      this.paramService.myParam = selectedScripObj;
      this.navCtrl.navigateForward('scripinfo');
    }).catch(error => {

      this.objToast.showAtBottom("Unable to open Scrip Info.");
      clsGlobal.logManager.writeErrorLog('scrrenr-view', 'scripinfo', error);
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PremiumDiscountPage', 'scripInfo',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
}