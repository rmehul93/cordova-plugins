import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
//import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PopoverController, NavController, ModalController, Platform, IonContent } from '@ionic/angular';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from '../../Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsMultiTouchLineRequest } from '../../communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from '../../communicator/clsMultiTouchLineResponse';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';

import { WatchlistloaderPage } from '../watchlistloader/watchlistloader.page';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
//import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { CupertinoPane, CupertinoSettings } from 'cupertino-pane';
//import { FindValueSubscriber } from 'rxjs/internal/operators/find'; 
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsExchManager } from 'src/app/Common/clsExchManager';
import { OptionChainPage } from '../option-chain/option-chain.page';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
@Component({
  selector: 'app-lookup',
  templateUrl: './lookup.page.html',
})
export class LookupPage implements OnInit {
  searchText: string = "";
  showSegments: boolean = false;
  searchTextChanged = new Subject<string>();
  subscription: any;
  lookupGlobalData: any = [];
  lookupData: any = [];
  lookupEquityData: any = []
  lookupOptFilterData: any = []
  lookupFutData: any = []
  lookupOptData: any = []
  optionChainpopUp: boolean = false;
  selectedSegment: any = "ALL";
  selectedScripObj: any;
  showPopUpOE: boolean = false;
  searchTextEntered: string = '';
  selectedOptionContract: any = []; //this will be selected contract on option click.
  selectedOptionContractData: any = [];// this will contain all option data
  selectedOptionContractIndex: any = 0;//on click contract on option tab index.
  bcastHandler: any;
  lstScripKey: any = [];
  watchlistData: any = '';
  selecteScrips: any = [];
  selecteScripAddToWatchlist: any;
  scripIndex: any = 0;
  recentlySearched: boolean = false;
  recentlySearchedScrip: any = [];
  showRecommendations: boolean = false;
  showSectors: boolean = false;
  showTrending: boolean = false;
  hotPursuitCount: number;
  initialWatchListCount: number;
  trendingScrips: any = [];
  loadMoreData: boolean = true;
  infiniteScroll: any;
  recordFrom: number = 0;
  recordTo: number = 25;
  showWatchList: boolean = false;
  savingData: boolean = false;
  selectContractForOption: any; // change by om to display selected contract on option window.
  showFullMode: boolean = false; // change by om on 3 feb21 new variable to display Popup order entry in full mode.
  showLoadersearch: boolean = false;
  showNoDataFound: boolean = false;
  recoFilterPopup: boolean = false;
  @ViewChild('divRecoFilter', { static: false }) divRecoFilter: ElementRef;
  @ViewChild('divScrollOptionChain', { static: false }) divScrollOptionChain: ElementRef;

  showExpandedRecoFilter: boolean = false;
  recoFilterPane: any;
  distinctOptExpiryDate = [];
  selectedIdxOptnChain: number = 0;
  recoData = [];
  isScrollIntoView = false;
  bIsScrollIntoViewProgress = false;
  divHeight = 385;
  dcExpiryWiseStrikePrice = new Dictionary<any>();
  deletedScrips: any = [];

  constructor(
    private navCtrl: NavController,
    public http: clsHttpService,
    private paramService: NavParamService,
    public toastProvider: ToastServicesProvider,
    private localstorageservice: clsLocalStorageService,
    private watchlistServ: WatchlistService,
    public popoverController: PopoverController,
    public modalController: ModalController,
    private route: ActivatedRoute,
    public alertCtrl: AlertServicesProvider,
    private objCDSService: CDSServicesProvider,
    public platform: Platform,
    public loadingCtrl: LoaderServicesProvider,
    public speechRecognition: SpeechRecognition
  ) {
    try {
      clsGlobal.logManager.writeErrorLog("lookup", "constructor_1", "Inside constructure.");
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("lookup", "constructor_2", "Inside constructure." + error.message);
    }
  }
  ngOnInit() {
    try {
      this.watchlistData = this.route.snapshot.queryParams.type != undefined ? this.route.snapshot.queryParams : '';
      if (this.watchlistData != '' && this.watchlistData.type == "UPDATE") {
        this.watchlistServ.getWatchlistProfileScrip(this.watchlistData.profile.nWatchListId, this.watchlistData.profile.sCreatedBy).then((profScrip: any) => {
          //this.selecteScrips =  profScrip.rows;
          //this will used to enable done button. if selectedScrips count is greated then initialWatchListCount
          this.initialWatchListCount = 0;
          if (profScrip != undefined) {
            this.initialWatchListCount = profScrip.length;
            for (let index = 0; index < profScrip.length; index++) {
              const element = profScrip[index];
              //this.selecteScrips.push({ MktSegId: parseInt(element.nMarketSegmetId || element.nMarketSegmentId), Token: element.nToken, SeqNo: element.nSequenceNo, isNew: false });
              this.selecteScrips.push({ MktSegId: parseInt(element.scripDet.MapMktSegId), Token: element.scripDet.token, SeqNo: (index + 1), isNew: false });
              if (index == profScrip.length - 1) {
                this.scripIndex = (index + 1);
              }
            }
          }
        }, (error) => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
        });
      }
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog("lookup", "ngOnInit", error.message);
      // console.log("Error LookUp_Contructor" + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ngOnInit2',error.Message,undefined,error.stack,undefined,undefined));
    }
    try {
      this.hotPursuitCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_HOTPURSUIT_SCRIP_COUNT)) || 10;
      this.scripIndex = 0;
      //, distinctUntilChanged()
      this.subscription = this.searchTextChanged.pipe(debounceTime(500)
      ).subscribe(search => this.getValues(search)); 
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.loadRecentScripts(); 
      this.getHotpursuitData();
      this.getRecommendation();
    } catch (error) {
      //alert("Error in ngOnInit" + error.message);
      // clsGlobal.logManager.writeErrorLog("lookup", "ngOnInit_2", error.message);
      // console.log("Error in ngOnInit " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ngOnInit3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewWilEnter() {
    try {
      this.scripIndex = 0;
      this.selecteScrips = [];
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "ionViewWilEnter", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ionViewWilEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      this.savingData = false;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "ionViewWillLeave", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  scripLtp: any = 0.00;
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (this.selectedSegment == "ALL") {
        for (let i = 0; i < this.lookupData.length; i++) {
          if (this.lookupData != undefined &&
            this.lookupData[i]._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.lookupData[i]._source.nToken == objMultiTLResp.Scrip.token) {
            this.lookupData[i].LTP = objMultiTLResp.LTP;
            break;
          }
        }
      }
      if (this.selectedSegment == "EQUITIES") {
        for (let i = 0; i < this.lookupEquityData.length; i++) {
          if (this.lookupEquityData != undefined &&
            this.lookupEquityData[i]._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.lookupEquityData[i]._source.nToken == objMultiTLResp.Scrip.token) {
            this.lookupEquityData[i].LTP = objMultiTLResp.LTP;
            break;
          }
        }
        //console.log(this.lookupEquityData)
      }
      if (this.selectedSegment == "FUTSTK") {
        for (let i = 0; i < this.lookupFutData.length; i++) {
          if (this.lookupFutData != undefined &&
            this.lookupFutData[i].element.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.lookupFutData[i].element.nToken == objMultiTLResp.Scrip.token) {
            this.lookupFutData[i].element.LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.lookupFutData[i].element.NetChangeInRs = arrNetChange[0];
            this.lookupFutData[i].element.PercNetChange = arrNetChange[1];
            this.lookupFutData[i].element.LTPTrend = arrNetChange[2];
            this.lookupFutData[i].element.arrowTrend = arrNetChange[3];
            break;
          }
          for (let j = 0; j < this.lookupFutData[i].futData.length; j++) {
            if (this.lookupFutData != undefined &&
              this.lookupFutData[i].futData[j]._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
              this.lookupFutData[i].futData[j]._source.nToken == objMultiTLResp.Scrip.token) {
              this.lookupFutData[i].futData[j].LTP = objMultiTLResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
              this.lookupFutData[i].futData[j].NetChangeInRs = arrNetChange[0];
              this.lookupFutData[i].futData[j].PercNetChange = arrNetChange[1];
              this.lookupFutData[i].futData[j].LTPTrend = arrNetChange[2];
              this.lookupFutData[i].futData[j].arrowTrend = arrNetChange[3];
              break;
            }
          }
        }
      }
      if (this.selectedSegment == "OPTSTK") {
        if (this.selectedOptionContract.length > 0) {
          for (let i = 0; i < this.selectedOptionContract.length; i++) {


            if (this.selectedOptionContract[i].ceData.Money == "call-add-money") {
              this.selectedOptionContract[i].ceData._source.nStrikePrice1 = this.scripLtp;
            }
            if (this.selectedOptionContract[i].peData.Money == "put-add-money") {
              this.selectedOptionContract[i].peData._source.nStrikePrice1 = this.scripLtp;
            }

            if (parseFloat(this.scripLtp) > parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1)) {
              if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                this.selectedOptionContract[i].ceData.Money = "call-background";
              }

            }
            else {
              if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                this.selectedOptionContract[i].ceData.Money = "put-background";
              }

            }

            if (parseFloat(this.scripLtp) < parseFloat(this.selectedOptionContract[i].peData._source.nStrikePrice1)) {
              if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                this.selectedOptionContract[i].peData.Money = "call-background";
              }

            }
            else {
              if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                this.selectedOptionContract[i].peData.Money = "put-background";
              }

            }

            if (this.selectedOptionContract != undefined &&
              this.selectedOptionContract[i].ceData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
              this.selectedOptionContract[i].ceData._source.nToken == objMultiTLResp.Scrip.token) {
              this.selectedOptionContract[i].ceData.LTP = objMultiTLResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
              this.selectedOptionContract[i].ceData.NetChangeInRs = arrNetChange[0];
              this.selectedOptionContract[i].ceData.PercNetChange = arrNetChange[1];
              this.selectedOptionContract[i].ceData.LTPTrend = arrNetChange[2];
              this.selectedOptionContract[i].ceData.arrowTrend = arrNetChange[3];
              this.selectedOptionContract[i].ceData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;;
              this.selectedOptionContract[i].ceData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;;
              if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) > 0) {
                this.selectedOptionContract[i].ceData.colorOITrend = "color-positive";
              }
              else if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) < 0) {
                this.selectedOptionContract[i].ceData.colorOITrend = "color-negative";
              }
              else {
                this.selectedOptionContract[i].ceData.colorOITrend = "";
              }
              let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLtp),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objMultiTLResp.LTP, "CALL");
              this.selectedOptionContract[i].ceData.IV = parseFloat(ImpVoltality).toFixed(4);
              break;


            }
            else if (this.selectedOptionContract != undefined &&
              this.selectedOptionContract[i].peData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
              this.selectedOptionContract[i].peData._source.nToken == objMultiTLResp.Scrip.token) {
              this.selectedOptionContract[i].peData.LTP = objMultiTLResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
              this.selectedOptionContract[i].peData.NetChangeInRs = arrNetChange[0];
              this.selectedOptionContract[i].peData.PercNetChange = arrNetChange[1];
              this.selectedOptionContract[i].peData.LTPTrend = arrNetChange[2];
              this.selectedOptionContract[i].peData.arrowTrend = arrNetChange[3];
              this.selectedOptionContract[i].peData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;
              this.selectedOptionContract[i].peData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;
              if (parseFloat(this.selectedOptionContract[i].peData.PercOI) > 0) {
                this.selectedOptionContract[i].peData.colorOITrend = "color-positive";
              }
              else if (parseFloat(this.selectedOptionContract[i].peData.PercOI) < 0) {
                this.selectedOptionContract[i].peData.colorOITrend = "color-negative";
              }
              else {
                this.selectedOptionContract[i].peData.colorOITrend = "";
              }
              let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLtp),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objMultiTLResp.LTP, "PUT");
              this.selectedOptionContract[i].peData.IV = parseFloat(ImpVoltality).toFixed(4);;

              break;
            }
            else if (this.selectedOptionContract != undefined &&
              this.selectedOptionContract[0].ceData._source.nAssetToken == objMultiTLResp.Scrip.token) {
              this.scripLtp = objMultiTLResp.LTP;
              if (this.selectedOptionContract.filter(x => x.ceData._source.class == 'call-put-add-money').length == 0) {
                let obj = {
                  "ceData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" },
                  "peData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" }
                }
                this.selectedOptionContract.push(obj)
                this.selectedOptionContract.sort((a, b) => (parseFloat(a.nStrikePrice1) < parseFloat(b.nStrikePrice1)) ? -1 : 1)
              }

              let nearScrip = this.selectedOptionContract.filter(x => parseFloat(x.ceData._source.nStrikePrice1) <= parseFloat(this.scripLtp));
              if (nearScrip.length > 0 && !this.isScrollIntoView) {//&& !this.isScrollIntoView
                //console.log(nearScrip[0]);
                //this.bIsScrollIntoViewProgress = true;
                if (this.divRecoFilter != undefined)
                  this.divRecoFilter.nativeElement.scrollTop = 0;
                setTimeout(() => {
                  let elemnt = document.getElementById(nearScrip[nearScrip.length - 2].ceData._source.nToken);
                  if (elemnt != undefined)
                    elemnt.scrollIntoView({ behavior: 'smooth' });
                  // setTimeout(() => {
                  //   this.bIsScrollIntoViewProgress = false;
                  // }, 5000);
                }, 2000);

                this.isScrollIntoView = true;
                //console.log('Element: ', nearScrip[0]);

              }
              break;
            }
          }
          this.selectedOptionContract.sort((a, b) => (parseFloat(a.ceData._source.nStrikePrice1) < parseFloat(b.ceData._source.nStrikePrice1)) ? -1 : 1)
        }


      }
    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  dateDiffernece(inputdate) {
    try {
      let nextdate: any = new Date(inputdate);
      let curruntData: any = new Date()
      let diffTime = Math.abs(nextdate - curruntData);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'dateDiffernece',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('lookup', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  sendBroadcastRequest() {
    try {
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      let data = [];
      this.lstScripKey = [];
      if (this.selectedSegment == "ALL") {
        data = this.lookupEquityData
      }
      if (this.selectedSegment == "EQUITIES") {
        data = this.lookupEquityData
      }
      if (this.selectedSegment == "FUTSTK") {
        data = this.lookupFutData
      }
      // if(this.selectedSegment == "OPTSTK")
      // {
      //   data = this.lookupFutData
      // }
      if (this.selectedSegment == "ALL" || this.selectedSegment == "EQUITIES") {
        for (let i = 0; i < data.length; i++) {
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = data[i]._source.nToken;
          objScrpKey.MktSegId = data[i]._source.nMarketSegmentId;
          this.lstScripKey.push(objScrpKey);
        }
      }
      else {
        for (let i = 0; i < data.length; i++) {
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = data[i].element.nToken;
          objScrpKey.MktSegId = data[i].element.nMarketSegmentId;
          this.lstScripKey.push(objScrpKey);
          for (let j = 0; j < data[i].futData.length; j++) {
            let objScrpKey: clsScripKey = new clsScripKey();
            objScrpKey.token = data[i].futData[j]._source.nToken;
            objScrpKey.MktSegId = data[i].futData[j]._source.nMarketSegmentId;
            this.lstScripKey.push(objScrpKey);
          }
        }
      }
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'sendBroadcastRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  search(event) {
    try{
    if (event.target != undefined && event.target.value) {
      this.searchText = event.target.value.toUpperCase().trim(); 
      this.searchTextChanged.next(event.target.value.toUpperCase().trim());
      this.recentlySearched = false;
      this.showTrending = false;
      this.showRecommendations = false;
    } else {
      this.loadRecentScripts();
      this.getHotpursuitData();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'search',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  recentlyTrendingSearch(symbol) {
    if (symbol != undefined) {
      this.searchText = symbol.toUpperCase().trim(); 
      this.searchTextChanged.next(this.searchText);
      this.recentlySearched = false;
      this.showTrending = false;
      this.showRecommendations = false;
    } else {
      this.loadRecentScripts();
      this.getHotpursuitData();
    }
  }
  getValues(search) {
    try {

      if (search.length < 2) {
        this.searchTextEntered = '';
        this.lookupData = [];
        this.lookupEquityData = [];
        this.lookupFutData = [];
        this.lookupOptData = [];
        this.clearSearch();
        return;
      }
      this.showLoadersearch = true;
      this.showNoDataFound = false;
      this.searchTextEntered = search.toUpperCase().trim();
      this.lookupData = [];
      this.lookupEquityData = [];
      this.lookupFutData = [];
      this.lookupOptData = [];
      this.recentlySearched = false;
      this.showTrending = false;
      this.showRecommendations = false;
      this.recordFrom = 0;
      this.recordTo = 25;
      //this.selectedSegment = "ALL";
      //alert("Search text : "+this.searchTextEntered);
      let _viewAllowed=clsGlobal.User.viewAllowed || -1;
       this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getScripLookUp/", this.searchTextEntered + "/"+_viewAllowed)
       //this.http.getJsonForSearch(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + '1524/' + clsGlobal.versionId + "/getScripLookUp/", this.searchTextEntered + "/-1")
        .subscribe(data => {
          //TODO
          let _response: any = data
          if (_response.status) {
            if (_response.result.hits != undefined) {
              //console.log("START: " + (new Date()).toISOString());
              this.showLoadersearch = false;
              this.lookupGlobalData = _response.result.hits.hits;
              if (this.lookupGlobalData.length > 0) {
                this.recordTo = this.recordTo >= this.lookupGlobalData.length ? this.lookupGlobalData.length : this.recordTo;
                for (let i = this.recordFrom; i < this.recordTo; i++) {
                  this.lookupData.push(this.lookupGlobalData[i]);
                }
                this.lookupEquityData = this.lookupData.filter(x => x._source.sInstrumentName == 'EQUITIES')
                this.lookupOptFilterData = this.lookupData.filter(x => x._source.sInstrumentName == 'OPTSTK')
                let distinctAssetToken = this.getDistinctAssetToken(this.lookupData);
                for (let i = 0; i < distinctAssetToken.length; i++) {
                  let futData = this.lookupData.filter(x => x._source.nAssetToken == distinctAssetToken[i] && x._source.sInstrumentName.startsWith("FUT") && x._source.nSpread == 0)
                  let futDataspread = this.lookupData.filter(x => x._source.nAssetToken == distinctAssetToken[i] && x._source.sInstrumentName.startsWith("FUT") && x._source.nSpread == 1)
                  if (futData.length > 0) {
                    let element = {
                      sSymbol: futData[0]._source.sSymbol,
                      sExchange: futData[0]._source.sExchange,
                      sDerivitiveDesc: futData[0]._source.sDerivitiveDesc,
                      nMarketSegmentId: 1,
                      nToken: futData[0]._source.nAssetToken,
                      spreadContract: false
                    }
                    this.lookupFutData.push({ "futData": futData, element })
                  }

                  if (futDataspread.length > 0) {
                    let element = {
                      sSymbol: futDataspread[0]._source.sSymbol,
                      sExchange: futDataspread[0]._source.sExchange,
                      sDerivitiveDesc: futDataspread[0]._source.sDerivitiveDesc,
                      nMarketSegmentId: 1,
                      nToken: futDataspread[0]._source.nAssetToken,
                      spreadContract: true
                    }
                    this.lookupFutData.push({ "futData": futDataspread, element })
                  }
                }
                this.sendBroadcastRequest();
                //console.log("END: " + (new Date()).toISOString());
                if (this.recordTo >= this.lookupGlobalData.length) {
                  this.loadMoreData = false;
                }
                //console.log(this.lookupData)  
                this.showSegments = true;
              }
              else {
                this.showNoDataFound = true;
              }

            }
            else {
              this.showLoadersearch = false;
              this.showNoDataFound = true;
              //this.toastProvider.showAtMiddle("No data Found");
            }
          }
          else {
            this.showLoadersearch = false;
            this.showNoDataFound = true;
            //this.toastProvider.showAtMiddle("No data Found");
          }
        }, error => {
          this.showLoadersearch = false;
          this.showNoDataFound = true;
          console.log(error.error.message);
          this.toastProvider.showAtBottom("Error in searching contracts, kindly try again or contact administrator.");
          //alert("ERROR in calling search : "+ JSON.stringify(error));
          this.showSegments = false;
          //clsGlobal.logManager.writeErrorLog('lookupPage', 'getValues 1', JSON.stringify(error));
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
          //this.toastProvider.showAtBottom(error.error.message);
        });
    } catch (error) {
      this.showLoadersearch = false;
      this.showNoDataFound = true;
      //alert("ERROR CATCH "+error.message);
      // clsGlobal.logManager.writeErrorLog('lookupPage', 'getValues 2', error);
      // console.log(error)
      this.toastProvider.showAtBottom("Error in searching contracts, kindly try again.");
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getValues2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  getDistinctAssetToken(array) {
    try{
    let distinct = [...new Set(array.map(item => item._source.nAssetToken))];
    let index = distinct.indexOf(0);
    if (index !== -1) {
      distinct.splice(index, 1);
    }
    return distinct;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getDistinctAssetToken',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  scripClick(scripobj) {
    try {
      if (scripobj.nIsIndex == 1) {
        return;
      }
      let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
      if (this.recentlySearchedScrip.filter(x => (x.nToken == scripinfoObj.scripDetail.scripDet.token) && (x.nMarketSegmentId == scripinfoObj.scripDetail.scripDet.MapMktSegId)).length <= 0) {
        if (this.recentlySearchedScrip.length >= 5) {
          this.recentlySearchedScrip.pop();
          this.recentlySearchedScrip.unshift(scripobj)
        }
        else {
          this.recentlySearchedScrip.unshift(scripobj)
        }
        this.localstorageservice.setItem(clsGlobal.User.userId + '_recentlySearchedScrip', this.recentlySearchedScrip);
      }
      this.paramService.myParam = scripinfoObj.scripDetail;
      this.navCtrl.navigateForward(["/scripinfo"]);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'scripClick',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  SearchTextEnter() {
    if (this.searchText.length > 0) {
      this.showSegments = true;
    }
    else {
      this.showSegments = false;
    }
  }
  clickPopover(ev: any) {
    // const popover =  this.popoverController.create({
    //   component: PopoversComponent,
    //   event: ev,
    //   translucent: true,
    //   mode : "ios"
    // });
    //return  popover.present();
  }
  onFocused() {
    console.log('Focus on input box.');
  }
  goBack() {
    this.navCtrl.pop();
  }
  CreateWatchList() {
    this.navCtrl.navigateForward('watchlist');
  }
  lookupSegmentChange(event) {
    try{
    this.sendBroadcastRequest();
    if (event.detail.value == 'OPTSTK') {
      if (this.lookupFutData != undefined && this.lookupFutData.length > 0) {
        let symbol = this.lookupFutData[0].element.sSymbol;
        if (this.distinctOptExpiryDate == undefined || this.distinctOptExpiryDate.length == 0) {

          this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/" + event.detail.value + "/" + null + "/" + symbol).subscribe(response => {
            try {
              //TODO
              let _response: any = response;
              if (_response.status) {
                if (_response.result.hits != undefined && _response.result.hits.hits.length != 0) {
                  this.selectedOptionContractData = _response.result.hits.hits;
                  this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
                  this.dcExpiryWiseStrikePrice.Clear();
                  for (let index = 0; index < this.distinctOptExpiryDate.length; index++) {
                    const element = this.distinctOptExpiryDate[index];
                    this.addExpiryWiseStrikePrice(element);
                  }
                }
                else {
                  this.selectedOptionContract = [];
                }
                //this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
                //this.showRecoFilter();
              }
              else {
                //no option data found.
              }
              //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
            } catch (error) {
              console.log(error);
            }
          }, error => {
            console.log(error.error.message);
            //this.toastProvider.showAtBottom(error.error.message);
          });
        }
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'lookupSegmentChange',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  async showOptionChain(data, index: any) {
    try {

      this.isScrollIntoView = false;
      if (this.divRecoFilter != undefined)
        this.divRecoFilter.nativeElement.scrollTop = 0;
      if (this.optionChainpopUp) {
        this.selectedOptionContractIndex = 0;
        //this.selectedOptionContractData = [];
        this.optionChainpopUp = false;
        return;
      }
      this.selectContractForOption = data._source;
      //this.selectedOptionContract=data;
      //this.selectedOptionContract = [];
      this.selectedOptionContractIndex = index;
      //this.distinctOptExpiryDate = [];
      this.optionChainpopUp = !this.optionChainpopUp;
      let instsub = data._source.sInstrumentName.substr(3, 3);
      let instrumentName = "OPT" + instsub
      let expiryDate = data._source.nExpiryDate1
      let symbol = data._source.sSymbol;

      this.showRecoFilter();
      this.ShowOptionChain(this.distinctOptExpiryDate[index], index);

      // await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/" + instrumentName + "/" + null + "/" + symbol).subscribe(response => {
      //   try {
      //     //TODO
      //     let _response: any = response;
      //     if (_response.status) {
      //       if (_response.result.hits != undefined && _response.result.hits.hits.length != 0) {
      //         this.selectedOptionContractData = _response.result.hits.hits;
      //         this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
      //         this.ShowOptionChain(this.distinctOptExpiryDate[index], index)
      //       }
      //       else {
      //         this.selectedOptionContract = [];
      //       }
      //       //this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
      //       //this.showRecoFilter();
      //     }
      //     else {
      //       //no option data found.
      //     }
      //     //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
      //   } catch (error) {
      //     console.log(error);
      //   }
      // }, error => {
      //   console.log(error.error.message);
      //   //this.toastProvider.showAtBottom(error.error.message);
      // });
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'showOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getDistinctExpiryDate(array) {
    try {
      let distinct = [...new Set(array.map(item => item._source.nExpiryDate1))];
      return distinct;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getDistinctExpiryDate1', error);
    }

  }

  async ShowOptionChain(expiryDate, idx) {
    try {
      this.selectedIdxOptnChain = idx;
      this.selectedOptionContract = [];
      this.isScrollIntoView = false;
      if (this.divScrollOptionChain != undefined)
        this.divScrollOptionChain.nativeElement.scrollTop = 0;
      // let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      // let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      // let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      // for (let i = 0; i < optCEData.length; i++) {
      //   let obj;
      //   optCEData[i].LTP = "0.00";
      //   optCEData[i].NetChangeInRs = "0.00";
      //   optCEData[i].PercNetChange = "0.00";
      //   optCEData[i].OI = "0.00";
      //   optCEData[i].PercOI = "0.00";
      //   optCEData[i].IV = "0";

      //   optPEData[i].LTP = "0.00";
      //   optPEData[i].NetChangeInRs = "0.00";
      //   optPEData[i].PercNetChange = "0.00";
      //   optPEData[i].OI = "0.00";
      //   optPEData[i].PercOI = "0.00";
      //   optPEData[i].IV = "0";

      //   let ceData = optCEData[i]
      //   let peData = optPEData[i]
      //   obj = { "ceData": ceData, "peData": peData }
      //   this.selectedOptionContract.push(obj)
      // }
      //this.sendBroadcastReqForOptionChain(this.selectedOptionContract);
      let modalOptChn = await this.modalController.create({
        component: OptionChainPage,
        componentProps: {
          'selectContractForOption': this.selectContractForOption,
          'distinctOptExpiryDate': this.distinctOptExpiryDate,
          //'selectedOptionContract': this.selectedOptionContract,
          //'selectedOptionContractData':this.selectedOptionContractData,
          'selectedOptionContractData': this.dcExpiryWiseStrikePrice,
          'selectedIdxOptnChain': idx,
          'watchlistData': this.watchlistData,
          'scripIndex': this.scripIndex,
          'selecteScrips': this.selecteScrips,
          'saveWatchlistHandle': this.saveWatchlist.bind(this)
        }
      });

      modalOptChn.onDidDismiss().then((evtData) => {
        this.hideOptionChain();
      })
      await modalOptChn.present();

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'ShowOptionChain1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ShowOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }


  }
  sendBroadcastReqForOptionChain(selectedData) {
    try {
      this.lstScripKey = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      for (let i = 0; i < selectedData.length; i++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = selectedData[i].ceData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].ceData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[i].peData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].peData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[0].peData._source.nAssetToken;
        objScrpKey.MktSegId = clsCommonMethods.getMarketSegmentIdForIndex(selectedData[i].peData._source.sExchange);
        this.lstScripKey.push(objScrpKey);
      }
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "sendBroadcastReqForOptionChain", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'sendBroadcastReqForOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  hideOptionChain() {
    //this.divScrollOptionChain.nativeElement.scrollTop = 0;
    this.recoFilterPopup = !this.recoFilterPopup;
    this.optionChainpopUp = !this.optionChainpopUp;
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
    this.selectedOptionContract = [];
    this.lstScripKey = [];
    //this.recoFilterPane.destroy({ animate: true });
  }
  //show Order Entry PopUp.
  showPopUpOrderEntry(item) {
    try {
      // if (clsGlobal.User.isGuestUser) {
      //   this.alertCtrl.showAlert(
      //     "Register now to access this feature!",
      //     "Order Error!"
      //   );
      //   return;
      // }

      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }


      //let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
      let ScripObj = clsCommonMethods.getScripObject(item._source);;
      // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
      let SegmentId = ScripObj.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      if (parseInt(ScripObj.scripDetail.Spread) == 1) {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.scripDetl = ScripObj.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.paramService.myParam = objOEFormDetail;
        this.navCtrl.navigateForward('spread-orderentry');
      }
      else {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;

        objOEFormDetail.scripDetl = ScripObj.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.selectedScripObj = objOEFormDetail;

        this.showPopUpOE = true;

      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "showPopUpOrderEntry", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'showPopUpOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode = false;
  }
  //change by ompraksh d on 3 feb.
  //when ever controls in order entry will focus 
  //popup order entry will be in full mode.
  onFocus(event) {
    this.showFullMode = true;
  }

  //add to watchlist
  addToGlobalWatchList(item) {
    try {
      if (this.watchlistData != '') {
        let scrip = item._source;

        let isScripExist = this.selecteScrips.filter(item => {
          return item.MktSegId == parseInt(scrip.nMarketSegmentId) && item.Token == scrip.nToken
        });
        if (isScripExist.length == 0) {
          let maxScripCnt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_WATCHLIST_SCRIP_COUNT) || '50')
          if (this.selecteScrips.length >= maxScripCnt) {
            this.toastProvider.showAtBottom(clsConstants.C_S_ERROR_PROFILE_SCRIP);
            return;
          }

          let isDelScripExist = this.deletedScrips.filter((item, idx) => {
            return item.MktSegId == parseInt(scrip.nMarketSegmentId) && item.Token == scrip.nToken
          });

          if (isDelScripExist.length == 0) {
            this.selecteScrips.push({ MktSegId: parseInt(scrip.nMarketSegmentId), Token: scrip.nToken, SeqNo: ++this.scripIndex });
          } else {

            this.selecteScrips.push(isDelScripExist[0]);
            for (let index = 0; index < this.deletedScrips.length; index++) {
              const element = this.deletedScrips[index];
              //&& element.isNew == undefined
              if (element.MktSegId == parseInt(scrip.nMarketSegmentId) && element.Token == scrip.nToken) {

                let deleteItem = this.deletedScrips.splice(index, 1);
                break;
              }
            }

          }
        }
        else {
          this.toastProvider.showAtBottom("Scrip already exist in watchlist.");
        }
      } else {
        this.showWatchList = true;
        this.selecteScripAddToWatchlist = clsCommonMethods.getScripObject(item._source);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "addToGlobalWatchList", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'addToGlobalWatchList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearch() {
    try {
      this.searchText = "";
      if (this.trendingScrips.length > 0) {
        this.showTrending = true;
      }
      else {
        this.showTrending = false;
      }

      if (this.recoData.length > 0) {
        this.showRecommendations = true;
      }
      else {
        this.showRecommendations = false;
      }



      this.showSegments = false;
      if (this.recentlySearchedScrip.length > 0) {
        this.recentlySearched = true;
      }
      else {
        this.recentlySearched = false;
      }

      this.lookupData = [];
      this.lookupEquityData = [];
      this.lookupFutData = [];
      this.lookupOptData = [];
      this.selectedSegment = "ALL";
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "clearSearch", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'clearSearch',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  async saveWatchlist() {
    try {
      if (this.savingData) {
        return;
      }
      this.savingData = true;
      if (this.watchlistData.type == "NEW" && this.selecteScrips.length == 0) {
        this.toastProvider.showAtBottom("You have to add at least one scrip to save your watchlist!")
        this.savingData = false;
        return;
      }
      let watclistObj: any = {};
      watclistObj.name = this.watchlistData.type == "NEW" ? this.watchlistData.name : this.watchlistData.profile.sWatchListName;
      watclistObj.scrip = this.selecteScrips;
      watclistObj.source = "WAVE";
      if (this.watchlistData.type == "NEW") {
        let statusUpdate = new BehaviorSubject("2");
        const modal = await this.modalController.create({
          component: WatchlistloaderPage,
          //cssClass: 'my-custom-class',
          componentProps: {
            'status': statusUpdate,
          }
        });
        await modal.present();
        statusUpdate.next("2");

        setTimeout(() => {
          let watchProfile = {
            nWatchListId: (Math.floor(Math.random() * 100) + 1),
            sWatchListName: this.watchlistData.name,
            bIsPrivate: true,//"false",
            bIsDefault: false,//"false",
            sCreatedBy: clsGlobal.User.userId,
            nTenantId: clsGlobal.ComId
          };

          this.watchlistServ.addNewWatchlist(watchProfile).then((data) => {

            let watchScrip = [];
            for (let index = 0; index < this.selecteScrips.length; index++) {
              const element = this.selecteScrips[index];
              watchScrip.push({
                nWatchListId: watchProfile.nWatchListId,
                nMarketSegmentId: element.MktSegId,
                nToken: element.Token,
                nSequenceNo: element.SeqNo
              })
            }

            this.watchlistServ.addWatchlistScrip(watchProfile, watchScrip).then((data) => {
              statusUpdate.next("1");
              setTimeout(() => {
                modal.dismiss().then(value => {
                  clsGlobal.reloadWatchlist = true;
                  clsGlobal.userSelectedWatchlist = watchProfile;
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                });
              }, 1000);
            });
          }, (error) => {
          });
        }, 1000);

      }
      else if (this.watchlistData.type == "UPDATE") {

        let updatedScrip = this.selecteScrips.filter(item => {
          return item.isNew == undefined;
        });
        //For in case of add in saved profile. 
        if (updatedScrip.length == 0 && this.deletedScrips.length == 0) return;


        let statusUpdate = new BehaviorSubject("4");
        const modal = await this.modalController.create({
          component: WatchlistloaderPage,
          //cssClass: 'my-custom-class',
          componentProps: {
            'status': statusUpdate,
          }
        });
        await modal.present();
        statusUpdate.next("4");

        setTimeout(async () => {

          watclistObj.scrip = updatedScrip;
          watclistObj.profileId = this.watchlistData.profile.nWatchListId;

          let watchScrip = [];
          for (let index = 0; index < updatedScrip.length; index++) {
            const element = updatedScrip[index];
            watchScrip.push({
              nWatchListId: this.watchlistData.profile.nWatchListId,
              nMarketSegmentId: element.MktSegId,
              nToken: element.Token,
              nSequenceNo: element.SeqNo
            })
          }

          if (watchScrip.length > 0) {

            this.watchlistServ.addWatchlistScrip(this.watchlistData.profile, watchScrip).then(async (data) => {
              //this.toastProvider.showAtBottom("Scrip(s) added.");
              //clsGlobal.reloadWatchlist = true;
              //this.navCtrl.navigateBack
              //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
              if (this.deletedScrips.length > 0) {
                await this.deleteScrip();
              }
              statusUpdate.next("1");
              setTimeout(() => {
                modal.dismiss().then(value => {
                  clsGlobal.reloadWatchlist = true;
                  //clsGlobal.userSelectedWatchlist = watchProfile;
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                });
              }, 1000);

            });

          } else if (this.deletedScrips.length > 0) {

            await this.deleteScrip();
            statusUpdate.next("1");
              setTimeout(() => {
                modal.dismiss().then(value => {
                  clsGlobal.reloadWatchlist = true;
                  //clsGlobal.userSelectedWatchlist = watchProfile;
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                });
              }, 1000);
          }

        }, 1000);
        // this.watchlistServ.updateWatchlistScrip(watclistObj).then((data) => {
        //   this.toastProvider.showAtBottom("Scrip(s) added.");
        //   clsGlobal.reloadWatchlist = true;
        //   //this.navCtrl.navigateBack
        //   this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
        // }, (error) => {
        // });
      }
    } catch (error) {
      this.savingData = false;
      //clsGlobal.logManager.writeErrorLog("lookup", "saveWatchlist", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'saveWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async deleteScrip() {
    try {

      let deletedScrip = [];
      for (let index = 0; index < this.deletedScrips.length; index++) {

        const element = this.deletedScrips[index];
        deletedScrip.push({
          nWatchListId: this.watchlistData.profile.nWatchListId,
          //nMarketSegmentId: clsTradingMethods.getMappedMarketSegmentId(element.MktSegId),
          nMarketSegmentId: element.MktSegId,
          nToken: element.Token,
          nSequenceNo: element.SeqNo,
          sCreatedBy: this.watchlistData.profile.sCreatedBy
        })
      }

      await this.watchlistServ.deleteWatchlistScrip(deletedScrip);

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'deleteScrip',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
  * @method : load recent searched scrip from local storage
  */
  loadRecentScripts() {
    try {
      this.localstorageservice.getItem(clsGlobal.User.userId + '_recentlySearchedScrip')
        .then((res: any) => {
          if (res != null && res != undefined) {
            this.recentlySearchedScrip = res;
            this.recentlySearched = true;
          }
          else {
            this.recentlySearchedScrip = [];
            this.recentlySearched = false;
          }
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("lookup", "loadRecentScripts", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'loadRecentScripts',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  async getHotpursuitData() {
    try {
      if (this.trendingScrips.length <= 0) {
        let requestString = clsGlobal.LocalComId + clsGlobal.versionId + "/" + this.hotPursuitCount + "/"
        await this.objCDSService.getHotPursuit(requestString).then((data: any) => {
          try {
            this.trendingScrips = [];
            if (data.ResponseObject.type != undefined && data.ResponseObject.type.toString().toUpperCase() == "SUCCESS" && data.ResponseObject.resultset.length > 0) {
              this.showTrending = true;
              let trendingScrip: any = {};
              for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
                let element = data.ResponseObject.resultset[index];
                let Symbol: string = "", token: string = "", mktSegId: number;
                if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
                  Symbol = element.ScripData_NSE.Symbol.trim();
                  token = element.ScripData_NSE.ODINCode;
                  mktSegId = element.ScripData_NSE.MarketSegmentId;
                }
                else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
                  Symbol = element.ScripData_BSE.Symbol.trim();
                  token = element.ScripData_BSE.ODINCode;
                  mktSegId = element.ScripData_BSE.MarketSegmentId;
                }
                else {
                  continue;
                }
                trendingScrip = {};
                trendingScrip.symbol = Symbol;
                this.trendingScrips.push(Symbol);
              }
              console.log(this.trendingScrips);
            }
          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getHotpursuitData1',error.Message,undefined,error.stack,undefined,undefined));
          }
        }).catch(error => {
          //clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getHotpursuitData2',error.Message,undefined,error.stack,undefined,undefined));
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getHotpursuitData3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  doInfinite(event) {
    try {
      setTimeout(() => {
        event.target.complete();
        this.infiniteScroll = event;
        this.fetchDetails();
      }, 500);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('LookupPage', 'doInfinite', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  fetchDetails() {
    try {
      this.recordFrom = this.recordFrom + 25;
      this.recordTo = this.recordTo + 25 >= this.lookupGlobalData.length ? this.lookupGlobalData.length : this.recordTo + 25;
      this.lookupEquityData = [];
      this.lookupFutData = [];
      for (let i = this.recordFrom; i < this.recordTo; i++) {
        this.lookupData.push(this.lookupGlobalData[i]);
      }
      this.lookupEquityData = this.lookupData.filter(x => x._source.sInstrumentName == 'EQUITIES')
      let distinctAssetToken = this.getDistinctAssetToken(this.lookupData);
      for (let i = 0; i < distinctAssetToken.length; i++) {
        let futData = this.lookupData.filter(x => x._source.nAssetToken == distinctAssetToken[i] && x._source.sInstrumentName.startsWith("FUT") && x._source.nSpread == 0)
        let futDataspread = this.lookupData.filter(x => x._source.nAssetToken == distinctAssetToken[i] && x._source.sInstrumentName.startsWith("FUT") && x._source.nSpread == 1)
        if (futData.length > 0) {
          let element = {
            sSymbol: futData[0]._source.sSymbol,
            sExchange: futData[0]._source.sExchange,
            sDerivitiveDesc: futData[0]._source.sDerivitiveDesc,
            nMarketSegmentId: 1,
            nToken: futData[0]._source.nAssetToken,
            spreadContract: false
          }
          this.lookupFutData.push({ "futData": futData, element })
        }

        if (futDataspread.length > 0) {
          let element = {
            sSymbol: futDataspread[0]._source.sSymbol,
            sExchange: futDataspread[0]._source.sExchange,
            sDerivitiveDesc: futDataspread[0]._source.sDerivitiveDesc,
            nMarketSegmentId: 1,
            nToken: futDataspread[0]._source.nAssetToken,
            spreadContract: true
          }
          this.lookupFutData.push({ "futData": futDataspread, element })
        }
      }
      if (this.recordTo >= this.lookupGlobalData.length) {
        this.loadMoreData = false;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('LookupPage', 'fetchDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'fetchDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  watchListSelectionCloseEvent(event) {
    this.showWatchList = false;
  }
  showRecoFilter() {
    try {
      this.recoFilterPopup = !this.recoFilterPopup;
      this.showExpandedRecoFilter = true;
      //this.checkForRecoFilterPopupUpElementRendrer();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('RecommendationPage', 'showRecoFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'showRecoFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForRecoFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divRecoFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForRecoFilterPopupUpElementRendrer();
        }, 300);
      } else {

        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divRecoFilterPopup');
          this.recoFilterPopupBottomToTop(divElement);
        }, 200);
      }
    } catch (error) {
      console.log("Error + checkForRecoFilterPopupUpElementRendrer" + error);
      //clsGlobal.logManager.writeErrorLog('lookup', 'checkForRecoFilterPopupUpElementRendrer', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'checkForRecoFilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  recoFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (320), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        //dragBy: ['.pane .draggable'],
        initialBreak: 'top',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop: true, //added by om on 26 th jan for backdrop display.,
        onDidPresent: () => {
          //console.log("onDidPresent")
          setTimeout(() => {
            this.calcDivHeight();
          }, 1000);
        },
        onDrag: () => {
          //  //console.log("onDrag");
        },
        onDragEnd: () => {

          //console.log("onDragEnd");
          let topDiv = this.divRecoFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedRecoFilter = true;
          } else {
            this.showExpandedRecoFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.hideOptionChain();
        }
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends"); 
        //   //console.log("onTransitionEnd")
        // }
      }
      this.recoFilterPane = new CupertinoPane(myElementRef, setting);
      //this.recoFilterPane.enableDrag();
      this.recoFilterPane.disableDrag();
      this.recoFilterPane.present({ animate: true });
    } catch (error) {
      console.log("Error + recoFilterPopupBottomToTop" + error);
      //clsGlobal.logManager.writeErrorLog('lookup', 'recoFilterPopupBottomToTop', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'recoFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  scrollOptionChain(event) {
    try{
    if (event.target.scrollTop > 20 && !this.bIsScrollIntoViewProgress) {
      //this.recoFilterPane.moveToBreak('top');
      this.showExpandedRecoFilter = true;
    }
    if (this.divRecoFilter != undefined)
      this.divRecoFilter.nativeElement.scrollTop = 0;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'scrollOptionChain',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeOrderDetailsPopup() {
    this.recoFilterPopup = !this.recoFilterPopup;
    this.optionChainpopUp = false;
    //this.showExpandedOrderDetails = false;
    //this.showAddiionalOrderDetails = false;
    //this.recoFilterPane.destroy({ animate: true });
  }

  getRecommendation() {
    try {

      // this.recoData = clsGlobal.EventList.filter((elemnt) => {
      //   return elemnt.type == "Reco";
      // });
      //debugger;
      for (let index = 0; index < clsGlobal.EventList.length; index++) {
        if (clsGlobal.EventList[index].type == "Reco") {
          let recoExists = this.recoData.filter((existelement) => {
            return existelement.mktid == clsGlobal.EventList[index].mktid &&
              existelement.token == clsGlobal.EventList[index].token
              && existelement.event == "Reco";
          });
          if (recoExists.length == 0) {
            this.recoData.push(clsGlobal.EventList[index])
          }
        }
      }
      if (this.recoData.length == 0) {
        this.showRecommendations = false;
      }
      else {
        this.showRecommendations = true;
      }


    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('researchcall', 'getRecommendation_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'getRecommendation',error.Message,undefined,error.stack,undefined,undefined));
    }

  }
  checkVoiceString: any;
  ShowVoiceModel() {
    try{
    this.searchText = '';

    this.checkVoiceString = '';
    this.speechRecognition.isRecognitionAvailable().then((available: boolean) => {
      if (available) {
        this.speechRecognition.hasPermission()
          .then((hasPermission: boolean) => {
            if (hasPermission)
              this.VoiceStartListening();
            else {
              this.speechRecognition.requestPermission()
                .then(
                  () => {
                    console.log('Granted');
                    this.VoiceStartListening();
                  },
                  () => {
                    console.log('Denied');
                    this.toastProvider.showAtBottom("you need to give permission for voice.");
                  }
                )


            }
          });
      }
      else {
        this.toastProvider.showAtBottom("microphone not available.");
      }
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'ShowVoiceModel',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  VoiceStartListening() {
    try{
    if (this.platform.is('android')) {
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            this.searchVoiceText(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            console.log("Error" + onerror);
          }
        );
    }
    else {
      this.loadingCtrl.showLoaderforText();
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            //alert("String "+matches[0].toString())
            this.loadingCtrl.hideLoaderforText();
            this.checkVoiceString = matches[0].toString();
            this.searchVoiceText(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //alert("Error "+onerror)
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            this.loadingCtrl.hideLoaderforText();
            console.log("Error" + onerror);
          }
        );
      setTimeout(() => {
        this.loadingCtrl.hideLoaderforText();
        this.speechRecognition.stopListening();
        setTimeout(() => {
          if (this.checkVoiceString == '' || this.checkVoiceString == undefined) {
            this.toastProvider.showAtBottom("Voice not captured. Try saying something again")
          }
        }, 1000)
      }, 3000);
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'VoiceStartListening',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  searchVoiceText(text) {
    try{
    if (text != undefined || text != '') {
      this.searchText = text.toUpperCase().trim();
      alert("Search text call searchvoice method");
      this.searchTextChanged.next(this.searchText);
      this.recentlySearched = false;
      this.showTrending = false;
      this.showRecommendations = false;
    } else {
      this.loadRecentScripts();
      this.getHotpursuitData();
    }
  }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'searchVoiceText',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  VoiceHasPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        return hasPermission;
      });
  }

  voiceSearchMaching(text: any) {
    try{
    var _text = text.toString().toUpperCase().trim();
    _text = _text.replace("JANUARY", "JAN").
      replace("FEBRUARY", "FEB").
      replace("MARCH", "MAR").
      replace("APRIL", "APR").
      replace("JUNE", "JUN").
      replace("JULY", "JUL").
      replace("AUGUST", "AUG").
      replace("SEPTEMBER", "SEP").
      replace("OCTOBER", "OCT").
      replace("NOVEMBER", "NOV").
      replace("DECEMBER", "DEC").
      replace("FUTURES", "FUT").
      replace("FUTURE", "FUT").
      replace("OPTIONS", "OPT").
      replace("OPTION", "OPT");
    return _text.toUpperCase();
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'voiceSearchMaching',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  calcDivHeight() {

    try {

      if (this.divScrollOptionChain != undefined) {
        let topDiv = this.divScrollOptionChain.nativeElement.getBoundingClientRect().top;
        let eleFilter: any = document.getElementsByClassName('filter-sort-wrap')[0];
        this.divHeight = window.innerHeight - 201;
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'calcDivHeight', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'calcDivHeight',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  isScripAlreadyAdded(item) {
    try {
      //if (this.watchlistData != '' && this.watchlistData.type == 'UPDATE') {
      let scrip = item._source;
      let isScripExist = this.selecteScrips.filter(item => {
        return item.MktSegId == parseInt(scrip.nMarketSegmentId) && item.Token == scrip.nToken && item.isNew == false;
      });

      if (isScripExist.length == 0) {
        return false;
      }
      else {
        return true;
      }
      //}
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'isScripAlreadyAdded',error.Message,undefined,error.stack,undefined,undefined));
      return false;
    }
  }


  isNewScripAdded(item) {
    try {
      //if (this.watchlistData != '' && this.watchlistData.type == 'NEW') {
      let scrip = item._source;
      let isScripExist = this.selecteScrips.filter(item => {
        return item.MktSegId == parseInt(scrip.nMarketSegmentId) && item.Token == scrip.nToken && item.isNew == undefined;
      });

      if (isScripExist.length == 0) {
        return false;
      }
      else {
        return true;
      }
      //}
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'isNewScripAdded',error.Message,undefined,error.stack,undefined,undefined));
      return false;
    }
  }


  removeFromWatchList(item) {
    try {
      //if (this.watchlistData != '' && this.watchlistData.type == 'NEW') {
      let scrip = item._source;

      for (let index = 0; index < this.selecteScrips.length; index++) {
        const element = this.selecteScrips[index];
        //&& element.isNew == undefined
        if (element.MktSegId == parseInt(scrip.nMarketSegmentId) && element.Token == scrip.nToken) {

          let deleteItem = this.selecteScrips.splice(index, 1);
          if (element.isNew != undefined) {
            this.deletedScrips.push(deleteItem[0])
          }

          break;
        }
      }

      //}
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'removeFromWatchList',error.Message,undefined,error.stack,undefined,undefined));
      return false;
    }
  }

  addExpiryWiseStrikePrice(expiryDate) {
    try {
      let optionContract = [];
      let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      for (let i = 0; i < optCEData.length; i++) {
        let obj;
        optCEData[i].LTP = "0.00";
        optCEData[i].NetChangeInRs = "0.00";
        optCEData[i].PercNetChange = "0.00";
        optCEData[i].OI = "0.00";
        optCEData[i].PercOI = "0.00";
        optCEData[i].IV = "0";

        optPEData[i].LTP = "0.00";
        optPEData[i].NetChangeInRs = "0.00";
        optPEData[i].PercNetChange = "0.00";
        optPEData[i].OI = "0.00";
        optPEData[i].PercOI = "0.00";
        optPEData[i].IV = "0";

        let ceData = optCEData[i]
        let peData = optPEData[i]
        obj = { "ceData": ceData, "peData": peData }
        optionContract.push(obj);
      }
      this.dcExpiryWiseStrikePrice.Add(expiryDate, optionContract);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('LookupPage', 'addExpiryWiseStrikePrice',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
