import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CalculatorLookupPage } from './calculator-lookup.page';

const routes: Routes = [
  {
    path: '',
    component: CalculatorLookupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CalculatorLookupPageRoutingModule {}
