import { Component, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { NavController, Platform } from '@ionic/angular';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-calculator-lookup',
  templateUrl: './calculator-lookup.page.html',
  styleUrls: ['./calculator-lookup.page.scss'],
})
export class CalculatorLookupPage implements OnInit {
  @ViewChild('inputId',{static : false}) inputId : { setFocus: () => void;};
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = '';
  lookupData: any = [];
  bcastHandler : any;
  lstScripKey: any = [];
  showHide : boolean = true;
  showTrending: boolean = false;
  instrument : any;
  futureOption : boolean = false;
  initialbuymargin: any;
  initialsellmargin: any;
  totalbuymargin: any;
  totalsellmargin: any;
  exposurebuymargin: any;
  exposuresellmargin: any;
  PriceFactor :any;
  marketlot :any;
  showcalculation : boolean = false;
  expiryDate : any;
  symbol : any;
  month : any;
  count : any = 0;
  noDataFound : boolean = false;
  hotPursuitCount: number;
  recentlySearched: boolean = false;
  recentlySearchedScrip: any = [];
  trendingScrips:any = [];
  showLoadersearch : boolean = false;
  constructor(public http: clsHttpService,
    private navCtrl: NavController,
    public alertCtrl: AlertServicesProvider,
    public platform: Platform,
    public loadingCtrl: LoaderServicesProvider,
    public speechRecognition: SpeechRecognition,
    public toastProvider: ToastServicesProvider,
    private dbService: DatabaseService,private localstorageservice: clsLocalStorageService,
    private objCDSService: CDSServicesProvider) { }

  ngOnInit() {
    try {
      if(clsGlobal.User.CalculatorType.toUpperCase() == 'FUTURE')
      {
        this.instrument = '';
      }
      else if(clsGlobal.User.CalculatorType.toUpperCase() == 'OPTION')
      {
        this.instrument = '';
      }
      else if(clsGlobal.User.CalculatorType.toUpperCase() == 'SPANMARGIN')
      {
        this.instrument = 'FUT';
      }
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.hotPursuitCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_HOTPURSUIT_SCRIP_COUNT)) || 10;
      //distinctUntilChanged()
      this.subscription = this.searchTextChanged.pipe(debounceTime(500)  
      ).subscribe(search => this.getValues(search)); 
      this.loadRecentScripts();
      this.getHotpursuitData();     
    } catch (error) {
      console.log(error);
    }
  }

  ionViewDidEnter(){
    this.setFocusOnInput();
  }

  setFocusOnInput(){
    this.inputId.setFocus();
  }

  goBack() {
    this.navCtrl.pop();
  }

  search($event) {
    if ($event) {
      this.searchText =  $event.toUpperCase().trim();
      //this.searchText.toUpperCase().trim();
      this.searchTextChanged.next(this.searchText);
      this.recentlySearched = false;
      this.showTrending = false;
    } else {
      this.noDataFound = false;
      this.futureOption = false;
      this.showHide = true;
      this.loadRecentScripts();
      this.getHotpursuitData();
      //numericDir [allowDecimals]="true"
    }
  }
/**
  * @method : load recent searched scrip from local storage
  */
  loadRecentScripts() {
    try {
      this.localstorageservice.getItem(clsGlobal.User.userId + '_recentlySearchedScripCalculator')
        .then((res: any) => {
          if (res != null && res != undefined) {
            this.recentlySearchedScrip = res;
            this.recentlySearched = true;
          }
          else {
            this.recentlySearchedScrip = [];
            this.recentlySearched = false;
          }
        });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("lookup", "loadRecentScripts", error.message);
    }
  }

  async getHotpursuitData() {
    try {
      if (this.trendingScrips.length <= 0) {
        let requestString = clsGlobal.LocalComId + clsGlobal.versionId + "/" + this.hotPursuitCount + "/"
        await this.objCDSService.getHotPursuit(requestString).then((data: any) => {
          try {
            if (data.ResponseObject.type != undefined && data.ResponseObject.type.toString().toUpperCase() == "SUCCESS" && data.ResponseObject.resultset.length > 0) {
              this.showTrending = true;
              let trendingScrip: any = {};
              for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
                let element = data.ResponseObject.resultset[index];
                let Symbol: string = "", token: string = "", mktSegId: number;
                if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
                  Symbol = element.ScripData_NSE.Symbol.trim();
                  token = element.ScripData_NSE.ODINCode;
                  mktSegId = element.ScripData_NSE.MarketSegmentId;
                }
                else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
                  Symbol = element.ScripData_BSE.Symbol.trim();
                  token = element.ScripData_BSE.ODINCode;
                  mktSegId = element.ScripData_BSE.MarketSegmentId;
                }
                else {
                  continue;
                }
                trendingScrip = {};
                trendingScrip.symbol = Symbol;
                this.trendingScrips.push(Symbol);
              }
              console.log(this.trendingScrips);
            }
          } catch (error) {
            clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData1', error);
          }
        }).catch(error => {
          clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData2', error);
        });
      }
      else
      {
        this.showTrending = true;
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('LookupPage', 'getHotpursuitData3', error);
    }
  }

  lookupGlobalData: any = [];
  /** <Norwin Dcruz> <05/01/2021> <To get search values> **/
  async getValues(search) {
    try {
      if (search.length < 2) {
        this.searchTextEntered = '';
        this.lookupData = [];
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      this.lookupData = [];
      this.noDataFound = false;
      this.showLoadersearch = true;
      this.recordFrom = 0;
      this.recordTo = 25;
      let _viewAllowed=clsGlobal.User.viewAllowed || -1;
      await this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId +"/getScripLookUp/", this.searchTextEntered+'%20'+this.instrument+ "/"+_viewAllowed)
        .subscribe(data => {
          try {
            if(clsGlobal.User.CalculatorType.toUpperCase() == 'SPANMARGIN')
            {
              this.futureOption = true;
            }
            this.showLoadersearch = false;
            let _response: any = data
            this.lookupGlobalData = _response.result.hits.hits;
            this.recordTo = this.recordTo >= this.lookupGlobalData.length ? this.lookupGlobalData.length : this.recordTo;
            if (this.lookupGlobalData.length > 0) {
              this.lstScripKey = [];
             
              for(let count = this.recordFrom; count < this.recordTo; count++)
              {
                if(this.lookupGlobalData[count]._source.nSpread != 1)
                {
                  this.lookupData.push(this.lookupGlobalData[count]);
                }
              }
              for (let i = 0; i < this.lookupData.length; i++) {
                if(this.lookupData[i]._source.nExpiryDate1 != "" && this.lookupData[i]._source.nExpiryDate1 != undefined)
                {
                  this.lookupData[i]._source.Date = new Date(this.lookupData[i]._source.nExpiryDate1).getDate()+' '+(new Date(this.lookupData[i]._source.nExpiryDate1).toLocaleString('default',{month : 'short'})).toUpperCase();
                }
                else
                {
                  this.lookupData[i]._source.Date = "";
                }
                this.lookupData[i]._source.nMarketSegmentId =  clsTradingMethods.GetMarketSegmentID(this.lookupData[i]._source.nMarketSegmentId);
                this.lookupData[i]._source.sInstrumentName = (this.lookupData[i]._source.sInstrumentName == 'EQUITIES' ? '' : this.lookupData[i]._source.sInstrumentName);
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = this.lookupData[i]._source.nToken;
                objScrpKey.MktSegId = this.lookupData[i]._source.nMarketSegmentId;
                this.lstScripKey.push(objScrpKey);
              }
              this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
              this.showHide = false;
              this.noDataFound = false;

              if (this.recordTo >= this.lookupGlobalData.length) {
                this.loadMoreData = false;
              }
              else
              {
                this.loadMoreData = true;
              }
            }
            else
            {
              this.showHide = false;
              this.noDataFound = true;
            }            
          } catch (error) {
            console.log(error);
          }
        }, error => {
          clsGlobal.logManager.writeErrorLog('CalculatorLookupPage', 'getValues', error);
          console.log(error);
          this.showHide = false;
          this.noDataFound = true;
          this.showLoadersearch = false;
        });
    } catch (error) {
      console.log(error)
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To select scrip and pop to previous page> **/
  scripClick(scripobj) {
    try {
      if(clsGlobal.User.CalculatorType.toUpperCase() == 'SPANMARGIN')
      {
        this.calculateSpanMargin(scripobj)
      }
      else
      {
        if(this.count == 0)
        {
          this.count++;
          if (this.recentlySearchedScrip.filter(x => (x._source.sSymbol == scripobj._source.sSymbol)).length <= 0) {
            if (this.recentlySearchedScrip.length >= 5) {
              this.recentlySearchedScrip.pop();
              this.recentlySearchedScrip.unshift(scripobj);
            }
            else {
              this.recentlySearchedScrip.unshift(scripobj);
            }
            this.localstorageservice.setItem(clsGlobal.User.userId + '_recentlySearchedScripCalculator', this.recentlySearchedScrip);
          }
          clsGlobal.User.selectedScrip = scripobj;
          clsGlobal.User.searchScrip = true;
          for(let count = 0; count < this.lookupData.length; count++){
            if(clsGlobal.User.CalculatorType.toUpperCase() == 'FUTURE'){
              clsGlobal.User.selectedArray = this.lookupData.filter(x => x._source.sSymbol.trim() == clsGlobal.User.selectedScrip._source.sSymbol.trim() && x._source.sExchange.trim() == clsGlobal.User.selectedScrip._source.sExchange.trim());
            }
            else if(clsGlobal.User.CalculatorType.toUpperCase() == 'OPTION'){
              clsGlobal.User.selectedArray = this.lookupData.filter(x => x._source.sSymbol.trim() == clsGlobal.User.selectedScrip._source.sSymbol.trim() && x._source.sExchange.trim() == clsGlobal.User.selectedScrip._source.sExchange.trim());
            }
          }      
          this.navCtrl.pop();
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  /** <Norwin Dcruz> <09/01/2021> <To change segment from future or options for span margin> **/
  segmentChanged(event){
    this.instrument = event.detail.value;
    if (clsGlobal.User.CalculatorType.toUpperCase() != 'OPTION') {
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
    }
    this.getValues(this.searchTextEntered)
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
        for (let i = 0; i < this.lookupData.length; i++) {
          if (this.lookupData != undefined &&
            this.lookupData[i]._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.lookupData[i]._source.nToken == objMultiTLResp.Scrip.token) {
            this.lookupData[i]._source.LTP = objMultiTLResp.LTP;
            break;
          }
        }
      
    }
    catch (error) {
      console.log(error);
    }
  }

  closeSpanmargin(){
    this.showcalculation = false;
  }

  /** <Norwin Dcruz> <09/01/2021> <To calculate span margin> **/
  calculateSpanMargin(item){
    try {
      let mapmarketsegmentid = clsTradingMethods.getMappedMarketSegmentId(item._source.nMarketSegmentId);
      let token = item._source.nToken;
      let dateformat = new Date(item._source.nExpiryDate1);
      let sDate = dateformat.getDate();
      let sMonth = (dateformat.toLocaleString('default',{month : 'short'})).toUpperCase();
      let nYear = dateformat.getFullYear().toString().substr(-2);
      this.expiryDate = sDate+' '+sMonth+' '+"'"+nYear;
      this.symbol = item._source.sSymbol;
      this.month = sMonth;
      let LTP = (item._source.LTP == '' || item._source.LTP == undefined) ? 0.00 : item._source.LTP;
      this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId, "/getSpanMargin/" + mapmarketsegmentid + "/" + token)
      .subscribe(respData => {
        try {
          let resposeAbtUs: any = respData;
          //this.refresher.complete();
          //let resposeAbtUs = respData;
          if (resposeAbtUs.status) {
            if (resposeAbtUs.result.length > 0) {
              let precision = clsTradingMethods.GetPriceFormatter(item._source.DecimalLocator,item._source.nMarketSegmentId,item._source.sInstrumentName);
              this.initialbuymargin = resposeAbtUs.result[0]["Initial Margin Long"].toFixed(precision);
              this.initialsellmargin = resposeAbtUs.result[0]["Initial Margin Short"].toFixed(precision);
              //this.exposurebuymargin = resposeAbtUs.result[0].InitialMarginShort.toFixed(precision);
              if (resposeAbtUs.result[0]["Special Long Margin"] != undefined)
               {//Code Comment : for all Exchanges
                this.exposurebuymargin = parseFloat(resposeAbtUs.result[0]["Special Long Margin"]).toFixed(precision);
                this.exposuresellmargin = parseFloat(resposeAbtUs.result[0]["Special Short Margin"]).toFixed(precision);
               }
              else if (resposeAbtUs.result[0]["Exposure Margin"] != undefined)
              {//Code Comment : for perticular 4 Exchanges
                this.exposurebuymargin = parseFloat(resposeAbtUs.result[0]["Exposure Margin"]).toFixed(precision);
                this.exposuresellmargin = parseFloat(resposeAbtUs.result[0]["Exposure Margin"]).toFixed(precision);
  
              }
              //Code Comment : Only for NCDEX
              else if (resposeAbtUs.result[0]["Market Segment"] == clsConstants.C_S_NCDEX_EXCHANGE_TEXT)
              {
                this.exposurebuymargin = parseFloat(resposeAbtUs.result[0]["Exposure/ Special Margin Long"]).toFixed(precision);
                this.exposuresellmargin = parseFloat(resposeAbtUs.result[0]["Exposure/ Special Margin Short"]).toFixed(precision);
              }
              this.totalbuymargin = resposeAbtUs.result[0]["Total Margin Long"].toFixed(precision);
              this.totalsellmargin = resposeAbtUs.result[0]["Total Margin Short"].toFixed(precision);
              this.PriceFactor = resposeAbtUs.result[0]["CVF"].toFixed(precision);
              this.marketlot = resposeAbtUs.result[0]["Lot Size"];
  
              if(resposeAbtUs.result[0]["Instrument Type"].substring(0,3) == clsConstants.C_S_INSTRUMENT_OPT)
              {
                let InitialMarginLongValue : any;
                InitialMarginLongValue = parseFloat(LTP) * parseFloat(this.marketlot) * parseFloat(this.PriceFactor);
                this.initialbuymargin = parseFloat(InitialMarginLongValue).toFixed(precision);
                //Code Comment : In case of OPTION Contract, ExposureMarginLong will be '0'.
                this.exposurebuymargin = parseFloat('0').toFixed(precision);
                // //Code Comment : Formula : InitialMarginLong + ExposureMarginLong.
                this.totalbuymargin = parseFloat(this.initialbuymargin + this.exposurebuymargin).toFixed(precision);
              }
              this.showcalculation = true;
            }
            else {
              this.alertCtrl.showAlert("No data Found for the given scrip. Kindly try again later");
            }
          }
          else {
            this.alertCtrl.showAlert(clsConstants.RESPONSE_MSG);
          }
        } catch (error) {
          console.log(error);
        } finally {
          //this.showLoader = false;
        }
      }, error => {
        clsGlobal.logManager.writeErrorLog('CalculatorLookupPage', 'calculateSpanMargin', error);
      });      
    } catch (error) {
      console.log(error);
    }
  }

  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
      if (clsGlobal.User.CalculatorType.toUpperCase() != 'OPTION') {
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      }
    } catch (error) {
      console.log("Error in ionViewWillLeave " + error);
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('CalculatorLookupPage', 'sendTouchlineRequest', error);
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To clear search fields and variables> **/
  clearSearch() {
    try {
      this.searchText = "";
      if(clsGlobal.User.CalculatorType.toUpperCase() == 'FUTURE')
      {
        this.instrument = '';
      }
      else if(clsGlobal.User.CalculatorType.toUpperCase() == 'OPTION')
      {
        this.instrument = '';
      }
      else if(clsGlobal.User.CalculatorType.toUpperCase() == 'SPANMARGIN')
      {
        this.instrument = 'FUT';
      }
      this.showHide = true;
      this.noDataFound = false;
      this.lookupData = [];
      this.futureOption = false;
      this.initialbuymargin = '';
      this.initialsellmargin = '';
      this.totalbuymargin = '';
      this.totalsellmargin = '';
      this.exposurebuymargin = '';
      this.exposuresellmargin = '';
      this.PriceFactor = '';
      this.marketlot = '';
      this.showcalculation = false;
      this.expiryDate = '';
      this.symbol = '';
      this.month = '';    
        

      if(this.trendingScrips.length > 0)
      {
        this.showTrending = true;
      }
      else
      {
        this.showTrending = false;
      }

      if(this.recentlySearchedScrip.length > 0)
      {
        this.recentlySearched = true; 
      }
      else
      {
        this.recentlySearched = false; 
      }
       
    } catch (error) {
      console.log(error);
    }  
  }



  checkVoiceString: any;
  ShowVoiceModel() {
    this.searchText = '';

    this.checkVoiceString = '';
    this.speechRecognition.isRecognitionAvailable().then((available: boolean) => {
      if (available) {
        this.speechRecognition.hasPermission()
          .then((hasPermission: boolean) => {
            if (hasPermission)
              this.VoiceStartListening();
            else {
              this.speechRecognition.requestPermission()
                .then(
                  () => {
                    console.log('Granted');
                    this.VoiceStartListening();
                  },
                  () => {
                    console.log('Denied');
                    this.toastProvider.showAtBottom("you need to give permission for voice.");
                  }
                )


            }
          });
      }
      else {
        this.toastProvider.showAtBottom("microphone not available.");
      }
    });
  }

  VoiceStartListening() {
    if (this.platform.is('android')) {
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            this.search(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            console.log("Error" + onerror);
          }
        );
    }
    else {
      this.loadingCtrl.showLoaderforText();
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            //alert("String "+matches[0].toString())
            this.loadingCtrl.hideLoaderforText();
            this.checkVoiceString = matches[0].toString();
            this.search(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //alert("Error "+onerror)
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            this.loadingCtrl.hideLoaderforText();
            console.log("Error" + onerror);
          }
        );
      setTimeout(() => {
        this.loadingCtrl.hideLoaderforText();
        this.speechRecognition.stopListening();
        setTimeout(() => {
          if (this.checkVoiceString == '' || this.checkVoiceString == undefined) {
            this.toastProvider.showAtBottom("Voice not captured. Try saying something again")
          }
        }, 1000)
      }, 3000);
    }

  }

  // searchVoiceText(text) {
  //   if (text != undefined || text != '') {
  //     this.searchText = text.toUpperCase().trim();
  //     this.searchTextChanged.next(this.searchText);
  //     this.recentlySearched = false;
  //     this.showTrending = false;
  //     this.showRecommendations = false;
  //   } else {
  //     this.loadRecentScripts();
  //     this.getHotpursuitData();
  //   }
  // }
  VoiceHasPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        return hasPermission;
      });
  }

  voiceSearchMaching(text: any) {
    var _text = text.toString().toUpperCase().trim();
    _text = _text.replace("JANUARY", "JAN").
      replace("FEBRUARY", "FEB").
      replace("MARCH", "MAR").
      replace("APRIL", "APR").
      replace("JUNE", "JUN").
      replace("JULY", "JUL").
      replace("AUGUST", "AUG").
      replace("SEPTEMBER", "SEP").
      replace("OCTOBER", "OCT").
      replace("NOVEMBER", "NOV").
      replace("DECEMBER", "DEC").
      replace("FUTURES", "FUT").
      replace("FUTURE", "FUT").
      replace("OPTIONS", "OPT").
      replace("OPTION", "OPT");
    return _text.toUpperCase();
  }

  loadMoreData: boolean = true;
  infiniteScroll: any;
  recordFrom: number = 0;
  recordTo: number = 25;

  doInfinite(event) {
    try {
      setTimeout(() => {
        event.target.complete();
        this.infiniteScroll = event;
        this.fetchDetails();
      }, 500);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('LookupPage', 'doInfinite', error);
    }
  }


  fetchDetails() {
    try {
      this.recordFrom = this.recordFrom + 25;
      this.recordTo = this.recordTo + 25 >= this.lookupGlobalData.length ? this.lookupGlobalData.length : this.recordTo + 25;
     
      for (let i = this.recordFrom; i < this.recordTo; i++) {
        this.lookupData.push(this.lookupGlobalData[i]);
      }  
      
      for (let i = 0; i < this.lookupData.length; i++) {
        if(this.lookupData[i]._source.nExpiryDate1 != "" && this.lookupData[i]._source.nExpiryDate1 != undefined)
        {
          this.lookupData[i]._source.Date = new Date(this.lookupData[i]._source.nExpiryDate1).getDate()+' '+(new Date(this.lookupData[i]._source.nExpiryDate1).toLocaleString('default',{month : 'short'})).toUpperCase();
        }
        else
        {
          this.lookupData[i]._source.Date = "";
        }        
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('LookupPage', 'fetchDetails', error);
    }
  }

}
