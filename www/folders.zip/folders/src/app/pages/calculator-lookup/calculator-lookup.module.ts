import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CalculatorLookupPageRoutingModule } from './calculator-lookup-routing.module';

import { CalculatorLookupPage } from './calculator-lookup.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CalculatorLookupPageRoutingModule
  ],
  declarations: [CalculatorLookupPage]
})
export class CalculatorLookupPageModule {}
