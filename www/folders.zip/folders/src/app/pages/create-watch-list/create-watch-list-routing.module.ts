import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateWatchListPage } from './create-watch-list.page';

const routes: Routes = [
  {
    path: '',
    component: CreateWatchListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateWatchListPageRoutingModule {}
