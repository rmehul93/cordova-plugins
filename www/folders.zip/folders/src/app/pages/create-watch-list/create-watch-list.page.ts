import { NavController, PopoverController, MenuController } from '@ionic/angular';
//import { Content, Navbar} from "ionic-angular"
import { Component, OnInit } from '@angular/core';
import { clsHttpService } from "src/app/Common/clsHTTPService";
import { HttpClient } from "@angular/common/http";
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { clsConstants } from 'src/app/Common/clsConstants';
import { NavigationExtras } from '@angular/router';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';

@Component({
  selector: 'app-create-watch-list',
  templateUrl: './create-watch-list.page.html',
  styleUrls: ['./create-watch-list.page.scss'],
})
export class CreateWatchListPage implements OnInit {

  IsWatchListExist: boolean = true;
  showInitLoader = true;
  profileList = [];
  profileName = "";

  constructor(private navCtrl: NavController,
    private objHttpService: clsHttpService,
    private http: HttpClient,
    private menuCtrl: MenuController,
    private paramService: NavParamService,
    private localstorageservice: clsLocalStorageService,
    public popoverController: PopoverController,
    public toastProvider: ToastServicesProvider,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService) {

  }

  ngOnInit() {
    try {
      // this.localstorageservice.getItem('global_profile').then(profile => {
      //   if (profile != undefined) {
      //     this.profileList = JSON.parse(profile);

      //   } else {
      //     //clsGlobal.VirtualDirectory
      //     this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsConstants.NONTRANSACTIONAL + clsConstants.C_S_API_GLOBAL_PROFILE_LIST).subscribe((respProfile: any) => {

      //       try {
      //         if (respProfile.status == "success") {
      //           //console.log('ProfileList: ' + respProfile.data[0]);
      //           this.profileList = respProfile.data[0];
      //           this.localstorageservice.setObject('global_profile', respProfile.data[0]);
      //         } else {

      //           this.toastProvider.showWithButtonDismissOnPageChange(respProfile.errorString);
      //         }
      //       } catch (error) {

      //         clsGlobal.logManager.writeErrorLog("watchlist", "ngOnInit", error);
      //       }
      //     },
      //       (error: any) => {

      //       });
      //   }
      // });

      this.watchlistServ.getGlobalWatchlistProfile().then((dataProfile: any) => {
        this.profileList = [];
        for (let index = 0; index < dataProfile.length; index++) {
          const element = dataProfile[index];

          let watchProfile = {
            nWatchListId: element.nWatchListId,
            sWatchListName: element.sWatchListName,
            bIsPrivate: element.bIsPrivate,//"false",
            bIsDefault: element.bIsDefault,//"false",
            sCreatedBy: element.sUserId,
            nTenantId: element.sTenantId
          };
          this.profileList.push(watchProfile);

        }
        //this.profileList = dataProfile.data[0];
      })
    } catch (error) {
      console.log(error);
    }
  }

  copyWatchlist(profile) {
    try {
      //console.log(profile);
      this.createFromGlobalWatchlist(profile);
    } catch (error) {
      console.log(error);
    }
  }

  createFromGlobalWatchlist(profileItem) {
    try {
      this.watchlistServ.getWatchlistProfile().then((profList: any) => {

        let maxProfile = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10')
        if (profList != undefined && profList.length > maxProfile) {
          this.toastProvider.showAtBottom(" Watchlist limit reached! Try reviewing your watchlists!");
         // this.toastProvider.showAtBottom("Maximum " + maxProfile + " watchlists allowed.");
          return;
        }
  
        //this.showLoader = true;
  
        setTimeout(() => {
          let navParam: NavigationExtras = {
            queryParams: { profile: profileItem }
          };
          this.navCtrl.navigateForward('create-watch-list-global', navParam);
          //this.showLoader = false;
        }, 500);
  
  
      }, (error) => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  AddScripFromLookUp() {
    try {
      if (this.profileName == undefined || this.profileName == '') {
        this.toastProvider.showAtBottom("Name is required to create the watchlist");
        return;
      }
  
      this.watchlistServ.getWatchlistProfile().then((profList: any) => {
        //this.selecteScrips =  profScrip.rows;
        if (profList != undefined) {
  
          let isProfileExist = profList.filter(item => {
            return item.sWatchListName.toUpperCase() == this.profileName.toUpperCase() && (item.sUserId == clsGlobal.User.userId || item.sUserId == "CHIEF")
          });
  
          if (isProfileExist.length != 0) {
            this.toastProvider.showAtBottom("Looks like this watchlist already exists. Try using a different name.");
            return;
          }

          if (this.profileName == 'My Holdings' || this.profileName == "Don't Miss") {
            this.toastProvider.showAtBottom("Watchlist name cannot rename as system name.");
            return;
          }
  
        }
  
        let maxProfile = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10')
        if (profList != undefined && profList.length > maxProfile) {
          //this.toastProvider.showAtBottom("Maximum " + maxProfile + " watchlists allowed.");
          this.toastProvider.showAtBottom("Watchlist limit reached! Try reviewing your watchlists!");

          return;
        }
  
        //this.showLoader = true;
  
        setTimeout(() => {
          let navParam: NavigationExtras = {
            queryParams: { name: this.profileName, type: "NEW" }
          };
          this.navCtrl.navigateForward('lookup', navParam);
          //this.showLoader = false;
        }, 500);
  
  
      }, (error) => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  skip() {
    this.navCtrl.navigateRoot('watchlist');
  }

}
