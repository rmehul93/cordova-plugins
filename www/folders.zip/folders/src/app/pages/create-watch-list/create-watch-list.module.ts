import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateWatchListPageRoutingModule } from './create-watch-list-routing.module';

import { CreateWatchListPage } from './create-watch-list.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateWatchListPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [CreateWatchListPage]
})
export class CreateWatchListPageModule {}
