import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MenuController, NavController } from '@ionic/angular';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { SocketIoServiceService } from 'src/app/providers/socket-io-service.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.page.html',
})
export class PortfolioPage implements OnInit {
  showExpandHeader: boolean = false;
  portfolio: string = 'Holdings';

  showHoldingDetails: boolean = false;
  holdingData: any = [];
  filterHoldingData: any = [];
  holdingScripKeys: any = [];
  selectedHoldingItem: any = null;
  sortFilterPopupHolding: boolean = false;
  holdingsFilterObject: any = {}
  isHoldingsFilterApply = false;
  minDaysPandLHolding: any = 0;
  maxDaysPandLHolding: any = 0;
  minDaysPandLPerHolding: any = 0;
  maxDaysPandLPerHolding: any = 0;
  minOverallPandLHolding: any = 0;
  maxOverallPandLHolding: any = 0;
  minOverallPandLPerHolding: any = 0;
  maxOverallPandLPerHolding: any = 0;
  @ViewChild('divPositionFilter', { static: false }) divPositionFilter: ElementRef;
  showExpandedPositionFilter: boolean = false;
  showAditionalHoldingDetails: boolean = false;
  holdingFilterPane: any;

  searchTextHolding: string = "";
  searchTextChangedHolding = new Subject<string>();
  subscriptionHolding: any;
  searchTextEnteredHolding: string = "";
  holdingSearchData: any = [];
  holdingSearchScripKeys: any = [];
  showSearchHolding: boolean = false;
  holdingLoading: boolean = true;

  netPositionDataDaily: any = [];
  filterNetpositionDataDaily: any = [];
  netPositionScripKeysDaily: any = [];
  sumMTMDaily: any = 0.00;
  // sumMTMDailyPer: any = 0.00;
  mtmDataTrendDaily: string = '';

  netPositionDataExpiry: any = [];
  filterNetpositionDataExpiry: any = [];
  netPositionScripKeysExpiry: any = [];
  sumMTMExpiry: any = 0.00;
  // sumMTMExpiryPer: any = 0.00;
  mtmDataTrendExpiry: string = '';

  netPositionDataTempNonIntropExpiry: any = [];
  netPositionDataTempNonIntropDaily: any = [];
  netPositionDataTempIntropExpiry: any = [];
  netPositionDataTempIntropDaily: any = [];

  segmentList: any = [];
  selectedSegment: any;
  netpositionSelection: any = "daily";
  sortFilterPopupPosition: boolean = false;
  positionFilterObject: any = {};
  isPositionFilterApply = false;

  minDaysPandLPosition: any = 0;
  maxDaysPandLPosition: any = 0;
  @ViewChild('divHoldingFilter', { static: false }) divHoldingFilter: ElementRef;
  showExpandedHoldingFilter: boolean = false;
  positionFilterPane: any;


  searchTextPosition: string = "";
  searchTextChangedPosition = new Subject<string>();
  subscriptionPosition: any;
  searchTextEnteredPosition: string = "";
  positionSearchData: any = [];
  positionSearchScripKeys: any = [];
  showSearchPosition: boolean = false;

  netpositionDailyLoading = true;
  netpositionExpiryLoading = true;

  bcastHandler: any;
  numberortell: any = "tel";
  zeroVal: number = 0;
  pricePrecision: any = 2;

  trendingData: any = [];

  EventList: any = clsGlobal.EventList;

  sumCurrentMarketValue: any = 0.00;
  sumInvestedValue: any = 0.00;
  sumPandL: any = 0.00;
  sumPandLper: any = 0.00;
  sumTodaysPandL: any = 0.00;
  sumTodaysPandLPer: any = 0.00;

  showtickerCard: boolean = false;

  showPositionDetails: boolean = false;
  selectedNetPosition: any;

  showPositionConversition: boolean = false;
  productTypesByExchange: any = [];
  selProductType: any = "";

  allProductType: any = [];
  allExchangeList: any = [];

  isPositionConversionClick: boolean = false;
  isPositionConversionQtyEdit: boolean = false;
  selectedQtyforPositionConversion: number = 0;
  orderSubscription: any;

  showConfirmDialog: boolean = false;
  confirmDialogDataObj: any = {};

  isScripFetchForSquareOff: boolean = false;
  interopOnOffFlag: boolean = false;
  // added by sonali
  isGuestUser: boolean = false; 
  fundsValueInText: string; 
  totalPurchasingPower: any = 0;
  totalCash: any = 0;
  totalCollatral: any = 0;
  totalMargin: any = 0;
  totalBuyingPower: any = 0;
  periodicityWisefundsDetails: any = [];
  //productWisefundsDetails: any = [];
  @ViewChild('indiceTicker', { static: false }) elTicker: any;

  constructor(private menutCtrl: MenuController,
    private transactionService: TransactionService,
    private paramService: NavParamService,
    private toastServicesProvider: ToastServicesProvider,
    private objSocketService: SocketIoServiceService,
    private navCtrl: NavController,
    public http: clsHttpService) { }

  ngOnInit() {
    try {
      this.isGuestUser = clsGlobal.User.isGuestUser;
      this.menutCtrl.enable(true);
      this.subscriptionHolding = this.searchTextChangedHolding.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValuesHolding(search));

      this.subscriptionPosition = this.searchTextChangedPosition.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValuesPosition(search));


    } catch (error) {
       console.log("Error  ngOnInit " + error);
      // clsGlobal.logManager.writeErrorLog("PortfolioPage", "ngOnInit", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("PortfolioPage", "", "VISIT", "");
  }

  ionViewDidEnter() {
    try {
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      this.orderSubscription = this.objSocketService.getOrders().subscribe((data) => this.getOrderMeessage(data));
      this.getHoldingsData();
      this.getNetPositionData();
      this.checkForIndiceTicker();

      // added by sonali
      if (!clsGlobal.User.isGuestUser) {
        // if (clsGlobal.User.fundsDetails && clsGlobal.User.fundsDetails.periodicityWisefundsDetails) {
        //   this.periodicityWisefundsDetails = clsGlobal.User.fundsDetails.periodicityWisefundsDetails;
        //    //this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;
        //   this.calculateFunds();
        // } else {
        //   this.getBalanceInfo();
        // }
        if (clsGlobal.User.totalBuyingPower == undefined) {
          this.transactionService.getPurchasePower().then((purchasePower: any) => {
            clsGlobal.User.totalBuyingPower = purchasePower.data;
            this.totalPurchasingPower = purchasePower.data;
            this.kFormatter(this.totalPurchasingPower);
          }).catch(error => {
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
          });
        } else {
          this.totalPurchasingPower = clsGlobal.User.totalBuyingPower;
          this.kFormatter(this.totalPurchasingPower);
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "ionViewDidEnter", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.holdingScripKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysDaily);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysExpiry);
      this.sendTouchlineRequest(OperationType.REMOVE, this.holdingSearchScripKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.positionSearchData);
      this.elTicker.ionViewWillLeave();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "ionViewWillLeave", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  menuToggle() {
    try {
      this.menutCtrl.toggle();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "menuToggle", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'menuToggle',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  segmentChanged(evt) {
    try {
      this.portfolio = evt.detail.value.toString();
      if (this.portfolio == "Holdings") {

      }
      else if (this.portfolio == "Positions") {
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "segmentChanged", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'segmentChanged',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showFilterForHolding() {
    try {
      this.sortFilterPopupHolding = !this.sortFilterPopupHolding;
      this.checkForHoldingiilterPopupUpElementRendrer();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "showFilterForHolding", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'showFilterForHolding',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showFilterForNetposition() {
    try {
      this.sortFilterPopupPosition = !this.sortFilterPopupPosition;
      this.checkForPositionFilterPopupUpElementRendrer();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("PortfolioPage", "showFilterForNetposition", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'showFilterForNetposition',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  squareOffAllOrders() {
    try {
        if (this.netPositionDataTempNonIntropExpiry.filter((element: any) => { return element.net_quantity != 0 && element.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && element.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT }).length > 0) {
          this.paramService.myParam = this.netPositionDataTempNonIntropExpiry.filter((element: any) => { return element.net_quantity != 0 && element.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && element.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT });
          this.navCtrl.navigateForward('squareoff-orders');
        }
    } catch (error) {
     // clsGlobal.logManager.writeErrorLog("PortfolioPage", "squareOffAllOrders", error.message);
     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'squareOffAllOrders',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getHoldingsData() {
    try {
      this.transactionService.getHoldingsData().then((holdingsResponse: any) => {

        if (this.refresherInstanceHolding != undefined) {
          this.refresherInstanceHolding.target.complete();
        }
        if (holdingsResponse.status == 'Success') {
          this.holdingData = holdingsResponse.data;
          this.holdingData.forEach(holdingDataItem => {
              holdingDataItem.ltp = 0.00;
              holdingDataItem.closePrice = 0.00;
              holdingDataItem.PandL = 0.00;
              holdingDataItem.TodaysPandL = 0.00;
              holdingDataItem.CMV = 0.00;
              holdingDataItem.InvestedValue = 0.00;
              holdingDataItem.perPandL = 0.00;
              holdingDataItem.perTodaysPandL = 0.00;
              holdingDataItem.NetChangeInRs = 0.00;
              holdingDataItem.PercNetChange = 0.00;
              holdingDataItem.LTPTrend = '';
              holdingDataItem.arrowTrend = '';
          });

          this.holdingLoading = false;
          if (this.isHoldingsFilterApply) {
            this.clearHoldingFilter();
          } else {
            this.createHoldingData();
            this.createBroadcastForHolding();
          }

        }
      }, error => {
        this.holdingLoading = false;
        if (this.refresherInstanceHolding != undefined) {
          this.refresherInstanceHolding.target.complete();
        }
        //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getHoldingsData_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getHoldingsData_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.holdingLoading = false;
      if (this.refresherInstanceHolding != undefined) {
        this.refresherInstanceHolding.target.complete();
      }
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getHoldingsData_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getHoldingsData_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getHoldingDetailsData(holdingItem: any) {
    try {
      this.selectedHoldingItem = holdingItem;
      this.showHoldingDetails = true;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getHoldingDetailsData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getHoldingDetailsData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async getNetPositionData() {
    try {

      if (!clsGlobal.User.interopSettingDetails) {
        await this.transactionService.getIntropConfiguration().then((intropConfigResponse: any) => {
          if (intropConfigResponse.status == 'success') {
            clsGlobal.User.interopSettingDetails = intropConfigResponse.data;
            for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
              if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1) {
                this.interopOnOffFlag = true;
              }
            }
          } else {

          }
        }, error => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getNetPositionData',error.Message,undefined,error.stack,undefined,undefined));
        });
      } else {
        for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
          if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1) {
            this.interopOnOffFlag = true;
          }
        }
      }

      await this.transactionService.getNetPositionDaily(0).then((netpositionResponse: any) => {
        this.netpositionDailyLoading = false;
        if (netpositionResponse.status == 'success') {
          this.netPositionDataTempNonIntropDaily = netpositionResponse.data;
          this.netPositionDataTempNonIntropDaily.forEach(element => {
            element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
            element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
            element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
            element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

            let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
            let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
            element.isCombined = isCombined;
            element.groupedSegment = customSegment;

            if (element.isCombined) {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            } else {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            }
          });
          this.netPositionDataDaily = this.netPositionDataTempNonIntropDaily;

        } else {
          this.netPositionDataDaily = [];
        }
      }, error => {
        this.netpositionDailyLoading = false;
        this.netPositionDataDaily = [];
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getNetPositionData2',error.Message,undefined,error.stack,undefined,undefined));
        
      });

      await this.transactionService.getNetPositionExpiry(0).then((netpositionResponse: any) => {
        this.netpositionExpiryLoading = false;
        if (netpositionResponse.status == 'success') {

          this.netPositionDataTempNonIntropExpiry = netpositionResponse.data;
          this.netPositionDataTempNonIntropExpiry.forEach(element => {
            element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
            element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
            element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
            element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

            let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
            let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
            element.isCombined = isCombined;
            element.groupedSegment = customSegment;
            if (element.isCombined) {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            } else {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            }
          });
          this.netPositionDataExpiry = this.netPositionDataTempNonIntropExpiry;
        } else {
          this.netPositionDataExpiry = [];
        }



      }, error => {
        this.netpositionExpiryLoading = false;
        this.netPositionDataExpiry = [];
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getNetPositionData3',error.Message,undefined,error.stack,undefined,undefined));
      });


      if (this.interopOnOffFlag) {

        await this.transactionService.getNetPositionExpiry(1).then((netpositionResponse: any) => {
          this.netpositionExpiryLoading = false;
          if (netpositionResponse.status == 'success') {

            this.netPositionDataTempIntropExpiry = netpositionResponse.data;
            this.netPositionDataTempIntropExpiry.forEach(element => {
              element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
              element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
              element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
              element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

              let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
              let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
              element.isCombined = isCombined;
              element.groupedSegment = customSegment;
              if (element.isCombined) {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              } else {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              }
            });

            this.netPositionDataExpiry = this.netPositionDataTempIntropExpiry;

          } else {
            this.netPositionDataExpiry = [];
          }



        }, error => {
          this.netpositionExpiryLoading = false;
          this.netPositionDataExpiry = [];
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getNetPositionData4',error.Message,undefined,error.stack,undefined,undefined));
        });

        await this.transactionService.getNetPositionDaily(1).then((netpositionResponse: any) => {
          this.netpositionDailyLoading = false;
          if (netpositionResponse.status == 'success') {
            this.netPositionDataTempIntropDaily = netpositionResponse.data;
            this.netPositionDataTempIntropDaily.forEach(element => {
              element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
              element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
              element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
              element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

              let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
              let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
              element.isCombined = isCombined;
              element.groupedSegment = customSegment;

              if (element.isCombined) {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              } else {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              }
            });
            this.netPositionDataDaily = this.netPositionDataTempIntropDaily;

          } else {
            this.netPositionDataDaily = [];
          }
        }, error => {
          this.netpositionDailyLoading = false;
          this.netPositionDataDaily = [];
        });

      }


      this.allExchangeList = [...new Set(this.netPositionDataExpiry.map(element => element.displayExchange))];
      this.allProductType = [...new Set(this.netPositionDataExpiry.map(element => element.displayProductType))];
      this.segmentFilter();
      if (this.isPositionFilterApply) {
        this.clearPositionFilter();
      } else {
        await this.createNetpositionData();
        await this.createBroadcastforNetpositionDaily();
        await this.createBroadcastforNetpositionExpiry();
      }

    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getNetPositionData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getNetPositionData5',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  segmentFilter() {
    try{
    if (this.interopOnOffFlag)
      this.segmentList.push('All', 'All Combined');
    else
      this.segmentList.push('All');

    for (let count = 0; count < this.netPositionDataExpiry.length; count++) {
      if (this.segmentList.indexOf(this.netPositionDataExpiry[count].groupedSegment) == -1) {
        this.segmentList.push(this.netPositionDataExpiry[count].groupedSegment);
        if (this.netPositionDataExpiry[count].groupedSegment == "Derv Combined") {
          this.segmentList.push("Equity FAO");
        }
        else
          if (this.netPositionDataExpiry[count].groupedSegment == "EQ Combined") {
            this.segmentList.push("Equity");
          }
          else
            if (this.netPositionDataExpiry[count].groupedSegment == "Currency Combined") {
              this.segmentList.push("Currency");
            }
      }
    }
    if (this.interopOnOffFlag) {
      this.selectedSegment = this.segmentList[1];

    }
    else {
      this.selectedSegment = this.segmentList[0];
    }
    //this.segmentfrontfilter = this.selectedSegment;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'segmentFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  async onSegmentChange(segment) {
    try{
    this.selectedSegment = segment;

    if (this.selectedSegment == 'All Combined' || this.selectedSegment == 'Derv Combined' || this.selectedSegment == 'EQ Combined' || this.selectedSegment == 'Currency Combined') {
      this.removePositionFilter('exchangeType');
    }
    await this.createNetpositionData();
    await this.createBroadcastforNetpositionDaily();
    await this.createBroadcastforNetpositionExpiry();
    this.allExchangeList = [...new Set(this.netPositionDataExpiry.map(element => element.displayExchange))];
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'onSegmentChange',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  /**
  * send request for broadcast
  * @param opType
  * @param scripList
  */
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null || scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {

        if (this.filterNetpositionDataDaily.length > 0) {
          this.filterNetpositionDataDaily.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) || (netPositionItem.isCombined && netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId)) {

              nFormat = objMultiTLResp.PriceFormat

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;


              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }

              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];




            }
          });
          this.calculatecurrentMTMDaily();
        }

        if (this.filterNetpositionDataExpiry.length > 0) {
          this.filterNetpositionDataExpiry.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) || (netPositionItem.isCombined && netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId)) {
              nFormat = objMultiTLResp.PriceFormat

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;

              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              // netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }


              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];

            }
          }
          );
          this.calculatecurrentMTMExpiry();
        }

        if (this.filterHoldingData.length > 0) {

          this.filterHoldingData.forEach(holdingDataItem => {
            if (holdingDataItem.nToken == objMultiTLResp.Scrip.token && holdingDataItem.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = objMultiTLResp.PriceFormat
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              holdingDataItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
              holdingDataItem.closePrice = objMultiTLResp.ClosePrice;
              holdingDataItem.PandL = ((parseFloat(holdingDataItem.ltp) - parseFloat(holdingDataItem.nBuyAvgPrice)) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.TodaysPandL = ((parseFloat(holdingDataItem.ltp) - parseFloat(holdingDataItem.closePrice)) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.CMV = (parseFloat(holdingDataItem.ltp) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.InvestedValue = (parseFloat(holdingDataItem.nBuyAvgPrice) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              if (parseInt(holdingDataItem.InvestedValue) == 0) {
                holdingDataItem.perPandL = 0.00;
              } else {
                holdingDataItem.perPandL = (((holdingDataItem.CMV - holdingDataItem.InvestedValue) / holdingDataItem.InvestedValue) * 100).toFixed(2)
              }

              // holdingDataItem.perTodaysPandL = ((((parseFloat(holdingDataItem.ltp)) - (parseFloat(objMultiTLResp.ClosePrice))) / (parseFloat(objMultiTLResp.ClosePrice))) * 100 * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.perTodaysPandL = ((((parseFloat(holdingDataItem.ltp)) - (parseFloat(objMultiTLResp.ClosePrice))) / (parseFloat(objMultiTLResp.ClosePrice))) * 100).toFixed(2);


              let arrNetChange = clsTradingMethods.getChangeInRs(holdingDataItem.ltp, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              holdingDataItem.NetChangeInRs = arrNetChange[0];
              holdingDataItem.PercNetChange = arrNetChange[1];
              holdingDataItem.LTPTrend = arrNetChange[2];
              holdingDataItem.arrowTrend = arrNetChange[3];
            }
          }
          );
          this.calculatedCurrentMarketAndInvestedValue();
        }

        if (this.holdingSearchData.length > 0) {

          this.holdingSearchData.forEach(holdingDataItem => {
            if (holdingDataItem.nToken == objMultiTLResp.Scrip.token && holdingDataItem.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = objMultiTLResp.PriceFormat
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              holdingDataItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
              holdingDataItem.closePrice = objMultiTLResp.ClosePrice;
              holdingDataItem.PandL = ((parseFloat(holdingDataItem.ltp) - parseFloat(holdingDataItem.nBuyAvgPrice)) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.TodaysPandL = ((parseFloat(holdingDataItem.ltp) - parseFloat(holdingDataItem.closePrice)) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.CMV = (parseFloat(holdingDataItem.ltp) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.InvestedValue = (parseFloat(holdingDataItem.nBuyAvgPrice) * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              if (parseInt(holdingDataItem.InvestedValue) == 0) {
                holdingDataItem.perPandL = 0.00;
              } else {
                holdingDataItem.perPandL = (((holdingDataItem.CMV - holdingDataItem.InvestedValue) / holdingDataItem.InvestedValue) * 100).toFixed(2)
              }

              // holdingDataItem.perTodaysPandL = ((((parseFloat(holdingDataItem.ltp)) - (parseFloat(objMultiTLResp.ClosePrice))) / (parseFloat(objMultiTLResp.ClosePrice))) * 100 * parseInt(holdingDataItem.TOTALQUANTITY)).toFixed(2);
              holdingDataItem.perTodaysPandL = ((((parseFloat(holdingDataItem.ltp)) - (parseFloat(objMultiTLResp.ClosePrice))) / (parseFloat(objMultiTLResp.ClosePrice))) * 100).toFixed(2);


              let arrNetChange = clsTradingMethods.getChangeInRs(holdingDataItem.ltp, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              holdingDataItem.NetChangeInRs = arrNetChange[0];
              holdingDataItem.PercNetChange = arrNetChange[1];
              holdingDataItem.LTPTrend = arrNetChange[2];
              holdingDataItem.arrowTrend = arrNetChange[3];
            }
          }
          );
        }

        if (this.positionSearchData.length > 0) {
          this.positionSearchData.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) || (netPositionItem.isCombined && netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId)) {
              nFormat = objMultiTLResp.PriceFormat
              netPositionItem.ltp = objMultiTLResp.LTP;

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined
                ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;

              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              netPositionItem.CMV = (parseFloat(netPositionItem.ltp) * parseInt(netPositionItem.net_quantity)).toFixed(2);
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }


              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];

            }
          }
          );
        }
      }
    }
    catch (error) {
      //console.log("Error receiveTouchlineResponse" + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  calculatedCurrentMarketAndInvestedValue() {
    try {
      let totalCMV = 0.00;
      let totalInvestedValue = 0.00;
      let totalTodaysPandL = 0.00;
      let totalTodaysPandLPer = 0.00;

      this.sumCurrentMarketValue = 0.00;
      this.sumInvestedValue = 0.00;
      this.sumTodaysPandL = 0.00;
      this.sumTodaysPandLPer = 0.00;

      for (let count = 0; count < this.filterHoldingData.length; count++) {

        //changes for handling undefined data.
        totalCMV = parseFloat(totalCMV.toFixed(2)) + parseFloat(this.filterHoldingData[count].CMV || 0);
        totalInvestedValue = parseFloat(totalInvestedValue.toFixed(2)) + parseFloat(this.filterHoldingData[count].InvestedValue || 0);
        totalTodaysPandL = parseFloat(totalTodaysPandL.toFixed(2)) + parseFloat(this.filterHoldingData[count].TodaysPandL || 0);
        totalTodaysPandLPer = parseFloat(totalTodaysPandLPer.toFixed(2)) + ((this.filterHoldingData[count].closePrice || 0) * parseInt(this.filterHoldingData[count].TOTALQUANTITY));
      } 

      this.sumCurrentMarketValue = totalCMV.toFixed(2);
      this.sumInvestedValue = totalInvestedValue.toFixed(2);

      this.sumTodaysPandL = totalTodaysPandL.toFixed(2);
      this.sumTodaysPandLPer = (((totalCMV - totalTodaysPandLPer) / totalTodaysPandLPer) * 100).toFixed(2);

      this.sumPandL = (parseFloat(this.sumCurrentMarketValue) - parseFloat(this.sumInvestedValue)).toFixed(2);
      
      if(isNaN(this.sumInvestedValue) || parseInt(this.sumInvestedValue)==0){
        this.sumPandLper = 0.00;
      }else{
        this.sumPandLper = (((parseFloat(this.sumCurrentMarketValue) - parseFloat(this.sumInvestedValue)) / parseFloat(this.sumInvestedValue)) * 100).toFixed(2);
      }
    } catch (error) {
      //console.log('PortfolioPage sendTouchlineRequest' + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'calculatedCurrentMarketAndInvestedValue',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  calculatecurrentMTMDaily() {
    try {

      let totalMTM = 0.00;
      //let totalInvestedValue = 0.00;
      //let totalCurrentValue = 0.00;

      this.sumMTMDaily = 0.00;
      for (let count = 0; count < this.netPositionDataDaily.length; count++) {

        totalMTM = parseFloat(totalMTM.toFixed(2)) + parseFloat(this.netPositionDataDaily[count].mtm);
        // totalCurrentValue = parseFloat(totalCurrentValue.toFixed(2)) + (parseInt(this.netPositionDataDaily[count].net_quantity) * parseFloat(this.netPositionDataDaily[count].ltp));
        // totalInvestedValue = parseFloat(totalInvestedValue.toFixed(2)) + (parseInt(this.netPositionDataDaily[count].net_quantity) * parseFloat(this.netPositionDataDaily[count].net_price));
      }
      this.sumMTMDaily = totalMTM.toFixed(2);
      //this.sumMTMDailyPer = (((totalCurrentValue - totalInvestedValue) / totalInvestedValue) * 100).toFixed(2)
      //console.log("daily" , this.sumMTMDaily);
      if (parseFloat(this.sumMTMDaily) > 0) {
        this.mtmDataTrendDaily = 'color-positive';
      }
      else if (parseFloat(this.sumMTMDaily) < 0) {
        this.mtmDataTrendDaily = 'color-negative';
      } else {
        this.mtmDataTrendDaily = 'no-change';
      }

    } catch (error) {
      //console.log('PortfolioPage calculatecurrentMTMDaily' + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'calculatecurrentMTMDaily',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  calculatecurrentMTMExpiry() {
    try {
      let totalMTM = 0.00;
      // let totalInvestedValue = 0.00;
      // let totalCurrentValue = 0.00;
      this.sumMTMExpiry = 0.00;
      for (let count = 0; count < this.netPositionDataExpiry.length; count++) {

        totalMTM = parseFloat(totalMTM.toFixed(2)) + parseFloat(this.netPositionDataExpiry[count].mtm);
        // totalCurrentValue = parseFloat(totalCurrentValue.toFixed(2)) + (parseInt(this.netPositionDataExpiry[count].net_quantity) * parseFloat(this.netPositionDataExpiry[count].ltp));
        //  totalInvestedValue = parseFloat(totalInvestedValue.toFixed(2)) + (parseInt(this.netPositionDataExpiry[count].net_quantity) * parseFloat(this.netPositionDataExpiry[count].net_price));
      }

      this.sumMTMExpiry = totalMTM.toFixed(2);
      // this.sumMTMExpiryPer = (((totalCurrentValue - totalInvestedValue) / totalInvestedValue) * 100).toFixed(2)
      // console.log("Expiry" , this.sumMTMExpiry);

      if (parseFloat(this.sumMTMExpiry) > 0) {
        this.mtmDataTrendExpiry = 'color-positive';
      }
      else if (parseFloat(this.sumMTMExpiry) < 0) {
        this.mtmDataTrendExpiry = 'color-negative';
      } else {
        this.mtmDataTrendExpiry = 'no-change';
      }
    } catch (error) {
      //console.log("Error in calculateCurrentMTMExpiry" + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'calculatecurrentMTMExpiry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showOrderEntry(transaction_type) {
    try {
      let Token = this.selectedHoldingItem.nToken;
      let mktSegId = this.selectedHoldingItem.nMarketSegmentId;
      let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
      let scripdetail = {
        scrips: [{
          mkt: exchange,
          token: Token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        if (resp.status) {
          let scrip = resp.result[0];
          let currScrip = clsCommonMethods.getScripObject(scrip).scripDetail;
          // let currScrip: clsScrip = new clsScrip();
          // currScrip.scripDet.MktSegId = scrip.nMarketSegmentId;
          // currScrip.scripDet.token = scrip.nToken;
          // currScrip.symbol = scrip.sSymbol;
          // currScrip.Series = scrip.sSeries;
          // currScrip.InstrumentName = scrip.sInstrumentName;
          // currScrip.ExpiryDate = scrip.nExpiryDate;
          // currScrip.StrikePrice = scrip.nStrikePrice || "-1";
          // currScrip.OptionType = scrip.sOptionType || "NA";
          // currScrip.MarketLot = scrip.nRegularLot || 1;
          // currScrip.PriceTick = scrip.nPriceTick || 1;

          if (!clsCommonMethods.isLoginAllowed(mktSegId)) {
            //this.showError(clsConstants.ORDERBOOK_MODIFY_ERRORMSG);
            return;
          }

          let buysellnumber;
          if (transaction_type == clsConstants.C_S_ORDER_BUY_TEXT) {
            buysellnumber = clsConstants.C_V_ORDER_BUY;
          }
          else {
            buysellnumber = clsConstants.C_V_ORDER_SELL;
          }

          let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
          objOEFormDetail.buySell = buysellnumber;
          //objOEFormDetail.gwOrderNo = order.order_id;
          //objOEFormDetail.COL = order.COL;
          //objOEFormDetail.orderType = order.order_type;
          objOEFormDetail.pageSource = clsConstants.C_V_STOCKVIEW_PAGENO;
          objOEFormDetail.scripDetl = currScrip;
          objOEFormDetail.buyQty = null;
          objOEFormDetail.sellQty = null;
          objOEFormDetail.ltp = null;
          objOEFormDetail.closePrice = null;
          objOEFormDetail.recoId = '';
          objOEFormDetail.orderQty = this.selectedHoldingItem.TOTALQUANTITY;
          objOEFormDetail.orderPrice = this.selectedHoldingItem.nBuyAvgPrice;
          //objOEFormDetail.orderTrigPrice = order.trigger_price;
          objOEFormDetail.productType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
          objOEFormDetail.segmentsAllowed = this.selectedHoldingItem.OtherSegmentTokens;
          //objOEFormDetail.validity = order.validity;
          //objOEFormDetail.day = order.validity_days;
          //objOEFormDetail.exchOrderNo = order.exchange_order_no;
          //objOEFormDetail.cliOrderNo = order.order_identifier;
          //objOEFormDetail.cliExchangeOrderID = order.exchange_order_no;
          //objOEFormDetail.discQty = order.disclosed_quantity;
          //objOEFormDetail.apiExchange = order.exchange;
          //objOEFormDetail.tradedQty = order.traded_quantity
          // objOEFormDetail.protPerc = order.MarketProtPerc;
          // objOEFormDetail.OFSMargin = order.OFSMargin;
          // objOEFormDetail.SLOrderType = order.SLOrderType;
          // objOEFormDetail.SLOrderPrice = order.SLOrderPrice;
          // objOEFormDetail.SLTrigOrderPrice = order.SLTriggerPrice;
          // objOEFormDetail.SLJumpPrice = order.SLJumpPrice;
          // objOEFormDetail.LTPJumpPrice = order.LTPJumpPrice;
          // objOEFormDetail.profitOrderPrice = order.ProfitOrderPrice;
          // objOEFormDetail.bracketOrderId = order.BracketOrderId;
          // objOEFormDetail.boModifyBit = order.BracketOrder_ModifyBit;
          // objOEFormDetail.recoSQprice = null;
          // objOEFormDetail.legIndicator = order.LegIndicator;
          //objOEFormDetail.orderTime = order.order_timestamp;

          this.paramService.myParam = objOEFormDetail;
          this.navCtrl.navigateForward('orderentry');
          this.showHoldingDetails = false;
        } else {
          //console.log("Scrip not found in sqllite: ", exchange, "--", Token);
        }
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'showOrderEntry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'showOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  showOrderEntryCard(transactionType, trendingItem) {
    try {
      // console.log(this.selectedHoldingItem)
      let Token = trendingItem.nToken;
      //
      let mktSegId = trendingItem.nMarketSegmentId;
      let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
      let scripdetail = {
        scrips: [{
          mkt: exchange,
          token: Token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        if (resp.status) {
          let scrip = resp.result[0];
          let currScrip = clsCommonMethods.getScripObject(scrip).scripDetail;
          // let currScrip: clsScrip = new clsScrip();
          // currScrip.scripDet.MktSegId = scrip.nMarketSegmentId;
          // currScrip.scripDet.token = scrip.nToken;
          // currScrip.symbol = scrip.sSymbol;
          // currScrip.Series = scrip.sSeries;
          // currScrip.InstrumentName = scrip.sInstrumentName;
          // currScrip.ExpiryDate = scrip.nExpiryDate;
          // currScrip.StrikePrice = scrip.nStrikePrice || "-1";
          // currScrip.OptionType = scrip.sOptionType || "NA";
          // currScrip.MarketLot = scrip.nRegularLot || 1;
          // currScrip.PriceTick = scrip.nPriceTick || 1;

          if (!clsCommonMethods.isLoginAllowed(mktSegId)) {
            //this.showError(clsConstants.ORDERBOOK_MODIFY_ERRORMSG);
            return;
          }

          let buysellnumber;
          if (transactionType == clsConstants.C_S_ORDER_BUY_TEXT) {
            buysellnumber = clsConstants.C_V_ORDER_BUY;
          }
          else {
            buysellnumber = clsConstants.C_V_ORDER_SELL;
          }

          let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
          objOEFormDetail.buySell = buysellnumber;
          //objOEFormDetail.gwOrderNo = order.order_id;
          //objOEFormDetail.COL = order.COL;
          //objOEFormDetail.orderType = order.order_type;
          objOEFormDetail.pageSource = clsConstants.C_V_STOCKVIEW_PAGENO;
          objOEFormDetail.scripDetl = currScrip;
          objOEFormDetail.buyQty = null;
          objOEFormDetail.sellQty = null;
          objOEFormDetail.ltp = null;
          objOEFormDetail.closePrice = null;
          objOEFormDetail.recoId = '';
          objOEFormDetail.orderQty = trendingItem.TOTALFREEQUANTITY;
          objOEFormDetail.orderPrice = trendingItem.nBuyAvgPrice;
          //objOEFormDetail.orderTrigPrice = order.trigger_price;
          objOEFormDetail.productType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
          objOEFormDetail.segmentsAllowed = trendingItem.OtherSegmentTokens;
          
          //objOEFormDetail.validity = order.validity;
          //objOEFormDetail.day = order.validity_days;
          //objOEFormDetail.exchOrderNo = order.exchange_order_no;
          //objOEFormDetail.cliOrderNo = order.order_identifier;
          //objOEFormDetail.cliExchangeOrderID = order.exchange_order_no;
          //objOEFormDetail.discQty = order.disclosed_quantity;
          //objOEFormDetail.apiExchange = order.exchange;
          //objOEFormDetail.tradedQty = order.traded_quantity
          // objOEFormDetail.protPerc = order.MarketProtPerc;
          // objOEFormDetail.OFSMargin = order.OFSMargin;
          // objOEFormDetail.SLOrderType = order.SLOrderType;
          // objOEFormDetail.SLOrderPrice = order.SLOrderPrice;
          // objOEFormDetail.SLTrigOrderPrice = order.SLTriggerPrice;
          // objOEFormDetail.SLJumpPrice = order.SLJumpPrice;
          // objOEFormDetail.LTPJumpPrice = order.LTPJumpPrice;
          // objOEFormDetail.profitOrderPrice = order.ProfitOrderPrice;
          // objOEFormDetail.bracketOrderId = order.BracketOrderId;
          // objOEFormDetail.boModifyBit = order.BracketOrder_ModifyBit;
          // objOEFormDetail.recoSQprice = null;
          // objOEFormDetail.legIndicator = order.LegIndicator;
          //objOEFormDetail.orderTime = order.order_timestamp;

          this.paramService.myParam = objOEFormDetail;
          this.navCtrl.navigateForward('orderentry');
          this.showHoldingDetails = false;
        } else {
          //console.log("Scrip not found in sqllite: ", exchange, "--", Token);
        }
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'showOrderEntry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'showOrderEntryCard',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showScripInfo(trendingItem) {
    try {
      let Token = trendingItem.nToken;
      //
      let mktSegId = trendingItem.nMarketSegmentId;
      let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
      let scripdetail = {
        scrips: [{
          mkt: exchange,
          token: Token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        if (resp.status) {
          let scrip = resp.result[0];
          let currScrip = clsCommonMethods.getScripObject(scrip).scripDetail;
          // let currScrip: clsScrip = new clsScrip();
          // currScrip.scripDet.MktSegId = scrip.nMarketSegmentId;
          // currScrip.scripDet.token = scrip.nToken;
          // currScrip.symbol = scrip.sSymbol;
          // currScrip.Series = scrip.sSeries;
          // currScrip.InstrumentName = scrip.sInstrumentName;
          // currScrip.ExpiryDate = scrip.nExpiryDate;
          // currScrip.StrikePrice = scrip.nStrikePrice || "-1";
          // currScrip.OptionType = scrip.sOptionType || "NA";
          // currScrip.MarketLot = scrip.nRegularLot || 1;
          // currScrip.PriceTick = scrip.nPriceTick || 1;
          //this.selectedScrip = currScrip;//scripItem.scripDetail;// JSON.stringify(scripobject);
          this.paramService.myParam = currScrip;// clsCommonMethods.getScripObjectForWatchList(item);
          this.navCtrl.navigateForward('scripinfo');
        } else {
          //console.log("Scrip not found in sqllite: ", "exchange", "--", Token);
        }

      }, error => {
        console.log("unable to find scrip: ", Token, " ", "exchange");
      });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'scripInfo', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'scripInfo',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //Holdings Filter START
  createHoldingData() {
    try {
      this.filterHoldingData = []
      this.sendTouchlineRequest(OperationType.REMOVE, this.holdingScripKeys);
      this.holdingData.forEach(element => {
        element.exchange = clsTradingMethods.getExchangeName(element.nMarketSegmentId);
        element.events = [];
        this.EventList.forEach(event => {
          if (event.token == element.nToken && event.mktid == element.nMarketSegmentId) {
            element.events.push(event);
          }
        })
        this.filterHoldingData.push(element);
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'createHoldingData', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'createHoldingData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createBroadcastForHolding() {
    try {
      for (let index = 0; index < this.filterHoldingData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.filterHoldingData[index].nToken;
        objScrpKey.MktSegId = this.filterHoldingData[index].nMarketSegmentId;

        this.holdingScripKeys.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.holdingScripKeys);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'createBroadcastForHolding', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'createBroadcastForHolding',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setHoldingsFilter(filterName: any, filterValue: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          this.holdingsFilterObject.sortalpha = filterValue;
          break;
        case 'sortCMV':
          this.holdingsFilterObject.sortCMV = filterValue;
          break;
        case 'daysPandL':
          this.holdingsFilterObject['daysPandL'] = { 'sort': filterValue };
          break;
        case 'daysPandLPer':
          this.holdingsFilterObject['daysPandLPer'] = { 'sort': filterValue };
          break;
        case 'overallPandL':
          this.holdingsFilterObject['overallPandL'] = { 'sort': filterValue };
          break;
        case 'overallPandLPer':
          this.holdingsFilterObject['overallPandLPer'] = { 'sort': filterValue };
          break;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'setHoldingsFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'setHoldingsFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  removeHoldingsFilter(filterName: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          delete this.holdingsFilterObject.sortalpha
          break;
        case 'sortCMV':
          delete this.holdingsFilterObject.sortCMV
          break;
        case 'daysPandL':
          this.minDaysPandLHolding = 0;
          this.maxDaysPandLHolding = 0;
          delete this.holdingsFilterObject.daysPandL;
          break;
        case 'daysPandLPer':
          this.minDaysPandLPerHolding = 0;
          this.maxDaysPandLPerHolding = 0;
          delete this.holdingsFilterObject.daysPandLPer;
          break;
        case 'overallPandL':
          this.minOverallPandLHolding = 0;
          this.maxOverallPandLHolding = 0;
          delete this.holdingsFilterObject.overallPandL;
          break;
        case 'overallPandLPer':
          this.minOverallPandLPerHolding = 0;
          this.maxOverallPandLPerHolding = 0;
          delete this.holdingsFilterObject.overallPandLPer;
          break;
      }

      if (this.getHoldingsFiltersCount() == 0) {
        this.clearHoldingFilter();
      } else {
        this.applyHoldingsSortFilter();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'removeHoldingsFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'removeHoldingsFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  applyHoldingsSortFilter() {
    try {
      this.createHoldingData();
      this.isHoldingsFilterApply = true;
      this.showExpandedHoldingFilter = false;
      this.sortFilterPopupHolding = false;

      if (this.filterHoldingData.length > 0) {
        if (this.minDaysPandLHolding != 0 || this.maxDaysPandLHolding != 0) {
          this.holdingsFilterObject['daysPandL'] = { 'min': this.minDaysPandLHolding, 'max': this.maxDaysPandLHolding, "sort": (this.holdingsFilterObject.daysPandL && this.holdingsFilterObject.daysPandL.sort ? this.holdingsFilterObject['daysPandL'].sort : 'asc') }
        }

        if (this.minDaysPandLPerHolding != 0 || this.maxOverallPandLPerHolding != 0) {
          this.holdingsFilterObject['daysPandLPer'] = { 'min': this.minDaysPandLPerHolding, 'max': this.maxOverallPandLPerHolding, "sort": (this.holdingsFilterObject.daysPandLPer && this.holdingsFilterObject.daysPandLPer.sort ? this.holdingsFilterObject['daysPandLPer'].sort : 'asc') }
        }

        if (this.minOverallPandLHolding != 0 || this.maxOverallPandLHolding != 0) {
          this.holdingsFilterObject['overallPandL'] = { 'min': this.minOverallPandLHolding, 'max': this.maxOverallPandLHolding, "sort": (this.holdingsFilterObject.overallPandL && this.holdingsFilterObject.overallPandL.sort ? this.holdingsFilterObject['overallPandL'].sort : 'asc') }
        }

        if (this.minOverallPandLPerHolding != 0 || this.maxOverallPandLPerHolding != 0) {
          this.holdingsFilterObject['overallPandLPer'] = { 'min': this.minOverallPandLPerHolding, 'max': this.maxOverallPandLPerHolding, "sort": (this.holdingsFilterObject.overallPandLPer && this.holdingsFilterObject.overallPandLPer.sort ? this.holdingsFilterObject['overallPandLPer'].sort : 'asc') }
        }

        if (this.holdingsFilterObject.daysPandL) {

          if (this.holdingsFilterObject.daysPandL.min && this.holdingsFilterObject.daysPandL.min > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.TodaysPandL) > parseFloat(this.holdingsFilterObject.daysPandL.min));
          }

          if (this.holdingsFilterObject.daysPandL.max && this.holdingsFilterObject.daysPandL.max > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.TodaysPandL) < parseFloat(this.holdingsFilterObject.daysPandL.max));
          }

          if (this.holdingsFilterObject.daysPandL.sort) {
            if (this.holdingsFilterObject.daysPandL.sort == 'asc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(a.TodaysPandL).toFixed(2) < parseFloat(b.TodaysPandL).toFixed(2) ? 1 : -1))

            } else if (this.holdingsFilterObject.daysPandL.sort == 'desc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(b.TodaysPandL).toFixed(2) < parseFloat(a.TodaysPandL).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.holdingsFilterObject.overallPandL) {
          if (this.holdingsFilterObject.overallPandL.min && this.holdingsFilterObject.overallPandL.min > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.PandL) > parseFloat(this.holdingsFilterObject.overallPandL.min));
          }

          if (this.holdingsFilterObject.overallPandL.max && this.holdingsFilterObject.overallPandL.max > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.PandL) < parseFloat(this.holdingsFilterObject.overallPandL.max));
          }
          if (this.holdingsFilterObject.overallPandL.sort) {
            if (this.holdingsFilterObject.overallPandL == 'asc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(a.PandL).toFixed(2) < parseFloat(b.PandL).toFixed(2) ? 1 : -1))
            } else if (this.holdingsFilterObject.overallPandL == 'desc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(b.PandL).toFixed(2) < parseFloat(a.PandL).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.holdingsFilterObject.overallPandLPer) {
          if (this.holdingsFilterObject.overallPandLPer.min && this.holdingsFilterObject.overallPandLPer.min > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.perPandL) > parseFloat(this.holdingsFilterObject.overallPandLPer.min));
          }

          if (this.holdingsFilterObject.overallPandLPer.max && this.holdingsFilterObject.overallPandLPer.max > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.perPandL) < parseFloat(this.holdingsFilterObject.overallPandLPer.max));
          }
          if (this.holdingsFilterObject.overallPandLPer.sort) {
            if (this.holdingsFilterObject.overallPandLPer == 'asc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(a.perPandL).toFixed(2) < parseFloat(b.perPandL).toFixed(2) ? 1 : -1))
            } else if (this.holdingsFilterObject.overallPandLPer == 'desc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(b.perPandL).toFixed(2) < parseFloat(a.perPandL).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.holdingsFilterObject.daysPandLPer) {
          if (this.holdingsFilterObject.daysPandLPer.min && this.holdingsFilterObject.daysPandLPer.min > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.perTodaysPandL) > parseFloat(this.holdingsFilterObject.daysPandLPer.min));
          }

          if (this.holdingsFilterObject.daysPandLPer.max && this.holdingsFilterObject.daysPandLPer.max > 0) {
            this.filterHoldingData = this.filterHoldingData
              .filter(x => parseFloat(x.perTodaysPandL) < parseFloat(this.holdingsFilterObject.daysPandLPer.max));
          }
          if (this.holdingsFilterObject.daysPandLPer.sort) {
            if (this.holdingsFilterObject.daysPandLPer == 'asc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(a.perTodaysPandL).toFixed(2) < parseFloat(b.perTodaysPandL).toFixed(2) ? 1 : -1))
            } else if (this.holdingsFilterObject.daysPandLPer == 'desc') {
              this.filterHoldingData.sort((a, b) => (parseFloat(b.perTodaysPandL).toFixed(2) < parseFloat(a.perTodaysPandL).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.holdingsFilterObject.sortCMV) {
          if (this.holdingsFilterObject.sortCMV == 'asc') {
            this.filterHoldingData.sort((a, b) => (parseFloat(a.CMV).toFixed(2) < parseFloat(b.CMV).toFixed(2) ? 1 : -1))
          } else if (this.holdingsFilterObject.sortCMV == 'desc') {
            this.filterHoldingData.sort((a, b) => (parseFloat(b.CMV).toFixed(2) < parseFloat(a.CMV).toFixed(2) ? 1 : -1))
          }

        }

        if (this.holdingsFilterObject.sortalpha) {
          if (this.holdingsFilterObject.sortalpha == 'asc') {
            this.filterHoldingData.sort((a, b) => {
              return a.sSymbol.localeCompare(b.sSymbol);
            })
          } else if (this.holdingsFilterObject.sortalpha == 'desc') {
            this.filterHoldingData.sort((a, b) => {
              return b.sSymbol.localeCompare(a.sSymbol);
            })
          }
        }
      }
      //console.log(this.holdingsFilterObject);
      this.createBroadcastForHolding();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'applyHoldingsSortFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'applyHoldingsSortFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  clearHoldingFilter() {
    try {
      this.isHoldingsFilterApply = false;
      this.sortFilterPopupHolding = false;
      this.holdingsFilterObject = {};
      this.minDaysPandLHolding = 0;
      this.maxDaysPandLHolding = 0;
      this.minDaysPandLPerHolding = 0;
      this.maxDaysPandLPerHolding = 0;
      this.minOverallPandLHolding = 0;
      this.maxOverallPandLHolding = 0;
      this.minOverallPandLPerHolding = 0;
      this.maxOverallPandLPerHolding = 0;
      this.showExpandedHoldingFilter = false;
      this.createHoldingData();
      this.createBroadcastForHolding();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'clearHoldingFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'clearHoldingFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  getHoldingsFiltersCount() {
    try {
      return Object.keys(this.holdingsFilterObject).length;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getHoldingsFiltersCount', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getHoldingsFiltersCount',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  checkForHoldingiilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divholdingFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForHoldingiilterPopupUpElementRendrer();
        }, 100);
      } else {
        //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divholdingFilterPopup');
          this.holdingFilterPopupBottomToTop(divElement);
        }, 500);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'checkForHoldingiilterPopupUpElementRendrer', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'checkForHoldingiilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  holdingFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (240), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 800,
        buttonClose: false,
        backdrop: true, //added by om on 24 th jan for backdrop display.
        onDidPresent: () => {
          //console.log("onDidPresent")
        },

        // onDrag: () => {
        //   //  //console.log("onDrag");
        // },
        onDragEnd: () => {

          //console.log("onDragEnd");
          let topDiv = this.divHoldingFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedHoldingFilter = true;
          } else {
            this.showExpandedHoldingFilter = false;
          }

        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closeHoldingFilterPopup();
        }
        // onTransitionStart: () => {
        //   //console.log("onTransitionStart")
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends");
        //   //console.log("onTransitionEnd")
        // }
      }
      this.holdingFilterPane = new CupertinoPane(myElementRef, setting);
      this.holdingFilterPane.enableDrag();
      this.holdingFilterPane.present({ animate: true });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'holdingFilterPopupBottomToTop', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'checkForHoldingiilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollFilterDetails(event) {
    if (event.target.scrollTop > 20) {
      this.holdingFilterPane.moveToBreak('top');
      this.showExpandedHoldingFilter = true;
    }
  }

  closeHoldingFilterPopup() {
    try {
      this.sortFilterPopupHolding = false;
      this.showExpandedHoldingFilter = false;
      this.holdingFilterPane.destroy({ animate: true });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'closeHoldingFilterPopup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'closeHoldingFilterPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  //Holdings Filter END  
  //Holdings Search START

  showSearchPopupHolding() {
    this.searchTextHolding = '';
    this.showSearchHolding = true;
    this.holdingSearchData = [];
  }


  hideSearchPopupHolding() {
    this.showSearchHolding = false;
    this.searchTextHolding = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.holdingSearchData);
    this.holdingSearchScripKeys = [];
    this.holdingSearchData = [];
  }
  searchHolding(event) {
    try{
    if (event) {
      //this.searchTextHolding = $event.toUpperCase();
      this.searchTextHolding = event.target.value.toUpperCase().trim();
      this.searchTextChangedHolding.next(event.target.value.toUpperCase().trim());
    } else {
      this.sendTouchlineRequest(OperationType.REMOVE, this.holdingSearchScripKeys);
      this.holdingSearchScripKeys = [];
      this.holdingSearchData = [];
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'searchHolding',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getValuesHolding(search) {
    try {
      this.holdingSearchData = [];
      if (search.length < 1) {
        this.searchTextEnteredHolding = '';
        return;
      }
      this.searchTextEnteredHolding = search.toUpperCase();
      //console.log(this.searchTextEnteredHolding)

      this.holdingSearchData = this.holdingData
        .filter(x => (x.sSymbol.toUpperCase().trim().includes(this.searchTextEnteredHolding)));

      // console.log(this.holdingSearchData);

      this.sendTouchlineRequest(OperationType.REMOVE, this.holdingSearchData);
      this.creatBroadCastDataSearchHolding();

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getValuesHolding', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getValuesHolding',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchHolding() {
    this.searchTextHolding = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.holdingSearchScripKeys);
    this.holdingSearchScripKeys = [];
    this.holdingSearchData = [];
  }


  creatBroadCastDataSearchHolding() {
    try {
      this.holdingSearchScripKeys = [];
      for (let index = 0; index < this.holdingSearchData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.holdingSearchData[index].nToken;
        objScrpKey.MktSegId = this.holdingSearchData[index].nMarketSegmentId;

        this.holdingSearchScripKeys.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.holdingSearchScripKeys);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'creatBroadCastDataSearchHolding', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'creatBroadCastDataSearchHolding',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //Holding Search END

  //NetPosition Filter START  
  createNetpositionData() {
    try {
      this.filterNetpositionDataDaily = [];
      this.filterNetpositionDataExpiry = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysDaily);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysExpiry);
      if (this.selectedSegment == 'All' || this.selectedSegment == 'Equity' || this.selectedSegment == 'Currency' || this.selectedSegment == 'Equity FAO') {
        this.netPositionDataDaily = this.netPositionDataTempNonIntropDaily;
        this.netPositionDataExpiry = this.netPositionDataTempNonIntropExpiry;
      } else {
        this.netPositionDataDaily = this.netPositionDataTempIntropDaily;
        this.netPositionDataExpiry = this.netPositionDataTempIntropExpiry;
      }


      this.filterNetpositionDataDaily = this.netPositionDataDaily;
      this.filterNetpositionDataExpiry = this.netPositionDataExpiry;
    } catch (error) {
      //console.log("Error + createNetpositionData" + error.message);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'createNetpositionData', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'createNetpositionData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createBroadcastforNetpositionDaily() {
    try {
      for (let index = 0; index < this.netPositionDataDaily.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.netPositionDataDaily[index].isCombined ? this.netPositionDataDaily[index].preferred_scrip_token : this.netPositionDataDaily[index].scrip_token;
        objScrpKey.MktSegId = this.netPositionDataDaily[index].isCombined ? this.netPositionDataDaily[index].preferred_mktSegId : this.netPositionDataDaily[index].mktSegId;
        this.netPositionScripKeysDaily.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.netPositionScripKeysDaily);
    } catch (error) {
      console.log("Error + createBroadcastforNetpositionDaily" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'createBroadcastforNetpositionDaily', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'createBroadcastforNetpositionDaily',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createBroadcastforNetpositionExpiry() {
    try {
      for (let index = 0; index < this.netPositionDataExpiry.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.netPositionDataExpiry[index].isCombined ? this.netPositionDataExpiry[index].preferred_scrip_token : this.netPositionDataExpiry[index].scrip_token;
        objScrpKey.MktSegId = this.netPositionDataExpiry[index].isCombined ? this.netPositionDataExpiry[index].preferred_mktSegId : this.netPositionDataExpiry[index].mktSegId;
        this.netPositionScripKeysExpiry.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.netPositionScripKeysExpiry);
    } catch (error) {
      console.log("Error + createBroadcastforNetpositionExpiry" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'createBroadcastforNetpositionExpiry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'createBroadcastforNetpositionExpiry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setPositionFilter(filterName: any, filterValue: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          this.positionFilterObject.sortalpha = filterValue;
          break;
        case 'sortQty':
          this.positionFilterObject.sortQty = filterValue;
          break;
        case 'sortCMV':
          this.positionFilterObject.sortCMV = filterValue;
          break;
        case 'productType':
          this.positionFilterObject.productType = filterValue;
          break;
        case 'exchangeType':
          this.positionFilterObject.exchangeType = filterValue;
          break;
        case 'daysPandL':
          this.positionFilterObject['daysPandL'] = { 'sort': filterValue };
          break;
      }
    } catch (error) {
      console.log("Error + setPositionFilter" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'setPositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'setPositionFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  removePositionFilter(filterName: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          delete this.positionFilterObject.sortalpha
          break;
        case 'sortCMV':
          delete this.positionFilterObject.sortCMV
          break;
        case 'sortQty':
          delete this.positionFilterObject.sortQty
          break;
        case 'productType':
          delete this.positionFilterObject.productType
          break;
        case 'exchangeType':
          delete this.positionFilterObject.exchangeType
          break;
        case 'daysPandL':
          this.minDaysPandLPosition = 0;
          this.maxDaysPandLPosition = 0;
          delete this.positionFilterObject.daysPandL;
          break;
      }

      if (this.getPositionsFiltersCount() == 0) {
        this.clearPositionFilter();
      } else {
        this.applyPositionSortFilter();
      }
    } catch (error) {
      console.log("Error + removePositionFilter" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'removePositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'removePositionFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  applyPositionSortFilter() {
    try {
      this.createNetpositionData();
      this.isPositionFilterApply = true;
      this.sortFilterPopupPosition = false;
      this.showExpandedPositionFilter = false;

      if (this.filterNetpositionDataDaily.length > 0) {
        if (this.minDaysPandLPosition != 0 || this.maxDaysPandLPosition != 0) {
          this.positionFilterObject['daysPandL'] = { 'min': this.minDaysPandLPosition, 'max': this.maxDaysPandLPosition, "sort": (this.positionFilterObject.daysPandL && this.positionFilterObject.daysPandL.sort ? this.positionFilterObject['daysPandL'].sort : 'asc') }
        }

        if (this.positionFilterObject.productType) {
          this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
            .filter(x => x.displayProductType == this.positionFilterObject.productType)
        }

        if (this.positionFilterObject.exchangeType) {
          this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
            .filter(x => x.displayExchange == this.positionFilterObject.exchangeType)
        }

        if (this.positionFilterObject.daysPandL) {

          if (this.positionFilterObject.daysPandL.min && this.positionFilterObject.daysPandL.min > 0) {
            this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
              .filter(x => parseFloat(x.mtm) > parseFloat(this.positionFilterObject.daysPandL.min));
          }

          if (this.positionFilterObject.daysPandL.max && this.positionFilterObject.daysPandL.max > 0) {
            this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
              .filter(x => parseFloat(x.mtm) < parseFloat(this.positionFilterObject.daysPandL.max));
          }



          if (this.positionFilterObject.daysPandL.sort) {
            if (this.positionFilterObject.daysPandL.sort == 'asc') {
              this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(a.mtm).toFixed(2) < parseFloat(b.mtm).toFixed(2) ? 1 : -1))

            } else if (this.positionFilterObject.daysPandL.sort == 'desc') {
              this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(b.mtm).toFixed(2) < parseFloat(a.mtm).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.positionFilterObject.sortQty) {
          if (this.positionFilterObject.sortQty == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseInt(a.net_quantity) > parseInt(b.net_quantity) ? 1 : -1))
          } else if (this.positionFilterObject.sortQty == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseInt(b.net_quantity) > parseInt(a.net_quantity) ? 1 : -1))
          }
        }
        if (this.positionFilterObject.sortCMV) {
          if (this.positionFilterObject.sortCMV == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(a.CMV).toFixed(2) < parseFloat(b.CMV).toFixed(2) ? 1 : -1))
          } else if (this.positionFilterObject.sortCMV == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(b.CMV).toFixed(2) < parseFloat(a.CMV).toFixed(2) ? 1 : -1))
          }

        }
        if (this.positionFilterObject.sortalpha) {
          if (this.positionFilterObject.sortalpha == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => {
              return a.symbol.localeCompare(b.symbol);
            })
          } else if (this.positionFilterObject.sortalpha == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => {
              return b.symbol.localeCompare(a.symbol);
            })
          }
        }
      }

      if (this.filterNetpositionDataExpiry.length > 0) {
        if (this.minDaysPandLPosition != 0 || this.maxDaysPandLPosition != 0) {
          this.positionFilterObject['daysPandL'] = { 'min': this.minDaysPandLPosition, 'max': this.maxDaysPandLPosition, "sort": (this.positionFilterObject.daysPandL && this.positionFilterObject.daysPandL.sort ? this.positionFilterObject['daysPandL'].sort : 'asc') }
        }

        if (this.positionFilterObject.productType) {
          this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
            .filter(x => x.displayProductType == this.positionFilterObject.productType)
        }

        if (this.positionFilterObject.exchangeType) {
          this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
            .filter(x => x.displayExchange == this.positionFilterObject.exchangeType)
        }

        if (this.positionFilterObject.daysPandL) {

          if (this.positionFilterObject.daysPandL.min && this.positionFilterObject.daysPandL.min > 0) {
            this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
              .filter(x => parseFloat(x.mtm) > parseFloat(this.positionFilterObject.daysPandL.min));
          }

          if (this.positionFilterObject.daysPandL.max && this.positionFilterObject.daysPandL.max > 0) {
            this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
              .filter(x => parseFloat(x.mtm) < parseFloat(this.positionFilterObject.daysPandL.max));
          }



          if (this.positionFilterObject.daysPandL.sort) {
            if (this.positionFilterObject.daysPandL.sort == 'asc') {
              this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(a.mtm).toFixed(2) < parseFloat(b.mtm).toFixed(2) ? 1 : -1))

            } else if (this.positionFilterObject.daysPandL.sort == 'desc') {
              this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(b.mtm).toFixed(2) < parseFloat(a.mtm).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.positionFilterObject.sortQty) {
          if (this.positionFilterObject.sortQty == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseInt(a.net_quantity) > parseInt(b.net_quantity) ? 1 : -1))
          } else if (this.positionFilterObject.sortQty == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseInt(b.net_quantity) > parseInt(a.net_quantity) ? 1 : -1))
          }
        }
        if (this.positionFilterObject.sortCMV) {
          if (this.positionFilterObject.sortCMV == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(a.CMV).toFixed(2) < parseFloat(b.CMV).toFixed(2) ? 1 : -1))
          } else if (this.positionFilterObject.sortCMV == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(b.CMV).toFixed(2) < parseFloat(a.CMV).toFixed(2) ? 1 : -1))
          }

        }
        if (this.positionFilterObject.sortalpha) {
          if (this.positionFilterObject.sortalpha == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => {
              return a.symbol.localeCompare(b.symbol);
            })
          } else if (this.positionFilterObject.sortalpha == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => {
              return b.symbol.localeCompare(a.symbol);
            })
          }
        }
      }
      this.createBroadcastforNetpositionDaily();
      this.createBroadcastforNetpositionExpiry();
    } catch (error) {
      console.log("Error + applyPositionSortFilter" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'applyPositionSortFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'applyPositionSortFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearPositionFilter() {
    try {
      this.isPositionFilterApply = false;
      this.sortFilterPopupPosition = false;
      this.positionFilterObject = {};
      this.minDaysPandLPosition = 0;
      this.maxDaysPandLPosition = 0;
      this.showExpandedPositionFilter = false;
      this.createNetpositionData();
      this.createBroadcastforNetpositionDaily();
      this.createBroadcastforNetpositionExpiry();
    } catch (error) {
      console.log("Error clearPositionFilter" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'clearPositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'clearPositionFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getPositionsFiltersCount() {
    try {
      return Object.keys(this.positionFilterObject).length;
    } catch (error) {
      console.log("Error getPositionsFiltersCount" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getPositionsFiltersCount', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getPositionsFiltersCount',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForPositionFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divpositionFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForPositionFilterPopupUpElementRendrer();
        }, 100);
      } else {
        //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divpositionFilterPopup');
          this.positionFilterPopupBottomToTop(divElement);
        }, 500);
      }
    } catch (error) {
      console.log("Error checkForPositionFilterPopupUpElementRendrer" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'checkForPositionFilterPopupUpElementRendrer', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'checkForPositionFilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  positionFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (240), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 800,
        buttonClose: false,
        backdrop: true, //added by om on 24 th jan for backdrop display.
        onDragEnd: () => {
          //console.log("onDragEnd");
          let topDiv = this.divPositionFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedPositionFilter = true;
          } else {
            this.showExpandedPositionFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closePositionFilterPopup();
        }
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends"); 
        //   //console.log("onTransitionEnd")
        // },
        // onDrag: () => {
        //   //  //console.log("onDrag");
        // }
      }
      this.positionFilterPane = new CupertinoPane(myElementRef, setting);
      this.positionFilterPane.enableDrag();
      this.positionFilterPane.present({ animate: true });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "positionFilterPopupBottomToTop", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'positionFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollPositionFilterDetails(event) {
    if (event.target.scrollTop > 20) {
      this.positionFilterPane.moveToBreak('top');
      this.showExpandedPositionFilter = true;
    }
  }


  closePositionFilterPopup() {
    try {
      this.sortFilterPopupPosition = false;
      this.showExpandedPositionFilter = false;
      this.positionFilterPane.destroy({ animate: true });
    } catch (error) {
     // clsGlobal.ConsoleLogging("Error", "closePositionFilterPopup", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'closePositionFilterPopup',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //NetPosition Filter END 





  //Net Position START

  showSearchPopupPosition() {
    this.searchTextPosition = '';
    this.showSearchPosition = true;
    this.positionSearchData = [];
  }


  hideSearchPopupPosition() {
    this.showSearchPosition = false;
    this.searchTextPosition = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.positionSearchData);
    this.positionSearchScripKeys = [];
    this.positionSearchData = [];

  }


  searchPosition(event) {
    console.log("search position.");
    if (event) {
      //this.searchTextPosition = $event.toUpperCase();
      this.searchTextPosition = event.target.value.toUpperCase().trim(); 
      this.searchTextChangedPosition.next(event.target.value.toUpperCase().trim());
    } else {
      this.sendTouchlineRequest(OperationType.REMOVE, this.positionSearchScripKeys);
      this.positionSearchScripKeys = [];
      this.positionSearchData = [];
    }
  }

  getValuesPosition(search) {
    try {

      this.positionSearchData = [];

      if (search.length < 1) {
        this.searchTextEnteredPosition = '';
        return;
      }
      this.searchTextEnteredPosition = search.toUpperCase();

      let mergeNetpositionArray = this.netPositionDataDaily.concat(this.netPositionDataExpiry)
      mergeNetpositionArray = mergeNetpositionArray.filter((item, index) => {
        return (mergeNetpositionArray.indexOf(item) == index);
      })

      this.positionSearchData = mergeNetpositionArray
        .filter(x => (x.symbol.toUpperCase().trim().includes(this.searchTextEnteredPosition)));

      //console.log(this.positionSearchData);

      this.sendTouchlineRequest(OperationType.REMOVE, this.positionSearchData);
      this.creatBroadCastDataSearchPosition();

    } catch (error) {
      console.log(error)
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getValuesPosition',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchPosition() {
    this.searchTextPosition = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.positionSearchScripKeys);
    this.positionSearchScripKeys = [];
    this.positionSearchData = [];
  }


  creatBroadCastDataSearchPosition() {
    try{
    this.positionSearchScripKeys = [];
    for (let index = 0; index < this.positionSearchData.length; index++) {


      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.token = this.positionSearchData[index].scrip_token;
      objScrpKey.MktSegId = this.positionSearchData[index].mktSegId;

      this.positionSearchScripKeys.push(objScrpKey);
    }
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.positionSearchScripKeys);
    //Net Position Search END
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'creatBroadCastDataSearchPosition',error.Message,undefined,error.stack,undefined,undefined));
  }
  }


  filterholdingDataWithTrendingEvents(holdingDataItem) {
    return holdingDataItem.events.length > 0;
  }
  clicktickerCard() {
    this.showtickerCard = !this.showtickerCard;
  }

  refresherInstanceHolding: any;
  doRefreshHolding(refresher) {
    this.refresherInstanceHolding = refresher;
    this.getHoldingsData();
  }

  refresherInstancePosition: any;
  doRefreshPosition(refresher) {
    this.refresherInstancePosition = refresher;
    this.getNetPositionData();
  }



  async squareOffPosition() {
    try {
      if (this.interopOnOffFlag && this.selectedNetPosition.isCombined) {
        let intropOrderData = [];
        await this.netPositionDataTempNonIntropExpiry.forEach(element => {
          if (this.selectedNetPosition.preferred_mktSegId == element.preferred_mktSegId && this.selectedNetPosition.product_type == element.product_type && this.selectedNetPosition.preferred_scrip_token == element.preferred_scrip_token && element.net_quantity !=0) {
            intropOrderData.push(element);
          }
        });

          if (intropOrderData.length > 0) {
          this.paramService.myParam = intropOrderData;
          this.navCtrl.navigateForward('introp-orderentry');
          this.closeNetPositionDetailsPopup();
        }

      } else {
        this.isScripFetchForSquareOff = true;
        if (this.selectedNetPosition && !this.selectedNetPosition.scrip) {
          let scripdetail = {
            scrips: [{
              mkt: this.selectedNetPosition.exchange,
              token: this.selectedNetPosition.scrip_token
            }]
          }
          await clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
            if (resp.status) {
              this.isScripFetchForSquareOff = false;
              this.selectedNetPosition.scrip = resp.result[0];
            } else {
              this.isScripFetchForSquareOff = true;
            }
          });
        } else {
          this.isScripFetchForSquareOff = false;
        }
        if (this.selectedNetPosition && this.selectedNetPosition.scrip) {
          let currScrip: clsScrip = new clsScrip();
          currScrip = clsCommonMethods.getScripObject(this.selectedNetPosition.scrip).scripDetail;

          let buysellnumber;
          if (this.selectedNetPosition.net_quantity > 0) {
            buysellnumber = clsConstants.C_V_ORDER_SELL;
          }
          else {
            buysellnumber = clsConstants.C_V_ORDER_BUY;
          }

          let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
          objOEFormDetail.buySell = buysellnumber;
          objOEFormDetail.orderType = clsConstants.C_V_ORDER_REGULARLOT_MARKET;
          objOEFormDetail.pageSource = clsConstants.C_V_NETPOSITION_PAGENO;
          objOEFormDetail.scripDetl = currScrip;
          objOEFormDetail.buyQty = null;
          objOEFormDetail.sellQty = null;
          objOEFormDetail.ltp = this.selectedNetPosition.ltp;
          objOEFormDetail.closePrice = null;
          objOEFormDetail.recoId = '';
          objOEFormDetail.orderQty = Math.abs(this.selectedNetPosition.net_quantity);
          objOEFormDetail.orderPrice = this.selectedNetPosition.ltp;
          objOEFormDetail.productType = this.selectedNetPosition.product_type;
          objOEFormDetail.apiExchange = this.selectedNetPosition.exchange;

          this.paramService.myParam = objOEFormDetail;
          this.navCtrl.navigateForward('orderentry');
          this.closeNetPositionDetailsPopup();

        }
      }

    } catch (error) {
      this.toastServicesProvider.showAtMiddle("Unable to squareoff order");
      this.closeNetPositionDetailsPopup();
      //clsGlobal.logManager.writeErrorLog('PortfolioPage ', 'squareOffPosition', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'squareOffPosition',error.Message,undefined,error.stack,undefined,undefined));
    }

  }


  setProdutTypeForConversion(productType) {
    this.selProductType = productType;
  }
  showPositionDetailsPopup(netPositionitem) {
    if (netPositionitem.net_quantity != 0 && netPositionitem.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && netPositionitem.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
      this.selectedNetPosition = netPositionitem;
      this.showPositionDetails = true;
    }

  }
  closeNetPositionDetailsPopup() {
    this.showPositionDetails = false;
    this.isPositionConversionQtyEdit = false;
    this.selectedNetPosition = null;
    this.selectedQtyforPositionConversion = 0;
  }
  showPositionConverstionPopup() {
    this.showPositionConversition = true;
    this.productTypesByExchange = clsGlobal.ExchManager.populateProductTypes(this.selectedNetPosition.exchange, this.selectedNetPosition.mktSegId, false);
    this.productTypesByExchange = this.productTypesByExchange.filter(element => {
      if (this.selectedNetPosition.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
        return (element != this.selectedNetPosition.product_type && element != this.selectedNetPosition.displayProductType && element != clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT && element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);

      } else {
        return (element != this.selectedNetPosition.product_type && element != this.selectedNetPosition.displayProductType && element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
      }

    })
    this.selProductType = this.productTypesByExchange[0];
  }

  showPositionConversionEditPopup() {
    this.isPositionConversionQtyEdit = true;
    this.selectedQtyforPositionConversion = this.getFormattedQty(this.selectedNetPosition.net_quantity);
  }

  closePositionConversionEditPopup() {
    this.isPositionConversionQtyEdit = false;
    this.selectedQtyforPositionConversion = 0;
  }




  closePositionConvertionPopup() {
    this.showPositionConversition = false;
    this.selProductType = ""
  }


  convertPosition() {
    try{
    let net_quantity = 0;
    let old_product_type = "";
    if (this.isPositionConversionQtyEdit) {

      net_quantity = Math.abs(this.selectedQtyforPositionConversion) * this.selectedNetPosition.market_lot;
    } else {
      net_quantity = Math.abs(this.selectedNetPosition.net_quantity);
    }
    if (this.selProductType == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT) {
      old_product_type = this.selProductType;
      this.selProductType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT
    } else {
      old_product_type = this.selProductType;
    }

    let transaction_type = this.selectedNetPosition.net_quantity > 0 ? 'BUY' : 'SELL';

    this.isPositionConversionClick = true;
    this.transactionService.positionConversion(this.selectedNetPosition.exchange, this.selectedNetPosition.scrip_token, transaction_type, net_quantity, this.selectedNetPosition.product_type, this.selProductType, "").then((response: any) => {
      if (response.status == 'success') {
        this.showConfirmDialogPopup("Your " + this.selectedNetPosition.displayProductType + "  Order for " + this.selectedNetPosition.symbol + " " + this.selectedNetPosition.displayScripDesc + "(" + net_quantity + " Shares) has been converted to " + old_product_type + " Order", "");
        this.isPositionConversionClick = false;
        this.closePositionConvertionPopup();
        this.closeNetPositionDetailsPopup();
      } else {
        this.isPositionConversionClick = false;
        this.closePositionConvertionPopup();
        this.closeNetPositionDetailsPopup();

      }

    }, error => {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'convertPosition',error.Message,undefined,error.stack,undefined,undefined));
      this.isPositionConversionClick = false;
      this.closePositionConvertionPopup();
      this.closeNetPositionDetailsPopup();
    })
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'convertPosition2',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeConfirmDialogPopup() {
    try{
    this.confirmDialogDataObj = {};
    this.showConfirmDialog = false;
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getFormattedProductType',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  confirmDialogViewOrderStatusClick() {
    try{
    this.confirmDialogDataObj = {};
    this.showConfirmDialog = false;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'confirmDialogViewOrderStatusClick',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  showConfirmDialogPopup(message: string, orderId: string) {
    try{
    this.confirmDialogDataObj['message'] = message;
    this.confirmDialogDataObj['orderId'] = orderId;
    this.showConfirmDialog = true;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'showConfirmDialogPopup',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  scrollContent(event) {
    try{
    if (event.detail.scrollTop > 80) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    console.log(event);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'scrollContent',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  

  getFormattedQty(qty) {
    return Math.abs(qty);
  }

  getFormattedNumbers(sNumber) {
    if (sNumber) {
      return clsCommonMethods.getNumberWithCurrencyFormat(sNumber);
    } else {
      return 0.00;
    }
  }
  getFormattedProductType(productType: string) {
    try{
    let product_type = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        product_type = productType.replace(/\w\S*/g, (txt) => { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase() })
        break;
      default:
        product_type = productType;
        break;
    }
    return product_type;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getFormattedProductType',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
 

  getOrderMeessage(orderMessage) {
    try{

    if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_ORDER) {
    } else if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_TRADE) {
    }
    else if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_POS_CONV) {
      this.getNetPositionData();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getOrderMeessage',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  checkForIndiceTicker() {
    try {

      if (this.elTicker == undefined) {
        setTimeout(() => {
          this.checkForIndiceTicker();
        }, 100);
      } else {
        this.elTicker.ionViewWillEnter();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'checkForElementReder',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  // added by sonali
  addFunds() {
    this.navCtrl.navigateForward('fundsadd');
  }

  kFormatter(num) {
    try {
      let digits = 1;

      var si = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E5, symbol: "Lac" },
        { value: 1E7, symbol: "Cr." },
        { value: 1E12, symbol: "Cr." },
        { value: 1E15, symbol: "Cr." },
        { value: 1E18, symbol: "Cr." }
      ];
      var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
      var i;
      for (i = si.length - 1; i > 0; i--) {
        if (num >= si[i].value) {
          break;
        }
      }
      this.fundsValueInText = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
    } catch (error) {
      console.log("Error in k formatter watchlist." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'kFormatter',error.Message,undefined,error.stack,undefined,undefined));
      this.fundsValueInText = "0.00";
    }
  }

  calculateFunds() {
    try {
      this.totalPurchasingPower = 0.00;
      this.totalCash = 0.00;
      this.totalCollatral = 0.00;
      this.totalMargin = 0.00;
      this.totalBuyingPower = 0.00;

      let arrAmt = [];
      this.periodicityWisefundsDetails.forEach(element => {
        //this.totalPurchasingPower += parseFloat(element.net_available[0].nTotal);
        //this.totalCash += parseFloat(element.available.cash[0].nTotal);
        //this.totalCollatral += parseFloat(element.available.collateral[0].nTotal);
        arrAmt.push(parseFloat(element.data.filter(x => x.sDescription == 'Total Trading Power Limit')[0].nTotal));

      });

      this.totalPurchasingPower = Math.max.apply(Math, arrAmt);
      this.totalPurchasingPower = parseFloat(this.totalPurchasingPower).toFixed(2);
      // this.totalCash = parseFloat(this.totalCash).toFixed(2);
      // this.totalCollatral = parseFloat(this.totalCollatral).toFixed(2);
      // this.totalMargin = ((parseFloat(this.totalPurchasingPower) - parseFloat(this.totalCash) - parseFloat(this.totalCollatral)));
      // this.totalMargin = parseFloat(this.totalMargin).toFixed(2);
      // this.totalBuyingPower = ((parseFloat(this.totalCash) + parseFloat(this.totalCollatral) + parseFloat(this.totalMargin))).toFixed(2);
      clsGlobal.User.totalBuyingPower = this.totalPurchasingPower;// this.totalBuyingPower;
      this.kFormatter(this.totalPurchasingPower);
      clsGlobal.pubsub.publish('MENU_DYNAMIC');

    } catch (error) {
      //console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'calculateFunds',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getBalanceInfo() {
    try {

      this.transactionService.getPeridiocityWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {
          this.periodicityWisefundsDetails = balanceData.data;
          clsGlobal.User.fundsDetails.periodicityWisefundsDetails = balanceData.data;
          this.calculateFunds();
        }

      }, error => {
        console.log(error)
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getBalanceInfo',error.Message,undefined,error.stack,undefined,undefined));
      });

      // this.transactionService.getProductWiseBalanceInfo().then((balanceData: any) => {
      //   if (balanceData.status == 'success') {
      //     //this.productWisefundsDetails = balanceData.data;
      //     clsGlobal.User.fundsDetails.productWisefundsDetails = balanceData.data;
      //   }

      // }, error => {
      //   console.log(error)
      // });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PortfolioPage', 'getBalanceInfo2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


}
