import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { clsConstants } from './../../Common/clsConstants';
import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { OperationType } from 'src/app/Common/clsConstants';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';

@Component({
  selector: 'app-marektnews',
  templateUrl: './marektnews.page.html',
})
export class MarektnewsPage implements OnInit {
  filterPopup: boolean = false;
  NewsdetailsPopup: boolean = false;
  showMoreLessScrip: boolean = false;
  cardNews: any = [];
  dcTrendingScrip: Dictionary<any> = new Dictionary<any>();
  bcastHandler: any;
  lstScripKey: any = [];
  heading: any;
  details: any;
  date: any;
  cardNewsDetails: any = [];
  depthNewsDetails: any = [];
  otherNews: any = [];
  cardOrNewsDetails: any;
  //showExpandHeader: boolean = false;
  selectedScripObj: any = [];
  whatshotlist: any = [];
  whatsHotNewsDetails: any = [];
  cmotMode: any;
  statusMode: any = "HotPursuit";
  showLoader: boolean = false;
  showIndices: boolean = false;
  showSelectpopup: boolean = false;
  showAnnouncementDetails: boolean = false;

  announcementExchange: string = clsConstants.CDS_NSE;
  announcementList: any = [];
  pageSize: any = 10;
  iPageNo: any = clsConstants.CDS_PAGE_NO;
  sectorList: any = [];
  tempSectorList: any = [];
  sectorNews: any = [];
  sectorDetailsPopup: boolean = false;
  noDataFound: boolean = false;
  selectedSector: any = "";
  sectorNewsDescription: any = '';
  sectorHeading: any = '';
  sectorDate: any = '';
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  searchTextEntered: string = '';
  subscription: any;
  infiniteScroll: any;
  loadMoreData: boolean = false;
  visibleIndex = -1;
  sectorCode: any = '';

  constructor(public navCtrl: NavController,
    public objHttpService: clsHttpService,
    public objToast: ToastServicesProvider,
    private paramService: NavParamService,
    public objCDSService: CDSServicesProvider) { }

  ngOnInit() {
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.cmotMode = clsGlobal.CMOTMode;
    this.statusMode = this.cmotMode != 1 ? "HotPursuit" : "News";
    if (this.cmotMode == 1) {
      this.getSectorList();
    }
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
  }

  ionViewWillEnter() {
    this.cardNews = clsGlobal.cardNewsLst;
    this.dcTrendingScrip = clsGlobal.trendingNewsLst;
    this.cardNewsDetails = clsGlobal.cardNewsDetails;
    this.depthNewsDetails = clsGlobal.depthNewsDetails;
    this.whatshotlist = clsGlobal.EventListScrip;
    for (let counter = 0; counter < this.whatshotlist.length; counter++) {
      this.whatshotlist[counter].LTP = "0.00";
      this.whatshotlist[counter].NetChangeInRs = "0.00";
      this.whatshotlist[counter].PercNetChange = "0.00";
      this.whatshotlist[counter].LTPTrend = "";
    }
    let scrip = this.dcTrendingScrip.Values()
    for (let count = 0; count < scrip.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.MktSegId = scrip[count].scripKey._MktSegId;
      objScrpKey.token = scrip[count].scripKey.token;
      this.lstScripKey.push(objScrpKey);
    }
    for (let count = 0; count < this.whatshotlist.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.MktSegId = this.whatshotlist[count].scripDet._MktSegId;
      objScrpKey.token = this.whatshotlist[count].scripDet.token;
      this.lstScripKey.push(objScrpKey);
    }
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
  }

  whatsHotNews(item) {
    this.getWhatsHotScripNews(item.scripDet._MktSegId, item.scripDet.token, 10)
  }

  getWhatsHotScripNews(mktSegId: any, token: any, count: any) {
    try {
      let exchangeName = clsTradingMethods.getApiExchangeName(mktSegId);;
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {
          this.whatsHotNewsDetails = [];
          for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
            let element = data.ResponseObject.resultset[index];
            let newsDetail: any = {};
            newsDetail.Heading = element.Heading.trim();
            newsDetail.ArtText = element.ArtText.trim();
            newsDetail.Date = element.Date.trim();
            newsDetail.CompanyCode = element.CompanyCode.trim();
            newsDetail.Count = index;

            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
            this.whatsHotNewsDetails.push(newsDetail);
          }
          this.NewsdetailsPopup = true;
          this.otherNews = [];
          this.heading = this.whatsHotNewsDetails[0].Heading;
          this.details = this.whatsHotNewsDetails[0].ArtText;
          this.date = this.whatsHotNewsDetails[0].Date;
          this.cardOrNewsDetails = 'whatshot';

          for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
            if ((this.whatsHotNewsDetails[0].CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (this.whatsHotNewsDetails[0].Count != this.whatsHotNewsDetails[count].Count)) {
              this.otherNews.push(this.whatsHotNewsDetails[count]);
            }
          }
        }
      }).catch(error => {
        clsGlobal.logManager.writeErrorLog('MarketMainPage', 'getScripNews1', error);
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getWhatsHotScripNews2', error);
      console.log("Error  MarketMain_getWhatsHotScripNews2 " + error);
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('MarketNewsPage', 'sendTouchlineRequest', error);
    }
  }

  ionViewWillLeave() {
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
  }

  showfilter() {
    this.filterPopup = !this.filterPopup;
  }

  closeNews() {
    this.NewsdetailsPopup = false;
    this.showMoreLessScrip = false;
  }



  showdetailsNews(item) {
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'news'

    for (let count = 0; count < this.depthNewsDetails.length; count++) {
      if ((item.CompanyCode == this.depthNewsDetails[count].CompanyCode) && (item.Count != this.depthNewsDetails[count].Count)) {
        this.otherNews.push(this.depthNewsDetails[count]);
      }
    }
  }

  showdetailsCardNews(item) {
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'card'

    for (let count = 0; count < this.cardNewsDetails.length; count++) {
      if ((item.CompanyCode == this.cardNewsDetails[count].CompanyCode) && (item.SNo != this.cardNewsDetails[count].SNo)) {
        this.otherNews.push(this.cardNewsDetails[count]);
      }
    }
  }


  showmoreLess() {
    this.showMoreLessScrip = !this.showMoreLessScrip;
  }

  goBack() {
    this.navCtrl.pop();
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

    // console.log("obj", objMultiTLResp)
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        let scripDetail = this.dcTrendingScrip.getItem(objMultiTLResp.Scrip.toString())
        if (scripDetail != undefined && scripDetail.scripKey.token == objMultiTLResp.Scrip.token
          && scripDetail.scripKey.MktSegId == objMultiTLResp.Scrip.MktSegId) {
          nFormat = 2;

          scripDetail.LTP = objMultiTLResp.LTP;
          scripDetail.ClosePrice = objMultiTLResp.ClosePrice;

          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
          scripDetail.NetChangeInRs = arrNetChange[0];
          scripDetail.PercNetChange = arrNetChange[1];
          scripDetail.LTPTrend = arrNetChange[2];
          scripDetail.arrowTrend = arrNetChange[3];
        }

        for (let counter = 0; counter < this.whatshotlist.length; counter++) {
          if (this.whatshotlist[counter].scripDet._MktSegId == objMultiTLResp.Scrip.MktSegId &&
            this.whatshotlist[counter].scripDet.token == objMultiTLResp.Scrip.token) {
            this.whatshotlist[counter].LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');

            this.whatshotlist[counter].NetChangeInRs = arrNetChange[0];
            this.whatshotlist[counter].PercNetChange = arrNetChange[1];
            this.whatshotlist[counter].LTPTrend = arrNetChange[2];
          }
        }

      }
    }
    catch (error) {
      console.log('MarketNewsPage', 'receiveTouchlineResponse', error);
    }

  }

  showdetailsWhatsHotNews(item) {
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'whatshot';

    for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
      if ((item.CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (item.Count != this.whatsHotNewsDetails[count].Count)) {
        this.otherNews.push(this.whatsHotNewsDetails[count]);
      }
    }
  }

  //  scrollContent(event) {
  //   if (event.detail.scrollTop > 80) {
  //     this.showExpandHeader = true;
  //   }
  //   if (event.detail.scrollTop < 50) {
  //     this.showExpandHeader = false;
  //   }
  // }

  scripInfo(scripobj) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(scripobj.scripKey.MktSegId),
          token: scripobj.scripKey.token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let objScrpKey = new clsScripKey();

        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        objScrpKey.token = this.selectedScripObj.nToken;

        let scripInfo: clsScrip = new clsScrip();
        scripInfo.scripDet = objScrpKey;
        scripInfo.symbol = this.selectedScripObj.sSymbol.trim();
        scripInfo.Series = this.selectedScripObj.sSeries;
        scripInfo.DecimalLocator = this.selectedScripObj.DecimalLocator == "0" ? "100" : this.selectedScripObj.DecimalLocator;
        scripInfo.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        scripInfo.ExpiryDate = (this.selectedScripObj.nExpiryDate1 != null && this.selectedScripObj.nExpiryDate1.toString() != "" && this.selectedScripObj.nExpiryDate1.toString() != "0") ? this.selectedScripObj.nExpiryDate1 : "0";
        scripInfo.OptionType = this.selectedScripObj.sOptionType;
        scripInfo.MarketLot = this.selectedScripObj.nRegularLot;
        scripInfo.PriceTick = this.selectedScripObj.nPriceTick;
        scripInfo.SecurityDesc = this.selectedScripObj.sSecurityDesc;
        scripInfo.MWSecurityDesc = this.selectedScripObj.MWSecurityDesc;
        scripInfo.StrikePrice = this.selectedScripObj.nStrikePrice1.toString();
        scripInfo.ISIN = this.selectedScripObj.sISINCode;
        scripInfo.SPOS = "";
        scripInfo.POS = "";
        scripInfo.AssetToken = this.selectedScripObj.nAssetToken;
        scripInfo.FIILimit = this.selectedScripObj.nFIILimit;
        scripInfo.NRILimit = this.selectedScripObj.nNRILimit;
        scripInfo.MarginTypeIndicator = this.selectedScripObj.nMarginTypeIndicator;
        if (this.selectedScripObj.sInstrumentName.indexOf('IDX') != -1) {
          scripInfo.isIndex = true;
        }
        else {
          scripInfo.isIndex = false;
        }

        scripInfo.formatScripDisplayName()

        let idData = new clsIndexDetail();
        idData.scripDetail = scripInfo;

        this.paramService.myParam = idData.scripDetail;
        this.navCtrl.navigateForward(["/scripinfo"]);

      }).catch(error => {
        this.objToast.showAtBottom("Unable to get Scrip Info");
        clsGlobal.logManager.writeErrorLog('MarketmainPage', 'scripInfo', error);
      });
    } catch (error) {
      this.objToast.showAtBottom("Unable to get Scrip Info")
      console.log(error);
    }
  }

  searchNews() {
    this.paramService.myParam = this.statusMode;
    if (this.statusMode == 'News') {
      this.paramService.pageData = this.sectorNews;
    } else if (this.statusMode == 'Announcement') {
      this.paramService.pageData = this.announcementList;
    }
    this.navCtrl.navigateForward(["/marketnews-lookup"]);
  }

  eventChanged(event) {
    this.statusMode = event.detail.value;
    this.noDataFound = false;
    this.loadMoreData = false;
    if (this.statusMode == "News") {
      this.showLoader = true;
      if (this.sectorNews.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.sectorNews = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getSectorList();
      }
    } else if (this.statusMode == "Announcement") {
      this.showLoader = true;
      if (this.announcementList.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.announcementList = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getAnnouncementData();
      }

    } else if (this.statusMode == "HotPursuit") {
      this.ionViewWillEnter();
    }
  }

  getAnnouncementData() {
    try{
    this.showLoader = true;
    let requestString = "/" + this.announcementExchange + "/" + this.iPageNo + "/" + this.pageSize
    this.objCDSService
      .getAnnouncement(requestString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS && objresponse.ResponseObject.recordcount > 0) {
            this.showLoader = false;
            this.noDataFound = false;
            for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
              let element = objresponse.ResponseObject.resultset[i];
              let announcement: any = {};
              announcement.Caption = element.Caption.trim();
              announcement.CompanyCode = element.CompanyCode.trim();
              announcement.CompanyName = element.CompanyLongName.trim();
              announcement.Date = element.Date.split("-")[0] + " " + element.Date.split("-")[1] + "' " + element.Date.split("-")[2].substring(2, 4);
              announcement.Memo = element.Memo.trim();
              announcement.ScripData_BSE = element.ScripData_BSE;
              announcement.ScripData_NSE = element.ScripData_NSE;
              announcement.Symbol = element.Symbol;
              this.announcementList.push(announcement);
            }
            this.loadMoreData = true;
          } else {
            this.noDataFound = true;
            this.showLoader = false;
            this.loadMoreData = false;
          }
        } catch (error) {
          //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getAnnouncementData_1", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getAnnouncementData_1',error.Message,undefined,error.stack,undefined,undefined));
          this.showLoader = false;
          this.noDataFound = true;
          this.loadMoreData = false;
        }
      })
      .catch(error => {
        this.loadMoreData = false;
        this.showLoader = false;
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getAnnouncementData_2", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getAnnouncementData_2',error.Message,undefined,error.stack,undefined,undefined));
      });
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getAnnouncementData_3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getSectorList() {
    if (this.sectorList.length == 0) {
      this.showLoader = true;
      let iPageNo = "-";
      let pageSize = "-";
      let requestString = iPageNo + "/" + pageSize + "/";
      this.objCDSService
        .getSectorList(requestString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS && objresponse.ResponseObject.recordcount > 0) {
              this.showLoader = false;
              this.noDataFound = false;
              this.sectorList = objresponse.ResponseObject.resultset;
              this.tempSectorList = this.sectorList;
              this.selectedSector = this.sectorList[0].SectorName;
              this.sectorCode = this.sectorList[0].SectorCode;
              this.getSectorNews(this.sectorCode);
            } else {
              this.showLoader = false;
              this.noDataFound = true;
            }
          } catch (error) {
            this.showLoader = false;
            this.noDataFound = true;
            //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorList_1", error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorList_1',error.Message,undefined,error.stack,undefined,undefined));
          }
        })
        .catch(error => {
          this.showLoader = false;
          this.noDataFound = true;
          //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorList_2", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorList_2',error.Message,undefined,error.stack,undefined,undefined));
        });
    }
  }

  /**
* Api call to get all sector specific news.
*/
  getSectorNews(sectCode) {
    this.showLoader = true;
    let requestString = sectCode + "/" + this.iPageNo + "/" + this.pageSize + "/";

    this.objCDSService.getSectorWiseNews(requestString).then((resp: any) => {
      try {
        if (resp.ResponseObject.type.toUpperCase() == "SUCCESS" && resp.ResponseObject.recordcount > 0) {
          this.showLoader = false;
          this.noDataFound = false;
          for (let i = 0; i < resp.ResponseObject.resultset.length; i++) {
            let element = resp.ResponseObject.resultset[i];
            let sectorSpecificNews: any = {};
            sectorSpecificNews.Caption = element.Caption.trim();
            sectorSpecificNews.Heading = element.Heading.trim();
            sectorSpecificNews.SNo = element.SNo.trim();
            sectorSpecificNews.Date = element.Date.split("-")[0] + " " + element.Date.split("-")[1] + "' " + element.Date.split("-")[2].substring(2, 4);
            sectorSpecificNews.SectorName = element.SectorName.trim();
            sectorSpecificNews.Time = element.Time;
            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            sectorSpecificNews.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
            this.sectorNews.push(sectorSpecificNews);
          }
          this.loadMoreData = true;

        }
        else {
          this.showLoader = false;
          this.noDataFound = true;
          this.loadMoreData = false;
        }
      } catch (error) {
        this.loadMoreData = false;
        this.showLoader = false;
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNews_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorNews_1',error.Message,undefined,error.stack,undefined,undefined));
      }

    }).catch(error => {
      this.loadMoreData = false;
      this.showLoader = false;
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNews_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorNews_2',error.Message,undefined,error.stack,undefined,undefined));
    });

  }

  showIndicesPopUp() {
    this.showIndices = !this.showIndices;
  }

  selectPopup() {
    this.showSelectpopup = !this.showSelectpopup;
  }

  loadNewsAsperSector(sector) {
    try{
    this.showIndices = !this.showIndices;
    this.sectorNews = [];
    this.selectedSector = sector.SectorName;
    this.sectorCode = sector.SectorCode;
    this.iPageNo = clsConstants.CDS_PAGE_NO;
    this.getSectorNews(sector.SectorCode);
  } catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'loadNewsAsperSector',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  exchangeSelect(exchange) {
    this.showSelectpopup = !this.showSelectpopup;
    this.announcementExchange = exchange;
    this.announcementList = [];
    this.iPageNo = clsConstants.CDS_PAGE_NO;
    this.getAnnouncementData();
  }


  /**
  * Api call to get description of sector specific news.
  */
  getSectorNewsDescription(sNo: any) {
    this.showLoader = true;
    let requestString = sNo + "/";
    this.objCDSService.getSectorWiseNewsDetails(requestString).then((resp: any) => {
      try {
        if (resp.ResponseObject.type.toUpperCase() == "SUCCESS" && resp.ResponseObject.recordcount > 0) {
          this.sectorNewsDescription = resp.ResponseObject.resultset[0].ArtText;
          this.sectorHeading = resp.ResponseObject.resultset[0].Heading;
          let date = resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[0] + "/" + clsCommonMethods.getNumericMonth(resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[1].toUpperCase()) + "/" + resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[2] + " " + this.getTimeFormat(resp.ResponseObject.resultset[0].Time)
          this.sectorDate = date;
          this.showLoader = false;
          this.noDataFound = false;
        }
        else {
          this.noDataFound = true;
          this.showLoader = false;
        }
      } catch (error) {
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorNewsDescription_1',error.Message,undefined,error.stack,undefined,undefined));
      }

    }).catch(error => {
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getSectorNewsDescription_2',error.Message,undefined,error.stack,undefined,undefined));
      this.showLoader = false;
    });

  }

  showSectorDescription(sector) {
    this.sectorDetailsPopup = !this.sectorDetailsPopup;
    this.getSectorNewsDescription(sector.SNo);
  }

  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Convert time into PM and AM format .
*/
  getTimeFormat(time: any) {
    try{
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time + ' PM';
    } else {
      retTime = time + ' AM';
    }
    return retTime;
  } catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getTimeFormat',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeSectorNews() {
    this.NewsdetailsPopup = false;
    this.sectorDetailsPopup = false;
    this.sectorNewsDescription = '';
    this.sectorHeading = '';
    this.sectorDate = '';
  }


  showAnnouncement(i) {
    if (this.visibleIndex === i)
      this.visibleIndex = -1;
    else
      this.visibleIndex = i;
  }



  search($event) {
    if ($event) {
      this.searchText = $event;
      this.searchTextChanged.next($event);
    }
  }

  getValues(search) {
    try {
      this.searchTextEntered = search.toUpperCase().trim();
      let indicesData = this.sectorList;
      let filteredIndices = this.tempSectorList.filter(x => {
        return (x.SectorName).toUpperCase().indexOf(this.searchTextEntered.toUpperCase().trim()) !== -1
      });
      if (filteredIndices.length > 0) {
        this.sectorList = filteredIndices;
      } else {
        this.sectorList = indicesData;
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



  doInfinite(event) {
    try{
    setTimeout(() => {
      event.target.complete();
      this.infiniteScroll = event;
      this.fetchDetails(true);
    }, 500);
  } catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  fetchDetails(fromScrolling: boolean = false) {
    try {
      if (this.statusMode == "HotPursuit") {
        return;
      }
      else if (this.statusMode == "News") {
        if (this.sectorNews.length <= 0 || fromScrolling) {
          this.iPageNo += 1;
          if (this.iPageNo >= 2) {
            this.iPageNo = this.iPageNo;
          }
          else {
            this.iPageNo = clsConstants.CDS_PAGE_NO;
          }
          this.getSectorNews(this.sectorCode);
        }
      }
      else if (this.statusMode == "Announcement") {
        if (this.announcementList.length <= 0 || fromScrolling) {
          this.iPageNo += 1;
          if (this.iPageNo >= 2) {
            this.iPageNo = this.iPageNo;
          }
          else {
            this.iPageNo = clsConstants.CDS_PAGE_NO;
          }
          this.getAnnouncementData();
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketNewsPage', 'fetchDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketNewsPage', 'fetchDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
