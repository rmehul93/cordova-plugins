import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MarektnewsPageRoutingModule } from './marektnews-routing.module';

import { MarektnewsPage } from './marektnews.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MarektnewsPageRoutingModule
  ],
  declarations: [MarektnewsPage]
})
export class MarektnewsPageModule {}
