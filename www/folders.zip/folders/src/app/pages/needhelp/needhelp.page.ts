import { Component, OnInit, ViewChild } from '@angular/core';
import {  NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http'; 


import { IonContent } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsConstants } from 'src/app/Common/clsConstants';
@Component({
  selector: 'app-needhelp',
  templateUrl: './needhelp.page.html',
})
export class NeedhelpPage implements OnInit {
  needHelpData = [];
  needhelpQuestion : any;
  id : any;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  constructor(public navCtrl: NavController,   public http: HttpClient, 
    private navParams: NavParamService) { 
   }

  ngOnInit() { 
    if(this.navParams.myParam!=null && this.navParams.myParam!=undefined){
      this.needHelpData=this.navParams.myParam.helpData;
      this.needhelpQuestion = this.needHelpData[this.navParams.myParam.selectedQ];
    }
    else{
    this.http.get(clsGlobal.S3BucketPath + 'config/needhelp.json').subscribe((res: any) => {
      this.needHelpData=res.NeedHelp;
    },
      (err) => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('NeedhelpPage', 'ngOnInit',err.Message,undefined,err.stack,undefined,undefined));
      }); 
    }
  }
  ionViewDidEnter() {
   if(this.needhelpQuestion != undefined)
    this.scrollToLabel(this.needhelpQuestion.ID)    
  }
  goBack() {
    this.navCtrl.pop();
  }
  scrollToLabel(label) {
    try { 
    var titleELe = document.getElementById(label); 
    this.content.scrollToPoint(0, titleELe.offsetTop, 2000);
  
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('NeedhelpPage', 'scrollToLabel',error.Message,undefined,error.stack,undefined,undefined));
    }
  } 
  gotoPage(queButton){
    try{
    if(queButton == this.needhelpQuestion.queButton){
    this.navCtrl.navigateForward(this.needhelpQuestion.url)
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('NeedhelpPage', 'gotoPage',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
 
}
