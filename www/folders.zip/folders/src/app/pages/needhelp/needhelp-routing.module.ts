import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NeedhelpPage } from './needhelp.page';

const routes: Routes = [
  {
    path: '',
    component: NeedhelpPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NeedhelpPageRoutingModule {}
