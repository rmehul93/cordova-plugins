import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NeedhelpPageRoutingModule } from './needhelp-routing.module';

import { NeedhelpPage } from './needhelp.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NeedhelpPageRoutingModule
  ],
  declarations: [NeedhelpPage]
})
export class NeedhelpPageModule {}
