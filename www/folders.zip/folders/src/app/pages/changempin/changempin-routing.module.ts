import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChangempinPage } from './changempin.page';

const routes: Routes = [
  {
    path: '',
    component: ChangempinPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChangempinPageRoutingModule {}
