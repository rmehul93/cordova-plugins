import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { AlertServicesProvider } from '../../providers/alert-services/alert-services';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsConstants } from 'src/app/Common/clsConstants';
import { AuthenticationService } from 'src/app/providers/authentication.service';
@Component({
  selector: 'app-changempin',
  templateUrl: './changempin.page.html',
  styleUrls: ['./changempin.page.scss'],
})
export class ChangempinPage implements OnInit {
  isForgetMPIN: boolean = false;
  otpValue: number;
  changeMpinLoader: boolean = false;
  loginClicked: boolean = false;
  newMPIN: string = '';
  oldMPIN:string='';
  confirmMPIN: string = '';
  userID: string = "";
  groupId: string = "";
  oldmpinErr: any='';
  newmpinErr: any='';
  confirmmpinErr: any='';
  
  constructor(public activatedRoute: ActivatedRoute,
    public router: Router,
    public http: clsHttpService,
    public alertservice: AlertServicesProvider,
    private toastCtrl: ToastServicesProvider,
    public objStorage: clsLocalStorageService,
    private authService: AuthenticationService,
    public navCtrl: NavController
  ) {
    this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
      .then((item: any) => {
        try {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            this.userID = objMPIN.userId;
            this.groupId = objMPIN.groupId;
          }          
        } catch (error) {
          console.log(error);
        }
      }, error => {
        console.log('Error while retrieving local storage details.');
      });
  }
  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((res) => {
      if (res != undefined) {
        this.otpValue = res.otpvalue;
        console.log(res.otpvalue);
        this.isForgetMPIN = true;
      }
    });
  }
  changeSetMPIN() {
    try {
      let isValid = this.validateMPIN();
      if (!isValid) return;
      // if (!this.otpValue) {
      //   let errorMessage = "Invalid OTP. \n Kindly enter 6 digit OTP received on given mobile no.";
      //   this.alertservice.showAlert(errorMessage, 'OTP ERROR');
      //   return;
      // }
      /*let reqObj = {
        user_id: this.userID,
        otp: this.otpValue,
        mpin: this.newMPIN,
        mobile_udid: '',
        api_key: clsGlobal.apiKey,
        source: "WEBAPI"
      }
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + 'v1/user/mpin/reset/verify-otp', reqObj).subscribe((data: any) => {
        if (data.status) {
          if (data.code == "s-101") {
            // this.otpValue = '';
            // this.invalidOTPCnt = 0;
            this.otpVerified = !this.otpVerified;
            setTimeout(() => {
              this.router.navigate(['/mpinlogin'],);
            }, 2000);
          }
        }
      }, error => {
        if (error.status == "400") {
          if (error.error.message == "Incorrect OTP") {
            this.toastCtrl.showAtBottom(error.error.message);
            setTimeout(() => {
              this.router.navigate(['/forgetmpin']);
            }, 2000);
          } else {
            this.toastCtrl.showAtBottom(error.error.message);
          }
        }
        clsGlobal.logManager.writeErrorLog('ChangempinPage', 'changeSetMPIN', error);
      });
      */
      // this.otpVerified = true;

      let reqChangeMPINObj = {
        user_id: this.userID,
        old_mpin: this.oldMPIN,
        new_mpin: this.newMPIN, 
        api_key: clsGlobal.dConfigMaster.getItem("APP_ODIN_API_KEY"),
        source: "WEBAPI"
      };
      this.authService.changeMPIN(reqChangeMPINObj).then((response: any) => {
        if (response.status) {
          if (response.code == "s-101") {
            this.changeMpinLoader = !this.changeMpinLoader;
            clsGlobal.User.sessionId = '';
            setTimeout(() => {
              //page set to MPIN login after successfully MPIN changes.
              this.router.navigate(['/mpinlogin'],);
            }, 3000);
          }
        }
      }).catch(error => {
        this.loginClicked = false;
        this.toastCtrl.showWithButton(error);
      });
    /*
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + 'v1/user/mpin',reqChangeMPINObj).subscribe((data:any)=>{
        if (data.status) {
          if (data.code == "s-101") { 
            this.changeMpinLoader=!this.changeMpinLoader;
            setTimeout(() => {
              this.router.navigate(['/mpinlogin'],);
            }, 1000);
          }
        }
      }, error => {
        if (error.status == "400") {
          this.toastCtrl.showAtBottom(error.error.message);
          // if (error.error.message == "Incorrect OTP") {
          //   this.toastCtrl.showAtBottom(error.error.message);
          //   setTimeout(() => {
          //     this.router.navigate(['/forgetmpin']);
          //   }, 2000);
          // } else {
          //   this.toastCtrl.showAtBottom(error.error.message);
          // }
        }
        clsGlobal.logManager.writeErrorLog('ChangempinPage', 'changeSetMPIN', error);
      });
       */
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangempinPage', 'changeSetMPIN', error);
    }
  }
  validateMPIN() {
    try {
      this.confirmmpinErr = '';
      this.newmpinErr='';
      this.confirmmpinErr ='';
      if (this.oldMPIN == '' || this.oldMPIN.length < 6) {
        // this.toastCtrl.showAtBottom("Please enter valid MPIN.");
        this.oldmpinErr = "Please enter valid Old MPIN.";
        return false;
      }
      if (this.newMPIN == '' || this.newMPIN.length < 6) {
        // this.toastCtrl.showAtBottom("Please enter valid MPIN.");
        this.newmpinErr = "Please enter valid New MPIN.";
        return false;
      }
      if ((this.newMPIN !== this.confirmMPIN) || (this.confirmMPIN == '' || this.confirmMPIN.length < 6)) {
        // this.toastCtrl.showAtBottom("Confirm MPIN should be same as New MPIN.");
        this.confirmmpinErr = "Confirm MPIN should be same as New MPIN.";
        return false;
      }
      return true;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ChangempinPage', 'validateMPIN', error);
    }
  }
  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.newmpinErr='';
      this.oldmpinErr = '';
      this.confirmmpinErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'onKeyUp', error);
    }
  }
  goBack() {
    this.navCtrl.pop();
  }
  onOldPinCodeComplete(event: any) {
    console.log("OLD "+event);
    this.oldMPIN = event;
    // if(this.oldMPIN.length>0)
    // this.loginClicked = true;
    if(this.oldMPIN.length==6 && this.newMPIN.length==6 && this.confirmMPIN.length == 6)
    this.loginClicked = true;
    else
    this.loginClicked = false;
    //console.log('old mpin: -' + event);
    // if (this.oldMPIN != 'null' && this.oldMPIN.length == 6 && this.newMPIN.length < 6) {
    //   let input: HTMLElement = document.querySelectorAll('.pinCodeInput').item(6) as HTMLElement;
    //   input.focus();
    // }
  }

  onNewPinCodeComplete(event: any) {
    console.log("NEW "+event);
    this.newMPIN = event;
    // if(this.newMPIN.length>0)
    // this.loginClicked = true;
    if(this.oldMPIN.length==6 && this.newMPIN.length==6 && this.confirmMPIN.length == 6)
    this.loginClicked = true;
    else
    this.loginClicked = false;
    // if (this.newMPIN != 'null' && this.newMPIN.length == 6 && this.confirmMPIN.length < 6) {
    //   let input: HTMLElement = document.querySelectorAll('.pinCodeInput').item(12) as HTMLElement;
    //   input.focus();
    // }
  }

  onConfirmPinCodeComplete(event: any) {
    console.log("CONFIRM "+event);
    this.confirmMPIN = event;
    this.confirmmpinErr = '';
    // if(this.confirmMPIN.length>0)
    // this.loginClicked = true;
    if(this.oldMPIN.length==6 && this.newMPIN.length==6 && this.confirmMPIN.length == 6)
    this.loginClicked = true;
    else
    this.loginClicked = false;
  }
}
