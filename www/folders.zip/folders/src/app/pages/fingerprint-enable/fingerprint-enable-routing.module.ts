import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FingerprintEnablePage } from './fingerprint-enable.page';

const routes: Routes = [
  {
    path: '',
    component: FingerprintEnablePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FingerprintEnablePageRoutingModule {}
