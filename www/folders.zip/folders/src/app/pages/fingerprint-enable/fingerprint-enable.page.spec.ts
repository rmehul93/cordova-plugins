import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FingerprintEnablePage } from './fingerprint-enable.page';

describe('FingerprintEnablePage', () => {
  let component: FingerprintEnablePage;
  let fixture: ComponentFixture<FingerprintEnablePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FingerprintEnablePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FingerprintEnablePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
