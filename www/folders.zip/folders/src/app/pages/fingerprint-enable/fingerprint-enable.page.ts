import { AuthenticationService } from 'src/app/providers/authentication.service';
import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from "@ionic/angular";
import { Router } from '@angular/router';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsGlobal, clsPluginConstants } from '../../Common/clsGlobal';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { AlertServicesProvider } from '../../providers/alert-services/alert-services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { Platform } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { NavParamService } from 'src/app/providers/nav-param.service';


@Component({
  selector: 'app-fingerprint-enable',
  templateUrl: './fingerprint-enable.page.html',
  styleUrls: ['./fingerprint-enable.page.scss'],
})
export class FingerprintEnablePage implements OnInit {
  mobile: string = '';
  disableGenerate: boolean = true;
  showOtp: boolean = false;
  timerId: any;
  enableGenerate: boolean = false;
  generateOtpText = 'Generate OTP';
  userID: any;
  otp: any;
  maxInvalidOTPAttempt: number = 3;
  invalidOTPCnt: number = 0;
  disableSubmit: boolean = false;
  mobileDisaply: any = '******';
  isFirstTime: boolean = false;
  emailId: string = '';
  timerStarted: boolean = false;
  timerValue: number = 0;
  isAndroid: boolean = false;
  ShowOTPConfirm: boolean = false;
  enterManualOTP: boolean = false;
  otpVerified: boolean = false;
  enableSubmit: boolean = false;
  enableVerifyOtp: boolean = false;
  otpErr: any = '';
  isFingerPrintSelected: boolean = false;
  mobile_udid: any = '';
  type: any;
  groupId: string = "";
  constructor(private navCtrl: NavController,
    public http: clsHttpService,
    private toastCtrl: ToastServicesProvider,
    public alertservice: AlertServicesProvider,
    private loaderCtrl: LoaderServicesProvider,
    public objStorage: clsLocalStorageService,
    public platform: Platform,
    public router: Router,
    private paramService: NavParamService,
    private authService: AuthenticationService,
    public modalCtrl: ModalController,) { }

  ngOnInit() {
    try {
      this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length > 0) {
        this.maxInvalidOTPAttempt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT));
      }
      this.isAndroid = this.platform.is('android');
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'ngOnInit', e);
    }
  }

  ionViewWillEnter() {
    try {
      this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
        .then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            this.userID = objMPIN.userId;
            this.isFingerPrintSelected = objMPIN.Fingerprint == 'Y' ? true : false;
          }
          this.getUserDetails();
        }, error => {
          this.loaderCtrl.hideLoader();
          clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'ionViewWillEnter', error);
        });
    } catch (error) {
      console.log(error);
    }
  }

  getUserDetails() {
    try {
      this.authService.getUserInfo(this.userID).then((resp: any) => {
        console.log(resp);
        if (resp.status == true) {
          let userDetails = resp['result'];
          this.mobile = clsCommonMethods.TripleDESDecrypt(userDetails.mobile);
          this.mobileDisaply = this.mobile.substr(0,2)+this.mobileDisaply+ this.mobile.substr(8, 2);
          this.emailId = clsCommonMethods.TripleDESDecrypt(userDetails.email);
          this.enableSubmit = true;
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        this.loaderCtrl.hideLoader();
        clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'getUserDetails_1', error);
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'getUserDetails_2', error);
    }
  }

  RegenerateOTP() {
    this.ShowOTPConfirm = !this.ShowOTPConfirm;
    this.sendOTP();
  }

  sendOTP_og()//Reset MPIN Request send for OTP generation.
  {
    try {
      this.ShowOTPConfirm = !this.ShowOTPConfirm;
      if (this.isAndroid) {
        this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
        this.startTimer();
      }
      let reqOTPGenerate = {
        user_id: this.userID,
        api_key: clsGlobal.apiKey,
        source: "WEBAPI"
      };
      this.authService.resetPasswordOtpGenerate(reqOTPGenerate).then((resp: any) => {
        if (resp.status == "success") {
          this.enableGenerate = false;
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'sendOTP', error);
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'sendOTP', error);
    }
  }

  sendOTP() {
    try {
      this.ShowOTPConfirm = !this.ShowOTPConfirm;
      if (this.isAndroid) {
        this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
        this.startTimer();
      }
      let reqOTPGenerate = {
        mobileNo: this.mobile,
        reqType: 1// 1 --> generateOTP
      };
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + 'v1/getOTP', reqOTPGenerate)
        .subscribe(respData => {
          if (respData.status) {
            this.enableGenerate = false;
          } else {
            this.toastCtrl.showAtBottom('error while generating otp');
          }
        }, error => {
          this.toastCtrl.showAtBottom(error);
        });
    } catch (error) {
      this.toastCtrl.showAtBottom(error);
      clsGlobal.logManager.writeErrorLog('FingerprintEnablePage', 'getOTP', error);
    }
  }

  EnterManualOTP() {
    this.enterManualOTP = !this.enterManualOTP;
    this.otp = '';
  }

  startTimer() {
    try {
      this.timerStarted = true;
      this.timerId = setTimeout(function () {
        if (this.timerValue == 0) {
          // this.generateOtpText = 'Regenerate OTP';
          this.enableGenerate = true;
          this.otp = '';
          // this.showOtp = false;
          // this.disableSubmit = true;
          // this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));
          this.timerStarted = false;
        }
        else {
          this.timerValue--;
          this.startTimer();
        }
      }.bind(this), 1000);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'startTimer', error);
    }
  }

  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.otpErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'onKeyUp', error);
    }
  }

  checkOTPEnter(event) {
    try {
      this.enableVerifyOtp = event.target.value.trim().length == 6 ? true : false;
      this.otpErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("FingerprintEnable", "checkOTPEnter", error.message);
    }
  }

  verifyOTPRestAPI() // send Reset password request for OTP verification and new password creation.
  {
    this.enterManualOTP = !this.enterManualOTP;
    this.ShowOTPConfirm = !this.ShowOTPConfirm;
    try {
      let reqFingerprintEnableObj = {
        OTP: this.otp,
        userId: this.userID,
        mobileNo: this.mobile,
        reqType: 3
      }
      this.authService.fingerprintEnable(reqFingerprintEnableObj).then((resp: any) => {
        if (resp.status) {
          let fingerPrintRequest: any = {};
          this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
            .then((item: any) => {
              if (item != undefined) {
                let objMPIN: any = JSON.parse(item);
                this.groupId = objMPIN.groupId;
                this.type = 'fng';
                fingerPrintRequest.Udid = clsPluginConstants.DeviceUDID;
                objMPIN.MPINEnable = 'Y';
                objMPIN.Fingerprint = 'Y';
                this.getLoginRequestObjectForFingerPrint(this.type, fingerPrintRequest.Udid);
                this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
                this.otp = '';
                this.toastCtrl.showAtBottom("FingerPrint login is now enable on your device.");
                clsGlobal.logManager.writeUserAnalytics("FingerprintEnablePage", "FingerPrint Enable Success", "ENALBE", "Success");
                this.modalCtrl.dismiss(true);
                this.otpVerified = !this.otpVerified;
                let pageSource = "fingerprint-enable";
                this.paramService.myParam = pageSource;
                this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_SETTING);
              }
            });

        }
        else {
          this.otp = '';
          this.otpErr = "Incorrect OTP";
          this.ShowOTPConfirm = true;
          this.enterManualOTP = true;
          this.toastCtrl.showAtBottom("Incorrect OTP");
        }

      }).catch(error => {
        console.log(error)
        this.toastCtrl.showAtBottom(error);
        if (error == "Incorrect OTP.") {
          this.otp = '';
          this.otpErr = "Incorrect OTP";
          this.ShowOTPConfirm = true;
          this.enterManualOTP = true;
        }
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('FingerprintEnable', 'verifyOTPRestAPI', error);
    }
  }

  goBack() {
    let pageSource = "goback";
    this.paramService.myParam = pageSource;
    this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_SETTING);
    this.navCtrl.pop();
  }

  /**
  * @param opttype : to set operation type in service type:fng
  * @param udid : send udid in request
  */

  getLoginRequestObjectForFingerPrint(opttype: any, udid: string) {
    let fingerPrintRequest: any = {};
    // let MPIN = this.newMPIN;// this.pin1 + this.pin2 + this.pin3 + this.pin4;
    fingerPrintRequest.groupId = this.groupId;
    fingerPrintRequest.userId = this.userID;
    fingerPrintRequest.deviceType = clsGlobal.DeviceType;
    fingerPrintRequest.loginType = 'fingerprint';
    fingerPrintRequest.type = opttype;
    fingerPrintRequest.udid = udid;
    this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + 'v1/setMPIN', fingerPrintRequest).subscribe((response: any) => { })
    //return mpinRequest;
  }
}
