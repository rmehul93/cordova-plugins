import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FingerprintEnablePageRoutingModule } from './fingerprint-enable-routing.module';

import { FingerprintEnablePage } from './fingerprint-enable.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FingerprintEnablePageRoutingModule
  ],
  declarations: [FingerprintEnablePage]
})
export class FingerprintEnablePageModule {}
