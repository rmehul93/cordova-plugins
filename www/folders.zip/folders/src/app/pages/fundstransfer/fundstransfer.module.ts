import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { FundstransferPageRoutingModule } from './fundstransfer-routing.module';
import { FundstransferPage } from './fundstransfer.page';
import { DirectiveSharedModule } from '../../directives/directive.shared.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FundstransferPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [FundstransferPage]
})
export class FundstransferPageModule {}
