import { TransactionService } from 'src/app/providers/transaction.service';
import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';

@Component({
  selector: 'app-fundstransfer',
  templateUrl: './fundstransfer.page.html',
})
export class FundstransferPage implements OnInit {
  showResult: boolean = false;
  showAccounts: boolean = false;
  selectedFundsItem: any;
  productWisefundsDetails: any = [];
  filterproductWisefundsDetails: any = [];
  selectedProductForFundTransfer: any;
  selectedProductNameForFundTransfer: any;
  transferAmount: any;
  numberortell: any = "tel";
  constructor(private navCtrl: NavController,
    private toastCtrl: ToastServicesProvider,
    private transactionService: TransactionService,
    private loaderCtrl: LoaderServicesProvider,
    private navParamService: NavParamService) {
    this.selectedFundsItem = navParamService.myParam;
  }

  ngOnInit() {
    try {
      this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;

      for (let index = 0; index < this.productWisefundsDetails.length; index++) {
        this.productWisefundsDetails[index].balanceAmountDisplay =
          clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
      }

      if (!this.selectedFundsItem) {
        this.selectedFundsItem = this.productWisefundsDetails[0];
      }
      this.getMappedProduct();
      //this.filterproductWisefundsDetails = this.productWisefundsDetails.filter(elemnt => elemnt != this.selectedFundsItem);
      // this.selectedProductForFundTransfer = this.filterproductWisefundsDetails[0];
      // this.selectedProductNameForFundTransfer = this.selectedProductForFundTransfer.sProductName
    } catch (error) {
      console.log(error);
    }
  }

  goBack() {
    //this.navCtrl.pop();
    this.navCtrl.navigateBack('fundsmain');
  }

  closeResult() {
    this.showResult = false;
  }

  requestForTransfer() {
    try {
      //console.log(this.selectedFundsItem)
      if (!this.transferAmount || isNaN(parseFloat(this.transferAmount)) || parseFloat(this.transferAmount) == 0) {
        this.toastCtrl.showAtBottom("Fund transfer amount cannot be 0. Please try again with a different value!")
        return;
      }

      if (parseFloat(this.transferAmount) > parseFloat(this.selectedFundsItem.balanceAmount)) {
        this.toastCtrl.showAtBottom("Transfer amount should be less than the avalible amount")
        return;
      }

      if (this.selectedProductForFundTransfer == undefined) {
        this.toastCtrl.showAtBottom("To Transfer not avalible.")
        return;
      }

      this.loaderCtrl.showLoader(true);
      this.transactionService.transferFunds(this.selectedFundsItem.sProductId, this.selectedProductForFundTransfer.sProductId, this.transferAmount).then((response: any) => {
        if (response.status == "success") {
          setTimeout(() => {
            this.showResult = true;
            this.loaderCtrl.hideLoader();
          }, 2000);

          //clsGlobal.User.fundsDetails = [];
          this.getBalanceInfo();
        } else {
          this.loaderCtrl.hideLoader();
          this.toastCtrl.showAtBottom("Fund Transfer Failed")
          //this.showResult = true;
        }

      }, (error) => {
        this.loaderCtrl.hideLoader();
      })
    } catch (error) {
      console.log(error);
      this.loaderCtrl.hideLoader();
    }
  }
  clickAccounts() {
    this.showAccounts = !this.showAccounts;
  }

  getMappedProduct() {
    try {
      this.transactionService.mappedProduct(this.selectedFundsItem.sProductId).then((response: any) => {
        if (response.status == "success") {
          //this.filterproductWisefundsDetails = response.data;
          this.filterproductWisefundsDetails = [];
          for (let index = 0; index < response.data.length; index++) {
            const element = response.data[index];
            let product = this.productWisefundsDetails.filter(elemnt => elemnt.sProductId == element.nToProductId);
            //to display amount in readable format.
            

            if (product.length > 0) {
              //product.balanceAmountDisplay = clsCommonMethods.kFormatter(product.balanceAmount);
              this.filterproductWisefundsDetails.push(product[0])
            }
          }

          if (this.filterproductWisefundsDetails.length > 0) {
            this.selectedProductForFundTransfer = this.filterproductWisefundsDetails[0];
            this.selectedProductNameForFundTransfer = this.selectedProductForFundTransfer.sProductName;
          }

        } else {
          this.toastCtrl.showAtBottom("Fund Transfer Failed")
          //this.showResult = true;
        }
      })
    } catch (error) {

    }
  }

  setFundSelection(fundsItem) {
    try {

      this.showAccounts = !this.showAccounts;
      this.selectedFundsItem = fundsItem;
      this.getMappedProduct();
      //this.filterproductWisefundsDetails = this.productWisefundsDetails.filter(elemnt => elemnt != this.selectedFundsItem);
      this.selectedProductForFundTransfer = this.filterproductWisefundsDetails[0];
      this.selectedProductNameForFundTransfer = this.selectedProductForFundTransfer.sProductName;
    } catch (error) {

    }
  }

  selectProductForFundTransfer(selectedProductForFundTransfer: any) {
    //console.log("gg", selectedProductForFundTransfer)
    this.selectedProductForFundTransfer = selectedProductForFundTransfer;
    this.selectedProductNameForFundTransfer = this.selectedProductForFundTransfer.sProductName
  }

  getBalanceInfo() {
    try {

      this.transactionService.getPeridiocityWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {

          clsGlobal.User.fundsDetails.periodicityWisefundsDetails = balanceData.data;

          this.transactionService.getProductWiseBalanceInfo().then((balanceData: any) => {
            if (balanceData.status == 'success') {
              this.productWisefundsDetails = balanceData.data;
              for (let index = 0; index < this.productWisefundsDetails.length; index++) {
                this.productWisefundsDetails[index].balanceAmountDisplay =
                  clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
              }
              clsGlobal.User.fundsDetails.productWisefundsDetails = this.productWisefundsDetails;
            }

          }, error => {
            console.log(error)
          });

        }

      }, error => {
        console.log(error)
      });


    } catch (error) {
      console.log(error);
    }
  }

}
