import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FundstransferPage } from './fundstransfer.page';

const routes: Routes = [
  {
    path: '',
    component: FundstransferPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FundstransferPageRoutingModule {}
