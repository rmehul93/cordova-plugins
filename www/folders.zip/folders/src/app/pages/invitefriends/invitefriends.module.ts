import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InvitefriendsPageRoutingModule } from './invitefriends-routing.module';

import { InvitefriendsPage } from './invitefriends.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InvitefriendsPageRoutingModule
  ],
  declarations: [InvitefriendsPage]
})
export class InvitefriendsPageModule {}
