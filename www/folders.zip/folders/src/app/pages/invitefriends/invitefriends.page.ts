import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular'; 
import { clsConstants } from 'src/app/Common/clsConstants';
//import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { BrowserServicesProvider } from 'src/app/providers/browser-services/browser-services';

@Component({
  selector: 'app-invitefriends',
  templateUrl: './invitefriends.page.html', 
})
export class InvitefriendsPage implements OnInit {
  showinvitePopup:boolean = false;
  referDetails: string="";

  constructor(private navCtrl: NavController,
    private iab: BrowserServicesProvider
    ) { }

  ngOnInit() {
    console.log("Invite Friends page.");
    try {
      this.referDetails=clsGlobal.dConfigMaster.getItem("APP_INVITE_FRIENDS_DETAILS") || "Refer friends to recieve prize.";  

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('InvitefriendsPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  goBack()
  {
      this.navCtrl.pop();
  }
  openInvitationLink()
  {
    try {
      let _url=clsGlobal.dConfigMaster.getItem("APP_INVITE_FRIENDS_URL") || "about:blank";
      this.iab.openBrowser('SSO', _url, 1);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('InvitefriendsPage', 'openInvitationLink',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
 /**
  clickinvitePopup(){
    //this.showinvitePopup = !this.showinvitePopup;
    this.shareThisApp('SMS');
  }
 
   * Share This app method,
   * this method return appstore link for both ios and android.
   * for ios need to set apple reg id.
  
  shareThisApp(via) {
    //this.navCtrl.pop();
    try {
      let iosAppId='';
    if(clsGlobal.dConfigMaster.getItem("APP_IOS_APP_ID") != undefined)
      {
        iosAppId = clsGlobal.dConfigMaster.getItem("APP_IOS_APP_ID");
      }
      else
      {
        iosAppId = 'id1140100974';
      }
    var mktUrl = "http://play.google.com/store/apps/details?id=" + clsPluginConstants.AppPackageName.toString();
    mktUrl = mktUrl + "&utm_source=android";

    var GoogleLink = ". 'A complete market app'.Download for free Google App Store : " + mktUrl;
    var AppStoreLink = "Apple App Store : 'itms-apps://itunes.apple.com/in/app/nirmalbangbeyond/"+iosAppId+"'";

    this.socialSharing.share(GoogleLink + " " + AppStoreLink, clsPluginConstants.AppName + " New Trading Application","","")
    .then(function (result) {
    }, function (err) {
      clsGlobal.logManager.writeErrorLog('InviteFriends', 'shareThisApp', err);
    });
    //WILL DO IT LATER>
    // if(via=="SMS"){
    //   this.socialSharing.shareViaSMS(GoogleLink + " " + AppStoreLink + clsPluginConstants.AppName + " New Mobile Trading Application", "", this.shareSuccessCallBack,this.shareErrorCallBack);
    
    // }
    // else if(via="EMAIL"){
    //   this.socialSharing.shareViaEmail(GoogleLink + " " + AppStoreLink , clsPluginConstants.AppName + " New Mobile Trading Application", "", this.shareSuccessCallBack,this.shareErrorCallBack);
    
    // }
    // else if(via=="WA"){

    // }
    // else if(via=="FB"){
      
    // }
    // else if(via=="IG"){
      
    // }
    // else if(via=="TWEET"){
      
    // }
    // else{
    //   //do nothing as this are the selected option , will update more when added.
    // }
    } catch (error) {
      console.log("Error in sharing "+error.message);
    }

  }
  shareSuccessCallBack(result)
  {
    console.log("Success call back"+result)
  }
  shareErrorCallBack(msg)
  {
    console.log("Error in sharing"+msg);
  }
 */
}
