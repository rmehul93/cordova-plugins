import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';

@Component({
    selector: 'app-fundsavailable',
    templateUrl: './fundsavailable.page.html',
})
export class FundsavailablePage implements OnInit {


    tt: any = [
        {
            "id": "8589934591",
            "name": "All Exchange Combined",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 7760,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 7760
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 10100,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 10100
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": -2340,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": -2340
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 7660,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 7660
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 10100,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 10100
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": -2340,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": -2340
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        },
        {
            "id": "164225",
            "name": "Commodity Combined",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 50050,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 50050
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 50050,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 50050
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 50000,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 50000
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 50050,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 50050
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        },
        {
            "id": "18451",
            "name": "All Equity Combined ",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 17700,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 17700
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 20040,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 20040
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": -2340,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": -2340
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 17660,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 17660
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 20020,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 20020
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 20,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 20
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": -2340,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": -2340
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        },
        {
            "id": "12397",
            "name": "All Derivatives Combined",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 30296.54,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 30296.54
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 30296.54,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 30296.54
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 30000,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 30000
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 30030,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 30030
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 266.54,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 266.54
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        },
        {
            "id": "66561",
            "name": "Currency Combined",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 40040,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 40040
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 40040,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 40040
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 40000,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 40000
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 40040,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 40040
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        },
        {
            "id": "3",
            "name": "NSE Equities",
            "net_available": [
                {
                    "sSign": "",
                    "sDescription": "Net Available Funds",
                    "nTrading": 1010,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 1010
                }
            ],
            "total_available": [
                {
                    "sSign": " ",
                    "sDescription": "Total Trading Power Limit",
                    "nTrading": 1010,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 1010
                }
            ],
            "total_utilization": [
                {
                    "sSign": "",
                    "sDescription": "Total Utilization",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "total_withdrawable": [
                {
                    "sSign": "",
                    "sDescription": "For Allocation/Withdrawal",
                    "nTrading": 1000,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 1000
                }
            ],
            "net_payin_payout": [
                {
                    "sSign": "ADD",
                    "sDescription": "Funds Transferred Today",
                    "nTrading": 0,
                    "nIPO": 0,
                    "nMF": 0,
                    "nTotal": 0
                }
            ],
            "available": {
                "cash": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Deposit",
                        "nTrading": 1010,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 1010
                    }
                ],
                "collateral": [
                    {
                        "sSign": "ADD",
                        "sDescription": "Collateral",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Credit For Sale",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_credit_for_sale": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    },
                    {
                        "sSign": "",
                        "sDescription": "Option CFS",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ]
            },
            "utilised": {
                "limit": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Limit Utilization",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_realised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "Booked Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "pnl_unrealised": [
                    {
                        "sSign": "LESS",
                        "sDescription": "MTM Profit/Loss",
                        "nTrading": 0,
                        "nIPO": 0,
                        "nMF": 0,
                        "nTotal": 0
                    }
                ],
                "option_premium": 0
            }
        }
    ]

    selPeriodicity: any;
    periodicityWisefundsDetails: any = [];

    constructor(public navCtrl: NavController,
        private route: ActivatedRoute) {
        this.selPeriodicity = this.route.snapshot.queryParams.periodicity != undefined ? this.route.snapshot.queryParams.periodicity : null;
    }

    ngOnInit() {
    }

    ionViewWillEnter() {
        try {
            // if (clsGlobal.User.fundsDetails && clsGlobal.User.fundsDetails.periodicityWisefundsDetails) {
            //     this.periodicityWisefundsDetails = clsGlobal.User.fundsDetails.periodicityWisefundsDetails;
            //     this.calculateFunds();
            // }
            this.periodicityWisefundsDetails.push(this.selPeriodicity);
            this.calculateFunds();

        } catch (error) {

        }
    }

    cashDesposit: any = 0;
    notionalDeposit: any = 0;
    adhocDeposit: any = 0;
    overdraftLimit: any = 0;
    miscDeposit: any = 0;
    manualCollateral: any = 0;

    totalDeposit: any = 0;

    DP_collateral: any = 0;
    pool_collateral: any = 0;
    SAR_collateral: any = 0;
    DP_pledged_collateral: any = 0;
    pool_pledged_collateral: any = 0;
    max_collateral_limit: any = 0;

    totalCollateral: any = 0;

    FTDTotal: any = 0;
    FWTotal: any = 0;
    CFSTotal: any = 0;
    DPCFS: any = 0;
    PoolCFS: any = 0;
    SARCFS: any = 0;
    MaxCFSLimit: any = 0;

    OptionCFS: any = 0;
    MaxOptionCFSLimit: any = 0;

    totalTradingPowerLimit: any = 0;
    multiplier: any = 0;
    limitUtilization: any = 0;
    bookedPnL: any = 0;
    mtmPnL: any = 0;
    totalUtilization: any = 0;
    netAvlbFunds: any = 0;
    allocWithdrawal: any = 0;

    calculateFunds() {
        try {

            this.periodicityWisefundsDetails.forEach(element => {

                this.cashDesposit += parseFloat(element.data.filter(x => x.sDescription == 'Cash Deposit')[0].nTrading);
                this.notionalDeposit += parseFloat(element.data.filter(x => x.sDescription == 'Notional Deposit')[0].nTrading);
                this.overdraftLimit += parseFloat(element.data.filter(x => x.sDescription == 'Overdraft Limit')[0].nTrading);
                this.miscDeposit += parseFloat(element.data.filter(x => x.sDescription == 'Misc. Deposit')[0].nTrading);
                this.manualCollateral += parseFloat(element.data.filter(x => x.sDescription == 'Manual Collateral')[0].nTrading);
                this.adhocDeposit += parseFloat(element.data.filter(x => x.sDescription == 'Adhoc Deposit')[0].nTrading);


                this.totalDeposit += parseFloat(element.data.filter(x => x.sDescription == 'Deposit')[0].nTrading);

                this.DP_collateral += parseFloat(element.data.filter(x => x.sDescription == 'DP Collateral')[0].nTrading);
                this.pool_collateral += parseFloat(element.data.filter(x => x.sDescription == 'Pool Collateral')[0].nTrading);
                this.SAR_collateral += parseFloat(element.data.filter(x => x.sDescription == 'SAR Collateral')[0].nTrading);
                this.DP_pledged_collateral += parseFloat(element.data.filter(x => x.sDescription == 'DP Pledged Collateral')[0].nTrading);
                this.pool_pledged_collateral += parseFloat(element.data.filter(x => x.sDescription == 'Pool Pledged Collateral')[0].nTrading);
                this.max_collateral_limit += parseFloat(element.data.filter(x => x.sDescription == 'Maximum Collateral Limit')[0].nTrading);

                this.totalCollateral += parseFloat(element.data.filter(x => x.sDescription == 'Collateral')[0].nTrading);
                this.FTDTotal += parseFloat(element.data.filter(x => x.sDescription == 'Funds Transferred Today')[0].nTrading);
                this.FWTotal += parseFloat(element.data.filter(x => x.sDescription == 'Funds withdrawal/Allocation')[0].nTrading);
                this.CFSTotal += parseFloat(element.data.filter(x => x.sDescription == 'Credit For Sale')[0].nTrading);

                this.DPCFS += parseFloat(element.data.filter(x => x.sDescription == 'DP CFS')[0].nTrading);
                this.PoolCFS += parseFloat(element.data.filter(x => x.sDescription == 'Pool CFS')[0].nTrading);
                this.SARCFS += parseFloat(element.data.filter(x => x.sDescription == 'SAR CFS')[0].nTrading);
                this.MaxCFSLimit += parseFloat(element.data.filter(x => x.sDescription == 'Maximum CFS Limit')[0].nTrading);

                this.OptionCFS += parseFloat(element.data.filter(x => x.sDescription == 'Option CFS')[0].nTrading);
                this.MaxOptionCFSLimit += parseFloat(element.data.filter(x => x.sDescription == 'Maximum Option CFS')[0].nTrading);

                this.totalTradingPowerLimit += parseFloat(element.data.filter(x => x.sDescription == 'Total Trading Power Limit')[0].nTotal);
                this.multiplier += parseFloat(element.data.filter(x => x.sDescription == 'Multiplier')[0].nTrading);
                this.limitUtilization += parseFloat(element.data.filter(x => x.sDescription == 'Limit Utilization')[0].nTotal);
                this.bookedPnL += parseFloat(element.data.filter(x => x.sDescription == 'Booked Profit/Loss')[0].nTotal);
                this.mtmPnL += parseFloat(element.data.filter(x => x.sDescription == 'MTM Profit/Loss')[0].nTotal);
                this.totalUtilization += parseFloat(element.data.filter(x => x.sDescription == 'Total Utilization')[0].nTotal);
                this.netAvlbFunds += parseFloat(element.data.filter(x => x.sDescription == 'Net Available Funds')[0].nTotal);
                this.allocWithdrawal += parseFloat(element.data.filter(x => x.sDescription == 'For Allocation/Withdrawal')[0].nTotal);


            });

            this.cashDesposit = parseFloat(this.cashDesposit).toFixed(2);
            this.notionalDeposit = parseFloat(this.notionalDeposit).toFixed(2);
            this.overdraftLimit = parseFloat(this.overdraftLimit).toFixed(2);
            this.miscDeposit = parseFloat(this.miscDeposit).toFixed(2);
            this.manualCollateral = parseFloat(this.manualCollateral).toFixed(2);
            this.adhocDeposit = parseFloat(this.adhocDeposit).toFixed(2);

            this.totalDeposit = parseFloat(this.totalDeposit).toFixed(2);

            this.DP_collateral = parseFloat(this.DP_collateral).toFixed(2);
            this.pool_collateral = parseFloat(this.pool_collateral).toFixed(2);
            this.SAR_collateral = parseFloat(this.SAR_collateral).toFixed(2);
            this.DP_pledged_collateral = parseFloat(this.DP_pledged_collateral).toFixed(2);
            this.pool_pledged_collateral = parseFloat(this.pool_pledged_collateral).toFixed(2);
            this.max_collateral_limit = parseFloat(this.max_collateral_limit).toFixed(2);

            this.totalCollateral = parseFloat(this.totalCollateral).toFixed(2);

            this.FTDTotal = parseFloat(this.FTDTotal).toFixed(2);
            this.FWTotal = parseFloat(this.FWTotal).toFixed(2);
            this.CFSTotal = parseFloat(this.CFSTotal).toFixed(2);
            this.DPCFS = parseFloat(this.DPCFS).toFixed(2);
            this.PoolCFS = parseFloat(this.PoolCFS).toFixed(2);
            this.SARCFS = parseFloat(this.SARCFS).toFixed(2);
            this.MaxCFSLimit = parseFloat(this.MaxCFSLimit).toFixed(2);

            this.OptionCFS = parseFloat(this.OptionCFS).toFixed(2);
            this.MaxOptionCFSLimit = parseFloat(this.MaxOptionCFSLimit).toFixed(2);

            this.totalTradingPowerLimit = parseFloat(this.totalTradingPowerLimit).toFixed(2);
            this.multiplier = parseFloat(this.multiplier).toFixed(2);
            this.limitUtilization = parseFloat(this.limitUtilization).toFixed(2);
            this.bookedPnL = parseFloat(this.bookedPnL).toFixed(2);
            this.mtmPnL = parseFloat(this.mtmPnL).toFixed(2);
            this.totalUtilization = parseFloat(this.totalUtilization).toFixed(2);
            this.netAvlbFunds = parseFloat(this.netAvlbFunds).toFixed(2);
            this.allocWithdrawal = parseFloat(this.allocWithdrawal).toFixed(2);

        } catch (error) {
            console.log(error);
        }
    }

    getDetailsData(type, name, index) {
        try {
            if (this.periodicityWisefundsDetails.length > 0) {
                let value = parseFloat(this.periodicityWisefundsDetails[0].data.filter(x => x.sDescription == name)[index].nTrading);
                return value.toFixed(2);
            } else {
                return "0.00";
            }
        } catch (error) {
            return "0.00";
        }

    }

    goBack() {
        this.navCtrl.pop();
    }
}
