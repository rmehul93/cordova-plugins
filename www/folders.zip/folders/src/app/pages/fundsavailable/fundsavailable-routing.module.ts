import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FundsavailablePage } from './fundsavailable.page';

const routes: Routes = [
  {
    path: '',
    component: FundsavailablePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FundsavailablePageRoutingModule {}
