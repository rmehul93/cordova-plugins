import { clsAppConfigConstants } from './../../Common/clsAppConfigConstants';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { clsGlobal, clsPluginConstants } from '../../Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsConstants } from 'src/app/Common/clsConstants';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-setmpin',
  templateUrl: './setmpin.page.html',
})
export class SetmpinPage implements OnInit {
  isVerified: boolean = false;
  newMPIN: string = '';
  confirmMPIN: string = '';
  mpinErr: any;
  confirmMpinErr: any;
  isFingerAuthAvailable: boolean = false;
  isFingerPrintSelected: boolean = false;
  termsSelected: boolean = false;
  openTermsconditions: boolean = false;
  termsConditionData: any = '';

  constructor(private router: Router,
    private platform: Platform,
    public http: clsHttpService,
    //public faio: FingerprintAIO,
    private toastCtrl: ToastServicesProvider,
    public objStorage: clsLocalStorageService,
    public translate: TranslateService) {
    this.verifyFingerPrintOnDevice();
  }

  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will set Terms and Conditions text .
   */
  ngOnInit() {
    this.getTermsConditionsData();
  }

  /**
   * @method : Returns terms and conditions data from CDN Server
   */
  getTermsConditionsData() {
    try {
      //this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + "TermsCondition.txt").subscribe((respData: any) => {
      this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH)  + clsGlobal.LocalComId + 'v1/' + "TermsCondition.txt").subscribe((respData: any) => {
          this.termsConditionData = respData;
      }, error => {
        //console.log("Error in getTermsConditionsData : " + error);
        //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'getTermsConditionsData_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getTermsConditionsData_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'getTermsConditionsData_1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'getTermsConditionsData_2',error.Message,undefined,error.stack,undefined,undefined));

    }
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will retrieve user details from local storage .
   */
  ionViewWillEnter() {
    try {
      this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
        .then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            objMPIN.MPINEnable = 'Y';
            this.isFingerPrintSelected = objMPIN.Fingerprint == 'Y' ? true : false;
            objMPIN.mpinInvalidAttempt = 0;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
      //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'ionViewWillEnter', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will set Mpin and fingerprint (If available) after first time successfull traditional login
   */
  setMPIN() {
    try {
      let isValid = this.validateMPIN();
      if (!isValid) return;
      let mpinRequest: any = {
        mpin: this.newMPIN,
      };
      if (!this.isFingerPrintSelected) {
        mpinRequest.mobile_udid = null;
      }
      else {
        mpinRequest.mobile_udid = clsPluginConstants.DeviceUDID;
      }
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.versionId + '/user/mpin', mpinRequest).subscribe((data: any) => {
        if (data.status) {
          if (data.code == "s-101") {
            this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
              .then((item: any) => {
                if (item != undefined) {
                  let objMPIN: any = JSON.parse(item);
                  objMPIN.MPINEnable = 'Y';
                  objMPIN.Fingerprint = this.isFingerPrintSelected ? 'Y' : 'N';
                  objMPIN.mpinInvalidAttempt = 0;
                  this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
                }
              });
            setTimeout(() => {
              this.router.navigate(['./create-watch-list']);
            }, 2000);
            this.isVerified = true;
          }

        }
      }, error => {
        if (error.status == "400") {
          this.toastCtrl.showAtBottom(error.error.message);
        }
        //clsGlobal.ConsoleLogging("Error", "setMPIN_1", error);
        //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'setMPIN_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'setMPIN_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "setMPIN_2", error);
      //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'setMPIN_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'setMPIN_2',error.Message,undefined,error.stack,undefined,undefined));
    }

  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will Validate user input credentials
   */
  validateMPIN() {
    try {
      if (this.newMPIN == '' || this.newMPIN.length < 6) {
        this.mpinErr = "Please enter valid MPIN.";
        return false;
      }

      if (this.newMPIN != this.confirmMPIN) {
        this.confirmMpinErr = "Confirm MPIN should be same as New MPIN.";
        return false;
      }
      return true;
    } catch (error) {
     // clsGlobal.ConsoleLogging("Error", "validateMPIN", error);
     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'validateMPIN',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will clear error text below input box
   */
  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.mpinErr = '';
      this.confirmMpinErr = '';
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('SetmpinPage', 'onKeyUp', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'onKeyUp',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19344
   * @description : This method will Check fingerprint available on device or not
   */
  verifyFingerPrintOnDevice() {
    try {
      if (this.platform.is('cordova')) {
        this.isFingerAuthAvailable = false;
      } else {
        //on local fingerprint will not available.
        this.isFingerAuthAvailable = false;

      }
    } catch (error) {
      this.isFingerAuthAvailable = false;
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SettingsPage', 'verifyFingerPrintOnDevice_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onNewPinCodeComplete(event: any) {
    this.newMPIN = event;
    // if (this.newMPIN != 'null' && this.newMPIN.length == 6 && this.confirmMPIN.length < 6) {
    //   let input: HTMLElement = document.querySelectorAll('.pinCodeInput').item(6) as HTMLElement;
    //   input.focus();
    // }
    this.confirmMpinErr = '';
    this.mpinErr = '';
  }

  onConfirmPinCodeComplete(event: any) {
    this.confirmMPIN = event;
    this.confirmMpinErr = '';
    this.mpinErr = '';
  }

  termsConditionsClick(event) {
    this.termsSelected != this.termsSelected;
  }
  showTermsconditions() {
    this.openTermsconditions = !this.openTermsconditions;
  }
}
