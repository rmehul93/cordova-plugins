import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetmpinPageRoutingModule } from './setmpin-routing.module';

import { SetmpinPage } from './setmpin.page';
import { ComponentsModule } from 'src/app/components/components.module';
import { CodeInputModule } from 'angular-code-input';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetmpinPageRoutingModule,
    TranslateModule,ComponentsModule,CodeInputModule
  ],
  declarations: [SetmpinPage]
})
export class SetmpinPageModule {}
