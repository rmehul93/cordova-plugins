import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateWatchListExistingPageRoutingModule } from './create-watch-list-existing-routing.module';

import { CreateWatchListExistingPage } from './create-watch-list-existing.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateWatchListExistingPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [CreateWatchListExistingPage]
})
export class CreateWatchListExistingPageModule {}
