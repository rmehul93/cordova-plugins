import { Component, OnInit } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular';
import { clsHttpService } from "src/app/Common/clsHTTPService";
import { HttpClient } from "@angular/common/http";
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { ActivatedRoute, NavigationExtras } from '@angular/router';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';

@Component({
  selector: 'app-create-watch-list-existing',
  templateUrl: './create-watch-list-existing.page.html',
})
export class CreateWatchListExistingPage implements OnInit {

  IsWatchListExist: boolean = true;
  profileList = [];
  profileName = "";
  showLoader = false;
  showBackBtton = true;
  constructor(private navCtrl: NavController,
    private objHttpService: clsHttpService,
    private http: HttpClient,
    private paramService: NavParamService,
    private localstorageservice: clsLocalStorageService,
    public popoverController: PopoverController,
    public toastProvider: ToastServicesProvider,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService,
    private route: ActivatedRoute) {
    this.showBackBtton = route.snapshot.queryParams.showBackButton != undefined ? false : true;
  }

  ngOnInit() {
    try {

      this.watchlistServ.getGlobalWatchlistProfile().then((dataProfile: any) => {
        this.profileList = [];
        for (let index = 0; index < dataProfile.length; index++) {
          const element = dataProfile[index];

          if (element.bIsPrivate.toString() == "false") {
            let watchProfile = {
              nWatchListId: element.nWatchListId,
              sWatchListName: element.sWatchListName,
              bIsPrivate: element.bIsPrivate,//"false",
              bIsDefault: element.bIsDefault,//"false",
              sCreatedBy: element.sUserId,
              nTenantId: element.sTenantId
            };
            this.profileList.push(watchProfile);
          }

        }
        //this.profileList = dataProfile.data[0];
      })
      // this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_GLOBAL_PROFILE).then(profile => {
      //   if (profile != undefined) {
      //     this.profileList = JSON.parse(profile);

      //   } else {
      //     //clsGlobal.VirtualDirectory
      //     this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsConstants.NONTRANSACTIONAL + clsConstants.C_S_API_GLOBAL_PROFILE_LIST).subscribe((respProfile: any) => {

      //       try {
      //         if (respProfile.status == "success") {
      //           //console.log('ProfileList: ' + respProfile.data[0]);
      //           this.profileList = respProfile.data[0];
      //           this.localstorageservice.setObject(clsConstants.LOCAL_STORAGE_GLOBAL_PROFILE, respProfile.data[0]);

      //           //if (this.route.snapshot.queryParams.showBackButton != undefined) {

      //             // this.watchlistServ.getAllWatchlistProfile().then((data) => {
      //             //   for (let index = 0; index < respProfile.data[0].length; index++) {
      //             //     const element = respProfile.data[0][index];
      //             //     this.dbService.isGlobalProfileScripExist(element.nWatchListId).then((dataExists) => {
      //             //       if (!dataExists) {

      //             //         let profileScrip = respProfile.data[1].filter((profileScrip, index, array) => {
      //             //           return profileScrip.nWatchListId == element.nWatchListId;
      //             //         });

      //             //         if (profileScrip.length > 0) {
      //             //           this.dbService.addWatchlistProfileScrip(profileScrip).then((data) => {

      //             //           });
      //             //         }

      //             //       }
      //             //     });

      //             //   }

      //             // }, error => {

      //             // });
      //           //}

      //         } else {

      //           this.toastProvider.showAtBottom(respProfile.errorString);
      //         }
      //       } catch (error) {

      //         clsGlobal.logManager.writeErrorLog("watchlist", "ngOnInit", error);
      //       }
      //     },
      //       (error: any) => {

      //       });
      //   }
      // });      
    } catch (error) {
      console.log(error);
    }
  }

  checForWatchlistProfile() {

  }

  AddScripFromLookUp() {
    try {
      if (this.profileName == undefined || this.profileName == '') {
        this.toastProvider.showAtBottom("Name is required to create the watchlist");
        return;
      }

      this.watchlistServ.getWatchlistProfile().then((profList: any) => {
        //this.selecteScrips =  profScrip.rows;
        if (profList != undefined) {

          let isProfileExist = profList.filter(item => {
            return item.sWatchListName.toUpperCase() == this.profileName.toUpperCase() && (item.sUserId == clsGlobal.User.userId || item.sUserId == "CHIEF")
          });

          if (isProfileExist.length != 0) {
            this.toastProvider.showAtBottom("Looks like this watchlist already exists. Try using a different name.");
            return;
          }

          if (this.profileName == 'My Holdings' || this.profileName == "Don't Miss") {
            this.toastProvider.showAtBottom("Watchlist name cannot rename as system name.");
            return;
          }

        }

        let maxProfile = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10')
        if (profList != undefined && profList.length > maxProfile) {
          //this.toastProvider.showAtBottom("Maximum " + maxProfile + " watchlists allowed.");
          this.toastProvider.showAtBottom("Watchlist limit reached! Try reviewing your watchlists!");


          return;
        }

        this.showLoader = true;

        setTimeout(() => {
          let navParam: NavigationExtras = {
            queryParams: { name: this.profileName, type: "NEW" }
          };
          this.navCtrl.navigateForward('lookup', navParam);
          this.showLoader = false;
        }, 500);


      }, (error) => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  creaeFromGlobalWatchlist(profileItem) {
    try {
      this.watchlistServ.getWatchlistProfile().then((profList: any) => {

        let maxProfile = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10')
        if (profList != undefined && profList.length > maxProfile) {
          this.toastProvider.showAtBottom(" Watchlist limit reached! Try reviewing your watchlists!");
          // this.toastProvider.showAtBottom("Maximum " + maxProfile + " watchlists allowed.");

          return;
        }

        this.showLoader = true;

        setTimeout(() => {
          let navParam: NavigationExtras = {
            queryParams: { profile: profileItem }
          };
          this.navCtrl.navigateForward('create-watch-list-global', navParam);
          this.showLoader = false;
        }, 500);



      }, (error) => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  goBack() {
    if (this.route.snapshot.queryParams.showBackButton != undefined) {
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
    } else {
      this.navCtrl.pop();
    }

    // this.navCtrl.navigateForward('watchlist');
  }

}
