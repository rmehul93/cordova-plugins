import { ComponentsModule } from 'src/app/components/components.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { IonicModule } from '@ionic/angular'; 
import { ForgetmpinPageRoutingModule } from './forgetmpin-routing.module'; 
import { ForgetmpinPage } from './forgetmpin.page';
import { TranslateModule } from '@ngx-translate/core';
import { CodeInputModule } from 'angular-code-input';


 
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ForgetmpinPageRoutingModule,
    TranslateModule ,
    ComponentsModule,
    CodeInputModule
  ],
  declarations: [ForgetmpinPage]
})
export class ForgetmpinPageModule {}
