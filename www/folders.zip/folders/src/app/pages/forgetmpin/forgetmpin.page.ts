import { clsPluginConstants } from './../../Common/clsGlobal';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";
import { Router } from '@angular/router';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsGlobal } from '../../Common/clsGlobal';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { AlertServicesProvider } from '../../providers/alert-services/alert-services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { TranslateService } from '@ngx-translate/core';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { Platform } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';

@Component({
  selector: 'app-forgetmpin',
  templateUrl: './forgetmpin.page.html',
})
export class ForgetmpinPage implements OnInit {
  mobile: string = '';
  disableGenerate: boolean = true;
  showOtp: boolean = false;
  timerId: any;
  enableGenerate: boolean = false;
  generateOtpText = 'Generate OTP';
  userID: any;
  otpValue: any;
  otp: any;
  maxInvalidOTPAttempt: number = 3;
  invalidOTPCnt: number = 0;
  disableSubmit: boolean = false;
  mobileDisaply: any = '******';
  isFirstTime: boolean = false;
  emailId: string = '';
  panNumber: any;
  timerStarted: boolean = false;
  timerValue: number = 0;
  isAndroid: boolean = false;
  showOTPConfirm: boolean = false;
  enterManualOTP: boolean = false;
  otpVerified: boolean = false;
  mpin: number;
  enableSubmit: boolean = false;
  enableVerifyOtp: boolean = false;

  newMPIN: string = '';
  confirmMPIN: string = '';
  mpinErr: any;
  confirmMpinErr: any;
  enableSetMpin: boolean = false;
  otpErr: any = '';
  isFingerPrintSelected: boolean = false;
  mobile_udid: any = '';
  hashCode: any; // to get hash key for msg
  emailDisplay: any = '*****'
  mobilenumber: any;

  constructor(private navCtrl: NavController,
    public http: clsHttpService,
    private toastCtrl: ToastServicesProvider,
    public alertservice: AlertServicesProvider,
    private loaderCtrl: LoaderServicesProvider,
    public translate: TranslateService,
    public objStorage: clsLocalStorageService,
    public platform: Platform,
    public router: Router,
    private authService: AuthenticationService,
    private smsRetriever: SmsRetriever) { }

  ngOnInit() {
    try {
      this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length > 0) {
        this.maxInvalidOTPAttempt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT));
      }
      this.isAndroid = this.platform.is('android');

    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'ngOnInit', e);
    }
  }

  ionViewWillEnter() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      //  this.translate.use(clsGlobal.defaultLanguage);
      this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
        .then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            this.userID = objMPIN.userId;
            this.isFingerPrintSelected = objMPIN.Fingerprint == 'Y' ? true : false;
            this.getUserDetails();
          }

        }, error => {
          this.loaderCtrl.hideLoader();
          clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'ionViewWillEnter', error);
        });
      // this.getHash();
    } catch (error) {
      console.log(error);
    }
  }

  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19348
   * @description : This method will get User details like mobile,email etc
   */
  getUserDetails() {
    try {
      this.authService.getUserInfo(this.userID).then((resp: any) => {
        console.log(resp);
        if (resp.status == true) {
          let userDetails = resp['result'];
          this.mobile = clsCommonMethods.TripleDESDecrypt(userDetails.mobile);
         this.mobilenumber = this.mobile.substr(0,2)+this.mobileDisaply+ this.mobile.substr(8, 2);
          this.emailId = clsCommonMethods.TripleDESDecrypt(userDetails.email);
          this.emailDisplay += this.emailId.substr(8, this.emailId.length)
          this.enableSubmit = true;
          if (this.mobile == "") {
            this.alertservice.showAlert('Mobile no not set.');
            this.enableSubmit = false;
            return;
          }
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        this.loaderCtrl.hideLoader();
        clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'getUserDetails_1', error);
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'getUserDetails_2', error);
    }
  }

  RegenerateOTP() {
    this.showOTPConfirm = !this.showOTPConfirm;
    this.sendOTP();
  }

  sendOTP()//Reset MPIN Request send for OTP generation.
  {
    try {
      this.showOTPConfirm = !this.showOTPConfirm;
      if (this.isAndroid) {
        this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER)) || 60;
        this.startTimer();
      }

      let reqOTPGenerate = {
        user_id: this.userID,
        api_key: clsGlobal.apiKey,
        source: "WEBAPI",
        hashCode: this.hashCode
      };
      this.authService.resetMpinOtpGenerate(reqOTPGenerate).then(async (resp: any) => {
        if (resp.status == "success") {
          this.enableGenerate = false;
          // await this.retrieveSMS();
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'sendOTP', error);
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'sendOTP', error);
    }
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19348
   * @description : This method will open manual otp enter part 
   */
  enterManuallyOTP() {
    this.enterManualOTP = !this.enterManualOTP;
    this.otp = '';
  }

  startTimer() {
    try {
      this.timerStarted = true;
      this.timerId = setTimeout(function () {
        if (this.timerValue == 0) {
          // this.generateOtpText = 'Regenerate OTP';
          this.enableGenerate = true;
          this.otp = '';
          // this.showOtp = false;
          // this.disableSubmit = true;
          // this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));
          this.timerStarted = false;
        }
        else {
          this.timerValue--;
          this.startTimer();
        }
      }.bind(this), 1000);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'startTimer', error);
    }
  }

  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.otpErr = '';
      this.mpinErr = '';
      this.confirmMpinErr = '';
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'onKeyUp', error);
    }
  }

  checkOTPEnter(event) {
    try {
      this.enableVerifyOtp = event.target.value.trim().length == 6 ? true : false;
      this.otpErr = '';

    } catch (error) {
      clsGlobal.logManager.writeErrorLog("ForgotMpinPage", "checkOTPEnter", error.message);
    }
  }

  changeSetMPIN() {
    try {
      let isValid = this.validateMPIN();
      if (!isValid) return;
      if (!this.isFingerPrintSelected) {
        this.mobile_udid = null;
      }
      else {
        this.mobile_udid = clsPluginConstants.DeviceUDID;
      }
      let reqSetMpinObj = {
        user_id: this.userID,
        otp: this.otpValue,
        mpin: this.newMPIN,
        mobile_udid: this.mobile_udid,
        api_key: clsGlobal.apiKey,
        source: "WEBAPI"
      }
      this.authService.forgotMpinChange(reqSetMpinObj).then((resp: any) => {
        if (resp.status == "success") {
          if (resp.code == "s-101") {
            this.otpVerified = !this.otpVerified;
            setTimeout(() => {
              this.router.navigate(['/mpinlogin'],);
            }, 2000);
          }
        }
      }).catch(error => { 
             
        if (error == "Incorrect OTP." || error=="OTP should be Numeric and should not contain special characters or underscores.") {
          this.otp = '';
          this.otpErr = "Incorrect OTP. Try again.";
          this.showOTPConfirm = true;
          this.enterManualOTP = true;
          this.enableSetMpin = !this.enableSetMpin;
          this.enableVerifyOtp = !this.enableVerifyOtp;
          this.newMPIN = '';
          this.confirmMPIN = '';
        } else if (error == "MPIN cannot be same as last 5 mpin") {
          this.newMPIN = '';
          this.confirmMPIN = '';
          this.toastCtrl.showAtBottom(error);
          setTimeout(() => {
            this.showOTPConfirm = false;
            this.enterManualOTP = false;
            this.otpVerified = false;
            this.enableSetMpin = false;
            this.enableGenerate = false;
          }, 1000);

        } else {
          this.toastCtrl.showAtBottom(error);
        }
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'changeSetMPIN', error);
    }

  }


  verifyOTPRestAPI() // send Reset MPIN request for OTP verification and new MPIN creation.
  {
    // display done  block.
    // this.otpVerified = !this.otpVerified;
    this.enterManualOTP = !this.enterManualOTP;
    this.showOTPConfirm = !this.showOTPConfirm;
    this.enableSetMpin = !this.enableSetMpin;
    this.otpValue = this.otp

    // this.router.navigate(['/changempin'], {
    //   queryParams: { otpvalue: this.otp },
    // });
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @USD : BT-19348
   * @description : Validation for entered mpin
   */
  validateMPIN() {
    try {
      if (this.newMPIN == '' || this.newMPIN.length < 6) {
        this.mpinErr = "Please enter valid MPIN.";
        return false;
      }

      if (this.newMPIN != this.confirmMPIN) {
        this.confirmMpinErr = "Confirm MPIN should be same as New MPIN.";
        return false;
      }
      return true;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('ForgotMpinPage', 'validateMPIN', error);
    }
  }

  /**
* Desc : This function is to get hash string of APP.
*  @return {Promise<string>} Returns a promise that resolves when successfully generate hash of APP.
*/
  getHash() {
    try {
      if (typeof (this.smsRetriever) === 'undefined') {
        // Error: plugin not installed
        console.log('SMSRetriever: plugin not present');
      }
      else {
        console.log('SMSRetriever: plugin present');
        this.smsRetriever.getAppHash().then((res: any) => {
          this.hashCode = res;
        })
          .catch((error: any) => {
            clsGlobal.logManager.writeErrorLog("ForgotMpinPage", "getHash_1", error);
          });
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("ForgotMpinPage", "getHash_2", error);
    }
  }

  /**
   * Desc : This function start wathching message arrive event and retrive message text.
   *  @return {Promise<string>} Returns a promise that resolves when retrives SMS text or TIMEOUT after 5 min.
   */
  async retrieveSMS() {
    try {
      if (typeof (this.smsRetriever) === 'undefined') {
        // Error: plugin not installed
        console.log('SMSRetriever: plugin not present');
      }
      else {
        console.log('SMSRetriever: plugin present');
        await this.smsRetriever.startWatching().then((res: any) => {
          // this.autoVerifyOTP  = true;
          this.otp = res.Message.toString().substr(0, 6);
        }).catch((error: any) => {
          clsGlobal.logManager.writeErrorLog("ForgotMpinPage", "retrieveSMS_1", error);
        });
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("ForgotMpinPage", "retrieveSMS_2", error);
    }
  }

  onNewPinCodeComplete(event: any) {
    this.newMPIN = event;
    // if (this.newMPIN != 'null' && this.newMPIN.length == 6 && this.confirmMPIN.length < 6) {
    //   let input: HTMLElement = document.querySelectorAll('.pinCodeInput').item(12) as HTMLElement;
    //   input.focus();
    // }
    this.confirmMpinErr = '';
    this.mpinErr = '';
  }

  onConfirmPinCodeComplete(event: any) {
    this.confirmMPIN = event;
    this.confirmMpinErr = '';
    this.mpinErr = '';
  }
}
