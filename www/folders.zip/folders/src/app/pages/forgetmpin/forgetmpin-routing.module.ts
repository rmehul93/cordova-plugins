import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ForgetmpinPage } from './forgetmpin.page';

const routes: Routes = [
  {
    path: '',
    component: ForgetmpinPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForgetmpinPageRoutingModule {}
