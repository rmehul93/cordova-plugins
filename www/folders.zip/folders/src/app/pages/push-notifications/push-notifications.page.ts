import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from './../../Common/clsHTTPService';
import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-push-notifications',
  templateUrl: './push-notifications.page.html',
  styleUrls: ['./push-notifications.page.scss'],
})
export class PushNotificationsPage implements OnInit {
  topicList: any = [];
  exchangePref: any;
  inAppNotificationPref: any;
  fcmTopicPref: any;
  profilePicPref: any;
  orderPref: any;
  notificationArray : any =[];

  constructor(private navCtrl: NavController,
    private httpService: clsHttpService,
    private toastCtrl: ToastServicesProvider,
    private appSync: AppsyncDbService) { }

  ngOnInit() {
    try{
      this.getFcmUserTopicDetails();
      console.log("Inside push notification");
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'ngOnInit', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillEnter() {
    try { 
      if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != "" && clsGlobal.User.userPreference != null) {
        this.exchangePref = clsGlobal.User.userPreference.sExchange;
        this.inAppNotificationPref = clsGlobal.User.userPreference.sInAppNotification;
        this.profilePicPref = clsGlobal.User.userPreference.sProfilePicPath;
        this.orderPref = clsGlobal.User.userPreference.sOrder;
        if (clsGlobal.User.userPreference.sNotification != '[]' && clsGlobal.User.userPreference.sNotification != null && clsGlobal.User.userPreference.sNotification != undefined && clsGlobal.User.userPreference.sNotification != "") {
          this.notificationArray = JSON.parse(clsGlobal.User.userPreference.sNotification);
          for(let i = 0; i <= this.notificationArray.length; i++ ){
            this.topicList.filter(x=>{
              if(this.notificationArray[i].TopicNo == x.TopicNo){
                x.Selected = this.notificationArray[i].Selected;
              }
            })
          }
        } 

      }
      else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res != null && res.length > 0) {
            clsGlobal.User.userPreference = res[0]; //set for revisit this page.
            this.exchangePref = res[0].sExchange;
            this.inAppNotificationPref = res[0].sInAppNotification;
            this.profilePicPref = res[0].sProfilePicPath;
            this.orderPref = res[0].sOrder;
            if (res[0].sNotification != '[]' && res[0].sNotification != null && res[0].sNotification != undefined && res[0].sNotification != ""){
              this.notificationArray = JSON.parse(res[0].sNotification);
              for(let i = 0; i <= this.notificationArray.length; i++ ){
                this.topicList.filter(x=>{
                  if(this.notificationArray[i].TopicNo == x.TopicNo){
                    x.Selected = this.notificationArray[i].Selected;
                  }
                })
              }
            }
          } 
        }).catch(error => {
          clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'ionViewWillEnter_1', error.message);
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'ionViewWillEnter_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'onViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Navigate to previous page
   */
  goBack() {
    try{
      this.navCtrl.pop();
    }catch(error){
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'goBack', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'goBack',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Get FCM Topic details from global array and store into local variable
   */
  async getFcmUserTopicDetails() {
    try {
      if (clsGlobal.lstTopicList != undefined && clsGlobal.lstTopicList.length > 0) {
        this.topicList = clsGlobal.lstTopicList;
      }
      else {
        await this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getFCMUserTopicDetails').subscribe(((respData: any) => {
          if (respData.status) {
            let dataResultarr = respData.result;
            clsGlobal.lstTopicList = dataResultarr;//Globally store data.
            for (var i = 0; i < dataResultarr.length; i++) {
              if (dataResultarr[i].bSystemDefined != 1 && (dataResultarr[i].bIsCompalsary != 0 && dataResultarr[i].bIsDisplay != 0)) {
                this.topicList.push({
                  TopicNo: dataResultarr[i].nTopicNo,
                  TopicName: dataResultarr[i].sTopicName,
                  TopicDisplayName: dataResultarr[i].sTopicDisplayName,
                  bIsCompalsary: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false,
                  bIsDisplay: parseInt(dataResultarr[i].bIsDisplay) > 0 ? true : false,
                  //if topic is compalsory we will set selected by default
                  Selected: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false

                });
              }
            }
            //set it globally to use next visit.
            clsGlobal.lstTopicList = dataResultarr;
          }
          else {
            this.toastCtrl.showAtBottom("Unable to load topic list.");
          }
        }), error => {
          clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'getFcmUserTopicDetails_1', error.message);
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'getFcmUserTopicDetails_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'getFcmUserTopicDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
   * @method Create Fcm topic list for user prefernece setting
   * @param event event object of topic select event
   * @param selectedTopic selected topic name
   */
  topicSelect(event, selectedTopic) {
    try {
      this.topicList.forEach(element => {
        if (element.TopicNo == selectedTopic.TopicNo) {
          element.Selected = event.detail.checked;
        }
      });

      let subunsub=[];
      subunsub.push(selectedTopic);
      clsGlobal.pubsub.publish('TOPIC_CHANGED', subunsub);
      if(selectedTopic.Selected)
        this.toastCtrl.showAtBottom(selectedTopic.TopicDisplayName + " Topic Subscribed.");
      else
      this.toastCtrl.showAtBottom(selectedTopic.TopicDisplayName + " Topic Unsubscribed.");
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'topicSelect', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'topicSelect',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
  * @method Save User preference settings when leaving page
  */
  ionViewWillLeave() {
    try {
      let userPrefObj = {
        sExchange: this.exchangePref,
        sInAppNotification: this.inAppNotificationPref,
        sNotification: JSON.stringify(this.topicList),
        sOrder: this.orderPref,
        sProfilePicPath: this.profilePicPref,
        sTheme: clsGlobal.defaultTheme,
      }
      this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
        clsGlobal.User.userPreference = userPrefObj;
        console.log("Push Notification preference added successfully");
       // clsGlobal.pubsub.publish('TOPIC_CHANGED', clsGlobal.lstTopicList);
      }).catch(error => {
        clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'ionViewWillLeave_1', error.message);
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PushNotificationsPage', 'ionViewWillLeave_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('PushNotificationsPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
}
