import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';

@Component({
  selector: 'app-calculators-spanmargin',
  templateUrl: './calculators-spanmargin.page.html', 
})
export class CalculatorsSpanmarginPage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }

  ionViewDidEnter(){
    clsGlobal.User.CalculatorType = 'SPANMARGIN';
  }

  goBack()
  {
    this.navCtrl.pop();
  }

  showLookUp()
  {
    this.navCtrl.navigateForward('/calculator-lookup');
  } 
}
