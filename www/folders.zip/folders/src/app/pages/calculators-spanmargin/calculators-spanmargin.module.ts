import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CalculatorsSpanmarginPageRoutingModule } from './calculators-spanmargin-routing.module';

import { CalculatorsSpanmarginPage } from './calculators-spanmargin.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CalculatorsSpanmarginPageRoutingModule
  ],
  declarations: [CalculatorsSpanmarginPage]
})
export class CalculatorsSpanmarginPageModule {}
