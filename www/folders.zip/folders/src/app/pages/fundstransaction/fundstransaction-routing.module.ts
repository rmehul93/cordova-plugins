import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FundstransactionPage } from './fundstransaction.page';

const routes: Routes = [
  {
    path: '',
    component: FundstransactionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FundstransactionPageRoutingModule {}
