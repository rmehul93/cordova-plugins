import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FundstransactionPageRoutingModule } from './fundstransaction-routing.module';

import { FundstransactionPage } from './fundstransaction.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { NgCalendarModule  } from 'ionic2-calendar';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FundstransactionPageRoutingModule,
    DirectiveSharedModule,ComponentsModule,
    NgCalendarModule
  ],
  declarations: [FundstransactionPage]
})
export class FundstransactionPageModule {}
