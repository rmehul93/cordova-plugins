import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, Platform } from '@ionic/angular';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import { CalendarComponent } from 'ionic2-calendar/calendar';
import { DatePipe } from '@angular/common';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { tryCatch } from 'rxjs-compat/util/tryCatch';

@Component({
  selector: 'app-fundstransaction',
  templateUrl: './fundstransaction.page.html',
})
export class FundstransactionPage implements OnInit {

  showFilter: boolean = false;
  fundsTransactions = [];
  fiscalYear = [];
  numberortell = "tel";
  strFromDate: any = '';
  strToDate: any = '';
  selDtType = "";
  dateSelected = false;
  amtEntered = false;
  dblMinAmt: any = 0;
  dblMaxAmt: any = 0;
  selDateName: any = '';
  transactionLoader: boolean = false;
  noDataFoundTransaction: boolean = false;
  filterType: any = {};
  fundType: any = '';
  showCustomdatePopup: boolean = false;

  //added by Vivian F
  toPreviousMonth: any = "";
  fromPreviousMonth: any = "";
  selectedDateEvents: any = [];
  filterEvents: any = [];
  calendarFromDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };
  //currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
  //currentYear = this.calendar.currentDate.getFullYear();
  calendarToDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };
  //currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
  //currentYear = this.calendar.currentDate.getFullYear();
  selectedDate: Date;
  eventSource = [];
  isFrom: boolean = true;
  isTo: boolean = false;
  fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
  fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
  fromCurrentDay = new Date().toDateString().split(' ')[2];
  //fromCurrentDay = this.calendar.currentDate.getDay();
  fromSelectedDate: any = new Date();
  toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
  toCurrentYear = this.calendarToDate.currentDate.getFullYear();
  toCurrentDay = new Date().toDateString().split(' ')[2];
  //toCurrentDay = this.calendar.currentDate.getDay();
  toSelectedDate: any = new Date();
  isCustom: boolean = false;
  dslyFrmDt: string;
  dslyToDt: string;
  @ViewChild(CalendarComponent) objCalendar: CalendarComponent;
  showTransactionDetl = false;
  selFundsItem: any;

  constructor(private navCtrl: NavController,
    private transactionService: TransactionService,
    private alrtCtrl: AlertServicesProvider,
    public platform: Platform,
    private loader: LoaderServicesProvider,
    private toastCtrl: ToastServicesProvider,
    public dateFormatter: DatePipe,
    public objToast: ToastServicesProvider,) { }

  ngOnInit() {

    this.strFromDate = this.getDate(new Date());
    this.strToDate = this.getDate(new Date());

    this.calculateFinancialYear();
    this.getTransactionReport();
    if (this.platform.is('android')) {
      this.numberortell = 'tel';
    }
    else {
      this.numberortell = 'number';
    }
  }

  getTransactionReport() {
    try {

      let reqBody = {
        "FromDate": this.strFromDate,
        "ToDate": this.strToDate,
        "Status": 2,
        "bankId": "",
        "minAmt": this.dblMinAmt,
        "maxAmt": this.dblMaxAmt,
        "fund_type": this.fundType
      }
      this.transactionLoader = true;
      //this.loader.showLoader(true);
      this.transactionService.recentTransaction(reqBody).then((response: any) => {
        //this.loader.hideLoader();
        this.transactionLoader = false;
        if (response.status == 'success') {
          this.noDataFoundTransaction = false;
          this.fundsTransactions = response.data;
        } else {
          this.noDataFoundTransaction = true;
          this.toastCtrl.showAtBottom(response.errorString);
        }
      }, err => {
        console.log(err);
        //this.loader.hideLoader();
        this.transactionLoader = false;
        this.noDataFoundTransaction = true;
      });
    } catch (error) {
      this.transactionLoader = false;
      this.noDataFoundTransaction = true;
      //this.loader.hideLoader();
    }
  }

  cancelRequest(item) {
    try {


      let reqBody = {
        "productId": item.sProductId,
        "amount": item.nAmount,
        "TxnRefNo": item.nTxnRefNo
      }

      this.alrtCtrl.showAlertConfirmWithButtons("Withdraw Cancel", "Are you sure you want to cancel request?", ["Yes", "No"], () => {
        this.transactionService.cancelWithdraw(reqBody).then((response: any) => {
          if (response.status == 'success') {
            //this.fundsTransactions = response.data;
            this.getTransactionReport();
          } else {
            this.toastCtrl.showAtBottom(response.errorString);
          }
        }, err => {
          console.log(err);

        });
      }, () => {

      })


    } catch (error) {

    }
  }

  getDate(dateObj) {
    try {

      //let dateObj = new Date();
      let day = ("0" + dateObj.getDate()).slice(-2);
      let month = ("0" + (dateObj.getMonth() + 1)).slice(-2);
      let year = dateObj.getFullYear();

      let strDate = month + "-" + day + "-" + year;
      return strDate;

    } catch (error) {

    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  showFilterPopup() {
    this.showFilter = !this.showFilter;
  }

  closeFilter() {
    this.selDtType = '';
    this.selDateName = '';
    this.dateSelected = false;
    this.strFromDate = this.getDate(new Date());
    this.strToDate = this.getDate(new Date());
    this.dblMinAmt = 0;
    this.dblMaxAmt = 0;
    this.fundType = '';
    this.showFilter = !this.showFilter;
  }

  clearFilter(refreshData: boolean) {
    this.selDtType = '';
    this.selDateName = '';
    this.dateSelected = false;
    this.strFromDate = this.getDate(new Date());
    this.strToDate = this.getDate(new Date());
    if (refreshData) {
      this.getTransactionReport()
    }
  }

  clearFundFilter(refreshData: boolean) {
    this.fundType = '';
    this.getTransactionReport();
  }

  clearAmount(refreshData: boolean) {
    this.dblMinAmt = 0;
    this.dblMaxAmt = 0;
    this.amtEntered = false;
    if (refreshData) {
      this.getTransactionReport()
    }
  }

  calculateFinancialYear() {

    let currDate = new Date();
    let currMonth = currDate.getMonth() + 1;
    let currYear = currDate.getFullYear();

    let fromYear = 0, toYear = 0;
    if (currMonth <= 3) {
      fromYear = currYear - 1;
      toYear = currYear;
    }
    else {
      fromYear = currYear;
      toYear = currYear + 1;
    }

    let objFiscalYear: any = {};
    objFiscalYear.name = "FY " + (fromYear - 2).toString().slice(-2) + "-" + (toYear - 2).toString().slice(-2);
    objFiscalYear.fromYear = fromYear - 2;
    objFiscalYear.toYear = toYear - 2
    this.fiscalYear.push(objFiscalYear);

    objFiscalYear = {};
    objFiscalYear.name = "FY " + (fromYear - 1).toString().slice(-2) + "-" + (toYear - 1).toString().slice(-2);
    objFiscalYear.fromYear = fromYear - 1;
    objFiscalYear.toYear = toYear - 1;

    this.fiscalYear.push(objFiscalYear);

    objFiscalYear = {};
    objFiscalYear.name = "FY " + (fromYear).toString().slice(-2) + "-" + (toYear).toString().slice(-2);
    objFiscalYear.fromYear = fromYear;
    objFiscalYear.toYear = toYear;

    this.fiscalYear.push(objFiscalYear);

  }

  setFiscalYear(itemFiscal) {
    this.isCustom = false;
    this.resetCustomDate();
    if (this.selDtType != itemFiscal.name) {

      let from = new Date(itemFiscal.fromYear, 3, 1);
      let to = new Date(itemFiscal.toYear, 3, 0);
      this.strFromDate = this.getDate(from);
      this.strToDate = this.getDate(to);

      this.selDtType = itemFiscal.name;
      this.selDateName = itemFiscal.name;
    } else {

      this.selDtType = '';
      this.strFromDate = this.getDate(new Date());
      this.strToDate = this.getDate(new Date());
      this.selDateName = '';

    }
    //this.dateSelected = true;
  }

  setTransactionDate(type, name) {
    this.isCustom = false;
    this.resetCustomDate();
    if (this.selDtType != type) {
      this.selDtType = type;
      this.selDateName = name;
      let from = new Date();
      let to = new Date();

      if (type == 'CM') {
        from.setDate(1);
      }
      else if (type == 'LM') {
        let today = new Date()
        from = new Date(today.getFullYear(), (today.getMonth() - 1), 1);
        to = new Date(today.getFullYear(), (today.getMonth()), 0);
      }
      else if (type == 'L3M') {
        let today = new Date()
        //from = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 3),1);
        //to = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 3),0);
        from = new Date(today.setMonth(today.getMonth() - 3));
        //to = new Date(today.getFullYear(),today.getMonth(),0);
      }
      else if (type == 'L6M') {
        let today = new Date();
        //from = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 6),1);
        //to = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 6),0);
        from = new Date(today.setMonth(today.getMonth() - 6));
        //to = new Date(today.getFullYear(),today.getMonth(),0);
      }
      this.strFromDate = this.getDate(from);
      this.strToDate = this.getDate(to);
      //this.dateSelected = true;
    } else {
      this.selDtType = '';
      this.selDateName = '';
      this.strFromDate = this.getDate(new Date());
      this.strToDate = this.getDate(new Date());
    }
  }

  setFilterType(filterType) {

    if (filterType == 'Equity') {
      this.filterType.isEquity = !this.filterType.isEquity;
    }
    else if (filterType == 'Commodity') {
      this.filterType.isCommodity = !this.filterType.isCommodity;
    }
    else if (filterType == 'Currency') {
      this.filterType.isCurrency = !this.filterType.isCurrency;
    }

  }

  setFundsType(fType) {

    if (fType == 'A') {
      this.fundType = "A";
    }
    else if (fType == 'W') {
      this.fundType = "W";
    }


  }

  applyFilter() {

    if (this.selDtType != '') {
      this.dateSelected = true;
    } else {
      this.dateSelected = false;
    }

    if (this.dblMinAmt != '' && this.dblMinAmt != 0 && this.dblMaxAmt != '' && this.dblMaxAmt != 0) {
      this.amtEntered = true;
    } else {
      this.amtEntered = false;
      this.dblMinAmt = 0;
      this.dblMaxAmt = 0;
    }

    this.showFilter = !this.showFilter;
    if (this.isCustom) {
      this.strFromDate = this.fromCurrentDay + "-" + this.fromCurrentMonth + "-" + this.fromCurrentYear;
      this.strToDate = this.toCurrentDay + "-" + this.toCurrentMonth + "-" + this.toCurrentYear;
    }
    this.resetCustomDate();
    this.getTransactionReport();

  }

  CustomDate(value) {
    try {
      if (value == 'CLOSE') {
        if (this.isCustom && (this.toSelectedDate < this.fromSelectedDate)) {
          this.objToast.showAtBottom("To Date should not be before From Date");
          return;
        }
        else if((!this.dslyFrmDt && this.dslyToDt) || (this.dslyFrmDt && !this.dslyToDt))
        {
          this.objToast.showAtBottom("To Date or From Date was not provided.");
          return;
        }
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else if (value == 'EDIT') {
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else {
        //this.resetCustomDate();
        this.selDtType = '';
        this.strFromDate = this.getDate(new Date());
        this.strToDate = this.getDate(new Date());
        this.selDateName = '';
      }
      this.showCustomdatePopup = !this.showCustomdatePopup;
    } catch (e) {
      this.showCustomdatePopup = !this.showCustomdatePopup;
    }
  }

  loadSelectedDateEvent(selectedDate) {
    this.selectedDateEvents = [];
    this.selectedDateEvents = this.filterEvents.filter(eve =>
      new Date(selectedDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString()
    )
  }

  // onCurrentDateChanged(event, type) {
  //   if (this.previousMonth) {
  //     this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
  //     if (this.previousMonth == this.currentMonth) {
  //       this.calendar.currentDate = event;
  //     } else {
  //       this.previousMonth = this.currentMonth;
  //       this.currentYear = event.getFullYear();
  //       this.calendar.currentDate = event;
  //     }
  //   } else {
  //     this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
  //     this.previousMonth = this.currentMonth;
  //     this.currentYear = event.getFullYear();
  //     this.calendar.currentDate = event;
  //   }
  // }

  onToDateChanged(event) {
    if (this.toPreviousMonth) {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.toPreviousMonth == this.toCurrentMonth) {
        this.calendarToDate.currentDate = event;
      } else {
        this.toPreviousMonth = this.toCurrentMonth;
        this.toCurrentYear = event.getFullYear();
        this.calendarToDate.currentDate = event;
      }
    } else {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.toPreviousMonth = this.toCurrentMonth;
      this.toCurrentYear = event.getFullYear();
      this.calendarToDate.currentDate = event;
    }
  }

  onFromDateChanged(event) {
    if (this.fromPreviousMonth) {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.fromPreviousMonth == this.fromCurrentMonth) {
        this.calendarFromDate.currentDate = event;
      } else {
        this.fromPreviousMonth = this.fromCurrentMonth;
        this.fromCurrentYear = event.getFullYear();
        this.calendarFromDate.currentDate = event;
      }
    } else {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.fromPreviousMonth = this.fromCurrentMonth;
      this.fromCurrentYear = event.getFullYear();
      this.calendarFromDate.currentDate = event;
    }
  }


  // comparedayWithselectedDate(selectedDay) {

  //   if (this.calendar.mode == 'week') {
  //     if (new Date(this.calendar.currentDate).getDate() === new Date(selectedDay.date).getDate()) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   }
  //   else {
  //     return false
  //   }
  // }

  isDatefromCurrentMonth(date, type) {
    let dtCompare = (type == "FROM") ? new Date(this.calendarFromDate.currentDate).getMonth() : new Date(this.calendarToDate.currentDate).getMonth();
    if (new Date(date.date).getMonth() == dtCompare) {
      return true;
    } else {
      return false;
    }


  }

  formatDate(date: Date) {
    //console.log(date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear())
    return date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear();
  }

  setToDateSelected(event) {
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.toSelectedDate = event.date;
    this.toCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.toCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.toCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
      this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
  }

  setFromDateSelected(event) {
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.isCustom = true;
    this.fromSelectedDate = event.date;

    this.fromCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.fromCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.fromCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
      this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);

  }

  markDisabled(date: Date) {
    var current = new Date();
    return date > current;
  }

  setValue(value) {
    if (value == 'FROM') {
      this.isFrom = true;
      this.isTo = false;
    }
    else {
      this.isFrom = false;
      this.isTo = true;
    }

  }

  resetCustomDate() {
    this.isCustom = false;
    this.isFrom = true;
    this.isTo = false;
    this.fromSelectedDate = new Date();
    this.toSelectedDate = new Date();
    this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
    this.fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
    this.fromCurrentDay = new Date().toDateString().split(' ')[2];
    this.toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
    this.toCurrentYear = this.calendarToDate.currentDate.getFullYear();
    this.toCurrentDay = new Date().toDateString().split(' ')[2];
    this.calendarFromDate.currentDate = new Date();
    this.calendarToDate.currentDate = new Date();
    this.dslyFrmDt = '';
    this.dslyToDt = '';
  }

  showTransactionPopup(fundsItem) {
    this.showTransactionDetl = true;
    this.selFundsItem = fundsItem;
  }

  closeTransactionPopup() {
    this.showTransactionDetl = false;
  }


}
