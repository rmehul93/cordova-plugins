import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { OrderProtectionPage } from './order-protection.page';

describe('OrderProtectionPage', () => {
  let component: OrderProtectionPage;
  let fixture: ComponentFixture<OrderProtectionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderProtectionPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OrderProtectionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
