import { clsGlobal } from './../../Common/clsGlobal';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-order-protection',
  templateUrl: './order-protection.page.html',
  styleUrls: ['./order-protection.page.scss'],
})
export class OrderProtectionPage implements OnInit {
  protectionPerc: any = 0.00;
  exchangePref: any;
  fcmTopicPref: any;
  profilePicPref: any;
  inAppNotificationPref: any;
  orderParam = {
    productType: '',
    protectionPerc: ''
  }
  defaultPerc: any;

  constructor(private navCtrl: NavController, private appSync: AppsyncDbService) { }

  ngOnInit() {
  }


  ionViewWillEnter() {
    try {
      if (clsGlobal.User.userPreference != undefined || clsGlobal.User.userPreference != "") {
        this.exchangePref = clsGlobal.User.userPreference.sExchange;
        this.fcmTopicPref = clsGlobal.User.userPreference.sNotification;
        this.profilePicPref = clsGlobal.User.userPreference.sProfilePicPath;
        this.inAppNotificationPref = clsGlobal.User.userPreference.sInAppNotification
        if (clsGlobal.User.userPreference.sOrder != "" || clsGlobal.User.userPreference.sOrder != undefined) {
          this.protectionPerc = JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc == "" ? 0.00 : JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc;
          this.orderParam = JSON.parse(clsGlobal.User.userPreference.sOrder);
          this.defaultPerc = JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc == "" ? 0.00 : JSON.parse(clsGlobal.User.userPreference.sOrder).protectionPerc;
        }
      } else {
        this.appSync.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            this.exchangePref = res[0].sExchange;
            this.fcmTopicPref = res[0].sNotification;
            this.profilePicPref = res[0].sProfilePicPath;
            this.inAppNotificationPref = res[0].sInAppNotification;
            if (res[0].sOrder != null || res[0].sOrder != undefined || res[0].sOrder != "") {
              this.protectionPerc = JSON.parse(res[0].sOrder).protectionPerc == "" ? 0.00 : JSON.parse(res[0].sOrder).protectionPerc;
              this.orderParam = JSON.parse(res[0].sOrder);
              this.defaultPerc = JSON.parse(res[0].sOrder).protectionPerc == "" ? 0.00 : JSON.parse(res[0].sOrder).protectionPerc;
            }
          }
        }).catch(error => {
          console.log("Error in getting user preference : " + error);
        })
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProtectionPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Navigate to previous page
   */
  goBack() {
    
    try {
      let userPrefObj = {
        sExchange: this.exchangePref,
        sInAppNotification: this.inAppNotificationPref,
        sNotification: this.fcmTopicPref == null ? JSON.stringify(clsGlobal.lstTopicList) : this.fcmTopicPref,
        sOrder: JSON.stringify(this.orderParam),
        sProfilePicPath: this.profilePicPref,
        sTheme: clsGlobal.defaultTheme,
      }
      this.appSync.saveUpdateUserPreferenceData(userPrefObj).then(res => {
        clsGlobal.User.userPreference = userPrefObj;
        this.navCtrl.pop();
        console.log("Order Protection preference added successfully");
      }).catch(err => {
        this.navCtrl.pop();
        //clsGlobal.ConsoleLogging("Error", "ionViewWillLeave_1", err);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProtectionPage', 'ionViewWillLeave_1',err.Message,undefined,err.stack,undefined,undefined));
      })
    } catch (error) {
      this.navCtrl.pop();
      //clsGlobal.ConsoleLogging("Error", "ionViewWillLeave_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProtectionPage', 'ionViewWillLeave_2',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  /**
   * @method Set Protection percentage by plus minus icon
   * @param type : Type of plus/minus
   */
  plusminus(type) {
    try {
      if (type == 'plus') {
        if (parseFloat(this.protectionPerc) >= 99.99) {
          return;
        }
        this.protectionPerc = (parseFloat(this.protectionPerc) + 1).toFixed(2);
        this.orderParam.protectionPerc = this.protectionPerc;
      }
      else if (type == 'minus') {
        if (parseFloat(this.protectionPerc) <= 0) {
          return;
        }
        this.protectionPerc = (parseFloat(this.protectionPerc) - 1).toFixed(2);
        this.orderParam.protectionPerc = this.protectionPerc;
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProtectionPage', 'plusminus',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method Set protection % manually
   * @param event value of protection %
   */
  setProtection(event) {
    try{
    if (event > 99.99) {
      this.orderParam = JSON.parse(clsGlobal.User.userPreference.sOrder);
      return;
    }
    if (event != null) {
      this.protectionPerc = event;
      this.orderParam.protectionPerc = event.toFixed(2);
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OrderProtectionPage', 'setProtection',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /**
  * @method Save User preference settings when leaving page
  */
  ionViewWillLeave() {
   
  }

  /**
   * @method reset protection % to default
   */
  resetProtection() {
    this.protectionPerc = this.defaultPerc;
    this.orderParam.protectionPerc = this.defaultPerc;
  }
}
