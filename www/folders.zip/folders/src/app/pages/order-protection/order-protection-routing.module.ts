import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OrderProtectionPage } from './order-protection.page';

const routes: Routes = [
  {
    path: '',
    component: OrderProtectionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderProtectionPageRoutingModule {}
