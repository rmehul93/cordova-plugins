import { DirectiveSharedModule } from './../../directives/directive.shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OrderProtectionPageRoutingModule } from './order-protection-routing.module';

import { OrderProtectionPage } from './order-protection.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OrderProtectionPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [OrderProtectionPage]
})
export class OrderProtectionPageModule {}
