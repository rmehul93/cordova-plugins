import { Component, OnInit, ViewChild } from '@angular/core';
import { IonContent, MenuController, NavController, IonSlides } from '@ionic/angular';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { NavigationExtras } from '@angular/router';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsHttpService } from '../../Common/clsHTTPService';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsScrip } from 'src/app/Common/clsScrip';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { CalendarComponent } from 'ionic2-calendar/calendar';
import { DatePipe } from '@angular/common';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/internal/operators/debounceTime';
import { distinctUntilChanged } from 'rxjs/operators';
import { TransactionService } from 'src/app/providers/transaction.service';
@Component({
  selector: 'app-marketmain',
  templateUrl: './marketmain.page.html',
})


export class MarketmainPage implements OnInit {

  @ViewChild('slides', { static: false }) slides: IonSlides;
  initCardSize: any = 4;
  tempCardSize: any;
  prevSlideindex: any = 0;
  eventSource = [];
  viewTitle: string;
  events: any = [];
  filterEvents: any = [];
  selectedDateEvents: any = [];
  previousMonth: any = "";

  calendar: any = {
    mode: 'week',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };
  currentMonth: any = "";
  currentYear: any = ""

  selectedDate: Date;

  showEventsFilterPopup: boolean = false;
  allEventType: any = [];
  eventFilterobject: any = {};

  searchTextEvents: string = "";
  searchTextChangedEvents = new Subject<string>();
  subscriptionEvents: any;
  searchTextEnteredEvents: string = "";
  eventsSearchData: any = [];
  upcomingEventData: any = [];
  eventsSearchScripKeys: any = [];
  showSearchEvents: boolean = false;

  @ViewChild(CalendarComponent) objCalendar: CalendarComponent;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  labelSelected = 'indices';
  favouriteDetails: any = [];
  localScripKey: any = [];
  bcastHandler: any;
  hotPursuitCount: number;
  trendingScrips: any = [];
  dcTrendingScrip: Dictionary<any> = new Dictionary<any>();
  lstScripKey: any = [];
  EventScripKey: any = [];
  //Added by Vivian F for screeners
  isEqAllowed: boolean = false;
  isDerAllowed: boolean = false;
  isCurrencyAllowed: boolean = false;
  isCommAllowed: boolean = false;
  ExchangeToDisplay: any = [];
  segmentSelected: any = "1";
  scannerList: any = [];
  indexListObject: any = [];
  IndexList: any = [];
  globalScannerList: any = [];
  selectedIndex: any = '';
  segmentselectfirsttime: boolean = true;
  count: any = 0;
  bIsLoggedIn: boolean = false;
  aPriceBasedScannerList: any = [];
  dropDownData: any = [];
  selectedExchange: any = '';
  cardNews: any = [];
  initDone: boolean = false;
  newsCardExist: boolean = false;
  NewsdetailsPopup: boolean = false;
  heading: any;
  details: any;
  date: any;
  scrollClick: boolean = false;
  scrollCheck: any;
  favScreeners: any = [];
  tempFavScreeners: any = [];
  otherNews: any = [];
  depthNewsDetails: any = [];
  cardNewsDetails: any = [];
  cardOrNewsDetails: any;
  selectedEvent: any;
  eventclick: boolean = false;
  attempt: any = 0;
  scannerListAttempt: any = 0;
  showloader: boolean = false;
  selectedScripObj: any = [];
  showInitLoader = clsGlobal.watchlistFirstInit;
  dateExpression = /(\d{4})-(\d{2})-(\d{2}) (\d{2})(\d{2})(\d{2})/;
  holdingData: any = [];
  countNewsCard: any = 0;
  showMoreLessScrip: boolean = false;
  whatshotlist: any = [];
  whatsHotNewsDetails: any = [];
  whatsHotMktSegId: any;
  whatsHotToken: any;
  newScripSubscription: any = [];
  //End
  cmotMode: any;
  slideOpts = {
    initialSlide: 0,
    speed: 400,
    slidesPerView: 2,
    spaceBetween: 2.5,
    centeredSlides: false
  };
  slideOptsNews = {
    initialSlide: 0,
    speed: 400,
    slidesPerView: 2,
    spaceBetween: 2.5,
    centeredSlides: false
  }

  statusMode: any = "HotPursuit";
  showLoader: boolean = false;
  showIndices: boolean = false;
  showSelectpopup: boolean = false;
  showAnnouncementDetails: boolean = false;

  announcementExchange: string = clsConstants.CDS_NSE;
  announcementList: any = [];
  pageSize: any = 10;
  iPageNo: any = clsConstants.CDS_PAGE_NO;
  sectorList: any = [];
  tempSectorList: any = [];
  sectorNews: any = [];
  sectorDetailsPopup: boolean = false;
  noDataFound: boolean = false;
  selectedSector: any = "";
  sectorNewsDescription: any = '';
  sectorHeading: any = '';
  sectorDate: any = '';
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  searchTextEntered: string = '';
  subscription: any;
  visibleIndex = -1;
  // added by sonali
  isGuestUser: boolean = false;
  fundsValueInText: string;
  totalPurchasingPower: any = 0;
  totalCash: any = 0;
  totalCollatral: any = 0;
  totalMargin: any = 0;
  totalBuyingPower: any = 0;
  periodicityWisefundsDetails: any = [];
  //productWisefundsDetails: any = [];

  @ViewChild('indiceTicker', { static: false }) elTicker: any;

  constructor(public menuCtrl: MenuController,
    public navCtrl: NavController,
    public objStorage: clsLocalStorageService,
    private objCDSService: CDSServicesProvider,
    public objHttpService: clsHttpService,
    public objToast: ToastServicesProvider,
    private paramService: NavParamService,
    public dateFormatter: DatePipe,
    private transactionService: TransactionService,//added by sonali
  ) { }

  ngOnInit() {
    this.isGuestUser = clsGlobal.User.isGuestUser;

  }



  /** <Norwin Dcruz> <08/12/2020> <To get data from Local Storage> **/
  ionViewWillEnter() {
    try{
    this.showInitLoader = clsGlobal.watchlistFirstInit;
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.hotPursuitCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_HOTPURSUIT_SCRIP_COUNT)) || 10;
    this.menuCtrl.enable(true);
    this.holdingData = clsGlobal.User.Holding;
    this.cmotMode = clsGlobal.CMOTMode;
    this.statusMode = this.cmotMode != 1 ? "HotPursuit" : "News";
    if (this.cmotMode == 1) {
      this.getSectorList();
    }
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
    try {

      if (clsGlobal.User.sessionId) {
        this.bIsLoggedIn = true;
      }
      else {
        this.bIsLoggedIn = false;
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("MarketmainPage", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }

    this.isEqAllowed = false;
    this.isDerAllowed = false;
    this.isCommAllowed = false;
    this.isCurrencyAllowed = false;
    this.ExchangeToDisplay = [];

    clsGlobal.logManager.writeUserAnalytics("MarketmainPage", "", "VISIT", "");

    this.isEqAllowed = true;
    this.count++;

    this.isDerAllowed = true;
    this.count++;

    this.isCommAllowed = true;
    this.count++;

    this.isCurrencyAllowed = true;
    this.count++;

    if (this.count == 1) {
      //this.segmenthide = true;
    }

    if (this.segmentselectfirsttime == true) {
      if (this.isEqAllowed) {
        this.segmentSelected = '1';
      }
      else if (this.isDerAllowed) {
        this.segmentSelected = '2';
      }
      else if (this.isCommAllowed) {
        this.segmentSelected = '3';
      }
      else if (this.isCurrencyAllowed) {
        this.segmentSelected = '4';
      }
      this.segmentselectfirsttime = false;
    }

    this.getHotpursuitData();
    this.getCardNews();

    this.whatshotlist = clsGlobal.EventListScrip;
    for (let counter = 0; counter < this.whatshotlist.length; counter++) {
      this.whatshotlist[counter].LTP = "0.00";
      this.whatshotlist[counter].NetChangeInRs = "0.00";
      this.whatshotlist[counter].PercNetChange = "0.00";
      this.whatshotlist[counter].LTPTrend = "";
      for (let index = 0; index < this.holdingData.length; index++) {
        if (this.holdingData[index].nMarketSegmentId == this.whatshotlist[counter].scripDet.MktSegId && this.holdingData[index].nToken == this.whatshotlist[counter].scripDet.token) {
          this.whatshotlist[counter].holding = this.holdingData[index].TOTALFREEQUANTITY;
          break;
        }
        else {
          this.whatshotlist[counter].holding = '';
          break;
        }
      }
    }
    for (let count = 0; count < this.whatshotlist.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.MktSegId = this.whatshotlist[count].scripDet._MktSegId;
      objScrpKey.token = this.whatshotlist[count].scripDet.token;
      this.lstScripKey.push(objScrpKey);
    }

  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'ionViewWillEnter2',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("MarketmainPage", "", "VISIT", "");
  }

  ionViewDidEnter() {
    try{
    //this.fetchFavScreeners();
    if (this.initDone) {
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
      this.sendTouchlineRequest(OperationType.ADD, this.newScripSubscription);
      this.initDone = false;
    }
    this.getSegmentExchanges();
    this.getScannerList();
    this.getAllIndexSectorList();
    this.subscriptionEvents = this.searchTextChangedEvents.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValuesEvents(search));
    let currentDate = new Date(this.calendar.currentDate);
    let firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    let lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    this.getEventData(this.formatDate(firstDay), this.formatDate(lastDay));
    this.currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
    this.currentYear = this.calendar.currentDate.getFullYear();
    this.fetchfavIndices();
    this.fetchFavScreeners();
    this.checkForIndiceTicker();

    // added by sonali
    if (!clsGlobal.User.isGuestUser) {

      // if (clsGlobal.User.fundsDetails && clsGlobal.User.fundsDetails.periodicityWisefundsDetails) {
      //   this.periodicityWisefundsDetails = clsGlobal.User.fundsDetails.periodicityWisefundsDetails;
      //   //this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;
      //   this.calculateFunds();
      // } else {
      //   this.getBalanceInfo();
      // }
      if (clsGlobal.User.totalBuyingPower == undefined) {
        this.transactionService.getPurchasePower().then((purchasePower: any) => {
          clsGlobal.User.totalBuyingPower = purchasePower.data;
          this.totalPurchasingPower = purchasePower.data;
          this.kFormatter(this.totalPurchasingPower);
        }).catch(error => {

        });
      } else {
        this.totalPurchasingPower = clsGlobal.User.totalBuyingPower;
        this.kFormatter(this.totalPurchasingPower);
      }

    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }


  async fetchfavIndices() {
    try {
      this.favouriteDetails = [];
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES)
        .then((item: any) => {
          this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
          this.localScripKey = [];
          if (item != null && item != undefined && item != '') {
            this.favouriteDetails = JSON.parse(item);
            //this.tempFavIndices = this.favouriteDetails;
            for (let i = 0; i < this.favouriteDetails.length; i++) {
              if (this.favouriteDetails[i].Global != true) {
                this.favouriteDetails[i].LTP = "0.00";
                this.favouriteDetails[i].NetChangeInRs = "0.00";
                this.favouriteDetails[i].LTPTrend = '';
                this.favouriteDetails[i].colorTrend = '';
                this.favouriteDetails[i].PercNetChange = "0.00";
                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = this.favouriteDetails[i].nToken;
                objScrpKey.MktSegId = this.favouriteDetails[i].nMarketSegmentId
                this.localScripKey.push(objScrpKey);
              }
            }
            this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
          }
          else {
            if (clsGlobal.lstAllIndicesList.length > 0) {
              for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {
                if ((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '1') ||
                  (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '8')) {
                  let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
                  let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);

                  if (clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1) {
                    clsGlobal.lstIndicesExchange.push(exchangeName);
                  }

                  let objScrpKey: clsScripKey = new clsScripKey();
                  objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
                  objScrpKey.MktSegId = marketSegmentId

                  let indexScrip: any = {};
                  indexScrip = {};
                  indexScrip.nToken = clsGlobal.lstAllIndicesList[index].nToken;
                  indexScrip.nMarketSegmentId = marketSegmentId;
                  indexScrip.Exchange = exchangeName;
                  indexScrip.LTP = "0.00";
                  indexScrip.NetChangeInRs = "0.00";
                  indexScrip.LTPTrend = '';
                  indexScrip.colorTrend = '';
                  indexScrip.PercNetChange = "0.00";
                  indexScrip.sIndexDesc = clsGlobal.lstAllIndicesList[index].sIndexDesc;
                  indexScrip.hidefavourite = false;
                  indexScrip.Favourite = true;
                  indexScrip.Count = index;
                  indexScrip.Global = false;
                  indexScrip.Date = '';
                  this.favouriteDetails.push(indexScrip);
                  this.localScripKey.push(objScrpKey);
                }
              }
              this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
              this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES, JSON.stringify(this.favouriteDetails));
            }
            else {
              this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getIndexDetails").subscribe((respData: any) => {
                try {
                  if (respData.status) {
                    clsGlobal.lstAllIndicesList = respData.result;
                    for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {
                      if ((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '1') ||
                        (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == '8')) {
                        let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
                        let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);

                        if (clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1) {
                          clsGlobal.lstIndicesExchange.push(exchangeName);
                        }

                        let objScrpKey: clsScripKey = new clsScripKey();
                        objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
                        objScrpKey.MktSegId = marketSegmentId

                        let indexScrip: any = {};
                        indexScrip = {};
                        indexScrip.nToken = clsGlobal.lstAllIndicesList[index].nToken;
                        indexScrip.nMarketSegmentId = marketSegmentId;
                        indexScrip.Exchange = exchangeName;
                        indexScrip.LTP = "0.00";
                        indexScrip.NetChangeInRs = "0.00";
                        indexScrip.LTPTrend = '';
                        indexScrip.colorTrend = '';
                        indexScrip.PercNetChange = "0.00";
                        indexScrip.sIndexDesc = clsGlobal.lstAllIndicesList[index].sIndexDesc;
                        indexScrip.hidefavourite = false;
                        indexScrip.Favourite = true;
                        indexScrip.Count = index;
                        indexScrip.Global = false;
                        indexScrip.Date = '';
                        this.favouriteDetails.push(indexScrip);
                        this.localScripKey.push(objScrpKey);

                      }
                    }
                    this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES, JSON.stringify(this.favouriteDetails));
                    this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
                  }
                } catch (error) {
                  console.log(error);
                }
              },
                error => {
                  clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getAllDomesticIndices', error);
                }
              );
            }
          }
        }, error => {
          //console.log('Error while retrieving local storage details.' + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'fetchfavIndices',error.Message,undefined,error.stack,undefined,undefined));
        });
      // if (this.initDone) {
      //   this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
      // }
      //this.fetchFavScreeners();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'fetchfavIndices', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'fetchfavIndices',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async fetchFavScreeners() {
    try {
      await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          //console.log("marketmain fav screeners"+obj);
          if (obj && obj.length >= 5) {
            this.favScreeners = obj;
          }
          else {
            console.log("Price Based List" + this.aPriceBasedScannerList)
            try {
              // for (let i = 0; i< this.aPriceBasedScannerList.length; i++){
              //   let item = this.aPriceBasedScannerList[i];
              //   if (!item.Favourite || item.Favourite == false) {
              //     item.Favourite = true;
              //     clsGlobal.scannerList.forEach(element => {
              //       if (element.GroupName == item.GroupName)
              //         element.Favourite = true;
              //     });
              //     this.tempFavScreeners.push(item);
              //   }
              // }

              this.aPriceBasedScannerList.forEach(item => {
                if (!item.Favourite || item.Favourite == false) {
                  item.Favourite = true;
                  clsGlobal.scannerList.forEach(element => {
                    if (element.GroupName == item.GroupName)
                      element.Favourite = true;
                  });
                  this.tempFavScreeners.push(item);
                }

              })
              this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
              this.favScreeners = this.aPriceBasedScannerList;
            }
            catch (e) {
              clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'fetchFavScreeners',e.Message,undefined,e.stack,undefined,undefined));
            }
          }
          if (this.favScreeners.length == 0) {
            if (this.attempt < 7) {
              this.attempt++;
              setTimeout(() => this.fetchFavScreeners(), 500);
            }
          };
          //console.log("marketmain fav screeners" + this.favScreeners);
        }, error => {
          //console.log('Error while retrieving local storage details.' + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'fetchFavScreeners2',error.Message,undefined,error.stack,undefined,undefined));
        });
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'fetchFavScreeners3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onScroll(event) {
    try{
    if (this.scrollClick) {
      if (Math.ceil(event.detail.scrollTop) == this.scrollCheck) {
        this.scrollClick = false;
      }
      return;
    }
    var indices = document.getElementById('dvIndices');
    var screeners = document.getElementById('dvScreeners');
    var news = document.getElementById('dvNews');
    var events = document.getElementById('dvEvents');

    if (Math.ceil(event.detail.scrollTop) < indices.offsetTop) {
      this.labelSelected = 'indices';
    }
    else if (Math.ceil(event.detail.scrollTop) > screeners.offsetTop && Math.ceil(event.detail.scrollTop) < news.offsetTop) {
      this.labelSelected = 'screener';
    }
    else if (Math.ceil(event.detail.scrollTop) > news.offsetTop && Math.ceil(event.detail.scrollTop) < events.offsetTop) {
      this.labelSelected = 'news';
    }
    else if (Math.ceil(event.detail.scrollTop) > events.offsetTop) {
      this.labelSelected = 'events';
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'onScroll',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  whatsHotNews(item) {
    this.getWhatsHotScripNews(item.scripDet._MktSegId, item.scripDet.token, 10)
  }

  getScannerList() {
    try{
    if (clsGlobal.scannerList == undefined || clsGlobal.scannerList.length == 0) {
      //"http://172.25.100.174:8161/"
      this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + clsGlobal.versionId + '/getAppWaveScannerDetails')
        .subscribe((respData: any) => {
          this.scannerList = [];
          if (respData.status) {
            this.globalScannerList = respData.result;
            clsGlobal.scannerList = this.globalScannerList;
            this.scannerList = [];
            this.aPriceBasedScannerList = this.globalScannerList.filter((element, index, array) => {
              return element.Category == "Price Based";
            });
            this.scannerList = this.aPriceBasedScannerList;
            //this.populateScreener();
          }
        }, error => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScannerList',error.Message,undefined,error.stack,undefined,undefined));
        });
    } else {
      this.globalScannerList = clsGlobal.scannerList;
      this.scannerList = [];
      this.aPriceBasedScannerList = this.globalScannerList.filter((element, index, array) => {
        return element.Category == "Price Based";
      });
      this.scannerList = this.aPriceBasedScannerList;
      //this.populateScreener();
    }
    // if (this.scannerList.length == 0) {
    //   if (this.scannerListAttempt < 7) {
    //     this.scannerListAttempt++;
    //     setTimeout(() => this.getScannerList(), 500);
    //   }
    // };
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScannerList2',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  // populateScreener() {
  //   try {

  //     this.scannerList = [];
  //     this.aPriceBasedScannerList = this.globalScannerList.filter((element, index, array) => {
  //       return element.Category == "Price Based";
  //     });

  //     this.scannerList = this.aPriceBasedScannerList;
  //     //this.fetchFavScreeners();


  //   } catch (error) {
  //     this.objToast.showAtBottom(error);
  //   }
  // }

  /**
   * @method : Emit when card slides and load scrip news
   */
  slideChanged(event) {
    try{
    if (this.holdingData.length > this.initCardSize) {
      this.slides.getActiveIndex().then(currentIndex => {
        if (currentIndex > this.prevSlideindex) {
          this.prevSlideindex = currentIndex
          this.tempCardSize = this.initCardSize + 4;
          this.tempCardSize = this.tempCardSize > this.holdingData.length ? this.holdingData.length : this.tempCardSize;
          if (this.tempCardSize <= this.holdingData.length) {
            for (this.initCardSize; this.initCardSize < this.tempCardSize; this.initCardSize++) {
              this.getScripNewsCard(this.holdingData[this.initCardSize].nMarketSegmentId, this.holdingData[this.initCardSize].nToken, 10);
            }
          }
        }
      })
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'slideChanged',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  /** <Norwin Dcruz> <08/12/2020> <To get Card News based on holding data scrips present> **/
  getCardNews() {
    try {
      if (this.holdingData.length > 0) {
        this.newsCardExist = true;
        this.initCardSize = this.holdingData.length < this.initCardSize ? this.holdingData.length : this.initCardSize;
        for (let count = 0; count < this.initCardSize; count++) {
          this.getScripNewsCard(this.holdingData[count].nMarketSegmentId, this.holdingData[count].nToken, 10);
        }
      }
      else {
        this.newsCardExist = false;
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getCardNews',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closeNews() {
    this.NewsdetailsPopup = false;
    this.showMoreLessScrip = false;
  }

  showmoreLess() {
    this.showMoreLessScrip = !this.showMoreLessScrip;
  }

  showdetailsNews(item) {
    try{
    this.NewsdetailsPopup = false;
    this.otherNews = [];
    this.heading = '';
    this.details = '';
    this.date = '';
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'news'

    for (let count = 0; count < this.depthNewsDetails.length; count++) {
      if ((item.CompanyCode == this.depthNewsDetails[count].CompanyCode) && (item.Count != this.depthNewsDetails[count].Count)) {
        this.otherNews.push(this.depthNewsDetails[count]);
      }
    }
    this.NewsdetailsPopup = true;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'showdetailsNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  showdetailsCardNews(item) {
    try{
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'card'

    for (let count = 0; count < this.cardNewsDetails.length; count++) {
      if ((item.CompanyCode == this.cardNewsDetails[count].CompanyCode) && (item.SNo != this.cardNewsDetails[count].SNo)) {
        this.otherNews.push(this.cardNewsDetails[count]);
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'showdetailsCardNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  showdetailsWhatsHotNews(item) {
    this.NewsdetailsPopup = true;
    this.otherNews = [];
    this.heading = item.Heading;
    this.details = item.ArtText;
    this.date = item.Date;
    this.cardOrNewsDetails = 'whatshot';

    for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
      if ((item.CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (item.Count != this.whatsHotNewsDetails[count].Count)) {
        this.otherNews.push(this.whatsHotNewsDetails[count]);
      }
    }
  }

  getAllIndexSectorList() {
    try{
    if (clsGlobal.indexSectorList == undefined || clsGlobal.indexSectorList.length == 0) {
      //"http://172.25.100.174:8161/"
      this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + clsGlobal.versionId + '/getIndexSectorList')
        .subscribe((respData: any) => {
          if (respData.status) {

            this.indexListObject = [];

            for (let i = 0; i < respData.result.length; i++) {
              const indexObj = respData.result[i];

              for (let index = 0; index < indexObj.length; index++) {
                const element = indexObj[index];
                let indexDetail: any = {};
                indexDetail.nIndex = element.Name;
                indexDetail.nFlag = element.Flag;
                indexDetail.nMapMarketSegmentId = element.nMktSegId;
                indexDetail.nMarketSegmentId = clsTradingMethods.GetMarketSegmentID(parseInt(indexObj.nMktSegId));
                indexDetail.nExchange = element.Exchange;
                indexDetail.nCode = element.Code;
                indexDetail.DisplayName = element.Exchange + ' - ' + element.Name;
                indexDetail.ProfileId = '900';
                this.indexListObject.push(indexDetail);
              }

              //Global.IndexListObject.push(indexDetail);
            }

            clsGlobal.indexSectorList = this.indexListObject;
            //this.filterIndexDropDown(this.selectedExchange);
          }
        }, error => {

        });
    } else {
      this.indexListObject = clsGlobal.indexSectorList;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getAllIndexSectorList',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  getSegmentExchanges() {

    let ddItem = null;
    try {
      if (this.segmentSelected == 1) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_CASH);
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_CASH);
        //}
      }
      else if (this.segmentSelected == 2) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_DERIVATIVES);
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_DERIVATIVES);
        //}

      }
      else if (this.segmentSelected == 3) {
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_MCX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_MCX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        let valueAll2: any = {};
        valueAll2.exchName = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        valueAll2.exchID = clsConstants.C_V_NCDEX_DERIVATIVES;
        ddItem.Value = valueAll2;
        //ddItem.Value = clsConstants.C_V_NCDEX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
      }
      else if (this.segmentSelected == 4) {

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_NSX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_NSX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        let valueAll: any = {};
        valueAll.exchName = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        valueAll.exchID = clsConstants.C_V_BSECDX_DERIVATIVES;
        ddItem.Value = valueAll;
        //ddItem.Value = clsConstants.C_V_BSECDX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}

      }

      this.selectedExchange = this.dropDownData[0].Name;

    } catch (error) {
      this.objToast.showAtBottom(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSegmentExchanges',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  addExchange(exchange, value) {
try{
    let valueAll: any = {};

    valueAll.exchName = exchange;
    valueAll.exchID = value;
    valueAll.flagIndexSector = 0;

    let valueIndex: any = {};
    valueIndex.exchName = exchange;
    valueIndex.exchID = value;
    valueIndex.flagIndexSector = 1;

    let valueSector: any = {};
    valueSector.exchName = exchange;
    valueSector.exchID = value;
    valueSector.flagIndexSector = 2;

    let ddItem: any = {};
    ddItem.Name = exchange + " All";
    ddItem.Value = valueAll;
    if (this.dropDownData.length > 0) {
      this.dropDownData.splice(1, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;

    ddItem = {};
    ddItem.Name = exchange + " Index";
    ddItem.Value = valueIndex;
    if (this.dropDownData.length > 2) {
      this.dropDownData.splice(3, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;

    ddItem = {};
    ddItem.Name = exchange + " Sector";
    ddItem.Value = valueSector;
    if (this.dropDownData.length > 4) {
      this.dropDownData.splice(5, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'addExchange',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  listItemClick(item) {
    try{
    let segSlctd = this.segmentSelected;
    if (item.GroupName.toUpperCase() == 'FUTURE OI GAINERS/LOSERS' || item.GroupName.toUpperCase() == 'MOST ACTIVE INDEX/STOCKS OPTIONS') {
      segSlctd = 2;
    }

    let objScanner: any = {
      segSelcted: segSlctd,
      eqAllowed: this.isEqAllowed,
      dervAllowed: this.isDerAllowed,
      commAllowed: this.isCommAllowed,
      currAllowed: this.isCurrencyAllowed,
      scannerItem: item,
      Favourite: true,
      //tabsList: tabsList,
      //hdrName: hdrName 
    };
    this.segmentselectfirsttime = true;
    //this.navCtrl.push(ScreenersEquityPage, objScanner);
    this.paramService.myParam = objScanner;
    if (item.GroupName.toUpperCase() == 'FII/DII/MF ACTIVITY') {
      this.navCtrl.navigateForward('fii-dii-mf');
    } else if (item.GroupName.toUpperCase() == 'BULK/BLOCK DEALS') {
      this.navCtrl.navigateForward('bulk-block-deals');
    } else if (item.GroupName.toUpperCase() == 'MERGER & ACQUISITION') {
      this.navCtrl.navigateForward('merger-demerger-details');
    } else if (item.GroupName.toUpperCase() == "PREMIUM / DISCOUNT") {
      this.navCtrl.navigateForward('premium-discount');
    }
    else {
      this.navCtrl.navigateForward('screener-view');
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'listItemClick',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /** <Norwin Dcruz> <08/12/2020> <To navigate to index details page with details object> **/
  showIndexDetails(indexDetails) {
    if (indexDetails.Global == true) {
      return;
    }
    let navigationData: NavigationExtras = {
      queryParams: {
        data: JSON.stringify(indexDetails)
      }
    }
    this.navCtrl.navigateForward(['indexviewdetails'], navigationData);
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

    // console.log("obj", objMultiTLResp)
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        for (let i = 0; i < this.favouriteDetails.length; i++) {
          if (this.favouriteDetails[i].nToken == objMultiTLResp.Scrip.token &&
            this.favouriteDetails[i].nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
            this.favouriteDetails[i].LTP = objMultiTLResp.LTP;

            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.favouriteDetails[i].NetChangeInRs = arrNetChange[0];
            this.favouriteDetails[i].PercNetChange = arrNetChange[1];
            this.favouriteDetails[i].colorTrend = arrNetChange[2];

            this.favouriteDetails[i].Date = this.formatDisplayDate(objMultiTLResp.LUT, this.dateExpression, undefined);

            if (parseFloat(arrNetChange[3]) > 0 && parseFloat(arrNetChange[3]) < 1) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-6';
            }
            else if (parseFloat(arrNetChange[3]) > 1 && parseFloat(arrNetChange[3]) < 2) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-5';
            }
            else if (parseFloat(arrNetChange[3]) > 2 && parseFloat(arrNetChange[3]) < 5) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-4';
            }
            else if (parseFloat(arrNetChange[3]) > 5 && parseFloat(arrNetChange[3]) < 7.5) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-3';
            }
            else if (parseFloat(arrNetChange[3]) > 7.5 && parseFloat(arrNetChange[3]) < 10) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-2';
            }
            else if (parseFloat(arrNetChange[3]) > 10) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-mild-1';
            }
            else if (parseFloat(arrNetChange[3]) < 0 && parseFloat(arrNetChange[3]) > -1) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-6';
            }
            else if (parseFloat(arrNetChange[3]) < -1 && parseFloat(arrNetChange[3]) > -2) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-5';
            }
            else if (parseFloat(arrNetChange[3]) < -2 && parseFloat(arrNetChange[3]) > -5) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-4';
            }
            else if (parseFloat(arrNetChange[3]) < -5 && parseFloat(arrNetChange[3]) > -7.5) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-3';
            }
            else if (parseFloat(arrNetChange[3]) < -7.5 && parseFloat(arrNetChange[3]) > -10) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-2';
            }
            else if (parseFloat(arrNetChange[3]) < -10) {
              this.favouriteDetails[i].LTPTrend = 'background-hitmap-hot-1';
            }
            else {
              this.favouriteDetails[i].LTPTrend = '';
            }

          }
        }

        let scripDetail = this.dcTrendingScrip.getItem(objMultiTLResp.Scrip.toString())
        if (scripDetail != undefined && scripDetail.scripKey.token == objMultiTLResp.Scrip.token
          && scripDetail.scripKey.MktSegId == objMultiTLResp.Scrip.MktSegId) {
          nFormat = 2;

          scripDetail.LTP = objMultiTLResp.LTP;
          scripDetail.ClosePrice = objMultiTLResp.ClosePrice;

          scripDetail.Date = this.formatDisplayDate(objMultiTLResp.LUT, this.dateExpression, undefined);

          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
          scripDetail.NetChangeInRs = arrNetChange[0];
          scripDetail.PercNetChange = arrNetChange[1];
          scripDetail.LTPTrend = arrNetChange[2];
          scripDetail.arrowTrend = arrNetChange[3];
        }

        for (let counter = 0; counter < this.whatshotlist.length; counter++) {
          if (this.whatshotlist[counter].scripDet._MktSegId == objMultiTLResp.Scrip.MktSegId &&
            this.whatshotlist[counter].scripDet.token == objMultiTLResp.Scrip.token) {
            this.whatshotlist[counter].LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');

            this.whatshotlist[counter].NetChangeInRs = arrNetChange[0];
            this.whatshotlist[counter].PercNetChange = arrNetChange[1];
            this.whatshotlist[counter].LTPTrend = arrNetChange[2];
          }
        }

        if (this.selectedEvent != undefined)
          if (clsTradingMethods.GetMarketSegmentID(this.selectedEvent.scripObj.MarketSegmentId) == objMultiTLResp.Scrip.MktSegId &&
            this.selectedEvent.scripObj.ODINCode == objMultiTLResp.Scrip.token) {
            this.selectedEvent.LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');

            this.selectedEvent.NetChangeInRs = arrNetChange[0];
            this.selectedEvent.PercNetChange = arrNetChange[1];
            this.selectedEvent.LTPTrend = arrNetChange[2];
          }
      }
    }
    catch (error) {
      //console.log('MarketmainPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  formatDisplayDate(sDate, expression, sFormat) {
    let _FormattedDate = "";
    try {
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[1],
          +dateArray[2] - 1, // Careful, month starts at 0!
          +dateArray[3],
          +dateArray[4],
          +dateArray[5],
          +dateArray[6]
        );
        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "MM/dd/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
        let hrFormatDate = clsTradingMethods.getDateandTime(_FormattedDate)
        return hrFormatDate;
      }
    }
    catch (error) {
      //this.toastCtrl.showAtBottom(": " + e.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'formatDisplayDate',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <11/12/2020> <To get hot pursuit data for scrips> **/
  async getHotpursuitData() {
    try {
      let requestString = clsGlobal.LocalComId + clsGlobal.versionId + "/" + this.hotPursuitCount + "/"
      await this.objCDSService.getHotPursuit(requestString).then((data: any) => {
        try {
          if (data.ResponseObject.type.toUpperCase() == "SUCCESS" && data.ResponseObject.resultset.length > 0) {
            //this.showTrendingLoader = false;
            let trendingScrip: any = {};
            let _trendingScripArray: any = [];
            for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
              let element = data.ResponseObject.resultset[index];
              let Symbol: string = "", token: string = "", mktSegId: number;
              //let exchangeAllowedNSE = clsCommonMethods.isMktDataAllowed(clsTradingMethods.GetMarketSegmentID(element.ScripData_NSE.MarketSegmentId));
              //let exchangeAllowedBSE = clsCommonMethods.isMktDataAllowed(clsTradingMethods.GetMarketSegmentID(element.ScripData_BSE.MarketSegmentId));
              if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") { // && exchangeAllowedNSE
                Symbol = element.ScripData_NSE.Symbol.trim();
                token = element.ScripData_NSE.ODINCode;
                mktSegId = element.ScripData_NSE.MarketSegmentId;
              }
              else if (element.ScripData_BSE != undefined && element.ScripData_BSE != "-") { // && exchangeAllowedBSE
                Symbol = element.ScripData_BSE.Symbol.trim();
                token = element.ScripData_BSE.ODINCode;
                mktSegId = element.ScripData_BSE.MarketSegmentId;
              }
              else {
                continue;
              }
              trendingScrip = {};
              trendingScrip.symbol = Symbol;
              trendingScrip.showBuySell = false;
              //trendingScrip.buysell = element.flagBuySell == clsConstants.C_V_ORDER_BUY?clsConstants.C_S_ORDER_BUY_TEXT:clsConstants.C_S_ORDER_SELL_TEXT;
              //trendingScrip.buysellcss = element.flagBuySell == clsConstants.C_V_ORDER_BUY?'buy-btn':'sell-btn';
              let objScrpKey: clsScripKey = new clsScripKey();
              objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              objScrpKey.token = token;
              trendingScrip.scripKey = objScrpKey;

              trendingScrip.ExchangeName = clsTradingMethods.getExchangeName(objScrpKey.MktSegId);
              trendingScrip.LTP = "0.00";
              trendingScrip.ClosePrice = "0.00";
              trendingScrip.NetChangeInRs = "0.00";
              trendingScrip.PercNetChange = "0.00";
              trendingScrip.LTPTrend = '';
              trendingScrip.scripNews = [];
              trendingScrip.MktSegId = objScrpKey.MktSegId;
              trendingScrip.token = objScrpKey.token;
              for (let counter = 0; counter < this.holdingData.length; counter++) {
                if (this.holdingData[counter].nMarketSegmentId == objScrpKey.MktSegId && this.holdingData[counter].nToken == objScrpKey.token) {
                  trendingScrip.holding = this.holdingData[counter].TOTALFREEQUANTITY;
                  break;
                }
              }

              if (!this.dcTrendingScrip.ContainsKey(objScrpKey.toString())) {
                this.dcTrendingScrip.Add(objScrpKey.toString(), trendingScrip);
                this.newScripSubscription.push(objScrpKey);
                this.getScripNews(objScrpKey.MktSegId, objScrpKey.token, 10);
                //this.getScripDetails(objScrpKey.MktSegId, objScrpKey.token);
                _trendingScripArray.push(trendingScrip);//this is global array fro trending objects.
              }
              //this is global array fro trending objects.
            }
            if (this.newScripSubscription.length > 0) {
              this.sendTouchlineRequest(OperationType.ADD, this.newScripSubscription);
            }
          }
          else {
            console.log("No data");
          }

        } catch (error) {
          // this.nodatafound = true;
          // this.showTrendingLoader = false;
          //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getHotpursuitData1', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getHotpursuitData1',error.Message,undefined,error.stack,undefined,undefined));
        }
      }).catch(error => {
        // this.nodatafound = true;
        //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getHotpursuitData2', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getHotpursuitData2',error.Message,undefined,error.stack,undefined,undefined));
        // this.showTrendingLoader = false;
      });
      //console.log(promise);
    } catch (error) {
      // this.nodatafound = true;
      // this.showTrendingLoader = false;
      //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getHotpursuitData3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getHotpursuitData3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <14/12/2020> <To get scrip news based on token and marketsegmentid> **/
  getScripNews(mktSegId: any, token: any, count: any) {
    try {
      let exchangeName = clsTradingMethods.getApiExchangeName(mktSegId);
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {
          for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
            let element = data.ResponseObject.resultset[index];
            let token: string = "", mktSegId: number;
            let nfoundNSE: boolean = false;

            if (element.ScripData_NSE != undefined && element.ScripData_NSE != "-") {
              let objScrpKeyNSE: clsScripKey = new clsScripKey();
              token = element.ScripData_NSE.ODINCode;
              mktSegId = element.ScripData_NSE.MarketSegmentId;
              objScrpKeyNSE.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              objScrpKeyNSE.token = token;
              if (this.dcTrendingScrip.ContainsKey(objScrpKeyNSE.toString())) {
                nfoundNSE = true;
                let trendScripInfo = this.dcTrendingScrip.getItem(objScrpKeyNSE.toString());
                let newsDetail: any = {};
                newsDetail.Heading = element.Heading.trim();
                newsDetail.ArtText = element.ArtText.trim();
                newsDetail.Date = element.Date.trim();
                newsDetail.CompanyCode = element.CompanyCode.trim();
                newsDetail.Count = index;

                let date = element.Date.trim().split(' ')[0];
                let time = element.Time;
                newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);

                trendScripInfo.scripNews.push(newsDetail);
                this.depthNewsDetails.push(newsDetail);
              }
            }

            if (!nfoundNSE && element.ScripData_BSE != undefined && element.ScripData_BSE != "-") {
              let objScrpKeyBSE: clsScripKey = new clsScripKey();
              token = element.ScripData_BSE.ODINCode;
              mktSegId = element.ScripData_BSE.MarketSegmentId;
              objScrpKeyBSE.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              objScrpKeyBSE.token = token;
              if (this.dcTrendingScrip.ContainsKey(objScrpKeyBSE.toString())) {
                let trendScripInfo = this.dcTrendingScrip.getItem(objScrpKeyBSE.toString());
                let newsDetail: any = {};
                newsDetail.Heading = element.Heading.trim();
                newsDetail.ArtText = element.ArtText.trim();
                newsDetail.Date = element.Date.trim();
                newsDetail.CompanyCode = element.CompanyCode.trim();
                newsDetail.Count = index;

                let date = element.Date.trim().split(' ')[0];
                let time = element.Time;
                newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);

                trendScripInfo.scripNews.push(newsDetail);
                this.depthNewsDetails.push(newsDetail);
              }
            }

          }
          clsGlobal.trendingNewsLst = this.dcTrendingScrip;
          clsGlobal.depthNewsDetails = this.depthNewsDetails;
        }
        else {
          let trendingscrip = this.dcTrendingScrip.Values();
          this.dcTrendingScrip = new Dictionary<any>();
          for (let i = 0; i < trendingscrip.length; i++) {
            if (trendingscrip[i].scripKey.token == token && trendingscrip[i].scripKey.MktSegId == mktSegId) {

            }
            else {
              let objScrpKey: clsScripKey = new clsScripKey();
              objScrpKey.MktSegId = trendingscrip[i].scripKey.MktSegId;
              objScrpKey.token = trendingscrip[i].scripKey.token;
              this.dcTrendingScrip.Add(objScrpKey.toString(), trendingscrip[i]);
            }
          }
        }
      }).catch(error => {
        //clsGlobal.logManager.writeErrorLog('MarketMainPage', 'getScripNews1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScripNews1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('MarketMainPage', 'getScripNews2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScripNews2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /** <Norwin Dcruz> <14/12/2020> <To get scrip news based on token and marketsegmentid> **/
  getScripNewsCard(mktSegId: any, token: any, count: any) {
    try {
      let exchangeName = clsCommonMethods.getExchangeName(mktSegId);;
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {
          this.cardNews.push(data.ResponseObject.resultset[0]);
          let date = this.cardNews[this.countNewsCard].Date.trim().split(' ')[0];
          let time = this.cardNews[this.countNewsCard].Time;
          this.cardNews[this.countNewsCard].agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
          this.countNewsCard++;
          for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
            let element = data.ResponseObject.resultset[index];
            let newsDetail: any = {};
            newsDetail.Heading = element.Heading.trim();
            newsDetail.ArtText = element.ArtText.trim();
            newsDetail.Date = element.Date.trim();
            newsDetail.CompanyCode = element.CompanyCode.trim();
            newsDetail.SNo = element.SNo.trim();

            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);

            this.cardNewsDetails.push(newsDetail);
          }
          clsGlobal.cardNewsLst = this.cardNews
          clsGlobal.cardNewsDetails = this.cardNewsDetails;
        }
      }).catch(error => {
        //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getScripNewsCard1', error);
        //console.log("Error + MarketMain_getScripNewsCard1 " + error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScripNewsCard1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getScripNewsCard2', error);
      // console.log("Error+ MarketMain_getScripNewsCard2 " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getScripNewsCard2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getWhatsHotScripNews(mktSegId: any, token: any, count: any) {
    try {
      let exchangeName = clsTradingMethods.getApiExchangeName(mktSegId);
      let requestString = "/" + exchangeName + "/" + token + "/" + count;
      if (this.whatsHotMktSegId == mktSegId && this.whatsHotToken == token) {
        return;
      }
      this.whatsHotMktSegId = mktSegId;
      this.whatsHotToken = token
      this.objCDSService.getScripNews(requestString).then((data: any) => {

        if (data.ResponseObject.type == "success" && data.ResponseObject.resultset.length > 0) {
          this.whatsHotNewsDetails = [];
          for (let index = 0; index < data.ResponseObject.resultset.length; index++) {
            let element = data.ResponseObject.resultset[index];
            let newsDetail: any = {};
            newsDetail.Heading = element.Heading.trim();
            newsDetail.ArtText = element.ArtText.trim();
            newsDetail.Date = element.Date.trim();
            newsDetail.CompanyCode = element.CompanyCode.trim();
            newsDetail.Count = index;

            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            newsDetail.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
            this.whatsHotNewsDetails.push(newsDetail);
          }
          this.NewsdetailsPopup = true;
          this.otherNews = [];
          this.heading = this.whatsHotNewsDetails[0].Heading;
          this.details = this.whatsHotNewsDetails[0].ArtText;
          this.date = this.whatsHotNewsDetails[0].Date;
          this.cardOrNewsDetails = 'whatshot';

          for (let count = 0; count < this.whatsHotNewsDetails.length; count++) {
            if ((this.whatsHotNewsDetails[0].CompanyCode == this.whatsHotNewsDetails[count].CompanyCode) && (this.whatsHotNewsDetails[0].Count != this.whatsHotNewsDetails[count].Count)) {
              this.otherNews.push(this.whatsHotNewsDetails[count]);
            }
          }
        }
      }).catch(error => {
        //clsGlobal.logManager.writeErrorLog('MarketMainPage', 'getScripNews1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getWhatsHotScripNews',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog('MarketmainPage', 'getWhatsHotScripNews2', error);
      // console.log("Error + MarketMain_getWhatsHotScripNews2 " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getWhatsHotScripNews2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  menuToggle() {
    this.menuCtrl.toggle();
  }

  showMoreNews() {
    this.navCtrl.navigateForward('marektnews');
  }

  showMoreIndices() {
    this.navCtrl.navigateForward('indexview');
  }

  showScreeners() {
    this.navCtrl.navigateForward('screener-main');
  }

  scrollToLabel(labelid, label) {
    this.scrollClick = true;
    var titleELe = document.getElementById(labelid);
    this.scrollCheck = titleELe.offsetTop;
    this.labelSelected = label;
    this.content.scrollToPoint(0, titleELe.offsetTop, 1000);
  }

  ionViewWillLeave() {
    this.initDone = true;
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.EventScripKey);
    this.elTicker.ionViewWillLeave();
  }



  scripInfo(scripobj) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(scripobj.scripKey.MktSegId),
          token: scripobj.scripKey.token
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let objScrpKey = new clsScripKey();

        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        objScrpKey.token = this.selectedScripObj.nToken;

        let scripInfo: clsScrip = new clsScrip();
        scripInfo.scripDet = objScrpKey;
        scripInfo.symbol = this.selectedScripObj.sSymbol.trim();
        scripInfo.Series = this.selectedScripObj.sSeries;
        scripInfo.DecimalLocator = this.selectedScripObj.DecimalLocator == "0" ? "100" : this.selectedScripObj.DecimalLocator;
        scripInfo.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        scripInfo.ExpiryDate = (this.selectedScripObj.nExpiryDate1 != null && this.selectedScripObj.nExpiryDate1.toString() != "" && this.selectedScripObj.nExpiryDate1.toString() != "0") ? this.selectedScripObj.nExpiryDate1 : "0";
        scripInfo.OptionType = this.selectedScripObj.sOptionType;
        scripInfo.MarketLot = this.selectedScripObj.nRegularLot;
        scripInfo.PriceTick = this.selectedScripObj.nPriceTick;
        scripInfo.SecurityDesc = this.selectedScripObj.sSecurityDesc;
        scripInfo.MWSecurityDesc = this.selectedScripObj.MWSecurityDesc;
        scripInfo.StrikePrice = this.selectedScripObj.nStrikePrice1.toString();
        scripInfo.ISIN = this.selectedScripObj.sISINCode;
        scripInfo.SPOS = "";
        scripInfo.POS = "";
        scripInfo.AssetToken = this.selectedScripObj.nAssetToken;
        scripInfo.FIILimit = this.selectedScripObj.nFIILimit;
        scripInfo.NRILimit = this.selectedScripObj.nNRILimit;
        scripInfo.MarginTypeIndicator = this.selectedScripObj.nMarginTypeIndicator;
        if (this.selectedScripObj.sInstrumentName.indexOf('IDX') != -1) {
          scripInfo.isIndex = true;
        }
        else {
          scripInfo.isIndex = false;
        }

        scripInfo.formatScripDisplayName()

        let idData = new clsIndexDetail();
        idData.scripDetail = scripInfo;

        this.paramService.myParam = idData.scripDetail;
        this.navCtrl.navigateForward(["/scripinfo"]);

      }).catch(error => {
        this.objToast.showAtBottom("Unable to get Scrip Info");
        //clsGlobal.logManager.writeErrorLog('MarketmainPage', 'scripInfo', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'scripInfo',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.objToast.showAtBottom("Unable to get Scrip Info")
     // console.log(error);
     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'scripInfo2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  changeCalenderMode() {

    if (this.calendar.mode == 'week') {
      this.calendar.mode = 'month'
    } else {
      this.calendar.mode = 'week'
    }
  }

  async getEventData(fromDate, toDate) {
    try{
    await this.objCDSService.getEventData(fromDate, toDate).then((response: any) => {
      if (response.resp.ResponseObject.type == "success") {
        this.loadEvents(response.resp.ResponseObject.resultset);
      }
    }, err => {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getEventData',err.Message,undefined,err.stack,undefined,undefined));
    });
    this.filterEvents = this.events;
    this.eventSource = this.filterEvents;
    let selectedDateEvents = this.filterEvents.filter(eve =>
      new Date(this.calendar.currentDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString())
    this.allEventType = [...new Set(selectedDateEvents.map(element => element.eventType))];
    this.loadSelectedDateEvent(this.calendar.currentDate);
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getEventData2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  showEventDetailsPopup(eventData) {
    try{
    console.log(this.eventFilterobject)
    let objScrpKey: clsScripKey = new clsScripKey();
    objScrpKey.token = eventData.scripObj.ODINCode;
    objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(eventData.scripObj.MarketSegmentId);
    this.EventScripKey.push(objScrpKey)
    this.sendTouchlineRequest(OperationType.ADD, this.EventScripKey);
    this.selectedEvent = eventData;
    this.selectedEvent.exchangeName = clsTradingMethods.getExchangeName(clsTradingMethods.GetMarketSegmentID(eventData.scripObj.MarketSegmentId));
    this.selectedEvent.LTP = "0.00";
    this.selectedEvent.NetChangeInRs = "0.00";
    this.selectedEvent.PercNetChange = "0.00";
    this.selectedEvent.LTPTrend = "";
    this.eventclick = true;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'showEventDetailsPopup',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeEventsDetailsPopup() {
    this.selectedEvent = null;;
    this.eventclick = false;
    this.sendTouchlineRequest(OperationType.REMOVE, this.EventScripKey);
  }

  loadEvents(eventArray) {
    try{
    this.events = [];
    eventArray.forEach(eventsArrayItem => {
      switch (eventsArrayItem.event) {

        case 'Change-of-Name':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({

                title: symbol == "" ? eventObj.OldName : symbol,
                desc: '',
                eveDate: '',
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.SourceDate).getFullYear(), new Date(eventObj.SourceDate).getMonth(), new Date(eventObj.SourceDate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.SourceDate).getFullYear(), new Date(eventObj.SourceDate).getMonth(), new Date(eventObj.SourceDate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Change-of-Name'
              })
            });
          }
          break;

        case 'AGM':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.gmdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.gmdate).getFullYear(), new Date(eventObj.gmdate).getMonth(), new Date(eventObj.gmdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.gmdate).getFullYear(), new Date(eventObj.gmdate).getMonth(), new Date(eventObj.gmdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'AGM'
              })
            });
          }
          break;

        case 'EGM':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.gmdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.gmdate).getFullYear(), new Date(eventObj.gmdate).getMonth(), new Date(eventObj.gmdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.gmdate).getFullYear(), new Date(eventObj.gmdate).getMonth(), new Date(eventObj.gmdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'EGM'
              })
            });
          }
          break;
        case 'BoardMeeting':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.bmdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.bmdate).getFullYear(), new Date(eventObj.bmdate).getMonth(), new Date(eventObj.bmdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.bmdate).getFullYear(), new Date(eventObj.bmdate).getMonth(), new Date(eventObj.bmdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'BoardMeeting'
              })
            });
          }
          break;

        case 'Announcement':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.CompanyLongName : symbol,
                desc: eventObj.Memo,
                eveDate: eventObj.Date,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.Date).getFullYear(), new Date(eventObj.Date).getMonth(), new Date(eventObj.Date).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.Date).getFullYear(), new Date(eventObj.Date).getMonth(), new Date(eventObj.Date).getDate() + 1)),
                allDay: true, data: eventObj,
                eventType: 'Announcement'
              })
            });
          }
          break;

        case 'Book-Closure':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.ComapnyName : symbol,
                desc: "",
                eveDate: eventObj.StartDate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.StartDate).getFullYear(), new Date(eventObj.StartDate).getMonth(), new Date(eventObj.StartDate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.StartDate).getFullYear(), new Date(eventObj.StartDate).getMonth(), new Date(eventObj.StartDate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Book-Closure'
              })
            });
          }
          break;

        case 'Split':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.recorddate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.recorddate).getFullYear(), new Date(eventObj.recorddate).getMonth(), new Date(eventObj.recorddate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.recorddate).getFullYear(), new Date(eventObj.recorddate).getMonth(), new Date(eventObj.recorddate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Split'
              })
            });
          }
          break;

        case 'Bonus':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.bonusdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.bonusdate).getFullYear(), new Date(eventObj.bonusdate).getMonth(), new Date(eventObj.bonusdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.bonusdate).getFullYear(), new Date(eventObj.bonusdate).getMonth(), new Date(eventObj.bonusdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Bonus'
              })
            });
          }
          break;

        case 'Buy Back':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.Description,
                eveDate: eventObj.startdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.startdate).getFullYear(), new Date(eventObj.startdate).getMonth(), new Date(eventObj.startdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.startdate).getFullYear(), new Date(eventObj.startdate).getMonth(), new Date(eventObj.startdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Buy Back'
              })
            });
          }
          break;

        case 'ForthComing Results':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: "",
                eveDate: eventObj.resultdate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.resultdate).getFullYear(), new Date(eventObj.resultdate).getMonth(), new Date(eventObj.resultdate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.resultdate).getFullYear(), new Date(eventObj.resultdate).getMonth(), new Date(eventObj.resultdate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'ForthComing Results'
              })
            });
          }
          break;

        case 'Delisted Share':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.Reason,
                eveDate: eventObj.DelistedDate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.DelistedDate).getFullYear(), new Date(eventObj.DelistedDate).getMonth(), new Date(eventObj.DelistedDate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.DelistedDate).getFullYear(), new Date(eventObj.DelistedDate).getMonth(), new Date(eventObj.DelistedDate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Delisted Share"'
              })
            });
          }
          break;

        case 'Dividend':
          if (eventsArrayItem.data.length > 0) {
            eventsArrayItem.data.forEach(eventObj => {
              let scripobj = eventObj.ScripData_NSE != '-' ? eventObj.ScripData_NSE : eventObj.ScripData_BSE != '-' ? eventObj.ScripData_BSE : '-'
              let symbol = "";
              if (scripobj != "-") {
                symbol = scripobj.Symbol
              }
              this.events.push({
                title: symbol == "" ? eventObj.co_name : symbol,
                desc: eventObj.description,
                eveDate: eventObj.recorddate,
                scripObj: scripobj,
                startTime: new Date(Date.UTC(new Date(eventObj.recorddate).getFullYear(), new Date(eventObj.recorddate).getMonth(), new Date(eventObj.recorddate).getDate())),
                endTime: new Date(Date.UTC(new Date(eventObj.recorddate).getFullYear(), new Date(eventObj.recorddate).getMonth(), new Date(eventObj.recorddate).getDate() + 1)),
                allDay: true,
                data: eventObj,
                eventType: 'Dividend'
              })
            });
          }
          break;

      }
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'loadEvents',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  oldDate: any;
  loadSelectedDateEvent(selectedDate) {
    this.selectedDateEvents = [];
    if (this.oldDate != selectedDate) {
      this.eventFilterobject.eventType = undefined;
    }
    this.oldDate = selectedDate
    let selectedDateEvents = this.events.filter(eve =>
      new Date(this.calendar.currentDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString())
    this.allEventType = [...new Set(selectedDateEvents.map(element => element.eventType))];
    this.selectedDateEvents = this.filterEvents.filter(eve =>
      new Date(selectedDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString()
    )
  }

  onCurrentDateChanged(event) {
  try{
    if (this.previousMonth) {
      this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.previousMonth == this.currentMonth) {
        this.calendar.currentDate = event;
        this.loadSelectedDateEvent(event)
      } else {

        let currentDate = event;
        let firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        let lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

        this.previousMonth = this.currentMonth;
        this.currentYear = event.getFullYear();
        this.calendar.currentDate = event;
        this.getEventData(this.formatDate(firstDay), this.formatDate(lastDay));

      }
    } else {
      this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.previousMonth = this.currentMonth;
      this.currentYear = event.getFullYear();
      this.calendar.currentDate = event;
      this.loadSelectedDateEvent(event)
    }

  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'onCurrentDateChanged',error.Message,undefined,error.stack,undefined,undefined));
  }

  }
  comparedayWithselectedDate(selectedDay) {
try{
    if (this.calendar.mode == 'week') {
      if (new Date(this.calendar.currentDate).getDate() === new Date(selectedDay.date).getDate()) {
        return true;
      } else {
        return false;
      }
    }
    else {
      return false
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'comparedayWithselectedDate',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  isDatefromCurrentMonth(date) {
    if (this.calendar.mode == 'month') {
      if (new Date(date.date).getMonth() == new Date(this.calendar.currentDate).getMonth()) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  formatDate(date: Date) {
    //console.log(date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear())
    return date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear();
  }
  showEventsFilter() {
    this.allEventType = [];
    let selectedDateEvents = this.events.filter(eve =>
      new Date(this.calendar.currentDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString())
    this.allEventType = [...new Set(selectedDateEvents.map(element => element.eventType))];
    this.showEventsFilterPopup = true;
  }
  closeEventsFilter() {
    this.showEventsFilterPopup = false;
  }
  setEventFilter(filterName: any, filterValue: any) {
    switch (filterName) {
      case 'eventType':
        this.eventFilterobject.eventType = filterValue;
        break;
    }
  }
  removeEventFilter(filterName: any) {
    try{
    switch (filterName) {
      case 'eventType':
        delete this.eventFilterobject.eventType
        break;
    }

    if (this.getEventsFiltersCount() == 0) {
      this.clearEventsFilter();
    } else {
      this.applyEventsFilter();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'removeEventFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getEventsFiltersCount() {
    return Object.keys(this.eventFilterobject).length;
  }

  clearFilter() {
    this.clearEventsFilter();
  }

  applyEventsFilter() {

    this.showEventsFilterPopup = false;
    this.selectedDateEvents = this.selectedDateEvents.filter(eve =>
      eve.eventType == this.eventFilterobject.eventType
    )

  }

  clearEventsFilter() {
    this.eventFilterobject = {};
    this.showEventsFilterPopup = false;
    this.filterEvents = this.events;
    this.eventSource = this.filterEvents;
    this.loadSelectedDateEvent(this.calendar.currentDate);
  }

  showSearchPopupEvents() {
    try{
    this.searchTextEvents = '';
    this.showSearchEvents = true;
    this.eventsSearchData = [];
    this.upcomingEventData = [];
    let upcomingEvent = this.events
      .filter(x => (new Date() <= new Date(x.eveDate)));

    for (let index = 0; index < upcomingEvent.length; index++) {
      if (!this.upcomingEventData.includes(upcomingEvent[index].eventType))
        this.upcomingEventData.push(upcomingEvent[index].eventType)
    }

  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'showSearchPopupEvents',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  hideSearchPopupEvents() {
    this.showSearchEvents = false;
    this.searchTextEvents = '';
    this.eventsSearchData = [];
  }

  searchEvents($event) {
    if ($event) {
      this.searchTextEvents = $event.toUpperCase();
      this.searchTextChangedEvents.next($event);
    } else {
      this.eventsSearchData = [];
    }
  }

  upcomingEventSearch(data) {
    this.searchTextEvents = data.toUpperCase();
    this.searchTextChangedEvents.next(this.searchTextEvents);
  }

  getValuesEvents(search) {
    try{
    this.eventsSearchData = [];
    if (search.length < 1) {
      this.searchTextEnteredEvents = '';
      this.eventsSearchData = [];
      return;
    }
    this.searchTextEnteredEvents = search.toUpperCase();
    //console.log(this.searchTextEnteredEvents)

    this.eventsSearchData = this.events
      .filter(x => (x.title.toUpperCase().trim().includes(this.searchTextEnteredEvents) || x.eventType.toUpperCase().trim().includes(this.searchTextEnteredEvents)));
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getValuesEvents',error.Message,undefined,error.stack,undefined,undefined));
  }
}

  clearSearchEvents() {
    this.searchTextEvents = '';
    this.eventsSearchData = [];
  }

  searchNews() {
    try{
    this.paramService.myParam = this.statusMode;
    if (this.statusMode == 'News') {
      this.paramService.pageData = this.sectorNews;
    } else if (this.statusMode == 'Announcement') {
      this.paramService.pageData = this.announcementList;
    }
    this.navCtrl.navigateForward(["/marketnews-lookup"]);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'searchNews',error.Message,undefined,error.stack,undefined,undefined));
  }
  }



  // markDisabled(date){
  //   if(this.currentMonth){
  //     if(clsCommonMethods.getAlphaMonth(date.getMonth()) ==  this.currentMonth){
  //       return false;
  //     }else{
  //       return true;
  //     }
  //   }else{
  //     if(clsCommonMethods.getAlphaMonth(date.getMonth()) == clsCommonMethods.getAlphaMonth(new Date().getMonth())){
  //       return false;
  //     }else{
  //       return true;
  //     }
  //   }

  // }

  eventChanged(event) {
    try{
    this.statusMode = event.detail.value;
    this.noDataFound = false;
    if (this.statusMode == "News") {
      this.showLoader = true;
      if (this.sectorNews.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.sectorNews = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getSectorList();
      }
    } else if (this.statusMode == "Announcement") {
      this.showLoader = true;
      if (this.announcementList.length > 0) {
        this.showLoader = false;
        return;
      }
      else {
        this.announcementList = [];
        this.iPageNo = clsConstants.CDS_PAGE_NO;
        this.getAnnouncementData();
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'eventChanged',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getAnnouncementData() {
try{
    this.showLoader = true;
    let requestString = "/" + this.announcementExchange + "/" + this.iPageNo + "/" + this.pageSize
    this.objCDSService
      .getAnnouncement(requestString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS && objresponse.ResponseObject.recordcount > 0) {
            this.showLoader = false;
            this.noDataFound = false;
            for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
              let element = objresponse.ResponseObject.resultset[i];
              let announcement: any = {};
              announcement.Caption = element.Caption.trim();
              announcement.CompanyCode = element.CompanyCode.trim();
              announcement.CompanyName = element.CompanyLongName.trim();
              announcement.Date = element.Date.split("-")[0] + " " + element.Date.split("-")[1] + "' " + element.Date.split("-")[2].substring(2, 4);
              announcement.Memo = element.Memo.trim();
              announcement.ScripData_BSE = element.ScripData_BSE;
              announcement.ScripData_NSE = element.ScripData_NSE;
              announcement.Symbol = element.Symbol;
              this.announcementList.push(announcement);
            }
          } else {
            this.noDataFound = true;
            this.showLoader = false;
          }
        } catch (error) {
          //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getAnnouncementData_1", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getAnnouncementData',error.Message,undefined,error.stack,undefined,undefined));
          this.showLoader = false;
          this.noDataFound = true;
        }
      })
      .catch(error => {
        this.showLoader = false;
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getAnnouncementData_2", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getAnnouncementData2',error.Message,undefined,error.stack,undefined,undefined));
      });
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getAnnouncementData3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  getSectorList() {
    if (this.sectorList.length == 0) {
      this.showLoader = true;
      let iPageNo = "-";
      let pageSize = "-";
      let requestString = iPageNo + "/" + pageSize + "/";
      this.objCDSService
        .getSectorList(requestString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS && objresponse.ResponseObject.recordcount > 0) {
              this.showLoader = false;
              this.noDataFound = false;
              this.sectorList = objresponse.ResponseObject.resultset;
              this.tempSectorList = this.sectorList;
              this.selectedSector = this.sectorList[0].SectorName;
              this.getSectorNews(this.sectorList[0].SectorCode);
            } else {
              this.showLoader = false;
              this.noDataFound = true;
            }
          } catch (error) {
            this.showLoader = false;
            this.noDataFound = true;
            ///clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorList_1", error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorList_1',error.Message,undefined,error.stack,undefined,undefined));
          }
        })
        .catch(error => {
          this.showLoader = false;
          this.noDataFound = true;
          clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorList_2", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorList_2',error.Message,undefined,error.stack,undefined,undefined));
        });
    }
  }

  /**
* Api call to get all sector specific news.
*/
  getSectorNews(sectCode) {
    this.showLoader = true;
    let requestString = sectCode + "/" + this.iPageNo + "/" + this.pageSize + "/";

    this.objCDSService.getSectorWiseNews(requestString).then((resp: any) => {
      try {
        if (resp.ResponseObject.type.toUpperCase() == "SUCCESS" && resp.ResponseObject.recordcount > 0) {
          this.showLoader = false;
          this.noDataFound = false;
          for (let i = 0; i < resp.ResponseObject.resultset.length; i++) {
            let element = resp.ResponseObject.resultset[i];
            let sectorSpecificNews: any = {};
            sectorSpecificNews.Caption = element.Caption.trim();
            sectorSpecificNews.Heading = element.Heading.trim();
            sectorSpecificNews.SNo = element.SNo.trim();
            sectorSpecificNews.Date = element.Date.split("-")[0] + " " + element.Date.split("-")[1] + "' " + element.Date.split("-")[2].substring(2, 4);
            sectorSpecificNews.SectorName = element.SectorName.trim();
            sectorSpecificNews.Time = element.Time;
            let date = element.Date.trim().split(' ')[0];
            let time = element.Time;
            sectorSpecificNews.agoDate = clsTradingMethods.getAgoTIme(date + ' ' + time);
            this.sectorNews.push(sectorSpecificNews);
          }
        }
        else {
          this.showLoader = false;
          this.noDataFound = true;
        }
      } catch (error) {
        this.showLoader = false;
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNews_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorNews_1',error.Message,undefined,error.stack,undefined,undefined));
      }

    }).catch(error => {
      this.showLoader = false;
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNews_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorNews_2',error.Message,undefined,error.stack,undefined,undefined));
    });

  }

  showIndicesPopUp() {
    this.showIndices = !this.showIndices;
  }

  selectPopup() {
    this.showSelectpopup = !this.showSelectpopup;
  }

  loadNewsAsperSector(sector) {
    this.showIndices = !this.showIndices;
    this.sectorNews = [];
    this.selectedSector = sector.SectorName;
    this.iPageNo = clsConstants.CDS_PAGE_NO;
    this.getSectorNews(sector.SectorCode);
  }

  exchangeSelect(exchange) {
    this.showSelectpopup = !this.showSelectpopup;
    this.announcementExchange = exchange;
    this.announcementList = [];
    this.iPageNo = clsConstants.CDS_PAGE_NO;
    this.getAnnouncementData();
  }


  /**
  * Api call to get description of sector specific news.
  */
  getSectorNewsDescription(sNo: any) {
    this.showLoader = true;
    let requestString = sNo + "/";
    this.objCDSService.getSectorWiseNewsDetails(requestString).then((resp: any) => {
      try {
        if (resp.ResponseObject.type.toUpperCase() == "SUCCESS" && resp.ResponseObject.recordcount > 0) {
          this.sectorNewsDescription = resp.ResponseObject.resultset[0].ArtText;
          this.sectorHeading = resp.ResponseObject.resultset[0].Heading;
          let date = resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[0] + "/" + clsCommonMethods.getNumericMonth(resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[1].toUpperCase()) + "/" + resp.ResponseObject.resultset[0].Date.replaceAll('-', '/').split('/')[2] + " " + this.getTimeFormat(resp.ResponseObject.resultset[0].Time)
          this.sectorDate = date;
          this.showLoader = false;
          this.noDataFound = false;
        }
        else {
          this.noDataFound = true;
          this.showLoader = false;
        }
      } catch (error) {
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_1", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorNewsDescription_1',error.Message,undefined,error.stack,undefined,undefined));
      }

    }).catch(error => {
      this.noDataFound = true;
      //clsGlobal.logManager.writeErrorLog("MarketNewsPage", "getSectorNewsDescription_2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getSectorNewsDescription_2',error.Message,undefined,error.stack,undefined,undefined));
      this.showLoader = false;
    });

  }

  showSectorDescription(sector) {
    this.sectorDetailsPopup = !this.sectorDetailsPopup;
    this.getSectorNewsDescription(sector.SNo);
  }

  /**
* @author : Rajendra Sirvi
* @date : 21/12/2020
* @USD : BT-37759
* @description : Convert time into PM and AM format .
*/
  getTimeFormat(time: any) {
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time + ' PM';
    } else {
      retTime = time + ' AM';
    }
    return retTime;
  }

  closeSectorNews() {
    this.NewsdetailsPopup = false;
    this.sectorDetailsPopup = false;
    this.sectorNewsDescription = '';
    this.sectorHeading = '';
    this.sectorDate = '';
  }

  search($event) {
    if ($event) {
      this.searchText = $event;
      this.searchTextChanged.next($event);
    }
  }

  getValues(search) {
    try {
      this.searchTextEntered = search.toUpperCase().trim();
      let indicesData = this.sectorList;
      let filteredIndices = this.tempSectorList.filter(x => {
        return (x.SectorName).toUpperCase().indexOf(this.searchTextEntered.toUpperCase().trim()) !== -1
      });
      if (filteredIndices.length > 0) {
        this.sectorList = filteredIndices;
      } else {
        this.sectorList = indicesData;
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showAnnouncement(i) {
    if (this.visibleIndex === i)
      this.visibleIndex = -1;
    else
      this.visibleIndex = i;
  }

  checkForIndiceTicker() {
    try {

      if (this.elTicker == undefined) {
        setTimeout(() => {
          this.checkForIndiceTicker();
        }, 100);
      } else {
        this.elTicker.ionViewWillEnter();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'checkForElementReder',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //added by sonali
  addFunds() {
    this.navCtrl.navigateForward('fundsadd');
  }

  kFormatter(num) {
    try {
      let digits = 1;

      var si = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E5, symbol: "Lac" },
        { value: 1E7, symbol: "Cr." },
        { value: 1E12, symbol: "Cr." },
        { value: 1E15, symbol: "Cr." },
        { value: 1E18, symbol: "Cr." }
      ];
      var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
      var i;
      for (i = si.length - 1; i > 0; i--) {
        if (num >= si[i].value) {
          break;
        }
      }
      this.fundsValueInText = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
    } catch (error) {
      //console.log("Error in k formatter watchlist." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'kFormatter',error.Message,undefined,error.stack,undefined,undefined));
      this.fundsValueInText = "0.00";
    }
  }

  calculateFunds() {
    try {
      this.totalPurchasingPower = 0.00;
      this.totalCash = 0.00;
      this.totalCollatral = 0.00;
      this.totalMargin = 0.00;
      this.totalBuyingPower = 0.00;

      let arrAmt = [];
      this.periodicityWisefundsDetails.forEach(element => {
        //this.totalPurchasingPower += parseFloat(element.net_available[0].nTotal);
        //this.totalCash += parseFloat(element.available.cash[0].nTotal);
        //this.totalCollatral += parseFloat(element.available.collateral[0].nTotal);
        arrAmt.push(parseFloat(element.data.filter(x => x.sDescription == 'Total Trading Power Limit')[0].nTotal));

      });

      this.totalPurchasingPower = Math.max.apply(Math, arrAmt);
      this.totalPurchasingPower = parseFloat(this.totalPurchasingPower).toFixed(2);
      // this.totalCash = parseFloat(this.totalCash).toFixed(2);
      // this.totalCollatral = parseFloat(this.totalCollatral).toFixed(2);
      // this.totalMargin = ((parseFloat(this.totalPurchasingPower) - parseFloat(this.totalCash) - parseFloat(this.totalCollatral)));
      // this.totalMargin = parseFloat(this.totalMargin).toFixed(2);
      // this.totalBuyingPower = ((parseFloat(this.totalCash) + parseFloat(this.totalCollatral) + parseFloat(this.totalMargin))).toFixed(2);
      clsGlobal.User.totalBuyingPower = this.totalPurchasingPower;// this.totalBuyingPower;
      this.kFormatter(this.totalPurchasingPower);
      clsGlobal.pubsub.publish('MENU_DYNAMIC');

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'calculateFunds',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getBalanceInfo() {
    try {

      this.transactionService.getPeridiocityWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {
          this.periodicityWisefundsDetails = balanceData.data;
          clsGlobal.User.fundsDetails.periodicityWisefundsDetails = balanceData.data;
          this.calculateFunds();
        }

      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getBalanceInfo',error.Message,undefined,error.stack,undefined,undefined));
      });

      // this.transactionService.getProductWiseBalanceInfo().then((balanceData: any) => {
      //   if (balanceData.status == 'success') {
      //     //this.productWisefundsDetails = balanceData.data;
      //     clsGlobal.User.fundsDetails.productWisefundsDetails = balanceData.data;
      //   }

      // }, error => {
      //   console.log(error)
      // });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MarketmainPage', 'getBalanceInfo2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


}
