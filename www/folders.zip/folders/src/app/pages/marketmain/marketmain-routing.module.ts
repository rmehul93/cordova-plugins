import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MarketmainPage } from './marketmain.page';

const routes: Routes = [
  {
    path: '',
    component: MarketmainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MarketmainPageRoutingModule {}
