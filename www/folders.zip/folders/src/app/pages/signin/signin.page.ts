import { Component, OnInit } from '@angular/core';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsConstants } from 'src/app/Common/clsConstants';
import { NavController, Platform, MenuController } from '@ionic/angular';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { NavParamService } from 'src/app/providers/nav-param.service';
//import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.page.html',
})
export class SigninPage implements OnInit {

  isVerified: boolean = false;
  userId: string = '';
  password: string = '';
  secondAuth: string = '';
  showPassword: boolean = false;
  passwordType: string = 'password';
  passwordIcon: string = "eye-off-icon";
  secondAuthType: string = 'password';
  authIcon: string = "icon-eye-off";
  showSecondAuth: boolean = false;
  loginClicked: boolean = false;
  isForgotPwdVisible: boolean = false;
  userIdErr: any = "";
  passErr: any = "";
  twoFApass: any = "";
  objPTNType: any;
  showBrokerInfoDataLoader: boolean = true;
  brokerInfoData: any = [];//to display broker info data
  ptnTypeName: string = 'PAN/Mobile/Date of Birth'
  signinForm: FormGroup;
  productCode: number = 0;/** mobile or tablet */
  noOfAttemptCount: number = 2;
  noOfAttempt: number = 1;
  exchangeTimeData: any = [];
  aboutUsData: string = "";
  showExchangeTiming: boolean = false;
  showAboutPopup: boolean = false;
  showBackButton : boolean = false;
  constructor(
    public http: clsHttpService,
    public toastProvider: ToastServicesProvider,
    private authService: AuthenticationService,
    private formBldr: FormBuilder,
    public platform: Platform,
    public objStorage: clsLocalStorageService,
    public splashScreen: SplashScreen,
    public navCtrl: NavController, public menuCtrl: MenuController, private paramService: NavParamService,
    //public translate: TranslateService,
  ) {
    this.signinForm = this.formBldr.group({
      userIdCtrl: ['', Validators.compose([Validators.required, Validators.pattern('[a-zA-Z0-9^-\s]*'), Validators.minLength(1), Validators.maxLength(10)])],
      passwordCtrl: ['', Validators.compose([Validators.required, Validators.pattern(/^\S*$/), Validators.minLength(parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MIN_PASSWORD_LENGTH))), Validators.maxLength(parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_PASSWORD_LENGTH)))])],
      secondAuthCtrl: ['', Validators.compose([Validators.required, Validators.pattern(/^\S*$/), Validators.minLength(1), Validators.maxLength(12)])]
    });
  }

  ngOnInit() {
    console.log('signin page visit');
    try {
      //this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      //this.translate.use(clsGlobal.defaultLanguage);
      this.menuCtrl.enable(false);// to disable sidemenu.
      this.menuCtrl.swipeGesture(false); //disable swipe open menu feature.
      //test code 
      this.getBrokerInfoData();
      this.getExchangeTimeData();
      this.getAboutUsData();
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("SignInPage", "", "VISIT", "");
  }
  ionViewWillEnter() {
    try {
      if(clsGlobal.CMOTMode != 2){
        this.showBackButton = true;
      }
      else{
        this.showBackButton = false;
      }
      console.log(this.showBackButton);
      this.signinForm.reset();
      if (clsGlobal.User.userId != '' && clsGlobal.User.userId != undefined) {
        this.signinForm.get('userIdCtrl').setValue(clsGlobal.User.userId);
      }
      this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, undefined);
      //this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      //this.translate.use(clsGlobal.defaultLanguage);
    }
    catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  /**
  * login button click event 
  * */
  login() {
    try {
      if (this.validateData()) {
        //if (this.signinForm) {
        this.loginClicked = true;
        this.setProductCode();
        let reqLogin =
        {
          "user_id": this.signinForm.get('userIdCtrl').value.toUpperCase().trim(),//this.userId.trim(),
          "login_type": "PASSWORD",
          "password": this.signinForm.get('passwordCtrl').value.trim(),//this.password.trim(),
          "UDID": clsPluginConstants.DeviceUDID,
          "second_auth": this.signinForm.get('secondAuthCtrl').value.toUpperCase().trim(),
          "api_key": clsGlobal.apiKey,
          "source": "WEBAPI"
        }
        this.isVerified = true;
        this.authService.login(reqLogin)
          .then((response: any) => {
            if (response.status == "success") {
            }
            this.loginClicked = false;
            //console.log("Login success" + response);
          }).catch(error => {
            this.isVerified = false;

            clsGlobal.ConsoleLogging("Error : Login unsuccess", "login", error);
            clsGlobal.logManager.writeErrorLog('SigninPage', 'login', error);
            //error == "Your account has been locked due to repeated failures.Please contact the administrator"
            //added by Vivian F to Handle navigation at UI end , based on error code <start>
            if (!error || !error.errorCode) {
              this.loginClicked = false;
              this.userIdErr = error || "Oops something went wrong, Kindly check internet connection.";
              //this.passErr = " or Password.";
              //this.toastProvider.showAtBottom(error);
              clsGlobal.User.userId = this.signinForm.get('userIdCtrl').value.toUpperCase().trim();
            }
            else {
              if (error.errorCode.trim() == clsConstants.ECODE_ACC_LOCKED/*"Your account has been locked due to repeated failures.Please contact the administrator".toUpperCase().trim()*/) {
                //error = "Your account has been locked due to too many attempts. Reset your password to Unlock Account";
                error = "Your account has been locked due to too many attempts. Please contact the administrator";
                //this.toastProvider.showAtBottom(error);

                this.userId = '';
                this.signinForm.get('passwordCtrl').setValue('');
                this.signinForm.get('secondAuthCtrl').setValue('');
                this.loginClicked = false;
                this.passErr = error;
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_INCORRECT_CLIENTID_OR_PASSWORD /*error.startsWith("Incorrect Client ID or Password.")*/) {
                //Incorrect Client ID or Password. Attempt 2 of 3 //Server message.
                //error = "Entered User Id or Password is incorrect. " + " "+this.noOfAttemptCount +" "+ "attempts remaining"
                this.userIdErr = error.message;
                this.passErr = " .";
                this.loginClicked = false;
                //this.toastProvider.showAtBottom(error);
                this.noOfAttemptCount -= 1;
                this.noOfAttempt += 1;
                if (this.noOfAttempt > 2 && this.noOfAttemptCount >= 0) {
                  this.noOfAttempt = 1;
                  this.noOfAttemptCount = 2;
                }
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_PWD_EXPIRED /*error == "Your password has expired, kindly change it to login" || error.startsWith("Your password has expired")*/) {
                clsGlobal.User.userId = this.signinForm.get('userIdCtrl').value.toUpperCase().trim();
                this.userIdErr = "";
                this.passErr = "";
                this.twoFApass = "";
                let pageSource = "Signin";
                this.loginClicked = false;
                this.paramService.myParam = pageSource;
                this.signinForm.get('passwordCtrl').setValue('');
                this.signinForm.get('secondAuthCtrl').setValue('');
                this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_CHANGEPASSWORD);//.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_CHANGEMPIN]);
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_INCORRECT_2FA/*error.toUpperCase().trim() == "Incorrect 2FA Password".toUpperCase().trim()*/) {
                this.twoFApass = error.message;
                this.loginClicked = false;
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_REQ_BODY_VALIDATIONS/*error.toUpperCase().trim() == "Incorrect User ID.".toUpperCase().trim()*/) {
                this.userIdErr = "Incorrect User Id";
                this.passErr = " or Password.";
                this.loginClicked = false;
              }
              else {
                this.loginClicked = false;
                this.userIdErr = error.message;
                //   //this.passErr = " or Password.";
                //this.toastProvider.showAtBottom(error);
                clsGlobal.User.userId = this.signinForm.get('userIdCtrl').value.toUpperCase().trim();

              }
              // else if (error.toUpperCase().trim() == "Password should be alphanumeric".toUpperCase().trim()) {
              //   this.userIdErr = "Incorrect User Id";
              //   this.passErr = " or Password.";
              //   this.loginClicked = false;
              // }
              // else {
              //   this.loginClicked = false;
              //   this.userIdErr = error;
              //   //this.passErr = " or Password.";
              //   //this.toastProvider.showAtBottom(error);
              //   clsGlobal.User.userId = this.signinForm.get('userIdCtrl').value.toUpperCase().trim();
              // }
            }
            //<end>
          });
      }
    } catch (error) {
      this.loginClicked = false;
      // this.toastProvider.showWithButton(error);
      // clsGlobal.ConsoleLogging("Error", "login", error);
      // clsGlobal.logManager.writeErrorLog('SigninPage', 'login', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'login',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * Validate user input on login click
   */

  validateData(): boolean {
    try {
      console.log("Validate login");
      this.userIdErr = "";
      this.passErr = "";
      this.twoFApass = "";

      if (this.signinForm.get('userIdCtrl').value.length == 0) {
        this.userIdErr = clsGlobal.dMsgMaster.getItem("NNSL3");
        //this.toastProvider.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL3"));
        return false;
      }
      if (this.signinForm.get('userIdCtrl').value.match(' ')) {
        //this.userIdErr = clsGlobal.dMsgMaster.getItem("NNSL3");
        //this.toastProvider.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL3"));
        this.userIdErr = "Incorrect User ID";
        return false;
      }
      if (this.signinForm.get('passwordCtrl').value.match(' ')) {
        return false;
      }
      if (!this.signinForm.get('userIdCtrl').value.trim().match('^[a-zA-Z0-9]+$')) {
        this.userIdErr = "Special characters not allowed in User Id field";
        return false;
      }
      if (this.signinForm.get('passwordCtrl').value.trim().length == 0) {
        this.passErr = clsGlobal.dMsgMaster.getItem("NNSL6");
        return false;
      }
      if (this.signinForm.get('secondAuthCtrl').value.trim().length == 0) {
        this.twoFApass = clsGlobal.dMsgMaster.getItem("OTP5")
        return false;
      }

      let passwordLen = (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_PASSWORD_LENGTH) || "12");
      let regexSpeciaChr = "^(?=.*[0-9a-zA-Z]+.*)[0-9a-zA-Z<>'`,._:;~!@#$%^&*()+-{}=\"|/\\\\]{6," + passwordLen + "}$";
      let regexPWD = "^(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9<>',._:;~!@#$%^&*()+-{}=\"|`/\\\\]{6," + passwordLen + "})$"

      let regExpPWD = new RegExp(regexPWD);
      let regExpSpc = new RegExp(regexSpeciaChr);

      if (!regExpSpc.test(this.signinForm.get('passwordCtrl').value.trim()) || !regExpPWD.test(this.signinForm.get('passwordCtrl').value.trim())) {
        this.passErr = "Password does not meet the policy requirement or cannot be blank";
        // this.toastProvider.showAtBottom("Password does not meet the policy requirement or cannot be blank");
        return false;
      }
    }
    catch (error) {
      // clsGlobal.logManager.writeErrorLog("SignInPage", "validateData", error);
      // clsGlobal.ConsoleLogging("Error", "validateData", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'validateData',error.Message,undefined,error.stack,undefined,undefined));
      return false;

    }
    return true;
  }

  //this method will make userid in upper case.
  upperCaseUserId(event) {
    try {
      this.userId = event.target.value.toUpperCase().trim();
      this.userIdErr = '';
      this.passErr = '';
    } catch (error) {
      //console.log("Error", "upperCaseUserId" + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'upperCaseUserId',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  upperCase2FA(event) {
    this.secondAuth = event.target.value.toUpperCase().trim();
    this.twoFApass = '';
  }
  goToHome() {
    this.navCtrl.navigateRoot('home');
  }
  getUserID($event) {
    try {
      let UserIdUpperCase = $event.target.value.toUpperCase();
      this.signinForm.get('userIdCtrl').setValue(UserIdUpperCase, {
        onlyself: true
      });
      if (this.signinForm.get('userIdCtrl').value.trim().length == 0) {
        this.isForgotPwdVisible = false;
      } else {
        this.isForgotPwdVisible = true;
      }
    } catch (error) {
     // clsGlobal.ConsoleLogging("Error", "getUserID", error);
     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getUserID',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  get2FAPassword($event) {
    try {
      let secondAuthUpperCase = $event.target.value.toUpperCase();
      this.signinForm.get('secondAuthCtrl').setValue(secondAuthUpperCase, {
        onlyself: true
      });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "get2FAPassword", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'get2FAPassword',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onKeyUp(event) {
    try {
      let newValue = event.target.value;
      this.userIdErr = '';
      this.passErr = '';
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "onKeyUp", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'onKeyUp',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * eye icon click event
   */

  hideShowPassword() {
    this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
    //this.passwordIcon = this.passwordIcon === 'eye-off-icon' ? 'eye-icon' : 'eye-off-icon';
    this.showPassword = this.passwordType == 'text' ? true : false;
  }

  hideShowSecondAuth() {
    this.secondAuthType = this.secondAuthType === 'text' ? 'password' : 'text';
    // this.authIcon = this.authIcon === 'icon-eye-off' ? 'icon-eye-on' : 'icon-eye-off';
    this.showSecondAuth = this.secondAuthType == 'text' ? true : false;
  }

  setProductCode() {
    try {
      /** set product mode */
      if (clsGlobal.applicationType == clsGlobal.MOBILE) {
        this.productCode = clsConstants.C_V_PHOENIX_MOBILE;
      }
      else if (clsGlobal.applicationType = clsGlobal.TABLET) {
        this.productCode = clsConstants.C_V_PHOENIX_TABLET
      } else {
        this.productCode = clsConstants.C_V_PHOENIX_MOBILE;
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "setProductCode", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'setProductCode',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  userIdOnLostFocus() {
    try {
      if (this.signinForm.get('userIdCtrl').value.trim().length == 0) {
        this.isForgotPwdVisible = false;
      } else {
        this.isForgotPwdVisible = true;
      }
    } catch (error) {
      //console.log('Error in userIdOnLoastFocus' + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'userIdOnLostFocus',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * Get Member Ship Details Data Server
   */
  getBrokerInfoData() {
    this.showBrokerInfoDataLoader = true;
    try {
      //const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + clsGlobal.versionId + '/' + clsConstants.C_S_BROKER_INFO_FILE;
      const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.LocalComId + clsGlobal.versionId + '/' + clsConstants.C_S_BROKER_INFO_FILE;
      this.http.getStaticFile(url).subscribe((respData: any) => {
        this.showBrokerInfoDataLoader = false;
        this.brokerInfoData = JSON.parse(respData);
      }, error => {
        this.showBrokerInfoDataLoader = false;
        // clsGlobal.ConsoleLogging("Error", "getBrokerInfoData_1", error);
        // clsGlobal.logManager.writeErrorLog('SignInPage', 'getBrokerInfoData_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getBrokerInfoData_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.showBrokerInfoDataLoader = false;
      // clsGlobal.ConsoleLogging("Error", "getBrokerInfoData_2", error);
      // clsGlobal.logManager.writeErrorLog('SignInPage', 'getBrokerInfoData_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getBrokerInfoData_2',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  //used to get keyboard status.
  isKeyBoardOpen() {
    return clsGlobal.isKeyBoardOpen;
  }

  forgotPassClick() {
    try {
      if (this.signinForm.get('userIdCtrl').value.trim().length != 0) {
        clsGlobal.User.userId = this.signinForm.get('userIdCtrl').value.toUpperCase().trim();
        //let UserId = this.signinForm.get('userIdCtrl').value;
        this.signinForm.get('passwordCtrl').setValue('');
        this.signinForm.get('secondAuthCtrl').setValue('');
        this.userIdErr = "";
        this.passErr = "";
        this.twoFApass = "";
        this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_FORGOT_PASSWORD);
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "forgotPassClick", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'forgotPassClick',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showMarketTimings() {
    this.showExchangeTiming = !this.showExchangeTiming;
  }

  closeMarketTimings() {
    this.showExchangeTiming = !this.showExchangeTiming;
  }

  getExchangeTimeData() {
    try {
      //this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_EXCHANGE_TIME_FILE).subscribe((respData: any) => {
      this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) +  clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_EXCHANGE_TIME_FILE).subscribe((respData: any) => {
          let data = JSON.parse(respData);
        for (let i = 0; i < data.length; i++) {
          this.exchangeTimeData.push({
            exchange: data[i].ExchnageName,
            marketOpen: this.getTimeFormat(data[i].Open),
            marketClose: this.getTimeFormat(data[i].Close),
            amoOpen: this.getTimeFormat(data[i].AmoOpen),
            amoClose: this.getTimeFormat(data[i].AmoClose)
          });
        }
        console.log(this.exchangeTimeData);
      }, error => {
        console.log(error);
        //clsGlobal.logManager.writeErrorLog('SignInPage', 'getExchangeTimeData_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getExchangeTimeData_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      console.log(error);
      //clsGlobal.logManager.writeErrorLog('SignInPage', 'getExchangeTimeData_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getExchangeTimeData_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getAboutUsData() {
    try {
      //this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_ABOUTUS_FILE).subscribe((respData: any) => {
      this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_ABOUTUS_FILE).subscribe((respData: any) => {
          //let data = JSON.parse(respData);
        this.aboutUsData = respData;
      }, error => {

        //this.toastCtrl.showAtBottom("Unable to show about us!");
        //clsGlobal.logManager.writeErrorLog('AboutUsPage', 'getAboutUsData_1', error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getAboutUsData_1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('AboutUsPage', 'getAboutUsData_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SigninPage', 'getAboutUsData_2',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  /**
   * @description : Convert time into PM and AM format .
  */
  getTimeFormat(time: any) {
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time.substring(0, 5) + ' PM';
    } else if (hour == '00') {
      retTime = '12:00' + ' AM';
    } else {
      retTime = time.substring(0, 5) + ' AM';
    }
    return retTime;
  }
  showAboutUs() {
    this.showAboutPopup = !this.showAboutPopup;
  }
}
