import { clsSecurityInfo } from './../../Common/clsSecurityInfo';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { AlertEngineService } from 'src/app/providers/alert-engine.service';
import { NavParamService } from './../../providers/nav-param.service';
import { Component, ElementRef, OnInit, ViewChild, ɵbypassSanitizationTrustResourceUrl } from '@angular/core';
import { NavController, Platform } from '@ionic/angular';
import { Subject } from 'rxjs';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsPivotPoint } from 'src/app/Common/clsPivotPoint';
import { clsContractInfo } from 'src/app/Common/clsContractInfo';
import { clsScrip } from 'src/app/Common/clsScrip';

@Component({
  selector: 'app-managealerts',
  templateUrl: './managealerts.page.html',
})
export class ManagealertsPage implements OnInit {


  pepperoni: any;
  scripAlertData
  scripAlertpopupShow: boolean = false;
  scripAlertFilterPopup: boolean = false;
  scripAlertFilterObject: any = {}
  filterScripAlertData: any = [];
  searchTextScripAlert: any = '';
  searchTextChangedScripAlert = new Subject<string>();
  searchTextEnteredScripAlert: any = '';
  showSearchScripAlert: boolean = false;
  scripAlertSearchData: any = [];
  subscriptionScripAlert: any;

  scripAlertKeys: any = [];
  bcastHandler: any;

  selectedAlert: any;
  selectedPrice: any = 0;
  minPrice: any = 0;
  maxPrice: any = 0;
  operator: any = "above";
  setAlertPricePopUp: boolean = false;
  @ViewChild('divScripAlertFilter', { static: false }) divScripAlertFilter: ElementRef;
  showExpandedScripAlertFilter: boolean = false;
  scripAlertFilterPane: any;

  showPivotpopup: boolean = false;
  PPPoint: clsPivotPoint = new clsPivotPoint();
  securityInfo: any;
  isSecurityInfo: boolean = false;
  contractInfo: any;
  issuedCapital: any;
  priceFormat: number;
  pivotPoints : any = [];
  selectedPivotPoint :any ; 
  pivotPointselected : boolean = false;
  numberortell: any;

  constructor(
    public platform: Platform,
    private navCtrl: NavController,
    private alertEngineService: AlertEngineService,
    private toastServicesProvider: ToastServicesProvider,
    private alertProvider: AlertServicesProvider,
    public http: clsHttpService,
    private navParams: NavParamService) {
    this.scripAlertData = this.navParams.myParam;
    this.securityInfo = new clsSecurityInfo(this.toastServicesProvider, this.alertProvider, this.http);
    this.contractInfo = new clsContractInfo(this.toastServicesProvider, this.alertProvider, this.http);
    this.PPPoint.calculatePP();

  }

  setSecurityInfo(IssuedCapital) {
    this.calculateMarketCap(IssuedCapital);
  }

  calculateMarketCap(IssuedCapital) {
    try{
    this.issuedCapital = IssuedCapital;
    
   if (this.isSecurityInfo == true) {
      if (
        this.securityInfo.PrevDayLow != undefined &&
        this.securityInfo.PrevDayHigh != undefined &&
        this.securityInfo.PrevDayClose != undefined
      ) {
        this.PPPoint.prevDayOpen = this.securityInfo.PrevDayOpen;
        this.PPPoint.prevDayHigh = this.securityInfo.PrevDayHigh;
        this.PPPoint.prevDayLow = this.securityInfo.PrevDayLow;
        this.PPPoint.prevDayClose = this.securityInfo.PrevDayClose;
        this.PPPoint.PriceFormat = this.priceFormat;
        if (
          this.securityInfo.PrevDayLow != "" &&
          this.securityInfo.PrevDayHigh != "" &&
          this.securityInfo.PrevDayClose != ""
        ) {
          this.PPPoint.calculatePP();
          this.loadPivotPoints()
        }
      }
    } else {
      
      if (
        this.contractInfo.PrevDayOpen != undefined &&
        this.contractInfo.PrevDayHigh != undefined &&
        this.contractInfo.PrevDayClose != undefined
      ) {
        this.PPPoint.prevDayOpen = this.contractInfo.PrevDayOpen;
        this.PPPoint.prevDayHigh = this.contractInfo.PrevDayHigh;
        this.PPPoint.prevDayLow = this.contractInfo.PrevDayLow;
        this.PPPoint.prevDayClose = this.contractInfo.PrevDayClose;
        this.PPPoint.PriceFormat = this.priceFormat;

        if (
          this.contractInfo.PrevDayLow != "" &&
          this.contractInfo.PrevDayHigh != "" &&
          this.contractInfo.PrevDayClose != ""
        ) {
          this.PPPoint.calculatePP();
          this.loadPivotPoints()
        }
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'calculateMarketCap',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  loadPivotPoints(){
    try{
      this.pivotPoints.push({ point  : "S1" , value : this.PPPoint.support1})
      this.pivotPoints.push({ point  : "S2" , value : this.PPPoint.support2})
      this.pivotPoints.push({ point  : "S3" , value : this.PPPoint.support3})
      this.pivotPoints.push({ point  : "Pivot" , value : this.PPPoint.pivotPoint});
      this.pivotPoints.push({ point  : "R1" , value : this.PPPoint.resistance1})
      this.pivotPoints.push({ point  : "R2" , value : this.PPPoint.resistance2})
      this.pivotPoints.push({ point  : "R3" , value : this.PPPoint.resistance3});
      this.selectedPivotPoint = this.pivotPoints[0];
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'loadPivotPoints',error.Message,undefined,error.stack,undefined,undefined));
    } 
  }

  selectPivotPoint(pivotPoint){
    this.showPivotpopup = false;
    this.selectedPivotPoint = pivotPoint;
    this.selectedPrice = pivotPoint.value;
    this.pivotPointselected = true;
  }

  clickPivot(){
    this.showPivotpopup = !this.showPivotpopup;
  }
  

  ngOnInit() {
    try{
    if (this.platform.is('android')) {
      this.numberortell = 'tel';
    }
    else {
      this.numberortell = 'number';
    }
    this.securityInfo.MCapCallBack = this.setSecurityInfo.bind(this);
    this.contractInfo.MCapCallBack = this.calculateMarketCap.bind(this);
    this.subscriptionScripAlert = this.searchTextChangedScripAlert.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValuesScripAlert(search));
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  ionViewWillEnter() {

    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.createScripAlertsData();
  }

  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("ManageAlertsPage", "", "VISIT", "");
  }

  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.scripAlertKeys);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      ///clsGlobal.logManager.writeErrorLog('manageAlerts', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {

        if (this.filterScripAlertData.length > 0) {
          this.filterScripAlertData.forEach(scripAlertItem => {
            if (scripAlertItem.token == objMultiTLResp.Scrip.token && scripAlertItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = 2;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              scripAlertItem.LTP = objMultiTLResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              scripAlertItem.NetChangeInRs = arrNetChange[0];
              scripAlertItem.PercNetChange = arrNetChange[1];
              scripAlertItem.LTPTrend = arrNetChange[2];
              scripAlertItem.arrowTrend = arrNetChange[3];
            }
          });
        }

        if (this.scripAlertSearchData.length > 0) {
          this.scripAlertSearchData.forEach(scripAlertItem => {
            if (scripAlertItem.token == objMultiTLResp.Scrip.token && scripAlertItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
              nFormat = 2;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              scripAlertItem.LTP = objMultiTLResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              scripAlertItem.NetChangeInRs = arrNetChange[0];
              scripAlertItem.PercNetChange = arrNetChange[1];
              scripAlertItem.LTPTrend = arrNetChange[2];
              scripAlertItem.arrowTrend = arrNetChange[3];
            }
          });
        }
      }
    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  createScripAlertsData() {
    try{
    this.scripAlertData.forEach(element => {
      element.checked = element.triggered == 0 ? true : false;
    });

    this.filterScripAlertData = this.scripAlertData.filter((alert: any) => { return alert.triggered == 0 });;
    this.createBroadcastforscripAlerts()
  }
  catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'createScripAlertsData',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  createBroadcastforscripAlerts() {
    try{
    this.sendTouchlineRequest(OperationType.REMOVE, this.scripAlertKeys);
    for (let index = 0; index < this.filterScripAlertData.length; index++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.token = this.filterScripAlertData[index].token;
      objScrpKey.MktSegId = this.filterScripAlertData[index].mktSegId;

      this.scripAlertKeys.push(objScrpKey);
    }
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.scripAlertKeys);
  }
  catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'createBroadcastforscripAlerts',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  //Alert Scrip  filter and Search START 

  getAlertFiltersCount() {
    return Object.keys(this.scripAlertFilterObject).length;
  }

  showScripAlertFilter() {
    this.scripAlertFilterPopup = true;
    this.checkForAlertScripFilterPopupUpElementRendrer();
  }

  setAlertScripFilter(filterName: any, filterValue: any) {
try{
    switch (filterName) {
      case 'category':
        this.scripAlertFilterObject.category = filterValue;
        break;
      case 'alertType':
        this.scripAlertFilterObject.alertType = filterValue;
        break;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'setAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  getAlertScripFiltersCount() {
    return Object.keys(this.scripAlertFilterObject).length;
  }

  removeAlertScripFilter(filterName: any) {
    try{
    switch (filterName) {
      case 'category':
        delete this.scripAlertFilterObject.category
        break;
      case 'alertType':
        delete this.scripAlertFilterObject.alertType;
        break;
    }

    console.log(this.scripAlertFilterObject)

    if (this.getAlertScripFiltersCount() == 0) {
      this.clearScripAlertFilter();
    } else {
      this.applyAlertScripFilter();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'removeAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  checkForAlertScripFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divScripAlertFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForAlertScripFilterPopupUpElementRendrer();
        }, 100);
      } else {

        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divScripAlertFilterPopup');
          this.alertScripFilterPopupBottomToTop(divElement);
        }, 200);
      }
    } catch (error) {
      //console.log("Error + checkForAlertScripFilterPopupUpElementRendrer "+ error);
      //clsGlobal.logManager.writeErrorLog('manageAlerts', 'checkForAlertScripFilterPopupUpElementRendrer', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'checkForAlertScripFilterPopupUpElementRendrer',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  alertScripFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop: true, //added by om on 26 th jan for backdrop display.
        onDidPresent: () => {
          //console.log("onDidPresent")
        },
        onDrag: () => {
          //  //console.log("onDrag");
        },
        onDragEnd: () => {

          //console.log("onDragEnd");
          let topDiv = this.divScripAlertFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedScripAlertFilter = true;
          } else {
            this.showExpandedScripAlertFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closeAlertScripFilterPopup();
        }
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends"); 
        //   //console.log("onTransitionEnd")
        // }
      }
      this.scripAlertFilterPane = new CupertinoPane(myElementRef, setting);
      this.scripAlertFilterPane.enableDrag();
      this.scripAlertFilterPane.present({ animate: true });
    } catch (error) { 
      //console.log("Error + alertScripFilterPopupBottomToTop "+ error);
      //clsGlobal.logManager.writeErrorLog('manageAlerts', 'alertScripFilterPopupBottomToTop', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'alertScripFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

   //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollAlertFilterDetails(event)
  {
    if (event.target.scrollTop > 20) {
      this.scripAlertFilterPane.moveToBreak('top');
      this.showExpandedScripAlertFilter  = true;
    }
  }  


  applyAlertScripFilter() {
    try{
    this.scripAlertFilterPopup = false;
    this.showExpandedScripAlertFilter = false;
    this.createScripAlertsData();
    if (this.filterScripAlertData.length > 0) {
      if (this.scripAlertFilterObject.alertType) {
        this.filterScripAlertData = this.filterScripAlertData
          .filter(x => x.data.alertType == this.scripAlertFilterObject.alertType)
      }
      if (this.scripAlertFilterObject.category) {
        this.filterScripAlertData = this.filterScripAlertData
          .filter(x => x.data.category == this.scripAlertFilterObject.category)
      }
    }
    this.createBroadcastforscripAlerts();
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'applyAlertScripFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  closeAlertScripFilterPopup() {
    this.scripAlertFilterPopup = false;
    this.showExpandedScripAlertFilter = false;
    this.scripAlertFilterPane.destroy({ animate: true });
  }

  clearScripAlertFilter() {
    try {

      this.scripAlertFilterPopup = false;
      this.scripAlertFilterObject = {};
      this.showExpandedScripAlertFilter = false;
      this.createScripAlertsData();
      this.createBroadcastforscripAlerts();
    } catch (error) { 
      //console.log("Error + clearScripAlertFilter "+ error);
      //clsGlobal.logManager.writeErrorLog('manageAlerts', 'clearScripAlertFilter', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'clearScripAlertFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showSearchPopupScripAlert() {
    this.searchTextScripAlert = '';
    this.showSearchScripAlert = true;
    this.scripAlertSearchData = [];
    //console.log(this.ScripALertData)
  }

  hideSearchPopupScripAlert() {
    this.showSearchScripAlert = false;
    this.searchTextScripAlert = '';
    this.scripAlertSearchData = [];

  }

  searchScripAlert($event) {
    if ($event) {
      this.searchTextScripAlert = $event.toUpperCase();
      this.searchTextChangedScripAlert.next($event);
    } else {
      this.scripAlertSearchData = [];
    }
  }

  getValuesScripAlert(search) {
    try {

      this.scripAlertSearchData = [];

      if (search.length < 1) {
        this.searchTextEnteredScripAlert = '';
        return;
      }
      this.searchTextEnteredScripAlert = search.toUpperCase();
      //console.log(this.searchTextEnteredScripAlert)

      this.scripAlertSearchData = this.scripAlertData
        .filter(x => (x.data.symbol.toUpperCase().trim().includes(this.searchTextEnteredScripAlert)));
      console.log(this.scripAlertSearchData)
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'getValuesScripAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  clearSearchScripAlert() {
    this.searchTextScripAlert = '';
    this.scripAlertSearchData = [];
  }



  //Alert Scrip  filter and Search END 


  async inizializeUI() {
    try {
      await this.alertEngineService.getScripAlerts().then((alertsResponse: any) => {
        if (alertsResponse.status = 'success') {
          clsGlobal.scripAlertsList = alertsResponse.data;
        }
      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'inizializeUI',error.Message,undefined,error.stack,undefined,undefined));
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('manageAlerts', 'getScripAlerts', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'inizializeUI2',error.Message,undefined,error.stack,undefined,undefined));
    }
    this.scripAlertData = clsGlobal.scripAlertsList.filter((alert: any) => { return alert.triggered == 0 });
    await this.scripAlertData.forEach(element => {
      element.createDate = clsCommonMethods.getOrderDateTime(element.createDate);
      element.token = element.condition[0].operand1.token;
      element.mktSegId = clsTradingMethods.GetMarketSegmentID(element.condition[0].operand1.marketsegment);
      element.exchange = clsTradingMethods.getApiExchangeName(element.mktSegId);
      element.displayExchange = clsTradingMethods.getExchangeName(element.mktSegId);
    });

    // await  clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
    //   if (resp.status) {
    //     if(resp.result.length > 0 ){
    //     resp.result.forEach(scrip => {
    //       this.scripAlertData.forEach(scripAlert => {
    //         if(scripAlert.mktSegId == scrip.nMarketSegmentId  &&  scripAlert.token == scrip.nToken){
    //           scripAlert.scripObj = scrip;
    //           scripAlert.displayScripDesc = clsTradingMethods.formatScripDesc(scrip.nExpiryDate , scrip.sInstrumentName, scrip.sOptionType  , scrip.nStrikePrice )
    //         }
    //       });
    //     });
    // }
    //   } else {
    //     //console.log("Scrip not found in sqllite: ", exchange, "--", Token);
    //   }
    // })


    this.createScripAlertsData();
  }

  enableDisableAlert(alertItem, event) {
    try{
    if (event.detail.checked) { }
    else {
      console.log(alertItem);
      let buttons = ['yes', "no"];

      this.alertProvider.showAlertConfirmWithButtons("Alert", "Are you sure you want to delete alert?", buttons,
        () => {
          this.alertEngineService.deleteAlert(alertItem.serverAlertId).then((response: any) => {
            if (response.status = 'success') {
              alertItem.checked = false;
              this.toastServicesProvider.showAtBottom('Alert has been deleted');
              let itemIndexscripAlert = this.scripAlertData.indexOf(alertItem);
              if (itemIndexscripAlert > -1) {
                this.scripAlertData.splice(itemIndexscripAlert, 1)
              }

              let itemIndexitemIndexscripAlert = this.filterScripAlertData.indexOf(alertItem);
              if (itemIndexitemIndexscripAlert > -1) {
                this.filterScripAlertData.splice(itemIndexitemIndexscripAlert, 1)
              }

              let itemIndex = this.scripAlertSearchData.indexOf(alertItem);
              if (itemIndex > -1) {
                this.scripAlertSearchData.splice(itemIndex, 1)
              }
              let itemIndexGlobalScripAlert = clsGlobal.scripAlertsList.indexOf(alertItem);
              if (itemIndexGlobalScripAlert > -1) {
                clsGlobal.scripAlertsList.splice(itemIndexGlobalScripAlert, 1)
              }

            } else {
              alertItem.checked = false;
              this.toastServicesProvider.showAtBottom('Alert has been not deleted');
            }

          }, error => {
            //clsGlobal.logManager.writeErrorLog('ManageAlertsPage', 'enableDisableAlert', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'enableDisableAlert',error.Message,undefined,error.stack,undefined,undefined));
            this.toastServicesProvider.showAtBottom('Alert has been not deleted');
          })

        },
        () => {
          this.scripAlertData.forEach(element => {
            if (element.serverAlertId == alertItem.serverAlertId) {
              element.checked = true;
            }
          });

          this.filterScripAlertData.forEach(element => {
            if (element.serverAlertId == alertItem.serverAlertId) {
              element.checked = true;
            }
          });

          this.scripAlertSearchData.forEach(element => {
            if (element.serverAlertId == alertItem.serverAlertId) {
              element.checked = true;
            }
          });
        });
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'enableDisableAlert2',error.Message,undefined,error.stack,undefined,undefined));
  }

  }

  async showEditAlertPopup(alertItem) {
    try{
    this.selectedAlert = alertItem;
    this.pivotPoints = [];
    this.pivotPointselected = false;
    this.setAlertPricePopUp = true;
    this.operator = alertItem.condition[0].operator == '>'? "above" :"below";
    
    this.selectedPrice = clsTradingMethods.convertToRupees(alertItem.condition[0].operand2.value , alertItem.condition[0].operand1.marketsegment , 0);
    let scripdetail = {
      scrips: [{
        mkt:  clsTradingMethods.getApiExchangeName(clsTradingMethods.GetMarketSegmentID(alertItem.condition[0].operand1.marketsegment)),
        token: alertItem.condition[0].operand1.token
      }]
    }

    if( !this.selectedAlert.scrip){
      await  clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        if (resp.status) {
  
          this.selectedAlert.scrip = resp.result[0];
          let currScrip: clsScrip = new clsScrip();
           currScrip = clsCommonMethods.getScripObject(this.selectedAlert.scrip).scripDetail;
          if (currScrip.scripDet.MktSegId == clsConstants.C_V_NSE_CASH ||
            currScrip.scripDet.MktSegId == clsConstants.C_V_BSE_CASH ||
            currScrip.scripDet.MktSegId == clsConstants.C_V_MSX_CASH
          ) {
            this.isSecurityInfo  = true;
              this.securityInfo.displayDetails(currScrip.scripDet.MapMktSegId, currScrip.scripDet.token);
            
          }else{
            this.contractInfo.displayDetails(this.selectedAlert);
          }
          this.priceFormat = clsTradingMethods.getPriceFormatter(this.selectedAlert.DecimalLocator, currScrip.scripDet.MktSegId);
        }
      });
    }else{
      let currScrip: clsScrip = new clsScrip();
      currScrip = clsCommonMethods.getScripObject(this.selectedAlert.scrip).scripDetail;
      if (currScrip.scripDet.MktSegId == clsConstants.C_V_NSE_CASH ||
        currScrip.scripDet.MktSegId == clsConstants.C_V_BSE_CASH ||
        currScrip.scripDet.MktSegId == clsConstants.C_V_MSX_CASH
      ) {
        this.isSecurityInfo  = true;
          this.securityInfo.displayDetails(currScrip.scripDet.MapMktSegId, currScrip.scripDet.token);
        
      }else{
        this.contractInfo.displayDetails(this.selectedAlert);
      }
      this.priceFormat = clsTradingMethods.getPriceFormatter(this.selectedAlert.DecimalLocator, currScrip.scripDet.MktSegId);
    }
    

    
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'showEditAlertPopup',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  closePriceAlert() {
    this.selectedPrice = 0.00;
    this.minPrice = 0.00;
    this.maxPrice = 0.00;
    this.setAlertPricePopUp = false;
    this.selectedAlert = null;
  }

  segmentChanged(event) {
    try {
      if (event.detail.value != undefined) {
        this.operator = event.detail.value
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'segmentChanged',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  priceChange(event) {
    this.selectedPrice = event.detail.value;
  }

  setAlert() {
try{
    let expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 1);
    expiryDate.setHours(11, 59);
    let alertRequest = {
      "condition": [{
        "operand1": {
          "marketsegment": this.selectedAlert.condition[0].operand1.marketsegment,
          "token": this.selectedAlert.condition[0].operand1.token,
          "field": "LastTradedPrice"
        },
        "operand2": {
          "marketsegment": this.selectedAlert.condition[0].operand2.marketsegment,
          "token": this.selectedAlert.condition[0].operand2.token,
          "field": "USE_VALUE",
          "value": clsTradingMethods.convertRupeesToPaisa(this.selectedPrice, clsTradingMethods.GetMarketSegmentID(this.selectedAlert.condition[0].operand1.marketsegment), 0)
        },
        "operator": this.operator == "above" ? '>' : '<',
      }],
      "data": {
        "remarks": this.selectedAlert.data.symbol + " alert",
        "userid": clsGlobal.User.userId,
        "tenantid": clsGlobal.ComId,
        "symbol": this.selectedAlert.data.symbol,
        "alertType": "PRICE",
        "category": this.selectedAlert.data.category 
      },
      "expiration": -1,
      "createDate": new Date(),
      "serverAlertId": this.selectedAlert.serverAlertId
    }


    this.alertEngineService.updateScripAlert(alertRequest).then((response: any) => {

      if (response.status = 'success') {
        let itemIndexscripAlert = this.scripAlertData.indexOf(this.selectedAlert);
        if (itemIndexscripAlert > -1) {
          this.scripAlertData.splice(itemIndexscripAlert, 1)
        }

        let itemIndexitemIndexscripAlert = this.filterScripAlertData.indexOf(this.selectedAlert);
        if (itemIndexitemIndexscripAlert > -1) {
          this.filterScripAlertData.splice(itemIndexitemIndexscripAlert, 1)
        }

        let itemIndex = this.scripAlertSearchData.indexOf(this.selectedAlert);
        if (itemIndex > -1) {
          this.scripAlertSearchData.splice(itemIndex, 1)
        }

        let itemIndexGlobalScripAlert = clsGlobal.scripAlertsList.indexOf(this.selectedAlert);
        if (itemIndexGlobalScripAlert > -1) {
          clsGlobal.scripAlertsList.splice(itemIndexGlobalScripAlert, 1)
        }
        this.inizializeUI();
        this.selectedAlert.checked = true;
        this.setAlertPricePopUp = false;
        this.toastServicesProvider.showAtBottom("You will be alerted when the Avg. Price goes " + this.operator + " " + this.selectedPrice);
        this.selectedAlert = null;
        this.selectedPrice = 0.00;
        this.minPrice = 0.00;
        this.maxPrice = 0.00;
        
      } else {
        this.selectedAlert.checked = false;
        this.setAlertPricePopUp = false;
        this.toastServicesProvider.showAtBottom('Alert has been not Set');
        this.selectedAlert = null;
        this.selectedPrice = 0.00;
        this.minPrice = 0.00;
        this.maxPrice = 0.00;
      }
    }, error => {
      this.selectedAlert = null;
      this.selectedPrice = 0.00;
      this.setAlertPricePopUp = false;
      this.minPrice = 0.00;
      this.maxPrice = 0.00;
      this.toastServicesProvider.showAtBottom('Failed to update price alert');
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ManageAlertsPage', 'setAlert',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  convertPriceToRupee(rPrice, intMktSegId) {
    return clsTradingMethods.convertToRupees(rPrice, intMktSegId, 0)
  }




}

