import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManagealertsPageRoutingModule } from './managealerts-routing.module';

import { ManagealertsPage } from './managealerts.page';
import { DirectiveSharedModule } from '../../directives/directive.shared.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManagealertsPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [ManagealertsPage]
})
export class ManagealertsPageModule {}
