import { clsConstants } from 'src/app/Common/clsConstants';
import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { BrowserServicesProvider } from './../../providers/browser-services/browser-services';
import { clsAppConfigConstants } from './../../Common/clsAppConfigConstants';
import { clsGlobal } from './../../Common/clsGlobal';
import { NavController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sso-links',
  templateUrl: './sso-links.page.html',
  styleUrls: ['./sso-links.page.scss'],
})
export class SsoLinksPage implements OnInit {
  link1 = '';
  link2 = '';
  link3 = '';
  message = '';
  isLink1Avaiable = false;
  isLink2Avaiable = false;
  isLink3Avaiable = false;
  noLink = false;
  urlPart = '';
  isAllowSSOLink1: any;
  isAllowSSOLink2: any;
  isAllowSSOLink3: any;
  link1DisplayName: string = '';
  link2DisplayName: string = '';
  link3DisplayName: string = '';

  constructor(public navCtrl: NavController, private iab: BrowserServicesProvider) { }

  ngOnInit() {
    this.getSSoLinks();
  }

  /**
   * @method Get SSO Links Configuration details
   */
  getSSoLinks() {
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO1_ALLOWED).toString().length > 0) {
      this.isAllowSSOLink1 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO1_ALLOWED);
    }
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO2_ALLOWED).toString().length > 0) {
      this.isAllowSSOLink2 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO2_ALLOWED);
    }
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO3_ALLOWED).toString().length > 0) {
      this.isAllowSSOLink3 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO3_ALLOWED);
    }
    if (clsGlobal.applicationType == clsGlobal.TABLET) {
      if (this.isAllowSSOLink1 == '3' || this.isAllowSSOLink1 == '2') {
        this.isLink1Avaiable = true;
      }

      if (this.isAllowSSOLink2 == '3' || this.isAllowSSOLink2 == '2') {
        this.isLink2Avaiable = true;
      }

      if (this.isAllowSSOLink3 == '3' || this.isAllowSSOLink3 == '2') {
        this.isLink3Avaiable = true;
      }
    }
    else if (clsGlobal.applicationType == clsGlobal.MOBILE) {
      if (this.isAllowSSOLink1 == '3' || this.isAllowSSOLink1 == '1') {
        this.isLink1Avaiable = true;
      }

      if (this.isAllowSSOLink2 == '3' || this.isAllowSSOLink2 == '1') {
        this.isLink2Avaiable = true;
      }

      if (this.isAllowSSOLink3 == '3' || this.isAllowSSOLink3 == '1') {
        this.isLink3Avaiable = true;
      }
    } else {
      this.noLink = true;
      this.message = "Application Type : " + clsGlobal.applicationType;
    }


    if (this.isLink1Avaiable = true) {
      this.link1 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO1_LINK);
      this.link1DisplayName = 'Portfolio Tracker';
    }
    if (this.isLink2Avaiable = true) {
      this.link1 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO2_LINK);
      this.link2DisplayName = 'Capital Report';
    }
    if (this.isLink3Avaiable = true) {
      this.link1 = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SSO3_LINK);
      this.link3DisplayName = 'Commodity Report';
    }

    if (this.isAllowSSOLink1 == '0' && this.isAllowSSOLink2 == '0' && this.isAllowSSOLink3 == '0') {
      this.noLink = true;
      this.message = 'SSO Link not Allowed.';
    }

    this.urlPart = clsGlobal.dConfigMaster.getItem("APP_NETNET_URL") + 'NetNetAlliedProducts.aspx?' +
      'UserID=' + clsCommonMethods.EncryptString(clsGlobal.User.userId) +
      '&GroupId=' + clsCommonMethods.EncryptString(clsGlobal.User.groupId) +
      '&UserCode=' + clsCommonMethods.EncryptString(clsGlobal.User.userCode) +
      '&OCToken=' + clsCommonMethods.EncryptString(clsGlobal.User.OCToken) +
      '&DealerCode=' + clsCommonMethods.EncryptString(clsGlobal.User.userCode) +
      '&GroupCode=' + clsCommonMethods.EncryptString(clsGlobal.User.groupCode) +
      '&ManagerId=' + clsCommonMethods.EncryptString(clsGlobal.User.managerIP) +
      '&BrowserURL=' + 'BackOfficeforNetNet.aspx' +
      '&Encrypt=' + '1' +
      '&Link=';
    console.log(this.urlPart);
  }

  /**
   * @method Navigate to previous page
   */
  goBack() {
    this.navCtrl.pop();
  }

  /**
   * @method : Open SSO Links in InApp Browser
   * @param data 
   */
  openLink(data) {
    let url = '';
    if (data == 1) {
      url = this.urlPart + "&Product=WAVE" + "&MenuId=" + clsConstants.C_S_MENU_MYACCOUNT_BACKOFFICE;
    } else if (data == 2) {
      url = this.urlPart + "&Product=WAVE" + "&MenuId=" + clsConstants.C_S_MENU_MYACCOUNT_BACKOFFICE2;
    } else if (data == 3) {
      url = this.urlPart + "&Product=WAVE" + "&MenuId=" + clsConstants.C_S_MENU_MYACCOUNT_BACKOFFICE3;
    }
    this.iab.openBrowser('SSO', url, 2);
  }

}
