import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SsoLinksPage } from './sso-links.page';

const routes: Routes = [
  {
    path: '',
    component: SsoLinksPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SsoLinksPageRoutingModule {}
