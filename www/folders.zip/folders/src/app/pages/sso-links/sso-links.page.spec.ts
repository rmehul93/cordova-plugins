import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SsoLinksPage } from './sso-links.page';

describe('SsoLinksPage', () => {
  let component: SsoLinksPage;
  let fixture: ComponentFixture<SsoLinksPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SsoLinksPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SsoLinksPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
