import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';

@Component({
  selector: 'app-cancel-orders',
  templateUrl: './cancel-orders.page.html'
})
export class CancelOrdersPage implements OnInit {
  cancelOrderData: any = [];
  selectAll: boolean = false;
  isIndeterminate: boolean = false;
  cancelOrderCheckCount = 0;
  showCancelOrdersPopup: boolean = false;
  showExpandHeader: boolean = false;
  isCancelOrderClick : boolean = false;
  constructor(private paramService: NavParamService,
    private transactionService: TransactionService,
    private navCtrl: NavController,
    private toastServicesProvider : ToastServicesProvider,
  ) {
    this.cancelOrderData = paramService.myParam;
  }
  ngOnInit() {
    if (this.cancelOrderData.length > 0) {
      this.cancelOrderData.forEach(element => {
        element.isChecked = false;
      });
    }
  }
  selectAllOrders() {
    setTimeout(() => {
      this.cancelOrderData.forEach(element => {
        element.isChecked = this.selectAll;
      });
    });
  }
  checkUncheckOrder() {
    const totalItems = this.cancelOrderData.length;
    let checked = 0;
    try {
      this.cancelOrderData.map(element => {
        if (element.isChecked) checked++;
      });
      if (checked > 0 && checked < totalItems) {
        //If even one item is checked but not all
        this.isIndeterminate = true;
        this.selectAll = false;
      } else if (checked == totalItems) {
        //If all are checked
        this.selectAll = true;
        this.isIndeterminate = false;
      } else {
        //If none is checked
        this.isIndeterminate = false;
        this.selectAll = false;
      }
    } catch (error) {
      console.log("Error in CheckUncheckOrder" + error);
    }
    this.cancelOrderCheckCount = checked;
  }
  goBack() {
    this.navCtrl.pop();
  }
  cancelAllOrders() {
    try {


      if (this.cancelOrderCheckCount == 0) {
        alert("You need to select Order(s) to cancel.")
      }
      else {

        if (this.showCancelOrdersPopup) {
          var cancelOrderArray = [];
          this.cancelOrderData.forEach(element => {
            if (element.isChecked == true)
              cancelOrderArray.push([element.exchange, element.order_id]);
          });
          this.isCancelOrderClick = true;
          
          this.transactionService.cancelOrders(cancelOrderArray).then((response:any)=>{
            if(response.status ==true || response.status == 'success'){
              this.toastServicesProvider.showAtBottom("Cancel order's request submitted.");
              this.showCancelOrdersPopup = false;
              this.isCancelOrderClick = false;
              this.navCtrl.pop();
            }else{
              this.toastServicesProvider.showAtBottom("Failed to submit cancel order's request.");
              this.showCancelOrdersPopup = false;
              this.isCancelOrderClick = false;
              this.navCtrl.pop();
            }
          }).catch(error=>{
            this.toastServicesProvider.showAtBottom("Failed to submit cancel orders request");
            this.navCtrl.pop();
            this.showCancelOrdersPopup = false;
            this.isCancelOrderClick = false;
            clsGlobal.logManager.writeErrorLog("CancelOrdersPage" , "cancelAllOrders" , error.message )
          })


        } else {
          var cancelOrderArray = [];
          this.cancelOrderData.forEach(element => {
            if (element.isChecked == true)
              cancelOrderArray.push([element.exchange, element.order_id]);
          });

          if (cancelOrderArray.length > 0) {
            this.showCancelOrdersPopup = true
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  getFormattedProductType(productType: string) {
    let product_type = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        product_type = productType.replace(/\w\S*/g, (txt) => { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase() })
        break;
      default:
        product_type = productType;
        break;
    }
    return product_type;
  }


  closeCancelOrderPopup(){
    this.showCancelOrdersPopup = false;
  }

  filterCheckedOrders(cancelOrdersItem){
    return cancelOrdersItem.isChecked;
  }
  scrollContent(event) {
    if (event.detail.scrollTop > 80) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    console.log(event);
  }
}