import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CancelOrdersPage } from './cancel-orders.page';

const routes: Routes = [
  {
    path: '',
    component: CancelOrdersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CancelOrdersPageRoutingModule {}
