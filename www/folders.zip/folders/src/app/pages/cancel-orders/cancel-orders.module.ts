import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CancelOrdersPageRoutingModule } from './cancel-orders-routing.module';

import { CancelOrdersPage } from './cancel-orders.page';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CancelOrdersPageRoutingModule,
    DirectiveSharedModule    
  ],
  declarations: [CancelOrdersPage]
})
export class CancelOrdersPageModule {}
