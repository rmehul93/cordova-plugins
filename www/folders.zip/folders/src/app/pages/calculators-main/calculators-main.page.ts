import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-calculators-main',
  templateUrl: './calculators-main.page.html', 
})
export class CalculatorsMainPage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }
  goBack()
  {
    this.navCtrl.pop();
  }
  showFairValue()
  {
    this.navCtrl.navigateForward('/calculators-fairvalue');
  }
  showOptionValue()
  {
    this.navCtrl.navigateForward('/calculators-optionvalue');
  }
  showSpanMargin()
  {
    this.navCtrl.navigateForward('/calculators-spanmargin');
  }
}
