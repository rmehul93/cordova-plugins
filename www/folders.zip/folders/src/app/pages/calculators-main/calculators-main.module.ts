import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CalculatorsMainPageRoutingModule } from './calculators-main-routing.module';

import { CalculatorsMainPage } from './calculators-main.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CalculatorsMainPageRoutingModule
  ],
  declarations: [CalculatorsMainPage]
})
export class CalculatorsMainPageModule {}
