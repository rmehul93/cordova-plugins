import { Subject } from 'rxjs/Subject';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AuthenticationService } from './../../providers/authentication.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TranslateService } from '@ngx-translate/core';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.page.html',
})
export class RegistrationPage implements OnInit {
  registered: boolean = false;
  states: any[];
  selectedState: any = {
    districts: []
  };
  selectedCity: any;
  // userName: string;
  // mobileNumber: any;
  // emailId: any;
  pluginData: any = clsPluginConstants.GetPluginDetails();
  registrationForm: FormGroup;
  userNameErr: any;
  emailIdErr: any;
  mobileErr: any;
  citiesList: any = [];

  subscription: any;
  searchTextEntered: string = '';
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  showStateList: boolean = false;
  state = [];
  city: [];
  searchCities: string = "";
  showCitiesList: boolean = false;



  constructor(private navCtrl: NavController,
    public httpService: clsHttpService,
    public toastCtrl: ToastServicesProvider,
    private formBldr: FormBuilder,
    public translate: TranslateService,
    private authService: AuthenticationService) {
    this.registrationForm = this.formBldr.group({
      userNameCtrl: ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(30)])],
      mobileNoCtrl: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10)])],
      emailIdCtrl: ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(40)])],
      stateCtrl: ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(20)])],
      cityCtrl: ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(30)])]
    });
    this.states = [
      {
        "id": 1,
        "name": "Andhra Pradesh",
        "cities": [
          "Anantapur", "Chittoor", "East Godavari", "Guntur", "Kadapa", "Krishna", "Kurnool", "Nellore", "Prakasam", "Srikakulam", "Visakhapatnam", "Vizianagaram", "West Godavari"
        ]
      },
      {
        "id": 2,
        "name": "Arunachal Pradesh",
        "cities": [
          "Tawang", "West Kameng", "East Kameng", "Pakke-Kessang", "Papum Pare", "Kurung Kumey", "Kra Daadi", "Lower Subansiri", "Upper Subansiri", "West Siang", "Shi-Yomi", "East Siang", "Siang", "Upper Siang", "Lower Siang", "Lepa-Rada", "Lower Dibang Valley", "Dibang Valley", "Anjaw", "Lohit", "Namsai", "Changlang", "Tirap", "Longding", "Kamle"
        ]
      },
      {
        "id": 3,
        "name": "Assam",
        "cities": [
          "Baksa", "Barpeta", "Biswanath", "Bongaigaon", "Cachar", "Charaideo", "Chirang", "Darrang", "Dhemaji", "Dhubri", "Dibrugarh", "Dima Hasao", "Goalpara", "Golaghat", "Hailakandi", "Hojai", "Jorhat", "Kamrup Metropolitan", "Kamrup", "Karbi Anglong", "Karimganj", "Kokrajhar", "Lakhimpur", "Majuli", "Morigaon", "Nagaon", "Nalbari", "Sivasagar", "Sonitpur", "South Salmara-Mankachar", "Tinsukia", "Udalguri", "West Karbi Anglong"
        ]
      },
      {
        "id": 4,
        "name": "Bihar",
        "cities": [
          "Araria", "Arwal", "Aurangabad", "Banka", "Begusarai", "Bhabhua", "Bhagalpur", "Bhojpur", "Buxar", "Darbhanga", "East Champaran", "Gaya", "Gopalganj", "Jamui", "Jehanabad", "Katihar", "Khagaria", "Kishanganj", "Lakhisarai", "Madhepura", "Madhubani", "Monghyr", "Muzaffarpur", "Nalanda", "Nawada", "Patna", "Purnea", "Rohtas", "Saharsa", "Samastipur", "Saran", "Sheikhpura", "Sheohar", "Sitamarhi", "Siwan", "Supaul", "Vaishali", "West Champaran"
        ]
      },
      {
        "id": 5,
        "name": "Chandigarh",
        "cities": [
          "Chandigarh"
        ]
      },
      {
        "id": 6,
        "name": "Chhattisgarh",
        "cities": [
          "Balod", "Baloda Bazar", "Balrampur", "Bastar", "Bemetara", "Bijapur", "Bilaspur", "Dantewada", "Dhamtari", "Durg", "Gariaband", "Gaurella", "Janjgir-Champa", "Jashpur", "Kabirdham", "Kanker", "Kondagaon", "Korba", "Koriya", "Mahasamund", "Mungeli", "Narayanpur", "Raigarh", "Raipur", "Rajandgaon", "Sukma", "Surajpur", "Surguja"
        ]
      },
      {
        "id": 7,
        "name": "Daman and Diu",
        "cities": [
          "Daman", "Diu"
        ]
      },
      {
        "id": 8,
        "name": "Goa",
        "cities": [
          "North Goa", "South Goa"
        ]
      },
      {
        "id": 9,
        "name": "Gujrat",
        "cities": [
          "Ahmedabad", "Amreli", "Anand", "Aravali", "Banaskantha", "Bharuch", "Bhavnagar", "Botad", "Chota Udaipur", "Dahod", "Dang", "Devbhoomi Dwarka", "Gandhinagar", "Gir Somnath", "Jamnagar", "Junagadh", "Kutch", "Kheda", "Mahisagar", "Mehsana", "Morbi", "Narmada", "Navsari", "Panchmahal", "Patan", "Porbandar", "Rajkot", "Sabarkantha", "Surat", "Surendranagar", "Tapi", "Vadodara", "Valsad"
        ]
      },
      {
        "id": 10,
        "name": "Haryana",
        "cities": [
          "Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad", "Gurugram", "Hisar", "Jhajjar", "Jind", "Kaithal", "Karnal", "Kurukshetra", "Mahendragarh", "Nuh", "Palwal", "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa", "Sonipat", "Yamunanagar"
        ]
      },
      {
        "id": 11,
        "name": "Himachal Pradesh",
        "cities": [
          "Bilaspur", "Chamba", "Hamirpur", "Kangra", "Kinnaur", "Kullu", "Lahaul and Spiti", "Mandi", "Shimla", "Sirmaur", "Solan", "Una"
        ]
      },
      {
        "id": 12,
        "name": "Jammu and Kashmir",
        "cities": [
          "Anantnag", "Bandipora", "Baramulla", "Budgam", "Doda", "Ganderbal", "Jammu", "Kathua", "Kishtwar", "Kulgam", "Kupwara", "Kargil", "Leh", "Poonch", "Pulwama", "Rajouri", "Ramban", "Reasi", "Samba", "Shopian", "Srinagar", "Udhampur", ""
        ]
      },
      {
        "id": 13,
        "name": "Jharkhand",
        "cities": [
          "Garhwa", "Palamu", "Latehar", "Chatra", "Hazaribagh", "Koderma", "Giridih", "Ramgarh", "Bokaro", "Dhanbad", "Gumla", "Lohardaga", "Simdega", "Ranchi", "Khunti", "West Singhbhum", "Saraikela Kharsawan", "East Singhbhum", "Jamtara", "Deoghar", "Dumka", "Pakur", "Godda", "Sahebganj"
        ]
      },
      {
        "id": 14,
        "name": "Karnataka",
        "cities": [
          "Bagalkot", "Banglore", "Belgaum", "Ballari", "Bidar", "Bijapur", "Chamarajanagar", "Chikballapur", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada", "Davanagere", "Dharwad", "Gadag", "Gulbarga", "Hassan", "Haveri", "Kodagu", "Kolar", "Koppal", "Mandya", "Mysore", "Raichur", "Ramanagara", "Shimoga", "Tumkur", "Udupi", "Uttara Kannada", "Yadgir"
        ]
      },
      {
        "id": 15,
        "name": "Kerala",
        "cities": [
          "Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam", "Kozhikode", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram", "Thrissur", "Wayanad"
        ]
      },
      {
        "id": 16,
        "name": "Ladakh",
        "cities": [
          "Kargil", "Leh"
        ]
      },
      {
        "id": 17,
        "name": "Madhya Pradesh",
        "cities": [
          "Bhopal", "Raisen", "Rajgarh", "Sehore", "Vidisha", "Morena", "Sheopur", "Bhind", "Gwalior", "Ashoknagar", "Shivpuri", "Datia", "Guna", "Alirajpur", "Barwani", "Burhanpur", "Indore", "Dhar", "Jhabua", "Khandwa", "Khargone", "Balaghat", "Chhindwara", "Jabalpur", "Katni", "Mandla", "Narshinghpur", "Seoni", "Dindori", "Betul", "Harda", "Hoshangabad", "Rewa", "Satna", "Sidhi", "Singrauli", "Chhatarpur", "Damoh", "Panna", "Sagar", "Tikamgarh", "Niwari", "Anuppur", "Shahdol", "Umaria", "Agar Malwa", "Dewas", "Mandsaur", "Neemuch", "Ratlam", "Shajapur", "Ujjain"
        ]
      },
      {
        "id": 18,
        "name": "Maharashtra",
        "cities": [
          "Ahemednagar", "Akola", "Amravati", "Aurangabad", "Beed", "Bhandara", "Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kolhapur", "Latur", "Mumbai City", "Mumbai Suburban", "Nagpur", "Nanded", "Nandurbar", "Nashik", "Osmanabad", "Palghar", "Parbhani", "Pune", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal"
        ]
      },
      {
        "id": 19,
        "name": "Manipur",
        "cities": [
          "Bishnupur", "Chandel", "Churachandpur", "Imphal-East", "Imphal-West", "Senapati", "Tamenglong", "Thoubal", "Ukhrul", "Kangpokpi", "Tengnoupal", "Pherzawl", "Noney", "Kamjong", "Jiribam", "Kakching"
        ]
      },
      {
        "id": 20,
        "name": "Meghalaya",
        "cities": [
          "West Jaintia Hills", "East Jaintia Hills", "East Khasi Hills", "West Khasi Hills", "South West Khasi Hills", "Ri-Bhoi", "North Garo Hills", "East Garo Hills", "South Garo Hills", "West Garo Hills", "South West Garo Hills"
        ]
      },
      {
        "id": 21,
        "name": "Mizoram",
        "cities": [
          "Aizawl", "Kolasib", "Lawngtlai", "Lunglei", "Mamit", "Saiha", "Serchhip", "Champhai", "Hnahthial", "Khawzawl", "Saitual"
        ]
      },
      {
        "id": 22,
        "name": "Nagaland",
        "cities": [
          "Dimapur", "Kiphire", "Kohima", "Longleng", "Mokokchung", "Mon", "Peren", "Phek", "Tuensang", "Wokha", "Zunheboto", "Noklak"
        ]
      },
      {
        "id": 23,
        "name": "Odisha",
        "cities": [
          "Angul", "Boudh", "Balangir", "Bargarh", "Balasore", "Bhadrak", "Cuttack", "Debagarh", "Dhenkanal", "Ganjam", "Gajapati", "Jharsuguda", "Jajpur", "Jagatsinghapur", "Khordha", "Kendujhar", "Bhawanipatna", "Phulbani", "Koraput", "Kendrapara", "Malkangiri", "Mayurbhanj", "Nabarangpur", "Nuapada", "Nayagarh", "Puri", "Rayagada", "Sambalpur", "Subarnapur", "Sundargarh"
        ]
      },
      {
        "id": 24,
        "name": "Puducherry",
        "cities": [
          "Karaikal", "Mahe", "Pondicherry", "Yanam"
        ]
      },
      {
        "id": 25,
        "name": "Punjab",
        "cities": [
          "Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Firozpur", "Fazilka", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Mansa", "Moga", "Sri Muktsar Sahib", "Pathankot", "Patiala", "Rupnagar", "Sahibzada Ajit Singh Nagar", "Sangrur", "Shahid Bhagat Singh Nagar", "Tarn Taran"
        ]
      },
      {
        "id": 26,
        "name": "Rajasthan",
        "cities": [
          "Ajmer", "Alwar", "Banswara", "Baran", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur", "Hanumangarh", "Jaipur", "Jaisalmer", "Jalor", "Jhalawar", "Jhunjhunu", "Jodhpur", "Karauli", "Kota", "Nagaur", "Pali", "Pratapgarh", "Rajsamand", "Sawai Madhopur", "Sri Ganganagar", "Tonk", "Udaipur"
        ]
      },
      {
        "id": 27,
        "name": "Sikkim",
        "cities": [
          "Gangtok", "Mangan", "Namchi", "Geyzing"
        ]
      },
      {
        "id": 28,
        "name": "Tamil Nadu",
        "cities": [
          "Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharamapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram", "Kanniyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram", "Ranipet", "Salem", "Sivagangai", "Tenkasi", "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", "Tirupattur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar"
        ]
      }
      , {
        "id": 29,
        "name": "Telangana",
        "cities": [
          "Adilabad", "Bhadradri", "Hyderabad", "Jagitial", "Jangaon", "Jayashankar Bhupalpally", "Jogulamba Godwal", "Kamareddy", "Karimnagar", "Khammam", "Komaram Bheem", "Mahabubabad", "Mahabubnagar", "Mancherial", "Medak", "Medchal-Malkajgiri", "Mulugu", "Nagarkurnool", "Narayanpet", "Nalgonda", "Nirmal", "Nizamabad", "Peddapalli", "Rajanna Sircilla", "Ranga Reddy", "Sangareddy", "Siddipet", "Suryapet", "Vikarabad", "Wanaparthy", "Warangal Rural", "Warangal Urban", "Yadadri Bhuvanagiri"
        ]
      },
      {
        "id": 30,
        "name": "Tripura",
        "cities": [
          "Dhalai", "Sipahijala", "Khowai", "Gomati", "Unakoti", "North Tripura", "South Tripura", "West Tripura"
        ]
      },
      {
        "id": 31,
        "name": "Uttar Pradesh",
        "cities": [
          "Agra", "Aligarh", "Allahabad", "Ambedkar Nagar", "Amethi", "Amroha", "Auraiya", "Azamgarh", "Badaun", "Bagpat", "Bahraich", "Ballia", "Balrampur", "Banda", "Barabanki", "Bareilly", "Basti", "Bijnor", "Bulandshahr", "Chandauli", "Chitrakoot", "Deoria", "Etah", "Etawah", "Faizabad", "Farrukhabad", "Fatehpur", "Firozabad", "Gautam Buddha Nagar", "Ghaziabad", "Ghazipur", "Gonda", "Gorakhpur", "Hamirpur", "Hapur", "Hardoi", "Hathras", "Jalaun", "Jaunpur", "Jhansi", "Kannauj", "Kanpur Dehat", "Kanpur Nagar", "Kasganj", "Kasushambi", "Kushinagar", "Lakhimpur Kheri", "Lalitpur", "Lucknow", "Maharajganj", "Mahoba", "Mainpuri", "Mathura", "Mau", "Meerut", "Mirzapur", "Moradabad", "Muzaffarnagar", "Pilibhit", "Pratapgarh", "Rae Bareli", "Rampur", "Saharanpur", "Sant Kabir Nagar", "Sant Ravidas Nagar", "Sambhal", "Shahjahanpur", "Shamli", "Shravasti", "Siddharthnagar", "Sitapur", "Sonbhadra", "Sultanpur", "Unnao", "Varanasi"
        ]
      },
      {
        "id": 32,
        "name": "Uttarakhand",
        "cities": [
          "Almora", "Bageshwar", "Chamoli", "Champawat", "Dehradun", "Haridwar", "Nainital", "Pauri Garhwal", "Pithoragarh", "Rudraprayag", "Tehri Garhwal", "Udham Singh Nagar", "Uttarkashi"
        ]
      },
      {
        "id": 33,
        "name": "West Bengal",
        "cities": [
          "Alipurduar", "Bankura", "Paschim Bardhaman", "Purba Bardhaman", "Birbhum", "Cooch Behar", "Darjeeling", "Uttar Dinajpur", "Dakshin Dinajpur", "Hooghly", "Howrah", "Jalpaiguri", "Jhargram", "Kolkata", "Kalimpong", "Malda", "Paschim Medinipur", "Purba Medinipur", "Murshidabad", "Nadia", "Barasat", "Alipore", "Purulia"
        ]
      }
    ]
  }


  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @description : This method will set default language .
   */
  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      // this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
      // ).subscribe(search => this.getValues(search));
    }
    catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
      //clsGlobal.logManager.writeErrorLog('RegistrationPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("RegistrationPage", "", "VISIT", "");
  }
  /**
   * @author : Rajendra Sirvi
   * @date : 22/10/2020
   * @description : Get User Name and make it to UpperCase
   */
  getUserName($event) {
    try {
      let UserIdUpperCase = $event.target.value.toUpperCase();
      // this.registrationForm.get('userNameCtrl').setValue(UserIdUpperCase, {
      //   onlyself: true
      // });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "getUserName", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'getUserName',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



  /**
 * @author : Rajendra Sirvi
 * @date : 22/10/2020
 * @description : This method will loads districts as per selected state .
 */
  loadDistrictsForSelectedState(stateSelected) {
    try {
      this.selectedCity = '';
      this.citiesList = stateSelected.cities;
      this.searchText = stateSelected.name.toUpperCase();
      this.showStateList = false;
      this.searchCities = '';
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "loadDistrictsForSelectedState", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'loadDistrictsForSelectedState',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setCity(city) {
    try {
      this.searchCities = city.toUpperCase();
      this.showCitiesList = false;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "setCity", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'setCity',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



  // search($event) {
  //   if ($event) {
  //     console.log($event)
  //     this.searchText = $event.toUpperCase();
  //     this.searchTextChanged.next($event);
  //     this.city = [];
  //     this.searchCities = '';
  //     // this.citiesList = [];
  //   }
  // }

  // searchCityData($event) {
  //   if ($event) {
  //     this.searchCities = $event.toUpperCase();
  //     this.searchTextChanged.next($event);
  //     this.showStateList = false;
  //   }
  // }

  // getValues(search) {
  //   try {
  //     this.searchTextEntered = search.toUpperCase();
  //     let filteredStates = this.states.filter(x => {
  //       return (x.name).toUpperCase().indexOf(this.searchTextEntered.toUpperCase()) !== -1
  //     });
  //     let filteredCities = this.citiesList.filter(x => {
  //       return x.toUpperCase().indexOf(this.searchTextEntered.toUpperCase()) !== -1
  //     });
  //     if (filteredStates.length > 0 && filteredCities.length == 0) {
  //       this.showStateList = true;
  //       this.state = filteredStates;
  //     }
  //     if (filteredCities.length > 0) {
  //       this.showCitiesList = true;
  //       this.city = filteredCities;
  //     }

  //   } catch (error) {
  //     console.log(error)
  //   }
  // }

  /**
* @author : Rajendra Sirvi
* @date : 22/10/2020
* @description : This method will search state from states array.
*/
  searchState(event) {
    try {
      this.searchText = event.target.value.toUpperCase();
      this.searchCities = '';
      this.citiesList = [];
      let filteredStates = this.states.filter(x => {
        return (x.name).toUpperCase().indexOf(this.searchText.toUpperCase()) !== -1
      });

      if (filteredStates.length > 0) {
        this.showStateList = true;
        this.state = filteredStates;
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "searchState", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'searchState',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
* @author : Rajendra Sirvi
* @date : 22/10/2020
* @description : This method will search city from citiesList array as per user input.
*/
  searchCity(event) {
    try {
      this.searchCities = event.target.value.toUpperCase();
      let filteredCities = this.citiesList.filter(x => {
        return x.toUpperCase().indexOf(this.searchCities.toUpperCase()) !== -1
      });

      if (filteredCities.length > 0) {
        this.showCitiesList = true;
        this.city = filteredCities;
      } else if (filteredCities.length == 0) {
        this.showCitiesList = false;
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "searchCity", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'searchCity',error.Message,undefined,error.stack,undefined,undefined));
      
    }
  }

  /**
 * @author : Rajendra Sirvi
 * @date : 22/10/2020
 * @description : This method will do registration of user .
 */
  doRegistration() {
    try {
      let isValid = this.validateForm();
      if (!isValid) return;
      let registrationReq = {
        api_key: clsGlobal.apiKey,
        user_name: this.registrationForm.get('userNameCtrl').value.toUpperCase().trim(),
        mobile_number: this.registrationForm.get('mobileNoCtrl').value,
        state: this.registrationForm.get('stateCtrl').value,
        city: this.registrationForm.get('cityCtrl').value,
        email_id: this.registrationForm.get('emailIdCtrl').value.trim(),
        plugin_info: this.pluginData,

      }
      this.authService.userRegistration(registrationReq).then((resp: any) => {
        if (resp.status == "Success") {
          if (resp.code == "s-101") {
            if (resp.message == "Mobile Number or Email Id already registered") {
              this.toastCtrl.showAtBottom(resp.message);
            } else if (resp.message == "Registration Successful") {
              this.registered = !this.registered;
              setTimeout(() => {
                this.navCtrl.navigateBack(['/signin']);
              }, 2000);
            }
          }
        }
      }).catch(error => {
        this.toastCtrl.showAtBottom(error);
        //clsGlobal.ConsoleLogging("Error", "doRegistration_1", error);
        //clsGlobal.logManager.writeErrorLog('RegistrationPage', 'doRegistration_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'doRegistration_1',error.Message,undefined,error.stack,undefined,undefined));
      })
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "doRegistration_2", error);
      //clsGlobal.logManager.writeErrorLog('RegistrationPage', 'doRegistration_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'doRegistration_2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
 * @author : Rajendra Sirvi
 * @date : 22/10/2020
 * @description : This method will do form input fields validations .
 */
  validateForm() {
    try {
      if (this.registrationForm.get('userNameCtrl').value == '') {
        this.userNameErr = 'Please enter valid User Name.';
        return false;
      }
      if (this.registrationForm.get('mobileNoCtrl').value == '' || this.registrationForm.get('mobileNoCtrl').value.length < 10) {
        this.mobileErr = 'Please enter valid mobile Number.';
        return false;
      }
      if (this.registrationForm.get('emailIdCtrl').value == '') {
        this.emailIdErr = 'Please enter valid Email Id.'
        return false;
      }
      return true;
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "validateForm", error);
      //clsGlobal.logManager.writeErrorLog("RegistrationPage", "validateForm", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'validateForm',error.Message,undefined,error.stack,undefined,undefined));
      return false;
    }
  }

  /**
 * @author : Rajendra Sirvi
 * @date : 22/10/2020
 * @description : This method will clear error below input box on key up .
 */
  onKeyUp(event) {
    try {
      this.emailIdErr = '';
      this.mobileErr = '';
      this.userNameErr = '';
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "onKeyUp", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('RegistrationPage', 'onKeyUp',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
}
