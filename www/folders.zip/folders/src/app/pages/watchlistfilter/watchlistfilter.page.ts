import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';

@Component({
  selector: 'app-watchlistfilter',
  templateUrl: './watchlistfilter.page.html',
})
export class WatchlistfilterPage implements OnInit {


  alphabetAsc: boolean = false;
  priceAsc: boolean = false;
  percentAsc: boolean = false;

  selSorting: any = '';
  selSortingType: any = '';

  filterType: any = {};
  isFilterApplied: boolean = false;

  // isEquity: boolean = false;
  // isCommodity: boolean = false;
  // isCurrency: boolean = false;

  // isBSE: boolean = false;
  // isNSE: boolean = false;
  // isFAO: boolean = false;

  // filterApplied = [];
  userTypefilter = '';
  selWatchlist: any;
  keyFilter = '';
  arrWatchFilters = [];

  constructor(private navCtrl: NavController,
    private localStorage: clsLocalStorageService,
    private route: ActivatedRoute) {
    this.filterType.isEquity = false;
    this.filterType.isCommodity = false;
    this.filterType.isCurrency = false;
    this.filterType.isBSE = false;
    this.filterType.isNSE = false;
    this.filterType.isFAO = false;
    this.selWatchlist = this.route.snapshot.queryParams.profile != undefined ? this.route.snapshot.queryParams.profile : null;
  }

  ngOnInit() {
    this.userTypefilter = !clsGlobal.IsGuestUser ? clsConstants.LOCAL_STORAGE_WATCHLIST_FILTER : clsConstants.LOCAL_STORAGE_GUEST_WATCHLIST_FILTER;
    this.keyFilter = clsGlobal.User.userId + "_" + this.selWatchlist.nWatchListId;

  }
  ionViewDidEnter() {

    try {
      this.localStorage.getItem(this.userTypefilter).then(filter => {
        if (filter != undefined) {
          this.arrWatchFilters = JSON.parse(filter) || [];

          let selFilter = this.arrWatchFilters.filter(item => {
            return item.filterId == this.keyFilter;
          });

          if (selFilter.length > 0) {
            let objSortnFilter = selFilter[0].filter;

            this.filterType = objSortnFilter.filter;
            this.selSorting = objSortnFilter.sorting;
            this.selSortingType = objSortnFilter.sortingType;
          }

        }
      });
      //console.log('Filter Page Init.');
      /*
      if (clsGlobal.User.watchlistFilter != undefined) {
  
        this.isFilterApplied = true;
        this.filterType = clsGlobal.User.watchlistFilter.filter;
        this.selSorting = clsGlobal.User.watchlistFilter.sorting;
        this.selSortingType = clsGlobal.User.watchlistFilter.sortingType;
  
      } else {
        this.localStorage.getItem(this.userTypefilter).then(filter => {
          if (filter != undefined) {
            let objSortnFilter = JSON.parse(filter);
            this.filterType = objSortnFilter.filter;
            this.selSorting = objSortnFilter.sorting;
            this.selSortingType = objSortnFilter.sortingType;
          }
        });
      }
      */
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistfilterPage', 'ngOnInit', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  setSortType(sortName, sortType) {
    this.selSorting = sortName;
    this.selSortingType = sortType;
    this.isFilterApplied = true;
  }

  setFilterType(filterType) {
    try {
      if (filterType == 'Equity') {
        this.filterType.isEquity = !this.filterType.isEquity;
      }
      else if (filterType == 'Commodity') {
        this.filterType.isCommodity = !this.filterType.isCommodity;
      }
      else if (filterType == 'Currency') {
        this.filterType.isCurrency = !this.filterType.isCurrency;
      }
      else if (filterType == 'BSE') {
        this.filterType.isBSE = !this.filterType.isBSE;
      }
      else if (filterType == 'NSE') {
        this.filterType.isNSE = !this.filterType.isNSE;
      }
      else if (filterType == 'FAO') {
        this.filterType.isFAO = !this.filterType.isFAO;
      }
      this.isFilterApplied = true;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistfilterPage', 'setFilterType', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  clearFilter() {
    try {
      this.selSorting = '';
      this.selSortingType = '';

      this.filterType.isEquity = false;
      this.filterType.isCommodity = false;
      this.filterType.isCurrency = false;
      this.filterType.isBSE = false;
      this.filterType.isNSE = false;
      this.filterType.isFAO = false;

      this.isFilterApplied = false;
      // if(!clsGlobal.IsGuestUser)
      // this.localStorage.setObject(clsConstants.LOCAL_STORAGE_WATCHLIST_FILTER, undefined);
      // else{
      //   this.localStorage.setObject(clsConstants.LOCAL_STORAGE_GUEST_WATCHLIST_FILTER, undefined);
      // }
      this.localStorage.setObject(this.userTypefilter, undefined);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistfilterPage', 'clearFilter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  goBack() {
    try {
      let filterSorting: any = {};
      filterSorting.sorting = this.selSorting;
      filterSorting.sortingType = this.selSortingType;
      filterSorting.filter = this.filterType;

      //clsGlobal.User.watchlistFilter = filterSorting;

      let objFilter: any = {};
      objFilter.filterId = this.keyFilter;
      objFilter.filter = filterSorting;
      let isExists = false;
      for (let index = 0; index < this.arrWatchFilters.length; index++) {
        const filter = this.arrWatchFilters[index];
        if (this.keyFilter == filter.filterId) {
          this.arrWatchFilters.splice(index, 1);
          this.arrWatchFilters.push(objFilter);
          isExists = true;
          break;
        }
      }

      if (!isExists) {
        this.arrWatchFilters.push(objFilter);
      }

      this.localStorage.setObject(this.userTypefilter, this.arrWatchFilters);//filterSorting

      this.navCtrl.pop();
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('WatchlistfilterPage', 'goBack', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

}
