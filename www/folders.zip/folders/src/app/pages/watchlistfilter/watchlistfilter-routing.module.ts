import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WatchlistfilterPage } from './watchlistfilter.page';

const routes: Routes = [
  {
    path: '',
    component: WatchlistfilterPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class WatchlistfilterPageRoutingModule {}
