import { Component, OnInit } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { NavController, Platform } from '@ionic/angular';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { NavigationExtras, Router } from '@angular/router';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { Hub } from 'aws-amplify';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html'
})
export class HomePage implements OnInit {
  ShowOTPConfirm: boolean = false;
  enterManualOTP: boolean = false;
  showOTPDone: boolean = false;
  maxTelChar: number = 10; // Mobile no max char for input
  guestTelNo: string = ""; // To store entered mobile no.
  guestNo: string; // To stored splited mobile no.
  firstDigits: string; //To stored 1st two digit of mobile No
  lastDigits: string; //To stored last two digit of mobile No
  OTPGenerateClick: boolean = true; // to enabled or disabled verify button
  OTPVerifyClick: boolean = true; // to enabled or disabled otp verify button
  maxOTPChar: number = 6; // Mobile no max char for input
  timerId: any;
  timerValue: number; //otp time span value
  timerStarted: boolean = false;
  selectedCountry: any = "91"; // to set default value of country code
  enteredOTP: string; // to stored entered otp
  invalidOTPCnt: number = 0; // invalid OTP count
  maxInvalidOTPAttempt: number = 3;//allowed maximum OTP attempt
  hashCode: any; // to get hash key for msg
  isAndroid: boolean = false; // to check platform is present or not
  isCordova: boolean;
  enableRegenerateOTP: boolean = false; // enable disable re-generate otp
  maxEnableRegenerateOTP: number = 3;// x number of times it will enable 
  enableRegenerateOTPAttempt: number = 0;
  autoVerifyOTP: boolean = false;


  constructor(private splashScreen: SplashScreen,
    private alertCtrl: AlertServicesProvider,
    private httpService: clsHttpService,
    private toastProvider: ToastServicesProvider,
    private smsRetriever: SmsRetriever,
    public platform: Platform,
    private nav: NavController,
    private localstorageservice: clsLocalStorageService,
    private db: DatabaseService, private navCtrl: NavController,
    private router: Router,
    private appSync: AppsyncDbService,
    private watchlistServ: WatchlistService,) {
    this.isAndroid = this.platform.is('android');
    this.isCordova = this.platform.is('cordova');
  }
  ngOnInit() {
    this.splashScreen.hide();
    try {
      // this.alertCtrl.showPromtBox( async (data:any) => {
      //   clsGlobal.ComId=data.comId;
      //   clsGlobal.LocalComId=data.comId+"/";
      //   clsGlobal.dConfigMaster.Add("APP_ODIN_API_KEY",data.apiKey);
      //   //clsGlobal.dConfigMaster["APP_ODIN_API_KEY"]=data.apiKey;
      // }, async () => {
      //     console.log("Do nothing.");
      // });
      //let x = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length;
      //let y =  parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT));
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT) && clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length > 0) {
        this.maxInvalidOTPAttempt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT));
      }
      this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == '' ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));

    } catch (error) {
      console.log('error in sql data fetching ' + error);
      clsGlobal.logManager.writeErrorLog("home", "ngOnInit", error.message);
    }
  }

  ionViewWillEnter() {
    console.log("Inside home page.");
    //this.getHash(); this is one time call no need to call again
  }

  /**
   * Desc : This function is to get hash string of APP.
   *  @return {Promise<string>} Returns a promise that resolves when successfully generate hash of APP.
   */
  getHash() {
    try {
      if (typeof (this.smsRetriever) === 'undefined') {
        // Error: plugin not installed
        console.log('SMSRetriever: plugin not present');
      }
      else {
        console.log('SMSRetriever: plugin present');
        this.smsRetriever.getAppHash().then((res: any) => {

          this.hashCode = res;
        })
          .catch((error: any) => {
            alert(error);
            clsGlobal.logManager.writeErrorLog("home", "getHash_1", error.message);
          });
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "getHash_2", error.message);
    }
  }

  /**
   * Desc : This function start wathching message arrive event and retrive message text.
   *  @return {Promise<string>} Returns a promise that resolves when retrives SMS text or TIMEOUT after 5 min.
   */
  async retrieveSMS() {
    try {
      if (typeof (this.smsRetriever) === 'undefined') {
        // Error: plugin not installed
        console.log('SMSRetriever: plugin not present');
      }
      else {
        console.log('SMSRetriever: plugin present');
        await this.smsRetriever.startWatching().then((res: any) => {
          this.autoVerifyOTP = true;
          this.enteredOTP = res.Message.toString().substr(0, 6);
        }).catch((error: any) => {
          clsGlobal.logManager.writeErrorLog("home", "retrieveSMS_1", error.message);
        });
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "retrieveSMS_2", error.message);
    }
  }

  /**
   * Desc : To check length of mobile no and enable the button 
   * @param event : to get user entered mobile no
   */
  checkDataEnter(event) {
    try {
      this.OTPGenerateClick = event.detail.value.trim().length == this.maxTelChar ? false : true;//guestTelNo
      //this.OTPGenerateClick = this.guestTelNo.trim().length == this.maxTelChar ? false : true;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "checkDataEnter", error.message);
    }
  }

  /**
   * Desc : To check the length of entered OTP by user and enable the verify button
   * @param event : To get user enter OTP in manually enter
   */
  checkOTPEnter(event) {
    try {
      this.OTPVerifyClick = event.detail.value.trim().length == this.maxOTPChar ? false : true;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "checkOTPEnter", error.message);
    }
  }

  /**
   * Desc : Verify the mobile no and send OTP to user 
   */
  VerifyOTP() {
    try {
      this.localstorageservice.remove(clsConstants.LOCAL_STORAGE_USER_DETAILS);
      this.localstorageservice.setItem("PROFILE_PICTURE","");
      this.firstDigits = this.guestTelNo.substr(0, 2);
      this.lastDigits = this.guestTelNo.substr(8, 2);
      this.guestNo = this.firstDigits + "XXXXXX" + this.lastDigits;// changes done as per current ui
      let guestRegistrationData: any = {}; // to send guest registration request object
      guestRegistrationData.Type = 2;
      guestRegistrationData.deviceType = clsGlobal.applicationType;
      guestRegistrationData.email = "";
      guestRegistrationData.groupId = "";
      guestRegistrationData.mobile = "+" + this.selectedCountry + this.guestTelNo;
      guestRegistrationData.pluginData = clsPluginConstants.GetPluginDetails();
      guestRegistrationData.reqType = 1;
      guestRegistrationData.templateId = clsGlobal.User.guestTemplateId;
      guestRegistrationData.userId = this.guestTelNo;
      guestRegistrationData.userType = "G";
      guestRegistrationData.hashCode = this.hashCode;
      // alert("hashcode " + this.hashCode);
      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + clsGlobal.versionId + '/setGuestRegDetail', guestRegistrationData).subscribe(async data => {

        if (data.status == 'success') {
          if (data.data == undefined || data.data == '') {
            this.ShowOTPConfirm = true;
            this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == '' ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));
            this.startTimer();
            //auto otp code
            //await this.retrieveSMS();
            //if (this.isCordova) {

              //this.validateOTP();
            //}
          } else {
            if (!data.data.trial_expired) {

              clsGlobal.User.userId = this.guestTelNo;
              clsGlobal.User.sessionId = data.data.access_token;
              clsGlobal.User.isGuestUser = true;
              clsGlobal.pubsub.publish('MENU_DYNAMIC');

              this.appSync.signingCognitoForTradingUser();
              this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {

                if (item != undefined) {
                  let localData = JSON.parse(item)
                  if (localData.guestMode) {
                    this.toastProvider.showAtBottom(data.message);
                    this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                  }
                  else {
                    this.ShowOTPConfirm = false;
                    this.toastProvider.showAtBottom("Please get registered to keep enjoying the app. Click here to register now!");
                  }
                }
                else {

                  this.toastProvider.showAtBottom(data.message);
                  let userData: any = {}; //{ guestMode: boolean; guestRegistrationDate: Date; userUniqueId: any; } ;//= data; 
                  userData.guestMode = true;
                  userData.userId = this.guestTelNo;
                  userData.access_token = data.data.access_token;
                  userData.guestRegistrationDate = clsConstants.guestRegistrationDate;
                  userData.isGuestUser = true;
                  // userData.userUniqueId = data.data.userUniqueId;
                  this.localstorageservice.remove(clsConstants.LOCAL_STORAGE_USER_DETAILS);
                  this.localstorageservice.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, userData);

                  let navParam: NavigationExtras = {
                    queryParams: { showBackButton: false }
                  }

                  this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_GLOBAL_PROFILE, undefined);
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                  // this.db.isOtherUserProfileExist().then((othExists) => {
                  //   if (othExists) {
                  //     this.watchlistServ.deleteAllWatchlist().then(data => {
                  //     }, error => {
                  //       this.toastProvider.showAtBottom("Error in deleting all profile: " + error);
                  //     })
                  //   }
                  //   this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING, navParam);
                  // })

                }
              });
              /*
              const listener = Hub.listen("datastore", async hubData => {

                if (hubData.payload.event === "ready") {

                  listener();

                  this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {

                    if (item != undefined) {
                      let localData = JSON.parse(item)
                      if (localData.guestMode) {
                        this.toastProvider.showAtBottom(data.message);
                        this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
                      }
                      else {
                        this.ShowOTPConfirm = false;
                        this.toastProvider.showAtBottom("Please get registered to keep enjoying the app. Click here to register now!");
                      }
                    }
                    else {

                      this.toastProvider.showAtBottom(data.message);
                      let userData: any = {}; //{ guestMode: boolean; guestRegistrationDate: Date; userUniqueId: any; } ;//= data; 
                      userData.guestMode = true;
                      userData.userId = this.guestTelNo;
                      userData.guestRegistrationDate = clsConstants.guestRegistrationDate;
                      // userData.userUniqueId = data.data.userUniqueId;
                      this.localstorageservice.remove(clsConstants.LOCAL_STORAGE_USER_DETAILS);
                      this.localstorageservice.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, userData);

                      let navParam: NavigationExtras = {
                        queryParams: { showBackButton: false }
                      }

                      this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_GLOBAL_PROFILE, undefined);



                      // this.db.isOtherUserProfileExist().then((othExists) => {
                      //   if (othExists) {
                      //     this.watchlistServ.deleteAllWatchlist().then(data => {
                      //     }, error => {
                      //       this.toastProvider.showAtBottom("Error in deleting all profile: " + error);
                      //     })
                      //   }
                      //   this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING, navParam);
                      // })

                    }
                  });

                }
              });
              */
            } else {
              // this.ShowOTPConfirm = true;
              this.toastProvider.showAtBottom("Your Guest Trial Period Expired.");
            }

          }

        } else {
          //this.toastProvider.showAtBottom("error in sending message");
          if (data.result == undefined || data.result.message == undefined)
            this.toastProvider.showAtBottom("Unable to do registration. Kindly try after some time.");
          else
            this.toastProvider.showAtBottom(data.message);
        }

      }, error => {
        this.showOTPDone = false;
        this.toastProvider.showAtBottom("Unable to do registration. Kindly try after some time.");
        clsGlobal.logManager.writeErrorLog("home", "VerifyOTP__1", error.message);
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "VerifyOTP_2", error.message);
    }
  }

  /**
   * Desc : To validate the OTP
   */
  validateOTP() {
    try {

      let guestOTPVerificationData: any = {}; //to send guest OTP verification data
      guestOTPVerificationData.OTP = this.enteredOTP;
      guestOTPVerificationData.Type = 2;
      guestOTPVerificationData.deviceType = clsGlobal.applicationType;
      guestOTPVerificationData.email = "";
      guestOTPVerificationData.groupId = "";
      guestOTPVerificationData.mobile = "+" + this.selectedCountry + this.guestTelNo;
      guestOTPVerificationData.pluginData = clsPluginConstants.GetPluginDetails();
      guestOTPVerificationData.reqType = 3,
        guestOTPVerificationData.templateId = clsGlobal.User.guestTemplateId;
      guestOTPVerificationData.userId = this.guestTelNo;
      guestOTPVerificationData.userType = "G";

      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + clsGlobal.LocalComId + clsGlobal.versionId + '/validateGuestOTP', guestOTPVerificationData).subscribe(data => {

        if (data.status == 'success') {
          if (data.code == "s-101") {
            //is guest user login successfully then guestMode is true
            let userData: any = {}; //{ guestMode: boolean; guestRegistrationDate: Date; userUniqueId: any; } ;//= data; 
            userData.guestMode = true;
            userData.guestRegistrationDate = clsConstants.guestRegistrationDate;
            userData.userId = this.guestTelNo;
            userData.access_token = data.data.access_token;
            userData.isGuestUser = true;
            //userData.userUniqueId = data.data.userUniqueId;
            this.localstorageservice.remove(clsConstants.LOCAL_STORAGE_USER_DETAILS);
            this.localstorageservice.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, userData);
            clsGlobal.User.userId = this.guestTelNo;
            clsGlobal.User.sessionId = data.data.access_token;
            clsGlobal.User.isGuestUser = true;
            
            this.toastProvider.showAtBottom(data.message);
            this.enteredOTP = "";

            if (!this.autoVerifyOTP) {
              this.enterManualOTP = !this.enterManualOTP;
            }
            this.showOTPDone = true;
            clsGlobal.pubsub.publish('MENU_DYNAMIC');
            this.appSync.signingCognitoForTradingUser();
           // const listener = Hub.listen("datastore", async hubData => {
             // if (hubData.payload.event === "ready") {

                //listener();
                let navParam: NavigationExtras = {
                  queryParams: { showBackButton: false }
                }

                setTimeout(() => {
                  this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING, navParam);
                }, 2000);
              //} 
           // });

          }
          else {
            this.toastProvider.showAtBottom("Invalid OTP entered. Please enter valid OTP");
          }
        }
        else {
          this.toastProvider.showAtBottom("Invalid OTP entered. Please enter valid OTP");
        }
      }, error => {

        if (error.error.status == "error") {

          // if (this.autoVerifyOTP) {
          this.invalidOTPCnt++;
          //this.enteredOTP = "";
          if (this.invalidOTPCnt > this.maxInvalidOTPAttempt) {

            this.invalidOTPCnt = 0;
            //clearTimeout(this.timerId);
            this.timerStarted = false;
            this.timerValue = 0;
            this.alertCtrl.showAlert('All attempts Exhausted kindly click Resend OTP Button.');
          } else {

            this.toastProvider.showAtBottom("Invalid OTP entered. Please enter valid OTP");
          }
          // }

        }

      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "validateOTP", error.message);
    }
  }

  /**
   * Desc : To re-generate OTP 
   */
  RegenerateOTP() {
    try {
      this.enableRegenerateOTPAttempt++;
      this.enteredOTP = "";
      this.OTPVerifyClick = true;
      this.ShowOTPConfirm = true;
      this.enterManualOTP = false;
      this.showOTPDone = false;
      this.enableRegenerateOTP = false;
      this.VerifyOTP();
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "RegenerateOTP", error.message);
    }
  }

  /**
   * Desc : To start time for OTP verification
   */
  startTimer() {
    try {
      this.timerStarted = true;
      this.timerId = setTimeout(function () {
        if (this.timerValue == 0) {
          this.OTPAttemptValidation();
          this.errorMessage = "OTP not received. Kindly try again.";
          this.timerStarted = false;
        }
        else {
          this.timerValue--;
          this.startTimer();
        }
      }.bind(this), 1000);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("login", "startTimer", error.message);
    }
  }

  OTPAttemptValidation() {

    try {
      if (this.enableRegenerateOTPAttempt > this.maxEnableRegenerateOTP) {
        //this.enableRegenerateOTP = false;
        this.enteredOTP = "";
        this.ShowOTPConfirm = false;
        this.enterManualOTP = false;
        this.enableRegenerateOTPAttempt = 0;
        this.timerValue = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == undefined || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == null || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER) == '' ? "60" : clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTPTIMER));
      }
      else {
        this.enableRegenerateOTP = true;
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "OTPAttemptValidation", error.message);
    }
  }

  /**
   * Desc : To enter OTP manually
   */
  EnterManualOTP() {
    try {
      this.enterManualOTP = true;
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog("home", "EnterManualOTP", error.message);
    }
  }
  goBack() {

   // this.ShowOTPConfirm = !this.ShowOTPConfirm; // false
    if(this.enterManualOTP){
      //this.ShowOTPConfirm = false;
      this.enterManualOTP = false;
    }
    else{
      this.ShowOTPConfirm = false;
    }
    // this.enterManualOTP = false;
    //this.timerValue = 0;
  }
}
