import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OptionChainPageRoutingModule } from './option-chain-routing.module';

import { OptionChainPage } from './option-chain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OptionChainPageRoutingModule
  ],
  declarations: [OptionChainPage]
})
export class OptionChainPageModule {}
