import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ModalController,IonContent } from '@ionic/angular';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';


@Component({
  selector: 'app-option-chain',
  templateUrl: './option-chain.page.html'
})
export class OptionChainPage implements OnInit, OnDestroy {

  @Input() selectContractForOption;
  @Input() distinctOptExpiryDate;
  //@Input() selectedOptionContract;
  selectedOptionContract: any = [];
  @Input() selectedOptionContractData;
  @Input() selectedIdxOptnChain;
  @Input() watchlistData;
  @Input() selecteScrips;
  @Input() scripIndex;
  @Input() saveWatchlistHandle;

  showExpandedRecoFilter = true;
  lstScripKey = [];
  bcastHandler: any;
  assetScripKey: any;
  dcExpiryWiseStrikePrice = new Dictionary<any>();
  divHeight = window.innerHeight;
  @ViewChild('divRecoFilter', { static: false }) divRecoFilter: ElementRef;
  @ViewChild('divScrollOptionChain', { static: false }) divScrollOptionChain: ElementRef;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  isScrollIntoView = false;
  showPopUpOE = false;
  selectedScripObj: any;
  showFullMode: boolean = false;
  showWatchList: boolean = false;
  selecteScripAddToWatchlist: any;
  divDisplay = "none";
  onScrollChanged = new Subject<any>();
  subscription: any;
  viewPortHandler: any;
  dcViewPortScrip = new Dictionary<any>();
  viewPortSubList = [];
  viewPortUnSubList = [];

  constructor(public modalController: ModalController,
    public alertCtrl: AlertServicesProvider,
    public toastProvider: ToastServicesProvider) { }

  ngOnDestroy(): void {
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
    if (this.assetScripKey != undefined)
      this.sendTouchlineRequest(OperationType.REMOVE, [this.assetScripKey]);
    this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
    this.sendAllSubUnsubscribeRequest(OperationType.REMOVE);
  }

  ngOnInit() {
try{
    this.divHeight = window.innerHeight - 201;
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    //this.sendBroadcastReqForOptionChain(this.selectedOptionContract);
    this.viewPortHandler = this.onViewPortItemChange.bind(this);

    this.subscription = this.onScrollChanged.
      pipe(debounceTime(500)).
      subscribe(evt => this.viewPortHandler(evt));

    if (this.selectedOptionContractData != undefined && this.selectedOptionContractData.count > 0) {
      let objScrpKey = new clsScripKey();
      let optionKeys = this.selectedOptionContractData.Keys();
      let assetContract = this.selectedOptionContractData.getItem(optionKeys[0])[0].ceData._source
      objScrpKey.token = assetContract.nAssetToken;
      objScrpKey.MktSegId = clsCommonMethods.getMarketSegmentIdForIndex(assetContract.sExchange);
      this.assetScripKey = objScrpKey;
      this.sendTouchlineRequest(OperationType.ADD, [this.assetScripKey]);
    }

    this.dcExpiryWiseStrikePrice = this.selectedOptionContractData;
    //setTimeout(() => {

    // for (let index = 0; index < this.distinctOptExpiryDate.length; index++) {
    //   const element = this.distinctOptExpiryDate[index];
    //   this.addExpiryWiseStrikePrice(element);
    // }

    this.checkForScrollDivRender();


    this.ShowOptionChain(this.distinctOptExpiryDate[this.selectedIdxOptnChain], this.selectedIdxOptnChain);



    //}, 10);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
  }
}

  hideOptionChain() {
    //this.divScrollOptionChain.nativeElement.scrollTop = 0;

    //this.selectedOptionContract = [];
    //this.recoFilterPane.destroy({ animate: true });
    this.modalController.dismiss();
  }

  ShowOptionChain(expiryDate, idx) {
    try {

      this.selectedIdxOptnChain = idx;
      this.isScrollIntoView = false;
      setTimeout(() => {
        this.divDisplay = "none";


        this.selectedOptionContract = [];
        this.selectedOptionContract = this.dcExpiryWiseStrikePrice.getItem(expiryDate);
        // let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
        // let optCEData = optData.filter(x => x._source.sOptionType == "CE")
        // let optPEData = optData.filter(x => x._source.sOptionType == "PE")
        // for (let i = 0; i < optCEData.length; i++) {
        //   let obj;
        //   optCEData[i].LTP = "0.00";
        //   optCEData[i].NetChangeInRs = "0.00";
        //   optCEData[i].PercNetChange = "0.00";
        //   optCEData[i].OI = "0.00";
        //   optCEData[i].PercOI = "0.00";
        //   optCEData[i].IV = "0";

        //   optPEData[i].LTP = "0.00";
        //   optPEData[i].NetChangeInRs = "0.00";
        //   optPEData[i].PercNetChange = "0.00";
        //   optPEData[i].OI = "0.00";
        //   optPEData[i].PercOI = "0.00";
        //   optPEData[i].IV = "0";

        //   let ceData = optCEData[i]
        //   let peData = optPEData[i]
        //   obj = { "ceData": ceData, "peData": peData }
        //   this.selectedOptionContract.push(obj)
        // }

        if (this.scripLtp != undefined && this.scripLtp != "") {
          if (this.selectedOptionContract.filter(x => x.ceData._source.class == 'call-put-add-money').length == 0) {
            let obj = {
              "ceData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" },
              "peData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" }
            }
            this.selectedOptionContract.push(obj)
            this.selectedOptionContract.sort((a, b) => (parseFloat(a.nStrikePrice1) < parseFloat(b.nStrikePrice1)) ? -1 : 1)
          }
          setTimeout(() => {
            this.moveToSpotPrice();
          }, 1);
        }

        //this.sendBroadcastReqForOptionChain(this.selectedOptionContract);
        this.divDisplay = "block";


      }, 50);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('OptionChainPage', 'ShowOptionChain1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'ShowOptionChain1',error.Message,undefined,error.stack,undefined,undefined));
    }


  }

  addExpiryWiseStrikePrice(expiryDate) {
    try {
      let optionContract = [];
      let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      for (let i = 0; i < optCEData.length; i++) {
        let obj;
        optCEData[i].LTP = "0.00";
        optCEData[i].NetChangeInRs = "0.00";
        optCEData[i].PercNetChange = "0.00";
        optCEData[i].OI = "0.00";
        optCEData[i].PercOI = "0.00";
        optCEData[i].IV = "0";

        optPEData[i].LTP = "0.00";
        optPEData[i].NetChangeInRs = "0.00";
        optPEData[i].PercNetChange = "0.00";
        optPEData[i].OI = "0.00";
        optPEData[i].PercOI = "0.00";
        optPEData[i].IV = "0";

        let ceData = optCEData[i]
        let peData = optPEData[i]
        obj = { "ceData": ceData, "peData": peData }
        optionContract.push(obj);
      }
      this.dcExpiryWiseStrikePrice.Add(expiryDate, optionContract);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'addExpiryWiseStrikePrice',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sendBroadcastReqForOptionChain(selectedData) {
    try {

      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      this.lstScripKey = [];

      for (let i = 0; i < selectedData.length; i++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = selectedData[i].ceData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].ceData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[i].peData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].peData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
        // objScrpKey = new clsScripKey();
        // objScrpKey.token = selectedData[0].peData._source.nAssetToken;
        // objScrpKey.MktSegId = clsCommonMethods.getMarketSegmentIdForIndex(selectedData[i].peData._source.sExchange);
        // this.lstScripKey.push(objScrpKey);
      }

      // if (selectedData.length > 0) {
      //   let objScrpKey = new clsScripKey();
      //   objScrpKey.token = selectedData[0].peData._source.nAssetToken;
      //   objScrpKey.MktSegId = clsCommonMethods.getMarketSegmentIdForIndex(selectedData[0].peData._source.sExchange);
      //   this.lstScripKey.push(objScrpKey);
      // }
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("option-chain", "sendBroadcastReqForOptionChain", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'sendBroadcastReqForOptionChain',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('OptionChainPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  scripLtp: any = '';
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;

      if (this.selectedOptionContract != undefined && this.selectedOptionContract.length > 0) {
        for (let i = 0; i < this.selectedOptionContract.length; i++) {

          if (this.selectedOptionContract[i].ceData.Money == "call-add-money") {
            this.selectedOptionContract[i].ceData._source.nStrikePrice1 = this.scripLtp;
          }
          if (this.selectedOptionContract[i].peData.Money == "put-add-money") {
            this.selectedOptionContract[i].peData._source.nStrikePrice1 = this.scripLtp;
          }

          if (parseFloat(this.scripLtp) > parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1)) {
            if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
              this.selectedOptionContract[i].ceData.Money = "call-background";
            }

          }
          else {
            if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
              this.selectedOptionContract[i].ceData.Money = "put-background";
            }

          }

          if (parseFloat(this.scripLtp) < parseFloat(this.selectedOptionContract[i].peData._source.nStrikePrice1)) {
            if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
              this.selectedOptionContract[i].peData.Money = "call-background";
            }

          }
          else {
            if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
              this.selectedOptionContract[i].peData.Money = "put-background";
            }

          }

          if (this.selectedOptionContract != undefined &&
            this.selectedOptionContract[i].ceData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.selectedOptionContract[i].ceData._source.nToken == objMultiTLResp.Scrip.token) {
            //console.log("Touchline Resp For CE : ", this.selectedOptionContract[i].ceData._source.sSecurityDesc, " LTP: ",objMultiTLResp.LTP);
            this.selectedOptionContract[i].ceData.LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.selectedOptionContract[i].ceData.NetChangeInRs = arrNetChange[0];
            this.selectedOptionContract[i].ceData.PercNetChange = arrNetChange[1];
            this.selectedOptionContract[i].ceData.LTPTrend = arrNetChange[2];
            this.selectedOptionContract[i].ceData.arrowTrend = arrNetChange[3];
            this.selectedOptionContract[i].ceData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;;
            this.selectedOptionContract[i].ceData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;;
            if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) > 0) {
              this.selectedOptionContract[i].ceData.colorOITrend = "color-positive";
            }
            else if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) < 0) {
              this.selectedOptionContract[i].ceData.colorOITrend = "color-negative";
            }
            else {
              this.selectedOptionContract[i].ceData.colorOITrend = "";
            }
            let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLtp),
              parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
              this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objMultiTLResp.LTP, "CALL");
            this.selectedOptionContract[i].ceData.IV = parseFloat(ImpVoltality).toFixed(4);
            break;


          }
          else if (this.selectedOptionContract != undefined &&
            this.selectedOptionContract[i].peData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.selectedOptionContract[i].peData._source.nToken == objMultiTLResp.Scrip.token) {
            //console.log("Touchline Resp For PE : ", this.selectedOptionContract[i].peData._source.sSecurityDesc, " LTP: ",objMultiTLResp.LTP);
            this.selectedOptionContract[i].peData.LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.selectedOptionContract[i].peData.NetChangeInRs = arrNetChange[0];
            this.selectedOptionContract[i].peData.PercNetChange = arrNetChange[1];
            this.selectedOptionContract[i].peData.LTPTrend = arrNetChange[2];
            this.selectedOptionContract[i].peData.arrowTrend = arrNetChange[3];
            this.selectedOptionContract[i].peData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;
            this.selectedOptionContract[i].peData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;
            if (parseFloat(this.selectedOptionContract[i].peData.PercOI) > 0) {
              this.selectedOptionContract[i].peData.colorOITrend = "color-positive";
            }
            else if (parseFloat(this.selectedOptionContract[i].peData.PercOI) < 0) {
              this.selectedOptionContract[i].peData.colorOITrend = "color-negative";
            }
            else {
              this.selectedOptionContract[i].peData.colorOITrend = "";
            }
            let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLtp),
              parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
              this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objMultiTLResp.LTP, "PUT");
            this.selectedOptionContract[i].peData.IV = parseFloat(ImpVoltality).toFixed(4);;

            break;
          }
          else if (this.selectedOptionContract != undefined &&
            this.selectedOptionContract[0].ceData._source.nAssetToken == objMultiTLResp.Scrip.token) {
            this.scripLtp = objMultiTLResp.LTP;
            console.log("Touchline Resp For SPOT : ", this.selectedOptionContract[0].ceData._source.sSecurityDesc, " LTP: ", objMultiTLResp.LTP);
            if (this.selectedOptionContract.filter(x => x.ceData._source.class == 'call-put-add-money').length == 0) {
              let obj = {
                "ceData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" },
                "peData": { _source: { nStrikePrice1: this.scripLtp, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" }
              }
              this.selectedOptionContract.push(obj)
              this.selectedOptionContract.sort((a, b) => (parseFloat(a.nStrikePrice1) < parseFloat(b.nStrikePrice1)) ? -1 : 1)
            }

            this.moveToSpotPrice();
            break;
          }

        }
        this.selectedOptionContract.sort((a, b) => (parseFloat(a.ceData._source.nStrikePrice1) < parseFloat(b.ceData._source.nStrikePrice1)) ? -1 : 1)
      }

      if (this.selectedOptionContract != undefined && this.selectedOptionContract.length == 0 && this.assetScripKey != undefined
        && objMultiTLResp.Scrip.token == this.assetScripKey.token) {
        this.scripLtp = objMultiTLResp.LTP;
      }

    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  moveToLtpPrice()
  {
    this.isScrollIntoView = false;
    this.moveToSpotPrice()
  }

  moveToSpotPrice() {
    try {
      let nearScrip = this.selectedOptionContract.filter(x => parseFloat(x.ceData._source.nStrikePrice1) <= parseFloat(this.scripLtp));
      if (nearScrip.length > 0 && !this.isScrollIntoView) {

        if (this.divRecoFilter != undefined)
          this.divRecoFilter.nativeElement.scrollTop = 0;
        setTimeout(() => {
          let elemnt = document.getElementById(nearScrip[nearScrip.length - 2].ceData._source.nToken);
          if (elemnt != undefined)
            elemnt.scrollIntoView({ behavior: 'smooth' });

        }, 10);

        this.isScrollIntoView = true;

      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'moveToSpotPrice',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  optionchainTop: boolean = false
  optionchainbottom: boolean
  scrollContent(event) {
    try{
    //this.isScrollIntoView = false;
    let titleELe = document.getElementById("0");
    // console.log("titleELe"+titleELe.offsetTop);
    // console.log("scrollTop"+event.detail.scrollTop);
    this.optionchainTop = false;
    this.optionchainbottom = false;   
    if (titleELe != undefined) {
      if (event.srcElement.scrollTop > titleELe.offsetTop + 200) {
        this.optionchainTop = true;
      }

      if (event.srcElement.scrollTop < titleELe.offsetTop - 200) {
        this.optionchainbottom = true;
      }

      if (event.srcElement.scrollTop == titleELe.offsetTop) {
        this.optionchainTop = false;
        this.optionchainbottom = false;
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'scrollContent',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  dateDiffernece(inputdate) {
    try {
      let nextdate: any = new Date(inputdate);
      let curruntData: any = new Date()
      let diffTime = Math.abs(nextdate - curruntData);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'dateDiffernece',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showPopUpOrderEntry(item,buysell) {
    try {
      if (clsGlobal.User.isGuestUser) {
        this.alertCtrl.showAlert(
          "Register now to access this feature!",
          "Order Error!"
        );
        return;
      }
      //let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
      let ScripObj = clsCommonMethods.getScripObject(item._source);;
      // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
      let SegmentId = ScripObj.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = buysell=='B'? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;

      objOEFormDetail.scripDetl = ScripObj.scripDetail;
      objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
      this.selectedScripObj = objOEFormDetail;

      this.showPopUpOE = true;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("OptionChainPage", "showPopUpOrderEntry", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'showPopUpOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode = false;
    //this.modalController.dismiss();
  }

  onFocus(event) {
    this.showFullMode = true;
  }

  watchListSelectionCloseEvent(event) {
    this.showWatchList = false;
  }

  addToGlobalWatchList(item) {
    try {
      if (this.watchlistData != '') {
        let scrip = item._source;
        let isScripExist = this.selecteScrips.filter(item => {
          return item.MktSegId == parseInt(scrip.nMarketSegmentId) && item.Token == scrip.nToken
        });
        if (isScripExist.length == 0) {
          let maxScripCnt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_WATCHLIST_SCRIP_COUNT) || '50')
          if (this.selecteScrips.length >= maxScripCnt) {
            this.toastProvider.showAtBottom(clsConstants.C_S_ERROR_PROFILE_SCRIP);
            return;
          }
          this.selecteScrips.push({ MktSegId: parseInt(scrip.nMarketSegmentId), Token: scrip.nToken, SeqNo: ++this.scripIndex });
        }
        else {
          this.toastProvider.showAtBottom("Scrip already exist in watchlist.");
        }
      } else {
        this.showWatchList = true;
        this.selecteScripAddToWatchlist = clsCommonMethods.getScripObject(item._source);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("option-chain", "addToGlobalWatchList", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'addToGlobalWatchList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  saveWatchlist() {
    this.saveWatchlistHandle();
    this.modalController.dismiss();
  }

  checkForScrollDivRender() {
    try {

      //console.log("Scroll Div:", this.divScrollContent);
      if (this.divScrollOptionChain != undefined) {
        this.divScrollOptionChain.nativeElement.addEventListener("scroll", (event) => {
          if (event) {
            this.onScrollChanged.next(event);
          }
        });

      } else {
        setTimeout(() => {
          this.checkForScrollDivRender();
        }, 400);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'checkForElementReder',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onViewPortItemChange(event) {
    try {
      let element;
      if (event) {
        element = event.srcElement;
      } else {
        element = this.divScrollOptionChain.nativeElement;
      }
      this.scrollContent(event);
      if (element != null || element != undefined) {
        //let container = event.contentElement || event.getNativeElement();
        let containerTop = element.getBoundingClientRect().top;//event.contentTop;
        let containerBottom = element.getBoundingClientRect().bottom;

        if (element.getElementsByClassName('optionchainitem').length > 0) {

          let eleArray = element.getElementsByClassName('optionchainitem');
          this.viewPortSubList = [];
          this.viewPortUnSubList = [];

          for (let index = 0; index < eleArray.length; index++) {
            const element = eleArray[index];
            //ID "0" contains for SPOT broadcast record.
            if (element.id == "0") {
              continue;
            }
            let idData: any = this.selectedOptionContract.filter((item) => {
              return (item.ceData._source.nToken == element.id);
            });

            if (idData == undefined) {
              continue;
            }

            idData = idData[0];
            let eleTop = element.getBoundingClientRect().top;
            let eleBottom = element.getBoundingClientRect().bottom;
            let isInView = clsCommonMethods.isScrolledIntoView(containerTop, containerBottom, eleTop, eleBottom);
            if (isInView && this.dcViewPortScrip.ContainsKey(element.id) == false) {
              let valueObj: any = {};
              valueObj.isInView = isInView;
              valueObj.index = (element.id);
              valueObj.scripDet = idData;
              // Storing the same in ViewPort.
              this.dcViewPortScrip.Add(element.id, valueObj);
              // Scrip is in view so add in subscription list
              let objScrpKey: clsScripKey = new clsScripKey();
              objScrpKey.token = idData.ceData._source.nToken;
              objScrpKey.MktSegId = idData.ceData._source.nMarketSegmentId;
              this.viewPortSubList.push(objScrpKey);

              objScrpKey = new clsScripKey();
              objScrpKey.token = idData.peData._source.nToken;
              objScrpKey.MktSegId = idData.peData._source.nMarketSegmentId;
              this.viewPortSubList.push(objScrpKey);

            }
            else {
              let isSubsribed = this.dcViewPortScrip.getItem(element.id);
              // Scrip is subscribed and not in view.
              if (isSubsribed && !isInView) {
                // remove it from ViewPort
                this.dcViewPortScrip.Remove(element.id);
                // add in unsubscribe list.

                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = idData.ceData._source.nToken;
                objScrpKey.MktSegId = idData.ceData._source.nMarketSegmentId;
                this.viewPortUnSubList.push(objScrpKey);

                objScrpKey = new clsScripKey();
                objScrpKey.token = idData.peData._source.nToken;
                objScrpKey.MktSegId = idData.peData._source.nMarketSegmentId;
                this.viewPortUnSubList.push(objScrpKey);
              }
            }
          }

          this.viewPortSubUnsubscribeRequest();

        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('OptionChainPage', 'onViewPortItemChange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'onViewPortItemChange',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  viewPortSubUnsubscribeRequest() {
    try {

      if (this.viewPortSubList != null && this.viewPortSubList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = OperationType.ADD;
        objTLReq.ScripList = this.viewPortSubList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        objTLReq = null;
      }
      else {
        console.log("Blank subscription list.");
      }

      if (this.viewPortUnSubList != null && this.viewPortUnSubList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = OperationType.REMOVE;
        objTLReq.ScripList = this.viewPortUnSubList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        //this.viewPortUnSubList = null;
        //this.viewPortUnSubList = [];
        objTLReq = null;
      }
      else {
        console.log("Blank un subscription list.");
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('OptionChainPage', 'viewPortSubUnsubscribeRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'viewPortSubUnsubscribeRequest',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  sendAllSubUnsubscribeRequest(opType) {
    try {


      if (this.dcViewPortScrip.Count() > 0) {

        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;

        let tempIndexScripList = [];
        let arrScrip = this.dcViewPortScrip.Keys();
        let cnt = arrScrip.length;
        for (let i = 0; i < cnt; i++) {
          let scripKey = arrScrip[i];
          let optionItem = this.dcViewPortScrip.getItem(scripKey).scripDet;
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = optionItem.ceData._source.nToken;
          objScrpKey.MktSegId = optionItem.ceData._source.nMarketSegmentId;
          tempIndexScripList.push(objScrpKey);

          objScrpKey = new clsScripKey();
          objScrpKey.token = optionItem.peData._source.nToken;
          objScrpKey.MktSegId = optionItem.peData._source.nMarketSegmentId;
          tempIndexScripList.push(objScrpKey);
        }
        objTLReq.ScripList = tempIndexScripList;

        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        tempIndexScripList = null;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sendAllSubUnsubscribeRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'sendAllSubUnsubscribeRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  optionGreekes: any
  showpopupDelta:boolean = false
  showpopupD(data) {
    if (data != undefined) {
      this.optionGreekes = data;
      let callPut = data._source.sOptionType == "CE" ? 0 : 1
      this.showcalculate(this.scripLtp, data._source.nStrikePrice1, 4,
      this.dateDiffernece(data._source.nExpiryDate1), data.IV, callPut)
    }
    this.showpopupDelta = !this.showpopupDelta;
  }


  nTheoCall: any = 0.0;
  nTheoPut: any = 0.0;
  nDeltaCall: any = 0.0;
  nDeltaPut: any = 0.0;
  nGammaCall: any = 0.0;
  nGammaPut: any = 0.0;
  nThetaCall: any = 0.0;
  nThetaPut: any = 0.0;
  nVegaCall: any = 0.0;
  nVegaPut: any = 0.0;
  nRhoCall: any = 0.0;
  nRhoPut: any = 0.0;
  HUNDRED_FLOAT: any = 100.00;
  nDaysUntilExpiration: any = 0.0;
  nActualMarketPrice: any = 0.0;
  showcalculate(nIndexPrice, nStrikePrice, nInterestRate, nDaysUntilExpiration, pVolatility, nOption) {
    try {
      let lnCall, lnPut, lnIndexPrice, lnStrikePrice, lnVolatility, lnInterestRate, lnDaysUntilExpiry, lnDividentYield;
      let lnD1, lnD2;
      let lnstdNormal1, lnstdNormal2, lnstdNormal3, lnstdNormal4;

      lnIndexPrice = nIndexPrice;
      lnStrikePrice = nStrikePrice;
      lnInterestRate = nInterestRate / this.HUNDRED_FLOAT;
      lnDaysUntilExpiry = nDaysUntilExpiration / 365.0;
      lnVolatility = parseFloat((pVolatility)) / this.HUNDRED_FLOAT;

      let lnExponential = Math.exp((-lnInterestRate) * lnDaysUntilExpiry);
      let lnNaturalLog = Math.log(lnIndexPrice / lnStrikePrice);
      let lnVolatilitySq = Math.pow(lnVolatility, 2);
      let lnSqrtDaysUntilExpiry = Math.pow(lnDaysUntilExpiry, 0.5);
      if (parseInt(nDaysUntilExpiration) === 0) {
        this.nGammaCall = 0;
        this.nGammaPut = 0;
        this.nThetaCall = 0;
        this.nThetaPut = 0;
        this.nVegaCall = 0;
        this.nVegaPut = 0;
        this.nRhoCall = 0;
        this.nRhoPut = 0;

        if (nIndexPrice >= nStrikePrice) {
          this.nDeltaCall = 1;
          this.nDeltaPut = 0;
          this.nTheoCall = nIndexPrice - nStrikePrice;
          this.nTheoPut = 0;
        }
        else {
          this.nDeltaCall = 0;
          this.nDeltaPut = -1;
          this.nTheoCall = 0;
          this.nTheoPut = nStrikePrice - nIndexPrice;
        }
        //call or put
        if (nOption === 0) {
          this.nActualMarketPrice = this.nTheoCall;
        }
        if (nOption === 1) {
          this.nActualMarketPrice = this.nTheoPut;
        }
      }
      else {
        lnD1 = (lnNaturalLog + ((lnInterestRate + (lnVolatilitySq / 2)) * lnDaysUntilExpiry)) / (lnVolatility * lnSqrtDaysUntilExpiry);
        lnD2 = lnD1 - lnVolatility * Math.pow((lnDaysUntilExpiry), 0.5);

        lnstdNormal1 = clsCommonMethods.fn_StdNormal(lnD1);
        lnstdNormal2 = clsCommonMethods.fn_StdNormal(lnD2);
        lnstdNormal3 = clsCommonMethods.fn_StdNormal(-lnD2);
        lnstdNormal4 = clsCommonMethods.fn_StdNormal(-lnD1);

        lnCall = lnIndexPrice * lnstdNormal1 - lnStrikePrice * lnExponential * lnstdNormal2;
        lnPut = lnStrikePrice * lnExponential * lnstdNormal3 - lnIndexPrice * lnstdNormal4;

        let lpFormatedCall;
        let lpFormatedPut;
        //**
        lpFormatedCall = lnCall.toFixed(4);
        lpFormatedPut = lnPut.toFixed(4);

        // this.nCall = lpFormatedCall;
        // this.nPut = lpFormatedPut;

        let lnDeltaCall, lnDeltaPut;
        let lpFormatedDeltaCall;
        let lpFormatedDeltaPut;
        lnDeltaCall = lnstdNormal1;

        lnDeltaPut = lnstdNormal1 - 1;
        lpFormatedDeltaCall = lnDeltaCall.toFixed(4);
        lpFormatedDeltaPut = lnDeltaPut.toFixed(4);
        this.nDeltaCall = parseFloat(lpFormatedDeltaCall);
        this.nDeltaPut = parseFloat(lpFormatedDeltaPut);

        let Normalpdf = Math.exp(-Math.pow(lnD1, 2) / 2) / 2.507132680972429;//Math.sqrt(2 * 3.14285714); // impr

        let lnGammaCall, lnGammaPut;
        let lpFormatedGammaCall;
        let lpFormatedGammaPut;
        lnGammaCall = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
        lnGammaPut = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
        lpFormatedGammaCall = lnGammaCall.toFixed(4);
        lpFormatedGammaPut = lnGammaPut.toFixed(4);
        this.nGammaCall = parseFloat(lpFormatedGammaCall);
        this.nGammaPut = parseFloat(lpFormatedGammaPut);


        let lnThetaCall, lnThetaPut;
        let lpFormatedThetaCall;
        let lpFormatedThetaPut;
        lnThetaCall = -((lnIndexPrice * Normalpdf * lnVolatility) / 2.0 / lnSqrtDaysUntilExpiry) -
          (lnInterestRate * lnStrikePrice * lnExponential * lnstdNormal2);
        lnThetaPut = -(lnIndexPrice * Normalpdf * lnVolatility / 2.0 / lnSqrtDaysUntilExpiry)
          + (lnInterestRate * lnStrikePrice * lnExponential * (1 - lnstdNormal2));

        lnThetaCall = (lnThetaCall / 365.0);
        lpFormatedThetaCall = lnThetaCall.toFixed(4);
        lnThetaPut = (lnThetaPut / 365.0);
        lpFormatedThetaPut = lnThetaPut.toFixed(4);
        this.nThetaCall = parseFloat(lpFormatedThetaCall);
        this.nThetaPut = parseFloat(lpFormatedThetaPut);


        let lnVegaCall, lnVegaPut;
        let lpFormatedVegaCall;
        let lpFormatedVegaPut;
        lnVegaCall = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;
        lnVegaPut = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;

        lnVegaCall = lnVegaCall / 100.0;
        lpFormatedVegaCall = lnVegaCall.toFixed(4);
        lnVegaPut = lnVegaPut / 100.0;
        lpFormatedVegaPut = lnVegaPut.toFixed(4);

        this.nVegaCall = parseFloat(lpFormatedVegaCall);
        this.nVegaPut = parseFloat(lpFormatedVegaPut);

        let lnRhoCall, lnRhoPut;
        let lpFormatedRhoCall;
        let lpFormatedRhoPut;
        lnRhoCall = lnStrikePrice * lnExponential * lnDaysUntilExpiry * lnstdNormal2;
        lnRhoPut = -lnDaysUntilExpiry * lnExponential * (lnIndexPrice) * lnstdNormal3;
        lnRhoCall = lnRhoCall / 100.0;
        lpFormatedRhoCall = lnRhoCall.toFixed(4);
        lnRhoPut = lnRhoPut / 100.0;
        lpFormatedRhoPut = lnRhoPut.toFixed(4);
        this.nRhoCall = parseFloat(lpFormatedRhoCall);
        this.nRhoPut = parseFloat(lpFormatedRhoPut);

        // this.nTheoCall = this.nCall;
        // this.nTheoPut = this.nPut;
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('OptionChainPage', 'showpopupD',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



}
