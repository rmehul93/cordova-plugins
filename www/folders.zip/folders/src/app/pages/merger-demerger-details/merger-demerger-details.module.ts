import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MergerDemergerDetailsPageRoutingModule } from './merger-demerger-details-routing.module';

import { MergerDemergerDetailsPage } from './merger-demerger-details.page';
import { NgCalendarModule  } from 'ionic2-calendar';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MergerDemergerDetailsPageRoutingModule,
    NgCalendarModule,
    DirectiveSharedModule,
    ComponentsModule
  ],
  declarations: [MergerDemergerDetailsPage]
})
export class MergerDemergerDetailsPageModule {}
