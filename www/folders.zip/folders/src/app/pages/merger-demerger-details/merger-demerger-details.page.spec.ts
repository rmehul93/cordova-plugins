import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MergerDemergerDetailsPage } from './merger-demerger-details.page';

describe('MergerDemergerDetailsPage', () => {
  let component: MergerDemergerDetailsPage;
  let fixture: ComponentFixture<MergerDemergerDetailsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MergerDemergerDetailsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MergerDemergerDetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
