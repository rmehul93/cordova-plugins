import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MergerDemergerDetailsPage } from './merger-demerger-details.page';

const routes: Routes = [
  {
    path: '',
    component: MergerDemergerDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MergerDemergerDetailsPageRoutingModule {}
