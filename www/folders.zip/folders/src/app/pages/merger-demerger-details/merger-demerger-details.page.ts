import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { clsLocalStorageService } from './../../Common/clsLocalStorageService';
import { NavParamService } from './../../providers/nav-param.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { clsConstants } from './../../Common/clsConstants';
import { clsGlobal } from './../../Common/clsGlobal';
import { NavController, IonContent } from '@ionic/angular';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CalendarComponent } from 'ionic2-calendar/calendar';


@Component({
  selector: 'app-merger-demerger-details',
  templateUrl: './merger-demerger-details.page.html', 
})
export class MergerDemergerDetailsPage implements OnInit {
  mergerDetails: any = [];
  noDataFound: boolean = false;
  loadMoreData: boolean = false;
  fromDate: string = (new Date(new Date().getTime() - (90 * 24 * 60 * 60 * 1000))).toISOString();
  toDate: string = new Date().toISOString();

  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = "";
  messageSearchData = []
  showSearch: boolean = false;
  showloader: boolean = false;

  @ViewChild(IonContent, { static: false }) content: IonContent;
  showExpandHeader: boolean = false;
  tempFavScreeners: any = [];
  hdrName: string = "";
  objScannerData: any = {};

  showCustomdatePopup: boolean = false;
  showFilter: boolean = false;

  //added by Vivian F
  toPreviousMonth: any = "";
  fromPreviousMonth: any = "";
  selectedDateEvents: any = [];
  filterEvents: any = [];
  calendarFromDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };
  //currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
  //currentYear = this.calendar.currentDate.getFullYear();
  calendarToDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };
  //currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
  //currentYear = this.calendar.currentDate.getFullYear();
  selectedDate: Date;
  eventSource = [];
  isFrom: boolean = true;
  isTo: boolean = false;
  fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
  fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
  fromCurrentDay = new Date().toDateString().split(' ')[2];
  //fromCurrentDay = this.calendar.currentDate.getDay();
  fromSelectedDate: any = new Date();
  toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
  toCurrentYear = this.calendarToDate.currentDate.getFullYear();
  toCurrentDay = new Date().toDateString().split(' ')[2];
  //toCurrentDay = this.calendar.currentDate.getDay();
  toSelectedDate: any = new Date();
  isCustom: boolean = false;
  dslyFrmDt: string;
  dslyToDt: string;
  @ViewChild(CalendarComponent) objCalendar: CalendarComponent;

  selDtType = "";
  dateSelected = false;
  amtEntered = false;
  dblMinAmt: any = 0;
  dblMaxAmt: any = 0;
  selDateName: any = '';

  constructor(public objCDSService: CDSServicesProvider,
    public navCtrl: NavController,
    public objToast: ToastServicesProvider,
    public clsLocalStorage: clsLocalStorageService,
    private paramService: NavParamService) {
      this.objScannerData = this.paramService.myParam;
      this.hdrName = this.objScannerData.scannerItem.GroupName;
     }

  ngOnInit() {
    this.getMergerDemergerDetails();
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
  }


  scrollContent(event) {
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    //console.log(event);
  }


  getMergerDemergerDetails() {
    this.showloader = true;
    let _fromdate = clsCommonMethods.getCDSDate(this.fromDate);
    let _todate = clsCommonMethods.getCDSDate(this.toDate);
    let requestString = _fromdate + '/' + _todate;
    this.objCDSService.getMergerDemergerData(requestString).then((objresponse: any) => {
      try {
        this.showloader = false;
        if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
          if (objresponse.ResponseObject.recordcount > 0) {
            this.noDataFound = false;
            this.mergerDetails = objresponse.ResponseObject.resultset;
            console.log(this.mergerDetails);
            this.loadMoreData = true;
          }
          else {
            this.noDataFound = true;
            this.loadMoreData = false;
          }
        }
        else {
          this.noDataFound = true;
          this.loadMoreData = false;
        }
      } catch (error) {
        this.noDataFound = true;
        //clsGlobal.logManager.writeErrorLog("MergerDemergerDetailsPage", "getMergerDemergerDetails", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'getMergerDemergerDetails',error.Message,undefined,error.stack,undefined,undefined));
      }
    }).catch(error => {
      this.noDataFound = true;
      this.showloader = false;
      //clsGlobal.logManager.writeErrorLog("MergerDemergerDetailsPage", "getMergerDemergerDetails", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'getMergerDemergerDetails2',error.Message,undefined,error.stack,undefined,undefined));
    }
    );
  }

  goBack() {
    this.navCtrl.pop();
  }

  search($event) {
    if ($event) {
      this.searchText = $event.toUpperCase();
      this.searchTextChanged.next($event);
    } else {
      this.messageSearchData = [];
    }
  }

  clearSearch() {
    this.searchText = '';
    this.messageSearchData = [];
    this.searchTextEntered = '';
  }

  showSearchPopup() {
    this.searchText = '';
    this.showSearch = true;
    this.messageSearchData = [];
  }

  hideSearchPopup() {
    this.showSearch = false;
    this.searchText = '';
    this.messageSearchData = [];
  }

  getValues(search) {
    try {
      this.messageSearchData = [];
      if (search.length < 1) {
        this.searchTextEntered = '';
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      this.messageSearchData = this.mergerDetails
        .filter(x => (x.MergedFrom_CompanyName.toUpperCase().includes(this.searchTextEntered)));
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async favUnFavScreeners(item) {
    try {
      await this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.tempFavScreeners = obj;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'favUnFavScreeners',error.Message,undefined,error.stack,undefined,undefined));
        });
      if (!item.scannerItem.Favourite || item.scannerItem.Favourite == false) {
        item.scannerItem.Favourite = true;
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = true;
        });
        this.tempFavScreeners.push(item.scannerItem);
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
      else {
        if (this.tempFavScreeners.length == 5)
          return this.objToast.showAtBottom("There should be atleast 5 Screeners in My Favourite Screeners.");
        item.scannerItem.Favourite = false;
        this.tempFavScreeners = this.tempFavScreeners.filter((element, index, array) => {
          return element.GroupName != this.hdrName;
        });
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = false;
        });
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'favUnFavScreeners2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  applyFilter() {
  try{
    if (this.selDtType != '') {
      this.dateSelected = true;
    } else {
      this.dateSelected = false;
    }

    this.showFilter = !this.showFilter;
    if (this.isCustom) {
      this.fromDate = clsCommonMethods.getCDSDate(this.fromSelectedDate);
      this.toDate = clsCommonMethods.getCDSDate(this.toSelectedDate);
    }
    this.resetCustomDate();
    this.mergerDetails = [];
    this.getMergerDemergerDetails();
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'applyFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  clearFilter(refreshData: boolean) {
    try{
    this.selDtType = '';
    this.selDateName = '';
    this.dateSelected = false;
    this.fromDate = (new Date(new Date().getTime() - (90 * 24 * 60 * 60 * 1000))).toISOString();
    this.toDate = new Date().toISOString();
    if (refreshData) {
      this.getMergerDemergerDetails()
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',error.Message,undefined,error.stack,undefined,undefined));clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MergerDemergerDetailsPage', 'clearFilter',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
 

  CustomDate(value) {
    try {
      if (value == 'CLOSE') {
        if (this.isCustom && (this.toSelectedDate < this.fromSelectedDate)) {
          this.objToast.showAtBottom("To Date should not be before From Date");
          return;
        }
        else if((!this.dslyFrmDt && this.dslyToDt) || (this.dslyFrmDt && !this.dslyToDt))
        {
          this.objToast.showAtBottom("To Date or From Date was not provided.");
          return;
        }
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else if (value == 'EDIT') {
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else {
        //this.resetCustomDate();
        this.selDtType = '';
        // this.strFromDate = this.getDate(new Date());
        // this.strToDate = this.getDate(new Date());
        this.selDateName = '';
      }
      this.showCustomdatePopup = !this.showCustomdatePopup;
    } catch (e) {
      this.showCustomdatePopup = !this.showCustomdatePopup;
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'doInfinite',e.Message,undefined,e.stack,undefined,undefined));
    }
  }

    setTransactionDate(type, name) {
    try{
    this.isCustom = false;
    this.resetCustomDate();
    if (this.selDtType != type) {
      this.selDtType = type;
      this.selDateName = name;
      let from = new Date();
      let to = new Date();

      if (type == 'CM') {
        from.setDate(1);
      }
      else if (type == 'LM') {
        let today = new Date()
        from = new Date(today.getFullYear(), (today.getMonth() - 1), 1);
        to = new Date(today.getFullYear(), (today.getMonth()), 0);
      }
      else if (type == 'L3M') {
        let today = new Date()
        //from = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 3),1);
        //to = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 3),0);
        from = new Date(today.setMonth(today.getMonth() - 3));
        //to = new Date(today.getFullYear(),today.getMonth(),0);
      }
      else if (type == 'L6M') {
        let today = new Date();
        //from = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 6),1);
        //to = new Date(today.getFullYear(),today.setMonth(today.getMonth() - 6),0);
        from = new Date(today.setMonth(today.getMonth() - 6));
        //to = new Date(today.getFullYear(),today.getMonth(),0);
      }
      this.fromDate = clsCommonMethods.getCDSDate(from);
      this.toDate = clsCommonMethods.getCDSDate(to);
      //this.dateSelected = true;
    } else {
      this.selDtType = '';
      this.selDateName = '';
      this.fromDate = clsCommonMethods.getCDSDate(new Date());
      this.toDate = clsCommonMethods.getCDSDate(new Date());
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'setTransactionDate',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  loadSelectedDateEvent(selectedDate) {
    this.selectedDateEvents = [];
    this.selectedDateEvents = this.filterEvents.filter(eve =>
      new Date(selectedDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString()
    )
  }

  // onCurrentDateChanged(event, type) {
  //   if (this.previousMonth) {
  //     this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
  //     if (this.previousMonth == this.currentMonth) {
  //       this.calendar.currentDate = event;
  //     } else {
  //       this.previousMonth = this.currentMonth;
  //       this.currentYear = event.getFullYear();
  //       this.calendar.currentDate = event;
  //     }
  //   } else {
  //     this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
  //     this.previousMonth = this.currentMonth;
  //     this.currentYear = event.getFullYear();
  //     this.calendar.currentDate = event;
  //   }
  // }

  onToDateChanged(event) {
    try{
    if (this.toPreviousMonth) {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.toPreviousMonth == this.toCurrentMonth) {
        this.calendarToDate.currentDate = event;
      } else {
        this.toPreviousMonth = this.toCurrentMonth;
        this.toCurrentYear = event.getFullYear();
        this.calendarToDate.currentDate = event;
      }
    } else {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.toPreviousMonth = this.toCurrentMonth;
      this.toCurrentYear = event.getFullYear();
      this.calendarToDate.currentDate = event;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'onToDateChanged',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  onFromDateChanged(event) {
    try{
    if (this.fromPreviousMonth) {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.fromPreviousMonth == this.fromCurrentMonth) {
        this.calendarFromDate.currentDate = event;
      } else {
        this.fromPreviousMonth = this.fromCurrentMonth;
        this.fromCurrentYear = event.getFullYear();
        this.calendarFromDate.currentDate = event;
      }
    } else {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.fromPreviousMonth = this.fromCurrentMonth;
      this.fromCurrentYear = event.getFullYear();
      this.calendarFromDate.currentDate = event;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'onFromDateChanged',error.Message,undefined,error.stack,undefined,undefined));
  }
  }


  // comparedayWithselectedDate(selectedDay) {

  //   if (this.calendar.mode == 'week') {
  //     if (new Date(this.calendar.currentDate).getDate() === new Date(selectedDay.date).getDate()) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   }
  //   else {
  //     return false
  //   }
  // }

  isDatefromCurrentMonth(date, type) {
    let dtCompare = (type == "FROM") ? new Date(this.calendarFromDate.currentDate).getMonth() : new Date(this.calendarToDate.currentDate).getMonth();
    if (new Date(date.date).getMonth() == dtCompare) {
      return true;
    } else {
      return false;
    }


  }

  formatDate(date: Date) {
    //console.log(date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear())
    return date.getDate() + "-" + clsCommonMethods.getAlphaMonth(date.getMonth()) + "-" + date.getFullYear();
  }

  setToDateSelected(event) {
    try{
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.toSelectedDate = event.date;
    this.toCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.toCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.toCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
      this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'setToDateSelected',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  setFromDateSelected(event) {
    try{
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.isCustom = true;
    this.fromSelectedDate = event.date;

    this.fromCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.fromCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.fromCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
      this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'setFromDateSelected',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  markDisabled(date: Date) {
    var current = new Date();
    return date > current;
  }

  setValue(value) {
    if (value == 'FROM') {
      this.isFrom = true;
      this.isTo = false;
    }
    else {
      this.isFrom = false;
      this.isTo = true;
    }

  }

  resetCustomDate() {
    try{
    this.isCustom = false;
    this.isFrom = true;
    this.isTo = false;
    this.fromSelectedDate = new Date();
    this.toSelectedDate = new Date();
    this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
    this.fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
    this.fromCurrentDay = new Date().toDateString().split(' ')[2];
    this.toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
    this.toCurrentYear = this.calendarToDate.currentDate.getFullYear();
    this.toCurrentDay = new Date().toDateString().split(' ')[2];
    this.calendarFromDate.currentDate = new Date();
    this.calendarToDate.currentDate = new Date();
    this.dslyFrmDt = '';
    this.dslyToDt = '';
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'resetCustomDate',error.Message,undefined,error.stack,undefined,undefined));

    }
  }


  showFilterPopup() {
    this.showFilter = !this.showFilter;
  }

    closeFilter() {
      try{
    this.selDtType = '';
    this.selDateName = '';
    this.dateSelected = false;
    this.toDate = new Date().toISOString();
    this.fromDate = (new Date(new Date().getTime() - (90 * 24 * 60 * 60 * 1000))).toISOString();
    this.showFilter = !this.showFilter;
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MessagesPage', 'closeFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
