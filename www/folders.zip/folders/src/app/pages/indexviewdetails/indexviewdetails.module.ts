import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { IndexviewdetailsPageRoutingModule } from './indexviewdetails-routing.module';

import { IndexviewdetailsPage } from './indexviewdetails.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IndexviewdetailsPageRoutingModule,
    ComponentsModule
  ],
  declarations: [IndexviewdetailsPage]
})
export class IndexviewdetailsPageModule {}
