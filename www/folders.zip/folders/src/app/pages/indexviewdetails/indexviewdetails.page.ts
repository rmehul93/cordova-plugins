import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavController, IonContent } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { ActivatedRoute, NavigationExtras } from '@angular/router';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { Chart } from "chart.js";
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { GlobalEventsService } from 'src/app/providers/global-events.service';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-indexviewdetails',
  templateUrl: './indexviewdetails.page.html', 
})
export class IndexviewdetailsPage implements OnInit { 
  filterPopup=false;
  indicedetails= "Constituents";
  indiceListGrid="list";
  bcastHandler: any;
  idexDetails : any
  indexConstituentList : any = [];
  localScripKey : any = [];
  scripKey : any = [];
  openPrice : any = "-";
  closePrice : any = "-";
  highPrice : any = "-";
  lowPrice : any = "-";
  lifeTimeHighPrice : any  = "-";
  lifeTimeLowPrice : any  = "-";
  futData : any = [];
  chartdetails : any = [];
  @ViewChild('lineChartDetailsCanvas') lineChartDetailsCanvas;
  chartLineData: any;
  tempFavIndices : any = [];
  showPopUpOE: boolean = false;
  selectedScripObj : any;
  selectedScrip : any;
  indexFilterObject: any = {}
  isFilterApply : boolean = false;
  mapMktSegId : any;
  chartTimeInterval : any;
  futOptScripKey : any = [];
  eventList : any = [];
  showExpandHeader: boolean = false;
  holdingData : any = [];
  @ViewChild('divIndexFilter', { static: false }) divIndexFilter: ElementRef;
  showExpandedIndexFilter: boolean = false;
  indexFilterPane: any;
  showFilterPopup: boolean = false;
  selecteScripAddToWatchlist : any;
  showWatchList : boolean = false;
  showFullMode:boolean =false; // change by om on 3 feb21 new variable to display Popup order entry in full mode.
  showFutLoadersearch : boolean = false;
  showOptLoadersearch : boolean = false;
  showConstituentLoadersearch : boolean = false;
  noFutDataFound : boolean = false;
  noOptDataFound : any = "";
  noConstituentDataFound : boolean = false
  disableApply : boolean = false;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  chartlabels : any = [];
  selectedOptionContractData = [];
  distinctOptExpiryDate = [];
  selectedIdxOptnChain: number = 0;
  selectedOptionContract = [];
  dateExpression = /(\d{4})-(\d{2})-(\d{2}) (\d{2})(\d{2})(\d{2})/;
  chartdetails2 : any = [];
  
  constructor(public navCtrl: NavController,
    private activatedRoute: ActivatedRoute,
    public http: clsHttpService,
    private cdsService : CDSServicesProvider,
    private toastCtrl: ToastServicesProvider,
    public objStorage: clsLocalStorageService,
    public alertCtrl: AlertServicesProvider,
    private glbEvtService: GlobalEventsService,
    private paramService: NavParamService,
    public dateFormatter: DatePipe,) { } 

  ngOnInit() {  
    this.bcastHandler = this.receiveTouchlineResponse.bind(this); 
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CHART_TIME_INTERVAL) !=undefined){
      this.chartTimeInterval =  parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CHART_TIME_INTERVAL));
    }
    else  
    {
      this.chartTimeInterval = clsConstants.CHART_TIME_INTERVAL;
    } 
    this.activatedRoute.queryParams.subscribe((res) => {
      if (res != undefined) {
        this.idexDetails = JSON.parse(res["data"]);    
      }
    });  
  } 

  ionViewWillEnter(){
    if(Object.keys(this.indexFilterObject).length == 0)
    {
      this.disableApply = true;
    }
    else
    {
      this.disableApply = false;
    }

    this.glbEvtService.fetchEvents().then(data => {

      try {
        this.eventList = clsGlobal.EventList;

      } catch (error) {
        clsGlobal.logManager.writeErrorLog('WatchlistPage', 'fetchEventList Response', error);
      }
    }, error => {
      console.log("Error in Fetch Event: " + error);
    })
    this.holdingData = clsGlobal.User.Holding;   
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    let objScrpKey: clsScripKey = new clsScripKey();
    objScrpKey.token = this.idexDetails.nToken;
    objScrpKey.MktSegId = this.idexDetails.nMarketSegmentId;
    this.mapMktSegId = clsTradingMethods.getMappedMarketSegmentId(this.idexDetails.nMarketSegmentId);
    this.scripKey.push(objScrpKey);
    this.indexConstituents(this.idexDetails); 
    this.sendTouchlineRequest(OperationType.ADD, this.scripKey); 
  }

  /** <Norwin Dcruz> <08/12/2020> <Non transaction service is called to get chart data of time interval> **/
  getChartData(MktSegId, Token, chartTimeInterval) {
    try {
        let requestString = {
          MktSegId: MktSegId,
          Token: Token,
          TimeInterval: chartTimeInterval
        }
        this.http.postJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId, "/getChartData", requestString) //http://172.25.91.98:8080/transactional/com.wave.test/v1/
          .subscribe(respData => {
            try {
              this.chartdetails = [];
              let response = respData.result[0]
              if (response.length > 0) {
                for (let count = 0; count < response.length; count++) {
                  this.chartdetails.push(clsTradingMethods.ConvertToRe((response[count].nClose),MktSegId,"100"));
                  this.chartlabels.push(clsCommonMethods.ConvertToDateObj(response[count].Time));
                  this.chartdetails2.push(this.idexDetails.LTP)
                }
                this.getChartDetails();
              }
              else {
                this.toastCtrl.showAtBottom("Unable to show chart data");
              }
            } catch (error) {
              clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'getChartData1', error);
            }
          }, error => {
            this.toastCtrl.showAtBottom("Unable to show chart data");
            clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'getChartData2', error);
          }); 
          
    } catch (error) {
      console.log(error);      
    }
  }

  showPopUpOrderEntry(item) {
    try { 
      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }

      for(let counter = 0; counter < this.indexConstituentList.length; counter++)
      {
        this.indexConstituentList[counter].disabled = true;
      }
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(item.nMarketSegmentId),
          token: item.nToken
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        for(let counter = 0; counter < this.indexConstituentList.length; counter++)
        {
          this.indexConstituentList[counter].disabled = false;
        }
        this.selectedScripObj = resp.result[0];
        let SegmentId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
          this.alertCtrl.showAlert(
            "You are currently not allowed to place/modify/cancel order in this segment",
            "Order Error!"
          );
          return;
        }
    
        let currScrip: clsScrip = new clsScrip();
        currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        currScrip.scripDet.token = this.selectedScripObj.nToken;
        currScrip.symbol = this.selectedScripObj.sSymbol.trim();
        currScrip.Series = this.selectedScripObj.sSeries;
        currScrip.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        currScrip.ExpiryDate = this.selectedScripObj.nExpiryDate1;
        currScrip.StrikePrice = this.selectedScripObj.nStrikePrice1 || "-1";
        currScrip.OptionType = this.selectedScripObj.sOptionType || "NA";
        currScrip.MarketLot = this.selectedScripObj.nRegularLot || 1;
        currScrip.PriceTick = this.selectedScripObj.nPriceTick || 1;
        //this.selectedScrip = currScrip;
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
        // objOEFormDetail.buyPrice = this.selBidPrice;
        // objOEFormDetail.sellPrice = this.selAskPrice;
        // objOEFormDetail.closePrice = this.closePrice;
        // objOEFormDetail.ltp = this.scripLTP;
        objOEFormDetail.scripDetl = currScrip;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.showPopUpOE = !this.showPopUpOE;
        this.selectedScrip = objOEFormDetail;
      }).catch(error => {
        for(let counter = 0; counter < this.indexConstituentList.length; counter++)
        {
          this.indexConstituentList[counter].disabled = false;
        }
        this.toastCtrl.showAtBottom("Unable to open Order Entry");
        clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'showPopUpOrderEntry', error);
      });
    } catch (error) {
      for(let counter = 0; counter < this.indexConstituentList.length; counter++)
      {
        this.indexConstituentList[counter].disabled = false;
      }
      this.toastCtrl.showAtBottom("Unable to open Order Entry");
      console.log(error);
    }
  }

  showPopUpOrderEntryFutOpt(item) {
    try {
      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }
      let SegmentId = clsTradingMethods.GetMarketSegmentID(item._source.nMarketSegmentId);
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(item._source.nMarketSegmentId);
      currScrip.scripDet.token = item._source.nToken;
      currScrip.symbol = item._source.sSymbol.trim();
      currScrip.Series = item._source.sSeries;
      currScrip.InstrumentName = item._source.sInstrumentName.trim();
      currScrip.ExpiryDate = item._source.nExpiryDate1;
      currScrip.StrikePrice = item._source.nStrikePrice1 || "-1";
      currScrip.OptionType = item._source.sOptionType || "NA";
      currScrip.MarketLot = item._source.nRegularLot || 1;
      currScrip.PriceTick = item._source.nPriceTick || 1;
      //this.selectedScrip = currScrip;
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;
      // objOEFormDetail.buyPrice = this.selBidPrice;
      // objOEFormDetail.sellPrice = this.selAskPrice;
      // objOEFormDetail.closePrice = this.closePrice;
      // objOEFormDetail.ltp = this.scripLTP;
      objOEFormDetail.scripDetl = currScrip;
      objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
      this.showPopUpOE = !this.showPopUpOE;
      this.selectedScrip = objOEFormDetail;

    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to open Order Entry");
      console.log(error);
    }
  }

  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode=false;
  }
  //change by ompraksh d on 3 feb.
  //when ever controls in order entry will focus 
  //popup order entry will be in full mode.
  onFocus(event){
    this.showFullMode=true;
  }
  /** <Norwin Dcruz> <09/12/2020> <TO create chart using the data provided by non transaction service> **/
  getChartDetails() {
    try {
      this.chartLineData = new Chart(
        this.lineChartDetailsCanvas.nativeElement,
        {
          type: 'line',
          data: {
            labels: this.chartlabels,
            datasets: [
              {
                data: this.chartdetails,
                borderWidth: 1,
                fill: false,
                pointRadius: 0
              },
              {
                label: 'Line Dataset',
                data: this.chartdetails2,
                type: 'line',
                // this dataset is drawn on top
                order: 1,
                borderWidth: 1,
                fill: false,
                pointRadius: 0,
                borderColor: '#2dd36f',
                borderDash: [5, 4],
                lineTension: 0,
                steppedLine: true
              }
            ]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  reverse: false
                },
                display: true,
                gridLines: {
                  display: true,
                  drawBorder: false,
                },
                position: 'right',
              },
              ],
              xAxes: [{
                display: true,
                gridLines: {
                  display: true,
                  drawBorder: false,
                },
                ticks: {
                  autoSkip: true,
                  maxTicksLimit: 3,
                  maxRotation: 0,
                  minRotation: 0
                }
              }]
            },
            responsive: true,
            elements: {
              line: {
                borderColor: '#000000',
                borderWidth: 1,
                lineTension: 0
              }
            },
            tooltips: {
              enabled: false,
            },
            legend: {
              display: false
            },
            point: {
              radius: 0
            }
          }
        }
      );
    } catch (error) {
      console.log(error);
    }
  }
  
  applyEventToIndices() {
    try {
      this.eventList.forEach(eventItem => {
        this.indexConstituentList.forEach(element => {
          if (element.ExchangeAPIName == clsTradingMethods.getApiExchangeName(parseInt(eventItem.mktid)) && element.nToken == parseInt(eventItem.token)) {
            if (!element.hots.includes(eventItem.event))
              element.hots.push(eventItem);
          }
        });
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'applyEventToIndices', error);
    }
  }

  applyHolding() {
    try {
      this.holdingData.forEach(item => {
        this.indexConstituentList.forEach(element => {
          if (element.ExchangeAPIName == clsTradingMethods.getApiExchangeName(parseInt(item.nMarketSegmentId)) && element.nToken == parseInt(item.nToken)) {
              element.holding = (item.TOTALFREEQUANTITY);
              element.PNLTrend = item.PNLTrend;
              element.PNL = item.PNL;
              element.PNLPer = item.PNLPer;
          }
        });
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'applyHolding', error);
    }
  }

  /** <Norwin Dcruz> <09/12/2020> <To call constituents of the particular index> **/
  indexConstituents(indexDetails){
    try {
      this.showConstituentLoadersearch = true;
      let reqParamsObj = "/"+indexDetails.Exchange+"/"+indexDetails.sIndexDesc.toLowerCase()+"/"+100;
      this.cdsService.getIndexConstituents(reqParamsObj).then((res:any)=>{
        this.showConstituentLoadersearch = false;
        if(res.ResponseObject.type=='success' && res.ResponseObject.resultset.length > 0){
          this.noConstituentDataFound = false;
          this.indexConstituentList = res.ResponseObject.resultset;
          for(let count = 0; count < this.indexConstituentList.length; count++){
            let scripDataCMOT = this.idexDetails.nMarketSegmentId == clsConstants.C_V_NSE_CASH ? this.indexConstituentList[count].ScripData_NSE : this.indexConstituentList[count].ScripData_BSE;
            this.indexConstituentList[count].nToken = scripDataCMOT.ODINCode;
            this.indexConstituentList[count].nMarketSegmentId = clsTradingMethods.GetMarketSegmentID(scripDataCMOT.MarketSegmentId);
            this.indexConstituentList[count].Exchange = clsTradingMethods.getExchangeName(this.indexConstituentList[count].nMarketSegmentId);
            this.indexConstituentList[count].ExchangeAPIName = clsTradingMethods.getApiExchangeName(this.indexConstituentList[count].nMarketSegmentId);
            this.indexConstituentList[count].hots = [];
            this.indexConstituentList[count].holding = '';
            this.indexConstituentList[count].disabled = false;

            this.indexConstituentList[count].LTP = "0.00";
            this.indexConstituentList[count].percentage = "0.00";
            this.indexConstituentList[count].NetChangeInRs = "0.00";
            this.indexConstituentList[count].LTPTrend = '';
            this.indexConstituentList[count].colorTrend = '';
            this.indexConstituentList[count].colorcontrast = '';
            this.indexConstituentList[count].PercNetChange = "0.00";

            let objScrpKey = new clsScripKey();
            objScrpKey.MktSegId = this.indexConstituentList[count].nMarketSegmentId;            
            objScrpKey.token = scripDataCMOT.ODINCode;
            this.localScripKey.push(objScrpKey);
            // let netChangeInRs = Math.round(this.indexConstituentList[count].PriceDifference * 100 + Number.EPSILON)/100
            // let percNetChange = Math.round(this.indexConstituentList[count].Change * 100 + Number.EPSILON)/100;
  
          }
          this.applyEventToIndices();
          this.applyHolding();
          this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
        }
        else
        {
          this.noConstituentDataFound = true;
        }
      },err=>{
        this.showConstituentLoadersearch = false;
        this.noConstituentDataFound = true;
        console.log(err);
      })        
    } catch (error) {
      this.showConstituentLoadersearch = false;
      this.noConstituentDataFound = true;
      console.log(error);      
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'sendTouchlineRequest', error);
    }
  }

  goBack()
  {
     this.navCtrl.pop();
  }

  showfilter()
  {
    this.filterPopup=!this.filterPopup;
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

    // console.log("obj", objMultiTLResp)
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        if (this.idexDetails.nToken == objMultiTLResp.Scrip.token &&
          this.idexDetails.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
          this.idexDetails.LTP = objMultiTLResp.LTP;

          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
          this.idexDetails.NetChangeInRs = arrNetChange[0];
          this.idexDetails.PercNetChange = arrNetChange[1];
          this.idexDetails.colorTrend = arrNetChange[2];

          this.idexDetails.Date = this.formatDisplayDate(objMultiTLResp.LUT,this.dateExpression,undefined);

          this.lifeTimeHighPrice =
            objMultiTLResp.LifeTimeHigh == "" ? "-" : objMultiTLResp.LifeTimeHigh;
          this.lifeTimeLowPrice =
            objMultiTLResp.LifeTimeLow == "" ? "-" : objMultiTLResp.LifeTimeLow;
          this.openPrice =
            objMultiTLResp.OpenPrice == "" ? "-" : objMultiTLResp.OpenPrice;
          this.highPrice =
            objMultiTLResp.HighPrice == "" ? "-" : objMultiTLResp.HighPrice;
          this.lowPrice = objMultiTLResp.LowPrice == "" ? "-" : objMultiTLResp.LowPrice;
          this.closePrice =
            objMultiTLResp.ClosePrice == "" ? "-" : objMultiTLResp.ClosePrice;
        }

        for (let count = 0; count < this.indexConstituentList.length; count++) {
          if (this.indexConstituentList[count].nToken.toString() == objMultiTLResp.Scrip.token &&
            this.indexConstituentList[count].nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
            this.indexConstituentList[count].LTP = objMultiTLResp.LTP;

            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.indexConstituentList[count].NetChangeInRs = arrNetChange[0];
            this.indexConstituentList[count].PercNetChange = arrNetChange[1];
            this.indexConstituentList[count].colorTrend = arrNetChange[2];
            this.indexConstituentList[count].percentage = arrNetChange[3];

            if(this.indexConstituentList[count].colorTrend == 'color-positive')
            {
              this.indexConstituentList[count].colorcontrast = 'background-positive-contrast'
            }
            else if(this.indexConstituentList[count].colorTrend == 'color-negative')
            {
              this.indexConstituentList[count].colorcontrast = 'background-negative-contrast'
            }

            if (arrNetChange[3] > 0 && arrNetChange[3] < 1) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-6';
            }
            else if (arrNetChange[3] > 1 && arrNetChange[3] < 2) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-5';
            }
            else if (arrNetChange[3] > 2 && arrNetChange[3] < 5) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-4';
            }
            else if (arrNetChange[3] > 5 && arrNetChange[3] < 7.5) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-3';
            }
            else if (arrNetChange[3] > 7.5 && arrNetChange[3] < 10) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-2';
            }
            else if (arrNetChange[3] > 10) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-mild-1';
            }
            else if (arrNetChange[3] < 0 && arrNetChange[3] > -1) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-6';
            }
            else if (arrNetChange[3] < -1 && arrNetChange[3] > -2) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-5';
            }
            else if (arrNetChange[3] < -2 && arrNetChange[3] > -5) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-4';
            }
            else if (arrNetChange[3] < -5 && arrNetChange[3] > -7.5) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-3';
            }
            else if (arrNetChange[3] < -7.5 && arrNetChange[3] > -10) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-2';
            }
            else if (arrNetChange[3] < -10) {
              this.indexConstituentList[count].LTPTrend = 'background-hitmap-hot-1';
            }
            else {
              this.indexConstituentList[count].LTPTrend = '';
            }

          }
        }

        for (let count = 0; count < this.futData.length; count++) {
          if (this.futData[count]._source.nToken == objMultiTLResp.Scrip.token &&
            this.futData[count]._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {
            this.futData[count]._source.LTP = objMultiTLResp.LTP;

            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            this.futData[count]._source.NetChangeInRs = arrNetChange[0];
            this.futData[count]._source.PercNetChange = arrNetChange[1];
            this.futData[count]._source.colorTrend = arrNetChange[2];
            this.futData[count]._source.percentage = arrNetChange[3];
            this.futData[count]._source.PremiumDiscount =  (parseFloat(this.idexDetails.LTP) - parseFloat(this.futData[count]._source.LTP)).toFixed(2) ;
          }
        }

        if (this.indicedetails == "OptionChain") {
          if (this.selectedOptionContract.length > 0) {
            for (let i = 0; i < this.selectedOptionContract.length; i++) {
  
              if (this.selectedOptionContract[i].ceData.Money == "call-add-money") {
                this.selectedOptionContract[i].ceData._source.nStrikePrice1 = this.idexDetails.LTP;
              }
              if (this.selectedOptionContract[i].peData.Money == "put-add-money") {
                this.selectedOptionContract[i].peData._source.nStrikePrice1 = this.idexDetails.LTP;
              }
  
  
              if (parseFloat(this.idexDetails.LTP) > parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1)) {
                if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                  this.selectedOptionContract[i].ceData.Money = "call-background";
                }
  
              }
              else {
                if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                  this.selectedOptionContract[i].ceData.Money = "put-background";
                }
  
              }
  
              if (parseFloat(this.idexDetails.LTP) < parseFloat(this.selectedOptionContract[i].peData._source.nStrikePrice1)) {
                if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                  this.selectedOptionContract[i].peData.Money = "call-background";
                }
  
              }
              else {
                if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                  this.selectedOptionContract[i].peData.Money = "put-background";
                }
  
              }
  
              if (this.selectedOptionContract != undefined &&
                this.selectedOptionContract[i].ceData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
                this.selectedOptionContract[i].ceData._source.nToken == objMultiTLResp.Scrip.token) {
                this.selectedOptionContract[i].ceData.LTP = objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, 2, false, 'arrow');
                this.selectedOptionContract[i].ceData.NetChangeInRs = arrNetChange[0];
                this.selectedOptionContract[i].ceData.PercNetChange = arrNetChange[1];
                this.selectedOptionContract[i].ceData.LTPTrend = arrNetChange[2];
                this.selectedOptionContract[i].ceData.arrowTrend = arrNetChange[3];
                this.selectedOptionContract[i].ceData.OI =  objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;;
                this.selectedOptionContract[i].ceData.PercOI = objMultiTLResp.PercOpenInt == "" ? "(0.00)" : objMultiTLResp.PercOpenInt;;
                if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) > 0) {
                  this.selectedOptionContract[i].ceData.colorOITrend = "color-positive";
                }
                else if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) < 0) {
                  this.selectedOptionContract[i].ceData.colorOITrend = "color-negative";
                }
                else {
                  this.selectedOptionContract[i].ceData.colorOITrend = "";
                }
                let ImpVoltality:any = clsCommonMethods.ImpliedVolatility(parseFloat(this.idexDetails.LTP),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1),4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1),objMultiTLResp.LTP,"CALL");
                this.selectedOptionContract[i].ceData.IV = parseFloat(ImpVoltality).toFixed(4);
                break;
              }
              else if (this.selectedOptionContract != undefined &&
                this.selectedOptionContract[i].peData._source.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
                this.selectedOptionContract[i].peData._source.nToken == objMultiTLResp.Scrip.token) {
                this.selectedOptionContract[i].peData.LTP = objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, 2, false, 'arrow');
                this.selectedOptionContract[i].peData.NetChangeInRs = arrNetChange[0];
                this.selectedOptionContract[i].peData.PercNetChange = arrNetChange[1];
                this.selectedOptionContract[i].peData.LTPTrend = arrNetChange[2];
                this.selectedOptionContract[i].peData.arrowTrend = arrNetChange[3];
                this.selectedOptionContract[i].peData.OI = objMultiTLResp.OpenInt == "" ? "0.00" : objMultiTLResp.OpenInt;
                this.selectedOptionContract[i].peData.PercOI = objMultiTLResp.PercOpenInt == "" ? "0.00" : objMultiTLResp.PercOpenInt;
                if (parseFloat(this.selectedOptionContract[i].peData.PercOI) > 0) {
                  this.selectedOptionContract[i].peData.colorOITrend = "color-positive";
                }
                else if (parseFloat(this.selectedOptionContract[i].peData.PercOI) < 0) {
                  this.selectedOptionContract[i].peData.colorOITrend = "color-negative";
                }
                else {
                  this.selectedOptionContract[i].peData.colorOITrend = "";
                }
                let ImpVoltality:any = clsCommonMethods.ImpliedVolatility(parseFloat(this.idexDetails.LTP),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1),4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1),objMultiTLResp.LTP,"PUT");
                this.selectedOptionContract[i].peData.IV = parseFloat(ImpVoltality).toFixed(4);;
        
                break;
              }
            }
          }
          this.selectedOptionContract.sort((a, b) => (parseFloat(a.ceData._source.nStrikePrice1) < parseFloat(b.ceData._source.nStrikePrice1)) ? -1 : 1)
  
        }
      }
    }
    catch (error) {
      console.log('IndexviewdetailsPage', 'receiveTouchlineResponse', error);
    }

  }

  dateDiffernece(inputdate)
  {
    try {
      let nextdate : any = new Date(inputdate);
      let curruntData:any =  new Date()
      let diffTime = Math.abs(nextdate - curruntData);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24 ));
      return diffDays;
    } catch (error) {
      console.log(error);
    }
  }

  formatDisplayDate(sDate, expression, sFormat) {
    let _FormattedDate = "";
    try {
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[1],
          +dateArray[2] - 1, // Careful, month starts at 0!
          +dateArray[3],
          +dateArray[4],
          +dateArray[5],
          +dateArray[6]
        );
        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "MM/dd/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
        let hrFormatDate = clsTradingMethods.getDateandTime(_FormattedDate)
        return hrFormatDate;
      }
    }
    catch (e) {
      //this.toastCtrl.showAtBottom(": " + e.message);
    }
  }

  /** <Norwin Dcruz> <10/12/2020> <To Favourite and Unfavourite Incdices and save in local storage> **/
  async favUnFavIndices(item) {
    try {
      await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES)
        .then((item: any) => {
          if (item != null && item != undefined && item != '') {
            this.tempFavIndices = JSON.parse(item);
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if (item.Favourite == false) {
        item.Favourite = true;
        this.tempFavIndices.push(item);
        this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES, JSON.stringify(this.tempFavIndices));
        if (item.Global) {
          clsGlobal.User.isGlobal = true;
        }
        else {
          clsGlobal.User.isLocal = true;
        }
      }
      else {
        item.Favourite = false;
        if (item.Global) {
          for (let i = 0; i < this.tempFavIndices.length; i++) {
            if (this.tempFavIndices[i].IndexID == item.IndexID) {
              this.tempFavIndices.splice(i, 1);
            }
          }
          clsGlobal.User.isGlobal = true;
        }
        else {
          for (let i = 0; i < this.tempFavIndices.length; i++) {

            if (this.tempFavIndices[i].nMarketSegmentId == item.nMarketSegmentId &&
              this.tempFavIndices[i].nToken == item.nToken) {
              this.tempFavIndices.splice(i, 1);
            }
          }
          clsGlobal.User.isLocal = true;
        }

        this.objStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_INDICES, JSON.stringify(this.tempFavIndices));
      }
    } catch (error) {
      console.log(error);
    }
  }

  /** <Norwin Dcruz> <09/12/2020> <Tab Selection> **/
  tabSelection(event) {
    this.content.scrollToPoint(0,0,0);  
    this.indicedetails = event.detail.value;
    this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.localScripKey = [];
    this.futOptScripKey = [];
    this.noOptDataFound = "";
    this.noFutDataFound = false;
    this.noConstituentDataFound = false;
    this.showFutLoadersearch = false;
    this.showOptLoadersearch = false;
    this.showConstituentLoadersearch = false;
    if (this.indicedetails == 'Constituents') {      
      if (this.indexConstituentList.length == 0)
      {
        this.indexConstituents(this.idexDetails);
      }
      else
      {
        for (let count = 0; count < this.indexConstituentList.length; count++) {
          let objScrpKey = new clsScripKey();
          objScrpKey.MktSegId = this.indexConstituentList[count].nMarketSegmentId;            
          objScrpKey.token = this.indexConstituentList[count].nToken;
          this.localScripKey.push(objScrpKey);
        }
        this.noConstituentDataFound = false;
        this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
      }        
    }
    else if (this.indicedetails == 'Overview') {
      if (this.chartdetails.length > 0) {
        this.chartLineData.destroy();
        this.getChartDetails();
      }
      else {
        /** <Norwin Dcruz> <08/12/2020> <To get chart data> **/
        this.getChartData(this.mapMktSegId, this.idexDetails.nToken, this.chartTimeInterval);
      }
    }
    else if (this.indicedetails == 'Futures') {
      if (this.futData.length == 0) {
        this.getFutData();
      }
      else {
        for (let count = 0; count < this.futData.length; count++) {
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = this.futData[count]._source.nToken;
          objScrpKey.MktSegId = this.futData[count]._source.nMarketSegmentId;
          this.futOptScripKey.push(objScrpKey);
        }
        this.noFutDataFound = false;
        this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);
      }
    }
    else if (this.indicedetails == 'OptionChain') {
      if (this.selectedOptionContract.length == 0) {
        this.getOptData();
        this.scrollToLabel();

      }
      else {
        this.noOptDataFound = "false";
        this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
        this.scrollToLabel();
      }
    }
  }

  scrollToLabel() {
    try {
      let titleELe = document.getElementById("call-put-add-money");
      if (titleELe == null) {
        setTimeout(() => {
        this.scrollToLabel();
      }, 300);
      }
      else {
        setTimeout(() => {
        let titleELe = document.getElementById("call-put-add-money");
        this.content.scrollToPoint(0, titleELe.offsetTop, 1000);
      }, 200);
      }


    } catch (error) {

    }
  }  

  /** <Norwin Dcruz> <11/12/2020> <To filter index constituents based on selection provided> **/
  setIndexFilter(filterName: any, filterValue: any) {
    try {  
      this.indexFilterObject = {};
      switch (filterName) {
        case 'sortalpha':
          this.indexFilterObject.sortalpha = filterValue;
          break;
        case 'pricesort':
          this.indexFilterObject.pricesort = filterValue;
          break;
        case 'percentagesort':
          this.indexFilterObject.percentagesort = filterValue;
          break;
        }
        if(Object.keys(this.indexFilterObject).length == 0)
        {
          this.disableApply = true;
        }
        else
        {
          this.disableApply = false;
        }     
    } catch (error) {
      console.log(error);
    }
  }

  applySortFilter() {
    this.isFilterApply = true;
    this.showFilterPopup = false;

    if (this.indexConstituentList.length > 0) {
      if (this.indexFilterObject.sortalpha == 'asc') {
        this.indexConstituentList.sort((a, b) => {
          return a.Symbol.localeCompare(b.Symbol);
        })
      } else if (this.indexFilterObject.sortalpha == 'desc') {
        this.indexConstituentList.sort((a, b) => {
          return b.Symbol.localeCompare(a.Symbol);
        })
      }

      if (this.indexFilterObject.pricesort == 'asc') {
        this.indexConstituentList.sort((a, b) => {
          return parseFloat(a.LTP) > parseFloat(b.LTP) ? 1 : -1;
        })
      } else if (this.indexFilterObject.pricesort == 'desc') {
        this.indexConstituentList.sort((a, b) => {
          return parseFloat(a.LTP) < parseFloat(b.LTP) ? 1 : -1;
        })
      }
  
      if (this.indexFilterObject.percentagesort == 'asc') {
        this.indexConstituentList.sort((a, b) => {
          return parseFloat(a.percentage) > parseFloat(b.percentage) ? 1 : -1;
        })
      } else if (this.indexFilterObject.percentagesort == 'desc') {
        this.indexConstituentList.sort((a, b) => {
          return parseFloat(a.percentage) < parseFloat(b.percentage) ? 1 : -1;
        })
      }
    }
  }

  getIndexFiltersCount() {
    return Object.keys(this.indexFilterObject).length;
  }

  /** <Norwin Dcruz> <11/12/2020> <To remove filter> **/
  removeFilter(filterName){
    try {
      switch (filterName) {
        case 'sortalpha':
          delete this.indexFilterObject.sortalpha
          break;
        case 'pricesort':
          delete this.indexFilterObject.pricesort
          break;
        case 'percentagesort':
          delete this.indexFilterObject.percentagesort;
          break;
      }
  
      if (this.getIndexFiltersCount() == 0) {
        this.clearFilter();
      } else {
        this.applySortFilter();
      }     
    } catch (error) {
     console.log(error); 
    }
  }

  clearFilter() {
    this.isFilterApply = false;
    this.indexFilterObject = {};
    if(Object.keys(this.indexFilterObject).length == 0)
    {
      this.disableApply = true;
    }
    else
    {
      this.disableApply = false;
    }
  }

  getFutData() {
    this.showFutLoadersearch = true;
    this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId +"/getScripbyAssetToken/", this.idexDetails.nToken+ "/"+ "FUTIDX")
    .subscribe(data => {
      try {
        this.showFutLoadersearch = false;
        let _response: any = data
        if (_response.status && _response.result.hits != undefined && _response.result.hits.total.value > 0) {
          this.noFutDataFound = false;
          this.futOptScripKey = [];
          for(let count = 0; count <  _response.result.hits.hits.length; count++)
          {
            if(_response.result.hits.hits[count]._source.nSpread != 1)
            {
              this.futData.push(_response.result.hits.hits[count]);
            }
          }
          for(let count = 0; count < this.futData.length; count++){
            this.futData[count]._source.nMarketSegmentId = clsTradingMethods.GetMarketSegmentID(this.futData[count]._source.nMarketSegmentId);
            this.futData[count]._source.LTP = "0.00";
            this.futData[count]._source.PercNetChange = "0.00";
            this.futData[count]._source.NetChangeInRs = "0.00";
            this.futData[count]._source.colorTrend = '';
            this.futData[count]._source.PremiumDiscount = "0.00";
            let objScrpKey: clsScripKey = new clsScripKey();
            objScrpKey.token = this.futData[count]._source.nToken;
            objScrpKey.MktSegId = this.futData[count]._source.nMarketSegmentId;
            this.futOptScripKey.push(objScrpKey);
          }
          this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);
        }
        else
        {
          this.noFutDataFound = true;
        }            
      } catch (error) {
        this.noFutDataFound = true;
        console.log(error);
      }
    }, error => {
      this.noFutDataFound = true;
      this.showFutLoadersearch = false;
      console.log("unable to find scrip: ", 'FUTIDX', this.idexDetails.nToken);
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'getFutData', error);
    });
  }

  getOptData() {  
    this.showOptLoadersearch = true;
    this.http.getJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId +"/getScripbyAssetToken/", this.idexDetails.nToken+ "/"+ "OPTIDX")
    .subscribe(data => {
      try {
        let _response: any = data;
        if (_response.status && _response.result.hits != undefined && _response.result.hits.total.value > 0) {
          this.noOptDataFound = "false";
          for(let count = 0; count <  _response.result.hits.hits.length; count++)
          {
            if(_response.result.hits.hits[count]._source.nSpread != 1)
            {
              this.selectedOptionContractData.push(_response.result.hits.hits[count]);
            }
          }
          this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
          this.ShowOptionChain(this.distinctOptExpiryDate[0], 0)
        }
        else
        {
          this.noOptDataFound = "true";
          this.showOptLoadersearch = false;
        }            
      } catch (error) {
        this.noOptDataFound = "true";
        this.showOptLoadersearch = false;
        console.log(error);
      }
    }, error => {
      this.noOptDataFound = "true";
      this.showOptLoadersearch = false;
      console.log("unable to find scrip: ", 'OPTIDX', this.idexDetails.nToken);
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'getOptData', error);
    });  
  }

  ShowOptionChain(expiryDate, idx) {
    try {
      this.showOptLoadersearch = true;
      this.selectedIdxOptnChain = idx;
      this.selectedOptionContract = [];
      let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      optData.push({ _source: { nStrikePrice1: this.idexDetails.LTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" })
      optData.push({ _source: { nStrikePrice1: this.idexDetails.LTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" })
      optData.sort((a, b) => (parseFloat(a._source.nStrikePrice1) > parseFloat(b._source.nStrikePrice1)) ? -1 : 1)
      let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      for (let i = 0; i < optCEData.length; i++) {
        let obj;
        optCEData[i].LTP = "0.00";
        optCEData[i].NetChangeInRs = "0.00";
        optCEData[i].PercNetChange = "(0.00)";
        optCEData[i].OI = "0.00";
        optCEData[i].PercOI = "(0.00)";
        optCEData[i].IV = "0";

        optPEData[i].LTP = "0.00";
        optPEData[i].NetChangeInRs = "0.00";
        optPEData[i].PercNetChange = "(0.00)";
        optPEData[i].OI = "0.00";
        optPEData[i].PercOI = "(0.00)";
        optPEData[i].IV = "0";

        let ceData = optCEData[i]
        let peData = optPEData[i]
        obj = { "ceData": ceData, "peData": peData }
        this.selectedOptionContract.push(obj)
      }
      this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
      this.showOptLoadersearch = false;
      this.scrollToLabel();

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'ShowOptionChain1', error);
    }
  }

  sendBroadcastReqForOptionChain(selectedData) {
    try {
      this.futOptScripKey = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
      for (let i = 0; i < selectedData.length; i++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = selectedData[i].ceData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].ceData._source.nMarketSegmentId;
        this.futOptScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[i].peData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].peData._source.nMarketSegmentId;
        this.futOptScripKey.push(objScrpKey);
      }
      this.sendTouchlineRequest(OperationType.ADD, this.futOptScripKey);

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'sendBroadcastReqForOptionChain', error);
    }
  }

  getDistinctExpiryDate(array) {
    try {
      let distinct = [...new Set(array.map(item => item._source.nExpiryDate1))];
      return distinct;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'getDistinctExpiryDate1', error);
    }
  }


  ionViewWillLeave() {
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.scripKey);
    this.sendTouchlineRequest(OperationType.REMOVE, this.futOptScripKey);
    clsGlobal.pubsub.unsubscribe("MTLRES", this.bcastHandler);
  }

  optionchainTop: boolean = false
  optionchainbottom: boolean = false
  scrollContent(event) {
    let titleELe = document.getElementById("call-put-add-money");
    this.optionchainTop = false;
    this.optionchainbottom = false;

    if (event.detail.scrollTop > 80) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    if (titleELe != undefined) {
      if (event.detail.scrollTop > titleELe.offsetTop + 200) {
        this.optionchainTop = true;
      }

      if (event.detail.scrollTop < titleELe.offsetTop - 200) {
        this.optionchainbottom = true;
      }

      if (event.detail.scrollTop == titleELe.offsetTop) {
        this.optionchainTop = false;
        this.optionchainbottom = false;
      }
    }
  }

  showAdvanceChart() {
    try {
      console.log(this.idexDetails);
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = this.idexDetails.nMarketSegmentId;
      currScrip.scripDet.token = this.idexDetails.nToken;
      currScrip.symbol = this.idexDetails.sIndexDesc;
      currScrip.Series = 'NA';
      currScrip.InstrumentName = '';
      currScrip.ExpiryDate = '';
      currScrip.StrikePrice = '';
      currScrip.OptionType = '';
      currScrip.MarketLot = 1;
      currScrip.PriceTick = 1;
      this.selectedScrip = currScrip;
      this.paramService.myParam = currScrip;
      this.navCtrl.navigateForward("advance-chart-iq");
    } catch (error) {
      console.log("Unable to open set chart page." + error);
    }
  }

  showIndexFilterPopup() {
    this.showFilterPopup = true;
    this.checkForIndexFilterPopupUpElementRendrer();
  }

  checkForIndexFilterPopupUpElementRendrer() {
    const divElement: HTMLElement = document.getElementById('divIndexFilterPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForIndexFilterPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divIndexFilterPopup');
        this.indexFilterPopupBottomToTop(divElement);
      }, 200);
    }
  }

  indexFilterPopupBottomToTop(myElementRef) {
     try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop:true, //added by om on 24 th jan for backdrop display.
        onDidPresent: () => {
          ////console.log("onDidPresent")
        },
  
        // onDrag: () => {
        //   //  //console.log("onDrag");
        // },
        // onDragEnd: () => { 
        //   //console.log("onDragEnd"); 
        // },
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        onTransitionEnd: () => { 
          let topDiv = this.divIndexFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedIndexFilter = true;
          } else {
            this.showExpandedIndexFilter = false;
          }
        },
        onBackdropTap: ()=>{
          //added by omprakash on 24 th jan for backdrop click
          this.closeIndexFilterPopup();
        }
      }
      this.indexFilterPane = new CupertinoPane(myElementRef, setting);
      this.indexFilterPane.enableDrag();
      this.indexFilterPane.present({ animate: true });
     } catch (error) {
       console.log("Error in filter page display "+error);
     }
  }
    // change by omprakash for scroll behaviour.
    scrollFilter(event)
    {
      if (event.target.scrollTop > 10) {
        this.indexFilterPane.moveToBreak('top');
        this.showExpandedIndexFilter = true;
      }
    }

  closeIndexFilterPopup() {
    this.showFilterPopup = false;
    this.showExpandedIndexFilter = false;
    this.indexFilterPane.destroy({ animate: true });
  }

  addToGlobalWatchList(item) {
    try {
      this.selecteScripAddToWatchlist = clsCommonMethods.getScripObject(item._source);
      this.showWatchList = true;
    } catch (error) {
      console.log(error);
    }
  }

  watchListSelectionCloseEvent()
  {
    this.showWatchList=false;
  }

  scripClick(scripobj) {
    try {
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(scripobj.nMarketSegmentId),
          token: scripobj.nToken
        }]
      }
       clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        this.selectedScripObj = resp.result[0];
        let objScrpKey = new clsScripKey();

        objScrpKey.MktSegId = clsTradingMethods.GetMarketSegmentID(this.selectedScripObj.nMarketSegmentId);
        objScrpKey.token = this.selectedScripObj.nToken;
    
        let scripInfo: clsScrip = new clsScrip();
        scripInfo.scripDet = objScrpKey;
        scripInfo.symbol = this.selectedScripObj.sSymbol.trim();
        scripInfo.Series = this.selectedScripObj.sSeries;
        scripInfo.DecimalLocator = this.selectedScripObj.DecimalLocator == "0" ? "100" : this.selectedScripObj.DecimalLocator;
        scripInfo.InstrumentName = this.selectedScripObj.sInstrumentName.trim();
        scripInfo.ExpiryDate = (this.selectedScripObj.nExpiryDate1 != null && this.selectedScripObj.nExpiryDate1.toString() != "" && this.selectedScripObj.nExpiryDate1.toString() != "0") ? this.selectedScripObj.nExpiryDate1 : "0";
        scripInfo.OptionType = this.selectedScripObj.sOptionType;
        scripInfo.MarketLot = this.selectedScripObj.nRegularLot;
        scripInfo.PriceTick = this.selectedScripObj.nPriceTick;
        scripInfo.SecurityDesc = this.selectedScripObj.sSecurityDesc;
        scripInfo.MWSecurityDesc = this.selectedScripObj.MWSecurityDesc;
        scripInfo.StrikePrice = this.selectedScripObj.nStrikePrice1.toString();
        scripInfo.ISIN = this.selectedScripObj.sISINCode;
        scripInfo.SPOS = "";
        scripInfo.POS = "";
        scripInfo.AssetToken = this.selectedScripObj.nAssetToken;
        scripInfo.FIILimit = this.selectedScripObj.nFIILimit;
        scripInfo.NRILimit = this.selectedScripObj.nNRILimit;
        scripInfo.MarginTypeIndicator = this.selectedScripObj.nMarginTypeIndicator;
        scripInfo.FOExists = this.selectedScripObj.nFOExists;
        if (this.selectedScripObj.sInstrumentName.indexOf('IDX') != -1) {
          scripInfo.isIndex = true;
        }
        else {
          scripInfo.isIndex = false;
        }
    
        scripInfo.formatScripDisplayName()
    
        let idData = new clsIndexDetail();
         idData.scripDetail = scripInfo;

         this.paramService.myParam = idData.scripDetail;
         this.navCtrl.navigateForward(["/scripinfo"]);
            
      }).catch(error => {
        this.toastCtrl.showAtBottom("Unable to get Scrip Info");
        clsGlobal.logManager.writeErrorLog('IndexviewdetailsPage', 'scripClick', error);
      });
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to get Scrip Info")
      console.log(error);
    }
  }
  /**
   * To open search page
   */
  openIndexViewDetailLookup(){
    try{
     
      this.paramService.myParam = this.indexConstituentList;
     
      let navigationData: NavigationExtras = {
        queryParams: {
          data:this.idexDetails.sIndexDesc
        }
      }
      this.navCtrl.navigateForward(['indexviewdetailslookup'],navigationData);
      //this.navCtrl.navigateForward('indexviewdetailslookup');
    }catch(error){

    }
  }
}