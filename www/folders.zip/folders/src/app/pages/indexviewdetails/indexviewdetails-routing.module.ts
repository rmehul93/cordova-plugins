import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IndexviewdetailsPage } from './indexviewdetails.page';

const routes: Routes = [
  {
    path: '',
    component: IndexviewdetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IndexviewdetailsPageRoutingModule {}
