import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonContent } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsHttpService } from '../../Common/clsHTTPService';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsTradingMethods } from '../../Common/clsTradingMethods';
import { clsCommonMethods } from '../../Common/clsCommonMethods';
import { clsLocalStorageService } from '../../Common/clsLocalStorageService';
import { TranslateService } from '@ngx-translate/core';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { GlobalEventsService } from 'src/app/providers/global-events.service';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
@Component({
  selector: 'app-screener-view',
  templateUrl: './screener-view.page.html',
})
export class ScreenerViewPage implements OnInit {
  @ViewChild(IonContent, { static: false }) content: IonContent;
  filterPopup: boolean = false;
  showSegment: boolean = false;
  showInstrument: boolean = false;
  showExpiry: boolean = false;
  hideMe = false;
  isItemClick: boolean = true;
  viewExpand: boolean = false;
  selectedIndex: any = '';
  dropDownData: any = [];
  globalScannerList: any = [];
  scannerList: any = [];
  indexListObject: any = [];
  IndexList: any = [];
  segmentSelected: any = 1;
  selectedExchange: any = '';
  objScannerData: any = {};
  scannerItemList: any = [];
  selScannerName: any = '';
  selScannerId: any = '';
  displaySegmentName: any = '';
  selSegmentName: any = '';
  selScannerItem: any = '';
  nodatafound: boolean = false;
  isLazyLoadData: boolean = true;
  futOptArray = [
    { "Name": "All", "Value": "All" },
    { "Name": "Futures", "Value": "FUT" },
    { "Name": "Options", "Value": "OPT" },
    { "Name": "Call", "Value": "CE" },
    { "Name": "Put", "Value": "PE" }
  ];
  filtersObject: any = {}; //To Store the Filter Data.
  nearFarArray = [
    { "Name": "Near Month", "Value": "Near" },
    { "Name": "Next Month", "Value": "Next" },
    { "Name": "Far Month", "Value": "Far" }
  ];
  segmentArray = [];
  segmentArrayDisplay = [];
  selectedFutOpt;
  selectedNearFar;
  scripObject: any;
  count: any = 0;
  ellipsehide: boolean = false;
  refresherInstance: any;
  prevSelectedIndex;
  prevSelectedFutOpt;
  prevSelectedNearFar;
  prevSelectedExchange;
  prevSelectedSegment;
  showloader: boolean = true;
  orderDesc: boolean = true;
  sortField: any = '';
  showIndices: boolean = false;
  showExchange: boolean = false;
  type: string = '1';
  tabsList: any = [];
  hdrName: string = "";
  selectedScrip: any;
  showPopUpOE = false;
  displaySegment = {
    Name: "Equity",
    Value: 1
  };
  subscription: any;
  indicesList: any;
  eventList: any = [];
  whatsHotScripList = [];
  whatsHotScripKeyList = [];
  myStockScripList = [];
  eventProfile: any;
  tempFavScreeners: any = [];
  bcastHandler: any;
  dcTrendingScrip: Dictionary<any> = new Dictionary<any>();
  showExpandHeader: boolean = false;
  showFullMode: boolean = false; // change by om on 3 feb21 new variable to display Popup order entry in full mode.
  constructor(private navCtrl: NavController, private paramService: NavParamService,
    public objHttpService: clsHttpService,
    public objToast: ToastServicesProvider,
    public clsLocalStorage: clsLocalStorageService,
    public translate: TranslateService,
    public alertCtrl: AlertServicesProvider,
    private glbEvtService: GlobalEventsService,
    //private transactionService: TransactionService,
  ) {
    try {
      this.objScannerData = this.paramService.myParam;
      this.segmentSelected = this.objScannerData.segSelcted;
      this.tabsList.push(this.objScannerData.scannerItem.ScannerName_1);
      this.tabsList.push(this.objScannerData.scannerItem.ScannerName_2);
      this.objScannerData.Favourite = false
      //this.type = this.objScannerData.GroupName;
      this.hdrName = this.objScannerData.scannerItem.GroupName;
      this.globalScannerList = clsGlobal.scannerList;
      this.populateScreener();
    } catch (e) {

    }
  }
  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValues(search));
    }
    catch (e) { 
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'ngOnInit',e.Message,undefined,e.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("ScreenerViewPage", "", "VISIT", "");
  }
  // ionViewDidEnter() {
  //   this.getAnalyticsData(this.objScannerData.scannerItem);
  // }
  ionViewWillEnter() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      this.initLoad();
    }
    catch (e) { 
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'ionViewWillEnter',e.Message,undefined,e.stack,undefined,undefined));
    }
  }
  scrollContent(event) {
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    //console.log(event);
  }
  switchTab(event) {
    //console.log(event);
    this.content.scrollToTop();
    event.detail.value = (event.detail.value == '1') ? this.tabsList[0] : this.tabsList[1];
    this.onScannerItemChange(event.detail.value);
  }
  initLoad() {
    if (clsGlobal.indexSectorList.length != 0) {
      this.indexListObject = clsGlobal.indexSectorList;
    } else {
      this.getAllIndexSectorList();
    }
    this.selScannerName = this.objScannerData.scannerItem.ScannerName_1;
    clsGlobal.logManager.writeUserAnalytics("ScreenerViewPage", "", "VISIT", "");
    if (this.objScannerData.eqAllowed == true) {
      this.count++;
      this.segmentArray.push({ 'Name': 'Equity', 'Value': 1 });
    }
    if (this.objScannerData.dervAllowed == true) {
      this.count++;
      this.segmentArray.push({ 'Name': 'Derivative', 'Value': 2 });
    }
    if (this.objScannerData.commAllowed == true) {
      this.count++;
      this.segmentArray.push({ 'Name': 'Commodity', 'Value': 3 });
    }
    if (this.objScannerData.currAllowed == true) {
      this.count++;
      this.segmentArray.push({ 'Name': 'Currency', 'Value': 4 });
    }
    this.setSegmentName();
    this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_SCREENERS_FILTER)
      .then((res: any) => {
        if (res != null && res != undefined && res != "") {
          this.filtersObject = res;
          if (this.selSegmentName === 'Equity') {
            this.selectedFutOpt = this.futOptArray[0].Value;
            this.selectedNearFar = this.nearFarArray[0].Value;
          } else {
            if (this.filtersObject[this.selSegmentName]) {
              if (this.filtersObject[this.selSegmentName].instrument) {
                this.selectedFutOpt = this.filtersObject[this.selSegmentName].instrument
              } else {
                this.selectedFutOpt = this.futOptArray[0].Value;
              }
              if (this.filtersObject[this.selSegmentName].expiry) {
                this.selectedNearFar = this.filtersObject[this.selSegmentName].expiry
              } else {
                this.selectedNearFar = this.nearFarArray[0].Value;
              }
            } else {
              this.selectedFutOpt = this.futOptArray[0].Value;
              this.selectedNearFar = this.nearFarArray[0].Value;
            }
          }
          this.getSegmentExchanges();
        } else {
          this.selectedFutOpt = this.futOptArray[0].Value;
          this.selectedNearFar = this.nearFarArray[0].Value;
          if (this.segmentArray.length > 0) {
            this.segmentArray.forEach((segObject) => {
              if (segObject.Name === 'Equity') {
                this.filtersObject[segObject.Name] = { exchange: '', index: '' };
              } else {
                this.filtersObject[segObject.Name] = { exchange: '', instrument: '', expiry: '' };
              }
            });
            this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_SCREENERS_FILTER, this.filtersObject);
          }
          this.getSegmentExchanges();
        }
      });
    // this.selectedFutOpt = this.futOptArray[0].Value;
    // this.selectedNearFar = this.nearFarArray[0].Value;
    // if (this.segmentArray.length > 0) {
    //   this.segmentArray.forEach((segObject) => {
    //     if (segObject.Name === 'Equity') {
    //       this.filtersObject[segObject.Name] = { exchange: '', index: '' };
    //     } else {
    //       this.filtersObject[segObject.Name] = { exchange: '', instrument: '', expiry: '' };
    //     }
    //   });
    // }
    // this.getSegmentExchanges();
    if (this.count == 1) {
      this.ellipsehide = true;
    }
  }
  showfilter() {
    if (!this.filterPopup) {
      //console.log("filter open");
      this.filterPopup = !this.filterPopup;
      this.prevSelectedIndex = this.selectedIndex;
      this.prevSelectedFutOpt = this.selectedFutOpt
      this.prevSelectedNearFar = this.selectedNearFar;
      this.prevSelectedExchange = this.selectedExchange;
      this.prevSelectedSegment = this.segmentSelected;
    } else {
      //console.log("filter close");
      this.filterPopup = !this.filterPopup;
      if (!(this.prevSelectedSegment == this.segmentSelected && this.selectedExchange == this.prevSelectedExchange && this.selectedIndex == this.prevSelectedIndex)
        || !(this.prevSelectedSegment == this.segmentSelected && this.prevSelectedFutOpt == this.selectedFutOpt && this.prevSelectedNearFar == this.selectedNearFar)) {
        this.scannerItemList = [];
        if (this.selSegmentName === 'Equity') {
          this.filtersObject[this.selSegmentName] = { exchange: this.selectedExchange, index: this.selectedIndex }
        } else {
          this.filtersObject[this.selSegmentName] = { exchange: this.selectedExchange, instrument: this.selectedFutOpt, expiry: this.selectedNearFar }
        }
        this.updateFilterObject(this.filtersObject);
        this.onScannerItemChange(this.type == '1' ? this.tabsList[0] : this.tabsList[1]);
      }
    }
  }
  goBack() {
    this.navCtrl.pop();
  }
  showSegmentPopUp() {
    //this.setSegmentName()
    this.showSegment = !this.showSegment;
    if (this.filterPopup) {
      this.filterPopup = false;
      this.setSegmentName();
    }
    else {
      this.filterPopup = true;
    }
  }
  setSegmentName() {
    let segName = '';
    if (this.segmentSelected == 1) {
      segName = 'Equity';
    }
    else if (this.segmentSelected == 2) {
      segName = 'Derivative';
    }
    else if (this.segmentSelected == 3) {
      segName = 'Commodity';
    }
    else if (this.segmentSelected == 4) {
      segName = 'Currency';
    }
    this.selSegmentName = segName;
    // this.segmentArrayDisplay = this.segmentArray.filter((element, index, array) => {
    //   return element.Value != this.segmentSelected;
    // });

    this.segmentArrayDisplay = this.segmentArray;

  }
  showIndicesPopUp() {
    this.showIndices = !this.showIndices;
    this.searchText = '';
    this.IndexList = this.indicesList;
    if (this.filterPopup) {
      this.filterPopup = false;
    }
    else {
      this.filterPopup = true;
    }
  }
  showExchangePopUp() {
    this.showExchange = !this.showExchange;
    if (this.filterPopup) {
      this.filterPopup = false;
    }
    else {
      this.filterPopup = true;
    }
  }
  showInstrumentPopUp() {
    this.showInstrument = !this.showInstrument;
    if (this.filterPopup) {
      this.filterPopup = false;
    }
    else {
      this.filterPopup = true;
    }
  }
  showExpiryPopUp() {
    this.showExpiry = !this.showExpiry;
    if (this.filterPopup) {
      this.filterPopup = false;
    }
    else {
      this.filterPopup = true;
    }
  }
  submenuhide() {
    this.hideMe = !this.hideMe;
  }
  listItemClick(item) {
    this.isItemClick = !this.isItemClick;
    this.scannerItemList = [];
    this.getAnalyticsData(item);
  }
  onScannerItemChange(item) {
    this.scannerItemList = [];
    let selectedItem = this.scannerList.filter((element, index, array) => {
      if (item == this.tabsList[0])
        return element.ScannerName_1 == item;
      else
        return element.ScannerName_2 == item;
    });
    this.selScannerItem = selectedItem[0];
    this.getAnalyticsData(this.selScannerItem);
    // if (this.isLazyLoadData) {
    //   this.isLazyLoadData = false;
    //   setTimeout(() => {
    //     this.getAnalyticsData(this.selScannerItem);
    //   }, 500);
    // } else {
    //   this.getAnalyticsData(this.selScannerItem);
    // }
  }
  onExchangeChangeData(selitem) {
    if (this.indexListObject != undefined) {
      this.filterIndexDropDown(selitem);
    }
    else {
      this.getAllIndexSectorList();
    }
  }
  onFilterChange() {
    this.viewExpand = false;
    this.filterPopup = !this.filterPopup;
    this.scannerItemList = [];
    if (this.selSegmentName === 'Equity') {
      this.filtersObject[this.selSegmentName] = { exchange: this.selectedExchange, index: this.selectedIndex }
    } else {
      this.filtersObject[this.selSegmentName] = { exchange: this.selectedExchange, instrument: this.selectedFutOpt, expiry: this.selectedNearFar }
    }
    this.updateFilterObject(this.filtersObject);
    this.onScannerItemChange(this.type == '1' ? this.tabsList[0] : this.tabsList[1]);
    //this.getAnalyticsData(this.selScannerItem);
  }
  getSegmentExchanges() {
    let ddItem = null;
    this.dropDownData = [];
    try {
      if (this.segmentSelected == 1) {
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_CASH);
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_CASH);
        //}
      }
      else if (this.segmentSelected == 2) {
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_NSE_EXCHANGE_TEXT, clsConstants.C_V_NSE_DERIVATIVES);
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSE_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        this.addExchange(clsConstants.C_S_BSE_EXCHANGE_TEXT, clsConstants.C_V_BSE_DERIVATIVES);
        //}
      }
      else if (this.segmentSelected == 3) {
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MCX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_MCX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_MCX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_MCX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_ICEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_ICEX_EXCHANGE_TEXT;
        let valueAll: any = {};
        valueAll.exchName = clsConstants.C_S_ICEX_EXCHANGE_TEXT;
        valueAll.exchID = clsConstants.C_V_ICEX_DERIVATIVES;
        ddItem.Value = valueAll;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NCDEX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        let valueAll3: any = {};
        valueAll3.exchName = clsConstants.C_S_NCDEX_EXCHANGE_TEXT;
        valueAll3.exchID = clsConstants.C_V_NCDEX_DERIVATIVES;
        ddItem.Value = valueAll3;
        //ddItem.Value = clsConstants.C_V_NCDEX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
      }
      else if (this.segmentSelected == 4) {
        // (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_NSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        let valueAll2: any = {};
        valueAll2.exchName = clsConstants.C_S_NSX_EXCHANGE_TEXT;
        valueAll2.exchID = clsConstants.C_V_NSX_DERIVATIVES;
        ddItem.Value = valueAll2;
        //ddItem.Value = clsConstants.C_V_NSX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_BSECDX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        let valueAll: any = {};
        valueAll.exchName = clsConstants.C_S_BSECDX_EXCHANGE_TEXT;
        valueAll.exchID = clsConstants.C_V_BSECDX_DERIVATIVES;
        ddItem.Value = valueAll;
        //ddItem.Value = clsConstants.C_V_BSECDX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
        //if (clsGlobal.ExchManager.exchangeAllowed.getItem(clsConstants.C_V_MSX_DERIVATIVES.toString()) == clsConstants.C_S_ON) {
        ddItem = {};
        ddItem.Name = clsConstants.C_S_MSX_EXCHANGE_TEXT;
        let valueAll1: any = {};
        valueAll1.exchName = clsConstants.C_S_MSX_EXCHANGE_TEXT;
        valueAll1.exchID = clsConstants.C_V_MSX_DERIVATIVES;
        ddItem.Value = valueAll1;
        //ddItem.Value = clsConstants.C_V_MSX_DERIVATIVES;
        this.dropDownData.push(ddItem);
        ddItem = null;
        //}
      }
      if (this.filtersObject && this.filtersObject[this.selSegmentName]) {
        if (this.filtersObject[this.selSegmentName].exchange) {
          this.selectedExchange = this.filtersObject[this.selSegmentName].exchange;
        } else {
          let _selectedItem = this.dropDownData.filter((element, index, array) => {
            if (element.Name.toString().toUpperCase() == "NSE INDEX" || element.Name.toString().toUpperCase() == "BSE INDEX")
              return element.Name;
          });
          if (_selectedItem != undefined && _selectedItem != null && _selectedItem.length > 0)
            this.selectedExchange = _selectedItem[0].Name;
          else
            this.selectedExchange = this.dropDownData[0].Name;
        }
      } else {
        let _selectedItem = this.dropDownData.filter((element, index, array) => {
          if (element.Name.toString().toUpperCase() == "NSE INDEX" || element.Name.toString().toUpperCase() == "BSE INDEX")
            return element.Name;
        });
        if (_selectedItem != undefined && _selectedItem != null && _selectedItem.length > 0)
          this.selectedExchange = _selectedItem[0].Name;
        else
          this.selectedExchange = this.dropDownData[0].Name;
      }
      this.filterIndexDropDown(this.selectedExchange);
    } catch (error) {
      // this.objToast.showAtBottom(error);
    }
  }
  addExchange(exchange, value) {
    let valueAll: any = {};
    valueAll.exchName = exchange;
    valueAll.exchID = value;
    valueAll.flagIndexSector = 0;
    let valueIndex: any = {};
    valueIndex.exchName = exchange;
    valueIndex.exchID = value;
    valueIndex.flagIndexSector = 1;
    let valueSector: any = {};
    valueSector.exchName = exchange;
    valueSector.exchID = value;
    valueSector.flagIndexSector = 2;
    let ddItem: any = {};
    ddItem.Name = exchange;
    ddItem.Value = valueAll;
    if (this.dropDownData.length > 0) {
      this.dropDownData.splice(1, 0, ddItem);
    } else {
      this.dropDownData.push(ddItem);
    }
    ddItem = null;
    if (this.segmentSelected != 2) {
      ddItem = {};
      ddItem.Name = exchange + " Index";
      ddItem.Value = valueIndex;
      if (this.dropDownData.length > 2) {
        this.dropDownData.splice(3, 0, ddItem);
      } else {
        this.dropDownData.push(ddItem);
      }
      ddItem = null;
      ddItem = {};
      ddItem.Name = exchange + " Sector";
      ddItem.Value = valueSector;
      if (this.dropDownData.length > 4) {
        this.dropDownData.splice(5, 0, ddItem);
      } else {
        this.dropDownData.push(ddItem);
      }
      ddItem = null;
    }
  }
  getScannerList() {
    this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
      + 'v1/getAppWaveScannerDetails')
      .subscribe((respData: any) => {
        this.scannerList = [];
        if (respData.status) {
          this.globalScannerList = respData.result;
          this.populateScreener();
        }
      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getScannerList',error.Message,undefined,error.stack,undefined,undefined));
      });
  }
  populateScreener() {
    try {
      this.scannerList = [];
      for (let i = 0; i < this.globalScannerList.length; i++) {
        if ((this.segmentSelected == 1 && this.globalScannerList[i].EqAllowed == 1)
          || (this.segmentSelected == 2 && this.globalScannerList[i].DervAllowed == 1)
          || (this.segmentSelected == 3 && this.globalScannerList[i].CommAllowed == 1)
          || (this.segmentSelected == 4 && this.globalScannerList[i].CurrAllowed == 1)) {
          //IsLoggedIn &&
          if (this.globalScannerList[i].FundamentalTechnical == 'T' &&
            (this.globalScannerList[i].IsEnabled == 1 ||
              (this.globalScannerList[i].IsEnabled > 1))) {
            this.scannerList.push(this.globalScannerList[i]);
          }
        }
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'populateScreener',error.Message,undefined,error.stack,undefined,undefined));
      this.objToast.showAtBottom(error);
    }
  }
  getAllIndexSectorList() {
    this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
      + 'v1/getIndexSectorList')
      .subscribe((respData: any) => {
        if (respData.status) {
          this.indexListObject = [];
          for (let i = 0; i < respData.result.length; i++) {
            const indexObj = respData.result[i];
            for (let index = 0; index < indexObj.length; index++) {
              const element = indexObj[index];
              let indexDetail: any = {};
              indexDetail.nIndex = element.Name;
              indexDetail.nFlag = element.Flag;
              indexDetail.nMapMarketSegmentId = element.nMktSegId;
              indexDetail.nMarketSegmentId = clsTradingMethods.GetMarketSegmentID(parseInt(indexObj.nMktSegId));
              indexDetail.nExchange = element.Exchange;
              indexDetail.nCode = element.Code;
              indexDetail.DisplayName = element.Exchange + ' - ' + element.Name;
              indexDetail.ProfileId = '900';
              this.indexListObject.push(indexDetail);
            }
            clsGlobal.indexSectorList = this.indexListObject;
            //Global.IndexListObject.push(indexDetail);
          }
          this.filterIndexDropDown(this.selectedExchange);
        }
      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getAllIndexSectorList',error.Message,undefined,error.stack,undefined,undefined));
      });
  }
  filterIndexDropDown(selitem) {
    this.IndexList = [];
    let selectedItem = this.dropDownData.filter((element, index, array) => {
      return element.Name == selitem;
    });
    if (selectedItem[0].Value.flagIndexSector == undefined ||
      selectedItem[0].Value.flagIndexSector == 0) {
      this.IndexList = [{ "Name": "All", "Value": "All" },];
    }
    else {
      for (var i = 0; i < this.indexListObject.length; i++) {
        if (this.indexListObject[i].nExchange == selectedItem[0].Value.exchName &&
          this.indexListObject[i].nFlag == selectedItem[0].Value.flagIndexSector) {
          let ddItem: any = {};
          ddItem.Name = this.indexListObject[i].nIndex;
          ddItem.Value = this.indexListObject[i];
          this.IndexList.push(ddItem);
          ddItem = null;
        }
      }
    }
    if (this.IndexList.length > 0) {
      if (this.filtersObject && this.filtersObject[this.selSegmentName]) {
        if ((this.filtersObject[this.selSegmentName].exchange === this.selectedExchange) && this.filtersObject[this.selSegmentName].index) {
          this.selectedIndex = this.filtersObject[this.selSegmentName].index;
        } else {
          let _selectedIndex = this.IndexList.filter((element, index, array) => {
            if (element.Name.toString().toUpperCase() == "SENSEX" || element.Name.toString().toUpperCase() == "NIFTY 50")
              return element;
          });
          if (_selectedIndex != undefined && _selectedIndex != null && _selectedIndex.length > 0)
            this.selectedIndex = _selectedIndex[0].Name;
          else
            this.selectedIndex = this.IndexList[0].Name;
        }
      } else {
        let _selectedIndex = this.IndexList.filter((element, index, array) => {
          if (element.Name.toString().toUpperCase() == "SENSEX" || element.Name.toString().toUpperCase() == "NIFTY 50")
            return element;
        });
        if (_selectedIndex != undefined && _selectedIndex != null && _selectedIndex.length > 0)
          this.selectedIndex = _selectedIndex[0].Name;
        else
          this.selectedIndex = this.IndexList[0].Name;
      }
    }
    this.indicesList = this.IndexList;
    this.getAnalyticsData(this.objScannerData.scannerItem);
  }
  setSegmentTypeSelected(item) {
    this.displaySegmentName = item.Name;
    //this.segmentSelected = item.Value;
    // this.selSegmentName = item.Name;
    // this.segmentSelected = item.Value;
    let itemSel: any = {};

    if (item.detail.value == 'Equity') {
      this.selSegmentName = item.detail.value;
      this.segmentSelected = 1;
    }
    else if (item.detail.value == 'Derivative') {
      this.selSegmentName = item.detail.value;
      this.segmentSelected = 2;
    }
    else if (item.detail.value == 'Commodity') {
      this.selSegmentName = item.detail.value;
      this.segmentSelected = 3;
    }
    else if (item.detail.value == 'Currency') {
      this.selSegmentName = item.detail.value;
      this.segmentSelected = 4;
    }
    itemSel.Value = this.segmentSelected;
    itemSel.Name = this.selSegmentName;
    this.segmentTypeSelected(itemSel);
    this.showSegmentPopUp();
  }
  setIndexSelected(item) {
    this.selectedIndex = item.Name;
    this.showIndicesPopUp();
  }
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  search($event) {
    if ($event) {
      this.searchText = $event;
      this.searchTextChanged.next($event);
      // this.globalIndicesList = this.IndexList;
    }
  }
  searchTextEntered: string = '';
  // globalIndicesList : any = [];
  getValues(search) {
    try {
      // if (search.length < 3) {
      //   this.searchTextEntered = '';
      //   return;
      // }
      this.searchTextEntered = search.toUpperCase().trim();
      let indicesData = this.IndexList;
      //console.log(this.indicesList)
      //console.log(indicesData);
      // let filteredIndices = indicesData.filter(x => (x.Name).toUpperCase() == this.searchTextEntered);
      let filteredIndices = this.indicesList.filter(x => {
        return (x.Name).toUpperCase().indexOf(this.searchTextEntered.toUpperCase().trim()) !== -1
      });
      if (filteredIndices.length > 0) {
        this.IndexList = filteredIndices;
      } else {
        this.IndexList = indicesData;
      }
    } catch (error) {
      //console.log(error)
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getValues',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  setInstrumentTypeSelected(item) {
    this.selectedFutOpt = item.Name;
    //this.segmentSelected = item.Value;
    this.showInstrumentPopUp();
  }
  setExpiryTypeSelected(item) {
    this.selectedNearFar = item.Value;
    //this.segmentSelected = item.Value;
    this.showExpiryPopUp();
  }
  setExchangeTypeSelected(item) {
    this.selectedExchange = item.Name;
    this.onExchangeChangeData(this.selectedExchange);
    //this.segmentSelected = item.Value;
    this.showExchangePopUp();
  }
  segmentTypeSelected(type) {
    if (type.name === 'Equity') {
      this.segmentSelected = type.Value;
      //this.setSegmentName();
      this.dropDownData = [];
      //this.scannerItemList = [];
      this.selectedFutOpt = this.futOptArray[0].Value;
      this.selectedNearFar = this.nearFarArray[0].Value;
      this.getSegmentExchanges();
      this.populateScreener();
    } else {
      let filter = this.filtersObject[type.Name];
      this.segmentSelected = type.Value;
      //this.setSegmentName();
      this.dropDownData = [];
      //this.scannerItemList = [];
      this.getSegmentExchanges();
      if (filter.instrument) {
        this.selectedFutOpt = filter.instrument;
      } else {
        this.selectedFutOpt = this.futOptArray[0].Value;
      }
      if (filter.expiry) {
        this.selectedNearFar = filter.expiry;
      } else {
        this.selectedNearFar = this.nearFarArray[0].Value;
      }
      this.populateScreener();
    }
    // if (this.selScannerName != this.scannerList[0].ScannerName) {
    //   this.selScannerName = this.scannerList[0].ScannerName;
    // } else {
    //   this.getAnalyticsData(this.scannerList[0]);
    // }
  }
  getAnalyticsData(item) {
    try {
      this.nodatafound = false;
      this.selScannerName = '';
      if (item == undefined) {
        this.nodatafound = true;
        return;
      }
      //console.log(this.type);
      let redisKey = (this.type == '1') ? item.RedisKeyPrefix_1 : item.RedisKeyPrefix_2;
      item.ScannerName = (this.type == '1') ? item.ScannerName_1 : item.ScannerName_2;
      item.ScannerId = (this.type == '1') ? item.ScannerId_1 : item.ScannerId_2;
      this.selScannerName = item.ScannerName;
      this.selScannerId = item.ScannerId;
      let selIndexSector = this.IndexList.filter((element, index, array) => {
        return element.Name == this.selectedIndex;
      });
      let indexSector = selIndexSector[0].Value == 'All' ? selIndexSector[0].Value : selIndexSector[0].Value.nIndex;
      let selExch = this.dropDownData.filter((element, index, array) => {
        return element.Name == this.selectedExchange;
      });
      let mktSegId = selExch[0].Value.exchID;
      let mappedMktSegId = clsTradingMethods.getMappedMarketSegmentId(mktSegId);
      let futOpt = '-'
      if (this.segmentSelected != 1) {
        futOpt = this.selectedFutOpt;
      }
      let nearFar = '-'
      if (this.segmentSelected != 1) {
        nearFar = this.selectedNearFar;
      }
      let screenerType = 'WaveScreener';
      //if (this.refresherInstance == undefined || this.refresherInstance.state == "inactive")
      //this.loadingCtrl.showLoader();
      this.showloader = true;
      this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + 'v1/getAnalyticsData/' + screenerType + '/' + mappedMktSegId + '/' + indexSector + '/' + redisKey + '/' + futOpt + '/' + nearFar)
        .subscribe((respData: any) => {
          this.showloader = false;
          if (respData.status) {
            this.scannerItemList = [];
            let ItemList = respData.result;
            this.nodatafound = (ItemList != undefined && ItemList.length > 0) ? false : true;
            for (let i = 0; i < ItemList.length; i++) {
              this.scannerItemList.push(
                {
                  nClose: ItemList[i]["nClose"],
                  nData: ItemList[i]["nData"],
                  nExpiryDate: ItemList[i]["nExpiryDate"] != "0" ? this.getExpiry(ItemList[i]["nExpiryDate"]) : "",
                  nHigh: ItemList[i]["nHigh"],
                  nLastTradedPrice: ItemList[i]["nLTP"],
                  nLow: ItemList[i]["nLow"],
                  nMarketSegmentId: ItemList[i]["nMarketSegmentId"],
                  nNetChangeFromPrevClose: ItemList[i]["nPercChange"],//nNetChangeFromPrevClose
                  nOpen: ItemList[i]["nOpen"],
                  nStrikePrice: ((ItemList[i]["nStrikePrice"] != "-0.01" && ItemList[i]["nStrikePrice"] != "0.00" && ItemList[i]["nStrikePrice"] != "0.0000") ? ItemList[i]["nStrikePrice"] : ''),
                  nToken: ItemList[i]["nToken"],
                  nTotalQuantityTraded: ItemList[i]["nVolume"],//nTotalQuantityTraded
                  sData: ItemList[i]["sData"],
                  sInstrumentName: ItemList[i]["sInstrumentName"],
                  sOptionType: ItemList[i]["sOptionType"].trim() != "XX" ? ItemList[i]["sOptionType"].trim() : "",
                  sSectorName: ItemList[i]["sSectorName"],
                  sSeries: ItemList[i]["sSeries"].trim(),
                  sSymbol: ItemList[i]["sSymbol"],
                  sDataCol: this.getColumnData(ItemList[i]),
                  Visible: false,
                  sExchangeName: clsTradingMethods.getExchangeName(clsTradingMethods.GetMarketSegmentID(parseInt(ItemList[i]["nMarketSegmentId"]))),
                  hots: []
                });
              if (this.segmentSelected != 1) {
                let sInstrumentName = this.scannerItemList[i].sInstrumentName.substring(0, 3);
                let strExpDate = this.scannerItemList[i].nExpiryDate;
                if (strExpDate != '' && strExpDate != undefined)
                  strExpDate = strExpDate.substring(0, 2) + ' ' + strExpDate.substring(2, 5); /*+ "'" + strExpDate.substring(7, 9);*/
                let strStkPrice = this.scannerItemList[i].nStrikePrice;
                let strOptType = this.scannerItemList[i].sOptionType;
                let tarr = [];
                tarr.push([sInstrumentName, strExpDate.trim(), strStkPrice.trim(), strOptType.trim()]);
                let expiryFormat = tarr.join(" ").replace(/,/gi, " ");
                this.scannerItemList[i].formattedExpiry = expiryFormat;
              }
              let arrNetChange = clsTradingMethods.getChangeInRs(this.scannerItemList[i].nLastTradedPrice, this.scannerItemList[i].nClose, 2, true);
              this.scannerItemList[i].NetChangeInRs = arrNetChange[0];
              this.scannerItemList[i].PercNetChange = arrNetChange[1];
              this.scannerItemList[i].PercChngDataTrend = arrNetChange[2];
              this.scannerItemList[i].PercChngDataTrendArrow = arrNetChange[3];
            }
            this.sendTouchlineRequest(OperationType.ADD, this.scannerItemList);
            this.fetchEventList();
            if (!clsGlobal.User.isGuestUser)
              this.getHoldingsData();
            //window.scroll(0,50);
            //this.showExpandHeader = true;
            //this.loadingCtrl.hideLoader();
          } else {
            this.showloader = false;
            this.nodatafound = true;
            //this.loadingCtrl.hideLoader();
          }
        }, error => {
          this.showloader = false;
          this.nodatafound = true;
          //this.loadingCtrl.hideLoader();
          //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'getAnalyticsData', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getAnalyticsData',error.Message,undefined,error.stack,undefined,undefined));
        });
    } catch (error) {
      //this.loadingCtrl.hideLoader();
      this.showloader = false;
      this.nodatafound = true;
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'getAnalyticsData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getAnalyticsData2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  getHoldingsData() {
    // this.transactionService.getHoldingsData().then((holdingsResponse: any) => {
    //   if (holdingsResponse.status == 'Success') {
    //     //this.holdingData = holdingsResponse.data;
    //     clsGlobal.userHoldingForWatchlist = true;
    //     clsGlobal.userHoldingDataForWatchlist = holdingsResponse.data;
    this.fillStockViewScrip();
    //   }
    // }, error => {
    //   console.log(error)
    // });
  }
  /**
     * To get Stock View Scrip to display in My Stock Watchlist
     */
  async fillStockViewScrip() {
    try {
      if (clsGlobal.User.Holding.length > 0) {
        // this.profileList.push({
        //   nWatchListId: 1001,
        //   sWatchListName: 'My Holdings',
        //   bIsPrivate: "false",
        //   bIsDefault: "false",
        //   sCreatedBy: '',
        //   nTenantId: ''
        // });
        //this.profileCnt = this.profileList.length;
        this.fillHoldingData();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'getStockViewScrip', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'fillStockViewScrip',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  fillHoldingData() {
    try {
      //if (clsGlobal.userHoldingDataForWatchlist != undefined) {
      for (let i = 0; i < clsGlobal.User.Holding.length; i++) {
        let mapMktSegId = parseInt(clsGlobal.User.Holding[i].nMarketSegmentId);
        // this.myStockScripList.push({
        //   nWatchListId: 1001,
        //   nMarketSegmentId: clsTradingMethods.GetMarketSegmentID(mapMktSegId),
        //   nToken: parseInt(clsGlobal.userHoldingDataForWatchlist[i].nToken)
        // })
        let holdingScrip = this.scannerItemList.filter(item => {
          let currScrip: clsScrip = new clsScrip();
          currScrip.scripDet.MktSegId = parseInt(item.nMarketSegmentId);
          //currScrip.scripDet.MapMktSegId
          return currScrip.scripDet.MapMktSegId == mapMktSegId &&
            item.nToken == clsGlobal.User.Holding[i].nToken;
        })
        if (holdingScrip.length > 0) {
          //let holdingData: any = {};
          holdingScrip[0].holding = clsGlobal.User.Holding[i];
        }
      }
      //}
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'fillHoldingData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  gotoQuote(item: any) {
    try {
      //this.loadingCtrl.showLoader();
      this.getScripInfo(item.nMarketSegmentId, item.nToken).then((resp: any) => {
        let scripObj = clsCommonMethods.getScripObject(resp.result[0]).scripDetail;
        //scripObj.isDashboardScreener = true;
        let scripObjForWatchlist = {
          exp: scripObj.ExpiryDate,
          sSymbol: scripObj.symbol,
          sOptionType: scripObj.OptionType,
          nStrikePrice: ["", 0],
          nExpiryDate: (scripObj.ExpiryDate == 'NA') ? 0 : clsTradingMethods.convertToSeconds(scripObj.ExpiryDate),
          nExpiryDate1: '',
          nExpiryDate2: '',
          nAssetToken: scripObj.AssetToken,
          nInstrumentType: '',
          nMarketSegmentId: scripObj.scripDet.MapMktSegId,
          nNormal_MarketAllowed: '',
          nPriceBdAttribute: scripObj.DecimalLocator,
          nRegularLot: scripObj.MarketLot,
          nToken: scripObj.scripDet.token,
          sDerivitiveDesc: '',
          sInstrumentName: scripObj.InstrumentName,
          sSecurityDesc: scripObj.SecurityDesc,
          sSeries: scripObj.Series,
          nSPOS: '',
          nPOS: '',
          DecimalLocator: scripObj.DecimalLocator,
          nNRILimit: scripObj.NRILimit,
          nFIILimit: scripObj.FIILimit,
          nPriceTick: scripObj.PriceTick,
          nSpread: scripObj.Spread,
          sISINCode: scripObj.ISIN,
          sGlobalNormalFlag: '',
          nStrikePrice1: (scripObj.StrikePrice == 'NA') ? "" : scripObj.StrikePrice,
          nFIIFlag: '',
          nMarginTypeIndicator: '',
          nAVMBuyMargin: '',
          nAVMSellMargin: '',
          nPriceNum: scripObj.priceNumerator,
          nPriceDen: scripObj.priceDenominator,
          nIsAsset: '',
          nIntrinsicValue: '',
          nIsIndex: '',
          nFOExists: '',
          nCoCode: '',
          nSectorCode: '',
          nOtherExchToken: '',
          sSector: '',
          nExpiryMonth: '',
          sSearchText: '',
          markedDeleted: '',
        };
        //this.loadingCtrl.hideLoader();
        // let quotepopover = this.modalCtrl.create(QuotePopoverPage,  { obj: [scripObjForWatchlist, '', scripObj] }, { cssClass: clsGlobal.defaultTheme });
        // quotepopover.onDidDismiss((obj) =>{
        //   if(obj != undefined)
        //   {
        //     if(obj.QuotePage == true)
        //     {
        //         this.navCtrl.push(QuotePage, obj);
        //     }
        //     else if(obj.ChartPage == true)
        //     {
        //         this.navCtrl.push(AdvanceChartPage, obj)
        //     } 
        //     else if(obj.OrderPage == true)
        //     {
        //         this.navCtrl.push("OrderEntryPage", obj)
        //     }
        //   }
        // })
        // quotepopover.present();
      }).catch(error => {
        //this.loadingCtrl.hideLoader();
        //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'gotoQuote1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'gotoQuote1',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'gotoQuote2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'gotoQuote2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  getScripInfo(segmentId: any, token: any) {
    try {
      return new Promise((resolve, reject) => {
        try {
          this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
            + 'v1/getScrip/' + segmentId + "/" + token + "/" + clsGlobal.User.SITemplateId)
            .subscribe(respData => {
              resolve(respData);
            }, error => {
              reject("Unable to fetch data.");
            });
        } catch (error) {
          reject("Unable to fetch data.");
        }
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'getScripInfo', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'getScripInfo',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  getColumnData(item) {
    if (this.selScannerId == 3)
      return "52Wk High: " + item.sData;
    else if (this.selScannerId == 4)
      return "52Wk Low: " + item.sData;
    else if (this.selScannerId == 5 || this.selScannerId == 12 || this.selScannerId == 13)
      return "Vol: " + item.sData;
    else if (this.selScannerId == 6)
      return "HDPR: " + item.sData;
    else if (this.selScannerId == 7)
      return "LDPR: " + item.sData;
    else if (this.selScannerId == 14 || this.selScannerId == 15 || this.selScannerId == 18 || this.selScannerId == 19)
      return "OI: " + item.sData;
    else
      return "";
  }
  getExpiry(expiryseconds) {
    return clsTradingMethods.convertToDate(expiryseconds, undefined);
  }
  updateFilterObject(filtersObject) {
    this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_SCREENERS_FILTER, filtersObject);
  }
  /**
* Pull down on refresh.
* @param refresher
*/
  doRefresh(refresher) {
    try {
      this.scannerItemList = [];
      this.refresherInstance = refresher;
      if (this.refresherInstance != undefined)
        this.refresherInstance.complete();
      this.getAnalyticsData(this.selScannerItem);
    } catch (e) {
      if (this.refresherInstance != undefined)
        this.refresherInstance.complete();
      this.objToast.showAtBottom(e);
      //clsGlobal.logManager.writeErrorLog('message-hub', 'doRefresh', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'doRefresh',e.Message,undefined,e.stack,undefined,undefined));
    }
  }
  /**
  *
  * @param field
  * @param type
  */
  sortBy(field: string, type: any) {
    try {
      this.sortField = field;
      this.orderDesc = !this.orderDesc;
      this.scannerItemList = clsCommonMethods.sortArray(this.scannerItemList, type, field, this.orderDesc);
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'sortBy', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'sortBy',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  showPopUpOrderEntry(side, item) {

    if (clsGlobal.User.isGuestUser) {
      let buttons: any = ["Login", "Skip"];
      this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
        () => {
          //success navigate to login screen 
          this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
        }, () => {
          //fail No or cancel click //do nothing.
        });
      return;
    }
    let SegmentId = clsTradingMethods.GetMarketSegmentID(item.nMarketSegmentId);
    if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }

    let scripdetail = {
      scrips: [{
        mkt: clsTradingMethods.getApiExchangeName(clsTradingMethods.GetMarketSegmentID(parseInt(item.nMarketSegmentId))),
        token: item.nToken
      }]
    }
    clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
      let res = resp.result[0];
      if (!res) {
        this.objToast.showAtBottom("Unable to open Order Entry.");
        return;
      }
      let selectedScripObj = clsCommonMethods.getScripObject(resp.result[0]).scripDetail;
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;
      objOEFormDetail.scripDetl = selectedScripObj;
      this.selectedScrip = objOEFormDetail;
      //Uncomment Below to open order entry popup, in same page
      this.showPopUpOE = !this.showPopUpOE;

    }).catch(error => {

      this.objToast.showAtBottom("Unable to open Order Entry.");
      //clsGlobal.logManager.writeErrorLog('scrrenr-view', 'scripinfo', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'showPopUpOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    });
  }

  scripInfo(item) {
    if (clsGlobal.User.isGuestUser) {
      this.alertCtrl.showAlert(
        "Register now to access this feature!",
        "Order Error!"
      );
      return;
    }

    let SegmentId = clsTradingMethods.GetMarketSegmentID(item.nMarketSegmentId);
    if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }

    let scripdetail = {
      scrips: [{
        mkt: clsTradingMethods.getApiExchangeName(clsTradingMethods.GetMarketSegmentID(parseInt(item.nMarketSegmentId))),
        token: item.nToken
      }]
    }

    clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.objHttpService).then((resp: any) => {
      let res = resp.result[0];
      if (!res) {
        this.objToast.showAtBottom("Unable to open Scrip Info.");
        return;
      }
      let selectedScripObj = clsCommonMethods.getScripObject(resp.result[0]).scripDetail;
      this.paramService.myParam = selectedScripObj;
      this.navCtrl.navigateForward('scripinfo');
    }).catch(error => {

      this.objToast.showAtBottom("Unable to open Scrip Info.");
      //clsGlobal.logManager.writeErrorLog('scrrenr-view', 'scripinfo', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'scripinfo',error.Message,undefined,error.stack,undefined,undefined));
    });
  }

  receiveMessage($event) {
    this.showPopUpOE = !$event.closePopUp;
    this.showFullMode = false;
  }

  //change by ompraksh d on 3 feb.
  //when ever controls in order entry will focus 
  //popup order entry will be in full mode.
  onFocus(event) {
    this.showFullMode = true;
  }

  async fetchEventList() {
    await this.applyEventToScannerList();
  }

  applyEventToScannerList() {
    try {
      clsGlobal.EventList.forEach(eventItem => {
        this.scannerItemList.forEach(element => {
          if (clsTradingMethods.getMappedMarketSegmentId(element.nMarketSegmentId) == eventItem.mktid && parseInt(element.nToken) == eventItem.token) {
            if (!element.hots.includes(eventItem))
              element.hots.push(eventItem);
          }
        });
      });
      //console.log(this.scannerItemList);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'applyEventToScannerList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async favUnFavScreeners(item) {
    try {
      await this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.tempFavScreeners = obj;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if (!item.scannerItem.Favourite || item.scannerItem.Favourite == false) {
        item.scannerItem.Favourite = true;
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = true;
        });
        this.tempFavScreeners.push(item.scannerItem);
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
      else {
        if (this.tempFavScreeners.length == 5)
          return this.objToast.showAtBottom("There should be atleast 5 Screeners in My Favourite Screeners.");
        item.scannerItem.Favourite = false;
        this.tempFavScreeners = this.tempFavScreeners.filter((element, index, array) => {
          return element.GroupName != this.hdrName;
        });
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = false;
        });
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
    } catch (error) {
      console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'favUnFavScreeners',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  /**
     * Receive broadcast and bind to html
     * @param objMultiTLResp
     */
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      if (objMultiTLResp != null && this.scannerItemList != undefined) {
        //
        for (let i = 0; i < this.scannerItemList.length; i++) {
          if (
            this.scannerItemList[i].nMarketSegmentId == objMultiTLResp.Scrip.MktSegId &&
            this.scannerItemList[i].nToken == objMultiTLResp.Scrip.token) {
            //console.log(objMultiTLResp);
            if (this.scannerItemList[i].nLastTradedPrice > objMultiTLResp.LTP) {
              this.scannerItemList[i].LTPChangeCss = "sell-ltp-change";
            }
            else if (this.scannerItemList[i].nLastTradedPrice < objMultiTLResp.LTP) {
              this.scannerItemList[i].LTPChangeCss = "buy-ltp-change";
            }
            else {
              this.scannerItemList[i].LTPChangeCss = "";
            }
            //if(this.scannerItemList[i].scripDetail.scripDet.token=="26000")
            //console.log(this.scannerItemList[i].LTP +'--'+objMultiTLResp.LTP);
            this.scannerItemList[i].nLastTradedPrice = objMultiTLResp.LTP;
            // if (this.holdingdata.length > 0) {
            //   this.scannerItemList[i].totalFreeQuantity = this.holdingdata[0].TOTALFREEQUANTITY;
            //   this.scannerItemList[i].bShowHolding = true;
            // }
            // else {
            //   this.scannerItemList[i].totalFreeQuantity = "0"
            //   this.scannerItemList[i].bShowHolding = false;
            // }
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
            this.scannerItemList[i].NetChangeInRs = arrNetChange[0];
            this.scannerItemList[i].PercNetChange = arrNetChange[1];
            this.scannerItemList[i].LTPTrend = arrNetChange[2];
            this.scannerItemList[i].PercNetChangeRaw = arrNetChange[3];
            this.scannerItemList[i].BuyPrice = objMultiTLResp.BuyPrice;
            this.scannerItemList[i].BuyQty = objMultiTLResp.BuyQty;
            this.scannerItemList[i].SellPrice = objMultiTLResp.SellPrice;
            this.scannerItemList[i].SellQty = objMultiTLResp.SellQty;
            //this.scannerItemList[i].Volume = this.numbertoString(objMultiTLResp.Volume);
            //this.scannerItemList[i].HeatMapClass = this.getChangeInRsForHeatmap(arrNetChange[1], arrNetChange[2])
            if (this.scannerItemList[i].holding != undefined) {
              let buyAvgPrice = this.scannerItemList[i].holding.nBuyAvgPrice * this.scannerItemList[i].holding.TOTALFREEQUANTITY;
              let LTP = parseFloat(objMultiTLResp.LTP) * this.scannerItemList[i].holding.TOTALFREEQUANTITY;
              //let profitLoss = buyAvgPrice - LTP;
              let arrNetChangePNL = clsTradingMethods.getChangeInRs(buyAvgPrice.toString(), LTP.toFixed(2), objMultiTLResp.PriceFormat, false, 'uptrend');
              this.scannerItemList[i].holding.PNL = arrNetChangePNL[0];
              this.scannerItemList[i].holding.PNLPer = arrNetChangePNL[1];
              this.scannerItemList[i].holding.PNLTrend = arrNetChangePNL[2];
            }
            break;
          }
        }
      }
      for (let index = 0; index < this.eventList.length; index++) {
        const element = this.eventList[index];
        if (
          parseInt(element.mktid) == objMultiTLResp.Scrip.MktSegId &&
          (element.token) == objMultiTLResp.Scrip.token) {
          element.LTP = objMultiTLResp.LTP;
          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
          element.NetChangeInRs = arrNetChange[0];
          element.PercNetChange = arrNetChange[1];
          element.LTPTrend = arrNetChange[2];
          element.PercNetChangeRaw = arrNetChange[3];
          //break;
        }
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillLeave() {
    try {
      this.sendTouchlineRequest(OperationType.REMOVE, this.scannerItemList);
      this.showPopUpOE = false;
      this.selectedScrip = undefined;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScreenerViewPage', 'ionViewWillLeave', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('ScreenerViewPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  onFilters(type) {
    this.showfilter();
    if (type == 'seg') {
      this.showSegmentPopUp();
    }
    else if (type == 'exch') {
      this.showExchangePopUp();
    }
    else if (type == 'ind') {
      this.showIndicesPopUp();
    }
    else if (type == 'exp') {
      this.showExpiryPopUp();
    }
    else if (type == 'inst') {
      this.showInstrumentPopUp()
    }
  }

}
