import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ScreenerViewPageRoutingModule } from './screener-view-routing.module';
import { ComponentsModule } from "src/app/components/components.module";
import { ScreenerViewPage } from './screener-view.page';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { createTranslateLoader } from '../../Common/clsCustomeTranslateLoader';
import { clsHttpService } from '../../Common/clsHTTPService';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComponentsModule,
    ScreenerViewPageRoutingModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [clsHttpService]
      }
    })
  ],
  declarations: [ScreenerViewPage]
})
export class ScreenerViewPageModule {}
