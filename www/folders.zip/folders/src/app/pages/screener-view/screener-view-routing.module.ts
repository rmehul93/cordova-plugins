import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ScreenerViewPage } from './screener-view.page';

const routes: Routes = [
  {
    path: '',
    component: ScreenerViewPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ScreenerViewPageRoutingModule {}
