import { Component, OnInit } from '@angular/core';
import { NavController, NavParams, ModalController } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { TransactionService } from 'src/app/providers/transaction.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';

@Component({
  selector: 'app-multileg-confirmation',
  templateUrl: './multileg-confirmation.page.html',
})
export class MultilegConfirmationPage implements OnInit {

  multilegs : any;
  approxamt : any = 0;
  availableMargin : any = 0;
  isMultiLeg : boolean = false;
  isSpread : boolean = false;
  validity : any;
  spreadlegs : any = [];
  approxmargin : any = 0;
  modify : boolean = false;
  gatewayNo : any = '';
  showOrderResult : boolean = false;
  dataMultiLegOE: any = null;
  confirmTxt: any = "";
  orderID: any = "";
  _setVar;
  disableConfirm : boolean = false;

  constructor(private navCtrl: NavController,
    private paramService: NavParamService,
    private tranService: TransactionService,
    private toastCtrl: ToastServicesProvider,
    public navParam: NavParams,
    public modalCtrl: ModalController,) { }

  ngOnInit() {
    try{
    let details = this.navParam.get("scrip");
    this.isMultiLeg = details.isMultiLeg;
    this.isSpread = details.isSpread;
    this.approxmargin = details.approxmargin;
    this.availableMargin = details.availableMargin;
    this.validity = details.validity;
    if(this.isMultiLeg)
    {
      this.multilegs = details.legdetails;
    }
    if(this.isSpread)
    {
      this.modify =  details.modify;
      this.approxamt = details.approxamt;
      this.spreadlegs = details.legdetails;
      this.gatewayNo = details.gatewayNo;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  confirmOrder() {
    try{
    this.disableConfirm = true;
    let reqBody: any = {};

    if(this.isMultiLeg)
    {
      if (this.multilegs.length == 2) {
        reqBody =
        {
          "type": "2L",
          "validity": this.validity,
          "prot_perc": "",
          "leg_details":
            [
              {
                "leg_no": 1,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(this.multilegs[0].legmktsegid),
                  "scrip_token": this.multilegs[0].legToken,
                  "symbol": this.multilegs[0].legsymbol,
                  "series": this.multilegs[0].legseries,
                  "expiry_date": this.multilegs[0].legexpiryDate,
                  "strike_price": this.multilegs[0].legstrikePrice,
                  "option_type": this.multilegs[0].legoptionType,
                  "instrument_name": this.multilegs[0].leginstrumentName
                },
                "transaction_type": this.multilegs[0].legbuysell,
                "quantity": (this.multilegs[0].totallegLot * this.multilegs[0].originallegLot),
                "price": this.multilegs[0].legprice,
                "others": {
                  "market_lot": this.multilegs[0].originallegLot,
                  "price_tick": this.multilegs[0].legpricetick,
                  "decimal_loc": this.multilegs[0].legDecimalLocator
                }
              },
              {
                "leg_no": 2,
                "transaction_type": this.multilegs[1].legbuysell,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(this.multilegs[1].legmktsegid),
                  "scrip_token": this.multilegs[1].legToken,
                  "symbol": this.multilegs[1].legsymbol,
                  "series": this.multilegs[1].legseries,
                  "expiry_date": this.multilegs[1].legexpiryDate,
                  "strike_price": this.multilegs[1].legstrikePrice,
                  "option_type": this.multilegs[1].legoptionType,
                  "instrument_name": this.multilegs[1].leginstrumentName
                },
                "quantity": (this.multilegs[1].totallegLot * this.multilegs[1].originallegLot),
                "price": this.multilegs[1].legprice,
                "others": {
                  "market_lot": this.multilegs[1].originallegLot,
                  "price_tick": this.multilegs[1].legpricetick,
                  "decimal_loc": this.multilegs[1].legDecimalLocator
                }
              }
            ]
        }
      }
      else if (this.multilegs.length == 3) {
        reqBody =
        {
          "type": "3L",
          "validity": this.validity,
          "prot_perc": "",
          "leg_details":
            [
              {
                "leg_no": 1,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(this.multilegs[0].legmktsegid),
                  "scrip_token": this.multilegs[0].legToken,
                  "symbol": this.multilegs[0].legsymbol,
                  "series": this.multilegs[0].legseries,
                  "expiry_date": this.multilegs[0].legexpiryDate,
                  "strike_price": this.multilegs[0].legstrikePrice,
                  "option_type": this.multilegs[0].legoptionType,
                  "instrument_name": this.multilegs[0].leginstrumentName
                },
                "transaction_type": this.multilegs[0].legbuysell,
                "quantity": (this.multilegs[0].totallegLot * this.multilegs[0].originallegLot),
                "price": this.multilegs[0].legprice,
                "others": {
                  "market_lot":  this.multilegs[0].originallegLot,
                  "price_tick": this.multilegs[0].legpricetick,
                  "decimal_loc": this.multilegs[0].legDecimalLocator
                }
              },
              {
                "leg_no": 2,
                "transaction_type": this.multilegs[1].legbuysell,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(this.multilegs[1].legmktsegid),
                  "scrip_token": this.multilegs[1].legToken,
                  "symbol": this.multilegs[1].legsymbol,
                  "series": this.multilegs[1].legseries,
                  "expiry_date": this.multilegs[1].legexpiryDate,
                  "strike_price": this.multilegs[1].legstrikePrice,
                  "option_type": this.multilegs[1].legoptionType,
                  "instrument_name": this.multilegs[1].leginstrumentName
                },
                "quantity": (this.multilegs[1].totallegLot * this.multilegs[1].originallegLot),
                "price": this.multilegs[1].legprice,
                "others": {
                  "market_lot": this.multilegs[1].originallegLot,
                  "price_tick": this.multilegs[1].legpricetick,
                  "decimal_loc": this.multilegs[1].legDecimalLocator
                }
              },
              {
                "leg_no": 3,
                "transaction_type": this.multilegs[2].legbuysell,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(this.multilegs[2].legmktsegid),
                  "scrip_token": this.multilegs[2].legToken,
                  "symbol": this.multilegs[2].legsymbol,
                  "series": this.multilegs[2].legseries,
                  "expiry_date": this.multilegs[2].legexpiryDate,
                  "strike_price": this.multilegs[2].legstrikePrice,
                  "option_type": this.multilegs[2].legoptionType,
                  "instrument_name": this.multilegs[2].leginstrumentName
                },
                "quantity": (this.multilegs[2].totallegLot * this.multilegs[2].originallegLot),
                "price": this.multilegs[2].legprice,
                "others": {
                  "market_lot": this.multilegs[0].originallegLot,
                  "price_tick": this.multilegs[2].legpricetick,
                  "decimal_loc": this.multilegs[2].legDecimalLocator
                }
              }
            ]
        }
      }
    }

    if(this.isSpread)
    {
      reqBody =
      {
        "type": "SPREAD",
        "validity": this.validity,
        "prot_perc": "",
        "leg_details":
          [
            {
              "leg_no": 1,
              "scrip_info": {
                "exchange": clsTradingMethods.getApiExchangeName(this.spreadlegs.marketsegid),
                "scrip_token": this.spreadlegs.leg1token,
                "symbol": this.spreadlegs.leg1symbol,
                "series": this.spreadlegs.leg1series,
                "expiry_date": this.spreadlegs.leg1Expiry,
                "strike_price": this.spreadlegs.leg1strikeprice,
                "option_type": this.spreadlegs.leg1optiontype,
                "instrument_name": this.spreadlegs.leg1instrumentname
              },
              "transaction_type": this.spreadlegs.leg1buysell.toUpperCase(),
              "quantity": this.spreadlegs.totallot * this.spreadlegs.originalspreadLot,
              "price": this.spreadlegs.spreadprice,
              "others": {
                "market_lot": this.spreadlegs.originalspreadLot,
                "price_tick": this.spreadlegs.leg1pricetick,
                "decimal_loc": this.spreadlegs.leg1decimalloc
              }
            },
            {
              "leg_no": 2,
              "transaction_type": this.spreadlegs.leg2buysell.toUpperCase(),
              "scrip_info": {
                "exchange": clsTradingMethods.getApiExchangeName(this.spreadlegs.marketsegid),
                "scrip_token": this.spreadlegs.leg2token,
                "symbol": this.spreadlegs.leg2symbol,
                "series": this.spreadlegs.leg2series,
                "expiry_date": this.spreadlegs.leg2Expiry,
                "strike_price": this.spreadlegs.leg2strikeprice,
                "option_type": this.spreadlegs.leg2optiontype,
                "instrument_name": this.spreadlegs.leg2instrumentname
              },
              "quantity": this.spreadlegs.totallot * this.spreadlegs.originalspreadLot,
              "price": this.spreadlegs.spreadprice,
              "others": {
                "market_lot": this.spreadlegs.originalspreadLot,
                "price_tick": this.spreadlegs.leg2pricetick,
                "decimal_loc": this.spreadlegs.leg2decimalloc
              }
            }
          ]
      }
    }

    if(this.isSpread && this.modify)
    {
      this.tranService.modifyOrCancelSpreadOrder(reqBody,this.gatewayNo,'modify')
      .then((response: any) => {
        this.disableConfirm = false;;
        this.paramService.myParam = { "reqBody": reqBody, "response": response, "totallot" : this.spreadlegs.totallot };
        this.modalCtrl.dismiss();
        this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_TRANSACTION);

      }).catch(error => {
        this.disableConfirm = true;
        //this.toastCtrl.showWithButton(error.error.message);
        this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'orderResultDetails',error.Message,undefined,error.stack,undefined,undefined));
      });
    }
    else
    {
      this.tranService.placeMultiLegOrder(reqBody)
      .then((response: any) => {
        this.disableConfirm = false;
        if(this.isMultiLeg)
        this.paramService.myParam = { "reqBody": reqBody, "response": response };
        if(this.isSpread)
        this.paramService.myParam = { "reqBody": reqBody, "response": response, "totallot" : this.spreadlegs.totallot };
        this.showOrderResult = true;
        this.orderResultDetails()

      }).catch(error => {
        //this.toastCtrl.showWithButton(error.error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'confirmOrder',error.Message,undefined,error.stack,undefined,undefined));
        this.disableConfirm = true;
        this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
      });
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'confirmOrder',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  goBack(){
    this.modalCtrl.dismiss();
  }
  
  orderResultDetails()
  {
    try{
    if (this.paramService.myParam) {
      this.dataMultiLegOE = this.paramService.myParam;
      let leg1 = '';
      let leg2 = '';
      let leg3 = '';

      if (this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date != undefined &&
        this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date != '') {
        let leg1expiry = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(-2);

        if (this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.strike_price != '') {
          leg1 = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.symbol + ' ' + leg1expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.option_type;
        } else {
          leg1 = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.symbol + ' ' + leg1expiry + ' FUT';
        }
      }

      if (this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date != undefined &&
        this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date != '') {
        let leg2expiry = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(-2);

        if (this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.strike_price != '') {
          leg2 = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.symbol + ' ' + leg2expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.option_type;
        } else {
          leg2 = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.symbol + ' ' + leg2expiry + ' FUT';
        }
      }

      if(this.dataMultiLegOE.reqBody.type == '3L'){
        if (this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date != undefined &&
          this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date != '') {
          let leg3expiry = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(-2);
  
          if (this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.strike_price != '') {
            leg3 = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.symbol + ' ' + leg3expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.option_type;
          } else {
            leg3 = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.symbol + ' ' + leg3expiry + ' FUT';
          }
        }
      }

      if(this.dataMultiLegOE.reqBody.type == '2L')
      {
        this.confirmTxt = " Your Multileg order consisting of " + leg1 + " & " + leg2 + " has been placed Successfully! ";
      }
      else if(this.dataMultiLegOE.reqBody.type == '3L')
      {
        this.confirmTxt = " Your Multileg order consisting of " + leg1 + ", " + leg2 + " & " + leg3 + " has been placed Successfully! ";
      }
      else if(this.dataMultiLegOE.reqBody.type == 'SPREAD')
      {
        let typeleg1 = this.dataMultiLegOE.reqBody.leg_details[0].transaction_type;
        let typeleg2 = this.dataMultiLegOE.reqBody.leg_details[1].transaction_type;
        this.confirmTxt = " You have placed a Spread Order to " + typeleg1 + " " + leg1 + " and " + typeleg2 +" " + leg2 + " for "+ this.dataMultiLegOE.totallot + " Lot " + "("+ this.dataMultiLegOE.reqBody.leg_details[0].quantity+ " shares"+")";
      }
      this.orderID = this.dataMultiLegOE.response.data.orderId;
      this._setVar=setTimeout(() => {
        this.closeConfirmation(); 
       }, 5000); 
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'confirmOrder',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  
  closeConfirmation() {
    try {
      clearTimeout(this._setVar);
      if(this.orderID == '')
      {
        this.modalCtrl.dismiss();
      }
      else
      {
        this.modalCtrl.dismiss('Success');
      }
      //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "closeConfirmation", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'closeConfirmation',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillLeave(){
    clearTimeout(this._setVar);
  }

  gotoTransaction() {
    try {
      clearTimeout(this._setVar);
      this.paramService.myParam.mode = 'open';
      this.modalCtrl.dismiss();
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegConfirmationPage', 'gotoTransaction',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
