import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { IonicModule } from '@ionic/angular'; 
import { MpinloginPageRoutingModule } from './mpinlogin-routing.module'; 
import { MpinloginPage } from './mpinlogin.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { CodeInputModule } from 'angular-code-input';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,CodeInputModule,
    MpinloginPageRoutingModule,DirectiveSharedModule,ComponentsModule
  ],
  declarations: [MpinloginPage]
})
export class MpinloginPageModule {}
