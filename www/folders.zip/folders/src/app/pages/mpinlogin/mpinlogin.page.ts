import { NavParamService } from './../../providers/nav-param.service';
import { Component, OnInit } from '@angular/core';
import { NavController, Platform, ModalController, LoadingController, MenuController } from '@ionic/angular';
//import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsCommunicatorProvider } from 'src/app/communicator/clsCommunicatorProvider';
//import { PouchCouchServicesProvider } from 'src/app/providers/pouch-couch-services/pouch-couch-services';
import { DomSanitizer } from '@angular/platform-browser';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { TranslateService } from '@ngx-translate/core';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsExchManager } from 'src/app/Common/clsExchManager';
import { clsMarketStatus } from 'src/app/Common/clsMarketStatus';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mpinlogin',
  templateUrl: './mpinlogin.page.html',
})
export class MpinloginPage implements OnInit {
  userId: string = "";
  groupId: string = "";
  invalidAttempt: any = 1;
  isFingerPrintEnabled: boolean = false;
  profilePic: any = "";
  isFaceAvailable: boolean = false;
  isFingerAuthAvailable: boolean = false;
  productCode: number = 0;/** mobile or tablet */
  mpinMaxInvalidAttempt: number;
  // = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MPIN_MAX_INVALID_ATTEMPT)) || 5;
  mpinValue: string = '';
  loadingElement: any;
  isVerified: boolean = false;
  durationTime = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_LOADER_DISPLAY_MILLISECONDS)) || 20000;
  mpin1: any = '';
  mpin2: any = '';
  mpin3: any = '';
  mpin4: any = '';
  mpin5: any = '';
  mpin6: any = '';
  mpinError: string = "";
  passwordType: string = 'password';
  passwordIcon: string = "eye-off-icon";
  showMPIN: boolean = false;
  userName: string = "";
  shortName: string = "";
  showBrokerInfoDataLoader: boolean = true;
  brokerInfoData: any = [];//to display broker info data
  noOfAttemptCount: number = 2;
  noOfAttempt: number = 1;
  exchangeTimeData: any = [];
  aboutUsData: string = "";
  showExchangeTiming: boolean = false;
  showAboutPopup: boolean = false;

  constructor(
    //public navCtrl: NavController,
    public router: Router,
    //public faio: FingerprintAIO,
    private authService: AuthenticationService,
    public alertservice: AlertServicesProvider,
    public toastProvider: ToastServicesProvider,
    public http: clsHttpService,
    //private pouchcouch: PouchCouchServicesProvider,
    //private loadingCtrl: LoaderServicesProvider,
    public splashScreen: SplashScreen,
    public platform: Platform,
    private localstorageservice: clsLocalStorageService,
    public modalCtrl: ModalController,
    private loadingobj: LoadingController,
    private translate: TranslateService,
    private menuCtrl: MenuController,
    private paramService: NavParamService
  ) { }
  ngOnInit() {
    try {
      this.menuCtrl.enable(false);//need to handle for guest mode.
      this.menuCtrl.swipeGesture(false); //disable swipe open menu feature.
      console.log('mpin page visit');
      try {
        /* To get MPIN details */
        console.log("Get MPIN details from localstorage.");
        this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            this.userId = objMPIN.userId;
            this.groupId = objMPIN.groupId;
            this.userName = objMPIN.userName;
            let name = this.userName.split(/\s/).reduce((resp, word) => resp += word.slice(0, 1), '')
            console.log("Inside Get MPIN details from LOGIN." + JSON.stringify(objMPIN));
            // if (name.length > 1)
            this.shortName = name.toUpperCase();
            this.invalidAttempt = objMPIN.mpinInvalidAttempt || 1;
            /* check finger print status in local storage */
            console.log("INFO ionVIewDidEnter0 " + JSON.stringify(objMPIN));
            if (objMPIN.Fingerprint == 'Y') {
              this.isFingerPrintEnabled = true;
              this.verifyFingerPrintAvalOnDevice();
            }
          }
          else {
            console.log("Inside Get MPIN details from LOGIN. data is undefined.");
          }
        }, error => {
          console.log("Error ionViewDidEnter_2" + error);
          //clsGlobal.logManager.writeErrorLog("MpinloginPage", "ionViewDidEnter_2", error.message);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
        });
      }
      catch (error) {
        //alert("Error in LocalstorageReading" + error.message);
        console.log("Error ionViewDidEnter_3 " + error.message);
        //clsGlobal.logManager.writeErrorLog("MpinloginPage", "ionViewDidEnter_3", error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'ionViewDidEnter2',error.Message,undefined,error.stack,undefined,undefined));
      }
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      this.mpinMaxInvalidAttempt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MPIN_MAX_INVALID_ATTEMPT)) || 5;
      this.getBrokerInfoData();
      this.getExchangeTimeData();
      this.getAboutUsData();
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "ngOnInit_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'ionViewDidEnter3',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  numberOnlyValidation(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("MpinloginPage", "", "VISIT", "");
  }
  ionViewWillEnter() {

  }
  ionViewDidEnter() {

    try {
      this.updateProfile();
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
    }
    catch (error) {
      //console.log("Error_ ionViewDidEnter_1 " + error.message);
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "ionViewDidEnter_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  updateProfile() {
    try{
    this.localstorageservice.getItem("PROFILE_PICTURE").then((res: any) => {
      if (res != undefined && res != null) {
        this.profilePic = res;
      }
    }).catch(err => {
      console.log("Error in getting profile from local storage")
    })
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'updateProfile',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  /**
   * Desc :To check finger print available on device
   * (result depends on device and os.
   * iPhone X will return 'face' other Android or iOS devices will return 'finger')
   */
  verifyFingerPrintAvalOnDevice() {
    try {
        this.isFingerAuthAvailable = false;
    } catch (error) {
      console.log("Error verifyFingerPrintAvalOnDevice2" + error.message);
      // alert("Error 1" + error.message);
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "verifyFingerPrintAvalOnDevice_2", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'verifyFingerPrintAvalOnDevice2',error.Message,undefined,error.stack,undefined,undefined));
      this.isFingerAuthAvailable = false;
    }
  }
  /**
   * Desc : If fingerprint available then do login process.
   */
  showFingerAunthenticate() {
    // try {
    //   this.faio.isAvailable().then((result: any) => {
    //     this.faio.show({
    //       // clientId: 'Login to Wave',
    //       // clientSecret: 'password', //Only necessary for Android
    //       // disableBackup: true, //Only for Android(optional)
    //       // localizedFallbackTitle: 'Unable to authenticate using fingerprint.', //Only for iOS
    //       // localizedReason: 'Touch on finger on sensor to login.' //Only for iOS 
    //       title: 'Login to Wave',
    //       //subtitle: 'password',
    //       disableBackup: true,
    //       fallbackButtonTitle: 'Unable to authenticate using fingerprint.',
    //       description: 'Touch on finger on sensor to login.'
    //     }).then((result: any) => {
    //       //this.toastProvider.showAtBottom("Fingerprint recognized.");
    //       this.setProductCode();
    //       let forceLogin = false;
    //       //this.loadingCtrl.showLoader();
    //       let reqLogin = {
    //         "user_id": this.userId,
    //         "password": clsPluginConstants.DeviceUDID,
    //         "login_type": "FINGERPRINT",
    //         "second_auth": "",
    //         "UDID": clsPluginConstants.DeviceUDID,
    //         "api_key": clsGlobal.apiKey,
    //         "source": "WEBAPI"
    //       };
    //       console.log("SENDING FINGERPRINT LOGIN" + reqLogin);
    //       this.isVerified = true;
    //       this.authService.login(reqLogin);
    //     }).catch((error: any) => {
    //       this.isVerified = false;
    //      // console.log("Error", "MPIN_showFingerAunthenticate_2 " + JSON.stringify(error));
    //       //alert("Inside finger print show ."+error);
    //       //clsGlobal.logManager.writeErrorLog("MpinloginPage", "showFingerAunthenticate_2", JSON.stringify(error));
    //       //console.log("showFingerAunthenticate_2"+ error.message);
    //       //this.toastProvider.showWithButton("Fingerprint recognized."+error);//cancel
    //       clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'showFingerAunthenticate',error.Message,undefined,error.stack,undefined,undefined));
    //     });
    //   }).catch((error: any) => {
    //     //alert("Inside finger print available ."+error);
    //     //this.toastProvider.showAtBottom("Fingerprint authentication not available");
    //     this.isFingerAuthAvailable = false;
    //     //console.log("showFingerAunthenticate_3"+ error.message);
    //     // console.log("Error MPIN_showFingerAunthenticate_3" + error);
    //     // clsGlobal.logManager.writeErrorLog("MpinloginPage", "showFingerAunthenticate_3", error.message);
    //     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'showFingerAunthenticate2',error.Message,undefined,error.stack,undefined,undefined));
    //   });
    // } catch (error) {
    //   //alert("Inside finger print show 2 ."+error);
    //   //console.log("Error MPIN_showFingerAunthenticate_4" + error.message);
    //   //clsGlobal.logManager.writeErrorLog('MpinloginPage', 'showFingerAunthenticate_4', error.message);
    //   clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'showFingerAunthenticate3',error.Message,undefined,error.stack,undefined,undefined));
    //   this.isFingerAuthAvailable = false;
    // }
  }
  /**
   * Desc : To set the Product mode depend on device.
   */
  setProductCode() {
    try {
      /** set product mode */
      if (clsGlobal.applicationType == clsGlobal.MOBILE) {
        this.productCode = clsConstants.C_V_PHOENIX_MOBILE;
      }
      else if (clsGlobal.applicationType = clsGlobal.TABLET) {
        this.productCode = clsConstants.C_V_PHOENIX_TABLET
      } else {
        this.productCode = clsConstants.C_V_PHOENIX_MOBILE;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "setProductCode_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'setProductCode',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  /**
   * Desc : In case of forgot mpin navigate to that page. 
   */
  forgotMPIN() {
    //this.navCtrl.push('ForgotMpinPage');
    //this.navCtrl.navigateRoot('/',)
    this.mpinError = "";
    this.router.navigate(['/' + clsConstants.C_S_ROUTE_FORGETMPIN]);
  }
  /**
   * Desc : 
   * @param $event 
   */
  enterFingerPrint($event) {
    try {
      $event.preventDefault(); // to avoid submitting form
      this.showFingerAunthenticate();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "enterFingerPrint_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'enterFingerPrint',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  /**
   * Desc : To get user entered mpin values and stored into mpinValue and send to validate mpin
   * @param pin : To get entered mpin value
   */
  handleInput(pin: string) {
    try {
      if (this.mpinError != '')
        this.mpinError = '';
      if (pin != "6") {
        let controlid = "mpinid" + (parseInt(pin) + 1);
        document.getElementById(controlid).getElementsByTagName('input')[0].focus();
      }
      if (this.mpin1 != '' &&
        this.mpin2 != '' &&
        this.mpin3 != '' &&
        this.mpin4 != '' &&
        this.mpin5 != '' &&
        this.mpin6 != ''
      ) {
        this.mpinValue += this.mpin1 + this.mpin2 + this.mpin3 + this.mpin4 + this.mpin5 + this.mpin6;
        this.isVerified = !this.isVerified;
        this.validateMPIN();
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "enterFingerPrint_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'handleInput',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  isKeyBoardOpen() {
    return clsGlobal.isKeyBoardOpen;
  }
  /**
   * Desc : To validate the entered mpin with stored mpin.
   */
  validateMPIN() {
    try {
      if (this.mpinValue.length === 6) {
        if (this.invalidAttempt >= this.mpinMaxInvalidAttempt) {
          this.alertservice.showAlert('You have exceeded maximum invalid attempt.', "MPIN Login");
          this.clearFields();
          this.forgotMPIN();
          return;
        }
        this.setProductCode();
        //this.loadingCtrl.showLoader();
        let MPIN = this.mpinValue;
        let reqLogin =
        {
          "user_id": this.userId,
          "password": MPIN.trim(),
          "login_type": "MPIN",
          "second_auth": "",
          "UDID": clsPluginConstants.DeviceUDID,
          "api_key": clsGlobal.apiKey,
          "source": "WEBAPI"
        }
        //alert(JSON.stringify(reqLogin));
        this.isVerified = true;
        this.authService.loginWithMPIN(reqLogin)
          .then(response => {
            console.log("Login success" + JSON.stringify(response));
          }).catch(error => {
            //this.loadingCtrl.hideLoader();
            this.isVerified = false;
            this.clearFields();
            //this.mpinError = error;
            console.log("Error Mpin " + error);
            //let InvalidAtteptRemaining = this.mpinMaxInvalidAttempt - this.invalidAttempt;
            //console.log("Invalid MPIN attempt"+" "+"{"+this.noOfAttempt+"}"+ " " +"out of" +"{"+this.mpinMaxInvalidAttempt+"}"+". Please provide valid MPIN to process your login.");
            //added by Vivian F to Handle navigation at UI end , based on error code <start>
            if (!error || !error.errorCode) {
              this.mpinError = error || "Oops something went wrong, Kindly check internet connection.";
            }
            else {
              if (error.errorCode.trim() == clsConstants.ECODE_MPIN_EXPIRED_RESET_MPIN/*"Your MPIN has expired, Kindly use reset MPIN.".toUpperCase().trim()*/) {
                this.toastProvider.showAtBottom("Your MPIN has expired");
                this.mpinError = "";// to remove message since route to change MPIN page.
                this.router.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_CHANGEMPIN]);
              }
              //Incorrect MPIN. You have only one attempt remaining. Please enter the valid MPIN or your account will be locked.
              //"Invalid MPIN attempt"+" "+"{"+this.invalidAttempt+"}"+" "+"out of"+" "+"{"+this.mpinMaxInvalidAttempt+"}"+". Please provide valid MPIN to process your login."
              //added by Vivian F to Handle navigation at UI end , based on error code
              else if (error.errorCode.trim() == clsConstants.ECODE_INVALID_MPIN /*startsWith("Invalid MPIN") || error.startsWith('Incorrect MPIN')*/) {
                this.mpinError = error.message;
              }
              //added by Vivian F to Handle navigation at UI end , based on error code
              else if (error.errorCode.trim() == clsConstants.ECODE_MPIN_LOCKED_RESET_MPIN /*"You have exceeded maximum invalid attempt.MPIN is Locked, Kindly use Reset MPIN.".toUpperCase().trim()*/) {
                this.mpinError = "No more attempts left. Try resetting your M-PIN to unlock and access you account!";
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_UNSUCESSFUL_MPIN_FINGERPRINT_LOGIN) { //added by Vivian F to Handle navigation at UI end , based on error code
                this.paramService.myParam = "mpinlogin";
                setTimeout(() => {
                  this.router.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_CHANGEPASSWORD]);
                }, 1500)
              }
              //added by Vivian F to Handle navigation at UI end , based on error code
              else if (error.errorCode.trim() == clsConstants.ECODE_FINGERPRINT_AUTHORIZATION_FAILURE /*'Finger print authorization not available for this Device.Kindly login using UserId/Password or MPIN.'.toUpperCase().trim()*/) {
                this.mpinError = error.message;
              }
              else if (error.errorCode.trim() == clsConstants.ECODE_PWD_EXPIRED) //added by Vivian F to Handle navigation at UI end , based on error code
              {
                this.toastProvider.showAtBottom("Your Password has expired.");
                this.mpinError = "";// to remove message since route to change MPIN page.
                //this.router.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_SIGNIN]);
                //if password is expired then navigate to Change password.
                this.router.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_CHANGEPASSWORD]);
              }
              //added by Vivian F to Handle navigation at UI end , based on error code
              else if (error.errorCode.trim() == clsConstants.ECODE_RESPONSE_FAILURE /*startsWith("Failed to return value from stp user" ||
              error.startsWith("Failed to verify credentials(MPIN)")*/
              ) {
                this.mpinError = "Oops something went wrong, Kindly contact administrator.";
              }
              else {
                this.mpinError = error.message;
              }
            }
            // else
            // {
            //   this.mpinError=error;
            // }
            //<end>
          });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "validateMPIN_3", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'validateMPIN',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  /**
    * Desc : After succesful login to clear the set mpin value.
    */
  clearFields() {
    try {
      this.mpinValue = '';
      this.mpin1 = '';
      this.mpin2 = '';
      this.mpin3 = '';
      this.mpin4 = '';
      this.mpin5 = '';
      this.mpin6 = '';
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "clearFields_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'clearFields',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  //encryptMPINCheck: string;
  hideShowMPIN() {
    try {
      this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
      this.passwordIcon = this.passwordIcon === 'eye-off-icon' ? 'eye-icon' : 'eye-off-icon';
      this.showMPIN = this.passwordType == 'text' ? true : false;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "hideShowMPIN_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'hideShowMPIN',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  goToHome() {
    //this.navCtrl.setRoot(HomePage);
    //this.navCtrl.navigateRoot('/',);
    this.router.navigate(['/' + clsConstants.C_S_PAGE_ROUTE_HOME]);//
  }

  showLoader(dismissonPageChange?: boolean) {
    try {
      if (!this.loadingElement) {
        this.loadingElement = this.loadingobj.create({
          spinner: "lines",
          cssClass: "main-loader",//TODO
          backdropDismiss: false,
          showBackdrop: true,
          duration: this.durationTime //default 20 sec Number of milliseconds to wait before dismissing the loading indicator.
        });
        this.loadingElement.present();
      } else {
        this.loadingElement = undefined;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "showLoader_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'showLoader',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  hideLoader() {
    try {
      if (this.loadingElement != undefined) {
        this.loadingElement.dismiss().then(() => {
          this.loadingElement = undefined;
        });
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog("MpinloginPage", "hideLoader_1", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'hideLoader',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  /**
   * Get Member Ship Details Data Server
   */
  getBrokerInfoData() {
    this.showBrokerInfoDataLoader = true;
    try {
     // const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + clsGlobal.versionId + '/' + clsConstants.C_S_BROKER_INFO_FILE;
     const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH)  + clsGlobal.LocalComId + clsGlobal.versionId + '/' + clsConstants.C_S_BROKER_INFO_FILE;
    this.http.getStaticFile(url).subscribe((respData: any) => {
        this.showBrokerInfoDataLoader = false;
        this.brokerInfoData = JSON.parse(respData);
      }, error => {
        this.showBrokerInfoDataLoader = false;
        console.log("Error getBrokerInfoData_1" + error);
        //clsGlobal.logManager.writeErrorLog('MpinloginPage', 'getBrokerInfoData_1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getBrokerInfoData',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      this.showBrokerInfoDataLoader = false;
      console.log("Error getBrokerInfoData_2" + error);
      //clsGlobal.logManager.writeErrorLog('MpinloginPage', 'getBrokerInfoData_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getBrokerInfoData2',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  onPinCodeComplete(event: any) {
    try{
    this.mpinError = '';
    this.mpinValue = event;
    if (this.mpinValue.length == 6) {
      this.isVerified = !this.isVerified;
      this.validateMPIN();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'onPinCodeComplete',error.Message,undefined,error.stack,undefined,undefined));
  }
  }

  showMarketTimings() {
    this.showExchangeTiming = !this.showExchangeTiming;
  }

  closeMarketTimings() {
    this.showExchangeTiming = !this.showExchangeTiming;
  }

  getExchangeTimeData() {
    try {
      //this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_EXCHANGE_TIME_FILE).subscribe((respData: any) => {
        this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) +  clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_EXCHANGE_TIME_FILE).subscribe((respData: any) => {
        let data = JSON.parse(respData);
        for (let i = 0; i < data.length; i++) {
          this.exchangeTimeData.push({
            exchange: data[i].ExchnageName,
            marketOpen: this.getTimeFormat(data[i].Open),
            marketClose: this.getTimeFormat(data[i].Close),
            amoOpen: this.getTimeFormat(data[i].AmoOpen),
            amoClose: this.getTimeFormat(data[i].AmoClose)
          });
        }
        console.log(this.exchangeTimeData);
      }, error => {
        console.log(error);
        //clsGlobal.logManager.writeErrorLog('SignInPage', 'c', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getExchangeTimeData',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      console.log(error);
      //clsGlobal.logManager.writeErrorLog('SignInPage', 'getExchangeTimeData_2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getExchangeTimeData2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getAboutUsData() {
    try {
      //this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_ABOUTUS_FILE).subscribe((respData: any) => {
      this.http.getStaticFile(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.LocalComId + 'v1/' + clsConstants.C_S_ABOUTUS_FILE).subscribe((respData: any) => {
      //let data = JSON.parse(respData);
        this.aboutUsData = respData;
      }, error => {

        //this.toastCtrl.showAtBottom("Unable to show about us!");
        //clsGlobal.logManager.writeErrorLog('AboutUsPage', 'getAboutUsData_1', error.message);
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getAboutUsData',error.Message,undefined,error.stack,undefined,undefined));
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('AboutUsPage', 'getAboutUsData_2', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getAboutUsData2',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  /**
   * @description : Convert time into PM and AM format .
  */
  getTimeFormat(time: any) {
    try{
    let retTime = '';
    let hour = time.split(":")[0];
    if (hour > 12) {
      retTime = time.substring(0, 5) + ' PM';
    } else if (hour == '00') {
      retTime = '12:00' + ' AM';
    } else {
      retTime = time.substring(0, 5) + ' AM';
    }
    return retTime;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MpinloginPage', 'getTimeFormat',error.Message,undefined,error.stack,undefined,undefined));
  }
  }
  showAboutUs() {
    this.showAboutPopup = !this.showAboutPopup;
  }
}
