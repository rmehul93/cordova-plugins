import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MpinloginPage } from './mpinlogin.page';

const routes: Routes = [
  {
    path: '',
    component: MpinloginPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MpinloginPageRoutingModule {}
