import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TransactionPageRoutingModule } from './transaction-routing.module';

import { TransactionPage } from './transaction.page';
import { ComponentsModule } from 'src/app/components/components.module';
import { DirectiveSharedModule } from '../../directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TransactionPageRoutingModule,
    ComponentsModule,
    DirectiveSharedModule
  ],
  declarations: [TransactionPage]
})
export class TransactionPageModule {}
