import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll, MenuController, NavController } from '@ionic/angular';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { CupertinoPane, CupertinoSettings } from 'cupertino-pane';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { SocketIoServiceService } from 'src/app/providers/socket-io-service.service';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.page.html',
})
export class TransactionPage implements OnInit {

  @ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;

  mode: string = 'open';
  selectedOrderType: any;
  ordersType: any = [
    { orderTypeCode: 1, orderTypeDesp: "Single Scrip Orders" },
    { orderTypeCode: 2, orderTypeDesp: "Spread Orders" },
    { orderTypeCode: 3, orderTypeDesp: "Multileg Orders" },
    { orderTypeCode: 4, orderTypeDesp: "Good Till Date" }];
  showOrderTypePopup: boolean = false;

  multilegArray: any = ['leg_no_1', 'leg_no_2', 'leg_no_3'];
  selectedMultilegOrderLeg: any = 'leg_no_1';
  showMultilegSelection: boolean = false;

  pageSize: any = 20;

  lastPageForOpenOrder: boolean = false;
  lastPageForCompletedOrder: boolean = false;
  lastPageForAllOrder: boolean = false;
  openOrdersPageCount = 0;
  completedOrdersPageCount = 0;
  allOrdersPageCount = 0;

  lastPageForOpenOrderSpread: boolean = false;
  lastPageForCompletedOrderSpread: boolean = false;
  lastPageForAllOrderSpread: boolean = false;
  openOrdersPageCountSpread = 0;
  completedOrdersPageCountSpread = 0;
  allOrdersPageCountSpread = 0;

  lastPageForOpenOrderMultileg: boolean = false;
  lastPageForCompletedOrderMultileg: boolean = false;
  lastPageForAllOrderMultileg: boolean = false;
  openOrdersPageCountMultileg = 0;
  completedOrdersPageCountMultileg = 0;
  allOrdersPageCountMultileg = 0;

  lastPageForOpenOrderGTD: boolean = false;
  lastPageForCompletedOrderGTD: boolean = false;
  lastPageForAllOrderGTD: boolean = false;
  openOrdersPageCountGTD = 0;
  completedOrdersPageCountGTD = 0;
  allOrdersPageCountGTD = 0;

  filterOrderBookData: any = [];

  orderbookData: any = [];
  bracketOrderData: any = [];
  orderbookDataSpread: any = [];
  orderbookDataMultileg: any = [];
  orderbookDataGTD: any = [];

  showOrderDetailsPopup: boolean = false;
  showAddiionalOrderDetails: boolean = false;

  showMultilegOrderDetailsPopup: boolean = false;
  showAddiionalMultilegOrderDetails: boolean = false;

  showFilterPopup: boolean = false;
  isFilterApply: boolean = false;
  minOrderPriceFilter: number = 0;
  maxOrderPriceFilter: number = 0;
  pricePrecision: any = 2;
  showSearch: boolean = false;
  ordersLoading: boolean = true;
  showCancelOrderPopup: boolean = false;
  showExitOrderPopup: boolean = false;
  selectedOrder: any;
  orderScripKeys: any = [];

  bcastHandler: any;
  zeroVal: number = 0;
  numberortell = "tel";
  ordersFilterObject: any = {}


  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = "";
  orderSearchData: any = [];
  orderSearchScripKeys: any = [];
  showtickerCard: boolean = false;
  allExchangeListOrders: any = [];
  productTypesByExchange: any = [];
  selProductType: any = "";

  showPositionDetails: boolean = false;
  selectedNetPosition: any;
  allExchangeList: any = [];


  @ViewChild('divOrderDetails', { static: false }) divOrderDetails: ElementRef;
  showExpandedOrderDetails: boolean = false;
  orderDetailsPane: any;


  @ViewChild('divOrderFilter', { static: false }) divOrderFilter: ElementRef;
  showExpandedOrderFilter: boolean = false;
  orderFilterPane: any;

  @ViewChild('divMultilegOrderDetails', { static: false }) divMultilegOrderDetails: ElementRef;
  showExpandedMultilegOrderDetails: boolean = false;
  multilegOrderDetailsPane: any;

  allProductType: any = [];

  refresherInstance: any;
  scrollInstance: any;

  orderSubscription: any;

  isCancelOrderClick: boolean = false;
  isExitOrderClick: boolean = false;
  bracketOrderPositionConversion: boolean = false;
  isPositionConversionClickBracketOrder: boolean = false;
  isPositionConversionClick: boolean = false;
  isPositionConversionQtyEdit: boolean = false;
  selectedQtyforPositionConversion: number = 0;

  showConfirmDialog: boolean = false;
  confirmDialogDataObj: any = {};

  showNetPostion: boolean = false;
  netPositionDataDaily: any = [];
  netPositionDailyScripKeys: any = [];
  netPositionDataExpiry: any = [];
  netPositionExpiryScripKeys: any = [];
  netpositionSelection: any = "daily";
  netPositionDataTempNonIntropExpiry: any = [];
  netPositionDataTempNonIntropDaily: any = [];
  netPositionDataTempIntropExpiry: any = [];
  netPositionDataTempIntropDaily: any = [];

  segmentList: any = [];
  selectedSegment: any;
  sumMTMDaily: any = 0.00;
  mtmDataTrendDaily: string = '';

  sumMTMExpiry: any = 0.00;
  mtmDataTrendExpiry: string = '';
  showPositionConversition: boolean = false;
  allProductTypePosition: any = [];
  @ViewChild('divNetposition', { static: false }) divNetposition: ElementRef;
  showExpandedNetposition: boolean = false;
  netPositionPane: any;

  sortFilterPopupPosition: boolean = false;
  positionFilterObject: any = {};
  isPositionFilterApply = false;
  filterNetpositionDataDaily: any = [];
  netPositionScripKeysDaily: any = [];

  filterNetpositionDataExpiry: any = [];
  netPositionScripKeysExpiry: any = [];

  netpositionDailyLoading = true;
  netpositionExpiryLoading = true;

  minDaysPandLPosition: any = 0;
  maxDaysPandLPosition: any = 0;
  showExpandedPositionFilter: boolean = false;
  positionFilterPane: any;
  @ViewChild('divPositionFilter', { static: false }) divPositionFilter: ElementRef;

  isScripFetchForModify: boolean = false;
  isScripFetchForSquareOff: boolean = false;
  interopOnOffFlag: boolean = false;
  spreadDetails: any = [];

  showSpreadCancelOrderPopup : boolean = false;
  isSpreadCancelOrderClick : boolean = false;

  constructor(public menuCtrl: MenuController,
    private navCtrl: NavController,
    private paramService: NavParamService,
    private transactionService: TransactionService,
    private toastServicesProvider: ToastServicesProvider,
    private objSocketService: SocketIoServiceService,
    public http: clsHttpService,
    public alertCtrl: AlertServicesProvider,) {

  }



  ngOnInit() {
      try{
    this.menuCtrl.enable(true);
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
    let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
    let pageNo = this.mode == 'open' ? ++this.openOrdersPageCount : this.mode == 'completed' ? ++this.completedOrdersPageCount : this.mode == 'all' ? ++this.allOrdersPageCount : ++this.allOrdersPageCount;
    if (this.paramService.myParam && this.paramService.myParam.mode) {
      if (this.paramService.myParam.reqBody.type == 'SPREAD') {
        this.selectedOrderType = { orderTypeCode: 2, orderTypeDesp: "Spread Orders" };
      }
      else if (this.paramService.myParam.reqBody.type == '2L' || this.paramService.myParam.reqBody.type == '3L') {
        this.selectedOrderType = { orderTypeCode: 3, orderTypeDesp: "Multileg Orders" };
      }
      else if (this.paramService.myParam.reqBody.validity == 'GTD') {
        this.selectedOrderType = { orderTypeCode: 4, orderTypeDesp: "Good Till Date" };
      }
      else {
        this.selectedOrderType = { orderTypeCode: 1, orderTypeDesp: "Single Scrip Orders" };
      }
      this.mode = this.paramService.myParam.mode;
      delete this.paramService.myParam.mode;
      this.paramService.myParam = undefined;
    }
    else {
      this.selectedOrderType = { orderTypeCode: 1, orderTypeDesp: "Single Scrip Orders" };
    }
    this.getOrderBookData(pageNo, this.pageSize, orderstatus);
    this.getNetPositionData();
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'ngOnInit', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("TransactionPage", "", "VISIT", "");
  }

  ionViewWillEnter() {
    try{
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    this.orderSubscription = this.objSocketService.getOrders().subscribe((data) => this.getOrderMeessage(data));
    this.createBroadcastforNetpositionDaily();
    this.createBroadcastforNetpositionExpiry();
    this.creatBroadCastData()
    }catch(error){
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'ionViewWillEnter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.orderScripKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionDailyScripKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionExpiryScripKeys);
      this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
    } catch (error) {
      //console.log(err)
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'ionViewWillLeave', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  onOrderTypeChange(selectedOrderType) {
    try{
    this.closeOrderType();
    if (this.selectedOrderType.orderTypeCode == selectedOrderType.orderTypeCode) {
      return;
    }
    let isNewPageAvalible = true;
    this.filterOrderBookData = [];
    this.selectedOrderType = selectedOrderType;
    switch (this.selectedOrderType.orderTypeCode) {

      case 1:
        if (this.mode == 'open' && this.lastPageForOpenOrder) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrder) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrder) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCount : this.mode == 'completed' ? ++this.completedOrdersPageCount : this.mode == 'all' ? ++this.allOrdersPageCount : ++this.allOrdersPageCount;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.createOrderBookData();
          this.creatBroadCastData();
        }
        break;
      case 2:

        if (this.mode == 'open' && this.lastPageForOpenOrderSpread) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderSpread) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderSpread) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountSpread : this.mode == 'completed' ? ++this.completedOrdersPageCountSpread : this.mode == 'all' ? ++this.allOrdersPageCountSpread : ++this.allOrdersPageCountSpread;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.createOrderBookData();
          this.creatBroadCastData();
        }
        break;
      case 3:
        if (this.mode == 'open' && this.lastPageForOpenOrderMultileg) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderMultileg) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderMultileg) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountMultileg : this.mode == 'completed' ? ++this.completedOrdersPageCountMultileg : this.mode == 'all' ? ++this.allOrdersPageCountMultileg : ++this.allOrdersPageCountMultileg;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.createOrderBookData();
          this.creatBroadCastData();
        }
        break;
      case 4:

        if (this.mode == 'open' && this.lastPageForOpenOrderGTD) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderGTD) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderGTD) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountGTD : this.mode == 'completed' ? ++this.completedOrdersPageCountGTD : this.mode == 'all' ? ++this.allOrdersPageCountGTD : ++this.allOrdersPageCountGTD;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.createOrderBookData();
          this.creatBroadCastData();
        }
        break;

    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'onOrderTypeChange', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  async getOrderBookData(pageNo, pageeSize, orderStatus) {
    try{
    this.filterOrderBookData = [];
    if (pageNo == 1) {
      this.ordersLoading = true;
    }
    if (this.selectedOrderType.orderTypeCode == 1) {
      await this.transactionService.getOrderBook(pageNo, pageeSize, orderStatus).then((orderbookResponse: any) => {
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }

        if (orderbookResponse.status == 'success') {

          if (orderbookResponse.data.length > 0) {
            let newOrderbookData = orderbookResponse.data;
            let newBracketOrders = newOrderbookData.filter(newOrder => newOrder.bracket_details.parent_order_id != '');
            newOrderbookData = newOrderbookData.filter(newOrder => !newBracketOrders.filter(braacketorder => braacketorder.bracket_details.parent_order_id === newOrder.bracket_details.parent_order_id).length);
            if (this.orderbookData.length > 0 && newOrderbookData.length > 0) {
              newOrderbookData = newOrderbookData.filter(newOrder => !this.orderbookData.filter(oldOrder => oldOrder.order_id === newOrder.order_id).length);
            }

            if (this.bracketOrderData.length > 0 && newBracketOrders.length > 0) {
              newBracketOrders = newBracketOrders.filter(newBracketOrder => !this.bracketOrderData.filter(oldBracketOrder => oldBracketOrder.order_id === newBracketOrder.order_id).length);
            }
            let bracketOrderIdsCompletedOrders = newBracketOrders.length == 0 ? [] : newBracketOrders.filter((element) => { return element.traded_quantity > 0 }).map((element) => { return element.order_id });

            this.getTradesFromOrders('', bracketOrderIdsCompletedOrders).then((bracketOrderTrades: any) => {
              newBracketOrders.forEach(element => {
                if (element.status == "PENDING" && element.traded_quantity > 0) {
                  element.status = "PARTIALLYCOMPLETED";
                }
                element.orderDateTime = clsCommonMethods.getOrderDateTime(element.order_timestamp);
                element.exchangeDateTime = element.exchange_timestamp ? clsCommonMethods.getOrderDateTime(element.exchange_timestamp) : clsCommonMethods.getOrderDateTime(element.order_timestamp);
                element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);

                element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
                element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

                if (element.status == "PARTIALLYCOMPLETED" || element.status == "EXECUTED" || element.traded_quantity > 0) {
                  if (bracketOrderTrades.length > 0) {
                    element.trades = bracketOrderTrades.filter(bracketOrderTrade => bracketOrderTrade.order_id == element.order_id);
                  }
                } else {
                  element.trades = [];
                }
              });

              let newOrdersIdsCompletedOrders = newOrderbookData.length == 0 ? [] : newOrderbookData.filter((element) => { return element.traded_quantity > 0 }).map((element) => { return element.order_id });
              this.getTradesFromOrders('', newOrdersIdsCompletedOrders).then((newOrderTrades: any) => {
                newOrderbookData.forEach(element => {
                  if (element.status == "PENDING" && element.traded_quantity > 0 && element.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                    element.status = "PARTIALLYCOMPLETED";
                  }
                  element.orderDateTime = clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.exchangeDateTime = element.exchange_timestamp ? clsCommonMethods.getOrderDateTime(element.exchange_timestamp) : clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
                  element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
                  element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);
                  element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                  let allProductType = clsGlobal.ExchManager.populateProductTypes(element.displayExchange, element.mktSegId, false);
                  if (allProductType && allProductType.length > 0) {
                    element.displayProductType = allProductType.filter(product_element => {
                      if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                        return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                      } else {
                        return (product_element == element.product_type);
                      }

                    })[0];
                  } else {
                    element.displayProductType = element.product_type
                  }

                  if (element.status == "PARTIALLYCOMPLETED" || element.status == "EXECUTED" || element.traded_quantity > 0) {
                    if (newOrderTrades.length > 0) {
                      element.trades = newOrderTrades.filter(bracketOrderTrade => bracketOrderTrade.order_id == element.order_id);
                    }
                  } else {
                    element.trades = [];
                  }

                });

                this.orderbookData = this.orderbookData.concat(newOrderbookData);
                this.bracketOrderData = this.bracketOrderData.concat(newBracketOrders);
                this.allExchangeListOrders = [...new Set(this.orderbookData.map(element => element.displayExchange))];
                this.allProductType = [...new Set(this.orderbookData.map(element => element.displayProductType))];
                this.bracketOrderData.forEach(bracketOrder => {
                  this.orderbookData.forEach(order => {
                    if (order.order_id == bracketOrder.bracket_details.parent_order_id) {
                      order[bracketOrder.bracket_details.leg_indicator] = bracketOrder;
                    }
                  });
                });

                if (orderStatus == -1) {
                  if (newOrderbookData.length < this.pageSize) {
                    this.lastPageForAllOrder = true;
                  }
                } else if (orderStatus == 1) {
                  if (newOrderbookData.length < this.pageSize) {
                    this.lastPageForOpenOrder = true;
                  }
                } else if (orderStatus == 2) {
                  if (newOrderbookData.length <
                    this.pageSize) {
                    this.lastPageForCompletedOrder = true;
                  }
                }
                this.clearFilter()
                this.createOrderBookData();
                this.creatBroadCastData();
              }).catch(err => { });
            }).catch(err => { })
          } else {
            this.createOrderBookData();
            this.creatBroadCastData();
          }
        } else {
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
          if (this.scrollInstance != undefined) {
            this.scrollInstance.target.complete();
          }
          this.orderbookData = [];
          // this.filterOrderBookData = [];
        }
      }, error => {
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }
        // this.orderbookData = [];
        //this.filterOrderBookData = [];
      });
    }
    else if (this.selectedOrderType.orderTypeCode == 2 || this.selectedOrderType.orderTypeCode == 3) {
      let orderType = this.selectedOrderType.orderTypeCode == 2 ? 'spread' : this.selectedOrderType.orderTypeCode == 3 ? 'multileg' : 'multileg';
      await this.transactionService.getMultilegOrderBook(pageNo, pageeSize, orderType, orderStatus).then((orderbookResponse: any) => {
        console.log(orderbookResponse);
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }
        if (orderbookResponse.status == 'success') {

          if (orderbookResponse.data.length > 0) {

            if (this.selectedOrderType.orderTypeCode == 2) {
              let newOrderbookDataSpread = orderbookResponse.data;
              if (this.orderbookDataSpread.length > 0 && newOrderbookDataSpread.length > 0) {
                newOrderbookDataSpread = newOrderbookDataSpread.filter(newOrder => !this.orderbookDataSpread.filter(oldOrder => oldOrder.client_order_no === newOrder.client_order_no).length);
              }

              let spredOrderIdsCompletedOrders = newOrderbookDataSpread.length == 0 ? [] : newOrderbookDataSpread.filter((element) => { return element.status == 'EXECUTED' }).map((element) => { return element.order_id });

              this.getTradesFromOrders('', spredOrderIdsCompletedOrders).then((newSpredOrderTrades: any) => {

                newOrderbookDataSpread.forEach(element => {
                  element.symbol = element.leg_no_1.symbol;
                  element.orderDateTime = clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.exchangeDateTime = element.exchange_timestamp ? clsCommonMethods.getOrderDateTime(element.exchange_timestamp) : clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
                  element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
                  element.displayScripDesc = this.formatScripDescSpreadOrder(element);
                  element.leg_no_1.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_1.expiry_date, element.leg_no_1.instrument, element.leg_no_1.option_type, element.leg_no_1.strike_price);
                  element.leg_no_2.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_2.expiry_date, element.leg_no_2.instrument, element.leg_no_2.option_type, element.leg_no_2.strike_price);

                  element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                  let allProductType = clsGlobal.ExchManager.populateProductTypes(element.displayExchange, element.mktSegId, false);
                  if (allProductType && allProductType.length > 0) {
                    element.displayProductType = allProductType.filter(product_element => {
                      if (element.leg_no_1.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                        return (product_element == element.leg_no_1.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                      } else {
                        return (product_element == element.leg_no_1.product_type);
                      }

                    })[0];
                  } else {
                    element.displayProductType = element.leg_no_1.product_type
                  }
                  if (element.status == "EXECUTED") {

                    if (newSpredOrderTrades.length > 0) {
                      element.trades = newSpredOrderTrades.filter(newSpredOrderTrade => newSpredOrderTrade.order_id == element.order_id);
                    }else{
                      element.trades = [];  
                    }
                  } else {
                    element.trades = [];
                  }

                });
                this.orderbookDataSpread = this.orderbookDataSpread.concat(newOrderbookDataSpread);
                this.allExchangeListOrders = [...new Set(this.orderbookDataSpread.map(element => element.displayExchange))];
                this.allProductType = [...new Set(this.orderbookDataSpread.map(element => element.displayProductType))];
                if (orderStatus == -1) {
                  if (newOrderbookDataSpread.length < this.pageSize) {
                    this.lastPageForAllOrderSpread = true;
                  }
                } else if (orderStatus == 1) {
                  if (newOrderbookDataSpread.length < this.pageSize) {
                    this.lastPageForOpenOrderSpread = true;
                  }
                } else if (orderStatus == 2) {
                  if (newOrderbookDataSpread.length < this.pageSize) {
                    this.lastPageForCompletedOrderSpread = true;
                  }
                }
                this.clearFilter()
                this.createOrderBookData();
                this.creatBroadCastData();
              }).catch(err => { });
            } else if (this.selectedOrderType.orderTypeCode == 3) {
              let newOrderbookDataMultileg = orderbookResponse.data;
              if (this.orderbookDataMultileg.length > 0 && newOrderbookDataMultileg.length > 0) {
                newOrderbookDataMultileg = newOrderbookDataMultileg.filter(newOrder => !this.orderbookDataMultileg.filter(oldOrder => oldOrder.order_id == newOrder.order_id).length);
              }

              let multilegOrderIdsCompletedOrders = newOrderbookDataMultileg.length == 0 ? [] : newOrderbookDataMultileg.filter((element) => { return element.status == 'EXECUTED' }).map((element) => { return element.order_id });

              this.getTradesFromOrders('', multilegOrderIdsCompletedOrders).then((newMultilegOrderTrades: any) => {
                newOrderbookDataMultileg.forEach(element => {
                  element.symbol = element.leg_no_1.symbol;
                  element.orderDateTime = clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.exchangeDateTime = element.exchange_timestamp ? clsCommonMethods.getOrderDateTime(element.exchange_timestamp) : clsCommonMethods.getOrderDateTime(element.order_timestamp);
                  element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
                  element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
                  element.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_1.expiry_date, element.leg_no_1.instrument, element.leg_no_1.option_type, element.leg_no_1.strike_price);
                  element.leg_no_1.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_1.expiry_date, element.leg_no_1.instrument, element.leg_no_1.option_type, element.leg_no_1.strike_price);
                  element.leg_no_2.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_2.expiry_date, element.leg_no_2.instrument, element.leg_no_2.option_type, element.leg_no_2.strike_price);

                  if (element.leg_indicator == '3L') {
                    element.leg_no_3.displayScripDesc = clsTradingMethods.formatScripDesc(element.leg_no_3.expiry_date, element.leg_no_3.instrument, element.leg_no_3.option_type, element.leg_no_3.strike_price);
                  }


                  element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                  let allProductType = clsGlobal.ExchManager.populateProductTypes(element.displayExchange, element.mktSegId, false);
                  if (allProductType && allProductType.length > 0) {
                    element.displayProductType = allProductType.filter(product_element => {
                      if (element.leg_no_1.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                        return (product_element == element.leg_no_1.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                      } else {
                        return (product_element == element.leg_no_1.product_type);
                      }

                    })[0];
                  } else {
                    element.displayProductType = element.leg_no_1.product_type
                  }

                  if (element.status == "EXECUTED") {
                    if (newMultilegOrderTrades.length > 0) {
                      newMultilegOrderTrades.forEach(tradebookElement => {

                        if (tradebookElement.order_id == element.order_id) {
                          if (element.leg_no_1.scrip_token == tradebookElement.scrip_token) {
                            if (element.leg_no_1.trades) {
                              element.leg_no_1.trades.push(tradebookElement);
                            } else {
                              element.leg_no_1.trades = []
                              element.leg_no_1.trades.push(tradebookElement);
                            }

                          }
                          if (element.leg_no_2.scrip_token == tradebookElement.scrip_token) {
                            if (element.leg_no_2.trades) {
                              element.leg_no_2.trades.push(tradebookElement);
                            } else {
                              element.leg_no_2.trades = []
                              element.leg_no_2.trades.push(tradebookElement);
                            }
                          }
                          if (element.leg_no_3.scrip_token == tradebookElement.scrip_token && element.leg_indicator == '3L') {
                            if (element.leg_no_3.trades) {
                              element.leg_no_3.trades.push(tradebookElement);
                            } else {
                              element.leg_no_3.trades = []
                              element.leg_no_3.trades.push(tradebookElement);
                            }
                          }
                        }

                      });
                    } else {
                      element.leg_no_1.trades = []
                      element.leg_no_2.trades = []
                      element.leg_no_3.trades = []
                    }

                  } else {
                    element.leg_no_1.trades = []
                    element.leg_no_2.trades = []
                    element.leg_no_3.trades = []
                  }

                });
                this.orderbookDataMultileg = this.orderbookDataMultileg.concat(newOrderbookDataMultileg);
                this.allExchangeListOrders = [...new Set(this.orderbookDataMultileg.map(element => element.displayExchange))];
                this.allProductType = [...new Set(this.orderbookDataMultileg.map(element => element.displayProductType))];
                if (orderStatus == -1) {
                  if (newOrderbookDataMultileg.length < this.pageSize) {
                    this.lastPageForAllOrderMultileg = true;
                  }
                } else if (orderStatus == 1) {
                  if (newOrderbookDataMultileg.length < this.pageSize) {
                    this.lastPageForOpenOrderMultileg = true;
                  }
                } else if (orderStatus == 2) {
                  if (newOrderbookDataMultileg.length < this.pageSize) {
                    this.lastPageForCompletedOrderMultileg = true;
                  }
                }
                this.clearFilter()
                this.createOrderBookData();
                this.creatBroadCastData();
              }).catch(err => { });


            }

          } else {
            this.createOrderBookData();
            this.creatBroadCastData();
          }
        } else {
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
          if (this.scrollInstance != undefined) {
            this.scrollInstance.target.complete();
          }
        }

      }, error => {
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }
      });
    }
    else if (this.selectedOrderType.orderTypeCode == 4) {
      await this.transactionService.getGTDOrderBook(pageNo, pageeSize, orderStatus).then((orderbookResponse: any) => {
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }
        if (orderbookResponse.status == 'success') {

          if (orderbookResponse.data.length > 0) {
            let newOrderbookDataGTD = orderbookResponse.data;
            if (this.orderbookDataGTD.length > 0 && newOrderbookDataGTD.length > 0) {
              newOrderbookDataGTD = newOrderbookDataGTD.filter(newOrder => !this.orderbookDataGTD.filter(oldOrder => oldOrder.order_id === newOrder.order_id).length);
            }

            if (newOrderbookDataGTD.length > 0) {
              newOrderbookDataGTD.forEach(element => {
                element.orderDateTime = clsCommonMethods.getOrderDateTime(element.order_timestamp);
                element.exchangeDateTime = element.exchange_timestamp ? clsCommonMethods.getOrderDateTime(element.exchange_timestamp) : clsCommonMethods.getOrderDateTime(element.order_timestamp);
                element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
                element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
                element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                element.displayProductType = element.product_type;
              });
              this.orderbookDataGTD = this.orderbookDataGTD.concat(newOrderbookDataGTD);
              this.allExchangeListOrders = [...new Set(this.orderbookDataGTD.map(element => element.displayExchange))];
              this.allProductType = [...new Set(this.orderbookDataGTD.map(element => element.displayProductType))];

            }

            if (orderStatus == -1) {
              if (newOrderbookDataGTD.length < this.pageSize) {
                this.lastPageForAllOrderGTD = true;
              }
            } else if (orderStatus == 1) {
              if (newOrderbookDataGTD.length < this.pageSize) {
                this.lastPageForOpenOrderGTD = true;
              }
            } else if (orderStatus == 2) {
              if (newOrderbookDataGTD.length < this.pageSize) {
                this.lastPageForCompletedOrderGTD = true;
              }
            }
            this.clearFilter()
            this.createOrderBookData();
            this.creatBroadCastData();

          } else {
            this.createOrderBookData();
            this.creatBroadCastData();
          }
        } else {
          if (this.refresherInstance != undefined) {
            this.refresherInstance.target.complete();
          }
          if (this.scrollInstance != undefined) {
            this.scrollInstance.target.complete();
          }
          this.orderbookData = [];
          // this.filterOrderBookData = [];
        }

      }, error => {
        this.ordersLoading = false;
        if (this.refresherInstance != undefined) {
          this.refresherInstance.target.complete();
        }
        if (this.scrollInstance != undefined) {
          this.scrollInstance.target.complete();
        }
      });
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getOrderBookData', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  async getNetPositionData() {
    try {

      if (!clsGlobal.User.interopSettingDetails) {
        await this.transactionService.getIntropConfiguration().then((intropConfigResponse: any) => {
          if (intropConfigResponse.status == 'success') {
            clsGlobal.User.interopSettingDetails = intropConfigResponse.data;
            for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
              if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1) {
                this.interopOnOffFlag = true;
              }
            }
          } else {

          }
        }, error => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getNetPositionData', error.Message, undefined, error.stack, undefined, undefined));
        });
      } else {
        for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
          if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1) {
            this.interopOnOffFlag = true;
          }
        }
      }

      await this.transactionService.getNetPositionDaily(0).then((netpositionResponse: any) => {
        this.netpositionDailyLoading = false;
        if (netpositionResponse.status == 'success') {
          this.netPositionDataTempNonIntropDaily = netpositionResponse.data;
          this.netPositionDataTempNonIntropDaily.forEach(element => {
            element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
            element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
            element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
            element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

            let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
            let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
            element.isCombined = isCombined;
            element.groupedSegment = customSegment;

            if (element.isCombined) {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            } else {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            }
          });
          this.netPositionDataDaily = this.netPositionDataTempNonIntropDaily;

        } else {
          this.netPositionDataDaily = [];
        }
      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getNetPositionData2', error.Message, undefined, error.stack, undefined, undefined));
        this.netpositionDailyLoading = false;
        this.netPositionDataDaily = [];
      });

      await this.transactionService.getNetPositionExpiry(0).then((netpositionResponse: any) => {
        this.netpositionExpiryLoading = false;
        if (netpositionResponse.status == 'success') {

          this.netPositionDataTempNonIntropExpiry = netpositionResponse.data;
          this.netPositionDataTempNonIntropExpiry.forEach(element => {
            element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
            element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
            element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
            element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

            let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
            let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
            element.isCombined = isCombined;
            element.groupedSegment = customSegment;
            if (element.isCombined) {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            } else {
              element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
              element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                  return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                } else {
                  return (product_element == element.product_type);
                }

              })[0];
            }
          });
          this.netPositionDataExpiry = this.netPositionDataTempNonIntropExpiry;
        } else {
          this.netPositionDataExpiry = [];
        }



      }, error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getNetPositionData3', error.Message, undefined, error.stack, undefined, undefined));
        this.netpositionExpiryLoading = false;
        this.netPositionDataExpiry = [];
      });


      if (this.interopOnOffFlag) {

        await this.transactionService.getNetPositionExpiry(1).then((netpositionResponse: any) => {
          this.netpositionExpiryLoading = false;
          if (netpositionResponse.status == 'success') {

            this.netPositionDataTempIntropExpiry = netpositionResponse.data;
            this.netPositionDataTempIntropExpiry.forEach(element => {
              element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
              element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
              element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
              element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

              let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
              let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
              element.isCombined = isCombined;
              element.groupedSegment = customSegment;
              if (element.isCombined) {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              } else {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              }
            });

            this.netPositionDataExpiry = this.netPositionDataTempIntropExpiry;

          } else {
            this.netPositionDataExpiry = [];
          }



        }, error => {
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getNetPositionData4', error.Message, undefined, error.stack, undefined, undefined));
          this.netpositionExpiryLoading = false;
          this.netPositionDataExpiry = [];
        });

        await this.transactionService.getNetPositionDaily(1).then((netpositionResponse: any) => {
          this.netpositionDailyLoading = false;
          if (netpositionResponse.status == 'success') {
            this.netPositionDataTempIntropDaily = netpositionResponse.data;
            this.netPositionDataTempIntropDaily.forEach(element => {
              element.mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.exchange);
              element.preferred_mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(element.preferred_exchange);
              element.displayExchange = clsTradingMethods.getExchangeName(clsTradingMethods.getMktSegFromApiExchangeName(element.exchange));
              element.displayScripDesc = clsTradingMethods.formatScripDesc(element.expiry_date, element.instrument, element.option_type, element.strike_price);

              let customSegment = clsTradingMethods.getGroupedSegement(element.displayExchange, element.instrument.trim());
              let isCombined = clsTradingMethods.checkIsCombined(element.mktSegId, customSegment);
              element.isCombined = isCombined;
              element.groupedSegment = customSegment;

              if (element.isCombined) {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.preferred_mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.preferred_exchange, element.preferred_mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              } else {
                element.qtyCaption = clsGlobal.ExchManager.getQtyLotCaption(element.mktSegId, element.market_lot, false);
                element.displayProductType = clsGlobal.ExchManager.populateProductTypes(element.exchange, element.mktSegId, false).filter(product_element => {
                  if (element.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
                    return (product_element == element.product_type || product_element == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT);

                  } else {
                    return (product_element == element.product_type);
                  }

                })[0];
              }
            });
            this.netPositionDataDaily = this.netPositionDataTempIntropDaily;

          } else {
            this.netPositionDataDaily = [];
          }
        }, error => {
          this.netpositionDailyLoading = false;
          this.netPositionDataDaily = [];
        });

      }


      this.allExchangeList = [...new Set(this.netPositionDataExpiry.map(element => element.displayExchange))];
      this.allProductTypePosition = [...new Set(this.netPositionDataExpiry.map(element => element.displayProductType))];
      this.segmentFilter();
      if (this.isPositionFilterApply) {
        this.clearPositionFilter();
      } else {
        await this.createNetpositionData();
        await this.createBroadcastforNetpositionDaily();
        await this.createBroadcastforNetpositionExpiry();
      }


    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getNetPositionData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getNetPositionData5', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  getTradesFromOrders(orderId, orderIdArray) {
    try{
    return new Promise((resolve, reject) => {
      if (orderId != '' || orderIdArray.length > 0) {
        this.transactionService.getTradeBookFromOrderId(orderId, orderIdArray).then((tradeBookResponse: any) => {
          if (tradeBookResponse.status) {
            resolve(tradeBookResponse.data);
          } else {
            resolve([]);
          }
        }, error => {
          resolve([]);
        })
      } else {
        resolve([]);
      }
    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getTradesFromOrders', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  segmentFilter() {
    try{
    if (this.interopOnOffFlag)
      this.segmentList.push('All', 'All Combined');
    else
      this.segmentList.push('All');

    for (let count = 0; count < this.netPositionDataExpiry.length; count++) {
      if (this.segmentList.indexOf(this.netPositionDataExpiry[count].groupedSegment) == -1) {
        this.segmentList.push(this.netPositionDataExpiry[count].groupedSegment);
        if (this.netPositionDataExpiry[count].groupedSegment == "Derv Combined") {
          this.segmentList.push("Equity FAO");
        }
        else
          if (this.netPositionDataExpiry[count].groupedSegment == "EQ Combined") {
            this.segmentList.push("Equity");
          }
          else
            if (this.netPositionDataExpiry[count].groupedSegment == "Currency Combined") {
              this.segmentList.push("Currency");
            }
      }
    }
    if (this.interopOnOffFlag) {
      this.selectedSegment = this.segmentList[1];

    }
    else {
      this.selectedSegment = this.segmentList[0];
    }
    //this.segmentfrontfilter = this.selectedSegment;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'segmentFilter', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  async onSegmentChange(segment) {
    try{
    this.selectedSegment = segment;

    if (this.selectedSegment == 'All Combined' || this.selectedSegment == 'Derv Combined' || this.selectedSegment == 'EQ Combined' || this.selectedSegment == 'Currency Combined') {
      this.removePositionFilter('exchangeType');
    }
    await this.createNetpositionData();
    await this.createBroadcastforNetpositionDaily();
    await this.createBroadcastforNetpositionExpiry();
    this.allExchangeList = [...new Set(this.netPositionDataExpiry.map(element => element.displayExchange))];
     }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getTradeonSegmentChangeBookFromOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  getTradeBookFromOrder(order) {
    try{
    this.showAddiionalOrderDetails = false;
    if (this.selectedOrderType.orderTypeCode == 1) {
      if (order.status == "EXECUTED" || order.status == "COMPLETED" || order.status == "PARTIALLYCOMPLETED" || (order.status == "CANCELLED" && order.traded_quantity > 0)) {
        this.selectedOrder = order;
        if (this.selectedOrder.trades && this.selectedOrder.trades.length > 0) {
          this.selectedOrder.trades.forEach(tradebookItem => {
            if (!tradebookItem.display_trade_timestamp) {
              tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
            }

          });
        }


        if (order.product_type == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && order.status == "EXECUTED") {

          if (order['Profit Leg'] && order['Profit Leg'].trades && order['Profit Leg'].trades.length > 0) {
            order['Profit Leg'].trades.forEach(tradebookItem => {
              tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
            });

            let total_trade_value = order['Profit Leg'].trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
            order['Profit Leg'].average_trade_price = (parseFloat(total_trade_value) / order['Profit Leg'].trades.length).toFixed(2);
          }

          if (order['Stop Loss Leg'] && order['Stop Loss Leg'].trades && order['Stop Loss Leg'].trades.length > 0) {
            order['Stop Loss Leg'].trades.forEach(tradebookItem => {
              tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
            });

            let total_trade_value = order['Stop Loss Leg'].trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
            order['Stop Loss Leg'].average_trade_price = (parseFloat(total_trade_value) / order['Stop Loss Leg'].trades.length).toFixed(2);
          }



        }
        this.showOrderDetailsPopup = true;
        this.checkForOrderDetailsPopupUpElementRendrer();

      } else {
        this.selectedOrder = order;
        this.showOrderDetailsPopup = true;
        this.checkForOrderDetailsPopupUpElementRendrer();
      }
    } else if (this.selectedOrderType.orderTypeCode == 2 || this.selectedOrderType.orderTypeCode == 3) {

      if (order.status == "EXECUTED") {

        this.selectedOrder = order;
        if (this.selectedOrder.leg_no_1.trades && this.selectedOrder.leg_no_1.trades.length > 0) {
          this.selectedOrder.leg_no_1.trades.forEach(tradebookItem => {
            if (!tradebookItem.display_trade_timestamp) {
              tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
            }
          });
        }

        if (this.selectedOrder.leg_no_2.trades && this.selectedOrder.leg_no_2.trades.length > 0) {
          this.selectedOrder.leg_no_2.trades.forEach(tradebookItem => {
            if (!tradebookItem.display_trade_timestamp) {
              tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
            }
          });
        }

        if (this.selectedOrder.leg_indicator == '3L') {

          if (this.selectedOrder.leg_no_3.trades && this.selectedOrder.leg_no_3.trades.length > 0) {
            this.selectedOrder.leg_no_3.trades.forEach(tradebookItem => {
              if (!tradebookItem.display_trade_timestamp) {
                tradebookItem.display_trade_timestamp = clsCommonMethods.getTradeTime(tradebookItem.trade_timestamp);
              }
            });
          }
        }


        this.showMultilegOrderDetailsPopup = true;
        this.checkForMultilegOrderDetailsPopupUpElementRendrer();

      } else {
        this.selectedOrder = order;
        this.showMultilegOrderDetailsPopup = true;
        this.checkForMultilegOrderDetailsPopupUpElementRendrer();
      }
    } else if (this.selectedOrderType.orderTypeCode == 4) {
      this.selectedOrder = order;
      this.transactionService.getGTDOrderSummary(1, 1000, this.selectedOrder.gateway_order_id).then((gtdOrderSummaryResponse: any) => {
        if (gtdOrderSummaryResponse.status == 'success') {
          this.selectedOrder.order_history = gtdOrderSummaryResponse.data;
          this.selectedOrder.order_history.filter(element => { element.status == 'EXECUTED' });
          if (this.selectedOrder.order_history.length > 0) {
            this.selectedOrder.child_orders_qty = 0;
            this.selectedOrder.child_orders_average_price = 0;
            this.selectedOrder.child_orders_qty = this.selectedOrder.order_history.reduce((sum, currentvalue) => sum + currentvalue.traded_quantity, 0);
            let sum_order_price = this.selectedOrder.order_history.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.order_price), 0);
            this.selectedOrder.child_orders_average_price = (parseFloat(sum_order_price) / this.selectedOrder.child_orders_qty).toFixed(2);
          } else {
            this.selectedOrder.child_orders_qty = 0;
            this.selectedOrder.child_orders_average_price = 0;
          }

        } else {
          this.selectedOrder.order_history = [];
        }
      }, error => {
        this.selectedOrder.order_history = [];
      });
      console.log(order)
      this.showOrderDetailsPopup = true;
      this.checkForOrderDetailsPopupUpElementRendrer();

    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getTradeBookFromOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  segmentChanged(event) {
try{
    this.mode = event.detail.value;
    switch (this.selectedOrderType.orderTypeCode) {
      case 1:
        if (this.mode == 'open' && this.openOrdersPageCount == 0 && !this.lastPageForOpenOrder) {
          this.getOrderBookData(++this.openOrdersPageCount, this.pageSize, 1);
        }
        else if (this.mode == 'completed' && this.completedOrdersPageCount == 0 && !this.lastPageForCompletedOrder) {
          this.getOrderBookData(++this.completedOrdersPageCount, this.pageSize, 2);
        }
        else if (this.mode == 'all' && this.allOrdersPageCount == 0 && !this.lastPageForAllOrder) {
          this.getOrderBookData(++this.allOrdersPageCount, this.pageSize, -1);
        }
        else {
          this.createOrderBookData();
          if (this.isFilterApply) {
            this.applySortFilter();
          }
          this.creatBroadCastData();
        }
        break;
      case 2:
        if (this.mode == 'open' && this.openOrdersPageCountSpread == 0 && !this.lastPageForOpenOrderSpread) {
          this.getOrderBookData(++this.openOrdersPageCountSpread, this.pageSize, 1);
        }
        else if (this.mode == 'completed' && this.completedOrdersPageCountSpread == 0 && !this.lastPageForCompletedOrderSpread) {
          this.getOrderBookData(++this.completedOrdersPageCountSpread, this.pageSize, 2);
        }
        else if (this.mode == 'all' && this.allOrdersPageCountSpread == 0 && !this.lastPageForAllOrderSpread) {
          this.getOrderBookData(++this.allOrdersPageCountSpread, this.pageSize, -1);
        }
        else {
          this.createOrderBookData();
          if (this.isFilterApply) {
            this.applySortFilter();
          }
          this.creatBroadCastData();
        }
        break;
      case 3:
        if (this.mode == 'open' && this.openOrdersPageCountMultileg == 0 && !this.lastPageForOpenOrderMultileg) {
          this.getOrderBookData(++this.openOrdersPageCountMultileg, this.pageSize, 1);
        }
        else if (this.mode == 'completed' && this.completedOrdersPageCountMultileg == 0 && !this.lastPageForCompletedOrderMultileg) {
          this.getOrderBookData(++this.completedOrdersPageCountMultileg, this.pageSize, 2);
        }
        else if (this.mode == 'all' && this.allOrdersPageCountMultileg == 0 && !this.lastPageForAllOrderMultileg) {
          this.getOrderBookData(++this.allOrdersPageCountMultileg, this.pageSize, -1);
        }
        else {
          this.createOrderBookData();
          if (this.isFilterApply) {
            this.applySortFilter();
          }
          this.creatBroadCastData();
        }
        break;
      case 4:
        if (this.mode == 'open' && this.openOrdersPageCountGTD == 0 && !this.lastPageForOpenOrderGTD) {
          this.getOrderBookData(++this.openOrdersPageCountGTD, this.pageSize, 1);
        }
        else if (this.mode == 'completed' && this.completedOrdersPageCountGTD == 0 && !this.lastPageForCompletedOrderGTD) {
          this.getOrderBookData(++this.completedOrdersPageCountGTD, this.pageSize, 2);
        }
        else if (this.mode == 'all' && this.allOrdersPageCountGTD == 0 && !this.lastPageForAllOrderGTD) {
          this.getOrderBookData(++this.allOrdersPageCountGTD, this.pageSize, -1);
        }
        else {
          this.createOrderBookData();
          if (this.isFilterApply) {
            this.applySortFilter();
          }
          this.creatBroadCastData();
        }
        break;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'segmentChanged', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  createOrderBookData() {
    try{
    this.sendTouchlineRequest(OperationType.REMOVE, this.orderScripKeys);
    this.orderScripKeys = [];
    this.filterOrderBookData = [];

    switch (this.selectedOrderType.orderTypeCode) {
      case 1:
        if (this.mode == 'open') {
          this.orderbookData.forEach(element => {
            if (element.product_type == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
              if (element.bracket_details.bo_order_status == 'PENDING') {
                this.filterOrderBookData.push(element);
              }
            }
            else if (element.status == 'PENDING' || element.status == 'PARTIALLYCOMPLETED' || element.status == 'OMSXMITTED' || element.status == 'OMS_XMITTED' || element.status == 'EXXMITTED' || element.status == 'ADMINPENDING' || element.status == 'ADMINMODIFY' || element.status == 'ADMINACCEPT' || element.status == 'AMOACCEPTED' || element.status == 'MINIADMINPENDING' || element.status == 'AMO SUBMITTED' || element.status == 'ADMINMODIFY' || element.status == 'ADMINMODIFY') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'completed') {

          this.orderbookData.forEach(element => {
            if (element.product_type == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
              if (element.bracket_details.bo_order_status == 'COMPLETED') {
                this.filterOrderBookData.push(element);
              }
            }
            else if (element.status == 'EXECUTED') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'all') {
          this.orderbookData.forEach(element => {
            this.filterOrderBookData.push(element);
          });
        }
        break;
      case 2:
        if (this.mode == 'open') {
          this.orderbookDataSpread.forEach(element => {

            if (element.status == 'PENDING' || element.status == 'PARTIALLYCOMPLETED' || element.status == 'OMSXMITTED' || element.status == 'OMS_XMITTED' || element.status == 'EXXMITTED' || element.status == 'ADMINPENDING' || element.status == 'ADMINMODIFY' || element.status == 'ADMINACCEPT' || element.status == 'AMOACCEPTED' || element.status == 'MINIADMINPENDING' || element.status == 'AMO SUBMITTED' || element.status == 'ADMINMODIFY' || element.status == 'ADMINMODIFY') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'completed') {

          this.orderbookDataSpread.forEach(element => {
            if (element.status == 'EXECUTED') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'all') {
          this.orderbookDataSpread.forEach(element => {
            this.filterOrderBookData.push(element);
          });
        }
        break;
      case 3:
        if (this.mode == 'open') {
          this.orderbookDataMultileg.forEach(element => {

            if (element.status == 'PENDING' || element.status == 'PARTIALLYCOMPLETED' || element.status == 'OMSXMITTED' || element.status == 'OMS_XMITTED' || element.status == 'EXXMITTED' || element.status == 'ADMINPENDING' || element.status == 'ADMINMODIFY' || element.status == 'ADMINACCEPT' || element.status == 'AMOACCEPTED' || element.status == 'MINIADMINPENDING' || element.status == 'AMO SUBMITTED' || element.status == 'ADMINMODIFY' || element.status == 'ADMINMODIFY') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'completed') {

          this.orderbookDataMultileg.forEach(element => {
            if (element.status == 'EXECUTED') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'all') {
          this.orderbookDataMultileg.forEach(element => {
            this.filterOrderBookData.push(element);
          });
        }
        break;
      case 4:
        if (this.mode == 'open') {
          this.orderbookDataGTD.forEach(element => {

            if (element.status == 'ACTIVE' || element.status == 'PARTIALLYCOMPLETED' || element.status == 'OMSXMITTED' || element.status == 'OMS_XMITTED' || element.status == 'EXXMITTED' || element.status == 'ADMINPENDING' || element.status == 'ADMINMODIFY' || element.status == 'ADMINACCEPT' || element.status == 'AMOACCEPTED' || element.status == 'MINIADMINPENDING' || element.status == 'AMO SUBMITTED' || element.status == 'ADMINMODIFY' || element.status == 'ADMINMODIFY') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'completed') {

          this.orderbookDataGTD.forEach(element => {
            if (element.status == 'COMPLETED') {
              this.filterOrderBookData.push(element);
            }
          });
        } else if (this.mode == 'all') {
          this.orderbookDataGTD.forEach(element => {
            this.filterOrderBookData.push(element);
          });
        }
        break;
    }

  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'createOrderBookData', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  creatBroadCastData() {
    try{
    if (this.selectedOrderType.orderTypeCode == 1 || this.selectedOrderType.orderTypeCode == 4) {
      for (let index = 0; index < this.filterOrderBookData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.filterOrderBookData[index].scrip_token;
        objScrpKey.MktSegId = this.filterOrderBookData[index].mktSegId;
        this.orderScripKeys.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.orderScripKeys);
    }
    else if (this.selectedOrderType.orderTypeCode == 2 || this.selectedOrderType.orderTypeCode == 3) {
      for (let index = 0; index < this.filterOrderBookData.length; index++) {
        let objScrpKey1: clsScripKey = new clsScripKey();
        objScrpKey1.token = this.filterOrderBookData[index].leg_no_1.scrip_token;
        objScrpKey1.MktSegId = this.filterOrderBookData[index].mktSegId;
        this.orderScripKeys.push(objScrpKey1);

        let objScrpKey2: clsScripKey = new clsScripKey();
        objScrpKey2.token = this.filterOrderBookData[index].leg_no_2.scrip_token;
        objScrpKey2.MktSegId = this.filterOrderBookData[index].mktSegId;
        this.orderScripKeys.push(objScrpKey2);

        if (this.filterOrderBookData[index].leg_indicator == '3L') {
          let objScrpKey3: clsScripKey = new clsScripKey();
          objScrpKey3.token = this.filterOrderBookData[index].leg_no_3.scrip_token;
          objScrpKey3.MktSegId = this.filterOrderBookData[index].mktSegId;
          this.orderScripKeys.push(objScrpKey3);
        }
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.orderScripKeys);
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'creatBroadCastData', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  menuToggle() {
    this.menuCtrl.toggle();
  }

  /**
  * send request for broadcast
  * @param opType
  * @param scripList
  */
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'sendTouchlineRequest', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        if (this.selectedOrderType.orderTypeCode == 1) {
          if (this.filterOrderBookData.length > 0) {
            this.filterOrderBookData.forEach(orderBookItem => {
              if (orderBookItem.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "PARTIALLYCOMPLETED" || orderBookItem.traded_quantity > 0) {
                  let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.transaction_type == 'BUY') {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.average_trade_price = 0.00
                    orderBookItem.PandL = 0.00
                    orderBookItem.perPandL = 0.00
                  }

                }

              }
            });
          }

          if (this.orderSearchData.length > 0) {
            this.orderSearchData.forEach(orderBookItem => {
              if (orderBookItem.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "PARTIALLYCOMPLETED") {
                  let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.transaction_type == 'BUY') {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.average_trade_price = 0.00
                    orderBookItem.PandL = 0.00
                    orderBookItem.perPandL = 0.00
                  }


                }
              }
            });
          }
        } else if (this.selectedOrderType.orderTypeCode == 2) {
          if (this.filterOrderBookData.length > 0) {
            this.filterOrderBookData.forEach(orderBookItem => {
              if (orderBookItem.leg_no_1.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "PARTIALLYCOMPLETED" || orderBookItem.traded_quantity > 0) {
                  let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.transaction_type == 'BUY') {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.average_trade_price = 0.00
                    orderBookItem.PandL = 0.00
                    orderBookItem.perPandL = 0.00
                  }

                }

              }
            });
          }
          if (this.orderSearchData.length > 0) {
            this.orderSearchData.forEach(orderBookItem => {
              if (orderBookItem.leg_no_1.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "PARTIALLYCOMPLETED" || orderBookItem.traded_quantity > 0) {
                  let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.transaction_type == 'BUY') {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.average_trade_price = 0.00
                    orderBookItem.PandL = 0.00
                    orderBookItem.perPandL = 0.00
                  }

                }

              }
            });
          }
        } else if (this.selectedOrderType.orderTypeCode == 3) {
          if (this.filterOrderBookData.length > 0) {
            this.filterOrderBookData.forEach(orderBookItem => {
              if (orderBookItem.leg_no_1.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_1.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_1.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_1.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_1.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_1.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_1.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_1.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_1.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_1.transaction_type == 'BUY') {
                      orderBookItem.leg_no_1.PandL = ((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.leg_no_1.average_trade_price)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_1.perPandL = (((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.leg_no_1.average_trade_price)) / parseFloat(orderBookItem.leg_no_1.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_1.PandL = ((parseFloat(orderBookItem.leg_no_1.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_1.perPandL = (((parseFloat(orderBookItem.leg_no_1.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) / parseFloat(orderBookItem.leg_no_1.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.leg_no_1.average_trade_price = 0.00
                    orderBookItem.leg_no_1.PandL = 0.00
                    orderBookItem.leg_no_1.perPandL = 0.00
                  }

                }

              }

              if (orderBookItem.leg_no_2.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_2.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_2.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_2.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_2.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_2.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_2.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_2.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_2.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_2.transaction_type == 'BUY') {
                      orderBookItem.leg_no_2.PandL = ((parseFloat(orderBookItem.leg_no_2.LTP) - parseFloat(orderBookItem.leg_no_2.average_trade_price)) * parseInt(orderBookItem.leg_no_2.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_2.perPandL = (((parseFloat(orderBookItem.leg_no_2.LTP) - parseFloat(orderBookItem.leg_no_2.average_trade_price)) / parseFloat(orderBookItem.leg_no_2.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_2.PandL = ((parseFloat(orderBookItem.leg_no_2.average_trade_price) - parseFloat(orderBookItem.leg_no_2.LTP)) * parseInt(orderBookItem.leg_no_2.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_2.perPandL = (((parseFloat(orderBookItem.leg_no_2.average_trade_price) - parseFloat(orderBookItem.leg_no_2.LTP)) / parseFloat(orderBookItem.leg_no_2.average_trade_price)) * 100).toFixed(2);
                    }
                    orderBookItem.leg_no_2.average_trade_price = 0.00
                    orderBookItem.leg_no_2.PandL = 0.00
                    orderBookItem.leg_no_2.perPandL = 0.00
                  }

                }

              }

              if (orderBookItem.leg_no_3.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId && orderBookItem.leg_indicator == '3L') {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_3.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_3.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_3.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_3.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_3.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_3.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_3.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_3.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_3.transaction_type == 'BUY') {
                      orderBookItem.leg_no_3.PandL = ((parseFloat(orderBookItem.leg_no_3.LTP) - parseFloat(orderBookItem.leg_no_3.average_trade_price)) * parseInt(orderBookItem.leg_no_3.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_3.perPandL = (((parseFloat(orderBookItem.leg_no_3.LTP) - parseFloat(orderBookItem.leg_no_3.average_trade_price)) / parseFloat(orderBookItem.leg_no_3.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_3.PandL = ((parseFloat(orderBookItem.leg_no_3.average_trade_price) - parseFloat(orderBookItem.leg_no_3.LTP)) * parseInt(orderBookItem.leg_no_3.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_3.perPandL = (((parseFloat(orderBookItem.leg_no_3.average_trade_price) - parseFloat(orderBookItem.leg_no_3.LTP)) / parseFloat(orderBookItem.leg_no_3.average_trade_price)) * 100).toFixed(2);
                    }
                    orderBookItem.leg_no_3.average_trade_price = 0.00
                    orderBookItem.leg_no_3.PandL = 0.00
                    orderBookItem.leg_no_3.perPandL = 0.00
                  }

                }

              }
              if (orderBookItem.status == "EXECUTED") {
                orderBookItem.PandL = 0.00
                if (orderBookItem.leg_no_1.PandL && orderBookItem.leg_no_2.PandL) {
                  orderBookItem.PandL = orderBookItem.leg_no_1.PandL + orderBookItem.leg_no_2.PandL;

                  if (orderBookItem.leg_indicator == '3L') {
                    orderBookItem.PandL = orderBookItem.PandL + orderBookItem.leg_no_3.PandL;
                  }
                }
              } else {
                orderBookItem.PandL = 0.00
              }

            });
          }
          if (this.orderSearchData.length > 0) {
            this.orderSearchData.forEach(orderBookItem => {
              if (orderBookItem.leg_no_1.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_1.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_1.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_1.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_1.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_1.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_1.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_1.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_1.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_1.transaction_type == 'BUY') {
                      orderBookItem.leg_no_1.PandL = ((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.leg_no_1.average_trade_price)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_1.perPandL = (((parseFloat(orderBookItem.leg_no_1.LTP) - parseFloat(orderBookItem.leg_no_1.average_trade_price)) / parseFloat(orderBookItem.leg_no_1.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_1.PandL = ((parseFloat(orderBookItem.leg_no_1.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) * parseInt(orderBookItem.leg_no_1.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_1.perPandL = (((parseFloat(orderBookItem.leg_no_1.average_trade_price) - parseFloat(orderBookItem.leg_no_1.LTP)) / parseFloat(orderBookItem.leg_no_1.average_trade_price)) * 100).toFixed(2);
                    }
                  } else {
                    orderBookItem.leg_no_1.average_trade_price = 0.00
                    orderBookItem.leg_no_1.PandL = 0.00
                    orderBookItem.leg_no_1.perPandL = 0.00
                  }

                }

              }

              if (orderBookItem.leg_no_2.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_2.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_2.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_2.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_2.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_2.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_2.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_2.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_2.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_2.transaction_type == 'BUY') {
                      orderBookItem.leg_no_2.PandL = ((parseFloat(orderBookItem.leg_no_2.LTP) - parseFloat(orderBookItem.leg_no_2.average_trade_price)) * parseInt(orderBookItem.leg_no_2.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_2.perPandL = (((parseFloat(orderBookItem.leg_no_2.LTP) - parseFloat(orderBookItem.leg_no_2.average_trade_price)) / parseFloat(orderBookItem.leg_no_2.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_2.PandL = ((parseFloat(orderBookItem.leg_no_2.average_trade_price) - parseFloat(orderBookItem.leg_no_2.LTP)) * parseInt(orderBookItem.leg_no_2.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_2.perPandL = (((parseFloat(orderBookItem.leg_no_2.average_trade_price) - parseFloat(orderBookItem.leg_no_2.LTP)) / parseFloat(orderBookItem.leg_no_2.average_trade_price)) * 100).toFixed(2);
                    }
                    orderBookItem.leg_no_2.average_trade_price = 0.00
                    orderBookItem.leg_no_2.PandL = 0.00
                    orderBookItem.leg_no_2.perPandL = 0.00
                  }

                }

              }

              if (orderBookItem.leg_no_3.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId && orderBookItem.leg_indicator == '3L') {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.leg_no_3.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.leg_no_3.NetChangeInRs = arrNetChange[0];
                orderBookItem.leg_no_3.PercNetChange = arrNetChange[1];
                orderBookItem.leg_no_3.LTPTrend = arrNetChange[2];
                orderBookItem.leg_no_3.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED") {
                  let total_trade_value = orderBookItem.leg_no_3.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  orderBookItem.leg_no_3.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.leg_no_3.trades.length).toFixed(2);
                  if (orderBookItem.average_trade_price) {
                    if (orderBookItem.leg_no_3.transaction_type == 'BUY') {
                      orderBookItem.leg_no_3.PandL = ((parseFloat(orderBookItem.leg_no_3.LTP) - parseFloat(orderBookItem.leg_no_3.average_trade_price)) * parseInt(orderBookItem.leg_no_3.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_3.perPandL = (((parseFloat(orderBookItem.leg_no_3.LTP) - parseFloat(orderBookItem.leg_no_3.average_trade_price)) / parseFloat(orderBookItem.leg_no_3.average_trade_price)) * 100).toFixed(2);
                    } else {
                      orderBookItem.leg_no_3.PandL = ((parseFloat(orderBookItem.leg_no_3.average_trade_price) - parseFloat(orderBookItem.leg_no_3.LTP)) * parseInt(orderBookItem.leg_no_3.traded_quantity)).toFixed(2);
                      orderBookItem.leg_no_3.perPandL = (((parseFloat(orderBookItem.leg_no_3.average_trade_price) - parseFloat(orderBookItem.leg_no_3.LTP)) / parseFloat(orderBookItem.leg_no_3.average_trade_price)) * 100).toFixed(2);
                    }
                    orderBookItem.leg_no_3.average_trade_price = 0.00
                    orderBookItem.leg_no_3.PandL = 0.00
                    orderBookItem.leg_no_3.perPandL = 0.00
                  }

                }

              }
              if (orderBookItem.status == "EXECUTED") {
                orderBookItem.PandL = 0.00
                if (orderBookItem.leg_no_1.PandL && orderBookItem.leg_no_2.PandL) {
                  orderBookItem.PandL = orderBookItem.leg_no_1.PandL + orderBookItem.leg_no_2.PandL;

                  if (orderBookItem.leg_indicator == '3L') {
                    orderBookItem.PandL = orderBookItem.PandL + orderBookItem.leg_no_3.PandL;
                  }
                }
              } else {
                orderBookItem.PandL = 0.00
              }

            });
          }
        } else if (this.selectedOrderType.orderTypeCode == 4) {
          if (this.filterOrderBookData.length > 0) {
            this.filterOrderBookData.forEach(orderBookItem => {
              if (orderBookItem.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "COMPLETED" || orderBookItem.traded_quantity > 0) {
                  // let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  // orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  // if (orderBookItem.average_trade_price) {
                  //   if (orderBookItem.transaction_type == 'BUY') {
                  //     orderBookItem.PandL = ((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                  //     orderBookItem.perPandL = (((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                  //   } else {
                  //     orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                  //     orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                  //   }
                  // } else {
                  orderBookItem.average_trade_price = 0.00
                  orderBookItem.PandL = 0.00
                  orderBookItem.perPandL = 0.00
                  //}

                }

              }
            });
          }

          if (this.orderSearchData.length > 0) {
            this.orderSearchData.forEach(orderBookItem => {
              if (orderBookItem.scrip_token == objMultiTLResp.Scrip.token && orderBookItem.mktSegId == objMultiTLResp.Scrip.MktSegId) {
                nFormat = objMultiTLResp.PriceFormat
                objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
                orderBookItem.LTP = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
                orderBookItem.NetChangeInRs = arrNetChange[0];
                orderBookItem.PercNetChange = arrNetChange[1];
                orderBookItem.LTPTrend = arrNetChange[2];
                orderBookItem.arrowTrend = arrNetChange[3];
                if (orderBookItem.status == "EXECUTED" || orderBookItem.status == "COMPLETED" || orderBookItem.traded_quantity > 0) {
                  // let total_trade_value = orderBookItem.trades.reduce((sum, currentvalue) => sum + parseFloat(currentvalue.trade_price), 0);
                  // orderBookItem.average_trade_price = (parseFloat(total_trade_value) / orderBookItem.trades.length).toFixed(2);
                  // if (orderBookItem.average_trade_price) {
                  //   if (orderBookItem.transaction_type == 'BUY') {
                  //     orderBookItem.PandL = ((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                  //     orderBookItem.perPandL = (((parseFloat(orderBookItem.LTP) - parseFloat(orderBookItem.average_trade_price)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                  //   } else {
                  //     orderBookItem.PandL = ((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) * parseInt(orderBookItem.traded_quantity)).toFixed(2);
                  //     orderBookItem.perPandL = (((parseFloat(orderBookItem.average_trade_price) - parseFloat(orderBookItem.LTP)) / parseFloat(orderBookItem.average_trade_price)) * 100).toFixed(2);
                  //   }
                  // } else {
                  orderBookItem.average_trade_price = 0.00
                  orderBookItem.PandL = 0.00
                  orderBookItem.perPandL = 0.00
                  //}

                }
              }
            });
          }
        }

        if (this.filterNetpositionDataDaily.length > 0) {
          this.filterNetpositionDataDaily.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) || (netPositionItem.isCombined && netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId)) {

              nFormat = objMultiTLResp.PriceFormat

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;


              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }

              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];




            }
          });
          this.calculatecurrentMTMDaily();
        }

        if (this.filterNetpositionDataExpiry.length > 0) {
          this.filterNetpositionDataExpiry.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) || (netPositionItem.isCombined && netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId)) {
              nFormat = objMultiTLResp.PriceFormat

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;

              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              // netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }


              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];

            }
          }
          );
          this.calculatecurrentMTMExpiry();
        }
      }
    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'receiveTouchlineResponse', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  calculatecurrentMTMDaily() {

    try {
      let totalMTM = 0.00;
      // let totalInvestedValue = 0.00;
      //  let totalCurrentValue = 0.00;
      this.sumMTMDaily = 0.00;
      for (let count = 0; count < this.netPositionDataDaily.length; count++) {

        totalMTM = parseFloat(totalMTM.toFixed(2)) + parseFloat(this.netPositionDataDaily[count].mtm);
        //   totalCurrentValue = parseFloat(totalCurrentValue.toFixed(2)) + (Math.abs(this.netPositionDataDaily[count].net_quantity) * parseFloat(this.netPositionDataDaily[count].ltp));
        //  totalInvestedValue = parseFloat(totalInvestedValue.toFixed(2)) + (Math.abs(this.netPositionDataDaily[count].net_quantity) * parseFloat(this.netPositionDataDaily[count].net_price));

      }

      this.sumMTMDaily = totalMTM.toFixed(2);
      // this.sumMTMDailyPer = (((totalCurrentValue - totalInvestedValue) / totalInvestedValue) * 100).toFixed(2)
      //console.log("daily" , this.sumMTMDaily);
      if (parseFloat(this.sumMTMDaily) > 0) {
        this.mtmDataTrendDaily = 'color-positive';
      }
      else if (parseFloat(this.sumMTMDaily) < 0) {
        this.mtmDataTrendDaily = 'color-negative';
      } else {
        this.mtmDataTrendDaily = 'no-change';
      }
    } catch (error) {
      //console.log('TransactionPage calculatecurrentMTMDaily' + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'calculatecurrentMTMDaily', error.Message, undefined, error.stack, undefined, undefined));
    }

  }


  calculatecurrentMTMExpiry() {
    try {
      let totalMTM = 0.00;
      // let totalInvestedValue = 0.00;
      // let totalCurrentValue = 0.00;
      this.sumMTMExpiry = 0.00;
      for (let count = 0; count < this.netPositionDataExpiry.length; count++) {

        totalMTM = parseFloat(totalMTM.toFixed(2)) + parseFloat(this.netPositionDataExpiry[count].mtm);
        //totalCurrentValue = parseFloat(totalCurrentValue.toFixed(2)) + (parseInt(this.netPositionDataExpiry[count].net_quantity) * parseFloat(this.netPositionDataExpiry[count].ltp));
        // totalInvestedValue = parseFloat(totalInvestedValue.toFixed(2)) + (parseInt(this.netPositionDataExpiry[count].net_quantity) * parseFloat(this.netPositionDataExpiry[count].net_price));
      }

      this.sumMTMExpiry = totalMTM.toFixed(2);
      // this.sumMTMExpiryPer = (((totalCurrentValue - totalInvestedValue) / totalInvestedValue) * 100).toFixed(2)
      // console.log("Expiry" , this.sumMTMExpiry);

      if (parseFloat(this.sumMTMExpiry) > 0) {
        this.mtmDataTrendExpiry = 'color-positive';
      }
      else if (parseFloat(this.sumMTMExpiry) < 0) {
        this.mtmDataTrendExpiry = 'color-negative';
      } else {
        this.mtmDataTrendExpiry = 'no-change';
      }
    }
    catch (error) {
      //console.log('TransactionPage calculatecurrentMTMExpiry' + error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'calculatecurrentMTMExpiry', error.Message, undefined, error.stack, undefined, undefined));
    }

  }

  cancelOrder(order: any) {
    try{
    if (this.showCancelOrderPopup) {
      this.isCancelOrderClick = true;
      this.transactionService.cancelOrder(order.exchange, order.order_id)
        .then((response: any) => {
          this.showConfirmDialogPopup("Your Order for " + this.selectedOrder.symbol + " " + this.selectedOrder.displayScripDesc + " has been cancelled", "", false);
          this.showOrderDetailsPopup = false;
          this.showCancelOrderPopup = false
          this.isCancelOrderClick = false;
        }).catch(error => {
          this.showOrderDetailsPopup = false;
          this.showCancelOrderPopup = false;
          this.isCancelOrderClick = false;
        });
    } else {
      this.showCancelOrderPopup = true;

    }
  }
  catch (error) {
    //console.log('TransactionPage calculatecurrentMTMExpiry' + error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'cancelOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  exitBracketOrder(bracketOrder: any) {
    try{
    if (this.showExitOrderPopup) {
      this.isExitOrderClick = true;
      this.transactionService.exitBracketOrder(bracketOrder.exchange, bracketOrder.order_id)
        .then((response: any) => {
          this.showConfirmDialogPopup("Exit successfull!", bracketOrder.order_id, true);
          this.showOrderDetailsPopup = false;
          this.showExitOrderPopup = false;
          this.isExitOrderClick = false;
        }).catch(error => {
          this.showOrderDetailsPopup = false;
          this.showExitOrderPopup = false;
          this.isExitOrderClick = false;
        });
    } else {
      this.showExitOrderPopup = true;
    }
  }
  catch (error) {
    //console.log('TransactionPage calculatecurrentMTMExpiry' + error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'exitBracketOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  closeCancelorderPopup() {
    this.showCancelOrderPopup = false;
  }

  closeExitorderPopup() {
    this.showExitOrderPopup = false;
  }


  async modifyOrder(order: any) {
    try{
    this.isScripFetchForModify = true;
    if (!order.scrip) {
      let scripdetail = {
        scrips: [{
          mkt: order.exchange,
          token: order.scrip_token
        }]
      }
      await clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        if (resp.status) {
          this.isScripFetchForModify = false;
          order.scrip = resp.result[0];
        } else {
          this.isScripFetchForModify = true;
        }
      });
    } else {
      this.isScripFetchForModify = false;
    }




    let currScrip: clsScrip = new clsScrip();
    currScrip = clsCommonMethods.getScripObject(order.scrip).scripDetail;
    let buysellnumber;
    if (order.transaction_type == clsConstants.C_S_ORDER_BUY_TEXT) {
      buysellnumber = clsConstants.C_V_ORDER_BUY;
    }
    else {
      buysellnumber = clsConstants.C_V_ORDER_SELL;
    }

    let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
    objOEFormDetail.buySell = buysellnumber;
    objOEFormDetail.gwOrderNo = order.order_id;
    //objOEFormDetail.COL = order.COL;
    objOEFormDetail.orderType = order.order_type;
    objOEFormDetail.pageSource = clsConstants.C_V_ORDERBOOK_PAGENO;
    objOEFormDetail.scripDetl = currScrip;
    objOEFormDetail.buyQty = order.transaction_type == 'BUY' ? order.total_quantity : 0;
    objOEFormDetail.sellQty = order.transaction_type == 'SELL' ? order.total_quantity : 0;
    objOEFormDetail.ltp = order.LTP;
    objOEFormDetail.closePrice = null;
    objOEFormDetail.recoId = '';
    objOEFormDetail.orderQty = order.pending_quantity;
    objOEFormDetail.orderPrice = order.order_price;
    objOEFormDetail.orderTrigPrice = order.trigger_price;
    objOEFormDetail.productType = order.product_type;
    objOEFormDetail.validity = order.validity;
    objOEFormDetail.day = order.validity_days;
    objOEFormDetail.exchOrderNo = order.exchange_order_no;
    objOEFormDetail.cliOrderNo = order.order_identifier;
    objOEFormDetail.cliExchangeOrderID = order.exchange_order_no;
    objOEFormDetail.discQty = order.disclosed_quantity;
    objOEFormDetail.apiExchange = order.exchange;
    objOEFormDetail.tradedQty = order.traded_quantity;
    if(order.validity == 'GTD'){
      objOEFormDetail.orderTime = order.order_timestamp;
    }else{
      objOEFormDetail.orderTime = order.exchange_timestamp;
    };
    objOEFormDetail.isamo = order.is_amo_order;
    if (order.product_type == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {

      objOEFormDetail.SLOrderType = clsConstants.C_V_ORDER_STOPLOSS;
      objOEFormDetail.SLOrderPrice = order.order_price;
      objOEFormDetail.SLTrigOrderPrice = order.trigger_price;
    }
    if (order.product_type == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
      // objOEFormDetail.protPerc = order.MarketProtPerc;
      // objOEFormDetail.OFSMargin = order.OFSMargin;
      // objOEFormDetail.SLOrderType = order.SLOrderType;
      objOEFormDetail.SLOrderType = clsConstants.C_V_ORDER_STOPLOSS;
      objOEFormDetail.SLOrderPrice = order.bracket_details.stoploss_price;
      objOEFormDetail.SLTrigOrderPrice = order.bracket_details.stoploss_trigger_price;
      objOEFormDetail.SLJumpPrice = order.bracket_details.stoploss_jump_price;
      objOEFormDetail.LTPJumpPrice = order.bracket_details.ltp_jump_price;
      objOEFormDetail.profitOrderPrice = order.bracket_details.profit_price;
      objOEFormDetail.bracketOrderId = order.bracket_details.bo_order_id;
      objOEFormDetail.boModifyBit = order.bracket_details.bo_modify_flag;
      // objOEFormDetail.recoSQprice = null;
      objOEFormDetail.legIndicator = order.bracket_details.leg_indicator;
    }
    this.paramService.myParam = objOEFormDetail;
    this.navCtrl.navigateForward('orderentry');
    this.showOrderDetailsPopup = false;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'modifyOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  async squareOffPosition() {
    try {

      if (this.interopOnOffFlag && this.selectedNetPosition.isCombined) {
        let intropOrderData = [];
        await this.netPositionDataTempNonIntropExpiry.forEach(element => {
          if (this.selectedNetPosition.preferred_mktSegId == element.preferred_mktSegId && this.selectedNetPosition.product_type == element.product_type && this.selectedNetPosition.preferred_scrip_token == element.preferred_scrip_token && element.net_quantity != 0) {
            intropOrderData.push(element);
          }
        });


        if (intropOrderData.length > 0) {
          this.paramService.myParam = intropOrderData;
          this.navCtrl.navigateForward('introp-orderentry');
          this.hideNetpositionPopup();
          this.closeNetPositionDetailsPopup();
        }

      } else {
        this.isScripFetchForSquareOff = true;
        if (this.selectedNetPosition && !this.selectedNetPosition.scrip) {
          let scripdetail = {
            scrips: [{
              mkt: this.selectedNetPosition.exchange,
              token: this.selectedNetPosition.scrip_token
            }]
          }
          await clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
            if (resp.status) {
              this.isScripFetchForSquareOff = false;
              this.selectedNetPosition.scrip = resp.result[0];
            } else {
              this.isScripFetchForSquareOff = true;
            }
          });
        } else {
          this.isScripFetchForSquareOff = false;
        }

        if (this.selectedNetPosition && this.selectedNetPosition.scrip) {
          let currScrip: clsScrip = new clsScrip();
          currScrip = clsCommonMethods.getScripObject(this.selectedNetPosition.scrip).scripDetail;

          let buysellnumber;
          if (this.selectedNetPosition.net_quantity > 0) {
            buysellnumber = clsConstants.C_V_ORDER_SELL;
          }
          else {
            buysellnumber = clsConstants.C_V_ORDER_BUY;
          }

          let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
          objOEFormDetail.buySell = buysellnumber;
          objOEFormDetail.orderType = clsConstants.C_V_ORDER_REGULARLOT_MARKET;
          objOEFormDetail.pageSource = clsConstants.C_V_NETPOSITION_PAGENO;
          objOEFormDetail.scripDetl = currScrip;
          objOEFormDetail.buyQty = null;
          objOEFormDetail.sellQty = null;
          objOEFormDetail.ltp = this.selectedNetPosition.ltp;
          objOEFormDetail.closePrice = null;
          objOEFormDetail.recoId = '';
          objOEFormDetail.orderQty = Math.abs(this.selectedNetPosition.net_quantity);
          objOEFormDetail.orderPrice = this.selectedNetPosition.ltp;
          objOEFormDetail.productType = this.selectedNetPosition.product_type;
          objOEFormDetail.apiExchange = this.selectedNetPosition.exchange;

          this.paramService.myParam = objOEFormDetail;


          this.navCtrl.navigateForward('orderentry');
          this.hideNetpositionPopup();
          this.closeNetPositionDetailsPopup();

        }
      }

    } catch (error) {
      this.toastServicesProvider.showAtMiddle("Unable to squareoff order");
      this.closeNetPositionDetailsPopup();
      //clsGlobal.logManager.writeErrorLog('TransactionPage ', 'squareOffPosition', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'squareOffPosition', error.Message, undefined, error.stack, undefined, undefined));
    }

  }

  setProdutTypeForConversion(productType) {
    this.selProductType = productType;
  }

  showPositionDetailsPopup(netPositionitem) {
    if (netPositionitem.net_quantity != 0 && netPositionitem.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && netPositionitem.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {

      this.selectedNetPosition = netPositionitem;
      this.showPositionDetails = true;
    }
  }

  closeNetPositionDetailsPopup() {
    this.showPositionDetails = false;
    this.isPositionConversionQtyEdit = false;
    this.selectedQtyforPositionConversion = 0;
    this.selectedNetPosition = null;
  }

  showPositionConverstionPopup() {
    try{
    this.showPositionConversition = true;
    if (this.selectedNetPosition.isCombined) {
      this.productTypesByExchange = clsGlobal.ExchManager.populateProductTypes(this.selectedNetPosition.preferred_exchange, this.selectedNetPosition.preferred_mktSegId, false);
    } else {
      this.productTypesByExchange = clsGlobal.ExchManager.populateProductTypes(this.selectedNetPosition.exchange, this.selectedNetPosition.mktSegId, false);
    }

    this.productTypesByExchange = this.productTypesByExchange.filter(element => {
      if (this.selectedNetPosition.product_type == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
        return (element != this.selectedNetPosition.product_type && element != this.selectedNetPosition.displayProductType && element != clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT && element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);

      } else {
        return (element != this.selectedNetPosition.product_type && element != this.selectedNetPosition.displayProductType && element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);
      }

    })
    this.selProductType = this.productTypesByExchange[0];
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'showPositionConverstionPopup', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  showPositionConversionEditPopup() {
    this.isPositionConversionQtyEdit = true;
    this.selectedQtyforPositionConversion = this.getFormattedQty(this.selectedNetPosition.net_quantity);
  }

  closePositionConversionEditPopup() {
    this.isPositionConversionQtyEdit = false;
    this.selectedQtyforPositionConversion = 0;
  }

  convertBracketOrderPosition() {
    this.bracketOrderPositionConversion = true;
    this.selProductType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT
  }

  closePositionConvertionPopup() {
    this.showPositionConversition = false;
    this.isPositionConversionQtyEdit = false;
    this.bracketOrderPositionConversion = false;
    this.selProductType = ""
  }


  convertPosition() {
    try{
    if (this.bracketOrderPositionConversion) {
      this.isPositionConversionClickBracketOrder = true;
      this.transactionService.positionConversion(this.selectedOrder.exchange, this.selectedOrder.scrip_token, this.selectedOrder.transaction_type, this.selectedOrder.traded_quantity, this.selectedOrder.product_type, this.selProductType, this.selectedOrder.bracket_details.bo_order_id).then((response: any) => {
        if (response.status == 'success') {
          this.isPositionConversionClickBracketOrder = false;
          this.showConfirmDialogPopup("Your Intraday Order for " + this.selectedOrder.symbol + " " + this.selectedOrder.displayScripDesc + "(" + this.selectedOrder.traded_quantity + " Shares) has been converted to Delivery Order", "", true);
          this.closeOrderDetailsPopup();
          this.closePositionConvertionPopup();

        } else {
          this.isPositionConversionClickBracketOrder = false;
          this.closeOrderDetailsPopup();
          this.closePositionConvertionPopup();
        }

      }, error => {
        this.isPositionConversionClickBracketOrder = false;
        this.closeOrderDetailsPopup();
        this.closePositionConvertionPopup();

      });
    } else {
      let net_quantity = 0;
      let old_product_type = "";
      if (this.isPositionConversionQtyEdit) {

        net_quantity = Math.abs(this.selectedQtyforPositionConversion);
      } else {
        net_quantity = Math.abs(this.selectedNetPosition.net_quantity);
      }
      if (this.selProductType == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT) {
        old_product_type = this.selProductType;
        this.selProductType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT
      } else {
        old_product_type = this.selProductType;
      }

      let transaction_type = this.selectedNetPosition.net_quantity > 0 ? 'BUY' : 'SELL';

      this.isPositionConversionClick = true;
      this.transactionService.positionConversion(this.selectedNetPosition.exchange, this.selectedNetPosition.scrip_token, transaction_type, net_quantity, this.selectedNetPosition.product_type, this.selProductType, "").then((response: any) => {
        if (response.status == 'success') {
          this.showConfirmDialogPopup("Your " + this.selectedNetPosition.displayProductType + "  Order for " + this.selectedNetPosition.symbol + " " + this.selectedNetPosition.displayScripDesc + "(" + net_quantity + " Shares) has been converted to " + old_product_type + " Order", "", true);
          this.isPositionConversionClick = false;
          this.closePositionConvertionPopup();
          this.closeNetPositionDetailsPopup();

        } else {
          this.isPositionConversionClick = false;
          this.closePositionConvertionPopup();
          this.closeNetPositionDetailsPopup();
        }

      }, error => {
        this.isPositionConversionClick = false;
        this.closePositionConvertionPopup();
        this.closeNetPositionDetailsPopup();


      });
    }

  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'convertPosition', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  closeConfirmDialogPopup() {
    this.confirmDialogDataObj = {};
    this.showConfirmDialog = false;
  }

  confirmDialogViewOrderStatusClick() {
    this.confirmDialogDataObj = {};
    this.showConfirmDialog = false;
  }

  showConfirmDialogPopup(message: string, orderId: string, isShowOrderStatusButton: boolean) {
    try{
    this.confirmDialogDataObj['message'] = message;
    this.confirmDialogDataObj['orderId'] = orderId;
    this.confirmDialogDataObj['isShowOrderStatusButton'] = isShowOrderStatusButton;
    this.showConfirmDialog = true;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'showConfirmDialogPopup', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  cancelAllOrders() {
    if (this.filterOrderBookData.length > 0 && this.filterOrderBookData.filter(order => order.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && order.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && order.status != 'PENDING' && order.status != 'ACTIVE' && order.status != 'PARTIALLYCOMPLETED').length > 0) {
      this.paramService.myParam = this.filterOrderBookData.filter(order => order.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && order.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT && order.status != 'PENDING' && order.status != 'ACTIVE' && order.status != 'PARTIALLYCOMPLETED');
      this.navCtrl.navigateForward('cancel-orders');
    }
  }

  getCancelOrdersCount() {
    return this.filterOrderBookData.filter(order => order.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && order.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT).length;
  }

  squareOffAllOrders() {
    try {

      if (this.netPositionDataTempNonIntropExpiry.filter((element: any) => { return element.net_quantity != 0 && element.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && element.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT }).length > 0) {
        this.paramService.myParam = this.netPositionDataTempNonIntropExpiry.filter((element: any) => { return element.net_quantity != 0 && element.product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && element.product_type != clsConstants.C_S_PRODUCTTYPE_MP_TEXT });
        this.navCtrl.navigateForward('squareoff-orders');
      }
    } catch (error) {
      ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'squareOffAllOrders', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  setOrdersFilter(filterName: any, filterValue: any) {
try{
    switch (filterName) {
      case 'sortalpha':
        this.ordersFilterObject.sortalpha = filterValue;
        break;
      case 'transactionType':
        this.ordersFilterObject.transactionType = filterValue;
        break;
      case 'productType':
        this.ordersFilterObject.productType = filterValue;
        break;
      case 'orderStatus':
        this.ordersFilterObject.orderStatus = filterValue;
        break;
      case 'orderValue':
        this.ordersFilterObject.orderValue = filterValue;
        break;
      case 'exchangeType':
        this.ordersFilterObject.exchangeType = filterValue;
        break;
    }
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'setOrdersFilter', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  removeOrdersFilter(filterName: any) {
    try{
    switch (filterName) {
      case 'sortalpha':
        delete this.ordersFilterObject.sortalpha
        break;
      case 'transactionType':
        delete this.ordersFilterObject.transactionType
        break;
      case 'productType':
        delete this.ordersFilterObject.productType;
        break;
      case 'orderStatus':
        delete this.ordersFilterObject.orderStatus;
        break;
      case 'orderValue':
        this.minOrderPriceFilter = 0;
        this.maxOrderPriceFilter = 0;
        delete this.ordersFilterObject.orderValue;
        break;
      case 'exchangeType':
        delete this.ordersFilterObject.exchangeType;
        break;

    }

    if (this.getOrderFiltersCount() == 0) {
      this.clearFilter();
    } else {
      this.applySortFilter();
    }
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'removeOrdersFilter', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  applySortFilter() {

    this.createOrderBookData();
    this.isFilterApply = true;
    this.showFilterPopup = false;

    if (this.filterOrderBookData.length > 0) {
      if (this.minOrderPriceFilter != 0 || this.maxOrderPriceFilter != 0) {
        this.ordersFilterObject['orderValue'] = { 'min': this.minOrderPriceFilter, 'max': this.maxOrderPriceFilter }
      }


      if (this.ordersFilterObject.sortalpha == 'asc') {
        this.filterOrderBookData.sort((a, b) => {
          return a.symbol.localeCompare(b.symbol);
        })
      } else if (this.ordersFilterObject.sortalpha == 'desc') {
        this.filterOrderBookData.sort((a, b) => {
          return b.symbol.localeCompare(a.symbol);
        })
      }

      if (this.ordersFilterObject.transactionType) {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => x.transaction_type == this.ordersFilterObject.transactionType)
      }
      if (this.ordersFilterObject.productType) {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => x.displayProductType == this.ordersFilterObject.productType)
      }

      if (this.ordersFilterObject.exchangeType) {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => x.displayExchange == this.ordersFilterObject.exchangeType)
      }

      if (this.ordersFilterObject.orderStatus && this.mode == 'all') {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => x.status == this.ordersFilterObject.orderStatus)
      }


      if (this.ordersFilterObject.orderValue && this.ordersFilterObject.orderValue.min > 0) {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => ((parseInt(x.total_quantity) * parseFloat(x.order_price)) > parseFloat(this.ordersFilterObject.orderValue.min)));
      }

      if (this.ordersFilterObject.orderValue && this.ordersFilterObject.orderValue.max > 0) {
        this.filterOrderBookData = this.filterOrderBookData
          .filter(x => ((parseInt(x.total_quantity) * parseFloat(x.order_price)) < parseFloat(this.ordersFilterObject.orderValue.max)));
      }
    }
    this.creatBroadCastData();
  }

  getOrderFiltersCount() {
    return Object.keys(this.ordersFilterObject).length;
  }

  clearFilter() {
    this.isFilterApply = false;
    this.showFilterPopup = false;
    this.ordersFilterObject = {};
    this.minOrderPriceFilter = 0;
    this.maxOrderPriceFilter = 0;
    this.createOrderBookData();
    this.creatBroadCastData();
  }

  checkForOrderDetailsPopupUpElementRendrer() {
    try{
    const divElement: HTMLElement = document.getElementById('divOrderDetailsPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForOrderDetailsPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divOrderDetailsPopup');
        this.orderDetailsPopupBottomToTop(divElement);
      }, 200);
    }
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'checkForOrderDetailsPopupUpElementRendrer', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  orderDetailsPopupBottomToTop(myElementRef) {
    try{
    let setting: CupertinoSettings = {
      breaks: {
        top: { // Topper point that pane can reach
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight, // Pane breakpoint height
          bounce: false // Bounce pane on transition
        }
        , middle: {
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight - (230), // Pane breakpoint height
          bounce: false // Bounce pane on transition 
        },
        bottom: {
          enabled: false, // Enable or disable breakpoint 
        }
      },
      dragBy: ['.pane .draggable'],
      initialBreak: 'middle',
      bottomClose: false,
      animationType: "ease",
      animationDuration: 200,
      buttonClose: false,
      onDidPresent: () => {
        //console.log("onDidPresent")
      },

      onDrag: () => {
      },
      onDragEnd: () => {

        //console.log("onDragEnd");


      },
      onTransitionStart: () => {

        //console.log("onTransitionStart")

      },
      onTransitionEnd: () => {
        ////console.log("onTransitionEnd ends");

        //console.log("onTransitionEnd")

        let topDiv = this.divOrderDetails.nativeElement.getBoundingClientRect().top;
        //console.log("onDragEnd" ,topDiv );
        if (topDiv < 90) {
          this.showExpandedOrderDetails = true;
          //this.showAddiionalOrderDetails = true;
        } else {
          this.showExpandedOrderDetails = false;
        }
      }
    }
    this.orderDetailsPane = new CupertinoPane(myElementRef, setting);
    this.orderDetailsPane.enableDrag();
    //this.orderDetailsPane.disableDrag();
    this.orderDetailsPane.present({ animate: true });
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'orderDetailsPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  checkForMultilegOrderDetailsPopupUpElementRendrer() {
    try{
    const divElement: HTMLElement = document.getElementById('divMultilegOrderDetailsPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForMultilegOrderDetailsPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divMultilegOrderDetailsPopup');
        this.orderMultilegDetailsPopupBottomToTop(divElement);
      }, 200);
    }
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'orderDetailsPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  orderMultilegDetailsPopupBottomToTop(myElementRef) {
    try{
    let setting: CupertinoSettings = {
      breaks: {
        top: { // Topper point that pane can reach
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight, // Pane breakpoint height
          bounce: false // Bounce pane on transition
        }
        , middle: {
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight - (230), // Pane breakpoint height
          bounce: false // Bounce pane on transition 
        },
        bottom: {
          enabled: false, // Enable or disable breakpoint 
        }
      },
      dragBy: ['.pane .draggable'],
      initialBreak: 'middle',
      bottomClose: false,
      animationType: "ease",
      animationDuration: 200,
      buttonClose: false,
      onDidPresent: () => {
        //console.log("onDidPresent")
      },

      onDrag: () => {
      },
      onDragEnd: () => {

        //console.log("onDragEnd");


      },
      onTransitionStart: () => {

        //console.log("onTransitionStart")

      },
      onTransitionEnd: () => {
        ////console.log("onTransitionEnd ends");

        //console.log("onTransitionEnd")

        let topDiv = this.divMultilegOrderDetails.nativeElement.getBoundingClientRect().top;
        //console.log("onDragEnd" ,topDiv );
        if (topDiv < 90) {
          this.showExpandedMultilegOrderDetails = true;
          //this.showAddiionalOrderDetails = true;
        } else {
          this.showExpandedMultilegOrderDetails = false;
        }
      }
    }
    this.multilegOrderDetailsPane = new CupertinoPane(myElementRef, setting);
    this.multilegOrderDetailsPane.enableDrag();
    //this.multilegOrderDetailsPane.disableDrag();
    this.multilegOrderDetailsPane.present({ animate: true });
  } catch (error) {
    ///clsGlobal.logManager.writeErrorLog("TransactionPage", "squareOffAllOrders", error.message);
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'orderMultilegDetailsPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  scrollMultilegOrderDetails(item, event) {
    if (event.target.scrollTop > 20) {
      this.multilegOrderDetailsPane.moveToBreak('top');
      this.showExpandedMultilegOrderDetails = true;
    }
  }

  //changes by omprakash for scroll handling. 
  //on scroll on details pane it will expand to full view.
  scrollOrderDetails(item, event) {
    if (event.target.scrollTop > 20) {
      this.orderDetailsPane.moveToBreak('top');
      this.showExpandedOrderDetails = true;
    }
  }

  closeOrderDetailsPopup() {
    this.showOrderDetailsPopup = false;
    this.showExpandedOrderDetails = false;
    this.showAddiionalOrderDetails = false;
    this.selectedOrder = null;
    this.orderDetailsPane.destroy({ animate: true });
  }

  closeMultilegOrderDetailsPopup() {
    this.showMultilegOrderDetailsPopup = false;
    this.showExpandedMultilegOrderDetails = false;
    this.showAddiionalMultilegOrderDetails = false;
    this.selectedOrder = null;
    this.multilegOrderDetailsPane.destroy({ animate: true });
  }

  showOrderFilterPopup() {
    this.showFilterPopup = true;
    this.checkForOrderFiilterPopupUpElementRendrer();
  }

  checkForOrderFiilterPopupUpElementRendrer() {
    try{
    const divElement: HTMLElement = document.getElementById('divOrderFilterPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForOrderFiilterPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divOrderFilterPopup');
        this.orderFilterPopupBottomToTop(divElement);
      }, 200);
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'checkForOrderFiilterPopupUpElementRendrer', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  orderFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop: true, //added by om on 24 th jan for backdrop display.
        onDidPresent: () => {
          ////console.log("onDidPresent")
        },

        // onDrag: () => {
        //   //  //console.log("onDrag");
        // },
        // onDragEnd: () => { 
        //   //console.log("onDragEnd"); 
        // },
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        onTransitionEnd: () => {
          let topDiv = this.divOrderFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedOrderFilter = true;
          } else {
            this.showExpandedOrderFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closeOrderFiltePopup();
        }
      }
      this.orderFilterPane = new CupertinoPane(myElementRef, setting);
      this.orderFilterPane.enableDrag();
      this.orderFilterPane.present({ animate: true });
    } catch (error) {
      //console.log("Error in filter page display " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'orderFilterPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  // change by omprakash for scroll behaviour.
  scrollOrderDetailsFilter(event) {
    if (event.target.scrollTop > 20) {
      this.orderFilterPane.moveToBreak('top');
      this.showExpandedOrderFilter = true;
    }
  }

  closeOrderFiltePopup() {
    this.showFilterPopup = false;
    this.showExpandedOrderFilter = false;
    this.orderFilterPane.destroy({ animate: true });
  }

  showSearchPopup() {
    this.searchText = '';
    this.showSearch = true;
    this.orderSearchData = [];
  }

  hideSearchPopup() {
    this.showSearch = false;
    this.searchText = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
    this.orderSearchScripKeys = [];
    this.orderSearchData = [];

  }

  search(event) {
    if (event) {
      //this.searchText = $event.toUpperCase();
      this.searchText =event.target.value.toUpperCase().trim();
      this.searchTextChanged.next(event.target.value.toUpperCase().trim());
    } else {
      this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchScripKeys);
      this.orderSearchScripKeys = [];
      this.orderSearchData = [];
    }
  }

  /** <Norwin Dcruz> <05/01/2021> <To get search values> **/
  getValues(search) {
    try {

      this.orderSearchData = [];

      if (search.length < 1) {
        this.searchTextEntered = '';
        return;
      }
      this.searchTextEntered = search.toUpperCase();

      switch(this.selectedOrderType.orderTypeCode){

        case 1 : 
          this.orderSearchData = this.orderbookData.filter(x => (x.symbol.toUpperCase().includes(this.searchTextEntered)));
          this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
          this.creatBroadCastDataSearchOrders();
        break;
        case 2 : 
          this.orderSearchData = this.orderbookDataSpread.filter(x => (x.symbol.toUpperCase().includes(this.searchTextEntered)));
          this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
          this.creatBroadCastDataSearchOrders();
        break;
        case 3 : 
          this.orderSearchData = this.orderbookDataMultileg.filter(x => (x.symbol.toUpperCase().includes(this.searchTextEntered)));
          this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
          this.creatBroadCastDataSearchOrders();
        break;
        case 4 : 
          this.orderSearchData = this.orderbookDataGTD.filter(x => (x.symbol.toUpperCase().includes(this.searchTextEntered)));
          this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchData);
          this.creatBroadCastDataSearchOrders();
        break;
      }
      

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getValues', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  clearSearch() {
    this.searchText = '';
    this.sendTouchlineRequest(OperationType.REMOVE, this.orderSearchScripKeys);
    this.orderSearchScripKeys = [];
    this.orderSearchData = [];
  }

  creatBroadCastDataSearchOrders() {
    try{
    this.orderSearchScripKeys = [];
    for (let index = 0; index < this.orderSearchData.length; index++) {


      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.token = this.orderSearchData[index].scrip_token;
      objScrpKey.MktSegId = this.orderSearchData[index].mktSegId;

      this.orderSearchScripKeys.push(objScrpKey);
    }
    clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.ADD, this.orderSearchScripKeys);
  } catch (error) {
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'creatBroadCastDataSearchOrders', error.Message, undefined, error.stack, undefined, undefined));
  }
  }


  showNetpositonPopUp() {
    if (this.netPositionDataDaily.length > 0 || this.netPositionDataExpiry.length > 0) {
      this.showNetPostion = true;
      this.checkForNetpositionPopupUpElementRendrer();
    }
  }

  checkForNetpositionPopupUpElementRendrer() {
    try{
    const divElement: HTMLElement = document.getElementById('divNetpositionPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForNetpositionPopupUpElementRendrer();
      }, 100);
    } else {
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divNetpositionPopup');
        this.netPositionPopupBottomToTop(divElement);
      }, 200);
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'checkForNetpositionPopupUpElementRendrer', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  netPositionPopupBottomToTop(myElementRef) {
    try{
    let setting: CupertinoSettings = {
      breaks: {
        top: { // Topper point that pane can reach
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight, // Pane breakpoint height
          bounce: false // Bounce pane on transition
        }
        , middle: {
          enabled: true, // Enable or disable breakpoint
          height: window.innerHeight - (250), // Pane breakpoint height
          bounce: false // Bounce pane on transition 
        },
        bottom: {
          enabled: false, // Enable or disable breakpoint 
        }
      },
      dragBy: ['.pane .draggable'],
      initialBreak: 'middle',
      bottomClose: false,
      animationType: "ease",
      animationDuration: 300,
      buttonClose: false,
      backdrop: true,
      // onDidPresent: () => {
      //   ////console.log("onDidPresent")
      // }, 
      // onDrag: () => {
      //   //  //console.log("onDrag");
      // },
      // onDragEnd: () => { 
      //   //console.log("onDragEnd"); 
      // },
      // onTransitionStart: () => { 
      //   //console.log("onTransitionStart") 
      // },
      onTransitionEnd: () => {
        let topDiv = this.divNetposition.nativeElement.getBoundingClientRect().top;
        //console.log("onDragEnd" ,topDiv );
        if (topDiv < 90) {
          this.showExpandedNetposition = true;
        } else {
          this.showExpandedNetposition = false;
        }
      },
      onBackdropTap: () => {
        //added by omprakash on 24 th jan for backdrop click
        this.hideNetpositionPopup();
      }
    }
    this.netPositionPane = new CupertinoPane(myElementRef, setting);
    this.netPositionPane.enableDrag();
    this.netPositionPane.present({ animate: true });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'netPositionPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  //changes by omprakash for scroll behaviour.
  scrollNewPositionDetails(item, event) {
    if (event.target.scrollTop > 20) {
      this.showExpandedNetposition = true;
      this.netPositionPane.moveToBreak('top');
    }
  }

  hideNetpositionPopup() {
    try {
      this.showNetPostion = false;
      this.netPositionPane.destroy({ animate: true });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'hideNetpositionPopup', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'hideNetpositionPopup', error.Message, undefined, error.stack, undefined, undefined));
    }

  }

  clicktickerCard() {
    this.showtickerCard = !this.showtickerCard;
  }

  doRefresh(refresher) {
    try{
    this.refresherInstance = refresher;
    this.resetPage();
    let orderstatus;
    let pageNo;
    switch (this.selectedOrderType.orderTypeCode) {
      case 1:
        orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
        pageNo = this.mode == 'open' ? ++this.openOrdersPageCount : this.mode == 'completed' ? ++this.completedOrdersPageCount : this.mode == 'all' ? ++this.allOrdersPageCount : ++this.allOrdersPageCount;
        this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        break;
      case 2:
        orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
        pageNo = this.mode == 'open' ? ++this.openOrdersPageCountSpread : this.mode == 'completed' ? ++this.completedOrdersPageCountSpread : this.mode == 'all' ? ++this.allOrdersPageCountSpread : ++this.allOrdersPageCountSpread;
        this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        break;
      case 3:
        orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
        pageNo = this.mode == 'open' ? ++this.openOrdersPageCountMultileg : this.mode == 'completed' ? ++this.completedOrdersPageCountMultileg : this.mode == 'all' ? ++this.allOrdersPageCountMultileg : ++this.allOrdersPageCountMultileg;
        this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        break;
      case 4:
        orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
        pageNo = this.mode == 'open' ? ++this.openOrdersPageCountGTD : this.mode == 'completed' ? ++this.completedOrdersPageCountGTD : this.mode == 'all' ? ++this.allOrdersPageCountGTD : ++this.allOrdersPageCountGTD;
        this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        break;

    }

    this.getNetPositionData();
  }
  catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'doRefresh', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  resetPage() {

    switch (this.selectedOrderType.orderTypeCode) {
      case 1:
        this.lastPageForOpenOrder = false;
        this.lastPageForCompletedOrder = false;
        this.lastPageForAllOrder = false;
        this.openOrdersPageCount = 0;
        this.completedOrdersPageCount = 0;
        this.allOrdersPageCount = 0;
        this.orderbookData = [];
        break;
      case 2:
        this.lastPageForOpenOrderSpread = false;
        this.lastPageForCompletedOrderSpread = false;
        this.lastPageForAllOrderSpread = false;
        this.openOrdersPageCountSpread = 0;
        this.completedOrdersPageCountSpread = 0;
        this.allOrdersPageCountSpread = 0;
        this.orderbookDataSpread = [];
        break;
      case 3:
        this.lastPageForOpenOrderMultileg = false;
        this.lastPageForCompletedOrderMultileg = false;
        this.lastPageForAllOrderMultileg = false;
        this.openOrdersPageCountMultileg = 0;
        this.completedOrdersPageCountMultileg = 0;
        this.allOrdersPageCountMultileg = 0;
        this.orderbookDataMultileg = [];
        break;
      case 4:
        this.lastPageForOpenOrderGTD = false;
        this.lastPageForCompletedOrderGTD = false;
        this.lastPageForAllOrderGTD = false;
        this.openOrdersPageCountGTD = 0;
        this.completedOrdersPageCountGTD = 0;
        this.allOrdersPageCountGTD = 0;
        this.orderbookDataGTD = [];
        break;
    }
  }

  formatScripDescSpreadOrder(order) {
    let scripDesc = clsCommonMethods.getFormattedExpirydate(order.leg_no_1.expiry_date).substr(clsCommonMethods.getFormattedExpirydate(order.leg_no_1.expiry_date).indexOf(' ') + 1, 3) + " - " + clsCommonMethods.getFormattedExpirydate(order.leg_no_2.expiry_date).substr(clsCommonMethods.getFormattedExpirydate(order.leg_no_2.expiry_date).indexOf(' ') + 1, 3) + " " + clsTradingMethods.formatScripDesc(order.leg_no_1.expiry_date, order.leg_no_1.instrument, order.leg_no_1.option_type, order.leg_no_1.strike_price);
    return scripDesc;
  }

  getOrderIconClass(orderbookitem) {
    let cssClass = '';
    let status = orderbookitem.product_type == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT ? orderbookitem.bracket_details.bo_order_status : orderbookitem.status;
    switch (status) {
      case "PARTIALLYCOMPLETED":
        cssClass = 'icon-partially-completed';
        break;
      case "PENDING":
        cssClass = 'icon-open-order';
        break;
      case "ACTIVE":
        cssClass = 'icon-open-order';
        break;
      case "EXECUTED":
      case "COMPLETED":
        cssClass = 'icon-completed-order';
        break;
      default:
        cssClass = 'icon-cancelled-order';
        break;
    }

    return cssClass;
  }

  getOrderStatusText(orderStatus) {
    try{
    let orderStatusText = '';
    switch (orderStatus) {
      case 'ADMINPENDING':
      case 'MINIADMINPENDING':
        orderStatusText = 'Admin Pending';
        break;
      case 'ADMINREJECT':
      case 'ADMIN_REJECT':
      case 'OMSREJECT':
      case 'OMS_REJECT':
        orderStatusText = 'Rejected';
        break;
      case 'PENDING':
        orderStatusText = 'Open';
        break;
      case 'ACTIVE':
        orderStatusText = 'Active';
        break;
      case 'COMPLETED':
      case 'EXECUTED':
        orderStatusText = 'Completed';
        break;
      case 'PARTIALLY COMPLETED':
      case 'PARTIALLY_COMPLETED':
      case 'PARTIALLYCOMPLETED':
        orderStatusText = 'Partially Completed';
        break;
      case 'CANCELLED':
        orderStatusText = 'Cancelled';
        break;
      case 'WITHDRAWN':
        orderStatusText = 'Withdrawn';
        break;
      case 'CLIENT XMITTED':
      case 'CLIENTXMITTED':
      case 'CLIENT_XMITTED':
      case 'GATEWAY XMITTED':
      case 'GATEWAYXMITTED':
      case 'GATEWAY_XMITTED':
      case 'OMS XMITTED':
      case 'OMSXMITTED':
      case 'OMS_XMITTED':
      case 'EXCHANGE XMITTED':
      case 'EXCHANGEXMITTED':
      case 'EXCHANGE_XMITTED':
      case 'A.MODIFY':
      case 'ADMINMODIFY':
      case 'ADMIN MODIFY':
      case 'ADMIN_MODIFY':
      case 'AMO SUBMITTED':
      case 'AMOSUBMITTED':
      case 'AMO_SUBMITTED':
      case 'AMOACCEPTED':
      case 'AMO ACCEPTED':
      case 'AMO_ACCEPTED':
      case 'ADMINACCEPT':
      case 'ADMIN ACCEPT':
      case 'ADMIN_ACCEPT':
      case 'A.ACCEPT ':
        orderStatusText = 'In-Process';
        break;
      default:
        orderStatusText = orderStatus;
        break;
    }
    return orderStatusText;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getOrderStatusText', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  getFormattedQty(qty) {
    return Math.abs(qty);
  }

  getFormattedNumbers(sNumber) {
    if (sNumber) {
      return clsCommonMethods.getNumberWithCurrencyFormat(sNumber);
    } else {
      return 0.00;
    }
  }

  getFormattedProductType(productType: string) {
    try{
    let product_type = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        product_type = productType.replace(/\w\S*/g, (txt) => { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase() })
        break;
      default:
        product_type = productType;
        break;
    }
    return product_type;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getFormattedProductType', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  loadMoreorders(scrollInstance) {
    try{
    this.scrollInstance = scrollInstance;
    let isNewPageAvalible = true;
    switch (this.selectedOrderType.orderTypeCode) {
      case 1:
        if (this.mode == 'open' && this.lastPageForOpenOrder) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrder) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrder) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCount : this.mode == 'completed' ? ++this.completedOrdersPageCount : this.mode == 'all' ? ++this.allOrdersPageCount : ++this.allOrdersPageCount;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.scrollInstance.target.complete();
          this.scrollInstance = null;
        }
        break;
      case 2:

        if (this.mode == 'open' && this.lastPageForOpenOrderSpread) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderSpread) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderSpread) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountSpread : this.mode == 'completed' ? ++this.completedOrdersPageCountSpread : this.mode == 'all' ? ++this.allOrdersPageCountSpread : ++this.allOrdersPageCountSpread;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.scrollInstance.target.complete();
          this.scrollInstance = null;
        }
        break;
      case 3:
        if (this.mode == 'open' && this.lastPageForOpenOrderMultileg) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderMultileg) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderMultileg) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountMultileg : this.mode == 'completed' ? ++this.completedOrdersPageCountMultileg : this.mode == 'all' ? ++this.allOrdersPageCountMultileg : ++this.allOrdersPageCountMultileg;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.scrollInstance.target.complete();
          this.scrollInstance = null;
        }
        break;
      case 4:

        if (this.mode == 'open' && this.lastPageForOpenOrderGTD) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'completed' && this.lastPageForCompletedOrderGTD) {
          isNewPageAvalible = false
        }
        else if (this.mode == 'all' && this.lastPageForAllOrderGTD) {
          isNewPageAvalible = false
        }
        if (isNewPageAvalible) {
          let orderstatus = this.mode == 'open' ? 1 : this.mode == 'completed' ? 2 : this.mode == 'all' ? -1 : -1;
          let pageNo = this.mode == 'open' ? ++this.openOrdersPageCountGTD : this.mode == 'completed' ? ++this.completedOrdersPageCountGTD : this.mode == 'all' ? ++this.allOrdersPageCountGTD : ++this.allOrdersPageCountGTD;

          this.getOrderBookData(pageNo, this.pageSize, orderstatus);
        } else {
          this.scrollInstance.target.complete();
          this.scrollInstance = null;
        }
        break;
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'loadMoreorders', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  getGTDDate(order) {

    let gtdDate = new Date(order.order_timestamp);
    gtdDate.setDate(gtdDate.getDate() + order.validity_days);

    return gtdDate.getDate() + " " + clsCommonMethods.getAlphaMonth(gtdDate.getMonth()) + "'" + gtdDate.getFullYear().toString().substring(2, 4)
  }

  formatDate(date) {
    let formatedDate = new Date(date)
    return formatedDate.getDate() + " " + clsCommonMethods.getAlphaMonth(formatedDate.getMonth()) + "'" + formatedDate.getFullYear().toString().substring(2, 4)
  }


  getOrderMeessage(orderMessage) {
try{
    if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_ORDER || orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_GTD_ORDER) {

      this.transactionService.getOrderBookfromOrderId(orderMessage.UniqueCode).then((orderData: any) => {
        if (orderData.status == 'success') {
          if (orderData.data[0].status == "PENDING" && orderData.data[0].traded_quantity > 0 && orderData.data[0].product_type != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
            orderData.data[0].status = "PARTIALLYCOMPLETED";
          }
          this.fetchTradeBookDataforOrder(orderData).then(tradeData => {

            orderData.data[0].trades = tradeData;
            if (orderData.data[0].bracket_details.parent_order_id == '') {
              this.orderbookData.forEach(element => {
                if (element.order_id == orderData.data[0].order_id) {
                  element.trades = orderData.data[0].trades
                  element.order_id = orderData.data[0].order_id;
                  element.exchange = orderData.data[0].exchange;
                  element.scrip_token = orderData.data[0].scrip_token;
                  element.exchange_order_no = orderData.data[0].exchange_order_no;
                  element.status = orderData.data[0].status;
                  element.error_reason = orderData.data[0].error_reason;
                  element.transaction_type = orderData.data[0].transaction_type;
                  element.product_type = orderData.data[0].product_type;
                  element.order_type = orderData.data[0].order_type;
                  element.total_quantity = orderData.data[0].total_quantity;
                  element.pending_quantity = orderData.data[0].pending_quantity;
                  element.traded_quantity = orderData.data[0].traded_quantity;
                  element.disclosed_quantit = orderData.data[0].disclosed_quantit;
                  element.order_price = orderData.data[0].order_price;
                  element.trigger_price = orderData.data[0].trigger_price;
                  element.validity = orderData.data[0].validity;
                  element.validity_days = orderData.data[0].validity_days;
                  element.symbol = orderData.data[0].symbol;
                  element.series = orderData.data[0].series;
                  element.instrument = orderData.data[0].instrument;
                  element.expiry_date = orderData.data[0].expiry_date;
                  element.strike_price = orderData.data[0].strike_price;
                  element.option_type = orderData.data[0].option_type;
                  element.market_lot = orderData.data[0].market_lot;
                  element.order_timestampp = orderData.data[0].order_timestamp;
                  element.exchange_timestamp = orderData.data[0].exchange_timestamp;
                  element.initiated_by = orderData.data[0].initiated_by;
                  element.modified_by = orderData.data[0].modified_by;
                  element.is_amo_order = orderData.data[0].is_amo_order;
                  element.gateway_order_id = orderData.data[0].gateway_order_id;
                  element.order_identifier = orderData.data[0].order_identifier;
                  element.bracket_details.parent_order_id = orderData.data[0].bracket_details.parent_order_id;
                  element.bracket_details.leg_indicator = orderData.data[0].bracket_details.leg_indicator;
                  element.bracket_details.stoploss_price = orderData.data[0].bracket_details.stoploss_price;
                  element.bracket_details.stoploss_trigger_price = orderData.data[0].bracket_details.stoploss_trigger_price;
                  element.bracket_details.profit_price = orderData.data[0].bracket_details.profit_price;
                  element.bracket_details.stoploss_jump_price = orderData.data[0].bracket_details.stoploss_jump_price;
                  element.bracket_details.ltp_jump_price = orderData.data[0].bracket_details.ltp_jump_price;
                  element.bracket_details.bo_order_id = orderData.data[0].bracket_details.bo_order_id;
                  element.bracket_details.bo_order_status = orderData.data[0].bracket_details.bo_order_status;
                  element.bracket_details.bo_modify_flag = orderData.data[0].bracket_details.bo_modify_flag;

                }
              });

              if (this.filterOrderBookData.length > 0) {
                this.filterOrderBookData.forEach(element => {
                  if (element.order_id == orderData.data[0].order_id) {
                    element.trades = orderData.data[0].trades
                    element.order_id = orderData.data[0].order_id;
                    element.exchange = orderData.data[0].exchange;
                    element.scrip_token = orderData.data[0].scrip_token;
                    element.exchange_order_no = orderData.data[0].exchange_order_no;
                    element.status = orderData.data[0].status;
                    element.error_reason = orderData.data[0].error_reason;
                    element.transaction_type = orderData.data[0].transaction_type;
                    element.product_type = orderData.data[0].product_type;
                    element.order_type = orderData.data[0].order_type;
                    element.total_quantity = orderData.data[0].total_quantity;
                    element.pending_quantity = orderData.data[0].pending_quantity;
                    element.traded_quantity = orderData.data[0].traded_quantity;
                    element.disclosed_quantit = orderData.data[0].disclosed_quantit;
                    element.order_price = orderData.data[0].order_price;
                    element.trigger_price = orderData.data[0].trigger_price;
                    element.validity = orderData.data[0].validity;
                    element.validity_days = orderData.data[0].validity_days;
                    element.symbol = orderData.data[0].symbol;
                    element.series = orderData.data[0].series;
                    element.instrument = orderData.data[0].instrument;
                    element.expiry_date = orderData.data[0].expiry_date;
                    element.strike_price = orderData.data[0].strike_price;
                    element.option_type = orderData.data[0].option_type;
                    element.market_lot = orderData.data[0].market_lot;
                    element.order_timestamp = orderData.data[0].order_timestamp;
                    element.exchange_timestamp = orderData.data[0].exchange_timestamp;
                    element.initiated_by = orderData.data[0].initiated_by;
                    element.modified_by = orderData.data[0].modified_by;
                    element.is_amo_order = orderData.data[0].is_amo_order;
                    element.gateway_order_id = orderData.data[0].gateway_order_id;
                    element.order_identifier = orderData.data[0].order_identifier;
                    element.bracket_details.parent_order_id = orderData.data[0].bracket_details.parent_order_id;
                    element.bracket_details.leg_indicator = orderData.data[0].bracket_details.leg_indicator;
                    element.bracket_details.stoploss_price = orderData.data[0].bracket_details.stoploss_price;
                    element.bracket_details.stoploss_trigger_price = orderData.data[0].bracket_details.stoploss_trigger_price;
                    element.bracket_details.profit_price = orderData.data[0].bracket_details.profit_price;
                    element.bracket_details.stoploss_jump_price = orderData.data[0].bracket_details.stoploss_jump_price;
                    element.bracket_details.ltp_jump_price = orderData.data[0].bracket_details.ltp_jump_price;
                    element.bracket_details.bo_order_id = orderData.data[0].bracket_details.bo_order_id;
                    element.bracket_details.bo_order_status = orderData.data[0].bracket_details.bo_order_status;
                    element.bracket_details.bo_modify_flag = orderData.data[0].bracket_details.bo_modify_flag;
                  }
                });
              }

              if (this.orderSearchData.length > 0) {
                this.orderSearchData.forEach(element => {
                  if (element.order_id == orderData.data[0].order_id) {
                    element.trades = orderData.data[0].trades;
                    element.order_id = orderData.data[0].order_id;
                    element.exchange = orderData.data[0].exchange;
                    element.scrip_token = orderData.data[0].scrip_token;
                    element.exchange_order_no = orderData.data[0].exchange_order_no;
                    element.status = orderData.data[0].status;
                    element.error_reason = orderData.data[0].error_reason;
                    element.transaction_type = orderData.data[0].transaction_type;
                    element.product_type = orderData.data[0].product_type;
                    element.order_type = orderData.data[0].order_type;
                    element.total_quantity = orderData.data[0].total_quantity;
                    element.pending_quantity = orderData.data[0].pending_quantity;
                    element.traded_quantity = orderData.data[0].traded_quantity;
                    element.disclosed_quantit = orderData.data[0].disclosed_quantit;
                    element.order_price = orderData.data[0].order_price;
                    element.trigger_price = orderData.data[0].trigger_price;
                    element.validity = orderData.data[0].validity;
                    element.validity_days = orderData.data[0].validity_days;
                    element.symbol = orderData.data[0].symbol;
                    element.series = orderData.data[0].series;
                    element.instrument = orderData.data[0].instrument;
                    element.expiry_date = orderData.data[0].expiry_date;
                    element.strike_price = orderData.data[0].strike_price;
                    element.option_type = orderData.data[0].option_type;
                    element.market_lot = orderData.data[0].market_lot;
                    element.order_timestamp = orderData.data[0].order_timestamp;
                    element.exchange_timestam = orderData.data[0].exchange_timestam;
                    element.initiated_by = orderData.data[0].initiated_by;
                    element.modified_by = orderData.data[0].modified_by;
                    element.is_amo_order = orderData.data[0].is_amo_order;
                    element.gateway_order_id = orderData.data[0].gateway_order_id;
                    element.order_identifier = orderData.data[0].order_identifier;
                    element.bracket_details.parent_order_id = orderData.data[0].bracket_details.parent_order_id;
                    element.bracket_details.leg_indicator = orderData.data[0].bracket_details.leg_indicator;
                    element.bracket_details.stoploss_price = orderData.data[0].bracket_details.stoploss_price;
                    element.bracket_details.stoploss_trigger_price = orderData.data[0].bracket_details.stoploss_trigger_price;
                    element.bracket_details.profit_price = orderData.data[0].bracket_details.profit_price;
                    element.bracket_details.stoploss_jump_price = orderData.data[0].bracket_details.stoploss_jump_price;
                    element.bracket_details.ltp_jump_price = orderData.data[0].bracket_details.ltp_jump_price;
                    element.bracket_details.bo_order_id = orderData.data[0].bracket_details.bo_order_id;
                    element.bracket_details.bo_order_status = orderData.data[0].bracket_details.bo_order_status;
                    element.bracket_details.bo_modify_flag = orderData.data[0].bracket_details.bo_modify_flag;
                  }
                });
              }
              setTimeout(() => {
                this.createOrderBookData()
                this.creatBroadCastData();
              }, 500)

            } else {


              this.bracketOrderData.forEach(element => {
                if (element.order_id == orderData.data[0].order_id) {
                  element.trades = orderData.data[0].trades
                  element.order_id = orderData.data[0].order_id;
                  element.exchange = orderData.data[0].exchange;
                  element.scrip_token = orderData.data[0].scrip_token;
                  element.exchange_order_no = orderData.data[0].exchange_order_no;
                  element.status = orderData.data[0].status;
                  element.error_reason = orderData.data[0].error_reason;
                  element.transaction_type = orderData.data[0].transaction_type;
                  element.product_type = orderData.data[0].product_type;
                  element.order_type = orderData.data[0].order_type;
                  element.total_quantity = orderData.data[0].total_quantity;
                  element.pending_quantity = orderData.data[0].pending_quantity;
                  element.traded_quantity = orderData.data[0].traded_quantity;
                  element.disclosed_quantit = orderData.data[0].disclosed_quantit;
                  element.order_price = orderData.data[0].order_price;
                  element.trigger_price = orderData.data[0].trigger_price;
                  element.validity = orderData.data[0].validity;
                  element.validity_days = orderData.data[0].validity_days;
                  element.symbol = orderData.data[0].symbol;
                  element.series = orderData.data[0].series;
                  element.instrument = orderData.data[0].instrument;
                  element.expiry_date = orderData.data[0].expiry_date;
                  element.strike_price = orderData.data[0].strike_price;
                  element.option_type = orderData.data[0].option_type;
                  element.market_lot = orderData.data[0].market_lot;
                  element.order_timestamp = orderData.data[0].order_timestamp;
                  element.exchange_timestamp = orderData.data[0].exchange_timestamp;
                  element.initiated_by = orderData.data[0].initiated_by;
                  element.modified_by = orderData.data[0].modified_by;
                  element.is_amo_order = orderData.data[0].is_amo_order;
                  element.gateway_order_id = orderData.data[0].gateway_order_id;
                  element.order_identifier = orderData.data[0].order_identifier;
                  element.bracket_details.parent_order_id = orderData.data[0].bracket_details.parent_order_id;
                  element.bracket_details.leg_indicator = orderData.data[0].bracket_details.leg_indicator;
                  element.bracket_details.stoploss_price = orderData.data[0].bracket_details.stoploss_price;
                  element.bracket_details.stoploss_trigger_price = orderData.data[0].bracket_details.stoploss_trigger_price;
                  element.bracket_details.profit_price = orderData.data[0].bracket_details.profit_price;
                  element.bracket_details.stoploss_jump_price = orderData.data[0].bracket_details.stoploss_jump_price;
                  element.bracket_details.ltp_jump_price = orderData.data[0].bracket_details.ltp_jump_price;
                  element.bracket_details.bo_order_id = orderData.data[0].bracket_details.bo_order_id;
                  element.bracket_details.bo_order_status = orderData.data[0].bracket_details.bo_order_status;
                  element.bracket_details.bo_modify_flag = orderData.data[0].bracket_details.bo_modify_flag;

                }
              });


              this.orderbookData.forEach(element => {
                if (element.order_id == orderData.data[0].bracket_details.parent_order_id) {
                  element[orderData.data[0].bracket_details.leg_indicator] = orderData.data[0];
                }
              });

              setTimeout(() => {
                this.createOrderBookData()
                this.creatBroadCastData();
              }, 500)
            }
          },
            err => {
              console.log(err)
            })
        }
      }, error => {
        console.log(error)
      })
    } else if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_TRADE) {

    }
    else if (orderMessage.MessageType == clsConstants.OMEX_MESSAGETYPE_POS_CONV) {
      this.getNetPositionData();
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getOrderMeessage', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  fetchTradeBookDataforOrder(orderData) {
try{
    return new Promise((resolve, reject) => {
      if (orderData.data[0].status == "PARTIALLYCOMPLETED" || orderData.data[0].status == "EXECUTED" || orderData.data[0].traded_quantity > 0) {
        this.transactionService.getTradeBookFromOrderId(orderData.data[0].order_id, []).then((tradeBookResponse: any) => {
          if (tradeBookResponse.status) {
            resolve(tradeBookResponse.data);
          }
        }, error => {
          resolve([]);
        })

      } else {
        resolve([]);
      }

    });
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'fetchTradeBookDataforOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  showFilterForNetposition() {
    try {
      this.sortFilterPopupPosition = !this.sortFilterPopupPosition;
      this.checkForPositionFilterPopupUpElementRendrer();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("TransactionPage", "showFilterForNetposition", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'showFilterForNetposition', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  createNetpositionData() {
    try {
      this.filterNetpositionDataDaily = [];
      this.filterNetpositionDataExpiry = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysDaily);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeysExpiry);
      if (this.selectedSegment == 'All' || this.selectedSegment == 'Equity' || this.selectedSegment == 'Currency' || this.selectedSegment == 'Equity FAO') {
        this.netPositionDataDaily = this.netPositionDataTempNonIntropDaily;
        this.netPositionDataExpiry = this.netPositionDataTempNonIntropExpiry;
      } else {
        this.netPositionDataDaily = this.netPositionDataTempIntropDaily;
        this.netPositionDataExpiry = this.netPositionDataTempIntropExpiry;
      }


      this.filterNetpositionDataDaily = this.netPositionDataDaily;
      this.filterNetpositionDataExpiry = this.netPositionDataExpiry;
    } catch (error) {
      //console.log("Error + createNetpositionData" + error.message);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'createNetpositionData', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'createNetpositionData', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  createBroadcastforNetpositionDaily() {
    try {
      for (let index = 0; index < this.netPositionDataDaily.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.netPositionDataDaily[index].isCombined ? this.netPositionDataDaily[index].preferred_scrip_token : this.netPositionDataDaily[index].scrip_token;
        objScrpKey.MktSegId = this.netPositionDataDaily[index].isCombined ? this.netPositionDataDaily[index].preferred_mktSegId : this.netPositionDataDaily[index].mktSegId;
        this.netPositionScripKeysDaily.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.netPositionScripKeysDaily);
    } catch (error) {
      console.log("Error + createBroadcastforNetpositionDaily" + error);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'createBroadcastforNetpositionDaily', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'createBroadcastforNetpositionDaily', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  createBroadcastforNetpositionExpiry() {
    try {
      for (let index = 0; index < this.netPositionDataExpiry.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.netPositionDataExpiry[index].isCombined ? this.netPositionDataExpiry[index].preferred_scrip_token : this.netPositionDataExpiry[index].scrip_token;
        objScrpKey.MktSegId = this.netPositionDataExpiry[index].isCombined ? this.netPositionDataExpiry[index].preferred_mktSegId : this.netPositionDataExpiry[index].mktSegId;
        this.netPositionScripKeysExpiry.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.netPositionScripKeysExpiry);
    } catch (error) {
      console.log("Error + createBroadcastforNetpositionExpiry" + error);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'createBroadcastforNetpositionExpiry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'createBroadcastforNetpositionExpiry', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  setPositionFilter(filterName: any, filterValue: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          this.positionFilterObject.sortalpha = filterValue;
          break;
        case 'sortQty':
          this.positionFilterObject.sortQty = filterValue;
          break;
        case 'sortCMV':
          this.positionFilterObject.sortCMV = filterValue;
          break;
        case 'productType':
          this.positionFilterObject.productType = filterValue;
          break;
        case 'exchangeType':
          this.positionFilterObject.exchangeType = filterValue;
          break;
        case 'daysPandL':
          this.positionFilterObject['daysPandL'] = { 'sort': filterValue };
          break;
      }
    } catch (error) {
      console.log("Error + setPositionFilter" + error);
      ///clsGlobal.logManager.writeErrorLog('TransactionPage', 'setPositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'setPositionFilter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  removePositionFilter(filterName: any) {
    try {
      switch (filterName) {
        case 'sortalpha':
          delete this.positionFilterObject.sortalpha
          break;
        case 'sortCMV':
          delete this.positionFilterObject.sortCMV
          break;
        case 'sortQty':
          delete this.positionFilterObject.sortQty
          break;
        case 'productType':
          delete this.positionFilterObject.productType
          break;
        case 'exchangeType':
          delete this.positionFilterObject.exchangeType
          break;
        case 'daysPandL':
          this.minDaysPandLPosition = 0;
          this.maxDaysPandLPosition = 0;
          delete this.positionFilterObject.daysPandL;
          break;
      }

      if (this.getPositionsFiltersCount() == 0) {
        this.clearPositionFilter();
      } else {
        this.applyPositionSortFilter();
      }
    } catch (error) {
      console.log("Error + removePositionFilter" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'removePositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'removePositionFilter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  applyPositionSortFilter() {
    try {
      this.createNetpositionData();
      this.isPositionFilterApply = true;
      this.sortFilterPopupPosition = false;
      this.showExpandedPositionFilter = false;

      if (this.filterNetpositionDataDaily.length > 0) {
        if (this.minDaysPandLPosition != 0 || this.maxDaysPandLPosition != 0) {
          this.positionFilterObject['daysPandL'] = { 'min': this.minDaysPandLPosition, 'max': this.maxDaysPandLPosition, "sort": (this.positionFilterObject.daysPandL && this.positionFilterObject.daysPandL.sort ? this.positionFilterObject['daysPandL'].sort : 'asc') }
        }

        if (this.positionFilterObject.productType) {
          this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
            .filter(x => x.displayProductType == this.positionFilterObject.productType)
        }

        if (this.positionFilterObject.exchangeType) {
          this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
            .filter(x => x.displayExchange == this.positionFilterObject.exchangeType)
        }

        if (this.positionFilterObject.daysPandL) {

          if (this.positionFilterObject.daysPandL.min && this.positionFilterObject.daysPandL.min > 0) {
            this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
              .filter(x => parseFloat(x.mtm) > parseFloat(this.positionFilterObject.daysPandL.min));
          }

          if (this.positionFilterObject.daysPandL.max && this.positionFilterObject.daysPandL.max > 0) {
            this.filterNetpositionDataDaily = this.filterNetpositionDataDaily
              .filter(x => parseFloat(x.mtm) < parseFloat(this.positionFilterObject.daysPandL.max));
          }



          if (this.positionFilterObject.daysPandL.sort) {
            if (this.positionFilterObject.daysPandL.sort == 'asc') {
              this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(a.mtm).toFixed(2) < parseFloat(b.mtm).toFixed(2) ? 1 : -1))

            } else if (this.positionFilterObject.daysPandL.sort == 'desc') {
              this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(b.mtm).toFixed(2) < parseFloat(a.mtm).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.positionFilterObject.sortQty) {
          if (this.positionFilterObject.sortQty == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseInt(a.net_quantity) > parseInt(b.net_quantity) ? 1 : -1))
          } else if (this.positionFilterObject.sortQty == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseInt(b.net_quantity) > parseInt(a.net_quantity) ? 1 : -1))
          }
        }
        if (this.positionFilterObject.sortCMV) {
          if (this.positionFilterObject.sortCMV == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(a.CMV).toFixed(2) < parseFloat(b.CMV).toFixed(2) ? 1 : -1))
          } else if (this.positionFilterObject.sortCMV == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => (parseFloat(b.CMV).toFixed(2) < parseFloat(a.CMV).toFixed(2) ? 1 : -1))
          }

        }
        if (this.positionFilterObject.sortalpha) {
          if (this.positionFilterObject.sortalpha == 'asc') {
            this.filterNetpositionDataDaily.sort((a, b) => {
              return a.symbol.localeCompare(b.symbol);
            })
          } else if (this.positionFilterObject.sortalpha == 'desc') {
            this.filterNetpositionDataDaily.sort((a, b) => {
              return b.symbol.localeCompare(a.symbol);
            })
          }
        }
      }

      if (this.filterNetpositionDataExpiry.length > 0) {
        if (this.minDaysPandLPosition != 0 || this.maxDaysPandLPosition != 0) {
          this.positionFilterObject['daysPandL'] = { 'min': this.minDaysPandLPosition, 'max': this.maxDaysPandLPosition, "sort": (this.positionFilterObject.daysPandL && this.positionFilterObject.daysPandL.sort ? this.positionFilterObject['daysPandL'].sort : 'asc') }
        }

        if (this.positionFilterObject.productType) {
          this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
            .filter(x => x.displayProductType == this.positionFilterObject.productType)
        }

        if (this.positionFilterObject.exchangeType) {
          this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
            .filter(x => x.displayExchange == this.positionFilterObject.exchangeType)
        }

        if (this.positionFilterObject.daysPandL) {

          if (this.positionFilterObject.daysPandL.min && this.positionFilterObject.daysPandL.min > 0) {
            this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
              .filter(x => parseFloat(x.mtm) > parseFloat(this.positionFilterObject.daysPandL.min));
          }

          if (this.positionFilterObject.daysPandL.max && this.positionFilterObject.daysPandL.max > 0) {
            this.filterNetpositionDataExpiry = this.filterNetpositionDataExpiry
              .filter(x => parseFloat(x.mtm) < parseFloat(this.positionFilterObject.daysPandL.max));
          }



          if (this.positionFilterObject.daysPandL.sort) {
            if (this.positionFilterObject.daysPandL.sort == 'asc') {
              this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(a.mtm).toFixed(2) < parseFloat(b.mtm).toFixed(2) ? 1 : -1))

            } else if (this.positionFilterObject.daysPandL.sort == 'desc') {
              this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(b.mtm).toFixed(2) < parseFloat(a.mtm).toFixed(2) ? 1 : -1))
            }
          }
        }

        if (this.positionFilterObject.sortQty) {
          if (this.positionFilterObject.sortQty == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseInt(a.net_quantity) > parseInt(b.net_quantity) ? 1 : -1))
          } else if (this.positionFilterObject.sortQty == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseInt(b.net_quantity) > parseInt(a.net_quantity) ? 1 : -1))
          }
        }
        if (this.positionFilterObject.sortCMV) {
          if (this.positionFilterObject.sortCMV == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(a.CMV).toFixed(2) < parseFloat(b.CMV).toFixed(2) ? 1 : -1))
          } else if (this.positionFilterObject.sortCMV == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => (parseFloat(b.CMV).toFixed(2) < parseFloat(a.CMV).toFixed(2) ? 1 : -1))
          }

        }
        if (this.positionFilterObject.sortalpha) {
          if (this.positionFilterObject.sortalpha == 'asc') {
            this.filterNetpositionDataExpiry.sort((a, b) => {
              return a.symbol.localeCompare(b.symbol);
            })
          } else if (this.positionFilterObject.sortalpha == 'desc') {
            this.filterNetpositionDataExpiry.sort((a, b) => {
              return b.symbol.localeCompare(a.symbol);
            })
          }
        }
      }
      this.createBroadcastforNetpositionDaily();
      this.createBroadcastforNetpositionExpiry();
    } catch (error) {
      console.log("Error + applyPositionSortFilter" + error);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'applyPositionSortFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'applyPositionSortFilter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  clearPositionFilter() {
    try {
      this.isPositionFilterApply = false;
      this.sortFilterPopupPosition = false;
      this.positionFilterObject = {};
      this.minDaysPandLPosition = 0;
      this.maxDaysPandLPosition = 0;
      this.showExpandedPositionFilter = false;
      this.createNetpositionData();
      this.createBroadcastforNetpositionDaily();
      this.createBroadcastforNetpositionExpiry();
    } catch (error) {
      console.log("Error clearPositionFilter" + error);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'clearPositionFilter', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'clearPositionFilter', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  getPositionsFiltersCount() {
    try {
      return Object.keys(this.positionFilterObject).length;
    } catch (error) {
      console.log("Error getPositionsFiltersCount" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'getPositionsFiltersCount', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getPositionsFiltersCount', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  checkForPositionFilterPopupUpElementRendrer() {
    try {
      const divElement: HTMLElement = document.getElementById('divpositionFilterPopup');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForPositionFilterPopupUpElementRendrer();
        }, 100);
      } else {
        //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
        setTimeout(() => {
          const divElement: HTMLElement = document.getElementById('divpositionFilterPopup');
          this.positionFilterPopupBottomToTop(divElement);
        }, 500);
      }
    } catch (error) {
      //console.log("Error checkForPositionFilterPopupUpElementRendrer" + error);
      //clsGlobal.logManager.writeErrorLog('PortfolioPage', 'checkForPositionFilterPopupUpElementRendrer', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'checkForPositionFilterPopupUpElementRendrer', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  positionFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: true // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (240), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 800,
        buttonClose: false,
        backdrop: true, //added by om on 24 th jan for backdrop display.
        onDragEnd: () => {
          //console.log("onDragEnd");
          let topDiv = this.divPositionFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedPositionFilter = true;
          } else {
            this.showExpandedPositionFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closePositionFilterPopup();
        }
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        // onTransitionEnd: () => {
        //   ////console.log("onTransitionEnd ends"); 
        //   //console.log("onTransitionEnd")
        // },
        // onDrag: () => {
        //   //  //console.log("onDrag");
        // }
      }
      this.positionFilterPane = new CupertinoPane(myElementRef, setting);
      this.positionFilterPane.enableDrag();
      this.positionFilterPane.present({ animate: true });
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "positionFilterPopupBottomToTop", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'positionFilterPopupBottomToTop', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  scrollPositionFilterDetails(event) {
    if (event.target.scrollTop > 20) {
      this.positionFilterPane.moveToBreak('top');
      this.showExpandedPositionFilter = true;
    }
  }

  closePositionFilterPopup() {
    try {
      this.sortFilterPopupPosition = false;
      this.showExpandedPositionFilter = false;
      this.positionFilterPane.destroy({ animate: true });
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "closePositionFilterPopup", error);
    }
  }

  onMultilegOrderLegChange(selectedLeg) {
    this.selectedMultilegOrderLeg = selectedLeg;
    this.showMultilegSelection = false;
  }

  showMultilegSelectionPopup() {
    this.showMultilegSelection = true;
  }

  showOrderType() {
    this.showOrderTypePopup = !this.showOrderTypePopup;
  }

  closeOrderType() {
    this.showOrderTypePopup = false;
  }

  cancelSpreadMultilegOrder(order) {
    try{
    if (this.showSpreadCancelOrderPopup) {
      this.isSpreadCancelOrderClick = true;
      let reqBody: any = {};
      if(order.leg_indicator.toUpperCase() == 'SPREAD')
      {
        reqBody =
        {
          "type": order.leg_indicator.toUpperCase(),
          "validity": order.validity,
          "prot_perc": "",
          "leg_details":
            [
              {
                "leg_no": 1,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_1.scrip_token,
                  "symbol": order.leg_no_1.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_1.expiry_date),
                  "strike_price": (order.leg_no_1.strike_price == -1 || order.leg_no_1.strike_price == 'NA') ? '' : (order.leg_no_1.strike_price / order.leg_no_1.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_1.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_1.option_type,
                  "instrument_name": order.leg_no_1.instrument
                },
                "transaction_type": order.leg_no_1.transaction_type.toUpperCase(),
                "quantity": order.leg_no_1.total_quantity,
                "price": order.leg_no_1.order_price,
                "others": {
                  "market_lot": order.leg_no_1.market_lot,
                  "price_tick": order.leg_no_1.price_tick,
                  "decimal_loc": order.leg_no_1.dec_loc
                }
              },
              {
                "leg_no": 2,
                "transaction_type": order.leg_no_2.transaction_type.toUpperCase(),
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_2.scrip_token,
                  "symbol": order.leg_no_1.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_2.expiry_date),
                  "strike_price": (order.leg_no_2.strike_price == -1 || order.leg_no_2.strike_price == 'NA') ? '' : (order.leg_no_2.strike_price / order.leg_no_2.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_2.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_2.option_type,
                  "instrument_name": order.leg_no_2.instrument
                },
                "quantity": order.leg_no_2.total_quantity,
                "price": order.leg_no_1.order_price,
                "others": {
                  "market_lot": order.leg_no_2.market_lot,
                  "price_tick": order.leg_no_2.price_tick,
                  "decimal_loc": order.leg_no_2.dec_loc
                }
              }
            ]
        }
      }
      else if(order.leg_indicator.toUpperCase() == '2L')
      {
        reqBody =
        {
          "type": order.leg_indicator.toUpperCase(),
          "validity": order.validity,
          "prot_perc": "",
          "leg_details":
            [
              {
                "leg_no": 1,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_1.scrip_token,
                  "symbol": order.leg_no_1.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_1.expiry_date),
                  "strike_price": (order.leg_no_1.strike_price == -1 || order.leg_no_1.strike_price == 'NA') ? '' : (order.leg_no_1.strike_price / order.leg_no_1.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_1.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_1.option_type,
                  "instrument_name": order.leg_no_1.instrument
                },
                "transaction_type": order.leg_no_1.transaction_type.toUpperCase(),
                "quantity": order.leg_no_1.total_quantity,
                "price": order.leg_no_1.order_price,
                "others": {
                  "market_lot": order.leg_no_1.market_lot,
                  "price_tick": order.leg_no_1.price_tick,
                  "decimal_loc": order.leg_no_1.dec_loc
                }
              },
              {
                "leg_no": 2,
                "transaction_type": order.leg_no_2.transaction_type.toUpperCase(),
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_2.scrip_token,
                  "symbol": order.leg_no_2.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_2.expiry_date),
                  "strike_price": (order.leg_no_2.strike_price == -1 || order.leg_no_2.strike_price == 'NA') ? '' : (order.leg_no_2.strike_price / order.leg_no_2.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_2.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_2.option_type,
                  "instrument_name": order.leg_no_2.instrument
                },
                "quantity": order.leg_no_2.total_quantity,
                "price": order.leg_no_2.order_price,
                "others": {
                  "market_lot": order.leg_no_2.market_lot,
                  "price_tick": order.leg_no_2.price_tick,
                  "decimal_loc": order.leg_no_2.dec_loc
                }
              }
            ]
        }
      }
      else if(order.leg_indicator.toUpperCase() == '3L')
      {
        reqBody =
        {
          "type": order.leg_indicator.toUpperCase(),
          "validity": order.validity,
          "prot_perc": "",
          "leg_details":
            [
              {
                "leg_no": 1,
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_1.scrip_token,
                  "symbol": order.leg_no_1.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_1.expiry_date),
                  "strike_price": (order.leg_no_1.strike_price == -1 || order.leg_no_1.strike_price == 'NA') ? '' : (order.leg_no_1.strike_price / order.leg_no_1.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_1.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_1.option_type,
                  "instrument_name": order.leg_no_1.instrument
                },
                "transaction_type": order.leg_no_1.transaction_type.toUpperCase(),
                "quantity": order.leg_no_1.total_quantity,
                "price": order.leg_no_1.order_price,
                "others": {
                  "market_lot": order.leg_no_1.market_lot,
                  "price_tick": order.leg_no_1.price_tick,
                  "decimal_loc": order.leg_no_1.dec_loc
                }
              },
              {
                "leg_no": 2,
                "transaction_type": order.leg_no_2.transaction_type.toUpperCase(),
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_2.scrip_token,
                  "symbol": order.leg_no_2.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_2.expiry_date),
                  "strike_price": (order.leg_no_2.strike_price == -1 || order.leg_no_2.strike_price == 'NA') ? '' : (order.leg_no_2.strike_price / order.leg_no_2.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_2.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_2.option_type,
                  "instrument_name": order.leg_no_2.instrument
                },
                "quantity": order.leg_no_2.total_quantity,
                "price": order.leg_no_2.order_price,
                "others": {
                  "market_lot": order.leg_no_2.market_lot,
                  "price_tick": order.leg_no_2.price_tick,
                  "decimal_loc": order.leg_no_2.dec_loc
                }
              },
              {
                "leg_no": 3,
                "transaction_type": order.leg_no_3.transaction_type.toUpperCase(),
                "scrip_info": {
                  "exchange": clsTradingMethods.getApiExchangeName(order.mktSegId),
                  "scrip_token": order.leg_no_3.scrip_token,
                  "symbol": order.leg_no_3.symbol.trim(),
                  "series": 'XX',
                  "expiry_date": this.getDate(order.leg_no_3.expiry_date),
                  "strike_price": (order.leg_no_3.strike_price == -1 || order.leg_no_3.strike_price == 'NA') ? '' : (order.leg_no_3.strike_price / order.leg_no_3.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(order.mktsegid, order.leg_no_3.dec_loc.toString().length - 1)),
                  "option_type": order.leg_no_3.option_type,
                  "instrument_name": order.leg_no_3.instrument
                },
                "quantity": order.leg_no_3.total_quantity,
                "price": order.leg_no_3.order_price,
                "others": {
                  "market_lot": order.leg_no_3.market_lot,
                  "price_tick": order.leg_no_3.price_tick,
                  "decimal_loc": order.leg_no_3.dec_loc
                }
              }
            ]
        }
      }
      this.transactionService.modifyOrCancelSpreadOrder(reqBody,order.gateway_order_no,'cancel')
        .then((response: any) => {
          this.showConfirmDialogPopup("Your Order for " + this.selectedOrder.symbol + " " + this.selectedOrder.displayScripDesc + " has been cancelled", "", false);
          this.showOrderDetailsPopup = false;
          this.showSpreadCancelOrderPopup = false
          this.isSpreadCancelOrderClick = false;
        }).catch(error => {
          this.showOrderDetailsPopup = false;
          this.showSpreadCancelOrderPopup = false;
          this.isSpreadCancelOrderClick = false;
        });
    } else {
      this.showSpreadCancelOrderPopup = true;

    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'cancelSpreadMultilegOrder', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  modifySpreadOrder(order) {
    try{
    this.spreadDetails = [];
    if (clsGlobal.User.isGuestUser) {
      this.alertCtrl.showAlert(
        "Register now to access this feature!",
        "Order Error!"
      );
      return;
    }
    //let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
    let ScripObj = this.getScripObject(order);;
    // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
    let SegmentId = ScripObj.scripDetail.scripDet.MktSegId;
    if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }
    this.getSpreadLegDetails(order.mktSegId, order.leg_no_1);
    this.getSpreadLegDetails(order.mktSegId, order.leg_no_2);
    let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
    objOEFormDetail.scripDetl = ScripObj.scripDetail;
    objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
    objOEFormDetail.gwOrderNo = order.gateway_order_no;
    objOEFormDetail.spreadDetails = this.spreadDetails;
    objOEFormDetail.spreadQty = order.leg_no_1.total_quantity;
    objOEFormDetail.qtyOrlot = order.qtyCaption;
    objOEFormDetail.validity = order.validity;
    this.paramService.myParam = objOEFormDetail;
    this.navCtrl.navigateForward('spread-orderentry');
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'modifySpreadOrder', error.Message, undefined, error.stack, undefined, undefined));
  }

  }

  getScripObject(order) {
try{
    let objScrpKey = new clsScripKey();

    objScrpKey.MktSegId = parseInt(order.mktSegId);
    objScrpKey.token = order.spread_token;

    let scripInfo: clsScrip = new clsScrip();
    scripInfo.scripDet = objScrpKey;
    scripInfo.symbol = order.spread_symbol.trim();
    scripInfo.Series = 'XX';
    scripInfo.DecimalLocator = parseFloat(order.leg_no_1.dec_loc) == 0 ? 100 : order.leg_no_1.dec_loc;
    scripInfo.InstrumentName = order.leg_no_1.instrument.trim();
    scripInfo.ExpiryDate = '';
    scripInfo.OptionType = order.leg_no_1.option_type;
    scripInfo.MarketLot = order.leg_no_1.market_lot;
    scripInfo.PriceTick = order.leg_no_1.price_tick;
    scripInfo.SecurityDesc = order.displayScripDesc;
    // scripInfo.MWSecurityDesc = this.spreadDetails[0].sSecurityDesc.trim();
    scripInfo.StrikePrice = (order.leg_no_1.strike_price == -1 || order.leg_no_1.strike_price == 'NA') ? '' : order.leg_no_1.strike_price;
    scripInfo.ISIN = "";
    scripInfo.SPOS = "";
    scripInfo.POS = "";
    //scripInfo.Quantity = this.spreadDetails[0].nRegularLot;
    //scripInfo.AssetToken = this.spreadDetails[0].nAssetToken;
    scripInfo.FIILimit = "";
    scripInfo.NRILimit = "";
    //scripInfo.Spread = this.spreadDetails[0].nSpread;
    //scripInfo.MarginTypeIndicator = this.spreadDetails[0].nMarginTypeIndicator;
    if (order.leg_no_1.instrument.trim().indexOf('IDX') != -1) {
      scripInfo.isIndex = true;
    }
    else {
      scripInfo.isIndex = false;
    }

    scripInfo.formatScripDisplayName()

    let idData = new clsIndexDetail();
    idData.scripDetail = scripInfo;
    return idData;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getScripObject', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  getSpreadLegDetails(mktsegid, order) {
    try{
    let legDate = this.getDate(order.expiry_date);
    let legDetails = {
      legexpiryDate: legDate,
      legexpiryDayIOS: legDate.substr(2, 3) + '/' + legDate.substr(0, 2) + '/' + legDate.substr(-4),
      // legexpiryDay : legexpiryDate.substr(0,2),
      // legexpiryMonth : legexpiryDate.substr(2,3),
      legsymbol: order.symbol.trim(),
      legseries: 'XX',
      legoptionType: order.option_type.trim(),
      leginstrumentName: order.instrument,
      //leginstru : leginstrumentName.substr(0,3),
      originallegLot: order.market_lot,
      legstrikePrice: (order.strike_price == -1 || order.strike_price == 'NA') ? '' : (order.strike_price / order.dec_loc).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(mktsegid, order.dec_loc.toString().length - 1)),
      legToken: order.scrip_token,
      legDecimalLocator: order.dec_loc,
      legmktsegid: mktsegid,
      legmapmktsegid: clsTradingMethods.getMappedMarketSegmentId(mktsegid),
      legpricetick: order.price_tick,
      legexchangename: clsTradingMethods.getExchangeName(mktsegid),
      legpriceprecision: clsGlobal.ExchManager.returnPrecisionForPrice(mktsegid, order.dec_loc.toString().length - 1),
      legprice: order.order_price,
      legopenclose: false,
      legbuysell: order.transaction_type,
      sellimitlegPrice: '',
      selmarketlegPrice: '0.00',
      legpricetoggle: 'marketlegPrice',
      removeLeg: false,
      isin: '',
      securitydesc: order.displayScripDesc,
      fiilimit: '',
      nrilimit: '',
    }
    this.spreadDetails.push(legDetails);
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('TransactionPage', 'getSpreadLegDetails', error.Message, undefined, error.stack, undefined, undefined));
  }
  }

  getDate(date) {
    let datearray = date.split('-');
    return datearray[2] + clsCommonMethods.getMonthFormat(datearray[1]) + datearray[0];
  }

  closeSpreadCancelorderPopup() {
    this.showSpreadCancelOrderPopup = false;
  }
}