import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { OrderentryPageRoutingModule } from './orderentry-routing.module';
import { OrderentryPage } from './orderentry.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComponentsModule,
    OrderentryPageRoutingModule,
  ],
    
  declarations: [OrderentryPage]
})
export class OrderentryPageModule {}
