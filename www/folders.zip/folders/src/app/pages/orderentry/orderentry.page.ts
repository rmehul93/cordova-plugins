import { Component, OnInit, ViewChild } from '@angular/core';
import { clsOEFormDetl } from '../../Common/clsOrderEntryFormDetl';
import { Platform, ModalController, NavController, } from '@ionic/angular';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { TranslateService } from '@ngx-translate/core';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { Router } from '@angular/router';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { PopupOrderentryComponent } from 'src/app/components/popup-orderentry/popup-orderentry.component';

@Component({
  selector: 'app-orderentry',
  templateUrl: './orderentry.page.html'
})
export class OrderentryPage implements OnInit {

  objOEDetail: clsOEFormDetl;
  @ViewChild('popupOE') objPopupOE: PopupOrderentryComponent;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public clsLocalStorage: clsLocalStorageService,
    public translate: TranslateService,
    public platform: Platform,
    public router: Router,
    private paramService: NavParamService,
  ) {
    this.objOEDetail = this.paramService.myParam;
  }

  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      //clsGlobal.User.exchangesList = res.data.product_types;
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
    }
  }
  ionViewDidLoad(){
    clsGlobal.logManager.writeUserAnalytics("OrderEntryPage","","VISIT",""); 
  }
  /**
   * @method : Send Best five subscription request Order Entry
   */
  ionViewWillEnter() {
    try {
      //this.objOEDetail = this.paramService.myParam;
      this.objPopupOE.sendSubscritionRequest();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
    }
  }

  ionViewWillLeave() {
    try {
      //this.objOEDetail = this.paramService.myParam;
      this.objPopupOE.ionViewWillLeave();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ionViewWillLeave", error);
    }
  }

  receiveMessage($event) {
    try {
      this.closeOrderEntry();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "receiveMessage", error);
    }
  }

  /**
   * @method : close Order Entry pop up and go back to previous page
   */
  closeOrderEntry() {
    try {
      this.navCtrl.pop();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "closeOrderEntry", error);
    }
  }
}
