import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdvanceChartIqPage } from './advance-chart-iq.page';

const routes: Routes = [
  {
    path: '',
    component: AdvanceChartIqPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdvanceChartIqPageRoutingModule {}
