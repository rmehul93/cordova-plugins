import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { NavController, Platform } from '@ionic/angular';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
declare let d3: any;
@Component({
  selector: 'app-advance-chart-iq',
  templateUrl: './advance-chart-iq.page.html',
})
export class AdvanceChartIqPage implements OnInit {
  chartUrl: any = this.sanitizer.bypassSecurityTrustResourceUrl("about:blank");
  selectedScrip: any;
  broadcastMode: any;
  bcastHandler: any;
  chartIntradayDetails: any = [];
  chartIntradayCandleDetails: any = [];
  chartTimeInterval: any;
  options;
  data = [];
  chartTypeOptionArry = [
    {
      Display: 'Candle',
      value: 1
    },
    {
      Display: 'Line',
      value: 2
    },
    {
      Display: 'Area',
      value: 3
    },
  ];
  historicOptionArry = [
    {
      Display: '5D',
      value: 5
    },
    {
      Display: '1M',
      value: 30
    },
    {
      Display: '1Y',
      value: 260
    },
    {
      Display: '2Y',
      value: 520
    },
    {
      Display: '5Y',
      value: 1300
    },
    {
      Display: 'MAX',
      value: 0
    }
  ];
  userSelectedChartType: any;
  userHistoricSelectedChartType: any;
  showTypeSelectpopup: boolean = false;
  showTimeSelectpopup: boolean = false;
  plotColor: any = '#ffc107';
  chartType: any = 'INTRADAY';
  chartHistoric5DDetails: any = [];
  chartHistoric5DCandleDetails: any = [];
  chartHistoric30DDetails: any = [];
  chartHistoric30DCandleDetails: any = [];
  chartHistoric260DDetails: any = [];
  chartHistoric260DCandleDetails: any = [];
  chartHistoric520DDetails: any = [];
  chartHistoric520DCandleDetails: any = [];
  chartHistoric1300DDetails: any = [];
  chartHistoric1300DCandleDetails: any = [];
  chartHistoricMaxDetails: any = [];
  chartHistoricMaxCandleDetails: any = [];
  isHistoric: boolean = false;
  isChartIQ: boolean = false;
  objScrip: any;
  screenOrientation: any
  charLandscape: boolean = false;
  constructor(private navCtrl: NavController,
    private navParams: NavParamService, private sanitizer: DomSanitizer, public alertCtrl: AlertServicesProvider,
    public http: clsHttpService, private platform: Platform,
    private toastCtrl: ToastServicesProvider, private screenplugin: ScreenOrientation
  ) { }
  ngOnInit() {
    console.log("Inside advance chart.");
    this.selectedScrip = this.navParams.myParam;
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CHART_TIME_INTERVAL) != undefined) {
      this.chartTimeInterval = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CHART_TIME_INTERVAL));
    }
    else {
      this.chartTimeInterval = clsConstants.CHART_TIME_INTERVAL;
    }
    if (clsGlobal.dConfigMaster.getItem("APP_CHART_URL").toString() != "" && clsGlobal.dConfigMaster.getItem("APP_CHART_URL").toString() != undefined) {
      this.isChartIQ = true;
      this.setChartUrl();
      this.chartUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.chartUrl);
    }
    else {
      this.isChartIQ = false;
      this.userSelectedChartType = this.chartTypeOptionArry[1];
      this.getIntradayChartDetails();
    }
  }
  deviceRotation() {
    if (window.innerWidth > window.innerHeight)
      alert("Window resize height " + window.innerHeight + ", width : " + window.innerWidth);
    if (screen.orientation.type == "landscape-primary" || screen.orientation.type == "landscape-secondary") {
      clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "LANDSCAPE");
    }
    else if (screen.orientation.type == "portrait-primary" || screen.orientation.type == "portrait-secondary") {
      clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "PORTRAIT");
    }
  }
  deviceRotationChange() {
    alert("Rotation change." + screen.orientation.type);
    if (screen.orientation.type == "landscape-primary" || screen.orientation.type == "landscape-secondary") {
      clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "LANDSCAPE");
    }
    else if (screen.orientation.type == "portrait-primary" || screen.orientation.type == "portrait-secondary") {
      clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "PORTRAIT");
    }
  }
  ionViewWillEnter() {
    try {
      if (this.platform.is('cordova')) {
        // window.screen.orientation.unlock(); 
        this.screenplugin.unlock();
      }
    } catch (error) {
      alert("Error in screen rotaion.");
    }
    try {
      clsGlobal.pubsub.subscribe('ORIENTATIONCHANGE', (data: any) => {
        if (data == "PORTRAIT")
          this.charLandscape = false;
        else
          this.charLandscape = true;
      });
      // detect orientation changes
      this.screenplugin.onChange().subscribe(
        () => {
          if (this.screenplugin.type == "landscape-primary" || this.screenplugin.type == "landscape-secondary") {
            clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "LANDSCAPE");
          }
          else if (this.screenplugin.type == "portrait-primary" || this.screenplugin.type == "portrait-secondary") {
            clsGlobal.pubsub.publish("ORIENTATIONCHANGE", "PORTRAIT");
          }
        }
      );
    } catch (error) {
      alert("Error in orientation." + error.message);
    }
    try {
      if (this.selectedScrip != undefined) {
        this.bcastHandler = this.receiveTouchlineResponse.bind(this);
        clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
        this.sendTouchlineRequest(OperationType.ADD, this.selectedScrip.scripDet);
        //assing values to chart broadcast object.
        this.objScrip = {};
        this.objScrip.MktSegId = this.selectedScrip.scripDet.MktSegId;
        this.objScrip.Token = this.selectedScrip.scripDet.token;
        //this.broadcastMode = (clsGlobal.dConfigMaster.getItem("APP_CHART_BROADCAST") == undefined ? 'n' : clsGlobal.dConfigMaster.getItem("APP_CHART_BROADCAST"));
        //this.chartUrl = clsGlobal.dConfigMaster.getItem("APP_CHART_URL").toString();  //key 
        //this.chartUrl = 'http://beyond.nirmalbang.org/ChartIQ_HTML/?broadcastMode=n&range=n&ver=v1&mode=adv&mktsegid=1&tkn=10440&period=1&interval=MIN&style=candle&span=&continuous=&title=n&headsup=y&xaxis=y&yaxis=y&hdr=y&zoom=y&buysell=n&theme=d&group=g1&apikey=0HVTVTkNzEg7Dwjd80T0bXbO8t8FThd&uid=L3565';
        if (this.selectedScrip != undefined) {
          if (clsGlobal.User.Holding != undefined && clsGlobal.User.Holding.length > 0) {
            let holdingScrip = clsGlobal.User.Holding.filter(item => {
              return item.nMarketSegmentId == this.selectedScrip.scripDet.MapMktSegId &&
                item.nToken == this.selectedScrip.scripDet.token;
            });
            if (holdingScrip.length > 0) {
              this.selectedScrip.holding = holdingScrip[0];
            }
          }
        }
      }
    } catch (error) {
      console.log("Error + ngOnInit" + error);
      clsGlobal.logManager.writeErrorLog('AdvanceChartPage', 'sendTouchlineRequest', error);
    }
  }
  rotatePhone(type) {
    //manually set orientation on button click.
    try {
      if (type == "L") {
        if (this.platform.is('cordova')) 
        this.screenplugin.lock(this.screenplugin.ORIENTATIONS.LANDSCAPE);
        this.charLandscape = true;
      }
      else {
        if (this.platform.is('cordova')) 
        this.screenplugin.lock(this.screenplugin.ORIENTATIONS.PORTRAIT);
        this.charLandscape = false;
      } 
    } catch (error) {
      console.log("Rotation click not working.");
    }
  }
  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.selectedScrip.scripDet);  
      clsGlobal.pubsub.unsubscribe('ORIENTATIONCHANGE', null);//unsubscribe events reading.
      if (this.platform.is('cordova'))  
      this.screenplugin.lock(this.screenplugin.ORIENTATIONS.PORTRAIT); 
    }
    catch (e) {
      console.log("Error in ionVIewLeave advance chart." + e);
    }
  }
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {
      if (scripList != null && scripList != undefined) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList.push(scripList);
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('AdvanceChartPage', 'sendTouchlineRequest', error);
    }
  }
  /**
    * Receive broadcast and bind to html
    * @param objMultiTLResp
    */
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      if (objMultiTLResp != null && this.selectedScrip != undefined) {
        if (this.selectedScrip.scripDet.MktSegId == objMultiTLResp.Scrip.MktSegId &&
          this.selectedScrip.scripDet.token == objMultiTLResp.Scrip.token) {
          if (this.selectedScrip.LTP > objMultiTLResp.LTP) {
            this.selectedScrip.LTPChangeCss = "sell-ltp-change";
          }
          else if (this.selectedScrip.LTP < objMultiTLResp.LTP) {
            this.selectedScrip.LTPChangeCss = "buy-ltp-change";
          }
          else {
            this.selectedScrip.LTPChangeCss = "";
          }
          this.selectedScrip.LTP = objMultiTLResp.LTP;
          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
          this.selectedScrip.NetChangeInRs = arrNetChange[0];
          this.selectedScrip.PercNetChange = arrNetChange[1];
          this.selectedScrip.LTPTrend = arrNetChange[2];
          this.selectedScrip.PercNetChangeRaw = arrNetChange[3];
          this.selectedScrip.BuyPrice = objMultiTLResp.BuyPrice;
          this.selectedScrip.BuyQty = objMultiTLResp.BuyQty;
          this.selectedScrip.SellPrice = objMultiTLResp.SellPrice;
          this.selectedScrip.SellQty = objMultiTLResp.SellQty;
          //Send data to chart frame.//if broadcastmode is n then we will send broadcast to chart.
          if (this.broadcastMode == 'n')
            this.sendDataToChart(objMultiTLResp);
        }
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('AdvanceChartPage.', 'receiveTouchlineResponse', error);
    }
  }
  /**
  * Method to send data to chart iq frame.
  * This method getelementById from dom using id iframecheck
  *  Iframe tag in html should contian id field with value iframecheck
  * @param broadcastdata
  */
  sendDataToChart(broadcastdata: clsMultiTouchLineResponse) {
    try {
      var data: any =
      {
        messageCode: 'chartiq-bCast',
        data: {
          Scrip: this.objScrip,
          LUT: broadcastdata.LUT,
          LTP: broadcastdata.LTP,
          LTQ: broadcastdata.LTQ,
          Volume: broadcastdata.Volume,
          ClosePrice: broadcastdata.ClosePrice,
          OpenPrice: broadcastdata.OpenPrice,
          HighPrice: broadcastdata.HighPrice,
          LowPrice: broadcastdata.LowPrice
        }
      };
      console.log("Data send to chart : " + JSON.stringify(data));
      //var frame = document.getElementById('iframechart').contentWindow;
      var frame;
      //to handle multiple frame return from getElementsByTagName.
      if (document.getElementsByTagName("iframe")[0].id == "iframechart")//means quotes frame.
        frame = document.getElementsByTagName("iframe")[1].contentWindow;
      else
        frame = document.getElementsByTagName("iframe")[0].contentWindow;//means only one frame available.
      frame.postMessage(data, '*');
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('AdvanceChartPage', 'sendDataToChart', error);
      console.log(error);
    }
  }
  setChartUrl() {
    try {
      //broadcastMode=n means chart page will not create socket , we will send data.
      //broadcastMode= y means we will not send data to chart iq.
      this.broadcastMode = (clsGlobal.dConfigMaster.getItem("APP_CHART_BROADCAST") == undefined ? 'n' : clsGlobal.dConfigMaster.getItem("APP_CHART_BROADCAST"));
      this.chartUrl = clsGlobal.dConfigMaster.getItem("APP_CHART_URL").toString()  //key
        //this.chartUrl="http://nbtrade.nirmalbang.org/chartiq_html/?range=n&" //different server.
        //this.chartUrl='http://localhost/chartiq/?'//hosted mode
        //this.chartUrl='http://localhost:8080/?' //debug mode
        //this.chartUrl='http://beyond.nirmalbang.org/ChartIQ_HTML/?'
        + "broadcastMode=" + this.broadcastMode
        + "&range=n"
        + "&ver=v1"
        + "&mode=adv"
        + "&mktsegid=" + this.selectedScrip.scripDet.MktSegId
        + "&tkn=" + this.selectedScrip.scripDet.token
        + "&period=1"
        + "&interval=" + clsGlobal.dConfigMaster.getItem("APP_CHART_DATA_INTERVAL")  //"MIN" //KEY
        + "&style=" + clsGlobal.dConfigMaster.getItem("APP_CHART_ADVANCE_STYLE")//"candle" //KEY
        + "&span="
        + "&continuous="
        + "&title=y"
        + "&headsup=y"
        + "&xaxis=y"
        + "&yaxis=y"
        + "&hdr=y"
        + "&zoom=y"
        + "&buysell=n"
        + "&theme=" + (clsGlobal.defaultTheme == "light" ? "d" : "n")
        + "&group=g1"
        + "&apikey=" + clsGlobal.dConfigMaster.getItem("APP_CHART_API_KEY")  //"ABCD12233" //key
        //+'&apikey=0HVTVTkNzEg7Dwjd80T0bXbO8t8FThd'
        + "&uid=" + clsGlobal.User.userId;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('AdvanceChartPage', 'setChartUrl', error);
    }
  }
  showOrderEntry(buyorsell) {
    try {
      if (clsGlobal.User.isGuestUser) {
        this.alertCtrl.showAlert(
          "Register now to access this feature!",
          "Order Error!"
        );
        return;
      }
      let SegmentId = this.selectedScrip.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }
      //this.showPopUpOE = !this.showPopUpOE;
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = buyorsell == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;
      objOEFormDetail.scripDetl = this.selectedScrip;
      //objOEFormDetail.exchOrderNo
      objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
      //this.selectedScrip = objOEFormDetail;
      this.navParams.myParam = objOEFormDetail;
      this.navCtrl.navigateForward('orderentry');
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showOrderEntry', error);
    }
  }
  goBack() {
    this.navCtrl.pop();
  }
  getIntradayChartDetails() {
    let requestString = {
      MktSegId: this.selectedScrip.scripDet.MapMktSegId,
      Token: this.selectedScrip.scripDet.token,
      TimeInterval: this.chartTimeInterval
    }
    this.http.postJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId, "/getChartData", requestString) //http://172.25.91.98:8080/transactional/com.wave.test/v1/
      .subscribe(respData => {
        try {
          this.chartIntradayDetails = [];
          this.chartIntradayCandleDetails = [];
          let response = respData.result[0]
          if (response.length > 0) {
            for (let count = 0; count < response.length; count++) {
              let ltt = clsTradingMethods.convertToDateObj(parseInt(response[count].Time));
              let lttvalue = parseInt(ltt.getTime().toString()) / 10000;
              let o = parseFloat(clsTradingMethods.ConvertToRe((response[count].nOpen), this.selectedScrip.scripDet.MktSegId, "100"));
              let c = parseFloat(clsTradingMethods.ConvertToRe((response[count].nClose), this.selectedScrip.scripDet.MktSegId, "100"));
              let h = parseFloat(clsTradingMethods.ConvertToRe((response[count].nHigh), this.selectedScrip.scripDet.MktSegId, "100"));
              let l = parseFloat(clsTradingMethods.ConvertToRe((response[count].nLow), this.selectedScrip.scripDet.MktSegId, "100"));
              let v = response[count].nTotalQtyTraded.toString();
              this.chartIntradayDetails.push({ x: lttvalue, y: c });
              this.chartIntradayCandleDetails.push({ date: lttvalue, open: o, high: h, low: l, close: c, volume: parseInt(v) })
            }
            this.drawLineChart();
          }
          else {
            this.toastCtrl.showAtBottom("Unable to show chart data");
          }
        } catch (error) {
          clsGlobal.logManager.writeErrorLog('AdvanceChartIqPage', 'getIntradayChartDetails1', error);
        }
      }, error => {
        this.toastCtrl.showAtBottom("Unable to show chart data");
        clsGlobal.logManager.writeErrorLog('AdvanceChartIqPage', 'getIntradayChartDetails2', error);
      });
  }
  getHistoricChartDetails(record) {
    let requestString = {
      MktSegId: this.selectedScrip.scripDet.MapMktSegId,
      Token: this.selectedScrip.scripDet.token,
      Records: record
    }
    this.http.postJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId, "/getHistoricChartData", requestString) //http://172.25.91.98:8080/transactional/com.wave.test/v1/
      .subscribe(respData => {
        try {
          let response = respData.result[0]
          if (response.length > 0) {
            this.clearChartArea();
            this.clearChartBinding();
            for (let count = 0; count < response.length; count++) {
              let ltt = clsTradingMethods.convertToDateObj(parseInt(response[count].nLastUpdatedDate));
              let lttvalue = parseInt(ltt.getTime().toString()) / 10000;
              let data = clsTradingMethods.decryptChartData(response[count].sData)
              let splitData = data.split(',')
              let o = parseFloat(splitData[0]);
              let h = o + parseFloat(splitData[1]);
              let l = o - parseFloat(splitData[2]);
              let c = l + parseFloat(splitData[3]);
              let v = parseFloat(splitData[4]);
              let open = parseFloat(clsTradingMethods.ConvertToRe(o, this.selectedScrip.scripDet.MktSegId, "100"));
              let close = parseFloat(clsTradingMethods.ConvertToRe(c, this.selectedScrip.scripDet.MktSegId, "100"));
              let high = parseFloat(clsTradingMethods.ConvertToRe(h, this.selectedScrip.scripDet.MktSegId, "100"));
              let low = parseFloat(clsTradingMethods.ConvertToRe(l, this.selectedScrip.scripDet.MktSegId, "100"));
              let volume = v.toString();
              if (record == 5) {
                this.chartHistoric5DDetails.push({ x: lttvalue, y: close });
                this.chartHistoric5DCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
              else if (record == 30) {
                this.chartHistoric30DDetails.push({ x: lttvalue, y: close });
                this.chartHistoric30DCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
              else if (record == 260) {
                this.chartHistoric260DDetails.push({ x: lttvalue, y: close });
                this.chartHistoric260DCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
              else if (record == 520) {
                this.chartHistoric520DDetails.push({ x: lttvalue, y: close });
                this.chartHistoric520DCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
              else if (record == 1300) {
                this.chartHistoric1300DDetails.push({ x: lttvalue, y: close });
                this.chartHistoric1300DCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
              else if (record == 0) {
                this.chartHistoricMaxDetails.push({ x: lttvalue, y: close });
                this.chartHistoricMaxCandleDetails.push({ date: lttvalue, open: open, high: high, low: low, close: close, volume: parseInt(volume) });
              }
            }
            if (this.userSelectedChartType.value == 2 || this.userSelectedChartType.value == 3) {
              this.drawLineChart();
            }
            else if (this.userSelectedChartType.value == 1) {
              this.drawCandleChart();
            }
          }
          else {
            this.toastCtrl.showAtBottom("Unable to show chart data");
          }
        } catch (error) {
          clsGlobal.logManager.writeErrorLog('AdvanceChartIqPage', 'getHistoricChartDetails1', error);
        }
      }, error => {
        this.toastCtrl.showAtBottom("Unable to show chart data");
        clsGlobal.logManager.writeErrorLog('AdvanceChartIqPage', 'getHistoricChartDetails2', error);
      });
  }
  drawLineChart() {
    let details = this;
    let decimalFormat = ''
    if (details.selectedScrip.InstrumentName == "FUTCUR" || details.selectedScrip.DecimalLocator == "10000000") {
      decimalFormat = ',.4f';
    }
    else {
      decimalFormat = ',.2f';
    }
    this.options = {
      chart: {
        type: 'lineChart',
        height: window.innerHeight - 100,
        margin: {
          top: 20,
          right: 40,
          bottom: 40,
          left: 60
        },
        x: function (d) { return d.x; },
        y: function (d) { return d.y; },
        useInteractiveGuideline: true,
        tooltip: true,
        showLegend: false,
        xAxis: {
          //axisLabel: 'Time (ms)',
          tickFormat: function (d) {
            if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 5) {
              return d3.time.format('%a  %d')(new Date(d * 10000)); //x 
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 30) {
              return d3.time.format('%d %b')(new Date(d * 10000)); //x Monthly Yearly
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 260) {
              return d3.time.format('%d %b %y')(new Date(d * 10000)); //x Monthly Yearly
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && ((details.userHistoricSelectedChartType.value == 520) || (details.userHistoricSelectedChartType.value == 1300))) {
              return d3.time.format('%d %b %y')(new Date(d * 10000)); //•	%b - abbreviated month name. 2 yearly
            }
            else {
              if (details.chartType.toUpperCase() == 'INTRADAY' && details.userSelectedChartType.value == 1) {
                return d3.time.format('%H:%M:%S')(new Date(d * 10000));
              }
              else {
                return d3.time.format('%Y')(new Date(d * 10000));
              }
            }
          },
          showMaxMin: true,
          ticks: 5,
          axisLabelDistance: 500
        },
        yAxis: {
          //axisLabel: 'Voltage (v)',
          tickFormat: function (d) {
            return d3.format(decimalFormat)(d);
          },
          showMaxMin: true,
          ticks: 5,
          axisLabelDistance: 500
        },
        callback: function (chart) {
          console.log("!!! lineChart callback !!!");
        },
        zoom: {
          enabled: true
        }
      },
      // title: {
      //     enable: true,
      //     text: 'Memory Usage in Regression Test'
      // },
    };
    if (this.chartType.toUpperCase() == 'INTRADAY') {
      this.data = [{
        values: this.chartIntradayDetails,
        area: this.userSelectedChartType.value == 3 ? true : false,
        key: 'LTP',
        color: this.plotColor
      }];
    }
    else if (this.chartType.toUpperCase() == 'HISTORIC') {
      if (this.userHistoricSelectedChartType.value == 5) {
        this.data = [{
          values: this.chartHistoric5DDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 30) {
        this.data = [{
          values: this.chartHistoric30DDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 260) {
        this.data = [{
          values: this.chartHistoric260DDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 520) {
        this.data = [{
          values: this.chartHistoric520DDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 1300) {
        this.data = [{
          values: this.chartHistoric1300DDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 0) {
        this.data = [{
          values: this.chartHistoricMaxDetails,
          area: this.userSelectedChartType.value == 3 ? true : false,
          key: 'LTP',
          color: this.plotColor
        }];
      }
    }
  }
  drawCandleChart() {
    let details = this;
    let decimalFormat = ''
    if (details.selectedScrip.InstrumentName == "FUTCUR" || details.selectedScrip.DecimalLocator == "10000000") {
      decimalFormat = ',.4f';
    }
    else {
      decimalFormat = ',.2f';
    }
    this.options = {
      chart: {
        type: 'candlestickBarChart',
        height: window.innerHeight - 100,
        margin: {
          top: 20,
          right: 40,
          bottom: 40,
          left: 60
        },
        x: function (d) { return d['date']; },
        y: function (d) { return d['close']; },
        useInteractiveGuideline: true,
        showLegend: false,
        duration: 10,
        xAxis: {
          //axisLabel: 'Time (ms)',
          tickFormat: function (d) {
            if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 5) {
              return d3.time.format('%a  %d')(new Date(d * 10000)); //x 
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 30) {
              return d3.time.format('%d %b')(new Date(d * 10000)); //x Monthly Yearly
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && details.userHistoricSelectedChartType.value == 260) {
              return d3.time.format('%d %b %Y')(new Date(d * 10000)); //x Monthly Yearly
            }
            else if (details.chartType.toUpperCase() == 'HISTORIC' && ((details.userHistoricSelectedChartType.value == 520) || (details.userHistoricSelectedChartType.value == 1300))) {
              return d3.time.format('%d %b %y')(new Date(d * 10000)); //•	%b - abbreviated month name. 2 yearly
            }
            else {
              if (details.chartType.toUpperCase() == 'INTRADAY' && details.userSelectedChartType.value == 1) {
                return d3.time.format('%H:%M:%S')(new Date(d * 10000));
              }
              else {
                return d3.time.format('%Y')(new Date(d * 10000));
              }
            }
          },
          showMaxMin: false,
        },
        yAxis: {
          //axisLabel: 'Voltage (v)',
          tickFormat: function (d) {
            return d3.format(decimalFormat)(d);
          },
          showMaxMin: false,
        },
        callback: function (chart) {
          console.log("!!! BarChart callback !!!");
        },
        zoom: {
          enabled: true
        }
      },
      // title: {
      //     enable: true,
      //     text: 'Memory Usage in Regression Test'
      // },
    };
    if (this.chartType.toUpperCase() == 'INTRADAY') {
      this.data = [{
        values: this.chartIntradayCandleDetails,
        key: 'LTP',
        color: this.plotColor
      }];
    }
    else if (this.chartType.toUpperCase() == 'HISTORIC') {
      if (this.userHistoricSelectedChartType.value == 5) {
        this.data = [{
          values: this.chartHistoric5DCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 30) {
        this.data = [{
          values: this.chartHistoric30DCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 260) {
        this.data = [{
          values: this.chartHistoric260DCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 520) {
        this.data = [{
          values: this.chartHistoric520DCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 1300) {
        this.data = [{
          values: this.chartHistoric1300DCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
      else if (this.userHistoricSelectedChartType.value == 0) {
        this.data = [{
          values: this.chartHistoricMaxCandleDetails,
          key: 'LTP',
          color: this.plotColor
        }];
      }
    }
  }
  selectTypePopup() {
    this.showTypeSelectpopup = true;
  }
  selectTimePopup() {
    this.showTimeSelectpopup = true;
  }
  popUpClose() {
    this.showTypeSelectpopup = false;
    this.showTimeSelectpopup = false;
  }
  clearChartBinding() {
    this.data = [];
  }
  clearChartArea() {
    // if (this.data[0] != undefined) {
    //   if (this.data[0].area != undefined) {
    //     if (this.data[0].area == true)
    //       d3.selectAll('path.nv-area').remove();
    //   }
    // }
    if (this.data[0] != undefined) {
      d3.select('svg').remove();
    }
  }
  chartTypeSelect(item, type) {
    if (this.userSelectedChartType.value == item.value && type == "true") {
      return;
    }
    this.userSelectedChartType = item;
    let dd = this.userSelectedChartType.value;
    this.clearChartArea();
    this.clearChartBinding();
    if (dd == 2 || dd == 3) {
      this.drawLineChart();
    }
    if (dd == 1) {
      this.drawCandleChart();
    }
    this.popUpClose();
  }
  tabSelection(event) {
    this.chartType = event.detail.value;
    if (this.chartType.toUpperCase() == 'INTRADAY') {
      if (this.chartIntradayDetails.length > 0 && this.chartIntradayCandleDetails.length > 0) {
        this.clearChartArea();
        this.clearChartBinding();
        this.isHistoric = false;
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getIntradayChartDetails();
      }
    }
    else if (this.chartType.toUpperCase() == 'HISTORIC') {
      this.isHistoric = true;
      this.userHistoricSelectedChartType = this.historicOptionArry[0];
      if (this.userHistoricSelectedChartType.value == 5) {
        if (this.chartHistoric5DDetails.length > 0 && this.chartHistoric5DCandleDetails.length > 0) {
          this.chartTypeSelect(this.userSelectedChartType, "false");
        }
        else {
          this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
        }
      }
    }
  }
  chartTimeSelect(item, type) {
    if (this.userHistoricSelectedChartType.value == item.value && type == "true") {
      return;
    }
    this.userHistoricSelectedChartType = item;
    if (this.userHistoricSelectedChartType.value == 5) {
      if (this.chartHistoric5DDetails.length > 0 && this.chartHistoric5DCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
    else if (this.userHistoricSelectedChartType.value == 30) {
      if (this.chartHistoric30DDetails.length > 0 && this.chartHistoric30DCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
    else if (this.userHistoricSelectedChartType.value == 260) {
      if (this.chartHistoric260DDetails.length > 0 && this.chartHistoric260DCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
    else if (this.userHistoricSelectedChartType.value == 520) {
      if (this.chartHistoric520DDetails.length > 0 && this.chartHistoric520DCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
    else if (this.userHistoricSelectedChartType.value == 1300) {
      if (this.chartHistoric1300DDetails.length > 0 && this.chartHistoric1300DCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
    else if (this.userHistoricSelectedChartType.value == 0) {
      if (this.chartHistoricMaxDetails.length > 0 && this.chartHistoricMaxCandleDetails.length > 0) {
        this.chartTypeSelect(this.userSelectedChartType, "false");
      }
      else {
        this.getHistoricChartDetails(this.userHistoricSelectedChartType.value);
      }
    }
  }
}
