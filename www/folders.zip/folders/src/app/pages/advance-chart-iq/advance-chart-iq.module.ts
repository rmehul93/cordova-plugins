import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdvanceChartIqPageRoutingModule } from './advance-chart-iq-routing.module';

import { AdvanceChartIqPage } from './advance-chart-iq.page';
import { NvD3Module } from 'ng2-nvd3'; 

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdvanceChartIqPageRoutingModule,
    NvD3Module,
  ],
  declarations: [AdvanceChartIqPage]
})
export class AdvanceChartIqPageModule {}
