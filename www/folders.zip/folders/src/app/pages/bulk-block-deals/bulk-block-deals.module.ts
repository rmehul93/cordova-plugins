import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BulkBlockDealsPageRoutingModule } from './bulk-block-deals-routing.module';

import { BulkBlockDealsPage } from './bulk-block-deals.page';
import { NgCalendarModule  } from 'ionic2-calendar';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BulkBlockDealsPageRoutingModule,
    NgCalendarModule
  ],
  declarations: [BulkBlockDealsPage]
})
export class BulkBlockDealsPageModule {}
