import { NavParamService } from './../../providers/nav-param.service';
import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { clsLocalStorageService } from './../../Common/clsLocalStorageService';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { clsAppConfigConstants } from './../../Common/clsAppConfigConstants';
import { NavController, IonContent } from '@ionic/angular';
import { clsCommonMethods } from './../../Common/clsCommonMethods';
import { clsConstants } from './../../Common/clsConstants';
import { clsGlobal } from './../../Common/clsGlobal';
import { CDSServicesProvider } from './../../providers/cds-services/cds.services';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CalendarComponent } from 'ionic2-calendar/calendar';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-bulk-block-deals',
  templateUrl: './bulk-block-deals.page.html',
})
export class BulkBlockDealsPage implements OnInit {
  bulkblockmode: string = 'bulk';
  bulkblockexchange: string = clsConstants.CDS_BULKBLOCK_EXCHANGE;
  bulkBlockDetails: any = [];
  BulkBlockDetailsDate: any = [];

  fromDate: string = (new Date(new Date().getTime() - (15 * 24 * 60 * 60 * 1000))).toISOString();
  toDate: string = new Date().toISOString();
  minDate: string = (new Date().getFullYear() - 3).toString();
  maxDate: string = new Date().toISOString();
  showLoader: boolean = false;
  pageSize: any;
  selectOptions: any;
  page: any;
  iPageNo: number = 1;
  loadMoreData: boolean = false;
  infiniteScroll: any;
  noDataFound: boolean = false;
  isItemClick: boolean = true;
  myValue: boolean = false
  hideMe = false;
  todayOrders: any = [];
  yesterdayOrders: any = [];
  olderOrders: any = [];


  messageSearchData_today: any = [];
  messageSearchData_yesterday: any = [];
  messageSearchData_older: any = []


  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = "";
  messageSearchData = []
  showSearch: boolean = false;

  @ViewChild(IonContent, { static: false }) content: IonContent;
  showExpandHeader: boolean = false;
  tempFavScreeners: any = [];
  hdrName: string = "";
  objScannerData: any = {};

  showFilterPopUp: boolean = false;
  disableApply: boolean = false;
  filterObject: any = {};
  isFilterApply: boolean = false;
  showCustomdatePopup: boolean = false;

  toPreviousMonth: any = "";
  fromPreviousMonth: any = "";
  selectedDateEvents: any = [];
  filterEvents: any = [];
  calendarFromDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };

  calendarToDate: any = {
    mode: 'month',
    currentDate: new Date(),
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
    locale: 'en-IN'
  };

  selectedDate: Date;
  eventSource = [];
  isFrom: boolean = true;
  isTo: boolean = false;
  fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
  fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
  fromCurrentDay = new Date().toDateString().split(' ')[2];
  //fromCurrentDay = this.calendar.currentDate.getDay();
  fromSelectedDate: any = new Date();
  toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
  toCurrentYear = this.calendarToDate.currentDate.getFullYear();
  toCurrentDay = new Date().toDateString().split(' ')[2];
  //toCurrentDay = this.calendar.currentDate.getDay();
  toSelectedDate: any = new Date();
  isCustom: boolean = false;
  dslyFrmDt: string;
  dslyToDt: string;
  @ViewChild(CalendarComponent) objCalendar: CalendarComponent;
  strFromDate: any = '';
  strToDate: any = '';
  selDtType = "";
  selDateName: any = '';
  dateSelected = false;

  constructor(public objCDSService: CDSServicesProvider,
    public navCtrl: NavController,
    public objToast: ToastServicesProvider,
    public clsLocalStorage: clsLocalStorageService,
    private paramService: NavParamService) {
    this.objScannerData = this.paramService.myParam;
    this.hdrName = this.objScannerData.scannerItem.GroupName;
  }

  ngOnInit() {
    this.strFromDate = this.getDate(new Date());
    this.strToDate = this.getDate(new Date());
    this.setPageSize();
    this.bulkblockdetails();
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
  }

  ionViewWillEnter() {
    if (Object.keys(this.filterObject).length == 0) {
      this.disableApply = true;
    }
    else {
      this.disableApply = false;
    }
  }

  setPageSize() {
    if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDS_PAGE_SIZE) != undefined) {
      this.pageSize = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDS_PAGE_SIZE));
    }
    else {
      this.pageSize = clsConstants.CDS_PAGE_SIZE;
    }
  }

  scrollContent(event) {
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
  }

  bulkblockdetails() {
    this.showLoader = true;
    let _fromdate = clsCommonMethods.getCDSDate(this.fromDate);
    let _todate = clsCommonMethods.getCDSDate(this.toDate);
    let requestString = this.bulkblockexchange + '/' + this.bulkblockmode + '/' + _fromdate + '/' + _todate + '/' + this.iPageNo + '/' + this.pageSize;

    this.objCDSService.getBulkBlockData(requestString).then((objresponse: any) => {
      try {
        this.showLoader = false;
        if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
          if (objresponse.ResponseObject.recordcount > 0) {
            for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
              this.bulkBlockDetails.push({
                scripName: objresponse.ResponseObject.resultset[i].ScripName,
                transactionType: objresponse.ResponseObject.resultset[i].BuySell == 'B' ? 'Bought' : 'Sold',
                averagePrice: objresponse.ResponseObject.resultset[i].AveragePrice,
                quantity: objresponse.ResponseObject.resultset[i].QuantityShares,
                clientName: objresponse.ResponseObject.resultset[i].ClientName,
                date: objresponse.ResponseObject.resultset[i].Date.split('-')[0] + " " + objresponse.ResponseObject.resultset[i].Date.split('-')[1] + "'" + objresponse.ResponseObject.resultset[i].Date.split('-')[2].substring(2),
                status: this.getOrderStatus(objresponse.ResponseObject.resultset[i].Date)
              });
            }
            this.todayOrders = this.bulkBlockDetails.filter(x => (x.status.toUpperCase().includes('TODAY')));
            this.yesterdayOrders = this.bulkBlockDetails.filter(x => (x.status.toUpperCase().includes('YESTERDAY')));
            this.olderOrders = this.bulkBlockDetails.filter(x => (x.status.toUpperCase().includes('OLDER')));

            this.loadMoreData = true;
          }
          else {
            if (this.iPageNo == 1) {
              this.noDataFound = true;
            }
            this.loadMoreData = false;
          }
        }
        else {
          this.loadMoreData = false;
          this.noDataFound = true;
        }
      } catch (error) {
        this.showLoader = false;
        clsGlobal.logManager.writeErrorLog("BulkBlockDealsPage", "bulkblockdetails_1", error);
        this.noDataFound = true;
      }
      finally {
        this.showLoader = false;
      }
    }).catch(error => {
      this.showLoader = false;
      this.noDataFound = true;
      clsGlobal.logManager.writeErrorLog("BulkBlockDealsPage", "bulkblockdetails_2", error);
    }
    );
  }

  getOrderStatus(date: any) {
    let status: any;
    let current_date = new Date();
    let day = current_date.getDate();
    let yesterdayDate = "0" + (current_date.getDate() - 1);
    let month = clsCommonMethods.getAlphaMonth(current_date.getMonth());
    let year = (current_date.getFullYear()).toString();
    let formatted_date = "0" + day + "-" + month + "-" + year;
    let formatted_yesterday_date = yesterdayDate + "-" + month + "-" + year;
    if (date.toUpperCase() == formatted_date.toUpperCase()) {
      status = 'Today';
    } else if (date.toUpperCase() == formatted_yesterday_date.toUpperCase()) {
      status = 'Yesterday';
    } else {
      status = 'Older';
    }
    return status;
  }

  bulkblockExchangeChanged(event) {
    this.bulkBlockDetails = [];
    this.iPageNo = 1;
    this.noDataFound = false;
    this.bulkblockexchange = event;
    this.bulkblockdetails();
  }

  goBack() {
    this.navCtrl.pop();
  }

  checkDateRange() {
    try {
      if (new Date(this.fromDate) > new Date(this.toDate)) {
        this.bulkBlockDetails = [];
        this.isItemClick = true;
        // this.objToast.showWithButton(clsConstants.CDS_DATE_ERROR);
        return false;
      } else {
        return true;
      }
    } catch (error) {
      return false;
    }
  }

  search($event) {
    if ($event) {
      this.searchText = $event.toUpperCase();
      this.searchTextChanged.next($event);
    } else {
      this.messageSearchData_today = [];
      this.messageSearchData_yesterday = [];
      this.messageSearchData_older = [];
    }
  }

  clearSearch() {
    this.searchText = '';
    this.messageSearchData_today = [];
    this.messageSearchData_yesterday = [];
    this.messageSearchData_older = [];
    this.searchTextEntered = '';
  }

  showSearchPopup() {
    this.searchText = '';
    this.showSearch = true;
    this.messageSearchData_today = [];
    this.messageSearchData_yesterday = [];
    this.messageSearchData_older = [];
  }

  hideSearchPopup() {
    this.showSearch = false;
    this.searchText = '';
    this.messageSearchData_today = [];
    this.messageSearchData_yesterday = [];
    this.messageSearchData_older = [];
  }

  bulkblockChanged(event) {
    this.content.scrollToTop();
    this.bulkBlockDetails = [];
    this.showLoader = true;
    this.todayOrders = [];
    this.yesterdayOrders = [];
    this.olderOrders = [];
    this.iPageNo = 1;
    this.noDataFound = false;
    this.bulkblockmode = event.detail.value;
    this.bulkblockdetails();
  }


  getValues(search) {
    try {
      this.messageSearchData_today = [];
      this.messageSearchData_yesterday = [];
      this.messageSearchData_older = [];

      if (search.length < 1) {
        this.searchTextEntered = '';
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      this.messageSearchData_yesterday = this.yesterdayOrders
        .filter(x => (x.scripName.toUpperCase().includes(this.searchTextEntered)));
      this.messageSearchData_today = this.todayOrders
        .filter(x => (x.scripName.toUpperCase().includes(this.searchTextEntered)));
      this.messageSearchData_older = this.olderOrders
        .filter(x => (x.scripName.toUpperCase().includes(this.searchTextEntered)));
    } catch (error) {
      console.log(error)
    }
  }

  async favUnFavScreeners(item) {
    try {
      await this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.tempFavScreeners = obj;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if (!item.scannerItem.Favourite || item.scannerItem.Favourite == false) {
        item.scannerItem.Favourite = true;
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = true;
        });
        this.tempFavScreeners.push(item.scannerItem);
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
      else {
        if (this.tempFavScreeners.length == 5)
          return this.objToast.showAtBottom("There should be atleast 5 Screeners in My Favourite Screeners.");
        item.scannerItem.Favourite = false;
        this.tempFavScreeners = this.tempFavScreeners.filter((element, index, array) => {
          return element.GroupName != this.hdrName;
        });
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = false;
        });
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
    } catch (error) {
      console.log(error);
    }
  }

  showFilter() {
    this.showFilterPopUp = !this.showFilterPopUp;
  }

  closeFilter() {
    this.filterObject = {};
    this.showFilterPopUp = !this.showFilterPopUp;
  }


  applySortFilter() {
    this.showFilterPopUp = false;
    this.isFilterApply = true;
    this.todayOrders = [];
    this.yesterdayOrders = [];
    this.olderOrders = [];
    this.bulkBlockDetails = [];
    if (this.filterObject.sortdate != 'customdate') {
      this.resetCustomDate();
    }
    if (this.filterObject.sortdate == 'currmonth') {
      this.fromDate = (new Date(new Date().setDate(1))).toISOString();
    } else if (this.filterObject.sortdate == 'lastmonth') {
      let today = new Date()
      this.fromDate = new Date(today.getFullYear(), (today.getMonth() - 1), 1).toISOString();
      this.toDate = new Date(today.getFullYear(), (today.getMonth()), 0).toISOString();
    } else if (this.filterObject.sortdate == 'quarterly') {
      let today = new Date()
      this.fromDate = new Date(today.setMonth(today.getMonth() - 3)).toISOString();
    } else if (this.filterObject.sortdate == 'halfyearly') {
      let today = new Date()
      this.fromDate = new Date(today.setMonth(today.getMonth() - 6)).toISOString();
    } else if (this.filterObject.sortdate == 'yearly') {
      this.fromDate = (new Date(new Date().getTime() - (360 * 24 * 60 * 60 * 1000))).toISOString();
    } else if (this.filterObject.sortexchange == 'bse') {
      this.bulkblockexchange = 'bse'
    }
    if (this.isCustom) {
      this.fromDate = clsCommonMethods.getCDSDate(this.fromSelectedDate);
      this.toDate = clsCommonMethods.getCDSDate(this.toSelectedDate);
    }
    this.bulkblockdetails();
  }

  clearFilter(refreshData: boolean) {
    this.selDtType = '';
    this.selDateName = '';
    this.dateSelected = false;
    this.filterObject = {};
    this.todayOrders = [];
    this.yesterdayOrders = [];
    this.olderOrders = [];
    this.bulkBlockDetails = [];
    this.fromDate = (new Date(new Date().getTime() - (15 * 24 * 60 * 60 * 1000))).toISOString();;
    this.toDate = new Date().toISOString();
    if (refreshData) {
      this.bulkblockdetails();
    }
  }

  setIndexFilter(filterName: any, filterValue: any) {
    try {
      this.filterObject = {};
      switch (filterName) {
        case 'sortdate':
          this.filterObject.sortdate = filterValue;
          break;
        case 'sortexchange':
          this.filterObject.sortexchange = filterValue;
          break;
      }
      if (Object.keys(this.filterObject).length == 0) {
        this.disableApply = true;
      }
      else {
        this.disableApply = false;
      }
    } catch (error) {
      console.log(error);
    }
  }

  getIndexFiltersCount() {
    return Object.keys(this.filterObject).length;
  }

  resetCustomDate() {
    this.isCustom = false;
    this.isFrom = true;
    this.isTo = false;
    this.fromSelectedDate = new Date();
    this.toSelectedDate = new Date();
    this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarFromDate.currentDate.getMonth());
    this.fromCurrentYear = this.calendarFromDate.currentDate.getFullYear();
    this.fromCurrentDay = new Date().toDateString().split(' ')[2];
    this.toCurrentMonth = clsCommonMethods.getAlphaMonth(this.calendarToDate.currentDate.getMonth());
    this.toCurrentYear = this.calendarToDate.currentDate.getFullYear();
    this.toCurrentDay = new Date().toDateString().split(' ')[2];
    this.calendarFromDate.currentDate = new Date();
    this.calendarToDate.currentDate = new Date();
    this.dslyFrmDt = '';
    this.dslyToDt = '';
  }

  CustomDate(value) {
    try {
      this.filterObject = {};
      if (value == 'CLOSE') {
        if (this.isCustom && (this.toSelectedDate < this.fromSelectedDate)) {
          this.objToast.showAtBottom("To Date should not be before From Date");
          return;
        }
        else if ((!this.dslyFrmDt && this.dslyToDt) || (this.dslyFrmDt && !this.dslyToDt)) {
          this.objToast.showAtBottom("To Date or From Date was not provided.");
          return;
        }
        this.filterObject.sortdate = 'customdate'
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else if (value == 'EDIT') {
        if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
          this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);
        if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
          this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
      }
      else {
        //this.resetCustomDate();
        this.selDtType = '';
        this.strFromDate = this.getDate(new Date());
        this.strToDate = this.getDate(new Date());
        this.selDateName = '';
      }
      this.showCustomdatePopup = !this.showCustomdatePopup;
    } catch (e) {
      this.showCustomdatePopup = !this.showCustomdatePopup;
    }
  }

  loadSelectedDateEvent(selectedDate) {
    this.selectedDateEvents = [];
    this.selectedDateEvents = this.filterEvents.filter(eve =>
      new Date(selectedDate).toLocaleDateString() == new Date(eve.startTime).toLocaleDateString()
    )
  }

  getDate(dateObj) {
    try {

      //let dateObj = new Date();
      let day = ("0" + dateObj.getDate()).slice(-2);
      let month = ("0" + (dateObj.getMonth() + 1)).slice(-2);
      let year = dateObj.getFullYear();

      let strDate = month + "-" + day + "-" + year;
      return strDate;

    } catch (error) {

    }
  }

  setValue(value) {
    if (value == 'FROM') {
      this.isFrom = true;
      this.isTo = false;
    }
    else {
      this.isFrom = false;
      this.isTo = true;
    }

  }

  onFromDateChanged(event) {
    if (this.fromPreviousMonth) {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.fromPreviousMonth == this.fromCurrentMonth) {
        this.calendarFromDate.currentDate = event;
      } else {
        this.fromPreviousMonth = this.fromCurrentMonth;
        this.fromCurrentYear = event.getFullYear();
        this.calendarFromDate.currentDate = event;
      }
    } else {
      this.fromCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.fromPreviousMonth = this.fromCurrentMonth;
      this.fromCurrentYear = event.getFullYear();
      this.calendarFromDate.currentDate = event;
    }
  }

  onToDateChanged(event) {
    if (this.toPreviousMonth) {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      if (this.toPreviousMonth == this.toCurrentMonth) {
        this.calendarToDate.currentDate = event;
      } else {
        this.toPreviousMonth = this.toCurrentMonth;
        this.toCurrentYear = event.getFullYear();
        this.calendarToDate.currentDate = event;
      }
    } else {
      this.toCurrentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
      this.toPreviousMonth = this.toCurrentMonth;
      this.toCurrentYear = event.getFullYear();
      this.calendarToDate.currentDate = event;
    }
  }


  isDatefromCurrentMonth(date, type) {
    let dtCompare = (type == "FROM") ? new Date(this.calendarFromDate.currentDate).getMonth() : new Date(this.calendarToDate.currentDate).getMonth();
    if (new Date(date.date).getMonth() == dtCompare) {
      return true;
    } else {
      return false;
    }


  }


  setToDateSelected(event) {
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.toSelectedDate = event.date;
    this.toCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.toCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.toCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.toCurrentYear != '' && this.toCurrentYear != undefined)
      this.dslyToDt = this.toCurrentDay + " " + this.toCurrentMonth + "'" + this.toCurrentYear.substring(2, 4);
  }

  setFromDateSelected(event) {
    let today = new Date();
    if (event.date > today) {
      return;
    }
    this.isCustom = true;
    this.fromSelectedDate = event.date;

    this.fromCurrentDay = new Date(event.date).toDateString().split(' ')[2];
    this.fromCurrentMonth = new Date(event.date).toDateString().split(' ')[1];
    this.fromCurrentYear = new Date(event.date).toDateString().split(' ')[3];
    if (this.fromCurrentYear != '' && this.fromCurrentYear != undefined)
      this.dslyFrmDt = this.fromCurrentDay + " " + this.fromCurrentMonth + "'" + this.fromCurrentYear.substring(2, 4);

  }

  markDisabled(date: Date) {
    var current = new Date();
    return date > current;
  }

}
