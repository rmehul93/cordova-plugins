import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { IonicModule } from '@ionic/angular'; 
import { TestpagePageRoutingModule } from './testpage-routing.module'; 
import { TestpagePage } from './testpage.page';
import { IonicPullupModule } from 'ionic-pullup';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
 

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule, 
    TestpagePageRoutingModule,IonicPullupModule,DirectiveSharedModule
  ],
  declarations: [TestpagePage]
})
export class TestpagePageModule {}
