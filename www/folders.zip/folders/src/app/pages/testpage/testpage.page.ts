import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import { IonPullUpFooterState } from 'ionic-pullup';
import { clsAppInitService } from 'src/app/Common/clsAppInitService';
import { SocketIoServiceService } from 'src/app/providers/socket-io-service.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services'; 
import { API, DataStore, graphqlOperation, PubSub } from 'aws-amplify';
import { AppInfo, MsgInfo,UserPreference, NewWatchListProfile, NewWatchListScrips } from 'src/models';
import { APIService } from 'src/app/API.service';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-testpage',
  templateUrl: './testpage.page.html', 
})
export class TestpagePage implements OnInit {
  footerState: IonPullUpFooterState;
  orderSubscription:any;
  alertSubscription:any;
  screensize=window.innerHeight;
  constructor(private objSocketService:SocketIoServiceService,
    private toastObj:ToastServicesProvider,
    private objInit : clsAppInitService,
    private navCtrl: NavController) {
    this.footerState = IonPullUpFooterState.Collapsed; 
   }
   
  ngOnInit() {
    console.log(this.screensize);
   this.orderSubscription= this.objSocketService.getOrders().subscribe((data)=>{
        console.log(data);
    });
    this.alertSubscription= this.objSocketService.getAlerts().subscribe((data)=>{
      console.log(data);
      let msg=data.data.remarks+ " Create Date:"+data.createDate;
      this.toastObj.showAtBottom(msg); 
  });
  }
  
  fetchConfig()
  {
    this.objInit.getDBConfig();
  }
  goHome()
  {
    this.navCtrl.navigateRoot('watchlist');
  }
  ionViewWillLeave()
  {
    //this.objSocketService.getOrders().unsubscribe();
    this.orderSubscription.unsubscribe();
    this.alertSubscription.unsubscribe();
  }
  footerExpanded() {
    console.log('Footer expanded!');
  }

  footerCollapsed() {
    console.log('Footer collapsed!');
  }
  connectionSocket()
  {
   
  }
  toggleFooter() {
    this.footerState = this.footerState == IonPullUpFooterState.Collapsed ? IonPullUpFooterState.Expanded : IonPullUpFooterState.Collapsed;
    console.log("Footer state"+ this.footerState);
  }
  goBack()
  {
    this.navCtrl.pop();
  }
  showChangePassword()
  {
    this.navCtrl.navigateRoot('changepassword');
  }
  showChangeMPIN()
  {
    this.navCtrl.navigateRoot('changempin');
  }
  //
  appinfoKey:any ="";
  appinfoValue:any ="";
  appcomid:any ="com.wave.dev"
  getKey(event){
    this.appinfoKey=event.data.toUpperCase();
  }
  getValue(event){
    this.appinfoValue=event.data.toUpperCase();
  }
  addPushCheck()
  {
    clsGlobal.pubsub.publish('TEST_PUSH');
  }
  addAppInfoForTenant() 
  {
    try {
      DataStore.save(
        new AppInfo({ 
          sParamName: this.appinfoKey,
          sParamValue:this.appinfoValue,
          sTenantId : this.appcomid
        })
      );
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('testPage', 'addAppInfoForTenant',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

 async updateAppInfo()
  {
    const original = await DataStore.query(AppInfo, c => c.sParamName("eq", this.appinfoKey));
    await DataStore.save(
      AppInfo.copyOf(original[0], updated => {
        updated.sParamValue = this.appinfoValue;
      })
    );
  }
  addMsgInfo()
  {

  }
  updateMsgInfo(){

  }
  userPrefKey:any="";
  async DeleteUserPreference()
  {
    const todelete = await DataStore.query(UserPreference, c => c.id("eq",this.userPrefKey));
    DataStore.delete(todelete[0]);
  }
}
