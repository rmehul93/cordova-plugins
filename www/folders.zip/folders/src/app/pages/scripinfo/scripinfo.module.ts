import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ScripinfoPageRoutingModule } from './scripinfo-routing.module';

import { ScripinfoPage } from './scripinfo.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,ComponentsModule,
    ScripinfoPageRoutingModule
  ],
  declarations: [ScripinfoPage]
})
export class ScripinfoPageModule {}
