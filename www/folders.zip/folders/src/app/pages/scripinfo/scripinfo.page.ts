import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { IonContent, NavController } from "@ionic/angular";
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsContractInfo } from 'src/app/Common/clsContractInfo';
import { clsGlobal } from "src/app/Common/clsGlobal";
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsSecurityInfo } from 'src/app/Common/clsSecurityInfo';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsBestFiveRequest } from 'src/app/communicator/clsBestFiveRequest';
import { clsBestFiveResponse } from 'src/app/communicator/clsBestFiveResponse';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { clsPivotPoint } from "../../Common/clsPivotPoint";
import { Chart } from "chart.js";
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsScrip } from 'src/app/Common/clsScrip';
import xml2js from 'xml2js';
import { DatabaseService } from 'src/app/providers/database-services/database-services';

@Component({
  selector: 'app-scripinfo',
  templateUrl: './scripinfo.page.html',
})
export class ScripinfoPage implements OnInit {
  selectedSegment = "Overview";
  mode = clsGlobal.PlatformMode;
  openNews: boolean = false;
  openboardmeeting: boolean = false;
  openbookclosure: boolean = false;
  openagm: boolean = false;
  openegm: boolean = false;
  opensplit: boolean = false;
  opendividend: boolean = false;
  showmore: boolean = false;
  showManagementPopup: boolean = false;
  //temp variables
  corporateactions: any;
  analyticMode: string = "technical";
  srip: any;
  selectedScrip: any;
  eventActions: string = 'boardmeeting';
  BoardDirector: any;
  BoardDirectorDetails: any;
  bcastHandler: any;
  bcastHandlerSPOT: any;
  spotScripKey: clsScripKey = null;
  spotPrice: any = "-";
  B5Data = [];
  totalBidQty = "";
  totalAskQty = "";
  totalBidQtyPer: any = "-";
  totalAskQtyPer: any = "-";
  showExpandHeader: boolean = false;
  PPPoint: clsPivotPoint = new clsPivotPoint();
  showpopupDelta: boolean = false;
  showChooseAnnual: boolean = false;
  chartNoDataFound: boolean = false;
  mavgNoDataFound:boolean = false;
  ptclmstDataNoDataFound: boolean = false;
  vVSDNoDataFound:boolean = false;
  hTotalScrNoDataFound:boolean = false;
  cmpRatioStdNoDataFound:boolean = false;
  cmpRatioCosolidatedNoDataFound:boolean= false;
  ShreholdingPattrnNoDataFound:boolean = false;
  anualReportNoDataFound:boolean = false;
  QuarterlyTrendNoDataFound:boolean = false;
  LUT = "-";
  LTT = "-";

  LTQ = "0";
  ATP = "0.00";
  openPrice = "-";
  highPrice = "-";
  lowPrice = "-";
  closePrice: any = "-";
  DPR = "-";
  DPRLow = "-";
  TER = "-";
  lifeTimeHighCaption = "52W H";
  lifeTimeLowCaption = "52W L";
  lifeTimeHighPrice = "-";
  lifeTimeLowPrice = "-";
  Volume = "-";
  Value: any = "-";

  OI = "-";
  percOpenInt = "-";
  scripLTP: any = "0.00";
  netChangeInRs: any = "0.00";
  percNetChange: any = "0.00";
  LTPTrend = "";
  arrowTrend = "";
  selBidQty: any = "";
  selBidPrice: any = "";
  selAskQty: any = "";
  selAskPrice: any = "";
  selectedB5Data: any = null;
  emptyBestFiveData = [];


  dateExpression = /(\d{2}):(\d{2}):(\d{2}) (\d{4})-(\d{2})-(\d{2})/;
  zeroVal: number = 0;
  futObject: any;
  selectedScripObj: any;
  showPopUpOE: boolean = false;
  AGMList = [];
  EGMList = [];
  splitData = [];
  dividendData = [];
  bookclosureData = [];
  meetingtList = [];
  boardMeetingDetails: any;
  agmDetails: any;
  egmDetails: any;
  scripNews = [];
  otherNews = [];
  futData = [];
  selectedOptionContractData = [];
  selectedOptionContract = [];
  lstScripKey: any = [];
  distinctOptExpiryDate = [];
  putCallRatio = [];
  securityInfo: clsSecurityInfo;
  contractInfo: clsContractInfo;
  issuedCapital = "";
  MCap: any = "-";
  isMarketCapCalculated = false;
  bShowPivot: boolean = false;
  isSecurityInfo: boolean = true;
  priceFormat = 2;

  splitDetails: any;
  dividendDetails: any;
  bookClosureDetails: any;
  movingAvgDataNse: any;
  movingAvgDataBse: any;
  ShareHoldingPatternList = [];
  vdChartLable = ["Today", "Yesterday", "5 Day Avg", "30 Day Avg"]
  vdChartTotalVolume = [];
  vdChartDelivery = []
  putCallMastreData = []

  arrputCallStrikePrice = [];
  arrputCallPriceCEData = [];
  arrputCallPricePEData = [];
  arrputCallVolumeCEData = [];
  arrputCallVolumePEData = [];
  arrputCallOICEData = [];
  arrputCallOIPEData = [];
  arrputCallIVCEData = [];
  arrputCallIVPEData = [];

  shareHoldingPatternChart: any;
  trendAnlysisChart: any;
  PutCallDetailChart: any;

  companyTotalScore: any
  companyHealthStatus: any
  companyHealthcss: any
  newsDetails: any;

  showExchange: boolean = false;
  marketPulsData = [];
  ExchangeNames: any
  showMenuIcon: boolean = false;

  @ViewChild("lineChartDetailsCanvas") lineChartDetailsCanvas;
  @ViewChild("barResultCanvas") barResultCanvas;
  @ViewChild("shareHoldingPatternCanvas") shareHoldingPatternCanvas;
  @ViewChild("mixChartDetailCanvas") mixChartDetailCanvas;
  @ViewChild("PutCallDetailCanvas") PutCallDetailCanvas;

  chartLineData: any;
  resultbarChart: any;
  chartdetails: any = [];
  chartlabels: any = [];

  buyBackData: any = [];
  rightsData: any = [];
  companyInfoExpand: any;
  companyInfoCollapse: any;
  companyInfo: any;
  arrChartDate: any = [];
  arrTotalIncome: any = [];
  arrTotalExpenditure: any = []
  ProfitLossResp: any = [];
  ProfitLossdatearr: any = [];
  segmentSelected: string = "Profit & Loss"
  contactInfoInner: string = "RegisterAddress";
  modalPutCallRatio: string = "Price"
  modalTrendAnlytics: string = "newrevenue"
  modalOIBuiltup: string = "15min"
  BalanceSheetdatearr: any = [];
  CompanyBalanceSheet: any = [];
  TotalDebt: any
  Resultdatearr: any = [];
  arrResultTotalIncome: any = [];
  arrResultChartDate: any = [];
  arrResultTotalExpenditure: any = [];
  CompanyResult: any = [];
  showBalanceSheet: boolean = false;
  showProfitLoss: boolean = false;
  showCompanyResults: boolean = false;
  viewExpand: boolean = false;
  StandAloneDETAILS: any = {
    list: [],
    date: [],
    dataincome: [],
    dataexpenditure: [],
    labels: []
  }; // for Internal storage
  ConsolidatedDETAILS: any = {
    list: [],
    date: [],
    dataincome: [],
    dataexpenditure: [],
    labels: []
  };

  balanceSheetStandAloneDETAILS: any = {
    list: [],
    date: [],
    totaldebt: [],
    totalliabilities: [],
    totalassest: [],
    netdefferedtax: [],
  };
  balanceSheetConsolidatedDETAILS: any = {
    list: [],
    date: [],
    totaldebt: [],
    totalliabilities: [],
    totalassest: [],
    netdefferedtax: [],
  };
  resultStandAloneQuarterDETAILS: any = {
    list: [],
    date: [],
    totalresultincome: [],
    totalresultexpenditure: [],
    labels: []
  };
  resultConsolidatedQuarterDETAILS: any = {
    list: [],
    date: [],
    totalresultincome: [],
    totalresultexpenditure: [],
    labels: []
  };
  CMOTPnLTypeButton = "STANDALONE";
  balanceSheetType: any = "STANDALONE";
  resultType: any = "STANDALONE";
  resultPeriod: any = "QUARTERLY";
  annualReportType: any = "STANDALONE"
  arrQuarterlyTrendRevenue = [];
  arrQuarterlyTrendEBIT = [];
  arrQuarterlyTrendEBITDA = [];
  arrQuarterlyTrendNetprofit = [];

  companyExchangeData: any = '';
  companyListingData: any;
  companyPartOfIndices: any;
  RegisterAddress: any
  RegisterTel: any;
  RegisterFax: any;
  RegisterEmail: any;
  RegisterWeb: any;
  HOAddress: any
  HOATel: any
  HOFax: any
  HOEmail: any
  HOWeb: any
  RegistrarName: any
  RegistrarAdd: any
  RegistrarTel: any
  RegistrarFax: any
  RegistrarEmail: any
  RegistrarWeb: any
  RegistrarAuditor: any
  recoData = [];
  isHoldingExist: boolean = false;
  eventList = [];
  selectedIdxOptnChain: number = 0;
  showSelectpopup: boolean = false;
  noDataFoundFUT: boolean = false;
  noDataFoundOPT: boolean = false;
  noDataFoundReco: boolean = false;

  isScripHasAlert: boolean = false;

  bmNoDataFound: boolean = false;
  agmNoDataFound: boolean = false;
  egmNoDataFound: boolean = false;
  splitNoDataFound: boolean = false;
  dividendNoDataFound: boolean = false;
  bookClosureNoDataFound: boolean = false;
  rightsNoDataFound: boolean = false;
  buyBackNoDataFound: boolean = false;
  marketPulsNoDataFound: boolean = false;
  selecteScripAddToWatchlist: any;
  showOptLoadersearch: boolean = false;
  count: number = 0;
  corpActionLable: any = '';
  data: boolean = false
  cdsFromData = (new Date(new Date().getTime() - (1200 * 24 * 60 * 60 * 1000))).toISOString();
  cdsToDate = (new Date(new Date().getTime() + (365 * 24 * 60 * 60 * 1000))).toISOString();
  cmotMode: any;
  theme: any;
  isBracketAllowed : boolean = false;
  isCoverAllowed : boolean = false;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  isGuestMode : boolean = false;
  constructor(private navCtrl: NavController,
    private paramService: NavParamService,
    public dateFormatter: DatePipe,
    public http: clsHttpService,
    public cdsService: CDSServicesProvider,
    public toastCtrl: ToastServicesProvider,
    public alertCtrl: AlertServicesProvider,
    private dbService: DatabaseService) {

    this.securityInfo = new clsSecurityInfo(this.toastCtrl, this.alertCtrl, this.http);
    this.contractInfo = new clsContractInfo(this.toastCtrl, this.alertCtrl, this.http);
  }
  ngOnInit() {
    this.theme = clsGlobal.defaultTheme;
    this.selectedScrip = this.paramService.myParam;
    //this.futObject = this.paramService.myParam[0].futData;
    this.bcastHandler = this.receiveBestFiveResponse.bind(this); //only B5 request will send on this page.
    clsGlobal.pubsub.subscribe("B5RES", this.bcastHandler);
    this.bcastHandlerSPOT = this.receiveTouchlineResponse.bind(this);
    clsGlobal.pubsub.subscribe("MTLRES", this.bcastHandlerSPOT);
    this.getExchangeList();
    this.cmotMode = clsGlobal.CMOTMode;
    this.isScripHasAlert = clsGlobal.scripAlertsList.filter((alert: any) => { return (alert.data.symbol == this.selectedScrip.symbol) && (alert.triggered == 0) }).length > 0 ? true : false;
    //this.initializeQuote();
    //console.log(this.paramService.myParam)
    this.isGuestMode = clsGlobal.IsGuestUser;
  }

  initializeQuote() {

    this.clearFields();
    this.getFutData();
    this.getFNOPulseData();
    if (this.selectedScrip != undefined) {
      if (clsGlobal.User.Holding != undefined && clsGlobal.User.Holding.length > 0) {
        let holdingScrip = clsGlobal.User.Holding.filter(item => {
          return item.nMarketSegmentId == this.selectedScrip.scripDet.MapMktSegId &&
            item.nToken == this.selectedScrip.scripDet.token;
        });
        if (holdingScrip.length > 0) {
          //let holdingData: any = {};
          this.isHoldingExist = true;
          this.selectedScrip.holding = holdingScrip[0];
        }
        else {
          this.isHoldingExist = false;
        }
      }

      if (clsGlobal.EventList != undefined && clsGlobal.EventList.length > 0) {
        this.eventList = [];
        for (let j = 0; j < clsGlobal.EventList.length; j++) {
          if (this.selectedScrip.scripDet.MapMktSegId == clsGlobal.EventList[j].mktid && this.selectedScrip.scripDet.token == clsGlobal.EventList[j].token) {
            this.eventList.push(clsGlobal.EventList[j])
          }
        }

      }
    }
    this.sendB5Request(OperationType.ADD, this.selectedScrip);

  }
  receiveBestFiveResponse(objB5Resp: clsBestFiveResponse) {
    try {
      if (
        this.selectedScrip != null &&
        this.selectedScrip.scripDet != null &&
        this.selectedScrip.scripDet != null &&
        this.selectedScrip.scripDet != null &&
        this.selectedScrip.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
        this.gettoken() == objB5Resp.Scrip.token
      ) {
        this.processBestFiveResponse(objB5Resp);
      }
    } catch (error) {
      //this.toastCtrl.showAtBottom("" + error.message);
      //clsGlobal.logManager.writeErrorLog('QuotePage', 'receiveBestFiveResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','receiveBestFiveResponse', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  receiveTouchlineResponse(objSpotResp: clsMultiTouchLineResponse) {
    try {
      if (this.selectedSegment == "Futures") {
        for (let j = 0; j < this.futData.length; j++) {
          if (this.futData != undefined &&
            this.futData[j]._source.nMarketSegmentId == objSpotResp.Scrip.MktSegId &&
            this.futData[j]._source.nToken == objSpotResp.Scrip.token) {
            this.futData[j].LTP = objSpotResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objSpotResp.LTP, objSpotResp.ClosePrice, 2, false, 'arrow');
            this.futData[j].NetChangeInRs = arrNetChange[0];
            this.futData[j].PercNetChange = arrNetChange[1];
            this.futData[j].LTPTrend = arrNetChange[2];
            this.futData[j].arrowTrend = arrNetChange[3];
            this.futData[j].PremiumDiscount = (parseFloat(this.scripLTP) - parseFloat(this.futData[j].LTP)).toFixed(2);
            break;
          }
        }
      }

      if (this.selectedSegment == "OptionChain") {
        if (this.selectedOptionContract.length > 0) {
          for (let i = 0; i < this.selectedOptionContract.length; i++) {

            if (this.selectedOptionContract[i].ceData.Money == "call-add-money") {
              this.selectedOptionContract[i].ceData._source.nStrikePrice1 = this.scripLTP;
            }
            if (this.selectedOptionContract[i].peData.Money == "put-add-money") {
              this.selectedOptionContract[i].peData._source.nStrikePrice1 = this.scripLTP;
            }


            if (parseFloat(this.scripLTP) > parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1)) {
              if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                this.selectedOptionContract[i].ceData.Money = "call-background";
              }

            }
            else {
              if (this.selectedOptionContract[i].ceData.Money != "call-add-money") {
                this.selectedOptionContract[i].ceData.Money = "put-background";
              }

            }

            if (parseFloat(this.scripLTP) < parseFloat(this.selectedOptionContract[i].peData._source.nStrikePrice1)) {
              if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                this.selectedOptionContract[i].peData.Money = "call-background";
              }

            }
            else {
              if (this.selectedOptionContract[i].peData.Money != "put-add-money") {
                this.selectedOptionContract[i].peData.Money = "put-background";
              }

            }

            if (this.selectedOptionContract != undefined &&
              this.selectedOptionContract[i].ceData._source.nMarketSegmentId == objSpotResp.Scrip.MktSegId &&
              this.selectedOptionContract[i].ceData._source.nToken == objSpotResp.Scrip.token) {
              this.selectedOptionContract[i].ceData.LTP = objSpotResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objSpotResp.LTP, objSpotResp.ClosePrice, 2, false, 'arrow');
              this.selectedOptionContract[i].ceData.NetChangeInRs = arrNetChange[0];
              this.selectedOptionContract[i].ceData.PercNetChange = arrNetChange[1];
              this.selectedOptionContract[i].ceData.LTPTrend = arrNetChange[2];
              this.selectedOptionContract[i].ceData.arrowTrend = arrNetChange[3];
              this.selectedOptionContract[i].ceData.OI = objSpotResp.OpenInt == "" ? "0.00" : objSpotResp.OpenInt;;
              this.selectedOptionContract[i].ceData.PercOI = objSpotResp.PercOpenInt == "" ? "0.00" : objSpotResp.PercOpenInt;;
              if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) > 0) {
                this.selectedOptionContract[i].ceData.colorOITrend = "color-positive";
              }
              else if (parseFloat(this.selectedOptionContract[i].ceData.PercOI) < 0) {
                this.selectedOptionContract[i].ceData.colorOITrend = "color-negative";
              }
              else {
                this.selectedOptionContract[i].ceData.colorOITrend = "";
              }
              let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLTP),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objSpotResp.LTP, "CALL");
              this.selectedOptionContract[i].ceData.IV = parseFloat(ImpVoltality).toFixed(4);
              break;
            }
            else if (this.selectedOptionContract != undefined &&
              this.selectedOptionContract[i].peData._source.nMarketSegmentId == objSpotResp.Scrip.MktSegId &&
              this.selectedOptionContract[i].peData._source.nToken == objSpotResp.Scrip.token) {
              this.selectedOptionContract[i].peData.LTP = objSpotResp.LTP;
              let arrNetChange = clsTradingMethods.getChangeInRs(objSpotResp.LTP, objSpotResp.ClosePrice, 2, false, 'arrow');
              this.selectedOptionContract[i].peData.NetChangeInRs = arrNetChange[0];
              this.selectedOptionContract[i].peData.PercNetChange = arrNetChange[1];
              this.selectedOptionContract[i].peData.LTPTrend = arrNetChange[2];
              this.selectedOptionContract[i].peData.arrowTrend = arrNetChange[3];
              this.selectedOptionContract[i].peData.OI = objSpotResp.OpenInt == "" ? "0.00" : objSpotResp.OpenInt;
              this.selectedOptionContract[i].peData.PercOI = objSpotResp.PercOpenInt == "" ? "0.00" : objSpotResp.PercOpenInt;
              if (parseFloat(this.selectedOptionContract[i].peData.PercOI) > 0) {
                this.selectedOptionContract[i].peData.colorOITrend = "color-positive";
              }
              else if (parseFloat(this.selectedOptionContract[i].peData.PercOI) < 0) {
                this.selectedOptionContract[i].peData.colorOITrend = "color-negative";
              }
              else {
                this.selectedOptionContract[i].peData.colorOITrend = "";
              }
              let ImpVoltality: any = clsCommonMethods.ImpliedVolatility(parseFloat(this.scripLTP),
                parseFloat(this.selectedOptionContract[i].ceData._source.nStrikePrice1), 4,
                this.dateDiffernece(this.selectedOptionContract[i].ceData._source.nExpiryDate1), objSpotResp.LTP, "PUT");
              this.selectedOptionContract[i].peData.IV = parseFloat(ImpVoltality).toFixed(4);;

              break;
            }
          }
        }
        this.selectedOptionContract.sort((a, b) => (parseFloat(a.ceData._source.nStrikePrice1) < parseFloat(b.ceData._source.nStrikePrice1)) ? -1 : 1)

      }

    } catch (error) {
      //this.toastCtrl.showAtBottom("" + error.message);
      //clsGlobal.logManager.writeErrorLog('QuotePage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','receiveTouchlineResponse', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  dateDiffernece(inputdate) {
    try {
      let nextdate: any = new Date(inputdate);
      let curruntData: any = new Date()
      let diffTime = Math.abs(nextdate - curruntData);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch (error) {
      console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','dateDiffernece', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  calculateHistogram(sum: any, qty: number) {
    try {
      let histovalue = (Math.round(((qty * 100) / sum) * 100) / 100).toFixed(2);
      //console.log(histovalue);
      return histovalue;
    } catch (error) {
      console.log("Error in histor calculation ." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','calculateHistogram', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  processBestFiveResponse(_objB5Response: clsBestFiveResponse) {
    try {

      let bidSum = 0;
      let askSum = 0;
      for (let i = 0, len = this.B5Data.length; i < len; i++) {
        if (this.B5Data[i].sBidQty != undefined && this.B5Data[i].sBidQty != '-' && this.B5Data[i].sBidQty != 0)
          bidSum = bidSum + parseInt(this.B5Data[i].sBidQty);

        if (this.B5Data[i].sAskQty != undefined && this.B5Data[i].sAskQty != '-' && this.B5Data[i].sAskQty != 0)
          askSum = askSum + parseInt(this.B5Data[i].sAskQty);
      }

      for (let i = 0, len = this.B5Data.length; i < len; i++) {
        if (
          this.B5Data[i].RowIndex == _objB5Response.BestFiveData[i].RowIndex
        ) {
          this.B5Data[i].sBuyers = _objB5Response.BestFiveData[i].sBuyers;
          this.B5Data[i].sBidQty = _objB5Response.BestFiveData[i].sBidQty;
          this.B5Data[i].sBid = _objB5Response.BestFiveData[i].sBid;
          this.B5Data[i].sBidPer = this.calculateHistogram(bidSum, this.B5Data[i].sBidQty);

          this.B5Data[i].sSellers = _objB5Response.BestFiveData[i].sSellers;
          this.B5Data[i].sAskQty = _objB5Response.BestFiveData[i].sAskQty;
          this.B5Data[i].sAsk = _objB5Response.BestFiveData[i].sAsk;
          this.B5Data[i].sAskPer = this.calculateHistogram(askSum, this.B5Data[i].sAskQty);
        }
      }
      //this.B5Data.valueHasMutated();
      this.totalBidQty = (_objB5Response.TotBuyQty == '' ? '-' : _objB5Response.TotBuyQty).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      this.totalAskQty = (_objB5Response.TotSellQty == '' ? '-' : _objB5Response.TotSellQty).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      if (this.totalAskQty != '-' && this.totalBidQty != '-') {
        let _totalQty = parseInt(this.totalAskQty) + parseInt(this.totalBidQty);
        this.totalBidQtyPer = ((parseInt(this.totalBidQty) / _totalQty) * 100).toFixed(2);
        this.totalAskQtyPer = ((parseInt(this.totalAskQty) / _totalQty) * 100).toFixed(2);
        //we will calculate qty percent 
      }
      this.LUT = this.formatDisplayDate(
        _objB5Response.LUT,
        this.dateExpression,
        "HH:mm:ss"
      );
      this.LTT = this.formatDisplayDate(
        _objB5Response.LTT,
        this.dateExpression,
        "HH:mm:ss"
      );
      this.LTQ = _objB5Response.LTQ == "" ? 0 : _objB5Response.LTQ;
      this.ATP = _objB5Response.ATPPrc == "" ? this.zeroVal.toFixed(_objB5Response.PriceFormat) : _objB5Response.ATPPrc;
      this.openPrice = _objB5Response.OpenPrc == "" ? "-" : _objB5Response.OpenPrc;
      this.highPrice = _objB5Response.HighPrc == "" ? "-" : _objB5Response.HighPrc; //_objB5Response.HighPrc;
      this.lowPrice = _objB5Response.LowPrc == "" ? "-" : _objB5Response.LowPrc; //_objB5Response.LowPrc;
      this.closePrice = _objB5Response.ClosePrc == "" ? "-" : _objB5Response.ClosePrc;

      if (!this.isMarketCapCalculated) {
        this.calculateMarketCap(this.issuedCapital);
      }
      // //Setting the 52Week High/Low and LifeTime High/Low caption based on the exchange segmentid through exchange manager
      this.lifeTimeHighCaption = clsTradingMethods.getLifeTimeHighCaption(this.getMktSegmentId());
      this.lifeTimeLowCaption = clsTradingMethods.getLifeTimeLowCaption(this.getMktSegmentId());
      this.lifeTimeHighPrice = _objB5Response.YrHighPrc == "" ? "-" : _objB5Response.YrHighPrc; //_objB5Response.YrHighPrc;
      this.lifeTimeLowPrice = _objB5Response.YrLowPrc == "" ? "-" : _objB5Response.YrLowPrc; // _objB5Response.YrLowPrc;
      this.Volume = _objB5Response.Volume == "" || _objB5Response.Volume == undefined ? 0 : this.numbertoString(_objB5Response.Volume);
      this.Value = (parseInt(this.Volume) * parseFloat(this.ATP)).toFixed(2);

      this.scripLTP = _objB5Response.LTP == "" || _objB5Response.LTP == undefined ? this.zeroVal.toFixed(_objB5Response.PriceFormat) : _objB5Response.LTP;
      let arrNetChange = clsTradingMethods.getChangeInRs(_objB5Response.LTP, _objB5Response.ClosePrc, _objB5Response.PriceFormat, false, "arrowround");
      this.netChangeInRs = arrNetChange[0];
      this.percNetChange = arrNetChange[1];
      this.LTPTrend = arrNetChange[2];// == 'sell' ? '-' : '+';
      this.arrowTrend = arrNetChange[3];
      // this.selectedScrip.netChangeInRs = arrNetChange[0];
      // this.selectedScrip.percNetChange = arrNetChange[1];
      // this.selectedScrip.LTPTrend = arrNetChange[2];
      // this.selectedScrip.arrowTrend = arrNetChange[3];
      this.DPR = _objB5Response.DPR;
      let arrDPR;
      if (_objB5Response.DPR != undefined && _objB5Response.DPR != "") {
        //comment for Spread DPR in negative
        arrDPR = _objB5Response.DPR.split("-");
        this.DPR = arrDPR[1] == "" ? "-" : arrDPR[1];
        this.DPRLow = arrDPR[0] == "" ? "-" : arrDPR[0];
      }
      if (clsGlobal.User.LoginMode == clsConstants.C_S_REFRESH_MODE)
        this.TER = _objB5Response.TER;
      this.percOpenInt = _objB5Response.PercOpenInt;
      this.OI =
        _objB5Response.OI == "" || _objB5Response.OI == undefined
          ? 0
          : _objB5Response.OI;
      if (
        this.percOpenInt == undefined ||
        this.percOpenInt == "0.00" ||
        this.percOpenInt == ""
      ) {
        //this.OIPerctVisible = false;
      } else {
        //this.OIPerctVisible = true;
      }
      //this.priceFormat = _objB5Response.PriceFormat;
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','processBestFiveResponse', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  numbertoString(number) {
    if (number == undefined || number == "") return "-";
    let words: any = "";
    let Mcap = 0;
    let Val = parseInt(number);
    if (Val.toString().length > 7) {
      Mcap = number / 10000000;
      words = Mcap.toFixed(2) + " Cr";
    } else if (Val.toString().length <= 7 && Val.toString().length > 5) {
      Mcap = number / 100000;
      words = Mcap.toFixed(2) + " L";
    } else {
      words = parseFloat(number); //.toFixed(2); Solved by om on 14 jul for volume decimal in case of 3 or 4 digit values.
    }
    return words;
  }
  sendTouchlineRequest(intOperationType: OperationType, objScrip: clsScripKey) {
    try {
      let objTLReq = new clsMultiTouchLineRequest();
      objTLReq.OperationType = intOperationType;
      objTLReq.BypassRequestStore = false;
      objTLReq.ScripList = objScrip;
      clsGlobal.pubsub.publish('MTLREQ', objTLReq);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','sendTouchlineRequest', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  sendB5Request(intOperationType: OperationType, objScrip: any) {
    try {
      // let scripobject=clsCommonMethods.getScripObjectForWatchList(objScrip);
      let objTLReq = new clsBestFiveRequest();
      objTLReq.OperationType = intOperationType;
      objTLReq.ByPassRequestStore = false;
      objTLReq.Scrip = objScrip;
      clsGlobal.pubsub.publish("B5REQ", objTLReq);
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','sendB5Request', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  clearFields() {
    try {
      this.B5Data = this.getEmptyBestFiveData();
      this.totalBidQty = "";
      this.totalAskQty = "";
      this.LUT = "";
      this.LTT = "-";
      this.LTQ = "-";
      this.ATP = "-";
      this.openPrice = "-";
      this.highPrice = "-";
      this.lowPrice = "-";
      this.closePrice = "-";
      //Setting the 52Week High/Low and LifeTime High/Low caption based on the exchange segmentid through exchange manager
      this.lifeTimeHighCaption = "52W H";
      this.lifeTimeLowCaption = "52W L";
      this.lifeTimeHighPrice = "-";
      this.lifeTimeLowPrice = "-";
      this.Volume = "-";
      this.scripLTP = "0.00";
      this.percNetChange = "0.00";
      this.LTPTrend = "";
      this.arrowTrend = "";
      this.netChangeInRs = "0.00";
      this.DPR = "-";
      this.DPRLow = "-";
      this.selBidQty = "";
      this.selBidPrice = "";
      this.selAskQty = "";
      this.selAskPrice = "";
      this.selectedB5Data = null;
      this.TER = "-";
      this.spotPrice = "-";
      this.spotScripKey = new clsScripKey();
      this.BoardDirector = [];

      this.sendB5Request(OperationType.REMOVE, this.selectedScrip);
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      this.meetingtList = []
      this.scripNews = []
      this.EGMList = []
      this.AGMList = []
      this.splitData = []
      this.dividendData = []
      this.bookclosureData = []
      this.buyBackData = []
      this.rightsData = []

    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','clearfield', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  getEmptyBestFiveData() {
    let b1: any = {};
    b1.sBuyers = "-";
    b1.sBidQty = "-";
    b1.sBid = "-";
    b1.sSellers = "-";
    b1.sAskQty = "-";
    b1.sAsk = "-";
    b1.RowIndex = 0;
    b1.SelectedB5Class = "ht03";

    let b2: any = {};
    b2.sBuyers = "-";
    b2.sBidQty = "-";
    b2.sBid = "-";
    b2.sSellers = "-";
    b2.sAskQty = "-";
    b2.sAsk = "-";
    b2.RowIndex = 1;
    b2.SelectedB5Class = "ht03"; //ko.observable('ht03');

    let b3: any = {};
    b3.sBuyers = "-";
    b3.sBidQty = "-";
    b3.sBid = "-";
    b3.sSellers = "-";
    b3.sAskQty = "-";
    b3.sAsk = "-";
    b3.RowIndex = 2;
    b3.SelectedB5Class = "ht03";

    let b4: any = {};
    b4.sBuyers = "-";
    b4.sBidQty = "-";
    b4.sBid = "-";
    b4.sSellers = "-";
    b4.sAskQty = "-";
    b4.sAsk = "-";
    b4.RowIndex = 3;
    b4.SelectedB5Class = "ht03";

    let b5: any = {};
    b5.sBuyers = "-";
    b5.sBidQty = "-";
    b5.sBid = "-";
    b5.sSellers = "-";
    b5.sAskQty = "-";
    b5.sAsk = "-";
    b5.RowIndex = 4;
    b5.SelectedB5Class = "ht03"; //ko.observable('ht03');

    this.emptyBestFiveData = null;
    this.emptyBestFiveData = [];
    this.emptyBestFiveData.push(b1);
    this.emptyBestFiveData.push(b2);
    this.emptyBestFiveData.push(b3);
    this.emptyBestFiveData.push(b4);
    this.emptyBestFiveData.push(b5);
    return this.emptyBestFiveData;
  }
  formatDisplayDate(sDate, expression, sFormat) {
    let _FormattedDate = "";
    try {
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[4],
          +dateArray[5] - 1, // Careful, month starts at 0!
          +dateArray[6],
          +dateArray[1],
          +dateArray[2],
          +dateArray[3]
        );
        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "dd/MM/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
      }
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','formatDisplayDate', error.Message, undefined, error.stack, undefined, undefined));
    }
    return _FormattedDate;
  }
  closeScripInfo() {

    this.navCtrl.pop();
  }
  ionViewWillLeave() {

    clsGlobal.pubsub.unsubscribe("B5RES", this.bcastHandler);
    this.sendB5Request(OperationType.REMOVE, this.selectedScrip);
  }

  ionViewWillEnter() {
    try {
      clsGlobal.pubsub.subscribe("B5RES", this.bcastHandler);
      this.initializeQuote();
    }
    catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','ionViewWillEnter', error.Message, undefined, error.stack, undefined, undefined));
     }
  }

  //This method will return guest mode status.
  checkGuestMode() {
    if (clsGlobal.User.isGuestUser) {
      let buttons: any = ["Login", "Skip"];
      this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
        () => {
          //success navigate to login screen 
          this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
        }, () => {
          //fail No or cancel click //do nothing.
        });
      return true;
    }
    else {
      return false;
    }
  }

  login(){
    this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
  }
  
  /**
   * main Scrip info segment change event
   * @param event 
   */
  segmentChanged(event) {
try{
    if (this.selectedSegment == "Events") {
      // if (this.isGuestMode) {
//         this.selectedSegment = '';
        // return;
      // }
      if (this.meetingtList.length == 0) {
        this.getBoardMeetingData();
      }
      if (this.AGMList.length == 0) {
        this.getEGMAGMData("AGM");
      }
      if (this.EGMList.length == 0) {
        this.getEGMAGMData("EGM");
      }
      if (this.splitData.length == 0) {
        this.getSpiltData();
      }
      if (this.dividendData.length == 0) {
        this.getDivident();
      }
      if (this.bookclosureData.length == 0) {
        this.GetBookClosure();
      }
      if (this.buyBackData.length == 0) {
        this.getBuyBackData();
      }
      if (this.rightsData.length == 0) {
        this.getRightsData();
      }
      if (this.scripNews.length == 0 && this.cmotMode != 0 && this.cmotMode != 1) {
        this.fetchScripNews();
      }

    }
    if (this.selectedSegment == "Futures") {
      // if (this.isGuestMode) {
        // this.selectedSegment = '';
      //   return;
      // }
      if (this.futData.length == 0) {
        this.getFutData();
      }
      else {
        this.lstScripKey = [];
        for (let i = 0; i < this.futData.length; i++) {
          this.futData[i].LTP = "0.00";
          this.futData[i].NetChangeInRs = "0.00";
          this.futData[i].PercNetChange = "0.00";
          this.futData[i].PremiumDiscount = "0.00"
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = this.futData[i]._source.nToken;
          objScrpKey.MktSegId = this.futData[i]._source.nMarketSegmentId;
          this.lstScripKey.push(objScrpKey);
        }
        this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
      }
    }
    if (this.selectedSegment == "Recommendations") {
      this.getRecommendation();
      if (this.futData.length == 0) {
        this.getFutData();
      }
    }
    if (this.selectedSegment == "Analytics") {
      if (this.isGuestMode) {
        // this.selectedSegment = '';
        return;
      }
      this.analyticMode = "technical"
      if (this.chartdetails.length == 0) {
        this.getChartData(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token, 5);
      }
      this.securityInfo.MCapCallBack = this.setSecurityInfo.bind(this);
      this.contractInfo.MCapCallBack = this.calculateMarketCap.bind(this);
      if (!this.securityInfo.isDataFetch)
        this.securityInfo.displayDetails(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token);
      else {
        this.calculateMarketCap(this.securityInfo.IssuedCapital);
      }
      if (this.movingAvgDataNse == undefined && this.cmotMode != 0 && this.cmotMode != 1) {
        this.GetMovingAvg("NSE_EQ");
        this.GetMovingAvg("BSE_EQ");
      }
      this.modalPutCallRatio = "Price"
      if (this.putCallMastreData.length == 0) {
        this.getPutCallMasterData();
      }
      else{
        this.bindPutCallchart(this.arrputCallPriceCEData, this.arrputCallPricePEData, "Price")
      }
      this.getOIBuitData();
      if (this.cmotMode != 0 && this.cmotMode != 1) {
        this.getVolumeVsDelivery();
      }

    }
    if (this.selectedSegment == "OptionChain") {
      // if (this.isGuestMode) {
        // this.selectedSegment = '';
      //   return;
      // }
      if (this.selectedOptionContract.length == 0) {
        this.getOptData();
      }
      else {
        this.ShowOptionChain(this.distinctOptExpiryDate[0], 0)
      }
    }
    if (this.selectedSegment == "CompanyInfo") {
      // if (this.isGuestMode) {
        // this.selectedSegment = '';
      //   return;
      // }
      if (!this.securityInfo.isDataFetch) {
        this.securityInfo.displayDetails(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token);
      }
      this.fetchBoardDirector();
      this.fetchCompanyBackground();
      if (this.cmotMode != 0 && this.cmotMode != 1) {
        this.getCompanyHistory();
      }
      this.getcompanyListingData();
      this.getcompanyExchangeData();
      this.contactInfoInner = "RegisterAddress"
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','segmentChanged', error.Message, undefined, error.stack, undefined, undefined));
  }
    //console.log(event);
  }
  showOrderEntry(side) {
try{
    if (this.checkGuestMode()) {
      return;
    }

    let SegmentId = this.selectedScrip.scripDet.MktSegId;
    if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }
 
    if(parseInt(this.selectedScrip.Spread) == 1)
    {
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
      objOEFormDetail.scripDetl = this.selectedScrip;
      objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
      this.paramService.myParam = objOEFormDetail;
      this.navCtrl.navigateForward('spread-orderentry');
    }
    else
    {
    let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
    objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
    objOEFormDetail.buyQty = 1;
    objOEFormDetail.sellQty = 1;
    objOEFormDetail.orderQty = 1;

    objOEFormDetail.scripDetl = this.selectedScrip;

    objOEFormDetail.pageSource = clsConstants.C_V_BESTFIVE_PAGENO;

    this.paramService.myParam = objOEFormDetail;
    this.navCtrl.navigateForward('orderentry');
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','showOrderEntry', error.Message, undefined, error.stack, undefined, undefined));
  }

  }
  showRecoOrderEntry(item){
    try { 
     
      if (this.checkGuestMode()) {
        return;
      }
  
      let SegmentId = this.selectedScrip.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }
     
      let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
      
      for(let index = 1 ; index < clsGlobal.User.productTypesList.length; index++){
        if(clsGlobal.User.productTypesList[index] == "BRACKET"){
          this.isBracketAllowed = true;
        }
        if(clsGlobal.User.productTypesList[index] == "COVER"){
          this.isCoverAllowed = true;
        }
      }

      if (item.sRecoDetails[0].nBuySellText.toUpperCase() == clsConstants.C_S_ORDER_BUY_TEXT) {
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyPrice = item.sRecoDetails[0].EnteredPrice;
      
      }
      else {
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.sellPrice = item.sRecoDetails[0].EnteredPrice;
      }
      objOEFormDetail.orderPrice = item.sRecoDetails[0].EnteredPrice;
      let productType = clsGlobal.User.userPreference == undefined  || clsGlobal.User.userPreference.sOrder == null || clsGlobal.User.userPreference.sOrder == undefined ? "INTRADAY": JSON.parse(clsGlobal.User.userPreference.sOrder).productType;//orderPref;//"intraday";// added by sonali
      
      if(item.sRecoDetails[0].SLPrice!= "" && item.sRecoDetails[0].SQPrice == ""){
        objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;//clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT//"sl-mkt";//cover
        objOEFormDetail.recoSQprice =0; //item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = item.sRecoDetails[0].SLPrice;
        if( this.isCoverAllowed){
          objOEFormDetail.productType = "COVER";
        }else{
          objOEFormDetail.productType = productType;
        }
        
      }
      else if(item.sRecoDetails[0].SLPrice!= "" && item.sRecoDetails[0].SQPrice != ""){
        if(item.sRecoDetails[0].EnteredPrice != "0"){
          objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;//C_S_ORDER_REGULARLOT_TEXT;//"rl";//bracket 
        }
        else{
          objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
        }
          objOEFormDetail.recoSQprice = item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = item.sRecoDetails[0].SLPrice;
        if( this.isBracketAllowed){
          objOEFormDetail.productType = "BRACKET";
        }else{
          objOEFormDetail.productType = productType;
        }
      }
      else {
        objOEFormDetail.recoSQprice = 0;//item.sRecoDetails[0].SQPrice;
        objOEFormDetail.recoSLprice = 0;//item.sRecoDetails[0].SLPrice;
        objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT; //"rl";//normal
      
        if(productType == "DELIVERY" && (item.exchange == clsConstants.C_S_NSE_DERV_API || item.exchange == clsConstants.C_S_BSE_DERV_API 
          || item.exchange == clsConstants.C_S_MCX_DERV_API || item.exchange == clsConstants. C_S_ICEX_DERV_API 
          || item.exchange == clsConstants.C_S_NCDEX_DERV_API) ){
            objOEFormDetail.productType = "CARRYFORWARD";
          }
          else{
            objOEFormDetail.productType = productType;
          }
      }
      
      

      objOEFormDetail.buyQty = 1;
      objOEFormDetail.sellQty = 1;
      objOEFormDetail.orderQty = 1;
      //objOEFormDetail.
     
       objOEFormDetail.scripDetl = this.selectedScrip;
      //currScrip;
      objOEFormDetail.pageSource = clsConstants.C_V_RECOMMENDATION_PAGE;
      objOEFormDetail.recoId = item.sRecoDetails[0].sRecoId;
      this.paramService.myParam = objOEFormDetail;
      this.navCtrl.navigateForward('orderentry');
     
    } catch (error) {
      this.toastCtrl.showAtBottom("Unable to open order entry, kindly contact administrator.");
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'showrRecoOrderEntry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','showrRecoOrderEntry', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  showWatchList: boolean = false;
  showAddWatchList(from, item) {
    if (from == 'overview') {
      this.selecteScripAddToWatchlist = this.selectedScrip
    }
    else {
      this.selecteScripAddToWatchlist = clsCommonMethods.getScripObject(item._source).scripDetail;
    }

    this.showWatchList = !this.showWatchList;
    this.showMenuIcon = false;
  }
  watchListEvent(event) {
    this.showWatchList = false;
  }

  openNewsclick(newsObj) {
    setTimeout(() => { this.data = true; }, 2000);
    this.openNews = !this.openNews;
    this.otherNews = [];
    this.newsDetails = newsObj;
    for (let count = 0; count < this.scripNews.length; count++) {
      if (this.scripNews[count].index != newsObj.index) {
        this.otherNews.push(this.scripNews[count]);
      }
    }
  }

  openOtheNewsclick(newsObj) {
    try{
    this.data = false;
    setTimeout(() => { this.data = true; }, 2000);
    this.otherNews = [];
    this.newsDetails = newsObj;
    for (let count = 0; count < this.scripNews.length; count++) {
      if (this.scripNews[count].index != newsObj.index) {
        this.otherNews.push(this.scripNews[count]);
      }
    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','openOtheNewsclick', error.Message, undefined, error.stack, undefined, undefined));
  }
  }
  closeNewsclick() {
    this.openNews = false;
    this.data = false;
  }
  openboardmeetingclick(meetingData) {
    this.openboardmeeting = !this.openboardmeeting;
    if (meetingData != undefined)
      this.boardMeetingDetails = meetingData;
  }
  openbookclosureclick(bookClosureData) {
    this.openbookclosure = !this.openbookclosure;
    if (bookClosureData != undefined)
      this.bookClosureDetails = bookClosureData;
  }
  openagmclick(agmData) {
    this.openagm = !this.openagm;
    if (agmData != undefined)
      this.agmDetails = agmData
  }
  openegmclick(egmData) {
    this.openegm = !this.openegm;
    if (egmData != undefined)
      this.egmDetails = egmData;
  }
  opensplitclick(splitData) {
    this.opensplit = !this.opensplit;
    if (splitData != undefined)
      this.splitDetails = splitData
  }
  opendividendclick(dividendData) {
    this.opendividend = !this.opendividend;
    if (dividendData != undefined)
      this.dividendDetails = dividendData;
  }
  showprofitlossMore() {
    this.showmore = !this.showmore;
  }
  openManagementdetails(item) {
    if (item != undefined) {
      this.BoardDirectorDetails = item
    }
    this.showManagementPopup = !this.showManagementPopup;
  }

  eventsActionChange(event) {
try{
    if (event.detail.value == "agm") {
      if (this.AGMList.length == 0) {
        this.getEGMAGMData("AGM");
      }
    }
    if (event.detail.value == "egm") {
      if (this.EGMList.length == 0) {
        this.getEGMAGMData("EGM");
      }
    }
    if (event.detail.value == "split") {
      if (this.splitData.length == 0) {
        this.getSpiltData();
      }
    }
    if (event.detail.value == "dividend") {
      if (this.dividendData.length == 0) {
        this.getDivident();
      }
    }
    if (event.detail.value == "bookclosure") {
      if (this.bookclosureData.length == 0) {
        this.GetBookClosure();
      }
    }
    if (event.detail.value == "buyback") {
      if (this.buyBackData.length == 0) {
        this.getBuyBackData();
      }
    }
    if (event.detail.value == "rights") {
      if (this.rightsData.length == 0) {
        this.getRightsData();
      }
    }

    this.eventActions = event.detail.value;
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','eventsActionChange', error.Message, undefined, error.stack, undefined, undefined));
  }
  }
  setAlert() {
    if (!this.checkGuestMode()) {
      this.showMenuIcon = false;
      this.paramService.myParam = this.selectedScrip;
      this.navCtrl.navigateForward("setalerts");
    }
  }
  getFNOPulseData() {
    this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
      + 'v1/FNOPulseData/' + 2 + '/' + this.selectedScrip.symbol + '/null/null')
      .subscribe((respData: any) => {
        if (respData.status == true) {
          if (respData.result.length > 0) {
            this.marketPulsData = respData.result;
            this.marketPulsNoDataFound = false;
          }
          else {
            this.marketPulsNoDataFound = true;
          }
        }
        else {
          this.marketPulsNoDataFound = true;
        }
      }, error => {
        console.log(error);
        this.marketPulsNoDataFound = true;
        //clsGlobal.logManager.writeErrorLog('scipinfoPage', 'getFNOPulseData', err);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getFNOPulseData', error.Message, undefined, error.stack, undefined, undefined));
      });
  }
  async orderEntryPush(item) {
    try{
    if (this.checkGuestMode()) {
      return;
    }

    if (item.scripDetail == undefined) {
      let Token = item.nToken;
      let mktSegId = clsTradingMethods.GetMarketSegmentID(item.nMarketSegmentId)
      let scripdetail = {
        scrips: [{
          mkt: clsTradingMethods.getApiExchangeName(mktSegId),
          token: item.nToken
        }]
      }
      clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
        //console.log("Scrip Found: ", scrip);
        if (resp.result[0] != undefined) {
          let scrip = resp.result[0];
          let currScrip: clsScrip = new clsScrip();
          currScrip.scripDet.MktSegId = scrip.nMarketSegmentId;
          currScrip.scripDet.token = scrip.nToken;
          currScrip.symbol = scrip.sSymbol;
          currScrip.Series = scrip.sSeries;
          currScrip.InstrumentName = scrip.sInstrumentName;
          currScrip.ExpiryDate = scrip.nExpiryDate1;
          currScrip.StrikePrice = scrip.nStrikePrice || "-1";
          currScrip.OptionType = scrip.sOptionType || "NA";
          currScrip.MarketLot = scrip.nRegularLot || 1;
          currScrip.PriceTick = scrip.nPriceTick || 1;

          if (!clsCommonMethods.isLoginAllowed(mktSegId)) {
            this.alertCtrl.showAlert(
              "You are currently not allowed to place/modify/cancel order in this segment",
              "Order Error!"
            );
            return
          }

          let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
          objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
          objOEFormDetail.pageSource = clsConstants.C_V_BESTFIVE_PAGENO;
          objOEFormDetail.scripDetl = currScrip;
          objOEFormDetail.buyQty = 1;
          objOEFormDetail.sellQty = 1;
          objOEFormDetail.orderQty = 1;
          this.paramService.myParam = objOEFormDetail;
          this.navCtrl.navigateForward('orderentry');

        } else {
          //console.log("Scrip not found in sqllite: ", exchange, "--", Token);
        }

      }, error => {
        //console.log("unable to find scrip: ", Token, " ", exchange);
      });

    }
  }catch(error){
    clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','orderEntryPush', error.Message, undefined, error.stack, undefined, undefined));
  }
  }
  fetchCompanySector() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getCompanySector(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.resultset.length > 0) {
                //this.SectorName = resp.ResponseObject.resultset[0].Sector_Name;
              }
            }
          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchCompanySector1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanySector1', error.Message, undefined, error.stack, undefined, undefined));
          }
        })
        .catch(error => {
          //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchCompanySector2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanySector2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchCompanySector3', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanySector3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  fetchScripNews() {
    try {

      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/10"
      this.cdsService
        .getScripNews(reqString)
        .then((data: any) => {
          if (
            data.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS &&
            data.ResponseObject.resultset.length > 0
          ) {
            this.scripNews = [];
            for (
              let index = 0;
              index < data.ResponseObject.resultset.length;
              index++
            ) {
              let element = data.ResponseObject.resultset[index];
              let newsDetail: any = {};
              newsDetail.index = index;
              newsDetail.heading = element.Heading.trim();
              newsDetail.details = element.ArtText.trim();
              let date = element.Date.split("/")[1];
              let month = element.Date.split("/")[0].length == "2" ? clsCommonMethods.getMonthFormat(element.Date.split("/")[0]) : clsCommonMethods.getMonthFormat("0" + element.Date.split("/")[0])
              let time = (element.Date.split(" ")[1]).split(":")[0] + ":" + (element.Date.split(" ")[1]).split(":")[1] + " " + element.Date.split(" ")[2]
              newsDetail.date = date + " " + month + ", " + time;
              this.scripNews.push(newsDetail);
            }
          }
        })
        .catch(error => {
          //this.showNewsLoader = false;
          //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchScripNews1', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchScripNews1', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchScripNews2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchScripNews2', error.Message, undefined, error.stack, undefined, undefined));
      //this.showNewsLoader = false;
    }
  }

  getEGMAGMData(agmegmmode) {

    let fromDate = this.cdsFromData//(new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000))).toISOString();//.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let toDate = this.cdsToDate//new Date().toISOString(); //.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let reqString = "/" + agmegmmode + "/" + fromDate + "/" + toDate + "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/1/10"
    this.cdsService
      .getAGMEGM(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              if (agmegmmode == "AGM") {
                this.agmNoDataFound = false
                for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                  if (objresponse.ResponseObject.resultset[i].Upcoming) {
                    this.count++
                    if (this.corpActionLable.indexOf("AGM") == -1) {
                      this.corpActionLable += "AGM,"
                    }

                  }
                  this.AGMList.unshift(objresponse.ResponseObject.resultset[i]);
                }
              }
              else if (agmegmmode == "EGM") {
                this.egmNoDataFound = false
                for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                  if (objresponse.ResponseObject.resultset[i].Upcoming) {
                    this.count++
                    if (this.corpActionLable.indexOf("EGM") == -1) {
                      this.corpActionLable += "EGM,"
                    }

                  }
                  this.EGMList.unshift(objresponse.ResponseObject.resultset[i]);
                }
              }
            }
            else {
              if (agmegmmode == "AGM") {
                this.agmNoDataFound = true
              }
              else if (agmegmmode == "EGM") {
                this.egmNoDataFound = true
              }
            }
          }
          else {
            if (agmegmmode == "AGM") {
              this.agmNoDataFound = true
            }
            else if (agmegmmode == "EGM") {
              this.egmNoDataFound = true
            }
          }
        } catch (error) {
          if (agmegmmode == "AGM") {
            this.agmNoDataFound = true
          }
          else if (agmegmmode == "EGM") {
            this.egmNoDataFound = true
          }
        } finally {
          //this.showLoader = false;
        }
      }).catch(error => {
        if (agmegmmode == "AGM") {
          this.agmNoDataFound = true
        }
        else if (agmegmmode == "EGM") {
          this.egmNoDataFound = true
        }
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','agmegm', error.Message, undefined, error.stack, undefined, undefined));
      })
  }
  getBoardMeetingData() {
    let fromDate = this.cdsFromData;//(new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000))).toISOString();//.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let toDate = this.cdsToDate;//new Date().toISOString(); //.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + fromDate + "/" + toDate + "/1/100"
    this.cdsService
      .getBoardMeetings(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              this.bmNoDataFound = false
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Board Meeting") == -1) {
                    this.corpActionLable += "Board Meeting,"
                  }
                }
                this.meetingtList.unshift(objresponse.ResponseObject.resultset[i]);
              }
            }
            else {
              this.bmNoDataFound = true
            }
          } else {
            this.bmNoDataFound = true
          }
        } catch (error) {
          this.bmNoDataFound = true
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBoardMeetingData", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getBoardMeetingData', error.Message, undefined, error.stack, undefined, undefined));
        } finally {
          //this.showLoader = false;
        }
      })
      .catch(error => {
        this.bmNoDataFound = true
        //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBoardMeetingData", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getBoardMeetingData2', error.Message, undefined, error.stack, undefined, undefined));
      });
  }
  getSpiltData() {
    let fromDate = this.cdsFromData;//(new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000))).toISOString();//.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let toDate = this.cdsToDate;//new Date().toISOString(); //.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + fromDate + "/" + toDate + "/100"
    this.cdsService
      .getSplits(reqString)
      .then((objresponse: any) => {
        try {
          let resp = objresponse;
          if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (resp.ResponseObject.recordcount > 0) {
              this.splitNoDataFound = false;
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Split Announced") == -1) {
                    this.corpActionLable += "Split Announced,"
                  }
                }
                this.splitData.unshift(objresponse.ResponseObject.resultset[i])
              }
            }
            else {
              this.splitNoDataFound = true;
            }
          } else {
            this.splitNoDataFound = true;
          }
        } catch (error) {
          this.splitNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog('scripinfo', 'getSpiltData', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getSpiltData', error.Message, undefined, error.stack, undefined, undefined));
        }
      }).catch(error => {
        this.splitNoDataFound = true;
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getSpiltData2', error.Message, undefined, error.stack, undefined, undefined));
      })
  }
  getDivident() {
    let fromDate = this.cdsFromData//(new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000))).toISOString();//.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let toDate = this.cdsToDate//new Date().toISOString(); //.getDate() + "-"+new Date().getMonth()+1+"-"+new Date().getFullYear();
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + fromDate + "/" + toDate + "/100"
    this.cdsService
      .getDivident(reqString)
      .then((objresponse: any) => {
        try {
          let resp = objresponse;
          if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (resp.ResponseObject.recordcount > 0) {
              this.dividendNoDataFound = false
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Dividend Declared") == -1) {
                    this.corpActionLable += "Dividend Declared,"
                  }
                }
                this.dividendData.unshift(objresponse.ResponseObject.resultset[i])
              }
            }
            else {
              this.dividendNoDataFound = true
            }
          } else {
            this.dividendNoDataFound = true
          }
        } catch (error) {
          this.dividendNoDataFound = true
          //clsGlobal.logManager.writeErrorLog('scripinfo', 'getDivident', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getDivident', error.Message, undefined, error.stack, undefined, undefined));
        }
      }).catch(error => {
        this.dividendNoDataFound = true
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getDivident2', error.Message, undefined, error.stack, undefined, undefined));
      })
  }
  GetBookClosure() {
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
    this.cdsService
      .GetBookClosure(reqString)
      .then((objresponse: any) => {
        try {
          let resp = objresponse;
          if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (resp.ResponseObject.recordcount > 0) {
              this.bookClosureNoDataFound = false;
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Book Closure") == -1) {
                    this.corpActionLable += "Book Closure,"
                  }
                }
                this.bookclosureData.unshift(objresponse.ResponseObject.resultset[i]);
              }
            }
            else {
              this.bookClosureNoDataFound = true;
            }
          } else {
            this.bookClosureNoDataFound = true;
          }
        } catch (error) {
          this.bookClosureNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog('scripinfo', 'GetBookClosure', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetBookClosure', error.Message, undefined, error.stack, undefined, undefined));
        }
      }).catch(error => {
        this.bookClosureNoDataFound = true;
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetBookClosure2', error.Message, undefined, error.stack, undefined, undefined));
      })
  }
  getRightsData() {

    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
    this.cdsService
      .getRightsData(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              this.rightsNoDataFound = false;
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Rights") == -1) {
                    this.corpActionLable += "Rights,"
                  }
                }
                this.rightsData.unshift(objresponse.ResponseObject.resultset[i])
              }
            }
            else {
              this.rightsNoDataFound = true;
            }
          } else {
            this.rightsNoDataFound = true;
          }
        } catch (error) {
          this.rightsNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getrightsData", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getrightsData', error.Message, undefined, error.stack, undefined, undefined));
        } finally {

        }
      })
      .catch(error => {
        this.rightsNoDataFound = true;
        //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getrightsData", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getrightsData2', error.Message, undefined, error.stack, undefined, undefined));
      });
  }
  getBuyBackData() {
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
    this.cdsService
      .getBuyBackData(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              this.buyBackNoDataFound = false;
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                if (objresponse.ResponseObject.resultset[i].Upcoming) {
                  this.count++
                  if (this.corpActionLable.indexOf("Buy Back") == -1) {
                    this.corpActionLable += "Buy Back,"
                  }
                }
                this.buyBackData.unshift(objresponse.ResponseObject.resultset[i])
              }
            }
            else {
              this.buyBackNoDataFound = true;
            }
          } else {
            this.buyBackNoDataFound = true;
          }
        } catch (error) {
          this.buyBackNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBuyBackData", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getBuyBackData', error.Message, undefined, error.stack, undefined, undefined));
        } finally {

        }
      })
      .catch(error => {
        this.buyBackNoDataFound = true;
        //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBuyBackData", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getBuyBackData', error.Message, undefined, error.stack, undefined, undefined));
      });
  }

  getMktSegmentId() {
    return clsCommonMethods.getExchangeName(this.selectedScrip.scripDet.MktSegId);
  }
  gettoken() {
    return this.selectedScrip.scripDet.token;
  }
  getAssetMktSegmentId() {
    return clsCommonMethods.getAssetExchangeName(this.selectedScrip.scripDet.MktSegId);
  }
  getAssetToken() {
    if (this.selectedScrip.AssetToken == "" || this.selectedScrip.AssetToken == "0")
      return this.selectedScrip.scripDet.token;
    else
      return this.selectedScrip.AssetToken;
  }

  /**
   * to display advance chart page.
   */
  showAdvanceChart() {
    try {
      if (!this.checkGuestMode()) {
        this.paramService.myParam = this.selectedScrip;
        this.navCtrl.navigateForward("advance-chart-iq");
        this.showMenuIcon = false;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('scripInfoPage', 'showAdvanceChart', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','showAdvanceChart', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  receiveMessage(event) {
    this.showPopUpOE = false;
    this.showFullMode = false;
  }
  //show Order Entry PopUp.
  showPopUpOrderEntry(item, side) {
    try {
      if (this.checkGuestMode()) {
        return;
      }
      //let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
      let ScripObj = clsCommonMethods.getScripObject(item._source);;
      // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
      let SegmentId = ScripObj.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      if(parseInt(ScripObj.scripDetail.Spread) == 1)
      {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL; objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.scripDetl = ScripObj.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.paramService.myParam = objOEFormDetail;
        this.navCtrl.navigateForward('spread-orderentry');
      }
      else
      {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL; objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
  
        objOEFormDetail.scripDetl = ScripObj.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.selectedScripObj = objOEFormDetail;
  
        this.showPopUpOE = true;
  
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("scripinfo", "showPopUpOrderEntry", error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','showPopUpOrderEntry', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  cashDetails = [];
  exchangeSelected: any;
  exchangeScripList = [];
  showExchangePopUp() {

    if (this.selectedScrip.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
      this.selectedScrip.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
      this.selectedScrip.scripDet.MktSegId != clsConstants.C_V_MSX_CASH) {
      return;
    }
    this.showExchange = !this.showExchange;
  }

  //: TO DO Broadcast code for guest User
  getCdsBroadCast() {
    let reqString = "/" + this.getMktSegmentId() + "/" + this.gettoken()
    this.cdsService
      .getCdsBroadcast(reqString)
      .then((objresponse: any) => {
        try {

        } catch (error) {

          //clsGlobal.logManager.writeErrorLog('scripinfo', 'GetBookClosure', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetBookClosure', error.Message, undefined, error.stack, undefined, undefined));
          
        }
      }).catch(error => {
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetBookClosure2', error.Message, undefined, error.stack, undefined, undefined));
      })
  }

  getExchangeList() {
    try {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/EQUITIES/" + null + "/" + this.selectedScrip.symbol).subscribe(exchData => {


        let resultdata: any = exchData
        for (let index = 0; index < resultdata.result.hits.hits.length; index++) {
          const element = resultdata.result.hits.hits[index]._source;

          let currScrip: clsScrip = new clsScrip();
          currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId);
          currScrip.scripDet.token = element.nToken;
          currScrip.symbol = element.sSymbol;
          currScrip.Series = element.sSeries;
          currScrip.InstrumentName = element.sInstrumentName;
          currScrip.ExpiryDate = element.nExpiryDate;
          currScrip.StrikePrice = element.nStrikePrice || "-1";
          currScrip.OptionType = element.sOptionType || "NA";
          currScrip.MarketLot = element.nRegularLot || 1;
          currScrip.PriceTick = element.nPriceTick || 1;
          this.exchangeScripList.push(currScrip);
          if (this.ExchangeNames == null) {
            this.ExchangeNames = element.exchangeName
          }
          else {
            this.ExchangeNames += "," + element.exchangeName
          }

        }
        //this.exchangeScripList = resultdata;
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getExchangeList', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getExchangeList', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  toggleExchange(scrip) {
    try {
      this.showExchange = !this.showExchange;
      this.selectedScrip = scrip
      this.initializeQuote();


    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'toggleExchange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','toggleExchange', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  futureClick(item) {
    const element = item;
    let currScrip: clsScrip = new clsScrip();
    currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId);
    currScrip.scripDet.token = element.nToken;
    currScrip.symbol = element.sSymbol;
    currScrip.Series = element.sSeries;
    currScrip.InstrumentName = element.sInstrumentName;
    currScrip.ExpiryDate = element.nExpiryDate1;
    currScrip.StrikePrice = element.nStrikePrice || "-1";
    currScrip.OptionType = element.sOptionType || "NA";
    currScrip.MarketLot = element.nRegularLot || 1;
    currScrip.PriceTick = element.nPriceTick || 1;
    currScrip.AssetToken = element.nAssetToken || 0;
    this.selectedScrip = currScrip;
    this.selectedSegment = "Overview"
    this.initializeQuote();
  }

  /****************************** Recommendations TAB Code START *******************/
  async getRecommendation() {
    try {
      this.recoData = [];
      let recmParamReq: any = {};
      let mktSegId = clsTradingMethods.getMappedMarketSegmentId( this.selectedScrip.scripDet.MktSegId);
      recmParamReq.mktSegId =mktSegId;
      recmParamReq.token = this.selectedScrip.scripDet.token;
      recmParamReq.allowedNewsCat = clsGlobal.User.NewsCategories;
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getRecommendation', recmParamReq).subscribe(resRec => {
        if (resRec.status == true) {
          let recdata: any = resRec.result;
          if (recdata.length > 0) {
            for (let i = 0; i < recdata.length; i++) {
              let mktSegId = clsTradingMethods.GetMarketSegmentID(recdata[i].nMarketSegmentId);
              if (clsCommonMethods.isMktDataAllowed(mktSegId)) {
                let exchange = clsTradingMethods.getApiExchangeName(mktSegId);
                recdata[i].exchange = exchange;
                recdata[i].sRecoDetails = this.convertXmlToJson(recdata[i].sRecoDetails);
                recdata[i].sRecoType = ((recdata[i].sRecoDetails[0].sLongShort == "L") ? "Long Call" : "Short Call");
                recdata[i].detailsVisible = false;
                recdata[i].dEndTime = clsCommonMethods.getRecoDateTime(recdata[i].dEndTime);
                recdata[i].selctedReco = false;

                let recoEntryPrice = parseFloat(recdata[i].sRecoDetails[0].EnteredPrice);
                let calSLPrice = recoEntryPrice - ((recoEntryPrice * 10) / 100);
                let calSQPrice = recoEntryPrice + ((recoEntryPrice * 10) / 100);
                let recoSLPrice = recdata[i].sRecoDetails[0].SLPrice == '' ? calSLPrice : parseFloat(recdata[i].sRecoDetails[0].SLPrice);
                let recoSQPrice = recdata[i].sRecoDetails[0].SQPrice == '' ? calSQPrice : parseFloat(recdata[i].sRecoDetails[0].SQPrice);
                let recoLTP = parseFloat(this.scripLTP);

                recdata[i].graphValue = [
                  {
                    "value": recoEntryPrice,
                    "color": "A",
                    "lable": "EntyrPrice"
                  },
                  {
                    "value": recoSLPrice,
                    "color": "A",
                    "lable": "SLPrice"
                  },
                  {
                    "value": recoSQPrice,
                    "color": "A",
                    "lable": "TargetPrice"
                  },
                  {
                    "value": recoLTP,
                    "color": "A",
                    "lable": "LTP"
                  }].sort((n1, n2) => n1.value - n2.value)
                recdata[i].minValue = recdata[i].graphValue[0].value; //== 0 ? 'ND' : scripRecoItem.graphValue[0].value;== 0 ? 'ND' :scripRecoItem.graphValue[1].value
                recdata[i].maxValue = recdata[i].graphValue[3].value; //==

                this.recoData.push(recdata[i])
              }
            }
          }
          else {
            this.noDataFoundReco = true;
          }
        }
        else {
          this.noDataFoundReco = true;
        }
      }, error => {
        this.noDataFoundReco = true;
        //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getRecommendation1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getRecommendation1', error.Message, undefined, error.stack, undefined, undefined));
      });

    } catch (error) {
      this.noDataFoundReco = true;
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getRecommendation2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getRecommendation2', error.Message, undefined, error.stack, undefined, undefined));

    }
  }

  convertXmlToJson(sRecoDetails) {
    try {
      let json = [];
      console.log(this.scripLTP);
      xml2js.parseString(sRecoDetails, function (err, result) {
        for (let i = 0; i < result.RecoDetails.RecoChild.length; i++) {
          let data = result.RecoDetails.RecoChild[i].$
          data.nBuySellText = data.nBuySell == "1" ? "Buy" : "Sell";
          data.targetPrice = data.SQPrice == '' ? 'ND' : parseFloat(data.SQPrice);
          data.SLprice = data.SLPrice == '' ? 'ND' : parseFloat(data.SLPrice);
          data.buyExit = data.nBuySellText == 'Buy' ? 'Buy' : 'Exit';
          json.push(data);
        }
      });
      return json
    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','convertXmlToJson', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  showfollowReco(index) {
    this.recoData[index].selctedReco = true;
  }

  hidefollowReco(index) {
    this.recoData[index].selctedReco = false;
  }
  /****************************** Recommendations TAB Code END *******************/


  /****************************** Analytics TAB Code START *******************/
  analyticChange(event) {
    try {
      this.analyticMode = event.detail.value;
      if (event.detail.value == 'technical') {
        if (this.chartdetails.length == 0) {
          this.getChartData(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token, 5);
        }
        else
        {
          setTimeout(() => {
            this.getChartDetails();
          }, 300);  
          
        }
        this.securityInfo.MCapCallBack = this.setSecurityInfo.bind(this);
        this.contractInfo.MCapCallBack = this.calculateMarketCap.bind(this);
        if (!this.securityInfo.isDataFetch)
          this.securityInfo.displayDetails(this.selectedScrip.scripDet.MapMktSegId, this.selectedScrip.scripDet.token);
        else {
          this.calculateMarketCap(this.securityInfo.IssuedCapital);
        }
        if (this.movingAvgDataNse.length == 0 && this.cmotMode != 0 && this.cmotMode != 1) {
          this.GetMovingAvg("NSE_EQ");
        }
        if (this.movingAvgDataBse.length == 0 && this.cmotMode != 0 && this.cmotMode != 1) {
          this.GetMovingAvg("BSE_EQ");
        }
        this.modalPutCallRatio = "Price";
        if (this.putCallMastreData.length == 0) {
          this.getPutCallMasterData();
        }
        else{    
          setTimeout(() => {
            this.bindPutCallchart(this.arrputCallPriceCEData, this.arrputCallPricePEData, "Price")
          }, 300);      
         
        }

        if(this.obj15min.length == 0)
        {
          this.getOIBuitData();
        }       

        if (this.cmotMode != 0 && this.cmotMode != 1) {
          if(this.vdChartTotalVolume.length == 0)
          {
            this.getVolumeVsDelivery();
          }
          else
          {
            setTimeout(() => {
              this.bindVolumeVsDelChart()
            }, 300);      
            
          }
         
        }


      } else if (event.detail.value == 'fundamental') {

        if(this.ShareHoldingPatternList.length == 0)
        {
          this.fetchShareHoldingPattern();
        }
        else{
          setTimeout(() => {
            this.bindShareholdingChart()
          }, 300);  
        }
       

        if(this.companyTotalScore == undefined || this.companyTotalScore.length == 0 ) 
        {
          this.getHealthTotalScore();
        }
       
        if(this.standaloneFinRatio.length == 0)
        {
          this.getCompanyFinRatioStandalone();
        }

        if(this.consolidatedFinRatio.length == 0)
        {
          this.getCompanyFinRatioCosolidated();
        }        
        
        this.modalTrendAnlytics = "newrevenue"

        if (this.cmotMode != 0 && this.cmotMode != 1) {
          if(this.arrQuarterlyTrendRevenue.length == 0)
          {
            this.getQuarterlyTrend("QuarterlyTrend-Revenue")
            this.getQuarterlyTrend("QuarterlyTrend-EBIT")
            this.getQuarterlyTrend("QuarterlyTrend-EBITDA")
            this.getQuarterlyTrend("QuarterlyTrend-Netprofit")
          }
          else{
            setTimeout(() => {
              let labels = ["New Revenue", "Gross Profit Margin %"]
              this.bindchart(this.arrQuarterlyTrendRevenue, labels)
            }, 300);  
           
          }
         
          this.fetchCompanyProfitLoss();
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'analyticChange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','analyticChange', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  chartdetails2 = [];
  getChartData(MktSegId, Token, chartTimeInterval) {
    try {
      this.chartdetails = [];
      this.chartlabels = [];
      let requestString = {
        MktSegId: MktSegId,
        Token: Token,
        TimeInterval: chartTimeInterval
      }
      this.http.postJson(clsGlobal.VirtualDirectory + clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId, "/getChartData", requestString) //http://172.25.91.98:8080/transactional/com.wave.test/v1/
        .subscribe(respData => {
          try {
            let response = respData.result[0]
            if (response.length > 0) {
              for (let count = 0; count < response.length; count++) {
                this.chartdetails.push(clsTradingMethods.ConvertToRe((response[count].nClose), MktSegId, "100"))
                this.chartlabels.push(clsCommonMethods.ConvertToDateObj(response[count].Time/* * 1000*/))
                this.chartdetails2.push(this.scripLTP)
              }
              this.getChartDetails();
              this.chartNoDataFound = false;
              
            }
            else {
              this.chartNoDataFound = true;
              this.toastCtrl.showAtBottom("Unable to show chart data");
            }
          } catch (error) {
            this.chartNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getChartData21', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getChartData', error.Message, undefined, error.stack, undefined, undefined));
          }
        }, error => {
          this.chartNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getChartData2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getChartData2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.chartNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getChartData3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getChartData3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  getChartDetails() {
    try {

      this.chartLineData = new Chart(
        this.lineChartDetailsCanvas.nativeElement,
        {
          type: 'line',
          data: {
            labels: this.chartlabels,
            datasets: [
              {
                data: this.chartdetails,
                borderWidth: 1,
                fill: false,
                pointRadius: 0
              },
              {
                label: 'Line Dataset',
                data: this.chartdetails2,
                type: 'line',
                // this dataset is drawn on top
                order: 1,
                borderWidth: 1,
                fill: false,
                pointRadius: 0,
                borderColor: '#2dd36f',
                borderDash: [5, 4],
                lineTension: 0,
                steppedLine: true
              }
            ]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  reverse: false
                },
                display: true,
                gridLines: {
                  display: true,
                  drawBorder: false,
                },
                position: 'right',
              },
              ],
              xAxes: [{
                display: true,
                gridLines: {
                  display: true,
                  drawBorder: false,
                },
                ticks: {
                  autoSkip: true,
                  maxTicksLimit: 3,
                  maxRotation: 0,
                  minRotation: 0
                }
              }]
            },
            responsive: true,
            elements: {
              line: {
                borderColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                borderWidth: 1,
                lineTension: 0
              }
            },
            tooltips: {
              enabled: false,
            },
            legend: {
              display: false
            },
            point: {
              radius: 0
            }
          }
        }
      );


    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getChartDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getChartDetails', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  setSecurityInfo(IssuedCapital) {
    this.calculateMarketCap(IssuedCapital);
  }

  calculateMarketCap(IssuedCapital) {
    try {
      this.issuedCapital = IssuedCapital;
      if (
        this.closePrice != "" &&
        this.closePrice != "-" &&
        this.issuedCapital != "NA" &&
        this.issuedCapital != ""
      ) {
        let MCap =
          parseFloat(this.issuedCapital.replace(/,/g, "")) *
          parseFloat(this.closePrice);
        this.MCap = this.numbertoString(MCap);
        this.isMarketCapCalculated = true;
      }

      this.bShowPivot = false;
      if (this.isSecurityInfo == true) {
        if (
          this.securityInfo.PrevDayLow != undefined &&
          this.securityInfo.PrevDayHigh != undefined &&
          this.securityInfo.PrevDayClose != undefined
        ) {
          this.PPPoint.prevDayOpen = this.securityInfo.PrevDayOpen;
          this.PPPoint.prevDayHigh = this.securityInfo.PrevDayHigh;
          this.PPPoint.prevDayLow = this.securityInfo.PrevDayLow;
          this.PPPoint.prevDayClose = this.securityInfo.PrevDayClose;
          this.PPPoint.PriceFormat = this.priceFormat;
          if (
            this.securityInfo.PrevDayLow != "" &&
            this.securityInfo.PrevDayHigh != "" &&
            this.securityInfo.PrevDayClose != ""
          ) {
            this.bShowPivot = true;
            this.PPPoint.calculatePP();

          }
        }
      } else {
        if (
          this.contractInfo.PrevDayOpen != undefined &&
          this.contractInfo.PrevDayHigh != undefined &&
          this.contractInfo.PrevDayClose != undefined
        ) {
          this.PPPoint.prevDayOpen = this.contractInfo.PrevDayOpen;
          this.PPPoint.prevDayHigh = this.contractInfo.PrevDayHigh;
          this.PPPoint.prevDayLow = this.contractInfo.PrevDayLow;
          this.PPPoint.prevDayClose = this.contractInfo.PrevDayClose;
          this.PPPoint.PriceFormat = this.priceFormat;

          if (
            this.contractInfo.PrevDayLow != "" &&
            this.contractInfo.PrevDayHigh != "" &&
            this.contractInfo.PrevDayClose != ""
          ) {
            this.isMarketCapCalculated = true;
            this.bShowPivot = true;
            this.PPPoint.calculatePP();
            //this.getPivotResistanceChart();
          }
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'calculateMarketCap', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','calculateMarketCap', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  GetMovingAvg(exchange) {
    try {
      let reqString = "/" + exchange + "/" + this.getAssetToken() /*this.gettoken()*/
      this.cdsService
        .GetMovingAvg(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount > 0) {
                this.mavgNoDataFound= false
                if (exchange == "NSE_EQ") {
                  this.movingAvgDataNse = resp.ResponseObject.resultset[0]
                }
                else if (exchange == "BSE_EQ") {
                  this.movingAvgDataBse = resp.ResponseObject.resultset[0]
                }
                
              }
              else {
                this.mavgNoDataFound= true;
              }
            } else {
          this.mavgNoDataFound= true;
            }
          } catch (error) {
            this.mavgNoDataFound= true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'GetMovingAvg1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetMovingAvg', error.Message, undefined, error.stack, undefined, undefined));
          }
        }).catch(error => {
          this.mavgNoDataFound= true;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'GetMovingAvg2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetMovingAvg2', error.Message, undefined, error.stack, undefined, undefined));
        })
    } catch (error) {
      this.mavgNoDataFound= true;
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'GetMovingAvg3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','GetMovingAvg3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  getPutCallMasterData() {
    try {
      this.arrputCallPriceCEData = [];
      this.arrputCallVolumeCEData = [];
      this.arrputCallOICEData = [];
      this.arrputCallIVCEData = [];
      this.arrputCallPricePEData = [];
      this.arrputCallVolumePEData = [];
      this.arrputCallOIPEData = [];
      this.arrputCallIVPEData = [];
      this.putCallMastreData = []
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + 'v1/PutCallMasterData/' + 2 + '/' + this.selectedScrip.symbol + '/' + 1 + '/null')
        .subscribe((respData: any) => {
         
          if(respData.result.length > 0){
            this.ptclmstDataNoDataFound = false;
          for (let j = 0; j < respData.result.length; j++) {
            this.putCallMastreData.push(JSON.parse(respData.result[j]))
          }
          this.arrputCallStrikePrice = this.getDistinctStrikePrice(this.putCallMastreData)
        
          for (let j = 0; j < this.arrputCallStrikePrice.length; j++) {
            let CEdata = this.putCallMastreData.filter(x => x.sOptionType == "CE" && x.nStrikePrice == this.arrputCallStrikePrice[j])
            if (CEdata.length > 0) {
              this.arrputCallPriceCEData.push(CEdata[0].nLastTradedPrice.toFixed(2))
              this.arrputCallVolumeCEData.push(CEdata[0].nTotalQtyTraded.toFixed(2))
              this.arrputCallOICEData.push(CEdata[0].nOpenInterest.toFixed(2))
              this.arrputCallIVCEData.push(CEdata[0].nImpliedVolatility.toFixed(2))
            }
            let PEdata = this.putCallMastreData.filter(x => x.sOptionType == "PE" && x.nStrikePrice == this.arrputCallStrikePrice[j])
            if (PEdata.length > 0) {
              this.arrputCallPricePEData.push(PEdata[0].nLastTradedPrice.toFixed(2))
              this.arrputCallVolumePEData.push(PEdata[0].nTotalQtyTraded.toFixed(2))
              this.arrputCallOIPEData.push(PEdata[0].nOpenInterest.toFixed(2))
              this.arrputCallIVPEData.push(PEdata[0].nImpliedVolatility.toFixed(2))
            }
          }
        
          this.bindPutCallchart(this.arrputCallPriceCEData, this.arrputCallPricePEData, "Price")
        }else{
          this.ptclmstDataNoDataFound = true;
        }

        }, error => {
          this.ptclmstDataNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getPutCallMasterData1', err);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getPutCallMasterData1', error.Message, undefined, error.stack, undefined, undefined));
          //this.loadingCtrl.hideLoader();

        });
    } catch (error) {
      this.ptclmstDataNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getPutCallMasterData2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getPutCallMasterData2', error.Message, undefined, error.stack, undefined, undefined));
    }

  }

  getDistinctStrikePrice(array) {
    let distinct = [...new Set(array.map(item => item.nStrikePrice))];
    return distinct;
  }

  putCallRatioClick(event) {

    if (event.detail.value == "Price") {
      this.bindPutCallchart(this.arrputCallPriceCEData, this.arrputCallPricePEData, event.detail.value)
    }
    else if (event.detail.value == "Volume") {
      this.bindPutCallchart(this.arrputCallVolumeCEData, this.arrputCallVolumePEData, event.detail.value)
    }
    else if (event.detail.value == "OI") {
      this.bindPutCallchart(this.arrputCallOICEData, this.arrputCallOIPEData, event.detail.value)
    }
    else if (event.detail.value == "IV") {
      this.bindPutCallchart(this.arrputCallIVCEData, this.arrputCallIVPEData, event.detail.value)
    }
    this.modalPutCallRatio = event.detail.value;
  }
  
  
  bindPutCallchart(CeData, PeData, labelString) {
    try {
    if (this.PutCallDetailChart != undefined) {
        this.PutCallDetailChart.destroy();
      }

      this.PutCallDetailChart = new Chart(
        this.PutCallDetailCanvas.nativeElement,
        {
          type: 'bar',
          data: {
            datasets: [{
              label: "CALL",
              data: CeData,
              backgroundColor: "#464983",
              barThickness: 8,
              // this dataset is drawn below
              order: 1
            }, {
              label: "PUT",
              data: PeData,
              type: 'bar',
              barThickness: 8,
              backgroundColor: "#6fa9e2",
              // this dataset is drawn on top
              order: 2
            }],
            labels: this.arrputCallStrikePrice
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  reverse: false,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                  maxTicksLimit: 4
                },
                gridLines: {
                  display: false
                },
                scaleLabel: {
                  display: true,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                  labelString: labelString
                },
              },
              ],
              xAxes: [{
                gridLines: {
                  display: false
                },
                scaleLabel: {
                  display: true,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                  labelString: 'Strike Price'
                },
                ticks: {
                  fontSize: 12,
                  padding: 0,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                }
              }]
            },
            cornerRadius: 2,
            maintainAspectRatio: false,
            responsive: true,
            tooltips: {
              enabled: false,
            },
            legend: {
              display: false
            },
          }
        }
      );
      
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'bindPutCallchart', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindPutCallchart', error.Message, undefined, error.stack, undefined, undefined));

    }
  }
  obj15min = [];
  obj30min = [];
  obj60min = [];
  index: number = 0;
  expiryDates = []
  oibuiltupData: any;
  oibuiltupDataless: any;
  oibuiltupDatamore: any;
  showmoreOIbuildup: boolean = false;
  async getOIBuitData() {
    try {
      if (this.futData.length == 0) {
        await this.getFutData();
      }
      let futDataforOI = this.futData.filter(x => x._source.nSpread == 0)
      for (let i = 0; i < futDataforOI.length; i++) {
       
          this.expiryDates.push(futDataforOI[i]._source.nExpiryDate1)
          if (i == 0) {
            this.getOIBuiltUpData(futDataforOI[i]._source.nToken, 1, futDataforOI[i]._source.nExpiryDate1)
          }
          if (i == 1) {
            this.getOIBuiltUpData(futDataforOI[i]._source.nToken, 2, futDataforOI[i]._source.nExpiryDate1)
          }
          if (i > 1) {
            this.getOIBuiltUpData(futDataforOI[i]._source.nToken, 3, futDataforOI[i]._source.nExpiryDate1)
          }
        
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getOIBuitData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getOIBuiltData', error.Message, undefined, error.stack, undefined, undefined));
    }

  }
 OIBuildupNoDataFound: boolean = false;
  async getOIBuiltUpData(token, Expiry, expiryDate) {
    try {

      await this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
        + 'v1/OIDataForScrip/' + 2 + '/' + token + '/' + Expiry)
        .subscribe((respData: any) => {
          try {
            this.index++;
            if (respData.status) {
              if (respData.result.length > 0) {
                this.OIBuildupNoDataFound = true;
                for (let j = 0; j < respData.result[0].sOIBuilUP.length; j++) {
                  if (this.index == 1) {
                    this.obj15min.unshift(
                      {
                        time: clsCommonMethods.ConvertToDateObjAmPM(respData.result[0].sOIBuilUP[j].Key),
                        expiryDate1: Expiry == 1 ? respData.result[0].sOIBuilUP[j].Value : "-",
                        expiryDate2: Expiry == 2 ? respData.result[0].sOIBuilUP[j].Value : "-",
                        expiryDate3: Expiry == 3 ? respData.result[0].sOIBuilUP[j].Value : "-",
                      })
                  }
                  else {
                    if (this.obj15min.length > 0) {
                      if (Expiry == 1) {
                        this.obj15min[j].expiryDate1 = respData.result[0].sOIBuilUP[j].Value
                      }
                      if (Expiry == 2) {
                        this.obj15min[j].expiryDate2 = respData.result[0].sOIBuilUP[j].Value
                      }
                      if (Expiry == 3) {
                        this.obj15min[j].expiryDate3 = respData.result[0].sOIBuilUP[j].Value
                      }
                    }
                  }
                }
                for (let j = 0; j < respData.result[0].sOIBuilUP30Min.length; j++) {

                  if (this.index == 1) {
                    this.obj30min.unshift(
                      {
                        time: clsCommonMethods.ConvertToDateObjAmPM(respData.result[0].sOIBuilUP30Min[j].Key),
                        expiryDate1: Expiry == 1 ? respData.result[0].sOIBuilUP30Min[j].Value : "-",
                        expiryDate2: Expiry == 2 ? respData.result[0].sOIBuilUP30Min[j].Value : "-",
                        expiryDate3: Expiry == 3 ? respData.result[0].sOIBuilUP30Min[j].Value : "-",
                      })
                  }
                  else {
                    if (this.obj15min.length > 0) {
                      if (Expiry == 1) {
                        this.obj30min[j].expiryDate1 = respData.result[0].sOIBuilUP30Min[j].Value
                      }
                      if (Expiry == 2) {
                        this.obj30min[j].expiryDate2 = respData.result[0].sOIBuilUP30Min[j].Value
                      }
                      if (Expiry == 3) {
                        this.obj30min[j].expiryDate3 = respData.result[0].sOIBuilUP30Min[j].Value
                      }
                    }
                  }
                }

                for (let j = 0; j < respData.result[0].sOIBuilUP60Min.length; j++) {
                  if (this.index == 1) {
                    this.obj60min.unshift(
                      {
                        time: clsCommonMethods.ConvertToDateObjAmPM(respData.result[0].sOIBuilUP60Min[j].Key),
                        expiryDate1: Expiry == 1 ? respData.result[0].sOIBuilUP60Min[j].Value : "-",
                        expiryDate2: Expiry == 2 ? respData.result[0].sOIBuilUP60Min[j].Value : "-",
                        expiryDate3: Expiry == 3 ? respData.result[0].sOIBuilUP60Min[j].Value : "-",
                      })
                  }
                  else {
                    if (this.obj60min.length > 0) {
                      if (Expiry == 1) {
                        this.obj60min[j].expiryDate1 = respData.result[0].sOIBuilUP60Min[j].Value
                      }
                      if (Expiry == 2) {
                        this.obj60min[j].expiryDate2 = respData.result[0].sOIBuilUP60Min[j].Value
                      }
                      if (Expiry == 3) {
                        this.obj60min[j].expiryDate3 = respData.result[0].sOIBuilUP60Min[j].Value
                      }
                    }
                  }
                }
              }
             
            }
            else
            {
              this.OIBuildupNoDataFound = false;
            }
            if (this.obj15min.length > 0) {
              this.oibuiltupDatamore = this.obj15min
              this.oibuiltupDataless = this.obj15min.slice(0, 4)
              this.oibuiltupData = this.oibuiltupDataless;
            }
          } catch (error) {
            this.OIBuildupNoDataFound = false;
            console.log("Error in OI BuildUP : " + error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindPutCallchart', error.Message, undefined, error.stack, undefined, undefined));
          }

        }, error => {
          console.log(error);
          this.OIBuildupNoDataFound = false;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getOIBuiltUpData1', err);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindPutCallchart', error.Message, undefined, error.stack, undefined, undefined));
          //this.loadingCtrl.hideLoader(); 
        });



    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getOIBuiltUpData2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindPutCallchart', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  oiBuildupSegmentChange(event) {
    try {

      this.showmoreOIbuildup = false;
      if (event.detail.value == "15min") {
        this.oibuiltupDatamore = this.obj15min
        this.oibuiltupDataless = this.obj15min.slice(0, 4)
        this.oibuiltupData = this.oibuiltupDataless;
      }
      else if (event.detail.value == "30min") {
        this.oibuiltupDatamore = this.obj30min
        this.oibuiltupDataless = this.obj30min.slice(0, 4)
        this.oibuiltupData = this.oibuiltupDataless;
      }
      else if (event.detail.value == "60min") {
        this.oibuiltupDatamore = this.obj60min
        this.oibuiltupDataless = this.obj60min.slice(0, 4)
        this.oibuiltupData = this.oibuiltupDataless;
      }

      this.modalOIBuiltup = event.detail.value;

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "trendAnlysisClick", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','trendAnlysisClick', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  oiBuildUpShowMoreLess(value) {
    console.log(value);
    this.showmoreOIbuildup = !this.showmoreOIbuildup
    if (value == 'More') {
      this.oibuiltupData = this.oibuiltupDatamore
    }
    if (value == 'Less') {
      this.oibuiltupData = this.oibuiltupDataless
    }

  }

  getVolumeVsDelivery() {
    try {
      this.vdChartTotalVolume = [];
      this.vdChartDelivery = [];

      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() /*this.getMktSegmentId() + "/" + this.gettoken()*/
      this.cdsService
        .getVolumeVsDeliveryData(reqString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (objresponse.ResponseObject.recordcount > 0) {
                this.vVSDNoDataFound = false;
                this.vdChartTotalVolume = [
                  parseFloat(objresponse.ResponseObject.resultset[0].vol).toFixed(2),
                  parseFloat(objresponse.ResponseObject.resultset[0].vol_prev).toFixed(2),
                  parseFloat(objresponse.ResponseObject.resultset[0].vol_5dayavg).toFixed(2),
                  parseFloat(objresponse.ResponseObject.resultset[0].vol_30dayavg).toFixed(2)]
                this.vdChartDelivery = [0,
                  parseFloat(objresponse.ResponseObject.resultset[0].del_prev).toFixed(2),
                  parseFloat(objresponse.ResponseObject.resultset[0].del_5dayavg).toFixed(2),
                  parseFloat(objresponse.ResponseObject.resultset[0].del_30dayavg).toFixed(2)]
                  this.bindVolumeVsDelChart();
              }
              else{
                this.vVSDNoDataFound = true;
              }
            } else {
              this.vVSDNoDataFound = true;
            }
          } catch (error) {
            this.vVSDNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getVolumeVsDelivery1", error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getVolumeVsDelivery1', error.Message, undefined, error.stack, undefined, undefined));
          } finally {
          }
        })
        .catch(error => {
          this.vVSDNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getVolumeVsDelivery2", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getVolumeVsDelivery2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.vVSDNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getVolumeVsDelivery3", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getVolumeVsDelivery3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  bindVolumeVsDelChart()
  {
    if (this.resultbarChart != undefined) {
      this.resultbarChart.destroy();
    }
    let themecolor = this.theme == 'dark' ? '#ffffff' : '#303030';
    this.resultbarChart = new Chart(this.barResultCanvas.nativeElement,
      {
        type: "horizontalBar",
        data: {
          labels: this.vdChartLable,
          datasets: [
            {
              label: "Total volume",
              backgroundColor: "#464983",
              data: this.vdChartTotalVolume
            },
            {
              label: "Delivery",
              backgroundColor: "#6fa9e2",
              data: this.vdChartDelivery
            }
          ]
        },
        options: {
          scales: {
            //gridLines:{offsetGridLine : "false"},
            yAxes: [
              {
                ticks: {
                  beginAtZero: true,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                },
                scaleLabel: {
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                },
                gridLines: {
                  display: false,
                  drawBorder: false
                }
              }
            ],
            xAxes: [
              {
                scaleLabel: {
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                },

                ticks: {
                  beginAtZero: true,
                  display: false,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                },
                gridLines: {
                  display: false,
                  drawBorder: false
                },
              }
            ]
          },
          legend: {
            display: false,
            position: "bottom"
          },
          tooltips: {
            enabled: false,
          },
          hover:
            { mode: null },
          animation: {
            duration: 500,
            easing: "easeOutQuart",
            onComplete: function (e) {
              var ctx = this.chart.ctx;
              ctx.font = '12px rubikmedium';
              ctx.textAlign = 'left';
              ctx.textBaseline = 'middle';

              this.data.datasets.forEach(function (dataset) {
                for (var i = 0; i < dataset.data.length; i++) {
                  var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                    scale_max = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._yScale.maxHeight;
                  ctx.fillStyle = themecolor
                  var y_pos = model.y - 5;
                  if ((scale_max - model.y) / scale_max >= 0.93)
                    y_pos = model.y + 20;
                  ctx.fillText(clsCommonMethods.kFormatter(dataset.data[i]), model.x + 1.5, y_pos + 8);
                }
              });
              this.options.animation.onComplete = null; //disable after first render

            }
          }
        }
      }
    );
  }

  getHealthTotalScore() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() /*this.getMktSegmentId() + "/" + this.gettoken()*/
      this.cdsService
        .getHealthTotalScore(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount > 0) {
                this.hTotalScrNoDataFound = false;
                this.companyTotalScore = resp.ResponseObject.resultset[0].TotalScore;
                this.companyHealthStatus = resp.ResponseObject.resultset[0].HealthStatus;
                if (this.companyTotalScore <= 25) {
                  this.companyHealthcss = 'color-health1';
                }
                else if (this.companyTotalScore <= 50) {
                  this.companyHealthcss = 'color-health2';
                }
                else if (this.companyTotalScore <= 75) {
                  this.companyHealthcss = 'color-health3';
                }
                else {
                  this.companyHealthcss = 'color-health14';
                }
              }
              else {
                this.hTotalScrNoDataFound = true;
              }
            } else {
              this.hTotalScrNoDataFound = true;
            }
          } catch (error) {
            this.hTotalScrNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getHealthTotalScore1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getHealthTotalScore1', error.Message, undefined, error.stack, undefined, undefined));
          }
        }).catch(error => {
          this.hTotalScrNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getHealthTotalScore3", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getHealthTotalScore2', error.Message, undefined, error.stack, undefined, undefined));
        })
    } catch (error) {
      this.hTotalScrNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getHealthTotalScore2", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getHealthTotalScore3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  trendAnlysisClick(event) {
    try {

      let labels
      if (event.detail.value == "newrevenue") {
        labels = ["New Revenue", "Gross Profit Margin %"]
        this.bindchart(this.arrQuarterlyTrendRevenue, labels)
      }
      else if (event.detail.value == "EBIT") {
        labels = ["EBIT", "EBIT Margin %"]
        this.bindchart(this.arrQuarterlyTrendEBIT, labels)
      }
      else if (event.detail.value == "EBITDA") {
        labels = ["EBITDA", "EBITDA Marginn %"]
        this.bindchart(this.arrQuarterlyTrendEBITDA, labels)
      }
      else if (event.detail.value == "Net Profit") {
        labels = ["Net Profit", "Net Profit Margin %"]
        this.bindchart(this.arrQuarterlyTrendNetprofit, labels)
      }
      this.modalTrendAnlytics = event.detail.value;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "trendAnlysisClick", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','trendAnlysisClick', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  consolidatedFinRatio: any = [];
  standaloneFinRatio: any = [];
  FinRationMode: string = "Standalone";
  getCompanyFinRatioStandalone() {
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/S"
    this.cdsService
      .getCompanyFinancialRatio(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              this.cmpRatioStdNoDataFound= false;
              this.standaloneFinRatio = objresponse.ResponseObject.resultset
            }
            else {
              this.cmpRatioStdNoDataFound= true;
            }
          } else {
            this.cmpRatioStdNoDataFound= true;
          }
        } catch (error) {
          this.cmpRatioStdNoDataFound= true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getCompanyFinRatio", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyFinRatio', error.Message, undefined, error.stack, undefined, undefined));
        } finally {

        }
      })
      .catch(error => {
        this.cmpRatioStdNoDataFound= true;
        this.buyBackNoDataFound = true;
        //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBuyBackData", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyFinRatio2', error.Message, undefined, error.stack, undefined, undefined));
      });
  }

  getCompanyFinRatioCosolidated() {
    let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/C"
    this.cdsService
      .getCompanyFinancialRatio(reqString)
      .then((objresponse: any) => {
        try {
          if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (objresponse.ResponseObject.recordcount > 0) {
              this.cmpRatioCosolidatedNoDataFound= false;
              this.consolidatedFinRatio = objresponse.ResponseObject.resultset
            }
            else {
              this.cmpRatioCosolidatedNoDataFound= true;
            }
          } else {
            this.cmpRatioCosolidatedNoDataFound= true;
          }
        } catch (error) {
          this.cmpRatioCosolidatedNoDataFound= true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getCompanyFinRatio", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyFinRatio', error.Message, undefined, error.stack, undefined, undefined));
          
        } finally {

        }
      })
      .catch(error => {
        this.cmpRatioCosolidatedNoDataFound= true;
        this.buyBackNoDataFound = true;
        //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getBuyBackData", error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyFinRatio2', error.Message, undefined, error.stack, undefined, undefined));
      });
  }


  async getQuarterlyTrend(trend) {
    try {
      this.arrQuarterlyTrendRevenue = [];
      this.arrQuarterlyTrendEBIT = [];
      this.arrQuarterlyTrendEBITDA = [];
      this.arrQuarterlyTrendNetprofit = [];
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + trend
      await this.cdsService
        .getQuarterlyTrend(reqString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (objresponse.ResponseObject.recordcount > 0) {
                this.QuarterlyTrendNoDataFound = false;
                if (trend == "QuarterlyTrend-Revenue") {
                  this.arrQuarterlyTrendRevenue.push(objresponse.ResponseObject.resultset)
                  let labels = ["New Revenue", "Gross Profit Margin %"]
                  this.bindchart(this.arrQuarterlyTrendRevenue, labels)
                }
                if (trend == "QuarterlyTrend-EBIT") {
                  this.arrQuarterlyTrendEBIT.push(objresponse.ResponseObject.resultset)
                }
                if (trend == "QuarterlyTrend-EBITDA") {
                  this.arrQuarterlyTrendEBITDA.push(objresponse.ResponseObject.resultset)
                }
                if (trend == "QuarterlyTrend-Netprofit") {
                  this.arrQuarterlyTrendNetprofit.push(objresponse.ResponseObject.resultset)
                }

              }else{
                this.QuarterlyTrendNoDataFound = true;
              }
            } else {
              this.QuarterlyTrendNoDataFound = true;
            }
          } catch (error) {
            this.QuarterlyTrendNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getQuarterlyTrend1", error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getQuarterlyTrend1', error.Message, undefined, error.stack, undefined, undefined));
          } finally {

          }
        })
        .catch(error => {
          this.QuarterlyTrendNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getQuarterlyTrend2", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getQuarterlyTrend2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.QuarterlyTrendNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getQuarterlyTrend3", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getQuarterlyTrend3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  bindchart(data, labels) {
    try {
      let labelsdata = [];
      let profitMargin = [];
      let revenu = [];
      for (let j = 0; j < data[0].length; j++) {
        labelsdata.push([clsCommonMethods.getMonthFormat(data[0][j].yrc.slice(4, 6)), data[0][j].yrc.slice(0, 4)])
        //labelsdata.push(['JAN','2020'])
        profitMargin.push(parseFloat(data[0][j].profitmargin).toFixed(2))
        revenu.push(parseFloat(data[0][j].revenu).toFixed(2))
      }
      if (this.trendAnlysisChart != undefined) {
        this.trendAnlysisChart.destroy();
      }
      this.trendAnlysisChart = new Chart(
        this.mixChartDetailCanvas.nativeElement,
        {
          type: 'bar',
          data: {
            labels: labelsdata,
            datasets: [{
              label: labels[1],
              type: "line",
              borderColor: "#464983",
              data: profitMargin,
              fill: false,
              yAxisID: 'A',
              borderWidth: 2,
              pointRadius: 0
            }, {
              label: labels[0],
              type: "bar",
              backgroundColor: "#6fa9e2",
              backgroundColorHover: "#3e95cd",
              data: revenu,
              yAxisID: 'B',
            }
            ]
          },
          options: {
            scales: {
              yAxes: [{
                id: 'B',
                type: 'linear',
                position: 'left',
                gridLines: {
                  display: false,
                  drawBorder: false
                },
                ticks: {
                  reverse: false,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                  maxTicksLimit: 4
                },
              }, {
                id: 'A',
                type: 'linear',
                position: 'right',
                gridLines: {
                  display: false,
                  drawBorder: false
                },
                ticks: {
                  reverse: false,
                  fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  defaultFontSize: 10,
                  defaultFontFamily: 'rubikmedium',
                  maxTicksLimit: 4,
                  callback: function (value, index, values) {
                    return value + '%';
                  }
                },
              }],
              xAxes: [
                {
                  gridLines: {
                    display: false,
                    drawBorder: false
                  },
                  ticks: {
                    maxRotation: 0,
                    minRotation: 0,
                    fontSize: 12,
                    padding: 0,
                    fontColor: this.theme == 'dark' ? '#ffffff' : '#303030',
                  }
                },

              ],
            },
            tooltips: {
              enabled: false,
            },
            legend: { display: false }
          }
        }
      );
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "bindchart", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindchart', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  fetchShareHoldingPattern() {
    try {
      //this.showShareHoldingLoader = true;
      this.ShareHoldingPatternList = [];
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getCompanyShareHoldingPattern(reqString)
        .then((data: any) => {
          try {
            if (
              data.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS &&
              data.ResponseObject.resultset.length > 0
            ) {
              this.ShreholdingPattrnNoDataFound = false;
              let dataHolding = data.ResponseObject.resultset[0];
              this.ShareHoldingPatternList.push({
                FIIHolding: clsTradingMethods.formatPrice(
                  dataHolding.FIIHolding,
                  this.priceFormat
                ),
                MutualFundHolding: clsTradingMethods.formatPrice(
                  dataHolding.MutualFundHolding,
                  this.priceFormat
                ),
                Others: clsTradingMethods.formatPrice(
                  dataHolding.Others,
                  this.priceFormat
                ),
                PromoterHolding: clsTradingMethods.formatPrice(
                  dataHolding.PromoterHolding,
                  this.priceFormat
                )

              })
              this.bindShareholdingChart()
              

            } else {
              this.ShreholdingPattrnNoDataFound = true;
            }
          } catch (error) {
            this.ShreholdingPattrnNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchShareHoldingPattern1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindchart', error.Message, undefined, error.stack, undefined, undefined));
          }
          finally {
          }
        })
        .catch(error => {
          this.ShreholdingPattrnNoDataFound = true;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchShareHoldingPattern2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindchart2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.ShreholdingPattrnNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "fetchShareHoldingPattern3", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','bindchart3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  bindShareholdingChart()
  {
    this.shareHoldingPatternChart = new Chart(
      this.shareHoldingPatternCanvas.nativeElement,
      {
        type: "doughnut",
        data: {
          labels: ["FII", "MUTUAL FUND", "PROMOTER", "OTHERS"],
          datasets: [
            {
              label: "# of Votes",
              data: [this.ShareHoldingPatternList[0].FIIHolding,
              this.ShareHoldingPatternList[0].MutualFundHolding,
              this.ShareHoldingPatternList[0].PromoterHolding,
              this.ShareHoldingPatternList[0].Others
              ],
              backgroundColor: ["#464983", "#5f88c3", "#81cbff", "#6fa9e2"],
              borderWidth: 0
            }
          ]
        },
        options: {
          tooltips: {
            enabled: false
          },
          legend: {
            display: false,
            position: "right",
          },

          // animation: {
          //   duration: 1,

          //   onComplete: function () {
          //     let chartInstance = this.chart,
          //       ctx = chartInstance.ctx;

          //     ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
          //     ctx.textAlign = 'center';
          //     ctx.textBaseline = 'bottom';

          //     this.data.datasets.forEach(function (dataset, i) {
          //       let meta = chartInstance.controller.getDatasetMeta(i);
          //       meta.data.forEach(function (bar, index) {
          //         if (dataset.data[index] > 0) {
          //           let data = dataset.data[index];
          //           ctx.fillText(data, bar._model.x, bar._model.y);
          //         }
          //       });
          //     });
          //   }
          // }

        }
      }
    );
  }

  showDetailsData() {
    if (this.viewExpand) {
      this.viewExpand = false;
      this.companyInfo = this.companyInfoCollapse;
    } else {
      this.viewExpand = true;
      this.companyInfo = this.companyInfoExpand;
    }
  }


  onPnLOperationChange(event) {
    if (event != this.CMOTPnLTypeButton) {
      this.CMOTPnLTypeButton = event;
      // this.viewPLChart = false;
      // this.profitlosshide = false;
      // this.standconsolerror = false;
      this.fetchCompanyProfitLoss();
    }
  }
  annualReportOpChange(event) {
    if (this.segmentSelected == 'Profit & Loss') {
      this.onPnLOperationChange(event.detail.value)
    }
    else if (this.segmentSelected == 'Balance Sheet') {
      this.onBalanceSheetTypeOperationChange(event.detail.value)
    }
    else if (this.segmentSelected == 'Results') {
      this.onResultTypeOperationChange(event.detail.value)
    }
    this.annualReportType = event.detail.value;
    this.clickChooseAnnual();


  }


  checkPLFlagData() {
    if (this.CMOTPnLTypeButton.toUpperCase() == "STANDALONE") {
      this.ProfitLossResp = this.StandAloneDETAILS.list.length > 0 ? this.StandAloneDETAILS.list : [];
      this.ProfitLossdatearr = this.StandAloneDETAILS.date.length > 0 ? this.StandAloneDETAILS.date : [];

    } else if (this.CMOTPnLTypeButton.toUpperCase() == "CONSOLIDATED") {
      this.ProfitLossResp = this.ConsolidatedDETAILS.list.length > 0 ? this.ConsolidatedDETAILS.list : [];
      this.ProfitLossdatearr = this.ConsolidatedDETAILS.date.length > 0 ? this.ConsolidatedDETAILS.date : [];
    }
    return this.ProfitLossResp.length > 0 ? true : false;
  }

  fetchCompanyProfitLoss() {
    try {

      if (this.checkPLFlagData()) {
        // this.showPLLoader = false;
        return;
      }
      let _sType;
      if (this.CMOTPnLTypeButton == "STANDALONE") {
        _sType = "S";
      } else if (this.CMOTPnLTypeButton == "CONSOLIDATED") {
        _sType = "C";
      }

      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + _sType
      this.cdsService
        .getCompanyProfitLoss(reqString)
        .then((response: any) => {
          if (response.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
            if (response.ResponseObject.recordcount > 0) {
              this.showProfitLoss = true
              this.anualReportNoDataFound = false;
              // this.profitlosshide = false;
              this.arrChartDate = [];
              this.arrTotalIncome = [];
              this.arrTotalExpenditure = [];
              this.ProfitLossResp = [];
              let profitLossDataResp = response.ResponseObject.resultset;
              this.ProfitLossdatearr = [];
              let strYear = profitLossDataResp[0].CurrentFinYr.substr(0, 4);
              let strMonth = clsCommonMethods.getMonthFormat(
                profitLossDataResp[0].CurrentFinYr.substr(4, 2)
              );
              this.ProfitLossdatearr.push({
                DateId: profitLossDataResp[0].CurrentFinYr,
                Date: strMonth + " " + strYear
              });
              strYear = profitLossDataResp[0].YOY_1.substr(0, 4);
              strMonth = clsCommonMethods.getMonthFormat(
                profitLossDataResp[0].YOY_1.substr(4, 2)
              );
              this.ProfitLossdatearr.push({
                DateId: profitLossDataResp[0].YOY_1,
                Date: strMonth + " " + strYear
              });

              let rowData: any = {};
              for (let index = 1; index < profitLossDataResp.length; index++) {
                const element = profitLossDataResp[index];
                rowData = {};
                rowData.ColumnName = element.ColumnName;
                rowData.year1 = element.CurrentFinYr.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                rowData.year2 =  element.YOY_1.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                rowData.year3 = element.YOY_2.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                this.ProfitLossResp.push(rowData);
              }

              if (_sType == "S") {
                this.StandAloneDETAILS = {
                  list: this.ProfitLossResp,
                  date: this.ProfitLossdatearr,
                  dataincome: this.arrTotalIncome,
                  dataexpenditure: this.arrTotalExpenditure,
                  labels: this.arrChartDate
                };
              } else {
                this.ConsolidatedDETAILS = {
                  list: this.ProfitLossResp,
                  date: this.ProfitLossdatearr,
                  dataincome: this.arrTotalIncome,
                  dataexpenditure: this.arrTotalExpenditure,
                  labels: this.arrChartDate
                };
              }
            } else {
              //this.standconsolerror = true;
              //this.showPLLoader = false;
              this.anualReportNoDataFound = true;
            }
          } else {
            //this.profitlosshide = true;
            //this.showPLLoader = false;
            this.anualReportNoDataFound = true;
          }
        })
        .catch(error => {
          this.anualReportNoDataFound = true;
          //this.showError("Unable to fetch data.");
          //this.profitlosshide = true;
          //this.showPLLoader = false;
          //clsGlobal.logManager.writeErrorLog('QuotePage', 'fetchCompanyProfitLoss', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyProfitLoss', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.anualReportNoDataFound = true;
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyProfitLoss2', error.Message, undefined, error.stack, undefined, undefined));
      //this.showError(e);
    }
  }

  onBalanceSheetTypeOperationChange(event) {
    if (event != this.balanceSheetType) {
      this.balanceSheetType = event;
      this.CompanyBalanceSheet = [];
      this.BalanceSheetdatearr = [];
      this.fetchBalanceSheet();
    }
  }

  checkBalanceSheetFlagData() {
    if (this.balanceSheetType.toUpperCase() == "STANDALONE") {
      this.CompanyBalanceSheet = this.balanceSheetStandAloneDETAILS.list.length > 0 ? this.balanceSheetStandAloneDETAILS.list : [];
      this.BalanceSheetdatearr = this.balanceSheetStandAloneDETAILS.date.length > 0 ? this.balanceSheetStandAloneDETAILS.date : [];

    } else if (this.balanceSheetType.toUpperCase() == "CONSOLIDATED") {
      this.CompanyBalanceSheet = this.balanceSheetConsolidatedDETAILS.list.length > 0 ? this.balanceSheetConsolidatedDETAILS.list : [];
      this.BalanceSheetdatearr = this.balanceSheetConsolidatedDETAILS.date.length > 0 ? this.balanceSheetConsolidatedDETAILS.date : [];
    }
    return this.CompanyBalanceSheet.length > 0 ? true : false;
  }

  fetchBalanceSheet() {
    try {
      // this.showBalanceSheetLoader = true;
      if (this.checkBalanceSheetFlagData()) {
        // this.showBalanceSheetLoader = false;
        return;
      }

      let _sType;
      if (this.balanceSheetType == "STANDALONE") {
        _sType = "S";
      } else if (this.balanceSheetType == "CONSOLIDATED") {
        _sType = "C";
      }

      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + _sType;
      this.cdsService
        .getCompanyBalanceSheet(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount > 0) {
                // this.balancesheethide = false;
                this.anualReportNoDataFound = false;
                this.showBalanceSheet = true;
                let BalanceSheetDataResp = resp.ResponseObject.resultset;
                this.BalanceSheetdatearr = [];

                let strYear = BalanceSheetDataResp[0].CurrentYear.substr(0, 4);
                let strMonth = clsCommonMethods.getMonthFormat(
                  BalanceSheetDataResp[0].CurrentYear.substr(4, 2)
                );
                this.BalanceSheetdatearr.push({
                  DateId: BalanceSheetDataResp[0].CurrentYear,
                  Date: strMonth + " " + strYear
                });

                strYear = BalanceSheetDataResp[0].Year1.substr(0, 4);
                strMonth = clsCommonMethods.getMonthFormat(
                  BalanceSheetDataResp[0].Year1.substr(4, 2)
                );
                this.BalanceSheetdatearr.push({
                  DateId: BalanceSheetDataResp[0].Year1,
                  Date: strMonth + " " + strYear
                });

                strYear = BalanceSheetDataResp[0].Year2.substr(0, 4);
                strMonth = clsCommonMethods.getMonthFormat(
                  BalanceSheetDataResp[0].Year2.substr(4, 2)
                );
                this.BalanceSheetdatearr.push({
                  DateId: BalanceSheetDataResp[0].Year2,
                  Date: strMonth + " " + strYear
                });


                let rowData: any = {};
                for (let index = 1; index < BalanceSheetDataResp.length; index++) {
                  if (BalanceSheetDataResp[index].ColumnName == 'Total Debt / Loan Funds')
                    this.TotalDebt = BalanceSheetDataResp[index].CurrentYear;
                  // if (BalanceSheetDataResp[index].ColumnName == 'Total Liabilities')
                  //   this.TotalLiabilities = BalanceSheetDataResp[index].CurrentYear;
                  // if (BalanceSheetDataResp[index].ColumnName == 'Total Current Assets')
                  //   this.TotalAssests = BalanceSheetDataResp[index].CurrentYear;
                  // if (BalanceSheetDataResp[index].ColumnName == 'Net Deferred Tax')
                  //   this.NetDefferedTax = BalanceSheetDataResp[index].CurrentYear;

                  const element = BalanceSheetDataResp[index];
                  rowData = {};
                  rowData.ColumnName = element.ColumnName;
                  rowData.year1 = element.CurrentYear.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  rowData.year2 = element.Year1.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  rowData.year3 = element.Year2.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  this.CompanyBalanceSheet.push(rowData);
                }
                if (this.balanceSheetType.toUpperCase() == "STANDALONE") {
                  this.balanceSheetStandAloneDETAILS = {
                    list: this.CompanyBalanceSheet,
                    date: this.BalanceSheetdatearr,
                    totaldebt: this.TotalDebt,
                  };
                } else {
                  this.balanceSheetConsolidatedDETAILS = {
                    list: this.CompanyBalanceSheet,
                    date: this.BalanceSheetdatearr,
                    totaldebt: this.TotalDebt,
                  };
                }
                // this.showBalanceSheetLoader = false;
              }
              else {
                this.anualReportNoDataFound = true;
                // this.balancestandconsolierror = true;
                // this.showBalanceSheetLoader = false;
              }
            } else {
              this.anualReportNoDataFound = true;
              // this.balancesheethide = true;
              // this.showBalanceSheetLoader = false;
            }
          } catch (error) {
            this.anualReportNoDataFound = true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBalanceSheet1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBalanceSheet1', error.Message, undefined, error.stack, undefined, undefined));
            // this.balancesheethide = true;
            // this.showBalanceSheetLoader = false;
          }
        })
        .catch(error => {
          this.anualReportNoDataFound = true;
          // this.balancesheethide = true;
          // this.showBalanceSheetLoader = false;
          clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBalanceSheet2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBalanceSheet2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.anualReportNoDataFound = true;
     // clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBalanceSheet3', e);

      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBalanceSheet3', error.Message, undefined, error.stack, undefined, undefined));
    }
  }



  onResultTypeOperationChange(event) {
    if (event != this.resultType) {
      this.resultType = event;
      // this.showResultLoader = false;
      // this.viewResultExpand = false;
      // this.resultstandconsolierror = false;
      // this.resulthide = false;
      this.CompanyResult = [];
      this.Resultdatearr = [];
      this.fetchCompanyResult();
    }
  }

  checkResultFlagData() {
    if (this.resultType.toUpperCase() == "STANDALONE" && this.resultPeriod.toUpperCase() == "QUARTERLY") {
      this.CompanyResult = this.resultStandAloneQuarterDETAILS.list.length > 0 ? this.resultStandAloneQuarterDETAILS.list : [];
      this.Resultdatearr = this.resultStandAloneQuarterDETAILS.date.length > 0 ? this.resultStandAloneQuarterDETAILS.date : [];
    } else if (this.resultType.toUpperCase() == "CONSOLIDATED" && this.resultPeriod.toUpperCase() == "QUARTERLY") {
      this.CompanyResult = this.resultConsolidatedQuarterDETAILS.list.length > 0 ? this.resultConsolidatedQuarterDETAILS.list : [];
      this.Resultdatearr = this.resultConsolidatedQuarterDETAILS.date.length > 0 ? this.resultConsolidatedQuarterDETAILS.date : [];
    }
    return this.CompanyResult.length > 0 ? true : false;
  }

  fetchCompanyResult() {
    try {
      // this.showResultLoader = true;
      if (this.checkResultFlagData()) {
        // this.showResultLoader = false;
        return;
      }

      let _sType;
      if (this.resultType == "STANDALONE") {
        _sType = "S";
      } else if (this.resultType == "CONSOLIDATED") {
        _sType = "C";
      }
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken() + "/" + _sType + "/" + this.resultPeriod
      this.cdsService
        .getCompanyResult(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount == 0) {
                // this.resulthide = false;
                this.anualReportNoDataFound = false;
                let ResultDataResp = resp.ResponseObject.resultset;
                this.Resultdatearr = [];
                this.arrResultChartDate = [];
                this.arrResultTotalIncome = [];
                this.arrResultTotalExpenditure = [];

                let strYear = ResultDataResp[0].CurrentYear.substr(0, 4);
                let strMonth = clsCommonMethods.getMonthFormat(
                  ResultDataResp[0].CurrentYear.substr(4, 2)
                );
                this.Resultdatearr.push({
                  DateId: ResultDataResp[0].CurrentYear,
                  Date: strMonth + " " + strYear
                });
                this.arrResultChartDate.push(strMonth + " " + strYear);

                strYear = ResultDataResp[0].Year1.substr(0, 4);
                strMonth = clsCommonMethods.getMonthFormat(
                  ResultDataResp[0].Year1.substr(4, 2)
                );
                this.Resultdatearr.push({
                  DateId: ResultDataResp[0].Year1,
                  Date: strMonth + " " + strYear
                });
                this.arrResultChartDate.push(strMonth + " " + strYear);

                strYear = ResultDataResp[0].Year2.substr(0, 4);
                strMonth = clsCommonMethods.getMonthFormat(
                  ResultDataResp[0].Year2.substr(4, 2)
                );
                this.Resultdatearr.push({
                  DateId: ResultDataResp[0].Year2,
                  Date: strMonth + " " + strYear
                });
                this.arrResultChartDate.push(strMonth + " " + strYear);
                let rowData: any = {};
                for (let index = 1; index < ResultDataResp.length; index++) {
                  const element = ResultDataResp[index];
                  rowData = {};
                  rowData.ColumnName = element.ColumnName;
                  rowData.year1 = element.CurrentYear.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  rowData.year2 = element.Year1.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  rowData.year3 = element.Year2.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                  this.CompanyResult.push(rowData);
                }
                if (this.resultType.toUpperCase() == "STANDALONE" && this.resultPeriod.toUpperCase() == "QUARTERLY") {
                  this.resultStandAloneQuarterDETAILS = {
                    list: this.CompanyResult,
                    date: this.Resultdatearr,
                    totalresultincome: this.arrResultTotalIncome,
                    totalresultexpenditure: this.arrResultTotalExpenditure,
                    labels: this.arrResultChartDate
                  };
                }
                else if (this.resultType.toUpperCase() == "CONSOLIDATED" && this.resultPeriod.toUpperCase() == "QUARTERLY") {
                  this.resultConsolidatedQuarterDETAILS = {
                    list: this.CompanyResult,
                    date: this.Resultdatearr,
                    totalresultincome: this.arrResultTotalIncome,
                    totalresultexpenditure: this.arrResultTotalExpenditure,
                    labels: this.arrResultChartDate
                  };
                }
                // this.getResultChartData();
                // this.showResultLoader = false;
              }
              else {
                this.anualReportNoDataFound = true;
                // this.showResultLoader = false;
                // this.resultstandconsolierror = true;
              }
            } else {
              this.anualReportNoDataFound = true;
              
              // this.showResultLoader = false;
              // this.resulthide = true;
            }
          } catch (error) {
            this.anualReportNoDataFound = true;
            // this.showResultLoader = false;
            // this.resulthide = true;
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyResult1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyResult1', error.Message, undefined, error.stack, undefined, undefined));
          }
        })
        .catch(error => {
          this.anualReportNoDataFound = true;
          // this.showResultLoader = false;
          // this.resulthide = true;
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyResult2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyResult2', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      this.anualReportNoDataFound = true;
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyResult3', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyResult1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }


  annualReportTabChange(event) {
    this.annualReportType = "STANDALONE";
    if (event.detail.value == 'Profit & Loss') {
      this.showProfitLoss = true;
      this.showBalanceSheet = false;
      this.showCompanyResults = false;
      this.showmore = false;
      if (this.ProfitLossResp.length == 0) {
        this.fetchCompanyProfitLoss();
      }
    } else if (event.detail.value == 'Balance Sheet') {
      this.showProfitLoss = false;
      this.showCompanyResults = false;
      this.showBalanceSheet = true;
      this.showmore = false;
      if (this.CompanyBalanceSheet.length == 0) {
        this.fetchBalanceSheet();
      }
    } else if (event.detail.value == 'Results') {
      this.showCompanyResults = true;
      this.showBalanceSheet = false;
      this.showProfitLoss = false;
      this.showmore = false;
      if (this.CompanyResult.length == 0) {
        this.fetchCompanyResult();
      }
    }
    this.segmentSelected = event.detail.value
  }

  /****************************** Analytics TAB Code END *******************/

  /****************************** Futures TAB Code START *******************/
  getFutData() {
    try {
      let instrumentName = "FUTSTK"
      let symbol = this.selectedScrip.symbol
      if (this.futData.length == 0) {
        this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/" + instrumentName + "/" + null + "/" + symbol).subscribe(response => {
          //TODO
          let _response: any = response;
          if (_response.status) {
            if (_response.result.hits != undefined) {
              if (_response.result.hits.hits.length > 0) {
                this.noDataFoundFUT = false;
                for (let i = 0; i < _response.result.hits.hits.length; i++) {
                  if(_response.result.hits.hits[i]._source.nSpread == 0)
                  {
                    _response.result.hits.hits[i].LTP = "0.00";
                    _response.result.hits.hits[i].NetChangeInRs = "0.00";
                    _response.result.hits.hits[i].PercNetChange = "0.00";
                    _response.result.hits.hits[i].PremiumDiscount = "0.00"
                    this.futData.push(_response.result.hits.hits[i])
                    let objScrpKey: clsScripKey = new clsScripKey();
                    objScrpKey.token = _response.result.hits.hits[i]._source.nToken;
                    objScrpKey.MktSegId = _response.result.hits.hits[i]._source.nMarketSegmentId;
                    this.lstScripKey.push(objScrpKey);
                  }
                }
                this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
              }
              else {
                this.noDataFoundFUT = true;
              }
            }
            else {
              this.noDataFoundFUT = true;
            }
          }
          else {
            this.noDataFoundFUT = true;
          }

          //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
        }, error => {
          console.log(error.error.message);
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getFutData1', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getFutData1', error.Message, undefined, error.stack, undefined, undefined));
          this.noDataFoundFUT = true;
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getFutData2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getFutData1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  /****************************** Futures TAB Code END *******************/

  /****************************** Option Chain TAB Code START *******************/
  /**
   * Non-trasnsactional call to get data from elastic search
   */
  getOptData() {
    try {
      let instrumentName = "OPTSTK"
      let symbol = this.selectedScrip.symbol;
      this.showOptLoadersearch = true;
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/" + instrumentName + "/" + null + "/" + symbol).subscribe(response => {
        let _response: any = response;
        if (_response.status) {
          if (_response.result.hits != undefined) {
            if (_response.result.hits.hits.length > 0) {
              this.noDataFoundOPT = false
              this.selectedOptionContractData = _response.result.hits.hits;
              this.distinctOptExpiryDate = this.getDistinctExpiryDate(this.selectedOptionContractData);
              this.ShowOptionChain(this.distinctOptExpiryDate[0], 0)
            }
            else {
              this.showOptLoadersearch = false;
              this.noDataFoundOPT = true
            }
          }
          else {
            this.showOptLoadersearch = false;
            this.noDataFoundOPT = true
          }
        }
        else {
          this.showOptLoadersearch = false;
          this.noDataFoundOPT = true
        }

        //this.selectedOptionContract = this.selectedOptionContract.slice(0,2)
      }, error => {
        this.showOptLoadersearch = false;
        this.noDataFoundOPT = true
        console.log(error.error.message);
        //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getOptData1', error);
        clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getOptData1', error.Message, undefined, error.stack, undefined, undefined));
      });
    } catch (error) {
      this.showOptLoadersearch = false;
      this.noDataFoundOPT = true
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getOptData2', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getOptData1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  ShowOptionChain(expiryDate, idx) {
    try {
      this.showOptLoadersearch = true;
      this.selectedIdxOptnChain = idx;
      this.selectedOptionContract = [];
      let optData = this.selectedOptionContractData.filter(x => x._source.nExpiryDate1 == expiryDate)
      optData.push({ _source: { nStrikePrice1: this.scripLTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "CE", class: "call-put-add-money" }, Money: "call-add-money", chaintype: "LTP" })
      optData.push({ _source: { nStrikePrice1: this.scripLTP, nMarketSegmentId: 0, nToken: 0, sOptionType: "PE", class: "call-put-add-money" }, Money: "put-add-money", chaintype: "LTP" })
      optData.sort((a, b) => (parseFloat(a._source.nStrikePrice1) < parseFloat(b._source.nStrikePrice1)) ? -1 : 1)
      let optCEData = optData.filter(x => x._source.sOptionType == "CE")
      let optPEData = optData.filter(x => x._source.sOptionType == "PE")
      for (let i = 0; i < optCEData.length; i++) {
        let obj;
        optCEData[i].LTP = "0.00";
        optCEData[i].NetChangeInRs = "0.00";
        optCEData[i].PercNetChange = "0.00";
        optCEData[i].OI = "0.00";
        optCEData[i].PercOI = "0.00";
        optCEData[i].IV = "0";

        optPEData[i].LTP = "0.00";
        optPEData[i].NetChangeInRs = "0.00";
        optPEData[i].PercNetChange = "0.00";
        optPEData[i].OI = "0.00";
        optPEData[i].PercOI = "0.00";
        optPEData[i].IV = "0";

        let ceData = optCEData[i]
        let peData = optPEData[i]
        obj = { "ceData": ceData, "peData": peData }
        this.selectedOptionContract.push(obj)
      }
      this.sendBroadcastReqForOptionChain(this.selectedOptionContract)
      this.showOptLoadersearch = false;
      this.scrollToLabel();

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'ShowOptionChain1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','ShowOptionChain1', error.Message, undefined, error.stack, undefined, undefined));
    }


  }

  getDistinctExpiryDate(array) {
    try {
      let distinct = [...new Set(array.map(item => item._source.nExpiryDate1))];
      return distinct;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getDistinctExpiryDate1', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getDistinctExpiryDate1', error.Message, undefined, error.stack, undefined, undefined));
    }

  }

  sendBroadcastReqForOptionChain(selectedData) {
    try {
      this.lstScripKey = [];
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);
      for (let i = 0; i < selectedData.length; i++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = selectedData[i].ceData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].ceData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
        objScrpKey = new clsScripKey();
        objScrpKey.token = selectedData[i].peData._source.nToken;
        objScrpKey.MktSegId = selectedData[i].peData._source.nMarketSegmentId;
        this.lstScripKey.push(objScrpKey);
      }
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'sendBroadcastReqForOptionChain', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','sendBroadcastReqForOptionChain', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  /****************************** Option Chain TAB Code END *******************/


  /****************************** Company Information TAB Code START *******************/
  /**
   * To get the Board of Directore data from CDS
   */
  fetchBoardDirector() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getBoardofDirectors(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount > 0) {
                this.BoardDirector = resp.ResponseObject.resultset;
              }
              else {
                //this.noboardofdirectorfound = true;
              }
            } else {
              //this.noboardofdirectorfound = true;
            }
          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBoardDirector1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBoardDirector1', error.Message, undefined, error.stack, undefined, undefined));
          }
        })
        .catch(error => {
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBoardDirector2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBoardDirector1', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchBoardDirector3', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchBoardDirector1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  /**
  * To get the company Background data from CDS
  */
  fetchCompanyBackground() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getCompanyBackground(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse;
            if (resp.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (resp.ResponseObject.recordcount > 0) {
                let regAddr = '';
                let hoAddr = '';
                let RegistarAddr
                regAddr = resp.ResponseObject.resultset[0].Reg_address_l + ",";
                regAddr = regAddr + resp.ResponseObject.resultset[0].Reg_address_2 + ",";
                regAddr = regAddr + resp.ResponseObject.resultset[0].Reg_City + ",";
                regAddr = regAddr + resp.ResponseObject.resultset[0].Reg_Pin;
                this.RegisterAddress = regAddr;
                this.RegisterTel = resp.ResponseObject.resultset[0].Registr_tell;
                this.RegisterFax = resp.ResponseObject.resultset[0].Registr_Fax;
                this.RegisterEmail = resp.ResponseObject.resultset[0].Registr_Email;
                this.RegisterWeb = resp.ResponseObject.resultset[0].Registr_WebSite;

                hoAddr = resp.ResponseObject.resultset[0].HO_address_1 + ",";
                hoAddr = hoAddr + resp.ResponseObject.resultset[0].HO_address_2 + ",";
                hoAddr = hoAddr + resp.ResponseObject.resultset[0].HO_address_3 + ",";
                hoAddr = hoAddr + resp.ResponseObject.resultset[0].HO_city + ",";
                hoAddr = hoAddr + resp.ResponseObject.resultset[0].HO_pin + ",";
                hoAddr = hoAddr + (resp.ResponseObject.resultset[0].HO_tell != '-' ? "Tel: " + resp.ResponseObject.resultset[0].HO_tell : '-');
                this.HOAddress = (hoAddr != '-,-,-,-,-,-') ? hoAddr : '-';
                this.HOATel = resp.ResponseObject.resultset[0].HO_tell;
                this.HOFax = resp.ResponseObject.resultset[0].HO_Fax;
                this.HOEmail = resp.ResponseObject.resultset[0].HO_Email;
                this.HOWeb = resp.ResponseObject.resultset[0].HO_Website;

                RegistarAddr = resp.ResponseObject.resultset[0].Registr_address_1 + ",";
                RegistarAddr = RegistarAddr + resp.ResponseObject.resultset[0].Registr_address_2 + ",";
                RegistarAddr = RegistarAddr + resp.ResponseObject.resultset[0].Registr_address_3 + ",";
                RegistarAddr = RegistarAddr + resp.ResponseObject.resultset[0].Registr_address_4 + ",";
                this.RegistrarAdd = RegistarAddr;
                this.RegistrarTel = resp.ResponseObject.resultset[0].Registr_tell;
                this.RegistrarFax = resp.ResponseObject.resultset[0].Registr_Fax;
                this.RegistrarEmail = resp.ResponseObject.resultset[0].Registr_Email;
                this.RegistrarWeb = resp.ResponseObject.resultset[0].Registr_WebSite;
                this.RegistrarName = resp.ResponseObject.resultset[0].RegistrarName;
                this.RegistrarAuditor = resp.ResponseObject.resultset[0].Auditor;

              }
            } else {

            }
          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyBackground1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyBackground1', error.Message, undefined, error.stack, undefined, undefined));
          }
        })
        .catch(error => {
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyBackground2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyBackground1', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'fetchCompanyBackground3', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','fetchCompanyBackground1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  /**
     * To get the company History data from CDS
     */
  getCompanyHistory() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getComapnyHistory(reqString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type.toUpperCase() == clsConstants.CDS_SUCCESS) {
              if (objresponse.ResponseObject.recordcount > 0) {
                this.companyInfoExpand = objresponse.ResponseObject.resultset[0].memo;
                this.companyInfoCollapse = this.companyInfoExpand.substr(0, 120);
                this.companyInfo = this.companyInfoCollapse;
              }
            } else {

            }
          } catch (error) {
            //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getCompanyHistory1", error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyHistory1', error.Message, undefined, error.stack, undefined, undefined));
          } finally {

          }
        })
        .catch(error => {
          //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getCompanyHistory2", error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyHistory1', error.Message, undefined, error.stack, undefined, undefined));
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog("ScripinfoPage", "getCompanyHistory3", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getCompanyHistory1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  /**
   * To get the company listing data from CDS
   */
  getcompanyListingData() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getCompanyListingInfo(reqString)
        .then((objresponse: any) => {
          try {
            let resp = objresponse.ResponseObject;
            this.companyListingData = resp.resultset.ListingInformationlist2.ListingInformation2;
            this.companyPartOfIndices = resp.resultset.ListingInformationlist.ListingInformation;

          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyListingData1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyListingData1', error.Message, undefined, error.stack, undefined, undefined));
          }
        }).catch(error => {
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyListingData2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyListingData1', error.Message, undefined, error.stack, undefined, undefined));
        })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyListingData3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyListingData1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  getcompanyExchangeData() {
    try {
      let reqString = "/" + this.getAssetMktSegmentId() + "/" + this.getAssetToken()
      this.cdsService
        .getCompanyExchange(reqString)
        .then((objresponse: any) => {
          try {
            if (objresponse.ResponseObject.type == "success") {
              for (let i = 0; i < objresponse.ResponseObject.resultset.length; i++) {
                this.companyExchangeData += objresponse.ResponseObject.resultset[i].Sector_Names + ","
              }
              this.companyExchangeData = this.companyExchangeData.slice(0, this.companyExchangeData.length - 1)
            }

          } catch (error) {
            //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyExchangeData1', error);
            clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyExchangeData1', error.Message, undefined, error.stack, undefined, undefined));
          }
        }).catch(error => {
          //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyExchangeData2', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyExchangeData1', error.Message, undefined, error.stack, undefined, undefined));
        })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('ScripinfoPage', 'getcompanyExchangeData3', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','getcompanyExchangeData1', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  contactSegChange(event) {
    this.contactInfoInner = event.detail.value;
  }

  /****************************** Company Information TAB Code END *******************/

  optionchainTop: boolean = false
  optionchainbottom: boolean
  scrollContent(event) {
    let titleELe = document.getElementById("call-put-add-money");
    // console.log("titleELe"+titleELe.offsetTop);
    // console.log("scrollTop"+event.detail.scrollTop);
    this.optionchainTop = false;
    this.optionchainbottom = false;

    if (event.detail.scrollTop > 80) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    if (titleELe != undefined) {
      if (event.detail.scrollTop > titleELe.offsetTop + 200) {
        this.optionchainTop = true;
      }

      if (event.detail.scrollTop < titleELe.offsetTop - 200) {
        this.optionchainbottom = true;
      }

      if (event.detail.scrollTop == titleELe.offsetTop) {
        this.optionchainTop = false;
        this.optionchainbottom = false;
      }
    }

  }

  showMenu() {
    this.showMenuIcon = !this.showMenuIcon;
  }
  exchangeClose() {
    this.showMenuIcon = false;
  }

  optionGreekes: any
  showpopupD(data) {
    if (data != undefined) {
      this.optionGreekes = data;
      let callPut = data._source.sOptionType == "CE" ? 0 : 1
      this.showcalculate(this.scripLTP, data._source.nStrikePrice1, 4,
        this.dateDiffernece(data._source.nExpiryDate1), data.IV, callPut)
    }
    this.showpopupDelta = !this.showpopupDelta;
  }

  scrollToLabel() {
    try {
      let titleELe = document.getElementById("call-put-add-money");
      if (titleELe == null) {
        setTimeout(() => {
          this.scrollToLabel();
        }, 500);
      }
      else {
        setTimeout(() => {
          let titleELe = document.getElementById("call-put-add-money");
          this.content.scrollToPoint(0, titleELe.offsetTop, 1000);
        }, 200);
      }


    } catch (error) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','scrollToLabel', error.Message, undefined, error.stack, undefined, undefined));
    }
  }

  nTheoCall: any = 0.0;
  nTheoPut: any = 0.0;
  nDeltaCall: any = 0.0;
  nDeltaPut: any = 0.0;
  nGammaCall: any = 0.0;
  nGammaPut: any = 0.0;
  nThetaCall: any = 0.0;
  nThetaPut: any = 0.0;
  nVegaCall: any = 0.0;
  nVegaPut: any = 0.0;
  nRhoCall: any = 0.0;
  nRhoPut: any = 0.0;
  HUNDRED_FLOAT: any = 100.00;
  nDaysUntilExpiration: any = 0.0;
  nActualMarketPrice: any = 0.0;
  showcalculate(nIndexPrice, nStrikePrice, nInterestRate, nDaysUntilExpiration, pVolatility, nOption) {
    try {
      let lnCall, lnPut, lnIndexPrice, lnStrikePrice, lnVolatility, lnInterestRate, lnDaysUntilExpiry, lnDividentYield;
      let lnD1, lnD2;
      let lnstdNormal1, lnstdNormal2, lnstdNormal3, lnstdNormal4;

      lnIndexPrice = nIndexPrice;
      lnStrikePrice = nStrikePrice;
      lnInterestRate = nInterestRate / this.HUNDRED_FLOAT;
      lnDaysUntilExpiry = nDaysUntilExpiration / 365.0;
      lnVolatility = parseFloat((pVolatility)) / this.HUNDRED_FLOAT;

      let lnExponential = Math.exp((-lnInterestRate) * lnDaysUntilExpiry);
      let lnNaturalLog = Math.log(lnIndexPrice / lnStrikePrice);
      let lnVolatilitySq = Math.pow(lnVolatility, 2);
      let lnSqrtDaysUntilExpiry = Math.pow(lnDaysUntilExpiry, 0.5);
      if (parseInt(nDaysUntilExpiration) === 0) {
        this.nGammaCall = 0;
        this.nGammaPut = 0;
        this.nThetaCall = 0;
        this.nThetaPut = 0;
        this.nVegaCall = 0;
        this.nVegaPut = 0;
        this.nRhoCall = 0;
        this.nRhoPut = 0;

        if (nIndexPrice >= nStrikePrice) {
          this.nDeltaCall = 1;
          this.nDeltaPut = 0;
          this.nTheoCall = nIndexPrice - nStrikePrice;
          this.nTheoPut = 0;
        }
        else {
          this.nDeltaCall = 0;
          this.nDeltaPut = -1;
          this.nTheoCall = 0;
          this.nTheoPut = nStrikePrice - nIndexPrice;
        }
        //call or put
        if (nOption === 0) {
          this.nActualMarketPrice = this.nTheoCall;
        }
        if (nOption === 1) {
          this.nActualMarketPrice = this.nTheoPut;
        }
      }
      else {
        lnD1 = (lnNaturalLog + ((lnInterestRate + (lnVolatilitySq / 2)) * lnDaysUntilExpiry)) / (lnVolatility * lnSqrtDaysUntilExpiry);
        lnD2 = lnD1 - lnVolatility * Math.pow((lnDaysUntilExpiry), 0.5);

        lnstdNormal1 = clsCommonMethods.fn_StdNormal(lnD1);
        lnstdNormal2 = clsCommonMethods.fn_StdNormal(lnD2);
        lnstdNormal3 = clsCommonMethods.fn_StdNormal(-lnD2);
        lnstdNormal4 = clsCommonMethods.fn_StdNormal(-lnD1);

        lnCall = lnIndexPrice * lnstdNormal1 - lnStrikePrice * lnExponential * lnstdNormal2;
        lnPut = lnStrikePrice * lnExponential * lnstdNormal3 - lnIndexPrice * lnstdNormal4;

        let lpFormatedCall;
        let lpFormatedPut;
        //**
        lpFormatedCall = lnCall.toFixed(4);
        lpFormatedPut = lnPut.toFixed(4);

        // this.nCall = lpFormatedCall;
        // this.nPut = lpFormatedPut;

        let lnDeltaCall, lnDeltaPut;
        let lpFormatedDeltaCall;
        let lpFormatedDeltaPut;
        lnDeltaCall = lnstdNormal1;

        lnDeltaPut = lnstdNormal1 - 1;
        lpFormatedDeltaCall = lnDeltaCall.toFixed(4);
        lpFormatedDeltaPut = lnDeltaPut.toFixed(4);
        this.nDeltaCall = parseFloat(lpFormatedDeltaCall);
        this.nDeltaPut = parseFloat(lpFormatedDeltaPut);

        let Normalpdf = Math.exp(-Math.pow(lnD1, 2) / 2) / 2.507132680972429;//Math.sqrt(2 * 3.14285714); // impr

        let lnGammaCall, lnGammaPut;
        let lpFormatedGammaCall;
        let lpFormatedGammaPut;
        lnGammaCall = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
        lnGammaPut = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
        lpFormatedGammaCall = lnGammaCall.toFixed(4);
        lpFormatedGammaPut = lnGammaPut.toFixed(4);
        this.nGammaCall = parseFloat(lpFormatedGammaCall);
        this.nGammaPut = parseFloat(lpFormatedGammaPut);


        let lnThetaCall, lnThetaPut;
        let lpFormatedThetaCall;
        let lpFormatedThetaPut;
        lnThetaCall = -((lnIndexPrice * Normalpdf * lnVolatility) / 2.0 / lnSqrtDaysUntilExpiry) -
          (lnInterestRate * lnStrikePrice * lnExponential * lnstdNormal2);
        lnThetaPut = -(lnIndexPrice * Normalpdf * lnVolatility / 2.0 / lnSqrtDaysUntilExpiry)
          + (lnInterestRate * lnStrikePrice * lnExponential * (1 - lnstdNormal2));

        lnThetaCall = (lnThetaCall / 365.0);
        lpFormatedThetaCall = lnThetaCall.toFixed(4);
        lnThetaPut = (lnThetaPut / 365.0);
        lpFormatedThetaPut = lnThetaPut.toFixed(4);
        this.nThetaCall = parseFloat(lpFormatedThetaCall);
        this.nThetaPut = parseFloat(lpFormatedThetaPut);


        let lnVegaCall, lnVegaPut;
        let lpFormatedVegaCall;
        let lpFormatedVegaPut;
        lnVegaCall = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;
        lnVegaPut = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;

        lnVegaCall = lnVegaCall / 100.0;
        lpFormatedVegaCall = lnVegaCall.toFixed(4);
        lnVegaPut = lnVegaPut / 100.0;
        lpFormatedVegaPut = lnVegaPut.toFixed(4);

        this.nVegaCall = parseFloat(lpFormatedVegaCall);
        this.nVegaPut = parseFloat(lpFormatedVegaPut);

        let lnRhoCall, lnRhoPut;
        let lpFormatedRhoCall;
        let lpFormatedRhoPut;
        lnRhoCall = lnStrikePrice * lnExponential * lnDaysUntilExpiry * lnstdNormal2;
        lnRhoPut = -lnDaysUntilExpiry * lnExponential * (lnIndexPrice) * lnstdNormal3;
        lnRhoCall = lnRhoCall / 100.0;
        lpFormatedRhoCall = lnRhoCall.toFixed(4);
        lnRhoPut = lnRhoPut / 100.0;
        lpFormatedRhoPut = lnRhoPut.toFixed(4);
        this.nRhoCall = parseFloat(lpFormatedRhoCall);
        this.nRhoPut = parseFloat(lpFormatedRhoPut);

        // this.nTheoCall = this.nCall;
        // this.nTheoPut = this.nPut;
      }
    } catch (error) {
      console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId, clsConstants.C_S_LOGTYPE_APPERROR, undefined, clsGlobal.logManager.createLogPayload('ScripinfoPage','scrollToLabel', error.Message, undefined, error.stack, undefined, undefined));
    }
  }
  _csvData: any
  exportToCSV() {
    if (this.segmentSelected == "Profit & Loss")
      this.downloadFile(this.ProfitLossResp);
    if (this.segmentSelected == "Balance Sheet")
      this.downloadFile(this.CompanyBalanceSheet)
    if (this.segmentSelected == "Results")
      this.downloadFile(this.CompanyResult)
  }

  downloadFile(data, filename = 'data') {
    let csvData = this.ConvertToCSV(data, [
      'ColumnName', 'year1', 'year2', 'year3'
    ]);
    console.log(csvData)
    let blob = new Blob(['\ufeff' + csvData], {
      type: 'text/csv;charset=utf-8;'
    });

    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1;
    navigator.userAgent.indexOf('Chrome') == -1;
    //if Safari open in new window to save file with random filename. 
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  ConvertToCSV(objArray, headerList) {
    let array =
      typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row = 'S.No, ';
    for (let index in headerList) {
      row += headerList[index] + ', ';
    }

    row = row.slice(0, -1);
    str += row + '\r\n';
    for (let i = 0; i < array.length; i++) {
      let line: any = (i + 1);
      for (let index in headerList) {
        let head = headerList[index];
        line += "," + array[i][head];
      }
      str += line + "\r\n";
    }
    return str;
  }

  eventclick(event) {
    if (event.type == "Reco") {
      this.selectedSegment = "Recommendations"
    }
  }
  clickChooseAnnual() {
    this.showChooseAnnual = !this.showChooseAnnual;
  }

  showFullMode: boolean = false;
  onFocus(objOE) {
    this.showFullMode = true;
  }


}
