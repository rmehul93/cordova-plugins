import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonContent } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsHttpService } from '../../Common/clsHTTPService';
import { ToastServicesProvider } from '../../providers/toast-services/toast.services';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsTradingMethods } from '../../Common/clsTradingMethods';
import { clsCommonMethods } from '../../Common/clsCommonMethods';
import { clsLocalStorageService } from '../../Common/clsLocalStorageService';
import { TranslateService } from '@ngx-translate/core';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { GlobalEventsService } from 'src/app/providers/global-events.service';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { CDSServicesProvider } from 'src/app/providers/cds-services/cds.services';

@Component({
  selector: 'app-fii-dii-mf',
  templateUrl: './fii-dii-mf.page.html',
  styleUrls: ['./fii-dii-mf.page.scss'],
})
export class FiiDiiMfPage implements OnInit {
  @ViewChild(IonContent, { static: false }) content: IonContent;
  objScannerData: any = {};
  tabName: string = "FII";
  screenerData: any = [];
  showloader: boolean = false;
  showExpandHeader: boolean = false;
  tempFavScreeners: any = [];
  searchText: string = "";
  searchTextChanged = new Subject<string>();
  subscription: any;
  searchTextEntered: string = "";
  messageSearchData = []
  showSearch: boolean = false;
  hdrName: string = "";
  noDataFound: boolean = false;


  constructor(private navCtrl: NavController, private paramService: NavParamService,
    public objHttpService: clsHttpService,
    public objToast: ToastServicesProvider,
    public clsLocalStorage: clsLocalStorageService,
    public translate: TranslateService,
    public alertCtrl: AlertServicesProvider,
    private glbEvtService: GlobalEventsService,
    public cdsService: CDSServicesProvider,
    //private transactionService: TransactionService,
  ) {
    try {
      this.objScannerData = this.paramService.myParam;
      //this.segmentSelected = this.objScannerData.segSelcted;
      //this.tabsList.push(this.objScannerData.scannerItem.ScannerName_1);
      //this.tabsList.push(this.objScannerData.scannerItem.ScannerName_2);
      //this.objScannerData.Favourite = false
      //this.type = this.objScannerData.GroupName;
      this.hdrName = this.objScannerData.scannerItem.GroupName;
      //this.globalScannerList = clsGlobal.scannerList;
      //this.populateScreener();
    } catch (e) {

    }
  }

  ngOnInit() {
    this.getFIIDIIMFData();
    this.subscription = this.searchTextChanged.pipe(debounceTime(500), distinctUntilChanged()
    ).subscribe(search => this.getValues(search));
  }

  switchTab(event) {
    //console.log(event);
    this.content.scrollToTop();
    let methodName = "";
    event.detail.value = (event.detail.value == 'FII') ? methodName = "FII" : (event.detail.value == 'DII') ? methodName = "DII" : methodName = "MF";
    this.tabName = event.detail.value;
    this.getFIIDIIMFData();
  }

  getFIIDIIMFData() {
    this.showloader = true;
    this.screenerData = [];
    this.noDataFound = false;
    this.cdsService
      .getFIIDIIMFData(this.tabName)
      .then((objresponse: any) => {
        try {
          //console.log(objresponse);
          this.showloader = false;
          let resp: any;
          resp = objresponse.ResponseObject.resultset;
          if (resp && resp.length > 0)
            this.screenerData = resp;
          else
            this.noDataFound = true;
        } catch (error) {
          this.showloader = false;
          this.noDataFound = true;
          clsGlobal.logManager.writeErrorLog('fii-dii-mf', 'getFIIDIIMFData', error);
        }
      }).catch(error => {
        this.showloader = false;
        this.noDataFound = true;
      })
  }

  scrollContent(event) {
    if (event.detail.scrollTop > 130) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
    //console.log(event);
  }

  async favUnFavScreeners(item) {
    try {
      await this.clsLocalStorage.getItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS)
        .then((data: any) => {
          let obj = JSON.parse(data);
          if (obj && obj.length > 0) {
            this.tempFavScreeners = obj;
          }
        }, error => {
          console.log('Error while retrieving local storage details.' + error);
        });
      if (!item.scannerItem.Favourite || item.scannerItem.Favourite == false) {
        item.scannerItem.Favourite = true;
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = true;
        });
        this.tempFavScreeners.push(item.scannerItem);
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
      else {
        if (this.tempFavScreeners.length == 5)
          return this.objToast.showAtBottom("There should be atleast 5 Screeners in My Favourite Screeners.");
        item.scannerItem.Favourite = false;
        this.tempFavScreeners = this.tempFavScreeners.filter((element, index, array) => {
          return element.GroupName != this.hdrName;
        });
        clsGlobal.scannerList.forEach(element => {
          if (element.GroupName == item.scannerItem.GroupName)
            element.Favourite = false;
        });
        this.clsLocalStorage.setItem(clsConstants.LOCAL_STORAGE_FAVOURITE_SCREENERS, JSON.stringify(this.tempFavScreeners));
      }
    } catch (error) {
      console.log(error);
    }
  }

  goBack() {
    this.navCtrl.pop();
  }

  search($event) {
    if ($event) {
      this.searchText = $event.toUpperCase();
      this.searchTextChanged.next($event);
    } else {
      this.messageSearchData = [];
    }
  }

  clearSearch() {
    this.searchText = '';
    this.messageSearchData = [];
    this.searchTextEntered = '';
  }

  showSearchPopup() {
    this.searchText = '';
    this.showSearch = true;
    this.messageSearchData = [];
  }

  hideSearchPopup() {
    this.showSearch = false;
    this.searchText = '';
    this.messageSearchData = [];
  }

  getValues(search) {
    try {
      this.messageSearchData = [];
      if (search.length < 1) {
        this.searchTextEntered = '';
        return;
      }
      this.searchTextEntered = search.toUpperCase();
      if (this.tabName == 'FII') {
        this.messageSearchData = this.screenerData
          .filter(x => (x.FIIDate.toUpperCase().includes(this.searchTextEntered)));
      } else if (this.tabName == 'DII') {
        this.messageSearchData = this.screenerData
          .filter(x => (x.TransactionDate.toUpperCase().includes(this.searchTextEntered)));
        //console.log(this.messageSearchData)
      } else if (this.tabName == 'MF') {
        this.messageSearchData = this.screenerData
          .filter(x => (x.TransactionDate.toUpperCase().includes(this.searchTextEntered)));
        //console.log(this.messageSearchData)
      }


    } catch (error) {
      console.log(error)
    }
  }

  getFormattedNumbers(sNumber) {
    if (sNumber) {
      return clsCommonMethods.getNumberWithCurrencyFormat(sNumber);
    } else {
      return 0.00;
    }
  }
  
}
