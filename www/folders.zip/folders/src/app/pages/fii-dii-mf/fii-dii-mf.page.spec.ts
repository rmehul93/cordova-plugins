import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FiiDiiMfPage } from './fii-dii-mf.page';

describe('FiiDiiMfPage', () => {
  let component: FiiDiiMfPage;
  let fixture: ComponentFixture<FiiDiiMfPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiiDiiMfPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FiiDiiMfPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
