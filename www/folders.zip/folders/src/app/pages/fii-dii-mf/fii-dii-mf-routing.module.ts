import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FiiDiiMfPage } from './fii-dii-mf.page';

const routes: Routes = [
  {
    path: '',
    component: FiiDiiMfPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FiiDiiMfPageRoutingModule {}
