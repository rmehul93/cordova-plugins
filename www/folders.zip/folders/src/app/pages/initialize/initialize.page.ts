import { Component, OnInit } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { NavController, MenuController } from "@ionic/angular";
import { Hub } from 'aws-amplify';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsAppInitService } from 'src/app/Common/clsAppInitService';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants } from "src/app/Common/clsConstants";
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';

@Component({
  selector: 'app-initialize',
  templateUrl: './initialize.page.html',
})
export class InitializePage implements OnInit {
  
  guestTrailDays = 0;
  appInitText='The next gen<br> mobile trading app';
  constructor(private navCtrl: NavController,
    private toastservice: ToastServicesProvider,
   private nav: NavController,
   private menuCtrl: MenuController,private localstorageservice:clsLocalStorageService,
   private splashScreen:SplashScreen,
    private appSync: AppsyncDbService,
    private appInit : clsAppInitService,
    private navParamService: NavParamService
    ) {  
  } 
  ngOnInit() { 
    try {
      this.hideSplash(); 
      this.appInitText = this.navParamService.myParam || this.appInitText;
    } catch (error) {
      console.log(error)
    }
  } 

  ionViewWillEnter(){
    console.log("Inside Init page.");
    try {
      this.appInit.initializeApp().then(()=>{

        //SHOW MENU HIDE 
        clsGlobal.pubsub.publish('MENU_SHOW_HIDE');
        clsGlobal.pubsub.publish('MENU_DYNAMIC');
        clsGlobal.pubsub.publish("MENU_FONT_ZOOM");
        
        //APP_CMOT_CODE , If 1 then LITE mode, 2 means PRO , if zero then CMOT off.
        let _mode=clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CMOT_MODE)==undefined? 0 : parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CMOT_MODE).toString());
        clsGlobal.CMOTMode= (_mode);  
        //X API key for billing purpose need to use on header of every call.
        clsGlobal.X_API_KEY=  clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_X_API_KEY_PREFIX) ==undefined ?"": clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_X_API_KEY_PREFIX)+"_"+clsGlobal.ComId;
 
        if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT) != undefined && clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_OTP_INVALID_ATTEMPT_COUNT).toString().length > 0) {
          this.guestTrailDays = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_GUEST_MODE_TRIAL_DAYS));
        }
        this.menuCtrl.enable(false);
  
        setTimeout(() => { 
          this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
          .then((item: any) => { 
          if (item != undefined && item != 'undefined') {
            const objMPIN: any = JSON.parse(item);
            const lastLoginDate: Date = clsTradingMethods.convertToDateTime(objMPIN.LastLoginTime);
            const firstLoginOfDay = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_FIRST_LOGIN_OF_DAY) || 'ON';
            // TODO: todays date to be fetched from server.
            const todayDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
            let showMpin: boolean = false;
            if (firstLoginOfDay != undefined && firstLoginOfDay == 'ON') {
              if (lastLoginDate != undefined && lastLoginDate < todayDate) {
                // show signinPage
                showMpin = false;
              } else {
                // show mping page
                showMpin = true;
              }
            } else {
              // show mping page
              showMpin = true;
            } 
            
            if (showMpin && (objMPIN.MPINEnable == 'Y' || objMPIN.Fingerprint == 'Y')) { 
                //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_LOGIN); 
                console.log("Route to MPIN PAGE "+showMpin +" MPIN "+objMPIN.MPINEnable+ "  Fingerprint "+objMPIN.Fingerprint);
              this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_MPIN); //as mpin not working properly. 
            } 
            else if(objMPIN.guestMode){
              this.checkGuestAccount();
            } else {
                //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_LOGIN); 
                if( clsGlobal.CMOTMode == 2){
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
                }else{
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_LOGIN);
                } 
            }
          } else {
            if( clsGlobal.CMOTMode == 2){
              this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
            }else{
              this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_LOGIN);
            } 
          }
        }, error => {
          console.log('Error in getting MPINDetails.');
        }); 
        }, 500);
      });
    } catch (error) {
      console.log("Critical error :Unable to initialize page."+error);
    }
  }
  hideSplash()
  {
    try {
      this.splashScreen.hide();
      console.log("Splash is hide.");
    } catch (error) {
      console.log("Error in hiding splash screen.");
    }
  }

   /**
   * Disc : To check guest user is already present or not
   */

  checkGuestAccount(){
    try{
      this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((res :any)=>{
        
        let resp = JSON.parse(res);
        let currentDate = new Date();
        let guestRegisteredDate = Date.parse( resp.guestRegistrationDate)
        let diff = clsCommonMethods.dateDifferenceInDay(currentDate, guestRegisteredDate);
        if (resp.guestMode) {
          if (diff <= this.guestTrailDays) {
            clsGlobal.User.isGuestUser = true;
            clsGlobal.User.userId = resp.userId;
            clsGlobal.User.sessionId = resp.access_token;
            
            this.appSync.signingCognitoForTradingUser();
            //const listener = Hub.listen("datastore", async hubData => {
              //if (hubData.payload.event === "ready") {

               // listener();

                this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
              //}
            //});

            //this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);

          } else {
            this.toastservice.showAtBottom("Your Guest Trial Period Expired.");
            this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
          }
        }
        else {
          this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
        }
      })
    } catch (error) {
    }
  }


}
