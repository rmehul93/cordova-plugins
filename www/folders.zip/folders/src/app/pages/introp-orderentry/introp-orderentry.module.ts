import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { IntropOrderentryPageRoutingModule } from './introp-orderentry-routing.module';
import { IntropOrderentryPage } from './introp-orderentry.page';
import { ComponentsModule } from 'src/app/components/components.module';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComponentsModule,
    IntropOrderentryPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [IntropOrderentryPage]
})
export class IntropOrderentryPageModule {}
