import { IntropPopupOrderentryComponent } from './../../components/introp-popup-orderentry/introp-popup-orderentry.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, ModalController, Platform } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { NavParamService } from 'src/app/providers/nav-param.service';

@Component({
  selector: 'app-introp-orderentry',
  templateUrl: './introp-orderentry.page.html'
})
export class IntropOrderentryPage implements OnInit  {

  objOEDetail: any;
  @ViewChild('popupOE') objPopupOE: IntropPopupOrderentryComponent;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public clsLocalStorage: clsLocalStorageService,
    public translate: TranslateService,
    public platform: Platform,
    public router: Router,
    private paramService: NavParamService,
  ) {
    this.objOEDetail = this.paramService.myParam;
  }

  ngOnInit() {
    try {
      // this.translate.setDefaultLang(clsGlobal.defaultLanguage);
      // this.translate.use(clsGlobal.defaultLanguage);
      //clsGlobal.User.exchangesList = res.data.product_types;
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
    }
  }
  ionViewDidLoad(){
    clsGlobal.logManager.writeUserAnalytics("OrderEntryPage","","VISIT",""); 
  }
  /**
   * @method : Send Best five subscription request Order Entry
   */
  ionViewWillEnter() {
    try {
      //this.objOEDetail = this.paramService.myParam;
   //  this.objPopupOE.sendSubscritionRequest();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ionViewWillEnter", error);
    }
  }

  ionViewWillLeave() {
    try {
      //this.objOEDetail = this.paramService.myParam;
      this.objPopupOE.ionViewWillLeave();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "ionViewWillLeave", error);
    }
  }

  receiveMessage($event) {
    try {
      this.closeOrderEntry();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "receiveMessage", error);
    }
  }

  /**
   * @method : close Order Entry pop up and go back to previous page
   */
  closeOrderEntry() {
    try {
      this.navCtrl.pop();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "closeOrderEntry", error);
    }
  }
}
