import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CalculatorsOptionvaluePageRoutingModule } from './calculators-optionvalue-routing.module';

import { CalculatorsOptionvaluePage } from './calculators-optionvalue.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CalculatorsOptionvaluePageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [CalculatorsOptionvaluePage]
})
export class CalculatorsOptionvaluePageModule {}
