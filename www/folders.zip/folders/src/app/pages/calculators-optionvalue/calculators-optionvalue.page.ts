import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavController, IonInput } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { CupertinoSettings, CupertinoPane } from 'cupertino-pane';

@Component({
  selector: 'app-calculators-optionvalue',
  templateUrl: './calculators-optionvalue.page.html', 
})
export class CalculatorsOptionvaluePage implements OnInit {

  constructor(public navCtrl: NavController,
    public alertCtrl: AlertServicesProvider,) { }

  @ViewChild('inputId',{static : false}) inputId : IonInput;
  popupContractDays : boolean = false;
  popupStrikePrice : boolean = false;
  popupMarketvalue : boolean = false;
  currentDate : any;
  sSymbol : any = '';
  difference : any = '';
  searchcomplete : boolean = false;
  scripArrayList : any = [];
  tempexpirylist : any = [];
  tempstrikepricelist : any = [];
  strikeprice : any = '';
  spotprice : any = '';
  interestrate : any = '';
  volatility : any = '';
  dividend : any = '';
  selectedmode :any = 'CRRBM';
  callputmode : any = 'CALL';
  USDOREUR : any = 0;
  CallOrPut : any = 0;
  CallTheo : any = 0.0;
  PutTheo : any = 0.0;
  CallDelta : any = 0.0;
  PutDelta : any = 0.0;
  CallGamma : any = 0.0;
  PutGamma : any = 0.0;
  CallTheta : any = 0.0;
  PutTheta : any = 0.0;
  CallVega : any = 0.0;
  PutVega : any = 0.0;
  CallRho : any = 0.0;
  PutRho : any = 0.0;
  nIndexPrice : any = 0.0;
  nStrikePrice : any = 0.0;
  nInterestRate : any = 0.0;
  nDaysUntilExpiration : any = 0.0;
  nDividentYield : any = 0.0;
  nMethod : any = 0;
  nOption : any = 0;
  pVolatility : any = ''
  HUNDRED_FLOAT : any= 100.00;
  nTheoCall : any= 0.0;
  nTheoPut : any = 0.0;
  nDeltaCall : any = 0.0;
  nDeltaPut : any = 0.0;
  nGammaCall : any = 0.0;
  nGammaPut : any = 0.0;
  nThetaCall : any = 0.0;
  nThetaPut : any = 0.0;
  nVegaCall : any = 0.0;
  nVegaPut : any = 0.0;
  nRhoCall : any = 0.0;
  nRhoPut : any = 0.0;
  nActualMarketPrice : any = 0.0;
  nCall : any = 0.0;
  nPut : any = 0.0;
  bCalcImpVol: boolean = true;
  MarketVal : any = '';
  bAmerican : boolean = false;
  Steps : any = '0';
  expiryDayDiffList : any = [];
  strikepricelist : any = [];
  selected : boolean = true;
  @ViewChild('divFilter', { static: false }) divFilter: ElementRef;
  showExpandedFilter: boolean = false;
  filterPane: any;
  expiryDate : any;
  originalList : any = [];
  showhide : boolean = false;
  searchText : any;
  strikeOriginalList : any = [];
  disableOption : boolean = true;

  ngOnInit() {
    this.currentDate = new Date();
  }

  ionViewDidEnter(){
    try {
      clsGlobal.User.CalculatorType = 'OPTION';
      if(clsGlobal.User.searchScrip){
        this.selectedmode = 'CRRBM';
        this.callputmode = 'CALL';
        this.interestrate = '';
        this.volatility = '';
        this.dividend = '';
        this.strikeprice = '';
        this.tempexpirylist = [];
        this.expiryDayDiffList = [];
        this.tempstrikepricelist = [];
        this.strikepricelist = [];
        this.popupContractDays = false;
        this.popupStrikePrice = false;
        this.disableOption = true;
        this.expiryDate = '';
        this.difference = ''
        this.scripArrayList = [];
        this.originalList = [];
        this.sSymbol = clsGlobal.User.selectedScrip._source.sSymbol;
        this.spotprice = clsGlobal.User.selectedScrip._source.LTP;
        this.searchcomplete = true;
        this.scripArrayList = clsGlobal.User.selectedArray;
        for(let count = 0 ; count < this.scripArrayList.length; count++)
        {
          if(this.tempexpirylist.indexOf(this.scripArrayList[count]._source.nExpiryDate1) == -1)
          {
            if (this.scripArrayList[count]._source.nExpiryDate1 != '' && this.scripArrayList[count]._source.nExpiryDate1 != undefined) {
              this.tempexpirylist.push(this.scripArrayList[count]._source.nExpiryDate1);
              this.expiryDayDiffList.push({
                daysDifference: this.dateDiffernece(this.scripArrayList[count]._source.nExpiryDate1),
                Day: new Date(this.scripArrayList[count]._source.nExpiryDate1).getDate(),
                Month: (new Date(this.scripArrayList[count]._source.nExpiryDate1).toLocaleString('default', { month: 'short' })).toUpperCase(),
                Year: new Date(this.scripArrayList[count]._source.nExpiryDate1).getFullYear().toString().substr(-2),
                Date: new Date(this.scripArrayList[count]._source.nExpiryDate1).getDate() + ' ' + (new Date(this.scripArrayList[count]._source.nExpiryDate1).toLocaleString('default', { month: 'short' })).toUpperCase() + ' ' + "'" + new Date(this.scripArrayList[count]._source.nExpiryDate1).getFullYear().toString().substr(-2),
                selected: false
              });
            }
          }
  
          if(this.tempstrikepricelist.indexOf(this.scripArrayList[count]._source.nStrikePrice1) == -1)
          {
            if (this.scripArrayList[count]._source.nStrikePrice1 != '' && this.scripArrayList[count]._source.nStrikePrice1 != undefined) {
              this.tempstrikepricelist.push(this.scripArrayList[count]._source.nStrikePrice1);
              this.strikepricelist.push({
                strikeprice: this.scripArrayList[count]._source.nStrikePrice1,
                selected: false
              });
            }
          }
        }
  
        for(let count = 0; count < this.expiryDayDiffList.length; count++)
        {
          if(this.expiryDayDiffList[count].daysDifference == this.difference)
          {
            this.expiryDayDiffList[count].selected = true;
          }
        }

        if(clsGlobal.User.selectedScrip._source.sInstrumentName == 'EQUITIES' || clsGlobal.User.selectedScrip._source.sInstrumentName == '')
        {
          if(this.expiryDayDiffList.length > 0)
          {
          this.dateFormation(this.expiryDayDiffList[0].Date);
          this.difference = this.dateDiffernece(this.expiryDayDiffList[0].Date);
          this.strikeprice = this.strikepricelist[0].strikeprice;
          }
        }
        else
        {
          this.dateFormation(clsGlobal.User.selectedScrip._source.nExpiryDate1);
          this.difference = this.dateDiffernece(clsGlobal.User.selectedScrip._source.nExpiryDate1);
          this.strikeprice = clsGlobal.User.selectedScrip._source.nStrikePrice1;
        }

        if(this.strikepricelist.length > 0 && this.strikeprice == '')
        {
          this.strikeprice = this.strikepricelist[0].strikeprice;
        }

        for(let count = 0; count < this.strikepricelist.length; count++)
        {
          if(this.strikepricelist[count].strikeprice == this.strikeprice)
          {
            this.strikepricelist[count].selected = true;
          }
        }

        this.strikeOriginalList = this.strikepricelist;
        this.originalList = this.expiryDayDiffList;
        clsGlobal.User.selectedArray = [];
        clsGlobal.User.selectedScrip = ''
        clsGlobal.User.searchScrip = false;
      }
    } catch (error) {
      console.log(error);
    }
  }

  goBack()
  {
    this.navCtrl.pop();
  }

  showContractDays(){
    if(this.expiryDayDiffList.length > 0)
    {
    this.popupContractDays = true;
    this.setFocusOnInput();
    }
  }

  setFocusOnInput(){
    this.inputId.setFocus();
  }

  hideContractDays(){
    this.popupContractDays = false;
    this.removeFocusOnInput();
    this.expiryDayDiffList = this.originalList;
  }

  removeFocusOnInput(){
    this.inputId.getInputElement().then(
      inputElement => inputElement.blur()
    );
  }

  searchContract(event){
    this.popupContractDays = true;
    if(event == '')
    {
      this.expiryDayDiffList = this.originalList;
      this.checkOptionValue(event,'expiryDate');
      return;
    }
    let search = event.toUpperCase();
    this.checkOptionValue(event,'expiryDate');
    let tempList = [];
    for (let counter = 0; counter < this.originalList.length; counter++) {
      let Date = this.originalList[counter].Date;
      if (Date.includes(search)) {
        tempList.push(this.originalList[counter]);
      }
    }
    this.expiryDayDiffList = tempList;
  }

  /** <Norwin Dcruz> <08/01/2021> <To calculate option value> **/
  showcalculate(){   
    try {
      if(this.popupMarketvalue)
      {
        this.popupMarketvalue = !this.popupMarketvalue;
      }
      else
      {
        this.hideContractDays();
        if(this.validateOptionValues()){
          try {
            this.nIndexPrice = parseFloat(this.spotprice);
            this.nStrikePrice = parseFloat(this.strikeprice);
            this.nInterestRate = parseFloat(this.interestrate);
            this.nDaysUntilExpiration = parseInt(this.difference);
            this.nDividentYield = parseFloat(this.dividend);
            this.nMethod = this.USDOREUR;
            this.pVolatility = this.volatility.toString();
            this.nOption = this.CallOrPut;
            this.popupMarketvalue = !this.popupMarketvalue;
    
            this.actualCalculation();
            if (this.nMethod === 0 && this.nDaysUntilExpiration > 0)
                this.fn_ActualBinomialCalculation(this.Steps);
            if (isFinite(this.nTheoCall.toString()) === false) {
                this.nTheoCall = 0;
            }
            //  else { _selfOptionVal.MarketVal(this.nTheoPut); }
            if (isFinite(this.nTheoPut.toString()) === false) {
                this.nTheoPut = 0;
            }
            //  else { _selfOptionVal.MarketVal(this.nTheoCall); }
    
            this.CallTheo = this.nTheoCall.toString();
            this.PutTheo = this.nTheoPut.toString();
    
            this.CallDelta = this.nDeltaCall.toString();
            this.PutDelta = this.nDeltaPut.toString();
    
            this.CallGamma = this.nGammaCall.toString();
            this.PutGamma = this.nGammaPut.toString();
    
            this.CallTheta = this.nThetaCall.toString();
            this.PutTheta = this.nThetaPut.toString();
    
            this.CallVega = this.nVegaCall.toString();
            this.PutVega = this.nVegaPut.toString();
    
            this.CallRho = this.nRhoCall.toString();
            this.PutRho = this.nRhoPut.toString();
    
            this.MarketVal = this.nActualMarketPrice.toString();
    
          } catch (error) {
            clsGlobal.logManager.writeErrorLog('CalculatorsOptionvaluePage', 'showcalculate', error);
          }
    
        }
      }      
    } catch (error) {
      console.log(error);
    } 
  }

  /** <Norwin Dcruz> <08/01/2021> <To validate option value> **/
  validateOptionValues(){
    try {
      let SpotPrice = parseFloat(this.spotprice);
      let StrikePrice = parseFloat(this.strikeprice);
      let Volatility = parseFloat(this.volatility);
      let Interest = parseFloat(this.interestrate);
      let DividendYield = parseFloat(this.dividend);
      let DaysUntilExpiration = parseFloat(this.difference);
      //let MarketValue = parseFloat(this.marketvalue);

      if(DaysUntilExpiration == undefined || DaysUntilExpiration == null || DaysUntilExpiration == 0)
      {
        this.alertCtrl.showAlert('Contract Days is not valid');
        return false;    
      }

      if (DaysUntilExpiration < 0 || DaysUntilExpiration > 1800) {
        this.alertCtrl.showAlert('Please enter Days Until Expiration between 0 and 1800');
        return false;
      }

      if(this.strikepricelist.length > 0)
      {
        if(StrikePrice == undefined || StrikePrice == null || StrikePrice == 0)
        {
          this.alertCtrl.showAlert('Strike Price is not valid');
          return false;    
        }
      }
      else
      {
        if (StrikePrice === 0 || isNaN(StrikePrice))
        {
            this.alertCtrl.showAlert('Please Enter Valid Strike Price');
            return false;
        }
  
        if (StrikePrice < 0.0001 || StrikePrice > 99999.9999)
        {
            this.alertCtrl.showAlert('Please enter Strike Price between 0.0001 and 99999.9999');
            return false;
        }
      }

      if (SpotPrice === 0 || isNaN(SpotPrice))
       {
        this.alertCtrl.showAlert("Please Enter Valid Spot Price");
        return false;
       }

      if (SpotPrice < 0 || SpotPrice > 99999.9999)
      {
          this.alertCtrl.showAlert('Please enter Spot Price between 0.0001 and 99999.9999');
          return false;
      }     

      if (isNaN(Interest))
      {
          this.alertCtrl.showAlert('Please Enter Valid Interest Rate');
          return false;
      }

      if (Interest < 0.01 || Interest > 99.99)
      {
          this.alertCtrl.showAlert('Please enter Interest Rate between 0.01 and 99.99');
          return false;
      }

      if (isNaN(Volatility))
      {
          this.alertCtrl.showAlert('Please Enter Valid Volatility');
          return false;
      }

      if (Volatility < 0.01 || Volatility > 999.99)
      {
          this.alertCtrl.showAlert('Please enter Volatility between 0.01 and 999.99');
          return false;
      }

      if (DividendYield < 0 || DividendYield > 999.99)
      {
          this.alertCtrl.showAlert('Please enter Dividend Yield between 0 and 999.99');
          return false;
      }

      if (isNaN(DividendYield))
      {
          this.alertCtrl.showAlert('Please Enter Valid Dividend Yield');
          return false;
      }

      if(this.originalList > 0)
      {
        let expirypresent = false;
        for (let counter = 0; counter < this.originalList.length; counter++) {
          if (this.originalList[counter].Date == this.expiryDate) {
            expirypresent = true;
          }
        }
  
        if(!expirypresent)
        {
          this.alertCtrl.showAlert('Enter Proper Expiry in Contract Days');
          return false;
        }
      }

      return true;

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('CalculatorsOptionvaluePage', 'validateOptionValues', error);
    }

  }

  showLookUp()
  {
    this.navCtrl.navigateForward('/calculator-lookup');
  } 

  dateDiffernece(inputdate)
  {
    try {
      let nextdate : any = new Date(inputdate);
      let diffTime = Math.abs(nextdate - this.currentDate);
      let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24 ));
      return diffDays;
    } catch (error) {
      console.log(error);
    }
  }

  plusminus(item,type){
    try {
      if(type == 'interest')
      {
        if(this.interestrate == '')
        this.interestrate = 0;
        if(item == 'plus')
        {
          this.interestrate = parseFloat(this.interestrate) + 1;
        }
        else if(item == 'minus')
        {
          if(parseFloat(this.interestrate) <= 0)
          {
            this.checkOptionValue(this.interestrate,'interestrate');
            return;
          }
          this.interestrate = parseFloat(this.interestrate) - 1;
        }
        this.checkOptionValue(this.interestrate,'interestrate');
      }
      else
      {
        this.popupContractDays = false;
        if(this.difference == '')
        this.difference = 0;
        if(item == 'plus')
        {
          this.difference = parseFloat(this.difference) + 1;
        }
        else if(item == 'minus')
        {
          if(parseFloat(this.difference) <= 0)
          {
            this.checkOptionValue(this.difference,'difference');
            return;
          }
          this.difference = parseFloat(this.difference) - 1;
        }
        this.checkOptionValue(this.difference,'difference');
      }
    } catch (error) {
      console.log(error);
    }
  }

  selectcalculationmethod(event){
    if(event.detail.value == 'CRRBM')
    {
      this.selectedmode = event.detail.value;
      this.USDOREUR = 0;
    }
    else if(event.detail.value == 'BASPM')
    {
      this.selectedmode = event.detail.value
      this.USDOREUR = 1;
    }
  }

  methodchecked(event){

    if(event.detail.value == 'CALL')
    {
      this.CallOrPut = 0;
    }
    else if(event.detail.value == 'PUT')
    {
      this.CallOrPut = 1;
    }
    this.callputmode = event.detail.value;
  }

  actualCalculation(){
    try {
      let lnCall, lnPut, lnIndexPrice, lnStrikePrice, lnVolatility, lnInterestRate, lnDaysUntilExpiry, lnDividentYield;
      let lnD1, lnD2;
      let lnstdNormal1, lnstdNormal2, lnstdNormal3, lnstdNormal4;

      lnIndexPrice = this.nIndexPrice;
      lnStrikePrice = this.nStrikePrice;
      lnInterestRate = this.nInterestRate / this.HUNDRED_FLOAT;
      lnDaysUntilExpiry = this.nDaysUntilExpiration / 365.0;
      lnVolatility = parseFloat((this.pVolatility)) / this.HUNDRED_FLOAT;

      let lnExponential = Math.exp((-lnInterestRate) * lnDaysUntilExpiry);
      let lnNaturalLog = Math.log(lnIndexPrice / lnStrikePrice);
      let lnVolatilitySq = Math.pow(lnVolatility, 2);
      let lnSqrtDaysUntilExpiry = Math.pow(lnDaysUntilExpiry, 0.5);

      if (parseInt(this.nDaysUntilExpiration) === 0) {
          this.nGammaCall = 0;
          this.nGammaPut = 0;
          this.nThetaCall = 0;
          this.nThetaPut = 0;
          this.nVegaCall = 0;
          this.nVegaPut = 0;
          this.nRhoCall = 0;
          this.nRhoPut = 0;

          if (this.nIndexPrice >= this.nStrikePrice) {
            this.nDeltaCall = 1;
            this.nDeltaPut = 0;
            this.nTheoCall = this.nIndexPrice - this.nStrikePrice;
              this.nTheoPut = 0;
          }
          else {
              this.nDeltaCall = 0;
              this.nDeltaPut = -1;
              this.nTheoCall = 0;
              this.nTheoPut = this.nStrikePrice - this.nIndexPrice;
          }
          if (this.nOption === 0) {
              this.nActualMarketPrice = this.nTheoCall;
          }
          if (this.nOption === 1) {
              this.nActualMarketPrice = this.nTheoPut;
          }
      }
      else {

          if (this.nDividentYield === 0)	 //Non divident Adjusted
          {

              lnD1 = (lnNaturalLog + ((lnInterestRate + (lnVolatilitySq / 2)) * lnDaysUntilExpiry)) / (lnVolatility * lnSqrtDaysUntilExpiry);
              lnD2 = lnD1 - lnVolatility * Math.pow((lnDaysUntilExpiry), 0.5);

              lnstdNormal1 = this.fn_StdNormal(lnD1);
              lnstdNormal2 = this.fn_StdNormal(lnD2);
              lnstdNormal3 = this.fn_StdNormal(-lnD2);
              lnstdNormal4 = this.fn_StdNormal(-lnD1);

              lnCall = lnIndexPrice * lnstdNormal1 - lnStrikePrice * lnExponential * lnstdNormal2;
              lnPut = lnStrikePrice * lnExponential * lnstdNormal3 - lnIndexPrice * lnstdNormal4;

              let lpFormatedCall;
              let lpFormatedPut;
              //**
              lpFormatedCall = lnCall.toFixed(4);
              lpFormatedPut = lnPut.toFixed(4);

              this.nCall = lpFormatedCall;
              this.nPut = lpFormatedPut;

              let lnDeltaCall, lnDeltaPut;
              let lpFormatedDeltaCall;
              let lpFormatedDeltaPut;
              lnDeltaCall = lnstdNormal1;

              lnDeltaPut = lnstdNormal1 - 1;
              lpFormatedDeltaCall = lnDeltaCall.toFixed(4);
              lpFormatedDeltaPut = lnDeltaPut.toFixed(4);
              this.nDeltaCall = parseFloat(lpFormatedDeltaCall);
              this.nDeltaPut = parseFloat(lpFormatedDeltaPut);

              let Normalpdf = Math.exp(-Math.pow(lnD1, 2) / 2) / 2.507132680972429;//Math.sqrt(2 * 3.14285714); // impr

              let lnGammaCall, lnGammaPut;
              let lpFormatedGammaCall;
              let lpFormatedGammaPut;
              lnGammaCall = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
              lnGammaPut = Normalpdf / (lnIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
              lpFormatedGammaCall = lnGammaCall.toFixed(4);
              lpFormatedGammaPut = lnGammaPut.toFixed(4);
              this.nGammaCall = parseFloat(lpFormatedGammaCall);
              this.nGammaPut = parseFloat(lpFormatedGammaPut);


              let lnThetaCall, lnThetaPut;
              let lpFormatedThetaCall;
              let lpFormatedThetaPut;
              lnThetaCall = -((lnIndexPrice * Normalpdf * lnVolatility) / 2.0 / lnSqrtDaysUntilExpiry) -
                                  (lnInterestRate * lnStrikePrice * lnExponential * lnstdNormal2);
              lnThetaPut = -(lnIndexPrice * Normalpdf * lnVolatility / 2.0 / lnSqrtDaysUntilExpiry)
                                + (lnInterestRate * lnStrikePrice * lnExponential * (1 - lnstdNormal2));

              lnThetaCall = (lnThetaCall / 365.0);
              lpFormatedThetaCall = lnThetaCall.toFixed(4);
              lnThetaPut = (lnThetaPut / 365.0);
              lpFormatedThetaPut = lnThetaPut.toFixed(4);
              this.nThetaCall = parseFloat(lpFormatedThetaCall);
              this.nThetaPut = parseFloat(lpFormatedThetaPut);


              let lnVegaCall, lnVegaPut;
              let lpFormatedVegaCall;
              let lpFormatedVegaPut;
              lnVegaCall = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;
              lnVegaPut = lnIndexPrice * Normalpdf * lnSqrtDaysUntilExpiry;

              lnVegaCall = lnVegaCall / 100.0;
              lpFormatedVegaCall = lnVegaCall.toFixed(4);
              lnVegaPut = lnVegaPut / 100.0;
              lpFormatedVegaPut = lnVegaPut.toFixed(4);

              this.nVegaCall = parseFloat(lpFormatedVegaCall);
              this.nVegaPut = parseFloat(lpFormatedVegaPut);

              let lnRhoCall, lnRhoPut;
              let lpFormatedRhoCall;
              let lpFormatedRhoPut;
              lnRhoCall = lnStrikePrice * lnExponential * lnDaysUntilExpiry * lnstdNormal2;
              lnRhoPut = -lnDaysUntilExpiry * lnExponential * (lnIndexPrice) * lnstdNormal3;
              lnRhoCall = lnRhoCall / 100.0;
              lpFormatedRhoCall = lnRhoCall.toFixed(4);
              lnRhoPut = lnRhoPut / 100.0;
              lpFormatedRhoPut = lnRhoPut.toFixed(4);
              this.nRhoCall = parseFloat(lpFormatedRhoCall);
              this.nRhoPut = parseFloat(lpFormatedRhoPut);

              this.nTheoCall = this.nCall;
              this.nTheoPut = this.nPut;
          }
          else		 //Divident is not 0.Adjust for Divident
          {
              lnDividentYield = this.nDividentYield / this.HUNDRED_FLOAT;
              let lnDividentExpo = Math.exp((-lnDividentYield) * lnDaysUntilExpiry);
              let lnDivAdjustedIndexPrice = lnIndexPrice * lnDividentExpo;
              lnD1 = ((lnNaturalLog) + (lnInterestRate - lnDividentYield + (lnVolatilitySq / 2)) * lnDaysUntilExpiry) / lnVolatility / lnSqrtDaysUntilExpiry;
              lnD2 = lnD1 - lnVolatility * lnSqrtDaysUntilExpiry;

              let lnStdNormalD1 = this.fn_StdNormal(lnD1);
              let lnStdNormalD2 = this.fn_StdNormal(lnD2);


              lnCall = lnDivAdjustedIndexPrice * lnStdNormalD1 - lnStrikePrice * lnExponential * lnStdNormalD2;

              lnPut = lnStrikePrice * lnExponential * (1 - lnStdNormalD2) - lnDivAdjustedIndexPrice * (1 - lnStdNormalD1);

              //if (double.IsInfinity(lnCall) === false)
              //        lnCall = 0;
              //if (double.IsInfinity(lnPut) == false)
              //        lnPut = 0;


              let lpFormatedCall;
              let lpFormatedPut;
              lpFormatedCall = lnCall.toFixed(4);
              lpFormatedPut = lnPut.toFixed(4);
              //**
              this.nCall = lpFormatedCall;
              this.nPut = lpFormatedPut;

              let lnDeltaCall, lnDeltaPut;
              let lpFormatedDeltaCall;
              let lpFormatedDeltaPut;
              lnDeltaCall = lnDividentExpo * lnStdNormalD1;
              //lnDeltaPut	= lnDividentExpo * lnStdNormalD1 - 1;
              lnDeltaPut = lnDeltaCall - 1;
              lpFormatedDeltaCall = lnDeltaCall.toFixed(4);
              lpFormatedDeltaPut = lnDeltaPut.toFixed(4);
              this.nDeltaCall = parseFloat(lpFormatedDeltaCall);
              this.nDeltaPut = parseFloat(lpFormatedDeltaPut);

              let lnNormalPdfD1 = Math.exp(-Math.pow(lnD1, 2) / 2) / 2.507132680972429;//Math.sqrt(2 * 3.14285714);

              let lnGammaCall, lnGammaPut;
              let lpFormatedGammaCall;
              let lpFormatedGammaPut;
              lnGammaCall = lnNormalPdfD1 * lnDividentExpo / (lnDivAdjustedIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
              lnGammaPut = lnNormalPdfD1 * lnDividentExpo / (lnDivAdjustedIndexPrice * lnVolatility * lnSqrtDaysUntilExpiry);
              lpFormatedGammaCall = lnGammaCall.toFixed(4);
              lpFormatedGammaPut = lnGammaPut.toFixed(4);
              this.nGammaCall = parseFloat(lpFormatedGammaCall);
              this.nGammaPut = parseFloat(lpFormatedGammaPut);

              let lnVegaCall, lnVegaPut;
              let lpFormatedVegaCall;
              let lpFormatedVegaPut;
              lnVegaCall = lnDivAdjustedIndexPrice * lnSqrtDaysUntilExpiry * lnNormalPdfD1 * lnDividentExpo;
              lnVegaPut = lnDivAdjustedIndexPrice * lnSqrtDaysUntilExpiry * lnNormalPdfD1 * lnDividentExpo;;

              lnVegaCall = lnVegaCall / 100.0;
              lpFormatedVegaCall = lnVegaCall.toFixed(4);
              lnVegaPut = lnVegaPut / 100.0;
              lpFormatedVegaPut = lnVegaPut.toFixed(4);

              this.nVegaCall = parseFloat(lpFormatedVegaCall);
              this.nVegaPut = parseFloat(lpFormatedVegaPut);

              let lnThetaCall, lnThetaPut;
              let lpFormatedThetaCall;
              let lpFormatedThetaPut;
              lnThetaCall = -((lnDivAdjustedIndexPrice * lnNormalPdfD1 * lnVolatility * lnDividentExpo / 2 / lnSqrtDaysUntilExpiry))
                                + (lnDividentYield * lnDivAdjustedIndexPrice * lnStdNormalD1 * lnDividentExpo)
                                - (lnInterestRate * lnStrikePrice * lnExponential * lnStdNormalD2);

              lnThetaPut = -(lnDivAdjustedIndexPrice * lnNormalPdfD1 * lnVolatility * lnDividentExpo) / 2.0 / lnSqrtDaysUntilExpiry
                                - (lnDividentYield * lnDivAdjustedIndexPrice * (1 - lnStdNormalD1) * lnDividentExpo)
                                + (lnInterestRate * lnStrikePrice * lnExponential * (1 - lnStdNormalD2));

              lnThetaCall = lnThetaCall / 365.0;
              lpFormatedThetaCall = lnThetaCall.toFixed(4);
              lnThetaPut = lnThetaPut / 365.0;
              lpFormatedThetaPut = lnThetaPut.toFixed(4);

              this.nThetaCall = parseFloat(lpFormatedThetaCall);
              this.nThetaPut = parseFloat(lpFormatedThetaPut);

              let lnRhoCall, lnRhoPut;
              let lpFormatedRhoCall;
              let lpFormatedRhoPut;
              lnRhoCall = lnStrikePrice * lnDaysUntilExpiry * lnExponential * lnStdNormalD2;
              lnRhoPut = -lnStrikePrice * lnDaysUntilExpiry * lnExponential * (1 - lnStdNormalD2);
              lnRhoCall = lnRhoCall / 100.0;
              lpFormatedRhoCall = lnRhoCall.toFixed(4);
              lnRhoPut = lnRhoPut / 100.0;
              lpFormatedRhoPut = lnRhoPut.toFixed(4);
              this.nRhoCall = parseFloat(lpFormatedRhoCall);
              this.nRhoPut = parseFloat(lpFormatedRhoPut);

              this.nTheoCall = this.nCall;
              this.nTheoPut = this.nPut;

          }
          if (this.bCalcImpVol === true) {
              if (this.nOption === 0) {
                  this.nActualMarketPrice = this.nCall;
              }
              if (this.nOption === 1) {
                  this.nActualMarketPrice = this.nPut;
              }
          }
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('CalculatorsOptionvaluePage', 'actualCalculation', error);
    }
  }

  fn_ActualBinomialCalculation(steps){
    try {
      let T = this.nDaysUntilExpiration / 365.0;
      let n = (steps === 0) ? (parseInt(this.nDaysUntilExpiration) * 2)  : parseInt(steps); // used for precision
      let OptionValueC = new Array();
      let OptionValueP = new Array();


      let b = (this.nInterestRate / this.HUNDRED_FLOAT) - this.nDividentYield; //this.dCOC;
      let r = (this.nInterestRate / this.HUNDRED_FLOAT);
      let S = this.nIndexPrice;
      let X = this.nStrikePrice;

      let v = this.pVolatility / this.HUNDRED_FLOAT;

      let z = 1;

      let dt = T / n;
      let u = Math.exp(v * Math.pow(dt, 0.5));
      let q = 1 / u;
      let p = (Math.exp(b * dt) - q) / (u - q);
      let Df = Math.exp(-r * dt);


      for (let i = 0; i <= n; i++) {
          let temp = z * (S * Math.pow(u, i) * Math.pow(q, n - i) - X);
          OptionValueC[i] = Math.max(0, temp);
          OptionValueP[i] = Math.max(0, (-1) * temp);

      }

      for (let j = n - 1; j >= 0; j--)
          for (let i = 0; i <= j; i++) {
              if (this.bAmerican === false) {
                  OptionValueC[i] = (p * OptionValueC[i + 1] + (1 - p) * OptionValueC[i]) * Df;
                  OptionValueP[i] = (p * OptionValueP[i + 1] + (1 - p) * OptionValueP[i]) * Df;
              }
              else {
                  let x1 = (z * (S * Math.pow(u, i) * Math.pow(q, Math.abs(i - j)) - X));
                  let x2 = (p * OptionValueC[i + 1] + (1 - p) * OptionValueC[i]) * Df;
                  let x3 = (p * OptionValueP[i + 1] + (1 - p) * OptionValueP[i]) * Df;
                  OptionValueC[i] = Math.max(x1, x2);
                  OptionValueP[i] = Math.max(x1 * (-1), x3);

              }
          }

      this.nCall = OptionValueC[0];
      this.nPut = OptionValueP[0];

      this.nTheoCall = (Math.round(this.nCall * 10000)) / 10000;
      this.nTheoCall = this.nTheoCall.toString();
      let hello1 = this.nTheoCall
      if (hello1.indexOf(".") == -1) {
          this.nTheoCall += ".0000";
      }
      this.nPut = this.nPut.toString();
      if (this.nPut.indexOf(".") == -1) {
          this.nPut += ".0000";
      }
      this.nTheoPut = this.nPut;

      if (isFinite(this.nCall) === false)
          this.nCall = 0;
      if (isFinite(this.nPut) === false)
          this.nPut = 0;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('CalculatorsOptionvaluePage', 'fn_ActualBinomialCalculation', error);
    }
  }

  fn_StdNormal(nX){
    try {
      let lnResult;
      if (nX < -7.0)
          lnResult = this.fn_NormalDensityFunction(nX) / (Math.sqrt(1.0 + nX * nX));
      else if (nX > 7.0)
          lnResult = 1.0 - this.fn_StdNormal(-nX);
      else {
          lnResult = 0.2316419;
          let nNormalValues = [0.31938153,-0.356563782,1.7814477937,-1.8212255978,1.330274429];
          lnResult = 1.0 / (1 + lnResult * Math.abs(nX));
          lnResult = 1 - this.fn_NormalDensityFunction(nX) * (lnResult * (nNormalValues[0] +
                                                                    lnResult * (nNormalValues[1] +
                                                                    lnResult * (nNormalValues[2] +
                                                                    lnResult * (nNormalValues[3] +
                                                                   lnResult * (nNormalValues[4]))))));
          if (nX <= 0.0)
              lnResult = 1.0 - lnResult;
      }
      return lnResult;
      
    } catch (error) {
      console.log(error);
    }
  }

  fn_NormalDensityFunction(nVal){
    let result = 0.39894228040133 * Math.exp(-nVal * nVal / 2);
    return result;
  }

  selectedItem(item, type) {
    try {
      if (type.toUpperCase() == 'EXPIRY') {
        this.difference = item.daysDifference;
        this.expiryDate = item.Day + ' ' + item.Month + ' ' + "'" + item.Year;
        this.checkOptionValue(this.expiryDate,'expiryDate');
        this.hideContractDays();
        this.expiryDayDiffList = this.originalList;
      }
      else if (type.toUpperCase() == 'STRIKE') {
        this.strikeprice = item.strikeprice;
        for (let count = 0; count < this.strikepricelist.length; count++) {
          if (this.strikepricelist[count].strikeprice == this.strikeprice) {
            this.strikepricelist[count].selected = true;
          }
          else {
            this.strikepricelist[count].selected = false;
          }
        }
        this.closeStrikePrice();
      }

    } catch (error) {
      console.log(error);
    }
  }

  clearFields(){
    this.hideContractDays();
    this.sSymbol = '';
    this.difference = '';
    this.spotprice = '';
    this.expiryDayDiffList = [];
    this.originalList = [];
    this.strikeprice = ''
    this.strikepricelist = [];
    this.interestrate = '';
    this.volatility = '';
    this.dividend = '';
    this.selectedmode = 'CRRBM';
    this.callputmode = 'CALL';
    this.popupStrikePrice = false;
    this.popupContractDays = false;
    this.popupMarketvalue = false;
    this.disableOption = true;
    this.expiryDate = '';
    this.USDOREUR = 0;
    this.CallOrPut = 0;
    this.USDOREUR  = 0;
    this.CallOrPut = 0;
    this.CallTheo = 0.0;
    this.PutTheo = 0.0;
    this.CallDelta = 0.0;
    this.PutDelta = 0.0;
    this.CallGamma = 0.0;
    this.PutGamma = 0.0;
    this.CallTheta = 0.0;
    this.PutTheta = 0.0;
    this.CallVega = 0.0;
    this.PutVega = 0.0;
    this.CallRho = 0.0;
    this.PutRho = 0.0;
    this.nIndexPrice = 0.0;
    this.nStrikePrice = 0.0;
    this.nInterestRate = 0.0;
    this.nDaysUntilExpiration = 0.0;
    this.nDividentYield = 0.0;
    this.nMethod = 0;
    this.nOption = 0;
    this.pVolatility = ''
    this.HUNDRED_FLOAT= 100.00;
    this.nTheoCall= 0.0;
    this.nTheoPut = 0.0;
    this.nDeltaCall = 0.0;
    this.nDeltaPut = 0.0;
    this.nGammaCall = 0.0;
    this.nGammaPut = 0.0;
    this.nThetaCall = 0.0;
    this.nThetaPut = 0.0;
    this.nVegaCall = 0.0;
    this.nVegaPut = 0.0;
    this.nRhoCall = 0.0;
    this.nRhoPut = 0.0;
    this.nActualMarketPrice = 0.0;
    this.nCall = 0.0;
    this.nPut = 0.0;
    this.bCalcImpVol = true;
    this.MarketVal = '';
    this.bAmerican = false;
    this.Steps = '0';    
  }

  showStrikePrice(){
    if(this.strikepricelist.length > 0)
    {
    this.popupStrikePrice = true;
    this.checkForFilterPopupUpElementRendrer();
    }
  }

  checkForFilterPopupUpElementRendrer() {
    const divElement: HTMLElement = document.getElementById('divFilterPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForFilterPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divFilterPopup');
        this.filterPopupBottomToTop(divElement);
      }, 200);
    }
  }

  filterPopupBottomToTop(myElementRef) {
     try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        // dragBy: ['.pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop:true, //added by om on 24 th jan for backdrop display.
        onDidPresent: () => {
          ////console.log("onDidPresent")
        },
  
        // onDrag: () => {
        //   //  //console.log("onDrag");
        // },
        // onDragEnd: () => { 
        //   //console.log("onDragEnd"); 
        // },
        // onTransitionStart: () => { 
        //   //console.log("onTransitionStart") 
        // },
        onTransitionEnd: () => { 
          let topDiv = this.divFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedFilter = true;
          } else {
            this.showExpandedFilter = false;
          }
        },
        onBackdropTap: ()=>{
          //added by omprakash on 24 th jan for backdrop click
          this.closeStrikePrice();
        }
      }
      this.filterPane = new CupertinoPane(myElementRef, setting);
      this.filterPane.enableDrag();
      this.filterPane.present({ animate: true });
     } catch (error) {
       console.log("Error in filter page display "+error);
     }
  }

  closeStrikePrice() {
    this.popupStrikePrice = false;
    this.showExpandedFilter = false;
    this.showhide = false;
    this.filterPane.destroy({ animate: true });
  }

  /** <Norwin Dcruz> <28/01/2021> <To format date according to UI> **/
  dateFormation(inputdate) {
    try {
      let dateformat = new Date(inputdate)
      let sDate = dateformat.getDate();
      let sMonth = (dateformat.toLocaleString('default', { month: 'short' })).toUpperCase();
      let nYear = dateformat.getFullYear().toString().substr(-2);
      this.expiryDate = sDate + ' ' + sMonth + ' ' + "'" + nYear;
    } catch (error) {
      console.log(error);
    }
  }

  expandstrikeprice(){
    this.showhide = true;
    this.setFocusOnInput();
  }

  searchStrikePrice(event) {
    try{
      if(event == '')
      {
        this.searchText = '';
        this.strikepricelist = this.strikeOriginalList;
        return;
      }
      let search = event.toUpperCase();
      let tempList = [];
      for (let counter = 0; counter < this.strikeOriginalList.length; counter++) {
        let strikeprice = this.strikeOriginalList[counter].strikeprice;
        if (strikeprice.startsWith(search)) {
          tempList.push(this.strikeOriginalList[counter]);
        }
      }
      if(tempList.length == 0)
      { 
        this.strikepricelist = []
        return;
      }
      this.strikepricelist = tempList;
      this.showhide = true;
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indexviewdetailslookup', 'searchIndexViewDetailsLookup', error.message);
    }
  }

  checkOptionValue(event,type){
    if(type == 'spotprice'){
      this.spotprice = event;
    }
    else if(type == 'dividend'){
      this.dividend = event;
    }
    else if(type == 'interestrate'){
      this.interestrate = event;
    }
    else if(type == 'difference'){
      this.difference = event;
    }
    else if(type == 'expiryDate'){
      this.expiryDate = event;
    }
    else if(type == 'volatility'){
      this.volatility = event;
    }
    else if(type == 'strikeprice'){
      this.strikeprice = event;
    }

    if(this.spotprice == null)
    this.spotprice = '';

    if(this.strikeprice == null)
    this.strikeprice = '';

    if(this.volatility == null)
    this.volatility = '';

    if(this.interestrate == null)
    this.interestrate = '';

    if(this.difference == null)
    this.difference = '';

    if(this.dividend == null)
    this.dividend = '';

    let tempInterestRate = this.interestrate.toString();
    let tempDifference = this.difference.toString();

    this.dividend = this.dividend.toString();
    this.volatility = this.volatility.toString();
    this.spotprice = this.spotprice.toString();

    if(this.expiryDayDiffList.length == 0)
    {
      if((this.spotprice == '' || this.spotprice == undefined || this.volatility == '' || this.strikeprice == '' || this.dividend == '' || tempInterestRate == '' || tempDifference == '' || this.sSymbol == '')){
        this.disableOption = true;
      }
      else
      {
        this.disableOption = false;
      }
    }
    else
    {
      if((this.spotprice == '' || this.spotprice == undefined || this.volatility == '' || this.strikeprice == '' || this.dividend == '' || tempInterestRate == '' || tempDifference == '' || this.sSymbol == '' || this.expiryDate == '')){
        this.disableOption = true;
      }
      else
      {
        this.disableOption = false;
      }
    }
  }

}
