import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { WatchlistloaderPageRoutingModule } from './watchlistloader-routing.module';

import { WatchlistloaderPage } from './watchlistloader.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WatchlistloaderPageRoutingModule
  ],
  declarations: [WatchlistloaderPage]
})
export class WatchlistloaderPageModule {}
