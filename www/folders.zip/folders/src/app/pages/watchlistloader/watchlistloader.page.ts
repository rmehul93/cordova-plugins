import { Component, Input, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-watchlistloader',
  templateUrl: './watchlistloader.page.html',
})
export class WatchlistloaderPage implements OnInit {

  status:number=0;
  constructor(public navParam: NavParams) {
    let subject: BehaviorSubject<string> = this.navParam.get("status");
    subject.subscribe((message)=> this.status =parseInt(message));
  }

  ngOnInit() {
  }

}
