import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WatchlistloaderPage } from './watchlistloader.page';

const routes: Routes = [
  {
    path: '',
    component: WatchlistloaderPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class WatchlistloaderPageRoutingModule {}
