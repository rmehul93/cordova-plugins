import { ToastServicesProvider } from './../../providers/toast-services/toast.services';
import { NavParamService } from './../../providers/nav-param.service';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonInput, MenuController, NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';

@Component({
  selector: 'app-fundsadd',
  templateUrl: './fundsadd.page.html',
})
export class FundsaddPage implements OnInit {
  showAccounts: boolean = false;
  paymentGatewaychoice = false;
  addAmount: number;
  selectedFundsItem: any;
  productWisefundsDetails: any = [];
  selectedBankId: any;
  BankingOption: any = "NB";
  numberortell: any = "tel";
  bankList: any = [];
  selMappedBankId: any;
  mappedBankList: any = [];
  ModeOption = 0;
  UPIBankingOptionTabCode = "UP";
  trnResult = '';

  UPIRazorpayBankId = 'UPI - RAZORPAY';
  iInterval: any;
  NetNetPGLink = '';
  upiList = [];
  PGUPIGateway = []
  gatewayList = [];
  SelectedUPIGateway: any = '';
  gatewaySelected: any;
  amountEntered = 0;
  BankAccList = [];
  BankAccSelected: any;
  UPIID = '';
  MinUPIAmount = 50;
  PG_TRANSACTION_CHARGE_INCLUDED = "OFF"
  PG_TRANSACTION_CHARGE = 10;
  BlockedAmount = "0.00";
  AvailableAmount = "0.00";
  LedgerBalance = "0.00";
  ReleasableAmount = "0.00";
  BOB_DISPLAY_RELEASABLE_AMOUNT = "OFF";
  ModeSecVisible = false;
  AmountSecVisible = false;
  TransactionChrgSecVisible = false;
  TotalAmountSecVisible = false;
  ExpiryDateSecVisible = false;
  ExpiryStartDate = new Date();
  ExpiryEndDate = new Date();
  ExpiryDateText = '';
  ModeHoldSecEnable = false;
  ModeReleaseSecEnable = false;
  AccountNoSecVisible = false;
  PGConstantList = [];
  CheckBalanceSecVisible = false;
  LedgerBalanceSecVisible = false;
  ReleasableAmountSecVisible = false;
  PG_SIB_CHECKBALANCE = false;
  showUPIIdPopUp = false;
  BankBrokerCode = '';
  lastTransactionAmt = 0;
  showPayment: boolean = false;
  validUPIID = false;
  @ViewChild('ctrlUPIID', { static: false }) tagInputId: IonInput;

  showLinkAccount: boolean = false;
  selBankItem: any;

  showMappedBank: boolean = false;
  selMappedBankItem: any;

  showGatewayList: boolean = false;
  selGatewayItem: any;
  sDefaultBankId: any;
  sDefaultAccNo: any;
  sDefaultCustID: any;

  showBankAcc: boolean = false;
  selBankAccount: any;
  FundsAvailableSecVisible: boolean = false;

  constructor(private navCtrl: NavController,
    private menutCtrl: MenuController,
    private transactionService: TransactionService,
    private toastCtrl: ToastServicesProvider,
    private navParamService: NavParamService,
    private alertCtrl: AlertController,
    private localstorageservice: clsLocalStorageService,
    private iab: InAppBrowser) {
    if (navParamService.myParam != undefined) {//&& parseInt(navParamService.myParam) > 0
      //this.addAmount = navParamService.myParam;
      let isNumber = isNaN(parseInt(navParamService.myParam));
      if (!isNumber)
        this.addAmount = navParamService.myParam;
      else {
        if (typeof (navParamService.myParam) != "string")
          this.selectedFundsItem = navParamService.myParam;
      }
    }
  }



  ngOnInit() {
    try {

      this.productWisefundsDetails = clsGlobal.User.fundsDetails.productWisefundsDetails;
      for (let index = 0; index < this.productWisefundsDetails.length; index++) {
        this.productWisefundsDetails[index].balanceAmountDisplay =
          clsCommonMethods.kFormatter(this.productWisefundsDetails[index].balanceAmount);
      }

      if (!this.selectedFundsItem) {
        this.selectedFundsItem = this.productWisefundsDetails[0];
      }

      this.getBankList();
      this.getUPIDetails();

      this.localstorageservice.getItem("LAST_FUNDS_ADD").then(data => {
        if (data) {
          this.lastTransactionAmt = data;
        } else {
          this.lastTransactionAmt = 0;
        }
      });

    } catch (error) {
      console.log(error);
    }
  }
  ngAfterViewInit() {
    // setTimeout(() => {
    //   this.setFocusOnInput();
    // }, 1000);

  }

  setFocusOnInput() {
    this.tagInputId.setFocus();
  }
  clickAccounts() {
    this.showAccounts = !this.showAccounts;
  }

  goBack() {
    this.navCtrl.pop();
  }
  closePaymentGatewayPopUp() {
    this.showPayment = false;
  }
  rememberPaymentGateway(event) {
    this.paymentGatewaychoice = this.paymentGatewaychoice;
    if (this.paymentGatewaychoice) {
      this.localstorageservice.setItem("UPI_PAYMENT_GATEWAY", this.SelectedUPIGateway);

    }

  }
  setFundSelection(fundsItem) {

    this.showAccounts = !this.showAccounts;
    this.selectedFundsItem = fundsItem;
    this.selMappedBankItem = null;
    this.selBankItem = null;
    this.selectedBankId = '';
    this.showBankAcc = false;
    this.BankAccList = [];
    this.BankAccSelected = '';
    if (this.BankingOption == this.UPIBankingOptionTabCode || this.BankingOption == "NB") {
      this.getBankList();
      if (this.BankingOption == this.UPIBankingOptionTabCode) {
        this.fillMappedUPIGateway();
      }
    } else {
      this.getGatewayDetails();
    }

  }

  getBankList() {
    try {
      this.selectedBankId = null;
      //this.sDefaultBankId = undefined;
      //this.sDefaultCustID = undefined;
      //this.sDefaultAccNo = undefined;
      this.transactionService.getBankListForselectedProduct(this.selectedFundsItem.sProductId, this.BankingOption).then((response: any) => {
        if (response.status == 'success') {
          this.bankList = response.data[0];
          if (response.data[1][0] != undefined) {
            this.sDefaultBankId = response.data[1][0].PGDefaultBank.split('|')[0];
            this.sDefaultCustID = response.data[1][0].PGDefaultBank.split('|')[2];;
            this.sDefaultAccNo = response.data[1][0].PGDefaultBank.split('|')[1];;
          }
          if (this.bankList.length > 0) {
            if (this.sDefaultBankId != undefined) {
              let sDefBankItem = this.bankList.filter(item => {
                return item.sMasterBankId == this.sDefaultBankId;
              });
              if (sDefBankItem.length > 0) {
                this.selectedBankId = sDefBankItem[0].sMasterBankId;
                this.selBankItem = sDefBankItem[0];
              } else {
                this.selectedBankId = this.bankList[0].sMasterBankId;
                this.selBankItem = this.bankList[0];
              }

            } else {
              this.selectedBankId = this.bankList[0].sMasterBankId;
              this.selBankItem = this.bankList[0];
            }
            this.onPopBankChanges(this.selBankItem);
          }
          else
            this.toastCtrl.showWithButton("No linked bank account found.");
          //this.onBankChanges(null);
        } else {
          this.bankList = [];
        }
      }, err => {
        console.log(err);
        this.bankList = [];
      })
    } catch (error) {
      console.log(error);
    }
  }


  addFunds() {

    if (!this.selectedFundsItem) {
      this.toastCtrl.showAtBottom("Please select the Product")
      return;
    }

    if (!this.addAmount) {
      this.toastCtrl.showAtBottom("Please add amount ")
      return;
    }

    if ((this.addAmount) >= 9999999.99) {
      this.toastCtrl.showAtBottom('Please enter Amount between 0 to 9999999.99');

      return false;
    }

    let selectedBank = null;
    let selMappedBank = null;
    if (this.BankingOption == this.UPIBankingOptionTabCode || this.BankingOption == "NB") {

      this.bankList.forEach(element => {
        if (element.sMasterBankId == this.selectedBankId) {
          selectedBank = element;
        }
      });

      if (!selectedBank) {
        this.toastCtrl.showAtBottom("Please select bank account ");
        return;
      }


      this.mappedBankList.forEach(element => {
        if (element.sBankId == this.selMappedBankId) {
          selMappedBank = element;
        }
      });

      if (!selMappedBank) {
        this.toastCtrl.showAtBottom("Please select mapped bank account ");
        return;
      }
    }
    if (this.BankingOption == this.UPIBankingOptionTabCode) {
      if (this.showUPIIdPopUp) {


        let regexUPIIDobj = new RegExp(/^([a-zA-Z0-9]){5,30}([@]){1}([a-zA-Z]){3,30}?$/);
        if (this.UPIID.trim() == '') {
          this.toastCtrl.showAtBottom("Please Enter UPI ID");
          return;
        }
      } else {
        this.showUPIIdPopUp = !this.showUPIIdPopUp;
        //this.inputId.setFocus();
        setTimeout(() => {
          this.setFocusOnInput();
        }, 100);

        return;
      }

    }
    if (this.BankingOption == this.UPIBankingOptionTabCode) {
      if (selectedBank.sMasterBankId == "CBIHOLD" && this.ModeOption == 0) {
        //
        //strAmount = "0";
        this.addAmount = 0;
      }
      else if (selectedBank.sMasterBankId == "UCOHOLDSYNC") {

        //strAmount = "0";
        this.addAmount = 0;
      }



      //let strAmount;
      if (selectedBank.sMasterBankId == "CBIHOLD" && this.ModeOption == 0) {
        //
        //strAmount = "0";
        this.addAmount = 0;
      }
      else if (selectedBank.sMasterBankId == "UCOHOLDSYNC") {

        //strAmount = "0";
        this.addAmount = 0;
      }
      else {

        if ((this.addAmount) < this.MinUPIAmount) {
          this.toastCtrl.showAtBottom("The minimum amount can be transferred is Rs.50");
          return false;
        }

        //strAmount = (this.addAmount);
      }

    }
    else if (this.BankingOption == 'DC') {

      if (this.gatewaySelected == undefined || this.gatewaySelected == '') {

        this.toastCtrl.showAtBottom('Please select the Gateway');

        return false;
      }
    }


    if (this.BankingOption == this.UPIBankingOptionTabCode && this.PGUPIGateway.length > 0) {

      this.PGUPIGateway.forEach(element => {
        if (element.sMappedBankId == this.SelectedUPIGateway) {
          selMappedBank = element;
        }
      });
    }
    else if (this.BankingOption == 'DC') {

      this.gatewayList.forEach(element => {
        if (element.sMasterBankId == this.gatewaySelected) {
          selMappedBank = element;
        }
      });

    }

    let strBankId = selMappedBank.sBankId;
    let strMappedBankId = selMappedBank.sAggregatorBankId || '';
    let strAgencyId = selMappedBank.sMerchantId;
    let strBlockThirdParty = selMappedBank.nBlockThirdParty;
    let strBankGroupId = selMappedBank.nGroupId;

    let strBankAccountNo = "0";
    let strAcctCustId = "";
    if (this.BankingOption == this.UPIBankingOptionTabCode) {
      strBlockThirdParty = "1";
    }

    if (strMappedBankId.indexOf('-') != -1) {
      let arrBank = strMappedBankId.split('-');
      strMappedBankId = arrBank[0];
    }

    let selBankAcc;
    if (this.BankingOption == 'NB' || this.BankingOption == this.UPIBankingOptionTabCode) {

      if (strBlockThirdParty == "1") {

        if (this.BankAccSelected == undefined) {
          this.toastCtrl.showAtBottom('Bank account does not exist for selected bank');
          return false;
        }

        this.BankAccList.forEach(element => {
          if (element.sAccountNo == this.BankAccSelected) {
            selBankAcc = element;
          }
        });

        strBankAccountNo = selBankAcc.sAccountNo;
        strAcctCustId = selBankAcc.sCustomerId;

      }
    }

    if (this.BankingOption == 'DC') {
      strBankAccountNo = "0";
      strAcctCustId = "";
    }

    let strProductId = this.selectedFundsItem.sProductId;
    let strProductName = this.selectedFundsItem.sProductName;
    let strProduct = "WAVE";
    let strManagerId = clsGlobal.User.managerIP;
    if (strAgencyId != '')
      strAgencyId = strAgencyId.replace(" ", ",");

    let strUserId = clsGlobal.User.userId;
    let strUserGroupId = clsGlobal.User.groupId;//TODO: groupId hardcoded.

    let strBankBrokerCode = "";
    if (strBankId == 'BOMHOLD' && strBankBrokerCode == '') {
      this.toastCtrl.showAtBottom('Broker Code is mandatory for Bank of Maharashtra transactions');
      return false;
    }

    /*  Added on 29062010 for minimum amount validation for ATOM PG  */
    if ((strBankId == 'ATOMPG' || strBankId == 'ATOMPGDC') && this.addAmount < 50) // Currently amount set is 50
    {
      this.toastCtrl.showAtBottom('The minimum amount can be transferred is Rs.50');
      return false;
    }

    if (strBankId == 'HDFCS2S' && strAcctCustId == '') {
      this.toastCtrl.showAtBottom('Customer Id for the selected Bank Account is blank');
      return false;
    }

    if (strBankId == 'ATOMPG' || strBankId == 'BILL' || strBankId.toUpperCase() == 'TECHVIEW1') {
      if (this.PG_TRANSACTION_CHARGE_INCLUDED == "ON") {
        this.addAmount = (this.addAmount) + (this.PG_TRANSACTION_CHARGE);
      }
    }

    let strUrl = "ProcessSendData.aspx?BankID=" + strBankId + "&AgencyID=";
    strUrl += strAgencyId + "&ProductId=" + strProductId + "&ProductName=";
    strUrl += strProductName + "&Amount=" + this.addAmount.toString() + "&BankGroupId=" + strBankGroupId;
    strUrl += "&UserID=" + strUserId + "&UserGroupID=" + strUserGroupId;
    strUrl += "&Product=" + strProduct + "&ManagerId=" + strManagerId + "&BankAcctNo=";
    strUrl += strBankAccountNo + "&BlockThirdParty=" + strBlockThirdParty + "&BankBrokerCode=";
    strUrl += strBankBrokerCode + "&AccCustid=" + strAcctCustId + "&MappedBankId=" + strMappedBankId;

    if (this.BankingOption == this.UPIBankingOptionTabCode) {
      let UPIValueHeader = "";
      if (clsGlobal.dConfigMaster.getItem("PG_UPI_ATOM_VALUE_HEADER") != undefined && clsGlobal.dConfigMaster.getItem("PG_UPI_ATOM_VALUE_HEADER").length > 0) {
        UPIValueHeader = clsGlobal.dConfigMaster.getItem("PG_UPI_ATOM_VALUE_HEADER");
      }
      else {
        UPIValueHeader = clsConstants.C_S_PG_ATOM_UPIID_VALUE_HEADER;
      }
      strUrl += clsConstants.C_S_URL_PARAMERTER_DELIMITER + clsConstants.C_S_PG_ATOM_UPIID_TEXT + clsConstants.C_S_NAMEVALUE_DELIMITER + this.UPIID;  //"&UPIID="
    }

    if (this.ModeOption == 0)//HOLD
    {
      if (strUrl.indexOf("&HoldRelease") == -1)
        strUrl += "&HoldRelease=HOLD";
    }
    else if (this.ModeOption == 1)//RELEASE
    {
      if (strUrl.indexOf("&HoldRelease") == -1)
        strUrl += "&HoldRelease=RELEASE";
    }

    let MappedBankId = "";
    let strMappedBankValue = '';
    this.NetNetPGLink = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_NETNET_URL) + "PaymentGateway/";

    if (this.BankingOption != this.UPIBankingOptionTabCode) {

      if (this.BankingOption == 'NB')
        strMappedBankValue = this.selMappedBankId;
      else
        strMappedBankValue = '';//this.GatewaySelected.sBankId;

      MappedBankId = selMappedBank.sMasterBankId;
    }

    this.localstorageservice.setItem("LAST_FUNDS_ADD", this.addAmount);

    if (MappedBankId == clsConstants.C_S_BOM_BANKID || this.SelectedUPIGateway == this.UPIRazorpayBankId) {
      try {
        const openwindowobj = this.iab.create(this.NetNetPGLink + strUrl, '_blank', 'location=yes');
        //let openwindowobj = '';//cordova.InAppBrowser.open(this.NetNetPGLink + strUrl, '_blank', 'location=yes');
        this.trnResult = "";
      }
      catch (e) {
        //Global.LogManager.WriteLog('Exception Occured 001-00-622885/001-00-624771/001-00-624605' + e.message, 'Error for InAppBrowser open', 'pg_ToBrokerAccount.js', '');
      }

    }
    else {

      console.log(this.NetNetPGLink + strUrl);
      const openwindowobj = this.iab.create(this.NetNetPGLink + strUrl, '_blank', 'location=yes');//cordova.InAppBrowser.open(this.NetNetPGLink + strUrl, '_blank', 'location=yes');
      this.trnResult = "";

      try {
        openwindowobj.on('exit').subscribe((event) => {
          this.stopInterval();
        });

      } catch (error) {
        this.toastCtrl.showAtBottom("InAppBrowser Open: " + error);
      }

      //setTimeout(this.smartCloseCordovaInAppBrowser.bind(this),50, openwindowobj);

      this.iInterval = setInterval(this.smartCloseCordovaInAppBrowser.bind(this), 50, openwindowobj);
      clsGlobal.User.fundsDetails = [];
    }

  }

  smartCloseCordovaInAppBrowser(openwindowobj) {
    try {
      openwindowobj.executeScript(
        { code: "document.getElementById('divTransactionStatus').innerHTML" },//localStorage.getItem('PHOENIX_LOADING')
        (data) => {

          if (data != "") {

            this.toastCtrl.showAtBottom("InAppBrowser Open: " + data);

            if (this.trnResult != "")
              return;

            this.trnResult = data;
            this.stopInterval();
            openwindowobj.close();
            this.showFundsPopup(data)

          }
        }
      );
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('fundsAdd', 'stopInterval()', 'Exception: ' + e.message);
    }
  }

  async showFundsPopup(dataFunds: any) {

    const confirm = await this.alertCtrl.create({
      header: 'Transaction Status',
      message: dataFunds,
      cssClass: clsGlobal.defaultTheme,
      buttons: [{
        text: 'OK',
        role: 'cancel',
        handler: () => {
          //this.ClearClick();
          return false;
        }
      }, {
        text: 'Funds View',
        handler: () => {
          //this.$state.go('Main.FundsView', {});
          this.navCtrl.pop();
          clsGlobal.User.fundsDetails = [];
          return false;
        }
      }]
    });

    return await confirm.present();
  }

  stopInterval() {
    try {
      clearInterval(this.iInterval);
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('fundsAdd', 'stopInterval()', 'Exception: ' + e.message);
    }
  }

  selectMode(selectedPaymentMode: any) {
    this.BankingOption = selectedPaymentMode;
    this.selMappedBankItem = null;
    this.selBankItem = null;
    this.selectedBankId = '';
    this.showBankAcc = false;
    this.BankAccList = [];
    this.BankAccSelected = '';
    if (this.BankingOption == this.UPIBankingOptionTabCode || this.BankingOption == "NB") {
      this.getBankList();
      if (this.BankingOption == this.UPIBankingOptionTabCode) {
        this.fillMappedUPIGateway();
      }
    } else {
      this.getGatewayDetails();
    }

  }

  onBankChanges(event) {
    try {

      if (this.BankingOption == this.UPIBankingOptionTabCode) {

        this.BankAccList = [];

        //let strProductSelectedName = "";

        // if (this.selectedFundsItem.sProductId == 8)
        //   strProductSelectedName = "MutualFund";
        // else if (this.selectedFundsItem.sProductId == 7)
        //   strProductSelectedName = "IPO";
        // else
        //   strProductSelectedName = "WAVE";

        let selectedBank = null;
        this.bankList.forEach(element => {
          if (element.sMasterBankId == this.selectedBankId) {
            selectedBank = element;
          }
        });

        let strMasterBankId = selectedBank.sMasterBankId;
        this.fillBankAccList(strMasterBankId);

      } else {
        this.selMappedBankId = null;
        if (!this.selectedBankId) return;
        this.transactionService.getMappedBankList(this.selectedFundsItem.sProductId, this.selectedBankId).then((response: any) => {
          if (response.status == 'success') {

            this.mappedBankList = response.data;

            if (this.mappedBankList.length > 0) {
              this.selMappedBankId = this.mappedBankList[0].sBankId;
              this.selMappedBankItem = this.mappedBankList[0];
              //   if (this.mappedBankList.length > 1 && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
              //     this.MappedBankSecVisible = true;
              // else
              //     this.MappedBankSecVisible =false;

              //selectedBankId
              if ((this.mappedBankList[0].sBankId == clsConstants.C_S_SIBHOLD_BANKID ||
                this.mappedBankList[0].sBankId == clsConstants.C_S_BOBHOLD_BANKID)
                && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
              {
                //this.CheckBalanceSecVisible = true;//trAmtBlk.Style.Add("display", "");

                this.BlockedAmount = "0.00";
                this.AvailableAmount = "0.00";
              }
              else {
                //this.CheckBalanceSecVisible =false;//trAmtBlk.Style.Add("display", "none");

                this.BlockedAmount = "0.00";
                this.AvailableAmount = "0.00";
              }

              if (this.mappedBankList[0].sBankId == clsConstants.C_S_BOBHOLD_BANKID &&
                this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
              {
                //this.LedgerBalanceSecVisible = true;
                this.LedgerBalance = "0.00";
              }
              else {
                //this.LedgerBalanceSecVisible =false;
              }

              if (this.mappedBankList[0].sBankId == clsConstants.C_S_BOBHOLD_BANKID &&
                this.BOB_DISPLAY_RELEASABLE_AMOUNT != 'OFF'
                && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
              {
                //this.ReleasableAmountSecVisible = true;
                this.ReleasableAmount = "0.00";
              }
              else {
                //this.ReleasableAmountSecVisible =false;
              }


              this.onMappedBankChanges(null);
            }

          } else {
            this.mappedBankList = [];
          }
        }, err => {
          console.log(err);
          this.mappedBankList = [];
        })
      }
    } catch (error) {
      console.log(error);
    }
  }

  onMappedBankChanges(evt) {
    try {

      let selMappedBank = null;
      this.mappedBankList.forEach(element => {
        if (element.sBankId == this.selMappedBankId) {
          selMappedBank = element;
          //break;
        }
      });

      let strBankId = selMappedBank.sBankId;
      let strMasterBankId = selMappedBank.sMasterBankId;
      let strMappedBankId = selMappedBank.sAggregatorBankId;
      let strAgencyId = selMappedBank.sMerchantId;
      let strBlockThirdParty = selMappedBank.nBlockThirdParty;
      let strBankGroupId = selMappedBank.nGroupId;

      if (strBankId.toUpperCase() == clsConstants.C_S_PNBHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_INGHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_SIBHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_CBIHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_OBCHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_INDIANHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_HDFCS2S_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_ANDHRA_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_UBIHOLD_BANKID
        || strBankId.toUpperCase() == clsConstants.C_S_BOBHOLD_BANKID) // CR 3986
      {
        //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave<start>
        if (this.BankingOption == this.UPIBankingOptionTabCode) {
          this.ModeSecVisible = false;
        }
        else {
          this.ModeSecVisible = true;
        }
      } else {
        this.ModeSecVisible = false;
      }

      if (strBankId == clsConstants.C_S_CBIHOLD_BANKID ||
        strBankId == clsConstants.C_S_BANK_ID_UCOHOLDSYNC) {
        this.AmountSecVisible = false;
        this.TransactionChrgSecVisible = false;
        this.TotalAmountSecVisible = false;
      }
      else {
        this.AmountSecVisible = true
      }

      if (strBankId.toUpperCase().trim() == clsConstants.C_S_INGHOLD_BANKID) {
        if (this.ModeOption == 0 && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
        {
          this.ExpiryDateSecVisible = true;
        }

        this.ExpiryEndDate.setDate(parseInt(this.PGConstantList[1].Value));

        let startDate = this.ExpiryStartDate.getMonth() + 1 + '/' + this.ExpiryStartDate.getDate() + '/' + this.ExpiryStartDate.getFullYear();//MM-DD-YYYY format
        let endDate = this.ExpiryEndDate.getMonth() + 1 + '/' + this.ExpiryEndDate.getDate() + '/' + this.ExpiryEndDate.getFullYear();//MM-DD-YYYY format
        this.ExpiryDateText = "(" + startDate + " to " + endDate + ")";//lblDateRange.Text = "(" + hidCurrentDate.Value + " to " + hidExpiryDate.Value + ")";
      }
      else {
        this.ExpiryDateSecVisible = false;
        this.ExpiryDateText = "";
      }

      //Condition for Andhra Bank to show hold/release but in disabled mode as only hold is allowed for the same
      if (strBankId.toUpperCase() == clsConstants.C_S_ANDHRA_BANKID) {
        this.ModeHoldSecEnable = true;
        this.ModeReleaseSecEnable = true;
      }
      else {
        this.ModeHoldSecEnable = false;
        this.ModeReleaseSecEnable = false;
      }

      if (strBlockThirdParty == "1" || this.BankingOption == this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
      {
        this.AccountNoSecVisible = true;
        this.fillBankAccList(strMasterBankId);
      }
      else {
        this.AccountNoSecVisible = false;
      }

      if (strBankId.toUpperCase() == clsConstants.C_S_BOMHOLD_BANKID || strBankId.toUpperCase() == "FED") {
        this.getBrokerCode(strBankId);
      }

      if (this.PGConstantList[0].Value == clsConstants.C_S_ON &&
        (strBankId == clsConstants.C_S_ATOMPG_BANKID || strBankId == "BILL" || strBankId.toUpperCase() == "TECHVIEW1")) {
        this.TransactionChrgSecVisible = true;
        this.TotalAmountSecVisible = true;
      }
      else {
        this.TransactionChrgSecVisible = false;
        this.TotalAmountSecVisible = false;
      }

      if ((strBankId == clsConstants.C_S_SIBHOLD_BANKID
        || strBankId == clsConstants.C_S_BOBHOLD_BANKID) && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave // CR 3986
      {
        this.CheckBalanceSecVisible = true;
        this.BlockedAmount = "0.00";
        this.AvailableAmount = "0.00";
      }
      else {
        this.CheckBalanceSecVisible = false;
        this.BlockedAmount = "0.00";
        this.AvailableAmount = "0.00";
      }

      if (strBankId == clsConstants.C_S_BOBHOLD_BANKID && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
      {
        this.LedgerBalanceSecVisible = true;
        this.LedgerBalance = "0.00";
      }
      //BT-4621/BT-4617:Kunalk:13-08-2019:Net banking bank license removal to use UPI( HDFC/ATOM/RazorPay)<Start>
      //Code Comment : Code Added to solve issue, "Release Amount" field should not get display in case of UPI
      if (strBankId == clsConstants.C_S_BOBHOLD_BANKID && this.BOB_DISPLAY_RELEASABLE_AMOUNT != 'OFF' && this.BankingOption != this.UPIBankingOptionTabCode) {
        //BT-4621/BT-4617:Kunalk:13-08-2019:Net banking bank license removal to use UPI( HDFC/ATOM/RazorPay)<End>
        this.ReleasableAmountSecVisible = true;
        this.ReleasableAmount = "0.00";
      }

    } catch (error) {

    }
  }
  getUPIDetails() {
    try {
      this.transactionService.getUPIList().then((response: any) => {
        if (response.status == 'success') {
          this.upiList = response.data;
          this.fillMappedUPIGateway();
        } else {
          this.upiList = [];
        }
      }, err => {
        console.log(err);
        this.upiList = [];
      })
    } catch (error) {

    }
  }

  fillMappedUPIGateway() {
    try {

      let arrGateways = this.upiList.filter(item => {
        return item.sProductId == this.selectedFundsItem.sProductId;
      });

      this.PGUPIGateway = [];
      for (let index = 0; index < arrGateways.length; index++) {
        const element = arrGateways[index];
        this.PGUPIGateway.push(element);
      }

      if (this.PGUPIGateway.length > 0) {
        // if(clsGlobal.checkedPaymentGateway!=undefined){
        //   this.SelectedUPIGateway = clsGlobal.checkedPaymentGateway
        // }else{
        // this.SelectedUPIGateway = this.PGUPIGateway[0].sMappedBankId;
        // }
        this.localstorageservice.getItem("UPI_PAYMENT_GATEWAY").then(data => {
          if (data != undefined) {
            this.SelectedUPIGateway = data;
          } else {
            this.SelectedUPIGateway = this.PGUPIGateway[0].sMappedBankId;
          }
        });
      }
      else {
        this.SelectedUPIGateway = '';
      }

    } catch (error) {

    }
  }

  onGatewayChange(evt) {
    try {
      let a = evt.target.value;
    } catch (error) {

    }
  }

  getGatewayDetails() {
    try {
      this.transactionService.getGatewayList(this.selectedFundsItem.sProductId).then((response: any) => {
        this.gatewayList = [];
        this.gatewaySelected = '';
        if (response.status == 'success') {
          this.gatewayList = response.data;
          if (this.gatewayList.length > 0) {
            this.gatewaySelected = this.gatewayList[0].sMasterBankId;
            this.selGatewayItem = this.gatewayList[0];
          }
        }
      }, err => {
        console.log(err);
        this.gatewayList = [];
        this.gatewaySelected = '';
      })
    } catch (error) {

    }
  }

  fillBankAccList(strMasterBankId) {
    try {
      this.transactionService.getBankAccList(this.selectedFundsItem.sProductId, strMasterBankId).then((response: any) => {
        this.BankAccList = [];
        this.BankAccSelected = '';
        if (response.status == 'success') {

          this.BankAccList = response.data;
          if (this.BankAccList.length > 0) {
            if (this.sDefaultAccNo != undefined) {
              let sDefBankItem = this.BankAccList.filter(item => {
                return item.sAccountNo == this.sDefaultAccNo;
              });
              if (sDefBankItem.length > 0) {
                this.BankAccSelected = sDefBankItem[0].sAccountNo;
              } else {
                this.BankAccSelected = this.BankAccList[0].sAccountNo;
              }
            } else {
              this.BankAccSelected = this.BankAccList[0].sAccountNo;
            }
            
            if (this.BankingOption == this.UPIBankingOptionTabCode) {

              if (this.BankAccList.length == 2) {

                this.BankAccSelected = this.BankAccList[1].sAccountNo;

                this.FundsAvailableSecVisible = false;
                this.CheckBalanceSecVisible = false;
                this.BlockedAmount = "0.00";
                this.AvailableAmount = "0.00";

              } else {
                
                let strBankId = this.selectedBankId;
                if (this.sDefaultBankId != null && this.sDefaultBankId == strBankId) {
                  if (this.sDefaultAccNo != null && this.sDefaultAccNo.length > 0) {

                    
                    for (let i = 0; i < this.BankAccList.length; i++) {
                      if (this.BankAccList[i].sAccountNo == this.sDefaultAccNo) {
                        this.BankAccSelected = this.BankAccList[i].sAccountNo;
                        break;
                      }
                    }
                  }
                }
                this.FundsAvailableSecVisible = false;
                this.CheckBalanceSecVisible = false;
                this.BlockedAmount = "0.00";
                this.AvailableAmount = "0.00";
              }
            }
            else {
              
              if (this.BankAccList.length == 2) {
                this.BankAccSelected = this.BankAccList[1];

                if (this.selMappedBankItem.sBankId == clsConstants.C_S_HDFCS2S_BANKID && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
                  this.FundsAvailableSecVisible = true;
                else
                  this.FundsAvailableSecVisible = false;

                
                if ((this.selMappedBankItem.sBankId == clsConstants.C_S_SIBHOLD_BANKID
                  || this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID) && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
                {
                  this.CheckBalanceSecVisible = true;
                  
                  this.BlockedAmount = "0.00";
                  this.AvailableAmount = "0.00";
                }
                else {
                  this.CheckBalanceSecVisible = false;
                  
                  this.BlockedAmount = "0.00";
                  this.AvailableAmount = "0.00";
                }

                if (this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
                {
                  this.LedgerBalanceSecVisible = true;
                  this.LedgerBalance = "0.00";
                }

                if (this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID && this.BOB_DISPLAY_RELEASABLE_AMOUNT != 'OFF' && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
                {
                  this.ReleasableAmountSecVisible = true;
                  this.ReleasableAmount = "0.00";
                }
              }
              else {

                let strBankId = this.selMappedBankItem.sBankId;

                
                if (this.sDefaultBankId != null && this.sDefaultBankId == strBankId) {
                  if (this.sDefaultAccNo != null && this.sDefaultAccNo.length > 0) {

                    
                    for (let i = 0; i < this.BankAccList.length; i++) {
                      if (this.BankAccList[i].sAccountNo == this.sDefaultAccNo) {
                        this.BankAccSelected = this.BankAccList[i];
                        break;
                      }
                    }


                    if (this.selMappedBankItem.sBankId == clsConstants.C_S_HDFCS2S_BANKID && this.BankingOption != this.UPIBankingOptionTabCode) //BT-156/Aditya K:11122018:ATOM UPI implementation in Odin Wave
                      this.FundsAvailableSecVisible = true;
                    else
                      this.FundsAvailableSecVisible = false;
                    // CR 3300
                    if ((this.selMappedBankItem.sBankId == clsConstants.C_S_SIBHOLD_BANKID
                      || this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID) &&
                      this.BankingOption != this.UPIBankingOptionTabCode) {
                      this.CheckBalanceSecVisible = true;

                      this.BlockedAmount = "0.00";
                      this.AvailableAmount = "0.00";
                    }
                    else {
                      this.CheckBalanceSecVisible = false;

                      this.BlockedAmount = "0.00";
                      this.AvailableAmount = "0.00";
                    }

                    if (this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID &&
                      this.BankingOption != this.UPIBankingOptionTabCode) {
                      this.LedgerBalanceSecVisible = true;
                      this.LedgerBalance = "0.00";
                    }

                    if (this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID &&
                      this.BOB_DISPLAY_RELEASABLE_AMOUNT != 'OFF' && this.BankingOption != this.UPIBankingOptionTabCode) {
                      this.ReleasableAmountSecVisible = true;
                      this.ReleasableAmount = "0.00";
                    }
                  }
                }
              }
            }

            this.AccountNoSecVisible = true;

            if (this.BankingOption != this.UPIBankingOptionTabCode) {

              if (this.selMappedBankItem.sBankId == clsConstants.C_S_BOBHOLD_BANKID) {
                this.getBalanceDetails();
              }
            }

          }

        }
      }, err => {
        console.log(err);
        this.BankAccList = [];
        this.BankAccSelected = '';
      })
    } catch (error) {

    }
  }

  getBalanceDetails() {

    try {

      if (this.selectedFundsItem.sProductName == "") {
        this.toastCtrl.showAtBottom('Please select product');
        return;
      }
      if (this.BankAccSelected.sAccountNo == "") {
        this.toastCtrl.showAtBottom('Please select bank account');
        return;
      }

      if (this.PG_SIB_CHECKBALANCE == false)
        return;

      
      // this.transactionService.getBalanceDetails(this.selectedFundsItem.sProductId, this.selectedBankId, this.BankAccSelected.sAccountNo).then((response: any) => {
      //   if (response.status == 'success') {  
      //   } else { 
      //   }
      // }, err => {
      //   console.log(err); 
      // });

    } catch (error) {

    }

  }

  getBrokerCode(bankId) {
    try {

      this.transactionService.getBrokerCode(bankId).then((response: any) => {
        if (response.status == 'success') {
          this.BankBrokerCode = response.data;
        } else {
          this.BankBrokerCode = '';
        }
      }, err => {
        this.BankBrokerCode = '';
        console.log(err);

      })
    } catch (error) {

    }
  }
  clickPayment() {
    this.showPayment = !this.showPayment;

  }

  closeUPIIDpopup() {
    this.showUPIIdPopUp = false;
  }

  getUPIIDvalue($event) {
    try {
      if ($event.length > 0) {
        this.validUPIID = true;
      } else {
        this.validUPIID = false;
      }
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "onKeyUp", error);
    }
  }

  onPopBankChanges(bankItem) {
    this.selectedBankId = bankItem.sMasterBankId;
    this.selBankItem = bankItem;
    this.onBankChanges(bankItem);
    this.closeBank();
  }

  showBank() {
    this.showLinkAccount = true;
  }

  closeBank() {
    this.showLinkAccount = false;
  }

  showMapBank() {
    this.showMappedBank = true;
  }

  closeMapBank() {
    this.showMappedBank = false;
  }

  onPopMappedBankChanges(bankItem) {
    this.selMappedBankId = bankItem.sBankId;
    this.selMappedBankItem = bankItem;
    this.onMappedBankChanges(bankItem);
    this.closeMapBank();
  }

  showGateway() {
    this.showGatewayList = true;
  }

  closeGateway() {
    this.showGatewayList = false;
  }

  onPopGatewayChanges(gwItem) {
    this.selGatewayItem = gwItem;
    this.closeGateway();
  }

  showBankAccounts() {
    this.showBankAcc = true;
  }

  closeBankAccounts() {
    this.showBankAcc = false;
  }

  onBankAccChanges(bankAccItem) {
    this.BankAccSelected = bankAccItem.sAccountNo;
    this.selBankAccount = bankAccItem;
    this.closeBankAccounts();
  }

}
