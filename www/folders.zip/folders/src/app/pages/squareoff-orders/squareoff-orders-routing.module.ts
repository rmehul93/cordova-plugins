import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SquareoffOrdersPage } from './squareoff-orders.page';

const routes: Routes = [
  {
    path: '',
    component: SquareoffOrdersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SquareoffOrdersPageRoutingModule {}
