import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SquareoffOrdersPageRoutingModule } from './squareoff-orders-routing.module';

import { SquareoffOrdersPage } from './squareoff-orders.page';
import { DirectiveSharedModule } from 'src/app/directives/directive.shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SquareoffOrdersPageRoutingModule,
    DirectiveSharedModule
  ],
  declarations: [SquareoffOrdersPage]
})
export class SquareoffOrdersPageModule {}
