import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsScripKey } from 'src/app/Common/clsScripKey';

@Component({
  selector: 'app-squareoff-orders',
  templateUrl: './squareoff-orders.page.html',
})
export class SquareoffOrdersPage implements OnInit {

  netPositionData: any = [];
  selectAll: boolean = false;
  isIndeterminate: boolean = false;
  showExpandHeader: boolean = false;
  sqaureOffOrderCheckCount = 0;
  showSquareOrdersPopup :boolean = false;
  isSquareOffOrderClick : boolean = false;
  zeroVal: number = 0;
  bcastHandler: any;
  netPositionScripKeys: any = [];
  constructor(private paramService: NavParamService,
    private transactionService : TransactionService,
    private toastServicesProvider : ToastServicesProvider,
    private navCtrl: NavController,) {
    this.netPositionData = paramService.myParam;
  }

 ngOnInit() {
    try {
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      if (this.netPositionData.length > 0) {
        this.netPositionData.forEach(element => {
          element.isChecked = false;
        });

        this.createBroadcastforNetposition();
      }
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "ngOnInit", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLoad() {
    clsGlobal.logManager.writeUserAnalytics("SquareoffOrdersPage", "", "VISIT", "");
  }
  

  ionViewWillLeave() {
    try {
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.netPositionScripKeys);
    } catch (err) {
      //console.log(err)
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'ionViewWillLeave',err.Message,undefined,err.stack,undefined,undefined));
    }
  }


  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('SquareoffOrdersPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
       if (this.netPositionData.length > 0) {
          this.netPositionData.forEach(netPositionItem => {
            if ((netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId) ) {

              nFormat = objMultiTLResp.PriceFormat

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;


              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }

              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];
            }
          });
        }

      }
    }
    catch (err) {
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'receiveTouchlineResponse',err.Message,undefined,err.stack,undefined,undefined));
    }
  }


  createBroadcastforNetposition() {
    try {
      for (let index = 0; index < this.netPositionData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token =  this.netPositionData[index].scrip_token;
        objScrpKey.MktSegId = this.netPositionData[index].mktSegId;
        this.netPositionScripKeys.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.netPositionScripKeys);
    } catch (error) {
      console.log("Error + createBroadcastforNetpositionExpiry" + error);
      //clsGlobal.logManager.writeErrorLog('TransactionPage', 'createBroadcastforNetpositionExpiry', error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'createBroadcastforNetpositionExpiry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  selectAllOrders() {
    try {
      setTimeout(() => {
        this.netPositionData.forEach(element => {
          element.isChecked = this.selectAll;
        });
      });
    } catch (error) {
   //   clsGlobal.ConsoleLogging("Error", "selectAllOrders", error);
   clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'selectAllOrders',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkUncheckOrder() {
    try {
      const totalItems = this.netPositionData.length;
      let checked = 0;
      this.netPositionData.map(element => {
        if (element.isChecked) checked++;
      });
      if (checked > 0 && checked < totalItems) {
        //If even one item is checked but not all
        this.isIndeterminate = true;
        this.selectAll = false;
      } else if (checked == totalItems) {
        //If all are checked
        this.selectAll = true;
        this.isIndeterminate = false;
      } else {
        //If none is checked
        this.isIndeterminate = false;
        this.selectAll = false;
      }

      this.sqaureOffOrderCheckCount = checked;
    } catch (error) {
     // clsGlobal.ConsoleLogging("Error", "checkUncheckOrder", error);
     clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'checkUncheckOrder',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  goBack() {
    this.navCtrl.pop();
  }

  closeSquareOffOrderPopup(){
    this.showSquareOrdersPopup  = false
  }

  squareOffAllOrders() {
    try {
      if (this.sqaureOffOrderCheckCount == 0) {
        this.toastServicesProvider.showAtBottom("You need to select orders for sqaure off");
      }
      else {
        if(this.showSquareOrdersPopup){
          var sqaureOffOrderArray = [];
          this.netPositionData.forEach(element => {
            if (element.isChecked == true)
              sqaureOffOrderArray.push(element);
          });
          this.isSquareOffOrderClick = true;
         this.transactionService.bulkOrderEntry(this.createOrdersRequest(sqaureOffOrderArray)).then((response:any)=>{
           if(response.status == 'success'){
             this.toastServicesProvider.showAtBottom("Square-off orders request submitted");
             this.showSquareOrdersPopup = false;
             this.isSquareOffOrderClick = false;
             this.navCtrl.pop();
           }else{
            this.toastServicesProvider.showAtBottom("Failed to submit Square-off orders request");
            this.showSquareOrdersPopup = false;
            this.isSquareOffOrderClick = false;
            this.navCtrl.pop();
           }
         
         }, error=>{
          this.toastServicesProvider.showAtBottom("Failed to submit Square-off orders request");
          this.showSquareOrdersPopup = false;
          this.isSquareOffOrderClick = false;
          this.navCtrl.pop();
          clsGlobal.logManager.writeErrorLog("SqaureOffOrdersPage" , "squareOffAllOrders" , error.message )
         })

        }else{
          
          var sqaureOffOrderArray = [];;
          this.netPositionData.forEach(element => {
            if (element.isChecked == true)
              sqaureOffOrderArray.push(element);
          });

          if (sqaureOffOrderArray.length > 0) {
            this.showSquareOrdersPopup = true
          }
        }
        
        }
    } catch (error) {
      // clsGlobal.logManager.writeErrorLog("SqaureOffOrdersPage" , "squareOffAllOrders_1" , error.message )
      // clsGlobal.ConsoleLogging("Error", "squareOffAllOrders", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('SquareoffOrdersPage', 'squareOffAllOrders',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  scrollContent(event) {
    if (event.detail.scrollTop > 80) {
      this.showExpandHeader = true;
    }
    if (event.detail.scrollTop < 50) {
      this.showExpandHeader = false;
    }
  }

  createOrdersRequest(sqaureOffOrderArray) {
    let requestArray = [];

    sqaureOffOrderArray.forEach(element => {
      requestArray.push({
        "scrip_info": {
          "exchange": element.exchange,
          "scrip_token": element.scrip_token,
          "symbol": element.symbol,
          "series": element.series,
          "expiry_date": element.expiry_date,
          "strike_price": element.strike_price,
          "option_type": element.option_type
        },
        "transaction_type": element.net_quantity > 0 ? 'SELL':'BUY',
        "product_type": element.product_type,
        "order_type": "RL-MKT",
        "quantity": Math.abs(element.net_quantity),
        "price": 0,
        "trigger_price": 0,
        "disclosed_quantity": 0,
        "validity": "DAY",
        "is_amo": false,
        "order_identifier": ''
      });
    });

    return requestArray;

  }

  getFormattedProductType(productType: string) {
    let product_type = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        product_type = productType.replace(/\w\S*/g, (txt) => { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase() })
        break;
      default:
        product_type = productType;
        break;
    }
    return product_type;
  }
  
  filterCheckedOrders(sqaureofforderitem){
    return sqaureofforderitem.isChecked;
  }

  getFormattedQty(qty){
      return Math.abs(qty);
  }
}
