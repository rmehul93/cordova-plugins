import { NavController, PopoverController, MenuController, IonSlides, IonContent, ModalController, IonButton } from '@ionic/angular';
//import { Content, Navbar} from "ionic-angular"
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, OnDestroy } from '@angular/core';
import { clsHttpService } from "src/app/Common/clsHTTPService";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { rejects } from 'assert';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { NavigationExtras, Router } from '@angular/router';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';
//import { WatchlistActionComponent } from 'src/app/components/watchlist-action/watchlist-action.component';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsBestFiveResponse } from 'src/app/communicator/clsBestFiveResponse';
import { DatePipe } from '@angular/common';
import { clsBestFiveRequest } from 'src/app/communicator/clsBestFiveRequest';
import { clsScrip } from 'src/app/Common/clsScrip';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { TransactionService } from 'src/app/providers/transaction.service';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { GlobalEventsService } from 'src/app/providers/global-events.service';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { WatchlistloaderPage } from '../watchlistloader/watchlistloader.page';
import { CupertinoPane, CupertinoSettings } from 'cupertino-pane';
//import { createAnimation, Animation } from '@ionic/core';
import { Animation, AnimationController } from '@ionic/angular';
import { PopoverPage } from 'src/app/components/pop-over/popover.page';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { Hub } from 'aws-amplify';
//import {Keyboard} from '@ionic-native/keyboard';


@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.page.html'
})
export class WatchlistPage implements OnInit, OnDestroy {

  IsWatchListExist = true;
  showInitLoader = clsGlobal.watchlistFirstInit;
  showOverlay = false;
  showPopUpOE = false;
  showContext = false;
  showWatchListSelection = false;
  viewExpand: boolean = true;
  selectedScrip: any;
  showRename = false;
  showDone = false;
  //dummy data.
  eventList: any = [];

  profileList = [];

  // hots: [],
  // ltp: "1238.90", perChange: "+23(0.24%)",
  watchListScripts = [];

  whatsHotScripList = [];
  whatsHotScripKeyList = [];
  myStockScripList = [];

  filterWatchlistScripts = [];
  bcastHandler: any;
  bcastB5Handler: any;
  selProfile: any;
  selProfileId: any;
  selProfileName: any;
  selRenameProfileName: any;
  profileScrips = [];
  profileCnt: number = 0;
  maxProfileCnt: number = 0;
  eventProfile: any;
  myStockProfile: any;
  viewPortHandler: any;
  dcViewPortScrip = new Dictionary<any>();
  viewPortSubList = [];
  viewPortUnSubList = [];
  isInitDone = false;
  dateExpression = /(\d{2}):(\d{2}):(\d{2}) (\d{4})-(\d{2})-(\d{2})/;
  @ViewChild('sliderOverLay', { static: false }) sliderOverlay: IonSlides;
  @ViewChild('watchlist', { static: false }) divWatchlist: ElementRef;
  @ViewChild('watchlistScroll1', { static: false }) divScrollContent: ElementRef;
  @ViewChild('btnWatchlist', { static: false }) btnWatchlist: IonButton;

  onScrollChanged = new Subject<any>();
  subscription: any;
  myPane: any;
  showDontMiss = false;
  showDontMissCnt = false;
  showEvents = false;
  divHeight = 379;
  userTypefilter = '';
  showExchange: boolean = false;
  exchangeScripList = [];
  showtickerCard: boolean = false;
  showaddtoWatchlist: boolean = false;
  isGuestUser: boolean = false;
  //added by vivian f
  totalPurchasingPower: any = 0;
  totalCash: any = 0;
  totalCollatral: any = 0;
  totalMargin: any = 0;
  totalBuyingPower: any = 0;
  periodicityWisefundsDetails: any = [];
  //productWisefundsDetails: any = [];
  fundsValueInText: string;
  defaultWatchKey = '';
  defaultWatchListID = '0';
  exchangeIdx = -1;
  isDontMissExists = true;

  @ViewChild('indiceTicker', { static: false }) elTicker: any;

  constructor(private navCtrl: NavController,
    private objHttpService: clsHttpService,
    private http: HttpClient,
    private menuCtrl: MenuController,
    private paramService: NavParamService,
    private localstorageservice: clsLocalStorageService,
    public popoverController: PopoverController,
    public toastProvider: ToastServicesProvider,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService,
    public alertCtrl: AlertServicesProvider,
    public dateFormatter: DatePipe,
    public modalController: ModalController,
    private transactionService: TransactionService,
    private glbEvtService: GlobalEventsService,
    private animationCtrl: AnimationController,//private Keyboard: Keyboard
  ) {
    this.viewPortHandler = this.onViewPortItemChange.bind(this);
    this.maxProfileCnt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_MAX_PROFILE_COUNT) || '10');
  }

  ngOnDestroy(): void {
    window.onresize = null;
  }

  ngOnInit() {

    try {


      this.watchListScripts = [];
      this.filterWatchlistScripts = [];
      this.isInitDone = true;
      //this.eventList=clsGlobal.EventList;
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      this.bcastB5Handler = this.receiveBestFiveResponse.bind(this);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      clsGlobal.pubsub.subscribe('B5RES', this.bcastB5Handler);

      this.menuCtrl.enable(true);//need to handle for guest mode.
      this.showInitLoader = clsGlobal.watchlistFirstInit;
      this.IsWatchListExist = clsGlobal.watchlistFirstInit;
      this.isGuestUser = clsGlobal.User.isGuestUser;



      this.loadWatchlistProfile();

      this.subscription = this.onScrollChanged.
        pipe(debounceTime(500)).
        subscribe(evt => this.viewPortHandler(evt));

      this.userTypefilter = !clsGlobal.IsGuestUser ? clsConstants.LOCAL_STORAGE_WATCHLIST_FILTER : clsConstants.LOCAL_STORAGE_GUEST_WATCHLIST_FILTER;
      if (this.isGuestUser) {
        this.toastProvider.showWithButton("All prices are delayed by 15mins. Register now to access live prices!")
      }
      this.defaultWatchKey = !clsGlobal.IsGuestUser ? clsConstants.LOCAL_STORAGE_WATCHLIST_DEFAULT_PROFILE : clsConstants.LOCAL_STORAGE_GUEST_WATCHLIST_DEFAULT_PROFILE;
      //already called on ionicViewWillEnter.
      // if (!clsGlobal.User.isGuestUser) {
      //   if (!clsGlobal.User.fundsDetails || !clsGlobal.User.fundsDetails.periodicityWisefundsDetails || !clsGlobal.User.fundsDetails.productWisefundsDetails) {
      //     this.getBalanceInfo();
      //   }
      // }
      // this.Keyboard.onKeyboardHide().subscribe(()=>{
      //   this.calcDivHeight();
      //   this.toastProvider.showAtBottom("Key Hide Event Fired.");
      // })


    } catch (error) {
     // clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  getBalanceInfo() {
    try {

     
      this.transactionService.getPeridiocityWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {
          this.periodicityWisefundsDetails = balanceData.data;
          clsGlobal.User.fundsDetails.periodicityWisefundsDetails = balanceData.data;
          //this.calculateFunds();
        }

      }, error => {
       // console.log(error)
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getBalanceInfo',error.Message,undefined,error.stack,undefined,undefined));
      });
      

      this.transactionService.getProductWiseBalanceInfo().then((balanceData: any) => {
        if (balanceData.status == 'success') {
          //this.productWisefundsDetails = balanceData.data;
          clsGlobal.User.fundsDetails.productWisefundsDetails = balanceData.data;
        }

      }, error => {
        //console.log(error)
        clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getBalanceInfo2',error.Message,undefined,error.stack,undefined,undefined))
      });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ngOnInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getBalanceInfo',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  calculateFunds() {
    try {
      this.totalPurchasingPower = 0.00;
      this.totalCash = 0.00;
      this.totalCollatral = 0.00;
      this.totalMargin = 0.00;
      this.totalBuyingPower = 0.00;

      let arrAmt = [];
      this.periodicityWisefundsDetails.forEach(element => {
        //this.totalPurchasingPower += parseFloat(element.net_available[0].nTotal);
        //this.totalCash += parseFloat(element.available.cash[0].nTotal);
        //this.totalCollatral += parseFloat(element.available.collateral[0].nTotal);
        arrAmt.push(parseFloat(element.data.filter(x => x.sDescription == 'Total Trading Power Limit')[0].nTotal));

      });

      this.totalPurchasingPower = Math.max.apply(Math, arrAmt);
      this.totalPurchasingPower = parseFloat(this.totalPurchasingPower).toFixed(2);
      // this.totalCash = parseFloat(this.totalCash).toFixed(2);
      // this.totalCollatral = parseFloat(this.totalCollatral).toFixed(2);
      // this.totalMargin = ((parseFloat(this.totalPurchasingPower) - parseFloat(this.totalCash) - parseFloat(this.totalCollatral)));
      // this.totalMargin = parseFloat(this.totalMargin).toFixed(2);
      // this.totalBuyingPower = ((parseFloat(this.totalCash) + parseFloat(this.totalCollatral) + parseFloat(this.totalMargin))).toFixed(2);
      clsGlobal.User.totalBuyingPower = this.totalPurchasingPower;// this.totalBuyingPower;
      this.kFormatter(this.totalPurchasingPower);
      clsGlobal.pubsub.publish('MENU_DYNAMIC');

    } catch (error) {
      //console.log(error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'calculateFunds',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  ngAfterViewInit() {

    try {

      this.checkForElementReder();

      // setTimeout(() => {
      //   if (this.divScrollContent != undefined) {
      //     this.divScrollContent.nativeElement.addEventListener("scroll", (event) => {
      //       if (event) {
      //         this.onScrollChanged.next(event);
      //         this.myPane.disableDrag();
      //       }
      //     });
      //   }
      //   //this.setAnimation();
      // }, 3000);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ngAfterViewInit', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'ngAfterViewInit',error.Message,undefined,error.stack,undefined,undefined));
      
    }
  }

  setAnimation() {
    try {

      const divElement: HTMLElement = document.getElementById('divWatchlistDetl');
      this.watchListPaneBottomToTop(divElement);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'setAnimation', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'setAnimation',error.Message,undefined,error.stack,undefined,undefined));
      
    }
  }

  watchListPaneBottomToTop(myElementRef: any) {

    try {

      let settings: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (5), // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (45), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (180), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          }
        },
        dragBy: ['.pane .draggable'],
        initialBreak: 'top',
        bottomClose: false,
        clickBottomOpen: false,
        lowerThanBottom: false,
        animationType: "ease",
        animationDuration: 800,
        buttonClose: false,
        showDraggable: false,
        handleKeyboard: false,
        preventClicks: true,
        //touchMoveStopPropagation:true,
        topperOverflow: false,
        freeMode: true,
        // onWillDismiss: () => {
        //   console.log("Will dismiss");
        // },
        onDidPresent: () => {

          this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_WATCHLIST_DEMO).then(demo => {
            if (demo == undefined) {
              setTimeout(() => {
                try {
                  document.getElementById('btnWatch').click();
                } catch (error) {

                }
                this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_WATCHLIST_DEMO, "1");
              }, 500);

            } else {
              this.showDontMissCnt = true;
              setTimeout(() => {
                this.myPane.moveToBreak('middle');
              }, 400);

            }
          })


          this.onScrollChanged.next(undefined);
        },

        onDrag: () => {

          let topDiv = this.divWatchlist.nativeElement.getBoundingClientRect().top;
          //console.log("Top: ", topDiv)
          if (topDiv > 90) {
            this.showDontMissCnt = false;
            this.showEvents = true;
            if (this.eventList.length == 0) {
              this.isDontMissExists = false;
            } else {
              this.isDontMissExists = true;
            }
          }

          if (topDiv < 90) {
            this.showDontMissCnt = true;
            this.showEvents = false;
          }

        },
        onDragEnd: () => {

          //console.log("onDragEnd ends");
          this.calcDivHeight();

          this.onScrollChanged.next(undefined);

        },
        onTransitionStart: () => {

          this.setDivWatchlistVisible();

        },
        onTransitionEnd: () => {
          //console.log("onTransitionEnd ends");

          this.calcDivHeight();
        }
      };
      this.myPane = new CupertinoPane(myElementRef, settings);
      this.myPane.enableDrag();
      //this.myPane.disableDrag();
      this.myPane.present({ animate: true });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'watchListPaneBottomToTop', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'watchListPaneBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  ionViewWillEnter() {

    try {

      window.onresize = (evt) => {
        //this.toastProvider.showAtBottom("Resize Event Fired. height: " + window.innerHeight);
        this.calcDivHeight();
      };

      if (!this.isInitDone) {

        this.bcastHandler = this.receiveTouchlineResponse.bind(this);
        clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);

        this.bcastB5Handler = this.receiveBestFiveResponse.bind(this);
        clsGlobal.pubsub.subscribe('B5RES', this.bcastB5Handler);

        if (this.selectedScrip != undefined) {
          this.sendB5Request(OperationType.ADD, this.selectedScrip);
        }

        if (clsGlobal.reloadWatchlist) {
          clsGlobal.reloadWatchlist = false;
          this.loadWatchlistProfile();
          //this.applySortingandFilter();
        }
        else if (this.profileList == undefined || this.profileList.length == 0 ||
          clsGlobal.userSelectedWatchlist == '' || clsGlobal.userSelectedWatchlist == undefined) {
          let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
          this.localstorageservice.getItem(watchKeyFilter).then(watchId => {

            this.defaultWatchListID = watchId || '0';
            //console.log('Default Profile ID: ', this.defaultWatchListID);
            this.setDefaultProfile();
            if (this.selProfileId != undefined && this.selProfileId != 1000 && this.selProfileId != 1001) {
              this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
                if (profileScripData != undefined) {
                  this.profileScrips = profileScripData;
                  this.loadProfileDetails();
                }
              });
            }

            if (this.selProfileId == 1001) {
              this.setMyStockList();
            }
            else if (this.selProfileId == 1000) {
              this.setWhatsHotList();
            }

          });
        }
        else if (this.profileScrips == undefined || this.profileScrips.length == 0) {
          this.loadProfileDetails();
        }
        else if (this.filterWatchlistScripts.length == 0) {

          this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
            if (profileScripData != undefined) {
              this.profileScrips = profileScripData;
              this.loadProfileDetails();
            }
          });

        }
        else {
          this.applySortingandFilter();
        }

        this.sendTouchlineRequest(OperationType.ADD, this.whatsHotScripKeyList);
        //this.sendAllSubUnsubscribeRequest(OperationType.ADD);

      }

     

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ionViewWillEnter', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'ionViewWillEnter',error.Message,undefined,error.stack,undefined,undefined));
      
    }
  }
  

  ionViewDidEnter() {
    try {
      this.userTypefilter = !clsGlobal.IsGuestUser ? clsConstants.LOCAL_STORAGE_WATCHLIST_FILTER : clsConstants.LOCAL_STORAGE_GUEST_WATCHLIST_FILTER;

      if (!clsGlobal.User.isGuestUser) {
        // if (clsGlobal.User.fundsDetails && clsGlobal.User.fundsDetails.periodicityWisefundsDetails) {
        //   this.periodicityWisefundsDetails = clsGlobal.User.fundsDetails.periodicityWisefundsDetails;
          
        //   this.calculateFunds();
        // } else {
        //   this.getBalanceInfo();
        // }

        if (clsGlobal.User.fundsDetails != undefined && clsGlobal.User.fundsDetails.productWisefundsDetails == undefined) {
          this.getBalanceInfo();
        } 

        this.populateFundsData();

      }

      this.checkForScrollDivRender();
      this.checkForIndiceTicker();
      //this.calcDivHeight();

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ionViewDidEnter', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'ionViewDidEnter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  populateFundsData(){

    if(clsGlobal.User.totalBuyingPower == undefined){
      this.transactionService.getPurchasePower().then((purchasePower:any)=>{
        clsGlobal.User.totalBuyingPower = purchasePower.data;
        this.totalPurchasingPower= purchasePower.data;
        this.kFormatter(this.totalPurchasingPower);
      }).catch(error=>{

      });
    }else{
      this.totalPurchasingPower= clsGlobal.User.totalBuyingPower;
      this.kFormatter(this.totalPurchasingPower);
    }
  }

  checkForElementReder() {
    try {

      const divElement: HTMLElement = document.getElementById('divWatchlistDetl');
      if (divElement == null) {
        setTimeout(() => {
          this.checkForElementReder();
        }, 100);
      } else {

        try {
          this.divWatchlist.nativeElement.style.visibility = "hidden";
          this.divWatchlist.nativeElement.style.top = 0;
        } catch (error) {

        }

        //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
        setTimeout(() => {
          this.setAnimation();
        }, 500);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'checkForElementReder',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForScrollDivRender() {
    try {

      //console.log("Scroll Div:", this.divScrollContent);
      if (this.divScrollContent != undefined) {
        this.divScrollContent.nativeElement.addEventListener("scroll", (event) => {
          if (event) {
            this.onScrollChanged.next(event);
            this.myPane.disableDrag();
            //console.log("Current Scroll: ", event.target.scrollTop, " Height: ", event.target.offsetHeight , "Top + Height: ", (event.target.scrollTop + event.target.offsetHeight), "Scroll Height: ",event.target.scrollHeight);
            if ((event.target.scrollTop + event.target.offsetHeight) === event.target.scrollHeight) {
              //console.log('Bottom reached');
              if (this.myPane != undefined) {
                if (this.myPane.currentBreak() != 'top') {
                  this.myPane.moveToBreak('top');
                }
              }
            }

            if ((event.target.scrollTop) === 0) {
              //console.log('Top reached');
              if (this.myPane != undefined) {
                if (this.myPane.currentBreak() != 'middle') {
                  this.myPane.moveToBreak('middle');
                  this.showDontMissCnt = true;
                  this.showEvents = false;
                }
              }
            }
          }
        });
        this.calcDivHeight();
      } else {
        setTimeout(() => {
          this.checkForScrollDivRender();
        }, 400);
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'checkForScrollDivRender',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  checkForIndiceTicker(){
    try {
      
      if (this.elTicker == undefined) {
        setTimeout(() => {
          this.checkForIndiceTicker();
        }, 100);
      } else {
        this.elTicker.ionViewWillEnter();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'checkForIndiceTicke',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setDivWatchlistVisible() {
    try {
      if (this.divWatchlist == undefined) {
        setTimeout(() => {
          this.checkForElementReder();
        }, 100);
      } else {
        this.divWatchlist.nativeElement.style.visibility = "visible";
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'setDivWatchlistVisible', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'setDivWatchlistVisible',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  //async
  setDefaultProfile() {
    try {

      let defaultProfile;

      if (clsGlobal.userSelectedWatchlist != undefined && clsGlobal.userSelectedWatchlist != "") {

        defaultProfile = this.profileList.filter((element, index, array) => {
          return element.nWatchListId == clsGlobal.userSelectedWatchlist.nWatchListId;
        });

        //console.log('Set Selected Default Profile ID: ');

      } else {

        // defaultProfile = this.profileList.filter((element, index, array) => {
        //   return element.bIsDefault == true || element.bIsDefault == "true";
        // });

        defaultProfile = this.profileList.filter((element, index, array) => {
          return element.nWatchListId == this.defaultWatchListID;
        });

        if (defaultProfile.length == 0) {
          defaultProfile = [this.profileList[0]];
        }

        //console.log('Set Non Selected Default Profile ID: ');

        this.defaultWatchListID = defaultProfile[0].nWatchListId;
        clsGlobal.userSelectedWatchlist = defaultProfile[0];
        if (defaultProfile.length > 1) {
          for (let index = 0; index < defaultProfile.length; index++) {
            const element = defaultProfile[index];
            if (element.bIsPrivate == false || element.bIsPrivate == "false") {
              defaultProfile.splice(index, 1);
              element.bIsDefault = false;
              break;
            }
          }
        }

      }

      this.selProfileId = defaultProfile[0].nWatchListId;
      this.selProfileName = defaultProfile[0].sWatchListName;
      this.selRenameProfileName = defaultProfile[0].sWatchListName;
      this.selProfile = defaultProfile[0];

      //console.log('Set Default Profile ID Inside: ',  this.selProfileId);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'setDefaultProfile', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'setDefaultProfile',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  loadProfileDetails() {
    try {

      //let iCnt = 0;
      this.watchListScripts = [];
      this.filterWatchlistScripts = [];
      //let arrScrip = [];

      for (let index = 0; index < this.profileScrips.length; index++) {
        const element = this.profileScrips[index];
        this.watchListScripts.push({
          scripDetail: element,
          LTP: "0.00",
          PercNetChange: "(0.00)",
          NetChangeInRs: "0.00",
          LTPTrend: "",
          PercNetChangeRaw: "0.00",
          hots: [],
          B5Data: {}
        });
      }

      //this.fillHoldingData();
      this.applyHoldingToWatchlist();
      this.applyEventToWatchList();
      this.applySortingandFilter();

      /*
      for (let index = 0; index < this.profileScrips.length; index++) {
        const element = this.profileScrips[index];
        let Token = element.nToken;
        let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId || element.nMarketSegmentId)
        let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

        // let valueObj: any = {};
        // valueObj.isInView = true;
        // valueObj.index = 1;
        // let scripKey: clsScripKey = new clsScripKey();
        // scripKey.MktSegId = mktSegId;
        // scripKey.token = element.nToken;
        // valueObj.scripDet = scripKey;

        arrScrip.push({ "mkt": exchange, "token": Token });


        // Storing the same in ViewPort.
        //this.dcViewPortScrip.Add(scripKey.toString(), valueObj);
        // Scrip is in view so add in subscription list
        //this.viewPortSubList.push(scripKey);

        // this.dbService.getScripByToken(exchange, Token, element.nMarketSegmentId).then(scrip => {
        //   //console.log("Scrip Found: ", scrip);
        //   if (scrip[0] != undefined) {
        //     this.watchListScripts.push({
        //       scripDetail: scrip[0],
        //       LTP: "0.00",
        //       PercNetChange: "0.00",
        //       NetChangeInRs: "0.00",
        //       LTPTrend: "",
        //       PercNetChangeRaw: "0.00",
        //       hots: [],
        //       B5Data: {}
        //     });
        //   } else {
        //     console.log("Scrip not found in sqllite: ", exchange, "--", Token);
        //   }
        //   iCnt++;
        //   if (iCnt == this.profileScrips.length) {

        //     this.fillHoldingData();
        //     this.applyEventToWatchList();
        //     this.applySortingandFilter();

        //   }
        // }, error => {
        //   console.log("unable to find scrip: ", Token, " ", exchange);
        // });

      }

      if (arrScrip.length > 0) {
        let req = { scrips: arrScrip }
        clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {
          if (scripData.status == true) {
            if (scripData != undefined && scripData.result.length > 0) {

              for (let index = 0; index < this.profileScrips.length; index++) {

                const element = this.profileScrips[index];
                let Token = element.nToken;
                let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId || element.nMarketSegmentId)
                let scripItem = scripData.result.filter(item => {
                  return mktSegId == clsTradingMethods.GetMarketSegmentID(parseInt(item.nMarketSegmentId)) &&
                    Token == item.nToken;
                })

                if (scripItem.length > 0) {
                  let selectedScripObj = clsCommonMethods.getScripObject(scripItem[0]).scripDetail;
                  if (selectedScripObj != undefined) {

                    this.watchListScripts.push({
                      scripDetail: selectedScripObj,
                      LTP: "0.00",
                      PercNetChange: "0.00",
                      NetChangeInRs: "0.00",
                      LTPTrend: "",
                      PercNetChangeRaw: "0.00",
                      hots: [],
                      B5Data: {}
                    });

                  }
                }
              }
              // for (let index = 0; index < scripData.result.length; index++) {

              //   const element = scripData.result[index];
              //   let selectedScripObj = clsCommonMethods.getScripObject(element).scripDetail;
              //   if (selectedScripObj != undefined) {

              //     this.watchListScripts.push({
              //       scripDetail: selectedScripObj,
              //       LTP: "0.00",
              //       PercNetChange: "0.00",
              //       NetChangeInRs: "0.00",
              //       LTPTrend: "",
              //       PercNetChangeRaw: "0.00",
              //       hots: [],
              //       B5Data: {}
              //     });


              //   }
              // }

              this.fillHoldingData();
              this.applyEventToWatchList();
              this.applySortingandFilter();

            } else {

              this.applySortingandFilter();
            }
          } else {
            this.applySortingandFilter();
          }

        }, error => {
          this.toastProvider.showAtBottom("Unable to fetch scrip details.")
          this.applySortingandFilter();
        })
      }

      */

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'loadProfileDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'loadProfileDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  applySortingandFilter() {
    try {
      let timeout = this.divScrollContent ? 1 : 2000;

      if (clsGlobal.User.watchlistFilter != undefined) {

        this.filterWatchlist(clsGlobal.User.watchlistFilter);
        //this.filterWatchlistScripts = this.watchListScripts;
        this.sortWatchlist(clsGlobal.User.watchlistFilter);
        //this.sendAllSubUnsubscribeRequest(OperationType.ADD);
        setTimeout(() => {
          this.viewPortHandler();
        }, timeout);

      } else {

        this.localstorageservice.getItem(this.userTypefilter).then(filter => {
          if (filter != undefined) {

            let keyFilter = clsGlobal.User.userId + "_" + this.selProfileId;
            let arrWatchFilters = JSON.parse(filter) || [];

            let selFilter = arrWatchFilters.filter(item => {
              return item.filterId == keyFilter;
            });

            this.isFilterAvailable = false;

            if (selFilter.length > 0) {
              let objSortnFilter = selFilter[0].filter;

              this.filterWatchlist(objSortnFilter);
              //this.filterWatchlistScripts = this.watchListScripts;
              this.sortWatchlist(objSortnFilter);
              //clsGlobal.User.watchlistFilter = objSortnFilter;
              if (this.filterCount > 0) {
                this.isFilterAvailable = true;
              } else {
                this.isFilterAvailable = false;
              }
            }
            else {
              this.isFilterAvailable = false;
              this.filterCount = 0;
              this.filterWatchlistScripts = this.watchListScripts;
              if (clsGlobal.watchlistFirstInit) {

                clsGlobal.watchlistFirstInit = false;
                this.showInitLoader = clsGlobal.watchlistFirstInit;
                this.IsWatchListExist = false;
              }
            }

            if (selFilter.length > 0) {
              let objSortnFilter = selFilter[0].filter;

              this.filterType = objSortnFilter.filter;
              this.selSorting = objSortnFilter.sorting;
              this.selSortingType = objSortnFilter.sortingType;
              this.filterCount = objSortnFilter.filterCount || 0;
            }

            if (this.filterCount > 0) {
              this.isFilterAvailable = true;
            } else {
              this.isFilterAvailable = false;
            }

          } else {

            this.filterType = {};
            this.selSorting = '';
            this.selSortingType = '';
            this.filterCount = 0;
            this.isFilterAvailable = false;

            this.filterWatchlistScripts = this.watchListScripts;
            if (clsGlobal.watchlistFirstInit) {

              clsGlobal.watchlistFirstInit = false;
              this.showInitLoader = clsGlobal.watchlistFirstInit;
              this.IsWatchListExist = false;
            }
          }
          //this.sendAllSubUnsubscribeRequest(OperationType.ADD);
          setTimeout(() => {
            this.viewPortHandler();
          }, timeout);
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'applySortingandFilter', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'applySortingandFilter',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  sortWatchlist(objSortCriteria) {

    try {


      if (objSortCriteria.sorting == 'symbol') {
        if (objSortCriteria.sortingType == 'ASC') {
          this.filterWatchlistScripts.sort((a, b) => a.scripDetail[objSortCriteria.sorting] > b.scripDetail[objSortCriteria.sorting] ? 1 : -1);
        }
        else if (objSortCriteria.sortingType == 'DESC') {
          this.filterWatchlistScripts.sort((a, b) => a.scripDetail[objSortCriteria.sorting] < b.scripDetail[objSortCriteria.sorting] ? 1 : -1);
        }
      }
      else if (objSortCriteria.sorting == 'ltp') {
        if (objSortCriteria.sortingType == 'ASC') {
          this.filterWatchlistScripts.sort((a, b) => parseFloat(a.LTP) > parseFloat(b.LTP) ? 1 : -1);
        }
        else if (objSortCriteria.sortingType == 'DESC') {
          this.filterWatchlistScripts.sort((a, b) => parseFloat(a.LTP) < parseFloat(b.LTP) ? 1 : -1);
        }
      }
      else if (objSortCriteria.sorting == 'netChngInRs') {
        if (objSortCriteria.sortingType == 'ASC') {
          this.filterWatchlistScripts.sort((a, b) => parseFloat(a.PercNetChangeRaw) > parseFloat(b.PercNetChangeRaw) ? 1 : -1);
        }
        else if (objSortCriteria.sortingType == 'DESC') {
          this.filterWatchlistScripts.sort((a, b) => parseFloat(a.PercNetChangeRaw) < parseFloat(b.PercNetChangeRaw) ? 1 : -1);
        }
      }

      if (clsGlobal.watchlistFirstInit) {

        clsGlobal.watchlistFirstInit = false;
        this.showInitLoader = clsGlobal.watchlistFirstInit;
        this.IsWatchListExist = false;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sortWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'sortWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  filterWatchlist(objFilterCriteria) {
    try {

      let isFilterApplied = false;
      let filterData = [];
      let eqData = [], commData = [], currData = [];
      let bseData = [], nseData = [], faoData = [];

      if (objFilterCriteria.filter.isEquity) {
        eqData = this.watchListScripts.filter(element => {
          return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSE_CASH ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_CASH ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_CASH;
        });
        isFilterApplied = true;
        //filterData = filterData.concat(...eqData);
      }

      if (objFilterCriteria.filter.isCommodity) {
        commData = this.watchListScripts.filter(element => {
          return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES || // BSE COMM
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_UCX_DERIVATIVES; // NSE COMM
        });
        //filterData = filterData.concat(...commData);
        isFilterApplied = true;
      }

      if (objFilterCriteria.filter.isCurrency) {
        currData = this.watchListScripts.filter(element => {
          return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES;
        });
        isFilterApplied = true;
        //filterData = filterData.concat(...currData);
      }

      let filterData1 = [];
      //if (objFilterCriteria.filter.isEquity) {

      if (objFilterCriteria.filter.isBSE) {
        isFilterApplied = true;
        let eqBseData = [], comBseData = [], currBseData = [];
        if (eqData.length > 0) {
          eqBseData = eqData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_CASH;
          });
          filterData = filterData.concat(...eqBseData);
        }

        if (commData.length > 0) {
          comBseData = commData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES; // BSE COMM
          });
          filterData = filterData.concat(...comBseData);
        }

        if (currData.length > 0) {
          currBseData = currData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES;
          });
          filterData = filterData.concat(...currBseData);
        }

        // else {
        //   bseData = this.watchListScripts.filter(element => {
        //     return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_CASH ||
        //       element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES ||
        //       element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES; // BSE COMM
        //   });
        // }
        if (eqBseData.length == 0 && comBseData.length == 0 && currBseData.length == 0) {


          bseData = this.watchListScripts.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_CASH ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES; // BSE COMM
          });
          filterData = filterData.concat(...bseData);

        }

        //filterData1 = filterData1.concat(...bseData);

      }

      if (objFilterCriteria.filter.isNSE) {

        isFilterApplied = true;
        let eqNseData = [], comNseData = [], currNseData = [];

        if (eqData.length > 0) {
          eqNseData = eqData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSE_CASH;
          });
          filterData = filterData.concat(...eqNseData);
        }

        if (commData.length > 0) {
          comNseData = commData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_UCX_DERIVATIVES; // BSE COMM
          });
          filterData = filterData.concat(...comNseData);
        }

        if (currData.length > 0) {
          currNseData = currData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES;
          });
          filterData = filterData.concat(...currNseData);
        }

        if (eqNseData.length == 0 && comNseData.length == 0 && currNseData.length == 0) {

          nseData = nseData = this.watchListScripts.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSE_CASH ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_UCX_DERIVATIVES; // NSE COMM
          });

          filterData = filterData.concat(...nseData);
        }


      }
      //}

      if (objFilterCriteria.filter.isFAO) {

        isFilterApplied = true;

        faoData = this.watchListScripts.filter(element => {
          return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSE_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MSX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES ||
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES || // BSE COMM
            element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_UCX_DERIVATIVES; // NSE COMM
        });

        let eqFaoData = [], comFaoData = [], currFaoData = [];

        if (objFilterCriteria.filter.isEquity) {
          eqFaoData = faoData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSE_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_DERIVATIVES;
          });
          filterData = filterData.concat(...eqFaoData);
        }

        if (objFilterCriteria.filter.isCommodity) {
          comFaoData = faoData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NCDEX_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NMCE_DERIVATIVES || // BSE COMM
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_UCX_DERIVATIVES; // NSE COMM 
          });
          filterData = filterData.concat(...comFaoData);
        }

        if (objFilterCriteria.filter.isCurrency) {
          currFaoData = faoData.filter(element => {
            return element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES ||
              element.scripDetail.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_NSX_DERIVATIVES; // NSE COMM 
          });
          filterData = filterData.concat(...currFaoData);
        }

        if (eqFaoData.length == 0 && comFaoData.length == 0 && currFaoData.length == 0) {

          filterData = filterData.concat(...faoData);
        }

      }

      if (objFilterCriteria.filter.isEquity && !objFilterCriteria.filter.isBSE && !objFilterCriteria.filter.isNSE) {
        filterData = filterData.concat(...eqData);
      }

      if (isFilterApplied) {
        this.filterWatchlistScripts = filterData;
      } else {
        this.filterWatchlistScripts = this.watchListScripts;
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'filterWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'filterWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  addScripFromLookUp() {
    this.navCtrl.navigateForward('lookup');
  }

  showFilterPage() {

    this.showOrderFilterPopup();
    return;

    let navParam: NavigationExtras = {
      queryParams: { profile: this.selProfile }
    }
    this.navCtrl.navigateForward('watchlistfilter', navParam);
  }

  async fetchEventList() {

    try {

      let userProfileList = this.profileList.filter(item => {
        return item.bIsPrivate == true
      })

      this.glbEvtService.fetchEvents().then(async data => {
        try {
          let globalEventList = []
          for (let i = 0; i < clsGlobal.EventList.length; i++) {
            if (clsGlobal.EventList[i].type == "Reco") {
              let event: any = clsGlobal.EventList[i]
              event.eventItemList = []
              this.eventList.push(event)
            }
            else {
              let event: any = clsGlobal.EventList[i]
              event.eventItemList = []
              globalEventList.push(clsGlobal.EventList[i])
            }
          }

          //JSON.parse(respData);

          for (let index = 0; index < userProfileList.length; index++) {
            await this.watchlistServ.getWatchlistProfileScrip(userProfileList[index].nWatchListId, userProfileList[index].sCreatedBy, false).then((profileScripData: any) => {
              if (profileScripData != undefined) {
                globalEventList.forEach(eventItem => {
                  profileScripData.forEach(element => {

                    if (element.scripDet.MapMktSegId == eventItem.mktid && element.scripDet.token == eventItem.token) {
                      let eventExists = this.eventList.filter((existelement) => {
                        return existelement.mktid == eventItem.mktid && existelement.token == eventItem.token;
                      });
                      if (eventExists.length == 0) {
                        this.eventList.push(eventItem);
                      }
                      else {
                        eventExists[0].eventItemList.push(eventItem.event)
                      }
                    }
                  });
                });
              }
            });
          }


          this.whatsHotScripList = [];
          this.whatsHotScripKeyList = [];
          if (this.eventList.length > 0) {

            this.eventProfile = {
              nWatchListId: 1000,
              sWatchListName: "Don't Miss",//'Whats Hot',
              bIsPrivate: "false",
              bIsDefault: "false",
              sCreatedBy: '',
              nTenantId: ''
            };

            if (this.profileList.length != 0) {

              let evtProfile = this.profileList.filter((element, index, array) => {
                return element.nWatchListId == 1000;
              });

              if (evtProfile.length == 0)
                this.profileList.push(this.eventProfile);

            } else {
              this.profileList.push(this.eventProfile);
            }

            this.profileCnt = this.profileList.length;
            this.applyEventToWatchList();

            for (let index = 0; index < this.eventList.length; index++) {

              const element = this.eventList[index];
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.MktSegId = parseInt(element.mktid);
              scripKey.token = (element.token);

              //Check for duplicate scrip
              let lstScrip = this.whatsHotScripList.filter(scrip => {
                return scrip.nMarketSegmentId == scripKey.MapMktSegId && scrip.nToken == scripKey.token;
              })

              if (lstScrip.length == 0) {

                this.whatsHotScripList.push({
                  nWatchListId: 1000,
                  nMarketSegmentId: parseInt(element.mktid),
                  nToken: parseInt(element.token)
                });

                this.whatsHotScripKeyList.push(scripKey);
              }

            }

            let arrScrip = [];
            this.whatsHotScripList = [];

            for (let index = 0; index < this.whatsHotScripKeyList.length; index++) {
              const element = this.whatsHotScripKeyList[index];
              let Token = element.token;
              let mktSegId = (element.MktSegId)
              let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

              arrScrip.push({ "mkt": exchange, "token": Token });
            }

            if (arrScrip.length > 0) {

              let req = { scrips: arrScrip };
              clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

                if (scripData.status == true) {
                  if (scripData != undefined && scripData.result.length > 0) {

                    for (let index = 0; index < scripData.result.length; index++) {
                      const element = scripData.result[index];
                      let selectedScripObj = clsCommonMethods.getScripObject(element).scripDetail;
                      if (selectedScripObj != undefined) {
                        this.whatsHotScripList.push(selectedScripObj);
                      }
                    }

                    clsGlobal.EventListScrip = this.whatsHotScripList;

                    if (this.selProfileId == 1000) {
                      this.profileScrips = this.whatsHotScripList;
                      this.loadProfileDetails();
                    }

                    this.sendTouchlineRequest(OperationType.ADD, this.whatsHotScripKeyList);
                  }
                }

              }, error => {
                this.toastProvider.showAtBottom("Unable to fetch whats hot scrip details.");
              });

            }

            if (this.eventList.length == 0) {
              this.isDontMissExists = false;
            } else {
              this.isDontMissExists = true;
            }

          }

        } catch (error) {
          //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'fetchEventList Response', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'fetchEventList',error.Message,undefined,error.stack,undefined,undefined));
        }
      }, error => {
        this.toastProvider.showAtBottom("Error in Fetch Event: " + error);
      })
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'fetchEventList', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'fetchEventList2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  applyEventToWatchList() {
    try {

      clsGlobal.EventList.forEach(eventItem => {
        this.watchListScripts.forEach(element => {
          if (element.scripDetail.scripDet.MapMktSegId == parseInt(eventItem.mktid) && element.scripDetail.scripDet.token == parseInt(eventItem.token)) {
            if (!element.hots.includes(eventItem))
              element.hots.push(eventItem);
          }
        });
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'applyEventToWatchList', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'applyEventToWatchList',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  /**
     * To get Stock View Scrip to display in My Stock Watchlist
     */
  fillStockViewScrip() {
    try {

      if (clsGlobal.User.Holding.length > 0) {

        this.profileList.push({
          nWatchListId: 1001,
          sWatchListName: 'My Holdings',
          bIsPrivate: "false",
          bIsDefault: "false",
          sCreatedBy: '',
          nTenantId: ''
        });

        this.profileCnt = this.profileList.length;
        if (this.myStockScripList.length == 0) {
          if (clsGlobal.User.HoldingScrips.length > 0) {
            this.myStockScripList = clsGlobal.User.HoldingScrips;
          } else {
            this.fillHoldingData();
          }
        }

      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'getStockViewScrip', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getStockViewScrip',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  fillHoldingData() {
    try {

      if (clsGlobal.User.Holding != undefined) {

        this.myStockScripList = [];
        for (let i = 0; i < clsGlobal.User.Holding.length; i++) {
          let mapMktSegId = parseInt(clsGlobal.User.Holding[i].nMarketSegmentId);

          this.myStockScripList.push({
            nWatchListId: 1001,
            nMarketSegmentId: clsTradingMethods.GetMarketSegmentID(mapMktSegId),
            nToken: parseInt(clsGlobal.User.Holding[i].nToken)
          })

          let holdingScrip = this.watchListScripts.filter(item => {
            return item.scripDetail.scripDet.MapMktSegId == mapMktSegId &&
              item.scripDetail.scripDet.token == clsGlobal.User.Holding[i].nToken;
          })

          if (holdingScrip.length > 0) {
            //let holdingData: any = {};
            holdingScrip[0].holding = clsGlobal.User.Holding[i];
          }
        }

        let arrScrip = [];

        for (let index = 0; index < this.myStockScripList.length; index++) {
          const element = this.myStockScripList[index];
          let Token = element.nToken;
          let mktSegId = (element.nMarketSegmentId)
          let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

          arrScrip.push({ "mkt": exchange, "token": Token });
        }

        this.myStockScripList = [];
        if (arrScrip.length > 0) {

          let req = { scrips: arrScrip };

          clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

            if (scripData.status == true) {
              if (scripData != undefined && scripData.result.length > 0) {

                for (let index = 0; index < scripData.result.length; index++) {

                  const element = scripData.result[index];

                  let selectedScripObj = clsCommonMethods.getScripObject(element).scripDetail;
                  if (selectedScripObj != undefined) {
                    this.myStockScripList.push(selectedScripObj);
                  }
                }

                clsGlobal.User.HoldingScrips = this.myStockScripList;

              }

              // if (this.selProfileId == 1000) {
              //   this.profileScrips = this.myStockScripList;
              //   this.loadProfileDetails();
              // }
            }

          }, error => {
            this.toastProvider.showAtBottom("Unable to fetch whats hot scrip details.");
          });

        }

      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'fillHoldingData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'fillHoldingData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  applyHoldingToWatchlist() {
    if (clsGlobal.User.Holding != undefined) {

      //this.myStockScripList = [];
      for (let i = 0; i < clsGlobal.User.Holding.length; i++) {
        let mapMktSegId = parseInt(clsGlobal.User.Holding[i].nMarketSegmentId);

        let holdingScrip = this.watchListScripts.filter(item => {
          return item.scripDetail.scripDet.MapMktSegId == mapMktSegId &&
            item.scripDetail.scripDet.token == clsGlobal.User.Holding[i].nToken;
        })

        if (holdingScrip.length > 0) {
          //let holdingData: any = {};
          holdingScrip[0].holding = clsGlobal.User.Holding[i];
        }
      }
    }
  }

  showOverlayCarasoul(scripItem, index) {
    try {

      // if (clsGlobal.User.isGuestUser) {
      //   return;
      // }

      this.showOverlay = !this.showOverlay;
      //console.log(this.selectedScrip)
      if (scripItem != undefined) {
        if (index == 0) {
          // let currScrip: clsScrip = new clsScrip();
          // currScrip.scripDet.MktSegId = scripItem.scripDetail.scripDet.MktSegId;
          // currScrip.scripDet.token = scripItem.scripDetail.token;
          this.selectedScrip = scripItem.scripDetail;//  currScrip;// JSON.stringify(scripobject);
          this.sendB5Request(OperationType.ADD, this.selectedScrip);
        }
        setTimeout(() => { this.sliderOverlay.slideTo(index, 1); }, 10)
      } else {
        //this.selectedScrip = scripItem.scripDetail;// JSON.stringify(scripobject);
        this.sendB5Request(OperationType.REMOVE, this.selectedScrip);
        this.selectedScrip = undefined;
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showOverlayCarasoul', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'showOverlayCarasoul',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async scripInfo(item, fromOverlay) {
    try {
      if (item.scripDetail == undefined) {
        let Token = item.token;
        let mktSegId = clsTradingMethods.GetMarketSegmentID(item.mktid)
        let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

        let req = { scrips: [{ "mkt": exchange, "token": Token }] };

        await clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

          if (scripData.status == true) {
            if (scripData != undefined && scripData.result.length > 0) {
              for (let index = 0; index < scripData.result.length; index++) {
                const element = scripData.result[index];
                item.scripDetail = clsCommonMethods.getScripObject(element).scripDetail;
              }
            }
            this.paramService.myParam = item.scripDetail;// clsCommonMethods.getScripObjectForWatchList(item);
            this.navCtrl.navigateForward('scripinfo');
          } else {
            console.log("Unable to fetch scrip details: ", Token, " ", exchange);
            return;
          }
        });
      }
      else {
        if (fromOverlay) {
          if (this.selectedScrip != undefined) {
            this.paramService.myParam = this.selectedScrip;
          } else {
            this.paramService.myParam = item.scripDetail;
          }

        } else {
          this.paramService.myParam = item.scripDetail;// clsCommonMethods.getScripObjectForWatchList(item);
        }
        this.navCtrl.navigateForward('scripinfo');

      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'scripInfo', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'scripInfo',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  async showOrderEntry(side, item) {
    try {

      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }

      if (item.scripDetail == undefined) {
        let Token = item.token;
        let mktSegId = clsTradingMethods.GetMarketSegmentID(item.mktid)
        let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

        let req = { scrips: [{ "mkt": exchange, "token": Token }] };

        await clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

          if (scripData.status == true) {
            if (scripData != undefined && scripData.result.length > 0) {
              for (let index = 0; index < scripData.result.length; index++) {
                const element = scripData.result[index];
                item.scripDetail = clsCommonMethods.getScripObject(element).scripDetail;
              }
            }
          } else {
            console.log("Unable to fetch scrip details: ", Token, " ", exchange);
            return;
          }

        });

        // await this.dbService.getScripByToken(exchange, Token, item.mktid).then(scrip => {
        //   //console.log("Scrip Found: ", scrip);
        //   if (scrip[0] != undefined) {
        //     item.scripDetail = scrip[0]

        //   } else {
        //     console.log("Scrip not found in sqllite: ", exchange, "--", Token);
        //   }

        // }, error => {
        //   console.log("unable to find scrip: ", Token, " ", exchange);
        // });

      }
      let SegmentId = item.scripDetail.scripDet.MktSegId;//item.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      //this.showPopUpOE = !this.showPopUpOE;
      /*
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = item.scripDetail.scripDet.MktSegId;
      currScrip.scripDet.token = item.scripDetail.token;
      currScrip.symbol = item.scripDetail.symbol;
      currScrip.Series = item.scripDetail.series;
      currScrip.Series = item.scripDetail.series;
      currScrip.InstrumentName = item.scripDetail.instrument;
      currScrip.ExpiryDate = item.scripDetail.expiry;
      currScrip.StrikePrice = item.scripDetail.sp || "-1";
      currScrip.OptionType = item.scripDetail.ot || "NA";
      currScrip.MarketLot = item.scripDetail.ls || 1;
      currScrip.PriceTick = item.scripDetail.ts || 1;
      */

      if (parseInt(item.scripDetail.Spread) == 1) {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.scripDetl = item.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.paramService.myParam = objOEFormDetail;
        this.navCtrl.navigateForward('spread-orderentry');
      }
      else {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = side == 'B' ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;
        objOEFormDetail.scripDetl = item.scripDetail;//currScrip;
        //objOEFormDetail.exchOrderNo
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        //this.selectedScrip = objOEFormDetail;
        this.paramService.myParam = objOEFormDetail;
        this.navCtrl.navigateForward('orderentry');
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showOrderEntry', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'showOrderEntry',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  createWatchList() {
    this.showWatchListSelection = false;
    if (this.profileCnt >= this.maxProfileCnt) {
      this.toastProvider.showAtBottom("Maximum 7 watchlist allowed.");
      return;
    }
    this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING);
  }

  slideOpts = {
    initialSlide: 0,
    speed: 40
  };

  scrollme(item, $event) {

    try {


      //console.log($event.target.scrollTop);
      if ($event.target.scrollTop > 40) {

        /*
        let currScrip: clsScrip = new clsScrip();
        currScrip.scripDet.MktSegId = item.scripDetail.scripDet.MktSegId;
        currScrip.scripDet.token = item.scripDetail.scripDet.token;
        currScrip.symbol = item.scripDetail.symbol;
        currScrip.Series = item.scripDetail.Series;
        currScrip.InstrumentName = item.scripDetail.InstrumentName;
        currScrip.ExpiryDate = item.scripDetail.ExpiryDate;
        currScrip.StrikePrice = item.scripDetail.StrikePrice || "-1";
        currScrip.OptionType = item.scripDetail.OptionType || "NA";
        currScrip.MarketLot = item.scripDetail.MarketLot || 1;
        currScrip.PriceTick = item.scripDetail.PriceTick || 1;
        this.paramService.myParam = currScrip;//item;
        */
        this.paramService.myParam = this.selectedScrip; // item.scripDetail;// 
        this.navCtrl.navigateForward('scripinfo');
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'scrollme', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'scrollme',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  showPopUpOrderEntry(scripobject) {

    try {

      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }

      // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
      let SegmentId = scripobject.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }


      /*
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = scripobject.scripDetail.scripDet.MktSegId;
      currScrip.scripDet.token = scripobject.scripDetail.token;
      currScrip.symbol = scripobject.scripDetail.symbol;
      currScrip.Series = scripobject.scripDetail.series;
      currScrip.Series = scripobject.scripDetail.series;
      currScrip.InstrumentName = scripobject.scripDetail.instrument;
      currScrip.ExpiryDate = scripobject.scripDetail.expiry;
      currScrip.StrikePrice = scripobject.scripDetail.sp || "-1";
      currScrip.OptionType = scripobject.scripDetail.ot || "NA";
      currScrip.MarketLot = scripobject.scripDetail.ls || 1;
      currScrip.PriceTick = scripobject.scripDetail.ts || 1;
      */
      if (parseInt(scripobject.scripDetail.Spread) == 1) {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.scripDetl = scripobject.scripDetail;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
        this.paramService.myParam = objOEFormDetail;
        this.navCtrl.navigateForward('spread-orderentry');
      }
      else {
        let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
        objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
        objOEFormDetail.buyQty = 1;
        objOEFormDetail.sellQty = 1;
        objOEFormDetail.orderQty = 1;

        objOEFormDetail.scripDetl = scripobject.scripDetail;//currScrip;
        objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;

        this.selectedScrip = objOEFormDetail;
        //Uncomment Below to open order entry popup, in same page
        this.showPopUpOE = !this.showPopUpOE;
      }

      //this.paramService.myParam = objOEFormDetail;
      //this.navCtrl.navigateForward('orderentry');

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showPopUpOrderEntry', error);
    }

  }

  receiveMessage($event) {
    this.showPopUpOE = !$event.closePopUp;
    this.showFullMode = false;
    this.populateFundsData();
  }

  menuToggle() {
    this.menuCtrl.toggle(); //Add this method to your button click function
  }
  setAlert(item) {
    try {

      /*
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = item.scripDetail.scripDet.MktSegId;
      currScrip.scripDet.token = item.scripDetail.token;
      currScrip.symbol = item.scripDetail.symbol;
      currScrip.Series = item.scripDetail.series;
      currScrip.Series = item.scripDetail.series;
      currScrip.InstrumentName = item.scripDetail.instrument;
      currScrip.ExpiryDate = item.scripDetail.expiry;
      currScrip.StrikePrice = item.scripDetail.sp || "-1";
      currScrip.OptionType = item.scripDetail.ot || "NA";
      currScrip.MarketLot = item.scripDetail.ls || 1;
      currScrip.PriceTick = item.scripDetail.ts || 1;
      
      this.paramService.myParam = currScrip;
      */

      this.paramService.myParam = item.scripDetail;
      this.navCtrl.navigateForward("setalerts");
    } catch (error) {
      console.log("Unable to open set alert page." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'setAlert',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  showAdvanceChart(item) {
    try {
      /*
      let currScrip: clsScrip = new clsScrip();
      currScrip.scripDet.MktSegId = item.scripDetail.scripDet.MktSegId;
      currScrip.scripDet.token = item.scripDetail.token;
      currScrip.symbol = item.scripDetail.symbol;
      currScrip.Series = item.scripDetail.series;
      currScrip.Series = item.scripDetail.series;
      currScrip.InstrumentName = item.scripDetail.instrument;
      currScrip.ExpiryDate = item.scripDetail.expiry;
      currScrip.StrikePrice = item.scripDetail.sp || "-1";
      currScrip.OptionType = item.scripDetail.ot || "NA";
      currScrip.MarketLot = item.scripDetail.ls || 1;
      currScrip.PriceTick = item.scripDetail.ts || 1;
      //this.selectedScrip = currScrip;//scripItem.scripDetail;// JSON.stringify(scripobject);
      this.paramService.myParam = currScrip;// clsCommonMethods.getScripObjectForWatchList(item);
      */
      this.paramService.myParam = item.scripDetail;
      this.navCtrl.navigateForward("advance-chart-iq");
    } catch (error) {
      //console.log("Unable to open set chart page." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'showAdvanceChart',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  showContextMenu() {
    this.showContext = !this.showContext;
  }
  showWatchListSelectionMenu() {
    this.showWatchListSelection = !this.showWatchListSelection;
  }
  addFunds() {
    this.navCtrl.navigateForward('fundsadd');
  }

  availableFunds() {
    this.navCtrl.navigateForward('fundsavailable');
  }

  async saveDefaultProfile(profile) {
    try {

      if (!profile) {
        profile = this.selProfile;
      }

      // if (profile.nWatchListId == this.selProfileId) {
      //   this.toastProvider.showAtBottom("Atleast 1 default profile required.");
      //   return;
      // }


      let isDefault = false;
      if (profile.bIsDefault.toString() == "false") {
        isDefault = true;
        //profile.bIsDefault = true;
      } else {
        isDefault = false;
        //profile.bIsDefault = false;
      }

      let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
      let defWatchId = await this.localstorageservice.getItem(watchKeyFilter);
      if (!isDefault) {

        if (profile.nWatchListId == defWatchId) {
          this.toastProvider.showAtBottom("Atleast 1 default profile required.");
          return;
        }

      }

      this.defaultWatchListID = profile.nWatchListId;
      this.localstorageservice.setItem(watchKeyFilter, profile.nWatchListId);

      this.toastProvider.showWithUndoButton("This watchlist marked as default watchlist.", () => {

        this.defaultWatchListID = defWatchId;
        this.localstorageservice.setItem(watchKeyFilter, defWatchId);

        profile.bIsDefault = isDefault;
        // for (let index = 0; index < this.profileList.length; index++) {
        //   const objProfile = this.profileList[index];
        //   if (objProfile.nWatchListId != profile.nWatchListId) {
        //     objProfile.bIsDefault = false;
        //   }
        // }
        console.log("Undone Default Watchlist ID: ", this.defaultWatchListID);

      }, "Undo", 3000);

      profile.bIsDefault = isDefault;
      this.showWatchListSelectionMenu();
      console.log("Default Watchlist ID: ", this.defaultWatchListID);



    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'saveDefaultProfile', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'saveDefaultProfile',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  loadWatchlistProfile() {

    try {

      this.watchlistServ.getWatchlistProfile().then((profileData: any) => {
        if (!profileData) {
          if (!clsGlobal.watchlistSyncDone) {

            const listener = Hub.listen("datastore", hubData => {

              if (hubData.payload.event === "ready") {
                listener();
                clsGlobal.watchlistSyncDone = true;
                setTimeout(() => {
                  this.loadWatchlistProfile();
                }, 500);
              }

            });

          } else {


            this.fetchEventList();

            if (!clsGlobal.User.isGuestUser)
              this.getHoldingsData();

            if (!clsGlobal.User.isGuestUser) {
              if (clsGlobal.watchlistFirstInit) {
                this.navCtrl.navigateForward('/' + clsConstants.C_S_PAGE_ROUTE_CREATE_WATCHLIST_EXISTING);
              }
            }

            this.profileCnt = this.profileList.length;
            if (this.profileCnt == 0) {

            }

            let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
            this.localstorageservice.getItem(watchKeyFilter).then(watchId => {

              this.defaultWatchListID = watchId || '0';
              //console.log('Default Profile ID: ', this.defaultWatchListID);
              this.setDefaultProfile();
              if (this.selProfile != undefined && this.selProfileId != 1000 && this.selProfileId != 1001) {
                this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
                  if (profileScripData != undefined) {
                    this.profileScrips = profileScripData;
                    this.loadProfileDetails();
                  } else {

                    if (clsGlobal.watchlistFirstInit) {
                      clsGlobal.watchlistFirstInit = false;
                      this.showInitLoader = clsGlobal.watchlistFirstInit;
                      this.IsWatchListExist = false;
                    }
                  }
                });
              }

              if (this.selProfileId == 1001) {
                this.setMyStockList();
              }
              else if (this.selProfileId == 1000) {
                this.setWhatsHotList();
              }

            });
          }

        }
        else {

          // this.profileList = profileData.filter((profileScrip, index, array) => {
          //   return profileScrip.nTenantId != '';
          // });

          this.profileList = [];
          for (let index = 0; index < profileData.length; index++) {
            const element = profileData[index];

            let watchProfile = {
              nWatchListId: element.nWatchListId,
              sWatchListName: element.sWatchListName,
              bIsPrivate: element.bIsPrivate,//"false",
              bIsDefault: element.bIsDefault,//"false",
              sCreatedBy: element.sUserId,
              nTenantId: element.sTenantId
            };
            this.profileList.push(watchProfile);

          }
          //this.profileList = profileData;

          this.fillStockViewScrip();

          this.eventProfile = {
            nWatchListId: 1000,
            sWatchListName: "Don't Miss",//Whats Hot
            bIsPrivate: "false",
            bIsDefault: "false",
            sCreatedBy: '',
            nTenantId: ''
          };

          this.profileList.push(this.eventProfile);
          this.profileCnt = this.profileList.length;

          if (this.whatsHotScripList.length == 0) {
            // if (clsGlobal.EventListScrip.length > 0) {
            //   this.whatsHotScripList = clsGlobal.EventListScrip;
            // } else {
            this.fetchEventList();
            //}
          }

          if (!clsGlobal.User.isGuestUser && (clsGlobal.User.Holding == undefined
            || clsGlobal.User.Holding.length == 0))
            this.getHoldingsData();

          let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
          this.localstorageservice.getItem(watchKeyFilter).then(watchId => {

            this.defaultWatchListID = watchId || '0';
            this.setDefaultProfile();

            if (this.selProfileId != undefined && this.selProfileId != 1000 && this.selProfileId != 1001) {
              this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
                if (profileScripData != undefined) {
                  this.profileScrips = profileScripData;
                  this.loadProfileDetails();
                }
              });
            }

            if (this.selProfileId == 1001) {
              this.setMyStockList();
            }
            else if (this.selProfileId == 1000) {
              this.setWhatsHotList();
            }

          });

        }

      }, error => {
        console.log("Error in loading watchlist data5 : " + error);
      });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'loadWatchlistProfile', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'loadWatchlistProfile',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setMyStockList() {
    if (this.myStockScripList.length == 0) {
      setTimeout(() => {
        this.setMyStockList();
      }, 300);
    } else {
      this.profileScrips = this.myStockScripList;
      this.loadProfileDetails();
    }
  }

  setWhatsHotList() {
    if (this.whatsHotScripList.length == 0) {
      setTimeout(() => {
        this.setWhatsHotList();
      }, 300);
    } else {
      this.profileScrips = this.whatsHotScripList;
      this.loadProfileDetails();
    }
  }

  /**
     * send request for broadcast
     * @param opType
     * @param scripList
     */
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sendTouchlineRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'sendTouchlineRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
     * Receive broadcast and bind to html
     * @param objMultiTLResp
     */
  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      if (objMultiTLResp != null && this.filterWatchlistScripts != undefined) {
        //
        for (let i = 0; i < this.filterWatchlistScripts.length; i++) {

          if (
            this.filterWatchlistScripts[i].scripDetail.scripDet.MktSegId == objMultiTLResp.Scrip.MktSegId &&
            this.filterWatchlistScripts[i].scripDetail.scripDet.token == objMultiTLResp.Scrip.token) {

            //console.log(objMultiTLResp);

            if (this.filterWatchlistScripts[i].LTP > objMultiTLResp.LTP) {
              this.filterWatchlistScripts[i].LTPChangeCss = "sell-ltp-change";
            }
            else if (this.filterWatchlistScripts[i].LTP < objMultiTLResp.LTP) {
              this.filterWatchlistScripts[i].LTPChangeCss = "buy-ltp-change";
            }
            else {
              this.filterWatchlistScripts[i].LTPChangeCss = "";
            }
            //if(this.filterWatchlistScripts[i].scripDetail.scripDet.token=="26000")
            //console.log(this.filterWatchlistScripts[i].LTP +'--'+objMultiTLResp.LTP);

            this.filterWatchlistScripts[i].LTP = objMultiTLResp.LTP;

            // if (this.holdingdata.length > 0) {
            //   this.filterWatchlistScripts[i].totalFreeQuantity = this.holdingdata[0].TOTALFREEQUANTITY;
            //   this.filterWatchlistScripts[i].bShowHolding = true;
            // }
            // else {
            //   this.filterWatchlistScripts[i].totalFreeQuantity = "0"
            //   this.filterWatchlistScripts[i].bShowHolding = false;
            // }

            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');

            this.filterWatchlistScripts[i].NetChangeInRs = arrNetChange[0];
            this.filterWatchlistScripts[i].PercNetChange = arrNetChange[1];
            this.filterWatchlistScripts[i].LTPTrend = arrNetChange[2];
            this.filterWatchlistScripts[i].PercNetChangeRaw = arrNetChange[3];

            this.filterWatchlistScripts[i].BuyPrice = objMultiTLResp.BuyPrice;
            this.filterWatchlistScripts[i].BuyQty = objMultiTLResp.BuyQty;
            this.filterWatchlistScripts[i].SellPrice = objMultiTLResp.SellPrice;
            this.filterWatchlistScripts[i].SellQty = objMultiTLResp.SellQty;
            //this.filterWatchlistScripts[i].Volume = this.numbertoString(objMultiTLResp.Volume);
            //this.filterWatchlistScripts[i].HeatMapClass = this.getChangeInRsForHeatmap(arrNetChange[1], arrNetChange[2])
            if (this.filterWatchlistScripts[i].holding != undefined) {
              let buyAvgPrice = this.filterWatchlistScripts[i].holding.nBuyAvgPrice * this.filterWatchlistScripts[i].holding.TOTALFREEQUANTITY;
              let LTP = parseFloat(objMultiTLResp.LTP) * this.filterWatchlistScripts[i].holding.TOTALFREEQUANTITY;
              //let profitLoss = buyAvgPrice - LTP;
              let arrNetChangePNL = clsTradingMethods.getChangeInRs(buyAvgPrice.toString(), LTP.toFixed(2), objMultiTLResp.PriceFormat, false, 'uptrend');

              this.filterWatchlistScripts[i].holding.PNL = arrNetChangePNL[0];
              this.filterWatchlistScripts[i].holding.PNLPer = arrNetChangePNL[1];
              this.filterWatchlistScripts[i].holding.PNLTrend = arrNetChangePNL[2];
            }

            break;

          }
        }
      }

      for (let index = 0; index < this.eventList.length; index++) {
        const element = this.eventList[index];
        if (
          parseInt(element.mktid) == objMultiTLResp.Scrip.MktSegId &&
          (element.token) == objMultiTLResp.Scrip.token) {

          element.LTP = objMultiTLResp.LTP;
          let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');

          element.NetChangeInRs = arrNetChange[0];
          element.PercNetChange = arrNetChange[1];
          element.LTPTrend = arrNetChange[2];
          element.PercNetChangeRaw = arrNetChange[3];

          //break;
        }
      }

    }
    catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'receiveTouchlineResponse', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'receiveTouchlineResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
    * Receive b5 broadcast and bind to html
    * @param objMultiTLResp
    */
  receiveBestFiveResponse(objB5Resp: clsBestFiveResponse) {
    try {
      if (objB5Resp != null && this.filterWatchlistScripts != undefined) {

        if (this.selectedScrip != undefined && this.selectedScrip.scripDet != undefined) {
          if (this.selectedScrip.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
            this.selectedScrip.scripDet.token == objB5Resp.Scrip.token) {

            let scrip = [];

            scrip = this.filterWatchlistScripts.filter((scripItem) => {
              return scripItem.scripDetail.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
                scripItem.scripDetail.scripDet.token == objB5Resp.Scrip.token;
            });

            if (scrip.length == 0 && this.selectedScrip.InstrumentName == "EQUITIES") {
              scrip = this.filterWatchlistScripts.filter((scripItem) => {
                return scripItem.scripDetail.symbol == this.selectedScrip.symbol && scripItem.scripDetail.InstrumentName == "EQUITIES";
              });
            }

            // if (this.selectedScrip.InstrumentName == "EQUITIES") {
            //   scrip = this.filterWatchlistScripts.filter((scripItem) => {
            //     return scripItem.scripDetail.symbol == this.selectedScrip.symbol && scripItem.scripDetail.InstrumentName == "EQUITIES";
            //   })
            // } else {
            //   scrip = this.filterWatchlistScripts.filter((scripItem) => {
            //     return scripItem.scripDetail.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
            //       scripItem.scripDetail.scripDet.token == objB5Resp.Scrip.token;
            //   })
            // }

            if (scrip.length > 0) {
              ////CODE TO HISTOGRAM start BY Omprakash on 5th march.
              let bidSum = 0;
              let askSum = 0;
              let _B5Data = objB5Resp.BestFiveData;

              for (let i = 0, len = _B5Data.length; i < len; i++) {
                if (_B5Data[i].sBidQty != undefined && _B5Data[i].sBidQty != '-' && _B5Data[i].sBidQty != 0)
                  bidSum = bidSum + parseInt(_B5Data[i].sBidQty);

                if (_B5Data[i].sAskQty != undefined && _B5Data[i].sAskQty != '-' && _B5Data[i].sAskQty != 0)
                  askSum = askSum + parseInt(_B5Data[i].sAskQty);
              }
              for (let i = 0, len = _B5Data.length; i < len; i++) {
                objB5Resp.BestFiveData[i].sBidPer = this.calculateHistogram(bidSum, objB5Resp.BestFiveData[i].sBidQty);
                objB5Resp.BestFiveData[i].sAskPer = this.calculateHistogram(askSum, objB5Resp.BestFiveData[i].sAskQty);
              }
              //CODE TO HISTOGRAM ENDS
              //TOTAL BID ASK QTY PERCENTAGE
              //this.B5Data.valueHasMutated();
              //let totalBidQty = (objB5Resp.TotBuyQty == '' ? '-' : objB5Resp.TotBuyQty).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              //let totalAskQty = (objB5Resp.TotSellQty == '' ? '-' : objB5Resp.TotSellQty).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              let totalBidQty = (objB5Resp.TotBuyQty == '' ? '-' : objB5Resp.TotBuyQty).toString();
              let totalAskQty = (objB5Resp.TotSellQty == '' ? '-' : objB5Resp.TotSellQty).toString();

              scrip[0].B5Data = objB5Resp;

              let arrNetChange = clsTradingMethods.getChangeInRs(objB5Resp.LTP, objB5Resp.ClosePrc, objB5Resp.PriceFormat, false, 'uptrend');

              scrip[0].B5Data.NetChangeInRs = arrNetChange[0];
              scrip[0].B5Data.PercNetChange = arrNetChange[1];
              scrip[0].B5Data.LTPTrend = arrNetChange[2];
              scrip[0].B5Data.PercNetChangeRaw = arrNetChange[3];

              //Now calulcate percentage.
              if (totalAskQty != '-' && totalBidQty != '-') {
                let _totalQty = parseInt(totalAskQty) + parseInt(totalBidQty);
                scrip[0].B5Data.totalBidQtyPer = ((parseInt(totalBidQty) / _totalQty) * 100).toFixed(2);
                scrip[0].B5Data.totalAskQtyPer = ((parseInt(totalAskQty) / _totalQty) * 100).toFixed(2);
                //we will calculate qty percent 
              }
              else {
                scrip[0].B5Data.totalBidQtyPer = "";
                scrip[0].B5Data.totalAskQtyPer = "";
              }

              if (scrip[0].holding != undefined) {
                let buyAvgPrice = scrip[0].holding.nBuyAvgPrice * scrip[0].holding.TOTALFREEQUANTITY;
                let LTP = parseFloat(objB5Resp.LTP) * scrip[0].holding.TOTALFREEQUANTITY;
                //let profitLoss = buyAvgPrice - LTP;
                let arrNetChange = clsTradingMethods.getChangeInRs(buyAvgPrice.toString(), LTP.toFixed(2), objB5Resp.PriceFormat, false, 'uptrend');

                scrip[0].holding.PNL = arrNetChange[0];
                scrip[0].holding.PNLPer = arrNetChange[1];
                scrip[0].holding.PNLTrend = arrNetChange[2];
              }
            }
          }
        }
      }
    } catch (error) {
      //this.toastCtrl.showAtBottom("" + error.message);
      //console.log("error in B5 watchlist page." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'receiveBestFiveResponse',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  //calculate Histogram for overlay.
  calculateHistogram(sum: any, qty: number) {
    try {
      let histovalue = (Math.round(((qty * 100) / sum) * 100) / 100).toFixed(2);
      //console.log(histovalue);
      return histovalue;
    } catch (error) {
      //console.log("Error in histor calculation ." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'calculateHistogram',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  formatDisplayDate(sDate, expression, sFormat) {
    let _FormattedDate = "";
    try {
      if (sDate != undefined && sDate != "") {
        let dateString = sDate;
        let reggie = expression;
        let dateArray = reggie.exec(dateString);
        let dateObject = new Date(
          +dateArray[4],
          +dateArray[5] - 1, // Careful, month starts at 0!
          +dateArray[6],
          +dateArray[1],
          +dateArray[2],
          +dateArray[3]
        );

        if (sFormat == undefined) {
          _FormattedDate = this.dateFormatter.transform(
            dateObject,
            "dd/MM/yyyy HH:mm:ss"
          );
        } else {
          _FormattedDate = this.dateFormatter.transform(dateObject, sFormat);
        }
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'formatDisplayDate', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'formatDisplayDate',error.Message,undefined,error.stack,undefined,undefined));
    }
    return _FormattedDate;
  }

  onProfileChange(profile) {
    try {


      this.selProfileId = profile.nWatchListId;
      this.selProfileName = profile.sWatchListName;
      this.selRenameProfileName = profile.sWatchListName;
      this.selProfile = profile;
      clsGlobal.userSelectedWatchlist = profile;
      this.showWatchListSelection = false;
      this.filterWatchlistScripts = [];
      this.watchListScripts = [];
      this.sendAllSubUnsubscribeRequest(OperationType.REMOVE);
      this.dcViewPortScrip.Clear();
      //this.viewPortSubUnsubscribeRequest();

      if (this.selProfileId == 1000) {  // whats hot ID
        //if (profileScripData != undefined) {
        this.profileScrips = this.whatsHotScripList;
        this.loadProfileDetails();
        //}
      }
      else if (this.selProfileId == 1001) {  // Myholding
        //if (profileScripData != undefined) {
        this.profileScrips = this.myStockScripList;
        this.loadProfileDetails();
        //}
      } else {
        this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
          if (profileScripData != undefined) {
            this.profileScrips = profileScripData;
            this.loadProfileDetails();
          }
        });
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'onProfileChange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'onProfileChange',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  onDeleteProfile(profile, rowIndex) {

    try {

      //|| profile.bIsDefault.toString() == "true"
      if (profile.nWatchListId == this.defaultWatchListID
      ) {
        this.toastProvider.showAtBottom("Cannot delete default watchlist.");
        return;
      }

      if (profile.nTenantId == '' || profile.nWatchListId == 1000 || profile.nWatchListId == 1001) {
        this.toastProvider.showAtBottom("Cannot delete system profile.");
        return;
      }

      //Are you sure you want to delete the watchlist ‘Naveet top picks’?
      let buttons: any = ['Confirm', 'Cancel']
      this.alertCtrl.showAlertConfirmWithButtons("Watchlist", "Are you sure you want to delete the watchlist ‘" + profile.sWatchListName + "’?", buttons,
        async () => {
          let statusUpdate = new BehaviorSubject("1");
          const modal = await this.modalController.create({
            component: WatchlistloaderPage,
            //cssClass: 'my-custom-class',
            componentProps: {
              'status': statusUpdate,
            }
          });
          statusUpdate.next("1");

          this.showWatchListSelection = false;
          this.watchlistServ.deleteWatchlist(profile).then(async (data) => {
            //this.showDone = true;
            await modal.present();
            statusUpdate.next("1");
            setTimeout(() => {
              //this.showDone = false;
              modal.dismiss().then(async value => {

                this.showWatchListSelection = false;
                this.profileList.splice(rowIndex, 1);
                this.profileCnt = this.profileList.length;

                this.localstorageservice.getItem(this.userTypefilter).then(filter => {
                  if (filter != undefined) {

                    let keyFilter = clsGlobal.User.userId + "_" + profile.nWatchListId;
                    let arrWatchFilters = JSON.parse(filter) || [];
                    let bFound = false;

                    for (let index = 0; index < arrWatchFilters.length; index++) {
                      const element = arrWatchFilters[index];
                      if (keyFilter == arrWatchFilters.nWatchListId) {
                        arrWatchFilters.splice(index, 1);
                        bFound = true;
                        break;
                      }
                    }

                    if (bFound) {
                      this.localstorageservice.setObject(this.userTypefilter, arrWatchFilters);
                    }

                  }
                });

                if (this.selProfileId == profile.nWatchListId) {

                  this.sendAllSubUnsubscribeRequest(OperationType.REMOVE);
                  this.dcViewPortScrip.Clear();
                  clsGlobal.userSelectedWatchlist = undefined;
                  //await this.setDefaultProfile();
                  let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
                  this.localstorageservice.getItem(watchKeyFilter).then(watchId => {

                    this.defaultWatchListID = watchId || '0';
                    this.setDefaultProfile();
                    clsGlobal.userSelectedWatchlist = this.selProfile;
                    this.profileScrips = [];
                    this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
                      if (profileScripData != undefined) {
                        this.profileScrips = profileScripData;
                        this.loadProfileDetails();
                      }
                    });

                  });

                  //this.loadProfileDetails();

                }
              });

            }, 1000);

          }, (error) => {
            clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'onDeleteProfile',error.Message,undefined,error.stack,undefined,undefined));
          });


        },
        () => {
          console.log("Cancel");
        });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'onDeleteProfile', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'onDeleteProfile2',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  deleteWatchlist() {
    try {

      let selProfile = this.profileList.filter(profile => {
        return profile.nWatchListId == this.selProfileId;
      });

      if (selProfile.length == 0) {
        this.toastProvider.showAtBottom("Invalid Profile.");
        return;
      }

      if ((selProfile[0].bIsPrivate.toString() == "false" && selProfile[0].nTenantId != "") ||
        selProfile[0].nWatchListId == 1000 || selProfile[0].nWatchListId == 1001 || selProfile[0].nTenantId == '') {
        this.toastProvider.showAtBottom("Cannot delete system profile.");
        return;
      }

      //|| selProfile[0].bIsDefault.toString() == "true"
      if (selProfile[0].nWatchListId == this.defaultWatchListID) {
        this.toastProvider.showAtBottom("Cannot delete default watchlist.");
        return;
      }



      let buttons: any = ['Confirm', 'Cancel']
      this.alertCtrl.showAlertConfirmWithButtons("Watchlist", "Are you sure you want to delete watchlist '" + this.selProfileName + "' ?", buttons,
        async () => {

          let statusUpdate = new BehaviorSubject("1");
          const modal = await this.modalController.create({
            component: WatchlistloaderPage,
            //cssClass: 'my-custom-class',
            componentProps: {
              'status': statusUpdate,
            }
          });
          statusUpdate.next("1");

          this.watchlistServ.deleteWatchlist(selProfile[0]).then(async (data) => {

            await modal.present();
            statusUpdate.next("1");
            this.showWatchListSelection = false;
            setTimeout(() => {
              //this.showDone = false;
              modal.dismiss().then(async value => {

                this.showWatchListSelection = false;
                this.showContext = false;
                for (let index = 0; index < this.profileList.length; index++) {
                  const element = this.profileList[index];
                  if (element.nWatchListId == selProfile[0].nWatchListId) {
                    this.profileList.splice(index, 1);
                    break;
                  }
                }

                this.localstorageservice.getItem(this.userTypefilter).then(filter => {
                  if (filter != undefined) {

                    let keyFilter = clsGlobal.User.userId + "_" + selProfile[0].nWatchListId;
                    let arrWatchFilters = JSON.parse(filter) || [];
                    let bFound = false;

                    for (let index = 0; index < arrWatchFilters.length; index++) {
                      const element = arrWatchFilters[index];
                      if (keyFilter == arrWatchFilters.nWatchListId) {
                        arrWatchFilters.splice(index, 1);
                        bFound = true;
                        break;
                      }
                    }

                    if (bFound) {
                      this.localstorageservice.setObject(this.userTypefilter, arrWatchFilters);
                    }
                  }
                });

                this.profileCnt = this.profileList.length;
                clsGlobal.userSelectedWatchlist = undefined;
                if (this.selProfileId == selProfile[0].nWatchListId) {
                  this.sendAllSubUnsubscribeRequest(OperationType.REMOVE);
                  this.dcViewPortScrip.Clear();
                  //await this.setDefaultProfile();
                  let watchKeyFilter = this.defaultWatchKey + "_" + clsGlobal.User.userId;
                  this.localstorageservice.getItem(watchKeyFilter).then(watchId => {

                    this.defaultWatchListID = watchId || '0';
                    this.setDefaultProfile();
                    clsGlobal.userSelectedWatchlist = this.selProfile;

                    this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, this.selProfile.sCreatedBy).then((profileScripData: any) => {
                      if (profileScripData != undefined) {
                        this.profileScrips = profileScripData;
                        this.loadProfileDetails();
                      }
                    });

                  });

                }

              });
            }, 1000);

          });
        },
        () => {
          console.log("Cancel");
        });
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'deleteWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'deleteWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  renameWatchlist() {
    try {

      if (this.selProfile == undefined) {
        this.toastProvider.showAtBottom("Invalid Profile.");
        return;
      }

      if (this.selProfile.nTenantId == '' || this.selProfile.nWatchListId == 1000 || this.selProfile.nWatchListId == 1001) {
        this.toastProvider.showAtBottom("Cannot rename system profile.");
        return;
      }


      this.showWatchListSelection = false;
      this.showContext = false;
      this.showRename = true;

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'renameWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'renameWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  closeProfileRename() {
    this.showRename = !this.showRename;
  }

  updateProfileName() {

    try {

      if (this.selRenameProfileName.length == 0) {
        return this.toastProvider.showAtBottom("Watchlist name cannot be blank.");
      }

      this.watchlistServ.getWatchlistProfile().then(async (profList: any) => {

        try {

          let isProfileExist = profList.filter(item => {
            return item.sWatchListName == this.selRenameProfileName
          });

          if (isProfileExist.length != 0) {
            this.toastProvider.showAtBottom("Looks like this watchlist already exists. Try using a different name.");
            return;
          }

          if (this.selRenameProfileName == 'My Holdings' || this.selRenameProfileName == "Don't Miss") {
            this.toastProvider.showAtBottom("Watchlist name cannot rename as system name.");
            return;
          }

          let watclistObj: any = {};
          watclistObj.profileId = this.selProfileId;
          watclistObj.profileName = this.selRenameProfileName;

          watclistObj = {
            nWatchListId: this.selProfileId,
            sWatchListName: this.selRenameProfileName,
            bIsPrivate: this.selProfile.bIsPrivate,
            bIsDefault: this.selProfile.bIsDefault,
            sCreatedBy: clsGlobal.User.userId,
            nTenantId: clsGlobal.ComId
          };

          this.watchlistServ.updatProfileName(watclistObj).then((data) => {
            this.toastProvider.showAtBottom("Profile rename successfully.");
            this.selProfileName = this.selRenameProfileName;
            this.closeProfileRename();
            // let renameProfile = this.profileList.filter((element, index, array) => {
            //   return element.nWatchListId == this.selProfileId;
            // });
            // renameProfile[0].sWatchListName =  this.selRenameProfileName;
            this.selProfile.sWatchListName = this.selRenameProfileName;
          }, (error) => {
            this.toastProvider.showAtBottom("Cannot Rename Profile");
          });

        } catch (error) {
          //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'updateProfileName--getWatchlistProfile', error);
          clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'updateProfileName',error.Message,undefined,error.stack,undefined,undefined));
        }

      }, (error) => {

      });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'updateProfileName', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'updateProfileName2',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  addScripToWatchlist() {
    try {

      if (this.selProfile == undefined) {
        this.toastProvider.showAtBottom("Invalid Profile.");
        return;
      }

      //if (selProfile[0].bIsPrivate == 0 || selProfile[0].nTenantId == '') {
      if (this.selProfile.bIsPrivate.toString() == "false" || this.selProfile.nTenantId == '') {
        this.toastProvider.showAtBottom("Cannot add scrip to system profile.");
        return;
      }
      let navParam: NavigationExtras = {
        queryParams: { profile: this.selProfile, type: "UPDATE" }
      };
      this.navCtrl.navigateForward('lookup', navParam);
      this.showContext = false;

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'addScripToWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'addScripToWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  removeScripFromWatchlist() {
    try {

      if (this.selProfile == undefined) {
        this.toastProvider.showAtBottom("Invalid Profile.");
        return;
      }

      if (this.selProfile.bIsPrivate.toString() == "false" || this.selProfile.nTenantId == '') {
        this.toastProvider.showAtBottom("Cannot remove scrip from system profile.");
        return;
      }
      let navParam: NavigationExtras = {
        queryParams: { profile: this.selProfile, scripList: this.watchListScripts, type: "REMOVE" }
      };
      this.navCtrl.navigateForward('watchlist-remove-reorder', navParam);
      this.showContext = false;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'removeScripFromWatchlist', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'removeScripFromWatchlist',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  reOrderScrip() {
    try {

      if (this.selProfile == undefined) {
        this.toastProvider.showAtBottom("Invalid Profile.");
        return;
      }

      if (this.selProfile.bIsPrivate == 0 || this.selProfile.nTenantId == '') {
        this.toastProvider.showAtBottom("Cannot reorder scrip of system profile.");
        return;
      }

      let navParam: NavigationExtras = {
        queryParams: { profile: this.selProfile, scripList: this.watchListScripts, type: "REORDER" }
      };
      this.navCtrl.navigateForward('watchlist-remove-reorder', navParam);
      this.showContext = false;
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'reOrderScrip', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'reOrderScrip',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  getHoldingsData() {
    try {
      if (clsGlobal.User.Holding.length == 0) {
        this.transactionService.getHoldingsData().then((holdingsResponse: any) => {
          if (holdingsResponse.status == 'Success') {
            //this.holdingData = holdingsResponse.data;
            clsGlobal.userHoldingForWatchlist = true;
            clsGlobal.User.Holding = holdingsResponse.data;
            this.fillStockViewScrip();
          }
        }, error => {
          console.log(error)
        });
      } else {
        this.fillStockViewScrip();
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'getHoldingsData', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getHoldingsData',error.Message,undefined,error.stack,undefined,undefined));
    }
  }



  /**
     *
     * @param opType
     */
  sendAllSubUnsubscribeRequest(opType) {
    try {


      if (this.dcViewPortScrip.Count() > 0) {

        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;

        let tempIndexScripList = [];
        let arrScrip = this.dcViewPortScrip.Keys();
        let cnt = arrScrip.length;
        for (let i = 0; i < cnt; i++) {
          let scripKey = arrScrip[i];
          tempIndexScripList[i] = this.dcViewPortScrip.getItem(scripKey).scripDet;
        }
        objTLReq.ScripList = tempIndexScripList;

        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        tempIndexScripList = null;
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sendAllSubUnsubscribeRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'sendAllSubUnsubscribeRequest',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  viewPortSubUnsubscribeRequest() {
    try {

      if (this.viewPortSubList != null && this.viewPortSubList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = OperationType.ADD;
        objTLReq.ScripList = this.viewPortSubList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        objTLReq = null;
      }
      else {
        console.log("Blank subscription list.");
      }

      if (this.viewPortUnSubList != null && this.viewPortUnSubList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = OperationType.REMOVE;
        objTLReq.ScripList = this.viewPortUnSubList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
        //this.viewPortUnSubList = null;
        //this.viewPortUnSubList = [];
        objTLReq = null;
      }
      else {
        console.log("Blank un subscription list.");
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'viewPortSubUnsubscribeRequest', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'viewPortSubUnsubscribeRequest',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  onNextSlideStart(ev) {

    try {


      if (this.selectedScrip != undefined) {

        this.sliderOverlay.getPreviousIndex().then(index => {
          let scripPrevItem = this.filterWatchlistScripts[index];
          //console.log("PrevItem: " + scripPrevItem.scripDetail);
          // let prevScrip: clsScrip = new clsScrip();
          // prevScrip.scripDet.MktSegId = scripPrevItem.scripDetail.scripDet.MktSegId;
          // prevScrip.scripDet.token = scripPrevItem.scripDetail.scripDet.token;
          let prevScrip = scripPrevItem.scripDetail;

          this.sendB5Request(OperationType.REMOVE, prevScrip);
        });

      }

      this.sliderOverlay.getActiveIndex().then(index => {

        let scripNextItem = this.filterWatchlistScripts[index];
        //console.log("NextItem: " + scripNextItem.scripDetail);

        // let currScrip: clsScrip = new clsScrip();
        // currScrip.scripDet.MktSegId = scripNextItem.scripDetail.scripDet.MktSegId;
        // currScrip.scripDet.token = scripNextItem.scripDetail.scripDet.token;

        this.selectedScrip = scripNextItem.scripDetail;//currScrip;
        this.sendB5Request(OperationType.ADD, this.selectedScrip);
      });

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'onNextSlideStart', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'onNextSlideStart',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  sendB5Request(intOperationType: OperationType, objScrip: clsScrip) {
    try {
      let objTLReq = new clsBestFiveRequest();
      objTLReq.OperationType = intOperationType;
      objTLReq.ByPassRequestStore = false;
      objTLReq.Scrip = objScrip;
      clsGlobal.pubsub.publish("B5REQ", objTLReq);
    } catch (e) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'sendB5Request', e);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'sendB5Request',e.Message,undefined,e.stack,undefined,undefined));
    }
  }

  getValue(scrip) {
    let value = parseInt(scrip.B5Data.ATPPrc) * parseInt(scrip.B5Data.Volume);
    return value.toFixed(2).toString();
  }

  numbertoString(number) {
    let words: any = "";
    try {
      if (number == undefined || number == "") return "-";

      let Mcap = 0;
      let Val = parseInt(number);
      if (Val.toString().length > 7) {
        Mcap = number / 10000000;
        words = Mcap.toFixed(2) + " Cr";
      } else if (Val.toString().length <= 7 && Val.toString().length > 5) {
        Mcap = number / 100000;
        words = Mcap.toFixed(2) + " L";
      } else {
        words = parseFloat(number); //.toFixed(2); Solved by om on 14 jul for volume decimal in case of 3 or 4 digit values.
      }


    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'numbertoString', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'numbertoString',error.Message,undefined,error.stack,undefined,undefined));
    }
    return words;
  }


  onViewPortItemChange(event) {
    try {
      let element;
      if (event) {
        element = event.srcElement;
      } else {
        element = this.divScrollContent.nativeElement;
      }
      //event  =  event || this.divScrollContent;

      if (element != null || element != undefined) {
        //let container = event.contentElement || event.getNativeElement();
        let containerTop = element.getBoundingClientRect().top;//event.contentTop;
        let containerBottom = element.getBoundingClientRect().bottom;

        if (element.getElementsByClassName('watclistitem').length > 0) {

          let eleArray = element.getElementsByClassName('watclistitem');
          this.viewPortSubList = [];
          this.viewPortUnSubList = [];

          for (let index = 0; index < eleArray.length; index++) {
            const element = eleArray[index];
            let idData: any = this.filterWatchlistScripts.filter((item) => {
              return (item.scripDetail.scripDet == element.id);
            });

            if (idData == undefined) {
              continue;
            }

            idData = idData[0];
            let eleTop = element.getBoundingClientRect().top;
            let eleBottom = element.getBoundingClientRect().bottom;
            let isInView = clsCommonMethods.isScrolledIntoView(containerTop, containerBottom, eleTop, eleBottom);
            if (isInView && this.dcViewPortScrip.ContainsKey(element.id) == false) {
              let valueObj: any = {};
              valueObj.isInView = isInView;
              valueObj.index = (element.id);
              valueObj.scripDet = idData.scripDetail.scripDet;
              // Storing the same in ViewPort.
              this.dcViewPortScrip.Add(element.id, valueObj);
              // Scrip is in view so add in subscription list
              this.viewPortSubList.push(idData.scripDetail.scripDet);

            }
            else {
              let isSubsribed = this.dcViewPortScrip.getItem(element.id);
              // Scrip is subscribed and not in view.
              if (isSubsribed && !isInView) {
                // remove it from ViewPort
                this.dcViewPortScrip.Remove(element.id);
                // add in unsubscribe list.
                this.viewPortUnSubList.push(idData.scripDetail.scripDet);
              }
            }
          }

          this.viewPortSubUnsubscribeRequest();
          //this.assignHolding();
          setTimeout(() => {
            if (this.myPane != undefined)
              this.myPane.enableDrag();
          }, 400);



        }
      }


    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'onViewPortItemChange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'onViewPortItemChange',error.Message,undefined,error.stack,undefined,undefined));

    }
  }

  showDetails() {
    try {

      this.myPane.moveToBreak('bottom');

      this.showDontMiss = true;
      this.showEvents = false;

      setTimeout(() => {

        if (this.eventList.length == 0) {

          this.showEvents = false;
          this.isDontMissExists = false;
          setTimeout(() => {
            this.myPane.moveToBreak('middle');
            this.showDontMissCnt = true;
          }, 300);
        } else {
          this.myPane.moveToBreak('bottom');
          this.showEvents = true;
          this.isDontMissExists = true;
          setTimeout(() => {
            this.setEventAnimation();
          }, 10);
        }

      }, 2000);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'showDetails',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  async clickPopover(ev: any, stype) {
    const popover = await this.popoverController.create({
      component: PopoverPage,
      event: ev,
      translucent: true,
      mode: "ios",
      backdropDismiss: false,
      componentProps: {
        'type': stype,
      }
    });
    await popover.present();
    popover.onDidDismiss().then((result) => {
      if (result.data == 1) {
        this.showDetails();
      }
      else {
        this.showEventDetails();
      }
    });
  }

  showEventDetails() {

    try {

      this.myPane.moveToBreak('top');
      this.showDontMiss = false;
      //this.showEvents = false;
      setTimeout(() => {
        this.myPane.moveToBreak('middle');
        this.showDontMissCnt = true;
        this.showEvents = false;
      }, 1000);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'showEventDetails', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'showEventDetails',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  setEventAnimation() {

    try {


      const divElement: HTMLElement = document.getElementById('myCards');
      //console.log('Event: ', divElement);
      const animation: Animation = this.animationCtrl.create()
        .addElement(divElement)
        .duration(1000)
        .fromTo('transform', 'translateX(' + (window.innerWidth - 10) + 'px)', 'translateX(0px)')
      animation.play();

      animation.onFinish((data) => {
        try {
          document.getElementById('btnEvent').click();
        } catch (error) {
          console.log('Animation End: ', error.message);
        }
      })

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'setEventAnimation', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'setEventAnimation',error.Message,undefined,error.stack,undefined,undefined));
    }

  }

  calcDivHeight() {

    try {

      if (this.divWatchlist != undefined) {
        let topDiv = this.divWatchlist.nativeElement.getBoundingClientRect().top;
        let eleFilter: any = document.getElementsByClassName('filter-sort-wrap')[0];
        let filterHt = 0;
        if (eleFilter) {
          filterHt = eleFilter.offsetHeight;
        }
        //console.log("Top: ", topDiv)
        if (topDiv < 45) {
          this.divHeight = window.innerHeight - 82 - 48 - 30 - 44 - topDiv - filterHt;
        } else {
          this.divHeight = window.innerHeight - 82 - 48 - 30 - topDiv - filterHt;
        }
      }

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'calcDivHeight', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'calcDivHeight',error.Message,undefined,error.stack,undefined,undefined));
      
    }
  }
  showFullMode: boolean = false;
  onFocus(objOE) {
    this.showFullMode = true;
    // this.showPopUpOE = false;
    // setTimeout(() => {
    //   this.paramService.myParam = objOE;
    //   this.navCtrl.navigateForward('orderentry');
    // }, 50);

  }

  kFormatter(num) {
    try {
      let digits = 1;

      var si = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E5, symbol: "Lac" },
        { value: 1E7, symbol: "Cr." },
        { value: 1E12, symbol: "Cr." },
        { value: 1E15, symbol: "Cr." },
        { value: 1E18, symbol: "Cr." }
      ];
      var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
      var i;
      for (i = si.length - 1; i > 0; i--) {
        if (num >= si[i].value) {
          break;
        }
      }
      this.fundsValueInText = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
    } catch (error) {
      //console.log("Error in k formatter watchlist." + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'kFormatter',error.Message,undefined,error.stack,undefined,undefined));
      this.fundsValueInText = "0.00";
    }
  }

  showExchangePopUp(item, index) {

    if (this.showExchange == true) {
      this.showExchange = false;
    }
    else {
      this.exchangeIdx = index;
      if (item.scripDetail.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
        item.scripDetail.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
        item.scripDetail.scripDet.MktSegId != clsConstants.C_V_MSX_CASH) {
        return;
      }
      this.showExchange = true;
      this.getExchangeList(item);
    }

  }

  getExchangeList(scripObject) {
    try {

      this.exchangeScripList = [];
      if (clsGlobal.exchangeName.ContainsKey(scripObject.scripDetail.symbol)) {
        this.exchangeScripList = clsGlobal.exchangeName.getItem(scripObject.scripDetail.symbol);
      } else {

        this.objHttpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/EQUITIES/" + null + "/" + scripObject.scripDetail.symbol).subscribe(exchData => {
          //console.log("Exchanges: ", exchData);
          let resultdata: any = exchData
          if (resultdata.result == undefined) {
            return;
          }
          for (let index = 0; index < resultdata.result.hits.hits.length; index++) {
            const element = resultdata.result.hits.hits[index]._source;

            // let currScrip: clsScrip = new clsScrip();
            // currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId);
            // currScrip.scripDet.token = element.nToken;
            // currScrip.symbol = element.sSymbol;
            // currScrip.Series = element.sSeries;
            // currScrip.InstrumentName = element.sInstrumentName;
            // currScrip.ExpiryDate = element.nExpiryDate;
            // currScrip.StrikePrice = element.nStrikePrice || "-1";
            // currScrip.OptionType = element.sOptionType || "NA";
            // currScrip.MarketLot = element.nRegularLot || 1;
            // currScrip.PriceTick = element.nPriceTick || 1;
            let currScrip: any;
            currScrip = clsCommonMethods.getScripObject(element).scripDetail;
            let exchItem = this.exchangeScripList.filter(item => {
              return item.ExchangeName == currScrip.ExchangeName
            })
            if (exchItem.length == 0)
              this.exchangeScripList.push(currScrip);;
          }

          clsGlobal.exchangeName.Add(scripObject.scripDetail.symbol, this.exchangeScripList);
          //this.exchangeScripList = exchData;
        });
      }
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getExchangeList', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'getExchangeList',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  toggleExchange(scrip) {
    try {

      this.showExchange = !this.showExchange;
      this.sendB5Request(OperationType.REMOVE, this.selectedScrip);
      //this.filterWatchlistScripts[i]

      this.selectedScrip = scrip;
      this.sendB5Request(OperationType.ADD, scrip);

    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'toggleExchange', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'toggleExchange',error.Message,undefined,error.stack,undefined,undefined));
    }
  }


  ionViewWillLeave() {
    try {

      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      clsGlobal.pubsub.unsubscribe("B5RES", this.bcastB5Handler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.whatsHotScripKeyList);
      this.sendAllSubUnsubscribeRequest(OperationType.REMOVE);
      if (this.selectedScrip != undefined)
        this.sendB5Request(OperationType.REMOVE, this.selectedScrip);
      this.isInitDone = false;
      clsGlobal.userHoldingForWatchlist = false;
      this.showWatchListSelection = false;
      this.showContext = false;
      this.showPopUpOE = false;
      this.showRename = false;
      this.dcViewPortScrip.Clear();
      this.viewPortSubList = [];
      this.showOverlay = false;
      this.selectedScrip = undefined;
      window.onresize = null;
      //this.divScrollContent.nativeElement.removeEventListener("scroll");
      this.elTicker.ionViewWillLeave();
    } catch (error) {
      //clsGlobal.logManager.writeErrorLog('WatchlistPage', 'ionViewWillLeave', error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'ionViewWillLeave',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  clicktickerCard() {
    this.showtickerCard = !this.showtickerCard;
  }
  clickaddtoWatchlist() {
    this.showaddtoWatchlist = !this.showaddtoWatchlist;
  }
  exchangeClose() {
    this.showExchange = false;
  }

  showFilterPopup: boolean = false;

  @ViewChild('divFilter', { static: false }) divOrderFilter: ElementRef;
  showExpandedFilter: boolean = false;
  orderFilterPane: any;

  alphabetAsc: boolean = false;
  priceAsc: boolean = false;
  percentAsc: boolean = false;

  selSorting: any = '';
  selSortingType: any = '';

  filterType: any = {};
  isFilterApplied: boolean = false;
  hideFilter: boolean = false;
  selWatchlist: any;
  keyFilter = '';
  arrWatchFilters = [];
  filterCount = 0;
  isFilterAvailable = false;

  showOrderFilterPopup() {
    this.showFilterPopup = true;
    this.checkForOrderFiilterPopupUpElementRendrer();
  }

  checkForOrderFiilterPopupUpElementRendrer() {
    const divElement: HTMLElement = document.getElementById('divFilterPopup');
    if (divElement == null) {
      setTimeout(() => {
        this.checkForOrderFiilterPopupUpElementRendrer();
      }, 100);
    } else {
      //this.divScrollContent.nativeElement.offsetHeight = window.screen.height - 90;
      setTimeout(() => {
        const divElement: HTMLElement = document.getElementById('divFilterPopup');
        this.orderFilterPopupBottomToTop(divElement);
      }, 200);
    }
  }

  orderFilterPopupBottomToTop(myElementRef) {
    try {
      let setting: CupertinoSettings = {
        breaks: {
          top: { // Topper point that pane can reach
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight, // Pane breakpoint height
            bounce: false // Bounce pane on transition
          }
          , middle: {
            enabled: true, // Enable or disable breakpoint
            height: window.innerHeight - (250), // Pane breakpoint height
            bounce: false // Bounce pane on transition 
          },
          bottom: {
            enabled: false, // Enable or disable breakpoint 
          }
        },
        dragBy: ['.order-tab-wrap .pane .draggable'],
        initialBreak: 'middle',
        bottomClose: false,
        animationType: "ease",
        animationDuration: 300,
        buttonClose: false,
        backdrop: true,

        onTransitionEnd: () => {
          let topDiv = this.divOrderFilter.nativeElement.getBoundingClientRect().top;
          //console.log("onDragEnd" ,topDiv );
          if (topDiv < 90) {
            this.showExpandedFilter = true;
          } else {
            this.showExpandedFilter = false;
          }
        },
        onBackdropTap: () => {
          //added by omprakash on 24 th jan for backdrop click
          this.closeOrderFiltePopup();
        }
      }
      this.orderFilterPane = new CupertinoPane(myElementRef, setting);
      this.orderFilterPane.enableDrag();
      this.orderFilterPane.present({ animate: true });
    } catch (error) {
      //console.log("Error in filter page display " + error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('WatchlistPage', 'orderFilterPopupBottomToTop',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  // change by omprakash for scroll behaviour.
  scrollOrderDetailsFilter(event) {
    if (event.target.scrollTop > 30) {
      this.orderFilterPane.moveToBreak('top');
      this.showExpandedFilter = true;
    }
  }

  closeOrderFiltePopup() {
    this.showFilterPopup = false;
    this.showExpandedFilter = false;
    this.orderFilterPane.destroy({ animate: true });
  }

  setSortType(sortName, sortType) {
    this.selSorting = sortName;
    this.selSortingType = sortType;
    this.isFilterApplied = true;
    this.filterCount++;

    //if(this.selSortingType != ''){
    this.hideFilter = true;
    //}

  }

  setFilterType(filterType) {

    if (filterType == 'Equity') {
      this.filterType.isEquity = !this.filterType.isEquity;
      if (this.filterType.isEquity) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'Commodity') {
      this.filterType.isCommodity = !this.filterType.isCommodity;
      if (this.filterType.isCommodity) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'Currency') {
      this.filterType.isCurrency = !this.filterType.isCurrency;
      if (this.filterType.isCurrency) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'BSE') {
      this.filterType.isBSE = !this.filterType.isBSE;
      if (this.filterType.isBSE) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'NSE') {
      this.filterType.isNSE = !this.filterType.isNSE;
      if (this.filterType.isNSE) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'FAO') {
      this.filterType.isFAO = !this.filterType.isFAO;
      if (this.filterType.isFAO) { this.filterCount++; } else { this.filterCount--; }
    }
    this.isFilterApplied = true;
    this.hideFilter = true;
  }

  clearFilter() {

    this.selSorting = '';
    this.selSortingType = '';

    this.filterType.isEquity = false;
    this.filterType.isCommodity = false;
    this.filterType.isCurrency = false;
    this.filterType.isBSE = false;
    this.filterType.isNSE = false;
    this.filterType.isFAO = false;

    this.isFilterApplied = false;
    this.filterCount = 0;

    this.saveFilter();
    //this.localstorageservice.setObject(this.userTypefilter, undefined);
    this.closeOrderFiltePopup();
  }

  goBack() {

    let filterSorting: any = {};
    filterSorting.sorting = this.selSorting;
    filterSorting.sortingType = this.selSortingType;
    filterSorting.filter = this.filterType;
    filterSorting.filterCount = this.filterCount;



    this.localstorageservice.getItem(this.userTypefilter).then(filter => {

      let isExists = false;
      let keyFilter = clsGlobal.User.userId + "_" + this.selProfileId;

      let objFilter: any = {};
      objFilter.filterId = keyFilter;
      objFilter.filter = filterSorting;

      if (filter != undefined) {

        this.arrWatchFilters = JSON.parse(filter) || [];

        for (let index = 0; index < this.arrWatchFilters.length; index++) {
          const filter = this.arrWatchFilters[index];
          if (keyFilter == filter.filterId) {
            this.arrWatchFilters.splice(index, 1);
            this.arrWatchFilters.push(objFilter);
            isExists = true;
            break;
          }
        }

        if (!isExists) {
          this.arrWatchFilters.push(objFilter);
        }

      } else {
        this.arrWatchFilters.push(objFilter);
      }

      this.localstorageservice.setObject(this.userTypefilter, this.arrWatchFilters);

      setTimeout(() => {
        this.applySortingandFilter();
        this.closeOrderFiltePopup();
      }, 500);

    });
    //clsGlobal.User.watchlistFilter = filterSorting;

    //this.navCtrl.pop();
  }

  removeSort(sorting, type) {

    this.selSorting = '';
    this.selSortingType = '';
    this.filterCount--;
    this.saveFilter();

    if ((!this.filterType.isEquity && !this.filterType.isCommodity && !this.filterType.isCurrency &&
      !this.filterType.isNSE && !this.filterType.isFAO) && this.selSorting == '') {
      this.hideFilter = false;
    }

  }

  removeFilter(filterType) {
    if (filterType == 'Equity') {
      this.filterType.isEquity = !this.filterType.isEquity;
      if (this.filterType.isEquity) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'Commodity') {
      this.filterType.isCommodity = !this.filterType.isCommodity;
      if (this.filterType.isCommodity) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'Currency') {
      this.filterType.isCurrency = !this.filterType.isCurrency;
      if (this.filterType.isCurrency) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'BSE') {
      this.filterType.isBSE = !this.filterType.isBSE;
      if (this.filterType.isBSE) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'NSE') {
      this.filterType.isNSE = !this.filterType.isNSE;
      if (this.filterType.isNSE) { this.filterCount++; } else { this.filterCount--; }
    }
    else if (filterType == 'FAO') {
      this.filterType.isFAO = !this.filterType.isFAO;
      if (this.filterType.isFAO) { this.filterCount++; } else { this.filterCount--; }
    }

    this.saveFilter();
    if ((!this.filterType.isEquity && !this.filterType.isCommodity && !this.filterType.isCurrency &&
      !this.filterType.isNSE && !this.filterType.isFAO) && this.selSorting == '') {
      this.hideFilter = false;
    }

  }

  saveFilter() {
    let filterSorting: any = {};
    filterSorting.sorting = this.selSorting;
    filterSorting.sortingType = this.selSortingType;
    filterSorting.filter = this.filterType;
    filterSorting.filterCount = this.filterCount;
    this.localstorageservice.getItem(this.userTypefilter).then(filter => {

      let isExists = false;
      let keyFilter = clsGlobal.User.userId + "_" + this.selProfileId;

      let objFilter: any = {};
      objFilter.filterId = keyFilter;
      objFilter.filter = filterSorting;

      if (filter != undefined) {

        this.arrWatchFilters = JSON.parse(filter) || [];

        for (let index = 0; index < this.arrWatchFilters.length; index++) {
          const filter = this.arrWatchFilters[index];
          if (keyFilter == filter.filterId) {
            this.arrWatchFilters.splice(index, 1);
            this.arrWatchFilters.push(objFilter);
            isExists = true;
            break;
          }
        }

        if (!isExists) {
          this.arrWatchFilters.push(objFilter);
        }

      } else {
        this.arrWatchFilters.push(objFilter);
      }

      this.localstorageservice.setObject(this.userTypefilter, this.arrWatchFilters);

      setTimeout(() => {
        this.applySortingandFilter();

      }, 500);

    });
  }


}
