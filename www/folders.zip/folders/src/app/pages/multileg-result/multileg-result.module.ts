import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultilegResultPageRoutingModule } from './multileg-result-routing.module';

import { MultilegResultPage } from './multileg-result.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultilegResultPageRoutingModule
  ],
  declarations: [MultilegResultPage]
})
export class MultilegResultPageModule {}
