import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsConstants } from 'src/app/Common/clsConstants';

@Component({
  selector: 'app-multileg-result',
  templateUrl: './multileg-result.page.html'
})

export class MultilegResultPage implements OnInit {

  dataMultiLegOE: any = null;
  confirmTxt: any = "";
  orderID: any = "";

  constructor(private navCtrl: NavController,
    private paramService: NavParamService) {
    if (this.paramService.myParam) {
      this.dataMultiLegOE = this.paramService.myParam;
      let leg1 = '';
      let leg2 = '';
      let leg3 = '';

      if (this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date != undefined &&
        this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date != '') {
        let leg1expiry = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.expiry_date.substr(-2);

        if (this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.strike_price != '') {
          leg1 = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.symbol + ' ' + leg1expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.option_type;
        } else {
          leg1 = this.dataMultiLegOE.reqBody.leg_details[0].scrip_info.symbol + ' ' + leg1expiry + ' FUT';
        }
      }

      if (this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date != undefined &&
        this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date != '') {
        let leg2expiry = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.expiry_date.substr(-2);

        if (this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.strike_price != '') {
          leg2 = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.symbol + ' ' + leg2expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.option_type;
        } else {
          leg2 = this.dataMultiLegOE.reqBody.leg_details[1].scrip_info.symbol + ' ' + leg2expiry + ' FUT';
        }
      }

      if(this.dataMultiLegOE.reqBody.type == '3L'){
        if (this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date != undefined &&
          this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date != '') {
          let leg3expiry = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(2, 3) + "'" +this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.expiry_date.substr(-2);
  
          if (this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.strike_price != '') {
            leg3 = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.symbol + ' ' + leg3expiry + ' OPT ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.strike_price + ' ' + this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.option_type;
          } else {
            leg3 = this.dataMultiLegOE.reqBody.leg_details[2].scrip_info.symbol + ' ' + leg3expiry + ' FUT';
          }
        }
      }

      if(this.dataMultiLegOE.reqBody.type == '2L')
      {
        this.confirmTxt = " Your Multileg order consisting of " + leg1 + " & " + leg2 + " has been placed Successfully! ";
      }
      else if(this.dataMultiLegOE.reqBody.type == '3L')
      {
        this.confirmTxt = " Your Multileg order consisting of " + leg1 + ", " + leg2 + " & " + leg3 + " has been placed Successfully! ";
      }
      else if(this.dataMultiLegOE.reqBody.type == 'SPREAD')
      {
        let typeleg1 = this.dataMultiLegOE.reqBody.leg_details[0].transaction_type;
        let typeleg2 = this.dataMultiLegOE.reqBody.leg_details[1].transaction_type;
        this.confirmTxt = " You have placed a Spread Order to " + typeleg1 + " " + leg1 + " and " + typeleg2 +" " + leg2 + " for "+ this.dataMultiLegOE.totallot + " Lot " + "("+ this.dataMultiLegOE.reqBody.leg_details[0].quantity+ " shares"+")";
      }
      this.orderID = this.dataMultiLegOE.response.data.orderId;
    }
  }
  _setVar;
  ngOnInit() { 
    try {
      //auto close this page after 5 sec if user has not click.
      this._setVar=setTimeout(() => {
      this.closeConfirmation(); 
     }, 5000); 
    } catch (error) {
      //console.log("Error in ngOnInit"+error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegResultPage', 'ngOnInit',error.Message,undefined,error.stack,undefined,undefined));
    }
  }
  ionViewDidLeave(){
    //prevent settimeout to execute if user close the confirmation box.
    clearTimeout(this._setVar);
  }
  /**
   * @method : Close Order Confirmation box and route to watchlist
   */
  closeConfirmation() {
    try {
      this.navCtrl.pop().then(() => this.navCtrl.pop());
      //this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "closeConfirmation", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegResultPage', 'closeConfirmation',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

  /**
   * @method : Route to Transaction page
   */
  gotoTransaction() {
    try {
      this.paramService.myParam.mode = 'open';
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
    } catch (error) {
      //clsGlobal.ConsoleLogging("Error", "gotoTransaction", error);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('MultilegResultPage', 'gotoTransaction',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
