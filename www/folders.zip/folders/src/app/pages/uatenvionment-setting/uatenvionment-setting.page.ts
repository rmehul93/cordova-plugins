import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';

@Component({
  selector: 'app-uatenvionment-setting',
  templateUrl: './uatenvionment-setting.page.html' 
})
export class UATEnvionmentSettingPage implements OnInit {

  constructor(public navCtrl: NavController,public localstorage: clsLocalStorageService) { }

  tenantId:any ="";
  environmentURL:any ="";
  environmentPORT:any ="";
  ngOnInit() {
  }
  SetEnvironment()
  {
    try {
      clsGlobal.ComId=this.tenantId;
      clsGlobal.LocalComId=this.tenantId+"/";
      clsGlobal.URL=this.environmentURL.toString().trim();
      clsGlobal.PORT= this.environmentPORT.length==0?"/": ":"+this.environmentPORT+"/";
      clsGlobal.VirtualDirectory=clsGlobal.URL + clsGlobal.PORT;
      clsGlobal.URL_CDSSERVER = clsGlobal.URL + clsGlobal.PORT + 'cds/';
      
      let envset:any={};
      envset.ComId=clsGlobal.ComId;
      envset.LocalComId=clsGlobal.LocalComId;
      envset.URL=clsGlobal.URL;
      envset.PORT=clsGlobal.PORT;
      console.log(envset);
      this.localstorage.setItem("IS_UAT_SET",envset);
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
    } catch (error) {
      //console.log("Error in environment setting"+ error);
      alert("Error in set Environment"+error.message);
      clsGlobal.logManager.writeLog(clsGlobal.ComId,clsConstants.C_S_LOGTYPE_APPERROR,undefined,clsGlobal.logManager.createLogPayload('uatenvionment-setting', 'SetEnvironment',error.Message,undefined,error.stack,undefined,undefined));
    }
  }

}
