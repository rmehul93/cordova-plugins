/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.
import { Injectable } from "@angular/core";
import API, { graphqlOperation, GraphQLResult } from "@aws-amplify/api-graphql";
import { Observable } from "zen-observable-ts";

export interface SubscriptionResponse<T> {
  value: GraphQLResult<T>;
}

export type CreateAppInfoInput = {
  id?: string | null;
  sParamName: string;
  sParamValue?: string | null;
  sTenantId: string;
  _version?: number | null;
};

export type ModelAppInfoConditionInput = {
  sParamName?: ModelStringInput | null;
  sParamValue?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelAppInfoConditionInput | null> | null;
  or?: Array<ModelAppInfoConditionInput | null> | null;
  not?: ModelAppInfoConditionInput | null;
};

export type ModelStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null"
}

export type ModelSizeInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
};

export type UpdateAppInfoInput = {
  id: string;
  sParamName?: string | null;
  sParamValue?: string | null;
  sTenantId?: string | null;
  _version?: number | null;
};

export type DeleteAppInfoInput = {
  id?: string | null;
  _version?: number | null;
};

export type CreateMsgInfoInput = {
  id?: string | null;
  sMsgCode: string;
  sMessage?: string | null;
  sTenantId: string;
  _version?: number | null;
};

export type ModelMsgInfoConditionInput = {
  sMsgCode?: ModelStringInput | null;
  sMessage?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelMsgInfoConditionInput | null> | null;
  or?: Array<ModelMsgInfoConditionInput | null> | null;
  not?: ModelMsgInfoConditionInput | null;
};

export type UpdateMsgInfoInput = {
  id: string;
  sMsgCode?: string | null;
  sMessage?: string | null;
  sTenantId?: string | null;
  _version?: number | null;
};

export type DeleteMsgInfoInput = {
  id?: string | null;
  _version?: number | null;
};

export type CreateNewWatchListProfileInput = {
  id?: string | null;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate?: boolean | null;
  bIsDefault?: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version?: number | null;
};

export type ModelNewWatchListProfileConditionInput = {
  nWatchListId?: ModelIntInput | null;
  sWatchListName?: ModelStringInput | null;
  bIsPrivate?: ModelBooleanInput | null;
  bIsDefault?: ModelBooleanInput | null;
  sUserId?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelNewWatchListProfileConditionInput | null> | null;
  or?: Array<ModelNewWatchListProfileConditionInput | null> | null;
  not?: ModelNewWatchListProfileConditionInput | null;
};

export type ModelIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type ModelBooleanInput = {
  ne?: boolean | null;
  eq?: boolean | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type UpdateNewWatchListProfileInput = {
  id: string;
  nWatchListId?: number | null;
  sWatchListName?: string | null;
  bIsPrivate?: boolean | null;
  bIsDefault?: boolean | null;
  sUserId?: string | null;
  sTenantId?: string | null;
  _version?: number | null;
};

export type DeleteNewWatchListProfileInput = {
  id?: string | null;
  _version?: number | null;
};

export type CreateNewWatchListScripsInput = {
  id?: string | null;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo?: number | null;
  sUserId: string;
  sTenantId: string;
  _version?: number | null;
};

export type ModelNewWatchListScripsConditionInput = {
  nWatchListId?: ModelIntInput | null;
  nMarketSegmetId?: ModelIntInput | null;
  nToken?: ModelIntInput | null;
  nSequenceNo?: ModelIntInput | null;
  sUserId?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelNewWatchListScripsConditionInput | null> | null;
  or?: Array<ModelNewWatchListScripsConditionInput | null> | null;
  not?: ModelNewWatchListScripsConditionInput | null;
};

export type UpdateNewWatchListScripsInput = {
  id: string;
  nWatchListId?: number | null;
  nMarketSegmetId?: number | null;
  nToken?: number | null;
  nSequenceNo?: number | null;
  sUserId?: string | null;
  sTenantId?: string | null;
  _version?: number | null;
};

export type DeleteNewWatchListScripsInput = {
  id?: string | null;
  _version?: number | null;
};

export type CreateUserPreferenceInput = {
  id?: string | null;
  sUserId: string;
  sProfilePicPath?: string | null;
  sOrder?: string | null;
  sNotification?: string | null;
  sInAppNotification?: string | null;
  sTheme?: string | null;
  sExchange?: string | null;
  sTenantId: string;
  _version?: number | null;
};

export type ModelUserPreferenceConditionInput = {
  sUserId?: ModelStringInput | null;
  sProfilePicPath?: ModelStringInput | null;
  sOrder?: ModelStringInput | null;
  sNotification?: ModelStringInput | null;
  sInAppNotification?: ModelStringInput | null;
  sTheme?: ModelStringInput | null;
  sExchange?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelUserPreferenceConditionInput | null> | null;
  or?: Array<ModelUserPreferenceConditionInput | null> | null;
  not?: ModelUserPreferenceConditionInput | null;
};

export type UpdateUserPreferenceInput = {
  id: string;
  sUserId?: string | null;
  sProfilePicPath?: string | null;
  sOrder?: string | null;
  sNotification?: string | null;
  sInAppNotification?: string | null;
  sTheme?: string | null;
  sExchange?: string | null;
  sTenantId?: string | null;
  _version?: number | null;
};

export type DeleteUserPreferenceInput = {
  id?: string | null;
  _version?: number | null;
};

export type ModelAppInfoFilterInput = {
  id?: ModelIDInput | null;
  sParamName?: ModelStringInput | null;
  sParamValue?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelAppInfoFilterInput | null> | null;
  or?: Array<ModelAppInfoFilterInput | null> | null;
  not?: ModelAppInfoFilterInput | null;
};

export type ModelIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export type ModelMsgInfoFilterInput = {
  id?: ModelIDInput | null;
  sMsgCode?: ModelStringInput | null;
  sMessage?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelMsgInfoFilterInput | null> | null;
  or?: Array<ModelMsgInfoFilterInput | null> | null;
  not?: ModelMsgInfoFilterInput | null;
};

export type ModelNewWatchListProfileFilterInput = {
  id?: ModelIDInput | null;
  nWatchListId?: ModelIntInput | null;
  sWatchListName?: ModelStringInput | null;
  bIsPrivate?: ModelBooleanInput | null;
  bIsDefault?: ModelBooleanInput | null;
  sUserId?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelNewWatchListProfileFilterInput | null> | null;
  or?: Array<ModelNewWatchListProfileFilterInput | null> | null;
  not?: ModelNewWatchListProfileFilterInput | null;
};

export type ModelNewWatchListScripsFilterInput = {
  id?: ModelIDInput | null;
  nWatchListId?: ModelIntInput | null;
  nMarketSegmetId?: ModelIntInput | null;
  nToken?: ModelIntInput | null;
  nSequenceNo?: ModelIntInput | null;
  sUserId?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelNewWatchListScripsFilterInput | null> | null;
  or?: Array<ModelNewWatchListScripsFilterInput | null> | null;
  not?: ModelNewWatchListScripsFilterInput | null;
};

export type ModelUserPreferenceFilterInput = {
  id?: ModelIDInput | null;
  sUserId?: ModelStringInput | null;
  sProfilePicPath?: ModelStringInput | null;
  sOrder?: ModelStringInput | null;
  sNotification?: ModelStringInput | null;
  sInAppNotification?: ModelStringInput | null;
  sTheme?: ModelStringInput | null;
  sExchange?: ModelStringInput | null;
  sTenantId?: ModelStringInput | null;
  and?: Array<ModelUserPreferenceFilterInput | null> | null;
  or?: Array<ModelUserPreferenceFilterInput | null> | null;
  not?: ModelUserPreferenceFilterInput | null;
};

export type ModelStringKeyConditionInput = {
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
};

export enum ModelSortDirection {
  ASC = "ASC",
  DESC = "DESC"
}

export type ModelNewWatchListProfileByNewWatchListTenantCompositeKeyConditionInput = {
  eq?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
  le?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
  lt?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
  ge?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
  gt?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
  between?: Array<ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null> | null;
  beginsWith?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput | null;
};

export type ModelNewWatchListProfileByNewWatchListTenantCompositeKeyInput = {
  sUserId?: string | null;
  nWatchListId?: number | null;
};

export type CreateAppInfoMutation = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateAppInfoMutation = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteAppInfoMutation = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type CreateMsgInfoMutation = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateMsgInfoMutation = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteMsgInfoMutation = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type CreateNewWatchListProfileMutation = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateNewWatchListProfileMutation = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteNewWatchListProfileMutation = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type CreateNewWatchListScripsMutation = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateNewWatchListScripsMutation = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteNewWatchListScripsMutation = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type CreateUserPreferenceMutation = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateUserPreferenceMutation = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteUserPreferenceMutation = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type SyncAppInfosQuery = {
  __typename: "ModelAppInfoConnection";
  items: Array<{
    __typename: "AppInfo";
    id: string;
    sParamName: string;
    sParamValue: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type GetAppInfoQuery = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type ListAppInfosQuery = {
  __typename: "ModelAppInfoConnection";
  items: Array<{
    __typename: "AppInfo";
    id: string;
    sParamName: string;
    sParamValue: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type SyncMsgInfosQuery = {
  __typename: "ModelMsgInfoConnection";
  items: Array<{
    __typename: "MsgInfo";
    id: string;
    sMsgCode: string;
    sMessage: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type GetMsgInfoQuery = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type ListMsgInfosQuery = {
  __typename: "ModelMsgInfoConnection";
  items: Array<{
    __typename: "MsgInfo";
    id: string;
    sMsgCode: string;
    sMessage: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type SyncNewWatchListProfilesQuery = {
  __typename: "ModelNewWatchListProfileConnection";
  items: Array<{
    __typename: "NewWatchListProfile";
    id: string;
    nWatchListId: number;
    sWatchListName: string;
    bIsPrivate: boolean | null;
    bIsDefault: boolean | null;
    sUserId: string;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type GetNewWatchListProfileQuery = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type ListNewWatchListProfilesQuery = {
  __typename: "ModelNewWatchListProfileConnection";
  items: Array<{
    __typename: "NewWatchListProfile";
    id: string;
    nWatchListId: number;
    sWatchListName: string;
    bIsPrivate: boolean | null;
    bIsDefault: boolean | null;
    sUserId: string;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type SyncNewWatchListScripsQuery = {
  __typename: "ModelNewWatchListScripsConnection";
  items: Array<{
    __typename: "NewWatchListScrips";
    id: string;
    nWatchListId: number;
    nMarketSegmetId: number;
    nToken: number;
    nSequenceNo: number | null;
    sUserId: string;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type GetNewWatchListScripsQuery = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type ListNewWatchListScripssQuery = {
  __typename: "ModelNewWatchListScripsConnection";
  items: Array<{
    __typename: "NewWatchListScrips";
    id: string;
    nWatchListId: number;
    nMarketSegmetId: number;
    nToken: number;
    nSequenceNo: number | null;
    sUserId: string;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type SyncUserPreferencesQuery = {
  __typename: "ModelUserPreferenceConnection";
  items: Array<{
    __typename: "UserPreference";
    id: string;
    sUserId: string;
    sProfilePicPath: string | null;
    sOrder: string | null;
    sNotification: string | null;
    sInAppNotification: string | null;
    sTheme: string | null;
    sExchange: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type GetUserPreferenceQuery = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type ListUserPreferencesQuery = {
  __typename: "ModelUserPreferenceConnection";
  items: Array<{
    __typename: "UserPreference";
    id: string;
    sUserId: string;
    sProfilePicPath: string | null;
    sOrder: string | null;
    sNotification: string | null;
    sInAppNotification: string | null;
    sTheme: string | null;
    sExchange: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type AppInfoByTenantQuery = {
  __typename: "ModelAppInfoConnection";
  items: Array<{
    __typename: "AppInfo";
    id: string;
    sParamName: string;
    sParamValue: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type MsgInfoByTenantQuery = {
  __typename: "ModelMsgInfoConnection";
  items: Array<{
    __typename: "MsgInfo";
    id: string;
    sMsgCode: string;
    sMessage: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type NewWatchListByTenantQuery = {
  __typename: "ModelNewWatchListProfileConnection";
  items: Array<{
    __typename: "NewWatchListProfile";
    id: string;
    nWatchListId: number;
    sWatchListName: string;
    bIsPrivate: boolean | null;
    bIsDefault: boolean | null;
    sUserId: string;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type UserPreferenceByUserIdQuery = {
  __typename: "ModelUserPreferenceConnection";
  items: Array<{
    __typename: "UserPreference";
    id: string;
    sUserId: string;
    sProfilePicPath: string | null;
    sOrder: string | null;
    sNotification: string | null;
    sInAppNotification: string | null;
    sTheme: string | null;
    sExchange: string | null;
    sTenantId: string;
    _version: number;
    _deleted: boolean | null;
    _lastChangedAt: number;
    createdAt: string;
    updatedAt: string;
  } | null> | null;
  nextToken: string | null;
  startedAt: number | null;
};

export type OnCreateAppInfoSubscription = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateAppInfoSubscription = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteAppInfoSubscription = {
  __typename: "AppInfo";
  id: string;
  sParamName: string;
  sParamValue: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateMsgInfoSubscription = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateMsgInfoSubscription = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteMsgInfoSubscription = {
  __typename: "MsgInfo";
  id: string;
  sMsgCode: string;
  sMessage: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateNewWatchListProfileSubscription = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateNewWatchListProfileSubscription = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteNewWatchListProfileSubscription = {
  __typename: "NewWatchListProfile";
  id: string;
  nWatchListId: number;
  sWatchListName: string;
  bIsPrivate: boolean | null;
  bIsDefault: boolean | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateNewWatchListScripsSubscription = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateNewWatchListScripsSubscription = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteNewWatchListScripsSubscription = {
  __typename: "NewWatchListScrips";
  id: string;
  nWatchListId: number;
  nMarketSegmetId: number;
  nToken: number;
  nSequenceNo: number | null;
  sUserId: string;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateUserPreferenceSubscription = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateUserPreferenceSubscription = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteUserPreferenceSubscription = {
  __typename: "UserPreference";
  id: string;
  sUserId: string;
  sProfilePicPath: string | null;
  sOrder: string | null;
  sNotification: string | null;
  sInAppNotification: string | null;
  sTheme: string | null;
  sExchange: string | null;
  sTenantId: string;
  _version: number;
  _deleted: boolean | null;
  _lastChangedAt: number;
  createdAt: string;
  updatedAt: string;
};

@Injectable({
  providedIn: "root"
})
export class APIService {
  async CreateAppInfo(
    input: CreateAppInfoInput,
    condition?: ModelAppInfoConditionInput
  ): Promise<CreateAppInfoMutation> {
    const statement = `mutation CreateAppInfo($input: CreateAppInfoInput!, $condition: ModelAppInfoConditionInput) {
        createAppInfo(input: $input, condition: $condition) {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateAppInfoMutation>response.data.createAppInfo;
  }
  async UpdateAppInfo(
    input: UpdateAppInfoInput,
    condition?: ModelAppInfoConditionInput
  ): Promise<UpdateAppInfoMutation> {
    const statement = `mutation UpdateAppInfo($input: UpdateAppInfoInput!, $condition: ModelAppInfoConditionInput) {
        updateAppInfo(input: $input, condition: $condition) {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateAppInfoMutation>response.data.updateAppInfo;
  }
  async DeleteAppInfo(
    input: DeleteAppInfoInput,
    condition?: ModelAppInfoConditionInput
  ): Promise<DeleteAppInfoMutation> {
    const statement = `mutation DeleteAppInfo($input: DeleteAppInfoInput!, $condition: ModelAppInfoConditionInput) {
        deleteAppInfo(input: $input, condition: $condition) {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteAppInfoMutation>response.data.deleteAppInfo;
  }
  async CreateMsgInfo(
    input: CreateMsgInfoInput,
    condition?: ModelMsgInfoConditionInput
  ): Promise<CreateMsgInfoMutation> {
    const statement = `mutation CreateMsgInfo($input: CreateMsgInfoInput!, $condition: ModelMsgInfoConditionInput) {
        createMsgInfo(input: $input, condition: $condition) {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateMsgInfoMutation>response.data.createMsgInfo;
  }
  async UpdateMsgInfo(
    input: UpdateMsgInfoInput,
    condition?: ModelMsgInfoConditionInput
  ): Promise<UpdateMsgInfoMutation> {
    const statement = `mutation UpdateMsgInfo($input: UpdateMsgInfoInput!, $condition: ModelMsgInfoConditionInput) {
        updateMsgInfo(input: $input, condition: $condition) {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateMsgInfoMutation>response.data.updateMsgInfo;
  }
  async DeleteMsgInfo(
    input: DeleteMsgInfoInput,
    condition?: ModelMsgInfoConditionInput
  ): Promise<DeleteMsgInfoMutation> {
    const statement = `mutation DeleteMsgInfo($input: DeleteMsgInfoInput!, $condition: ModelMsgInfoConditionInput) {
        deleteMsgInfo(input: $input, condition: $condition) {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteMsgInfoMutation>response.data.deleteMsgInfo;
  }
  async CreateNewWatchListProfile(
    input: CreateNewWatchListProfileInput,
    condition?: ModelNewWatchListProfileConditionInput
  ): Promise<CreateNewWatchListProfileMutation> {
    const statement = `mutation CreateNewWatchListProfile($input: CreateNewWatchListProfileInput!, $condition: ModelNewWatchListProfileConditionInput) {
        createNewWatchListProfile(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateNewWatchListProfileMutation>(
      response.data.createNewWatchListProfile
    );
  }
  async UpdateNewWatchListProfile(
    input: UpdateNewWatchListProfileInput,
    condition?: ModelNewWatchListProfileConditionInput
  ): Promise<UpdateNewWatchListProfileMutation> {
    const statement = `mutation UpdateNewWatchListProfile($input: UpdateNewWatchListProfileInput!, $condition: ModelNewWatchListProfileConditionInput) {
        updateNewWatchListProfile(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateNewWatchListProfileMutation>(
      response.data.updateNewWatchListProfile
    );
  }
  async DeleteNewWatchListProfile(
    input: DeleteNewWatchListProfileInput,
    condition?: ModelNewWatchListProfileConditionInput
  ): Promise<DeleteNewWatchListProfileMutation> {
    const statement = `mutation DeleteNewWatchListProfile($input: DeleteNewWatchListProfileInput!, $condition: ModelNewWatchListProfileConditionInput) {
        deleteNewWatchListProfile(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteNewWatchListProfileMutation>(
      response.data.deleteNewWatchListProfile
    );
  }
  async CreateNewWatchListScrips(
    input: CreateNewWatchListScripsInput,
    condition?: ModelNewWatchListScripsConditionInput
  ): Promise<CreateNewWatchListScripsMutation> {
    const statement = `mutation CreateNewWatchListScrips($input: CreateNewWatchListScripsInput!, $condition: ModelNewWatchListScripsConditionInput) {
        createNewWatchListScrips(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateNewWatchListScripsMutation>(
      response.data.createNewWatchListScrips
    );
  }
  async UpdateNewWatchListScrips(
    input: UpdateNewWatchListScripsInput,
    condition?: ModelNewWatchListScripsConditionInput
  ): Promise<UpdateNewWatchListScripsMutation> {
    const statement = `mutation UpdateNewWatchListScrips($input: UpdateNewWatchListScripsInput!, $condition: ModelNewWatchListScripsConditionInput) {
        updateNewWatchListScrips(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateNewWatchListScripsMutation>(
      response.data.updateNewWatchListScrips
    );
  }
  async DeleteNewWatchListScrips(
    input: DeleteNewWatchListScripsInput,
    condition?: ModelNewWatchListScripsConditionInput
  ): Promise<DeleteNewWatchListScripsMutation> {
    const statement = `mutation DeleteNewWatchListScrips($input: DeleteNewWatchListScripsInput!, $condition: ModelNewWatchListScripsConditionInput) {
        deleteNewWatchListScrips(input: $input, condition: $condition) {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteNewWatchListScripsMutation>(
      response.data.deleteNewWatchListScrips
    );
  }
  async CreateUserPreference(
    input: CreateUserPreferenceInput,
    condition?: ModelUserPreferenceConditionInput
  ): Promise<CreateUserPreferenceMutation> {
    const statement = `mutation CreateUserPreference($input: CreateUserPreferenceInput!, $condition: ModelUserPreferenceConditionInput) {
        createUserPreference(input: $input, condition: $condition) {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateUserPreferenceMutation>response.data.createUserPreference;
  }
  async UpdateUserPreference(
    input: UpdateUserPreferenceInput,
    condition?: ModelUserPreferenceConditionInput
  ): Promise<UpdateUserPreferenceMutation> {
    const statement = `mutation UpdateUserPreference($input: UpdateUserPreferenceInput!, $condition: ModelUserPreferenceConditionInput) {
        updateUserPreference(input: $input, condition: $condition) {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateUserPreferenceMutation>response.data.updateUserPreference;
  }
  async DeleteUserPreference(
    input: DeleteUserPreferenceInput,
    condition?: ModelUserPreferenceConditionInput
  ): Promise<DeleteUserPreferenceMutation> {
    const statement = `mutation DeleteUserPreference($input: DeleteUserPreferenceInput!, $condition: ModelUserPreferenceConditionInput) {
        deleteUserPreference(input: $input, condition: $condition) {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteUserPreferenceMutation>response.data.deleteUserPreference;
  }
  async SyncAppInfos(
    filter?: ModelAppInfoFilterInput,
    limit?: number,
    nextToken?: string,
    lastSync?: number
  ): Promise<SyncAppInfosQuery> {
    const statement = `query SyncAppInfos($filter: ModelAppInfoFilterInput, $limit: Int, $nextToken: String, $lastSync: AWSTimestamp) {
        syncAppInfos(filter: $filter, limit: $limit, nextToken: $nextToken, lastSync: $lastSync) {
          __typename
          items {
            __typename
            id
            sParamName
            sParamValue
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (lastSync) {
      gqlAPIServiceArguments.lastSync = lastSync;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SyncAppInfosQuery>response.data.syncAppInfos;
  }
  async GetAppInfo(id: string): Promise<GetAppInfoQuery> {
    const statement = `query GetAppInfo($id: ID!) {
        getAppInfo(id: $id) {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetAppInfoQuery>response.data.getAppInfo;
  }
  async ListAppInfos(
    filter?: ModelAppInfoFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListAppInfosQuery> {
    const statement = `query ListAppInfos($filter: ModelAppInfoFilterInput, $limit: Int, $nextToken: String) {
        listAppInfos(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sParamName
            sParamValue
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListAppInfosQuery>response.data.listAppInfos;
  }
  async SyncMsgInfos(
    filter?: ModelMsgInfoFilterInput,
    limit?: number,
    nextToken?: string,
    lastSync?: number
  ): Promise<SyncMsgInfosQuery> {
    const statement = `query SyncMsgInfos($filter: ModelMsgInfoFilterInput, $limit: Int, $nextToken: String, $lastSync: AWSTimestamp) {
        syncMsgInfos(filter: $filter, limit: $limit, nextToken: $nextToken, lastSync: $lastSync) {
          __typename
          items {
            __typename
            id
            sMsgCode
            sMessage
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (lastSync) {
      gqlAPIServiceArguments.lastSync = lastSync;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SyncMsgInfosQuery>response.data.syncMsgInfos;
  }
  async GetMsgInfo(id: string): Promise<GetMsgInfoQuery> {
    const statement = `query GetMsgInfo($id: ID!) {
        getMsgInfo(id: $id) {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetMsgInfoQuery>response.data.getMsgInfo;
  }
  async ListMsgInfos(
    filter?: ModelMsgInfoFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListMsgInfosQuery> {
    const statement = `query ListMsgInfos($filter: ModelMsgInfoFilterInput, $limit: Int, $nextToken: String) {
        listMsgInfos(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sMsgCode
            sMessage
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListMsgInfosQuery>response.data.listMsgInfos;
  }
  async SyncNewWatchListProfiles(
    filter?: ModelNewWatchListProfileFilterInput,
    limit?: number,
    nextToken?: string,
    lastSync?: number
  ): Promise<SyncNewWatchListProfilesQuery> {
    const statement = `query SyncNewWatchListProfiles($filter: ModelNewWatchListProfileFilterInput, $limit: Int, $nextToken: String, $lastSync: AWSTimestamp) {
        syncNewWatchListProfiles(filter: $filter, limit: $limit, nextToken: $nextToken, lastSync: $lastSync) {
          __typename
          items {
            __typename
            id
            nWatchListId
            sWatchListName
            bIsPrivate
            bIsDefault
            sUserId
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (lastSync) {
      gqlAPIServiceArguments.lastSync = lastSync;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SyncNewWatchListProfilesQuery>(
      response.data.syncNewWatchListProfiles
    );
  }
  async GetNewWatchListProfile(
    id: string
  ): Promise<GetNewWatchListProfileQuery> {
    const statement = `query GetNewWatchListProfile($id: ID!) {
        getNewWatchListProfile(id: $id) {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetNewWatchListProfileQuery>response.data.getNewWatchListProfile;
  }
  async ListNewWatchListProfiles(
    filter?: ModelNewWatchListProfileFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListNewWatchListProfilesQuery> {
    const statement = `query ListNewWatchListProfiles($filter: ModelNewWatchListProfileFilterInput, $limit: Int, $nextToken: String) {
        listNewWatchListProfiles(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            nWatchListId
            sWatchListName
            bIsPrivate
            bIsDefault
            sUserId
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListNewWatchListProfilesQuery>(
      response.data.listNewWatchListProfiles
    );
  }
  async SyncNewWatchListScrips(
    filter?: ModelNewWatchListScripsFilterInput,
    limit?: number,
    nextToken?: string,
    lastSync?: number
  ): Promise<SyncNewWatchListScripsQuery> {
    const statement = `query SyncNewWatchListScrips($filter: ModelNewWatchListScripsFilterInput, $limit: Int, $nextToken: String, $lastSync: AWSTimestamp) {
        syncNewWatchListScrips(filter: $filter, limit: $limit, nextToken: $nextToken, lastSync: $lastSync) {
          __typename
          items {
            __typename
            id
            nWatchListId
            nMarketSegmetId
            nToken
            nSequenceNo
            sUserId
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (lastSync) {
      gqlAPIServiceArguments.lastSync = lastSync;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SyncNewWatchListScripsQuery>response.data.syncNewWatchListScrips;
  }
  async GetNewWatchListScrips(id: string): Promise<GetNewWatchListScripsQuery> {
    const statement = `query GetNewWatchListScrips($id: ID!) {
        getNewWatchListScrips(id: $id) {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetNewWatchListScripsQuery>response.data.getNewWatchListScrips;
  }
  async ListNewWatchListScripss(
    filter?: ModelNewWatchListScripsFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListNewWatchListScripssQuery> {
    const statement = `query ListNewWatchListScripss($filter: ModelNewWatchListScripsFilterInput, $limit: Int, $nextToken: String) {
        listNewWatchListScripss(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            nWatchListId
            nMarketSegmetId
            nToken
            nSequenceNo
            sUserId
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListNewWatchListScripssQuery>response.data.listNewWatchListScripss;
  }
  async SyncUserPreferences(
    filter?: ModelUserPreferenceFilterInput,
    limit?: number,
    nextToken?: string,
    lastSync?: number
  ): Promise<SyncUserPreferencesQuery> {
    const statement = `query SyncUserPreferences($filter: ModelUserPreferenceFilterInput, $limit: Int, $nextToken: String, $lastSync: AWSTimestamp) {
        syncUserPreferences(filter: $filter, limit: $limit, nextToken: $nextToken, lastSync: $lastSync) {
          __typename
          items {
            __typename
            id
            sUserId
            sProfilePicPath
            sOrder
            sNotification
            sInAppNotification
            sTheme
            sExchange
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (lastSync) {
      gqlAPIServiceArguments.lastSync = lastSync;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SyncUserPreferencesQuery>response.data.syncUserPreferences;
  }
  async GetUserPreference(id: string): Promise<GetUserPreferenceQuery> {
    const statement = `query GetUserPreference($id: ID!) {
        getUserPreference(id: $id) {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetUserPreferenceQuery>response.data.getUserPreference;
  }
  async ListUserPreferences(
    filter?: ModelUserPreferenceFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListUserPreferencesQuery> {
    const statement = `query ListUserPreferences($filter: ModelUserPreferenceFilterInput, $limit: Int, $nextToken: String) {
        listUserPreferences(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sUserId
            sProfilePicPath
            sOrder
            sNotification
            sInAppNotification
            sTheme
            sExchange
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListUserPreferencesQuery>response.data.listUserPreferences;
  }
  async AppInfoByTenant(
    sTenantId?: string,
    sParamName?: ModelStringKeyConditionInput,
    sortDirection?: ModelSortDirection,
    filter?: ModelAppInfoFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<AppInfoByTenantQuery> {
    const statement = `query AppInfoByTenant($sTenantId: String, $sParamName: ModelStringKeyConditionInput, $sortDirection: ModelSortDirection, $filter: ModelAppInfoFilterInput, $limit: Int, $nextToken: String) {
        appInfoByTenant(sTenantId: $sTenantId, sParamName: $sParamName, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sParamName
            sParamValue
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (sTenantId) {
      gqlAPIServiceArguments.sTenantId = sTenantId;
    }
    if (sParamName) {
      gqlAPIServiceArguments.sParamName = sParamName;
    }
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <AppInfoByTenantQuery>response.data.appInfoByTenant;
  }
  async MsgInfoByTenant(
    sTenantId?: string,
    sMsgCode?: ModelStringKeyConditionInput,
    sortDirection?: ModelSortDirection,
    filter?: ModelMsgInfoFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<MsgInfoByTenantQuery> {
    const statement = `query MsgInfoByTenant($sTenantId: String, $sMsgCode: ModelStringKeyConditionInput, $sortDirection: ModelSortDirection, $filter: ModelMsgInfoFilterInput, $limit: Int, $nextToken: String) {
        msgInfoByTenant(sTenantId: $sTenantId, sMsgCode: $sMsgCode, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sMsgCode
            sMessage
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (sTenantId) {
      gqlAPIServiceArguments.sTenantId = sTenantId;
    }
    if (sMsgCode) {
      gqlAPIServiceArguments.sMsgCode = sMsgCode;
    }
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <MsgInfoByTenantQuery>response.data.msgInfoByTenant;
  }
  async NewWatchListByTenant(
    sTenantId?: string,
    sUserIdNWatchListId?: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyConditionInput,
    sortDirection?: ModelSortDirection,
    filter?: ModelNewWatchListProfileFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<NewWatchListByTenantQuery> {
    const statement = `query NewWatchListByTenant($sTenantId: String, $sUserIdNWatchListId: ModelNewWatchListProfileByNewWatchListTenantCompositeKeyConditionInput, $sortDirection: ModelSortDirection, $filter: ModelNewWatchListProfileFilterInput, $limit: Int, $nextToken: String) {
        NewWatchListByTenant(sTenantId: $sTenantId, sUserIdNWatchListId: $sUserIdNWatchListId, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            nWatchListId
            sWatchListName
            bIsPrivate
            bIsDefault
            sUserId
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (sTenantId) {
      gqlAPIServiceArguments.sTenantId = sTenantId;
    }
    if (sUserIdNWatchListId) {
      gqlAPIServiceArguments.sUserIdNWatchListId = sUserIdNWatchListId;
    }
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <NewWatchListByTenantQuery>response.data.NewWatchListByTenant;
  }
  async UserPreferenceByUserId(
    sTenantId?: string,
    sUserId?: ModelStringKeyConditionInput,
    sortDirection?: ModelSortDirection,
    filter?: ModelUserPreferenceFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<UserPreferenceByUserIdQuery> {
    const statement = `query UserPreferenceByUserId($sTenantId: String, $sUserId: ModelStringKeyConditionInput, $sortDirection: ModelSortDirection, $filter: ModelUserPreferenceFilterInput, $limit: Int, $nextToken: String) {
        userPreferenceByUserId(sTenantId: $sTenantId, sUserId: $sUserId, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            sUserId
            sProfilePicPath
            sOrder
            sNotification
            sInAppNotification
            sTheme
            sExchange
            sTenantId
            _version
            _deleted
            _lastChangedAt
            createdAt
            updatedAt
          }
          nextToken
          startedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (sTenantId) {
      gqlAPIServiceArguments.sTenantId = sTenantId;
    }
    if (sUserId) {
      gqlAPIServiceArguments.sUserId = sUserId;
    }
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UserPreferenceByUserIdQuery>response.data.userPreferenceByUserId;
  }
  OnCreateAppInfoListener: Observable<
    SubscriptionResponse<OnCreateAppInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnCreateAppInfo {
        onCreateAppInfo {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnCreateAppInfoSubscription>>;

  OnUpdateAppInfoListener: Observable<
    SubscriptionResponse<OnUpdateAppInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnUpdateAppInfo {
        onUpdateAppInfo {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnUpdateAppInfoSubscription>>;

  OnDeleteAppInfoListener: Observable<
    SubscriptionResponse<OnDeleteAppInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnDeleteAppInfo {
        onDeleteAppInfo {
          __typename
          id
          sParamName
          sParamValue
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnDeleteAppInfoSubscription>>;

  OnCreateMsgInfoListener: Observable<
    SubscriptionResponse<OnCreateMsgInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnCreateMsgInfo {
        onCreateMsgInfo {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnCreateMsgInfoSubscription>>;

  OnUpdateMsgInfoListener: Observable<
    SubscriptionResponse<OnUpdateMsgInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnUpdateMsgInfo {
        onUpdateMsgInfo {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnUpdateMsgInfoSubscription>>;

  OnDeleteMsgInfoListener: Observable<
    SubscriptionResponse<OnDeleteMsgInfoSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnDeleteMsgInfo {
        onDeleteMsgInfo {
          __typename
          id
          sMsgCode
          sMessage
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnDeleteMsgInfoSubscription>>;

  OnCreateNewWatchListProfileListener: Observable<
    SubscriptionResponse<OnCreateNewWatchListProfileSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnCreateNewWatchListProfile {
        onCreateNewWatchListProfile {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<
    SubscriptionResponse<OnCreateNewWatchListProfileSubscription>
  >;

  OnUpdateNewWatchListProfileListener: Observable<
    SubscriptionResponse<OnUpdateNewWatchListProfileSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnUpdateNewWatchListProfile {
        onUpdateNewWatchListProfile {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<
    SubscriptionResponse<OnUpdateNewWatchListProfileSubscription>
  >;

  OnDeleteNewWatchListProfileListener: Observable<
    SubscriptionResponse<OnDeleteNewWatchListProfileSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnDeleteNewWatchListProfile {
        onDeleteNewWatchListProfile {
          __typename
          id
          nWatchListId
          sWatchListName
          bIsPrivate
          bIsDefault
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<
    SubscriptionResponse<OnDeleteNewWatchListProfileSubscription>
  >;

  OnCreateNewWatchListScripsListener: Observable<
    SubscriptionResponse<OnCreateNewWatchListScripsSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnCreateNewWatchListScrips {
        onCreateNewWatchListScrips {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnCreateNewWatchListScripsSubscription>>;

  OnUpdateNewWatchListScripsListener: Observable<
    SubscriptionResponse<OnUpdateNewWatchListScripsSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnUpdateNewWatchListScrips {
        onUpdateNewWatchListScrips {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnUpdateNewWatchListScripsSubscription>>;

  OnDeleteNewWatchListScripsListener: Observable<
    SubscriptionResponse<OnDeleteNewWatchListScripsSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnDeleteNewWatchListScrips {
        onDeleteNewWatchListScrips {
          __typename
          id
          nWatchListId
          nMarketSegmetId
          nToken
          nSequenceNo
          sUserId
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnDeleteNewWatchListScripsSubscription>>;

  OnCreateUserPreferenceListener: Observable<
    SubscriptionResponse<OnCreateUserPreferenceSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnCreateUserPreference {
        onCreateUserPreference {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnCreateUserPreferenceSubscription>>;

  OnUpdateUserPreferenceListener: Observable<
    SubscriptionResponse<OnUpdateUserPreferenceSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnUpdateUserPreference {
        onUpdateUserPreference {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnUpdateUserPreferenceSubscription>>;

  OnDeleteUserPreferenceListener: Observable<
    SubscriptionResponse<OnDeleteUserPreferenceSubscription>
  > = API.graphql(
    graphqlOperation(
      `subscription OnDeleteUserPreference {
        onDeleteUserPreference {
          __typename
          id
          sUserId
          sProfilePicPath
          sOrder
          sNotification
          sInAppNotification
          sTheme
          sExchange
          sTenantId
          _version
          _deleted
          _lastChangedAt
          createdAt
          updatedAt
        }
      }`
    )
  ) as Observable<SubscriptionResponse<OnDeleteUserPreferenceSubscription>>;
}
