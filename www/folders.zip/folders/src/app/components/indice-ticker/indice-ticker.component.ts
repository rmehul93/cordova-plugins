import { clsHttpService } from './../../Common/clsHTTPService';
import { Component, Input, OnInit } from '@angular/core';
import { NavController, Platform, PopoverController } from '@ionic/angular';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { IndicesTickerPopoverComponent } from '../indices-ticker-popover/indices-ticker-popover.component';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-indice-ticker',
  templateUrl: './indice-ticker.component.html',
})
export class IndiceTickerComponent implements OnInit {

  @Input("Type") tickerType: any="Text"; //script objcet to create order entry.
  showIndicesSelection: boolean = false;
  showticker: boolean = true;
  showtickerCard: boolean = false;
  showtickerSetting :boolean = false;
  showSelectpopup: boolean = false;

  selTickerObj: any = {};
  bcastHandler: any;
  templocalIndicesScripts: Dictionary<any> = new Dictionary<any>();
  localScripKey: any = [];
  listExchange: any = [];
  localIndexDetailsList: any = [];
  selTickerList = [];
  selIndice: any = {};
  selExchange = '';
  selIndex = -1;
  exchIndicesList = [];
  showExchange: boolean = false;
  //allExchange = [];

  //search variables
  searchTextChooseIndices:any  = '';
  showSearchChooseIndices:boolean = false;
  chooseIndicesSearchData:any = [];
  showSegments: boolean = false;
  searchTextChangedChooseIndices = new Subject<string>();
  subscriptionChooseIndices :any;
  searchTextEnteredChooseIndices:any='';
  isDataLoaded =false;

  constructor(private navCtrl: NavController,
    private httpService: clsHttpService,
    private localstorageservice: clsLocalStorageService,
    public popoverController: PopoverController,
    public objStorage: clsLocalStorageService,
    public platform: Platform,
    public loadingCtrl: LoaderServicesProvider,
    public speechRecognition: SpeechRecognition,
    public toastProvider: ToastServicesProvider,
    private router: Router) {

      // this.router.events.subscribe(event => {
      //   console.log('Event: ' + event);
      // });

     }

  ngOnInit() {
    // this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    // clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
    this.getAllDomesticIndices();
    this.subscriptionChooseIndices = this.searchTextChangedChooseIndices.pipe(debounceTime(500), distinctUntilChanged()
      ).subscribe(search => this.getValuesChooseIndices(search));
  }

  /** <Norwin Dcruz> <01/12/2020> <To get Domestic Indices> **/
  getAllDomesticIndices() {
    try {
      if (clsGlobal.User.isLocal == true) {
        clsGlobal.lstAllIndicesList = [];
        clsGlobal.User.isLocal = false;
      }
      this.localIndexDetailsList = [];
      if (clsGlobal.lstAllIndicesList.length > 0) {
        for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {

          let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
          let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);

          if (clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1) {
            clsGlobal.lstIndicesExchange.push(exchangeName);
          }

          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
          objScrpKey.MktSegId = marketSegmentId

          let indexScrip: any = {};
          indexScrip = {};
          indexScrip.nToken = clsGlobal.lstAllIndicesList[index].nToken;
          indexScrip.nMarketSegmentId = marketSegmentId;
          indexScrip.Exchange = exchangeName;
          indexScrip.LTP = "0.00";
          indexScrip.NetChangeInRs = "0.00";
          indexScrip.LTPTrend = '';
          indexScrip.colorTrend = '';
          indexScrip.PercNetChange = "0.00";
          indexScrip.sIndexDesc = clsGlobal.lstAllIndicesList[index].sIndexDesc;

          if ((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == clsConstants.C_V_NSE_CASH.toString()) ||
            (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == clsConstants.C_V_MAPPED_BSE_CASH.toString())) {
            indexScrip.hidefavourite = false;
          }
          else {
            indexScrip.hidefavourite = true;
          }

          indexScrip.Favourite = (clsGlobal.lstAllIndicesList[index].Favourite == undefined ? false : clsGlobal.lstAllIndicesList[index].Favourite);
          indexScrip.Count = index;
          indexScrip.Global = false;
          indexScrip.isDate = false;

          this.templocalIndicesScripts.Add(objScrpKey.toString(), indexScrip);
        }
        //this.currentExchange = clsGlobal.lstIndicesExchange[0];
        this.listExchange = clsGlobal.lstIndicesExchange;
        //this.getIndexOnExchange();
        this.loadTickerIndices();
      }
      else {
        this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + clsGlobal.versionId + "/getIndexDetails").subscribe((respData: any) => {
          try {
            if (respData.status) {
              clsGlobal.lstAllIndicesList = respData.result;

              for (let index = 0; index < clsGlobal.lstAllIndicesList.length; index++) {

                let marketSegmentId = clsTradingMethods.GetMarketSegmentID(clsGlobal.lstAllIndicesList[index].nMarketSegmentId);
                let exchangeName = clsTradingMethods.getExchangeName(marketSegmentId);

                if (clsGlobal.lstIndicesExchange.indexOf(exchangeName) == -1) {
                  clsGlobal.lstIndicesExchange.push(exchangeName)
                }

                let objScrpKey: clsScripKey = new clsScripKey();
                objScrpKey.token = clsGlobal.lstAllIndicesList[index].nToken;
                objScrpKey.MktSegId = marketSegmentId

                let indexScrip: any = {};
                indexScrip = {};
                indexScrip.nToken = clsGlobal.lstAllIndicesList[index].nToken;
                indexScrip.nMarketSegmentId = marketSegmentId;
                indexScrip.Exchange = exchangeName;
                indexScrip.scripKey = objScrpKey;
                indexScrip.LTP = "0.00";
                indexScrip.NetChangeInRs = "0.00";
                indexScrip.LTPTrend = '';
                indexScrip.colorTrend = '';
                indexScrip.PercNetChange = "0.00";
                indexScrip.sIndexDesc = clsGlobal.lstAllIndicesList[index].sIndexDesc;

                if ((clsGlobal.lstAllIndicesList[index].nToken == '26000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == clsConstants.C_V_NSE_CASH.toString()) ||
                  (clsGlobal.lstAllIndicesList[index].nToken == '19000' && clsGlobal.lstAllIndicesList[index].nMarketSegmentId == clsConstants.C_V_MAPPED_BSE_CASH.toString())) {
                  indexScrip.hidefavourite = false;
                }
                else {
                  indexScrip.hidefavourite = true;
                }

                indexScrip.Favourite = false;
                indexScrip.Count = index;
                indexScrip.Global = false;
                indexScrip.isDate = false;

                this.templocalIndicesScripts.Add(objScrpKey.toString(), indexScrip);
              }
              //this.currentExchange = clsGlobal.lstIndicesExchange[0];
              this.listExchange = clsGlobal.lstIndicesExchange;
              //this.getIndexOnExchange();
              this.loadTickerIndices();
            }
          } catch (error) {
            console.log(error);
          }
        },
          error => {
            clsGlobal.logManager.writeErrorLog('IndiceTicker', 'getAllDomesticIndices', error);
          }
        );
      }
    } catch (error) {
      console.log(error);
    }
  }

  loadTickerIndices() {
    try {
      this.localScripKey = [];
      //let userId = clsGlobal.User.userId;
      let keyIndices = clsGlobal.User.userId + "_" + clsConstants.LOCAL_STORAGE_INDICES_TICKER;
      this.localstorageservice.getItem(keyIndices).then(indices => {
        if (indices == undefined) {

          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = "26000";
          objScrpKey.MktSegId = 1;
          let indexScrip = this.templocalIndicesScripts.getItem(objScrpKey.toString());
          if (indexScrip != undefined) {
            this.selTickerList.push(indexScrip);
          }

          objScrpKey.token = "19000";
          objScrpKey.MktSegId = 3;
          indexScrip = this.templocalIndicesScripts.getItem(objScrpKey.toString());
          if (indexScrip != undefined) {
            this.selTickerList.push(indexScrip);
          }

          if (this.selTickerList.length == 0) {
            this.selTickerList.push(this.templocalIndicesScripts.Values()[0]);
            this.selTickerList.push(this.templocalIndicesScripts.Values()[0]);
          }

          this.localstorageservice.setObject(keyIndices, this.selTickerList);

        } else {
          this.selTickerList = JSON.parse(indices) || [];
        }

        for (let index = 0; index < this.selTickerList.length; index++) {
          const element = this.selTickerList[index];
          let objScrpKey: clsScripKey = new clsScripKey();
          objScrpKey.token = element.nToken;
          objScrpKey.MktSegId = element.nMarketSegmentId;
          this.localScripKey.push(objScrpKey)
        }

        this.isDataLoaded =true;
        //this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);

      })
    } catch (error) {

    }
  }

  /**
   * send request for broadcast
   * @param opType
   * @param scripList
   */
  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('IndiceTicker', 'sendTouchlineRequest', error);
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {

    try {
      let nFormat = 2;
      if (objMultiTLResp != null && this.selTickerList != undefined) {

        for (let index = 0; index < this.selTickerList.length; index++) {
          const element = this.selTickerList[index];
          if (element.nToken.toString() == objMultiTLResp.Scrip.token
            && element.nMarketSegmentId == objMultiTLResp.Scrip.MktSegId) {

            nFormat = 2;
            element.LTP = objMultiTLResp.LTP;
            let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, nFormat, false, 'arrow');
            element.NetChangeInRs = arrNetChange[0];
            element.PercNetChange = arrNetChange[1];
            element.colorTrend = arrNetChange[2];
            element.LTPTrend = arrNetChange[2];
            break;
          }
        }
        
      }
    }
    catch (error) {
      console.log('IndiceTicker', 'receiveTouchlineResponse', error);
    }

  }

  showTickerCard() {
    this.showtickerCard = true;
  }

  marketTickerFull() {
    this.showtickerSetting = false;
    this.showIndicesSelection = true;
  }


  async clickPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: IndicesTickerPopoverComponent,
      event: ev,
      translucent: true,
      cssClass: 'ticker-popup',
      mode: "ios",
      backdropDismiss: true,
      componentProps: {
        'selIndices': this.selTickerList,
        'allIndices': this.templocalIndicesScripts.Values(),
        'exchanges' :this.listExchange
      }
    });
    await popover.present();
    popover.onDidDismiss().then((result:any) => {
      if (result.data != undefined && result.data.showtickerSetting == true ) {
         this.showtickerSetting = true;
      }
      else {
        //this.showEventDetails();
      }
    });
  }

  ngOnDestroy(): void {
    //if (!this.isFromOrderEntry) {
    //this.ionViewWillLeave();
    //}
  }

  closeTickerSetting() {
    this.showIndicesSelection = false;
    this.showtickerSetting = false;
    this.showtickerCard = true;
  }

  marketTickerClose() {
    this.showIndicesSelection = false;
    this.showtickerSetting = true;
    this.showtickerCard = false;
  }

  changeTickerScrip(idxItem, index) {
    try {

      this.showIndicesSelection = true;
      this.showtickerSetting = false;
      this.showtickerCard = false;
      this.selIndice = idxItem;
      this.selIndex = index;
      this.selExchange = this.selIndice.Exchange;
      let lstExchnages = this.templocalIndicesScripts.Values();
      this.exchIndicesList = lstExchnages.filter(itemIndex => {
        return itemIndex.Exchange == idxItem.Exchange;
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'changeTickerScrip', error);
    }
  }

  showExchangePopUp() {

    this.showExchange = !this.showExchange;
  }

  toggleExchange(sExchange) {
    try {
      this.showExchange = !this.showExchange;

      if (this.selExchange != sExchange) {
        this.selExchange = sExchange;
        let lstExchnages = this.templocalIndicesScripts.Values();
        this.exchIndicesList = lstExchnages.filter(itemIndex => {
          return itemIndex.Exchange == sExchange;
        });
      }

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'toggleExchange', error);
    }
  }

  setSelectedIndices(item) {
    try {

      let itemIdx = this.selTickerList[this.selIndex];

      if (itemIdx.sIndexDesc != item.sIndexDesc) {
        this.selTickerList[this.selIndex] = item;

        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = itemIdx.nToken;
        objScrpKey.MktSegId = itemIdx.nMarketSegmentId;
        let scrpLst = [];
        scrpLst.push(objScrpKey);
        this.sendTouchlineRequest(OperationType.REMOVE, scrpLst);

        objScrpKey.token = item.nToken;
        objScrpKey.MktSegId = item.nMarketSegmentId;
        scrpLst = [];
        scrpLst.push(objScrpKey);
        this.sendTouchlineRequest(OperationType.ADD, scrpLst);

        let keyIndices = clsGlobal.User.userId + "_" + clsConstants.LOCAL_STORAGE_INDICES_TICKER;
        this.localstorageservice.setObject(keyIndices,(this.selTickerList));
        
      }
      this.clearSearchChooseIndices();
      this.hideSearchPopupChooseIndices();
      this.marketTickerClose();

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'setSelectedIndices', error);
    }
  }

  ionViewWillEnter(){
    if(this.isDataLoaded){

      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);

      this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
    }else{
      setTimeout(() => {
        this.ionViewWillEnter();
      }, 10);
    }
    //this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
  }


  ionViewWillLeave() {
    clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.showIndicesSelection = false;
    //this.showticker = false;
    this.showtickerCard = false;
    this.showtickerSetting = false;
    this.showSelectpopup = false;

  }
  
  showSearchPopupChooseIndices() {
    try{
      this.searchTextChooseIndices = '';
      this.showSearchChooseIndices = true;
      this.chooseIndicesSearchData = [];
    }catch(error){
       clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'showSearchPopupChooseIndices', error.message);
    }
  }
  hideSearchPopupChooseIndices() {
    try{
      this.showSearchChooseIndices = false;
      this.searchTextChooseIndices = '';
      this.chooseIndicesSearchData = [];
      this.showSegments = false;
    }catch(error){
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'hideSearchPopupChooseIndices', error.message);
    }
  }

  searchTextEnter(){
    try{
      if(this.searchTextChooseIndices.length > 0 ){
        this.showSegments = true;
      }else{
        this.showSegments = false;
      }
    }catch(error){
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'searchTextEnter', error.message);
    }
  }

  searchChooseIndices(event){
    try{
      if (event) {
        this.searchTextChooseIndices = event.toUpperCase();
       // this.searchTextChangedReco.next(event);
       } 
      this.searchTextChangedChooseIndices.next(event);
    }catch(error){
       clsGlobal.logManager.writeErrorLog('RecommendationPage', 'searchReco', error.message);
    }
  }


  getValuesChooseIndices(search) {
    try {
     
      if(search == '')
      {
        this.clearSearchChooseIndices();
        return; 
      }
      
      if (search.length < 1) {
        this.searchTextEnteredChooseIndices = '';
        return;
      }
      this.searchTextEnteredChooseIndices = search.toUpperCase();
       let chooseIndicesSearchList = [];
      for (let counter = 0; counter < this.exchIndicesList.length; counter++) {
        if(this.exchIndicesList[counter].sIndexDesc){
          let indexDesc = this.exchIndicesList[counter].sIndexDesc.toUpperCase();
          if (indexDesc.includes(this.searchTextEnteredChooseIndices)) {
            chooseIndicesSearchList.push(this.exchIndicesList[counter]);
          }
        }  
      }
      this.chooseIndicesSearchData = chooseIndicesSearchList;
      
      if(this.chooseIndicesSearchData.length == 0)
      { 
       // this.noDataFoundRecoSearch = true;
        this.chooseIndicesSearchData = []
        return;
      }
      
      this.showSegments = true;
      

    }catch(error){
      
       clsGlobal.logManager.writeErrorLog('RecommendationPage', 'getValuesReco', error.message);
    }
  }

  clearSearchChooseIndices(){
    try{
      this.searchTextChooseIndices = '';
      this.chooseIndicesSearchData = [];
      this.showSegments = false;
      //this.noDataFoundRecoSearch = false;
    }catch(error){
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'clearSearchChooseIndices', error.message);
    }
  }


  checkVoiceString: any;
  ShowVoiceModel() {
    this.searchTextChooseIndices = '';
 
    this.checkVoiceString = '';
    this.speechRecognition.isRecognitionAvailable().then((available: boolean) => {
      if (available) {
        this.speechRecognition.hasPermission()
          .then((hasPermission: boolean) => {
            if (hasPermission)
              this.VoiceStartListening();
            else {
              this.speechRecognition.requestPermission()
                .then(
                  () => {
                    console.log('Granted');
                    this.VoiceStartListening();
                  },
                  () => {
                    console.log('Denied');
                    this.toastProvider.showAtBottom("you need to give permission for voice.");
                  }
                )


            }
          });
      }
      else {
        this.toastProvider.showAtBottom("microphone not available.");
      }
    });
  }

  VoiceStartListening() {
    if (this.platform.is('android')) {
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            this.searchChooseIndices(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            console.log("Error" + onerror);
          }
        );
    }
    else {
      this.loadingCtrl.showLoaderforText();
      let options: any = {};
      this.speechRecognition.startListening(options)
        .subscribe(
          (matches: String[]) => {
            //alert("String "+matches[0].toString())
            this.loadingCtrl.hideLoaderforText();
            this.checkVoiceString = matches[0].toString();
            this.searchChooseIndices(this.voiceSearchMaching(matches[0].toString()));
          },
          (onerror) => {
            //alert("Error "+onerror)
            //this.alertProvider.presentAlert("Error in voice command", onerror)
            this.loadingCtrl.hideLoaderforText();
            console.log("Error" + onerror);
          }
        );
      setTimeout(() => {
        this.loadingCtrl.hideLoaderforText();
        this.speechRecognition.stopListening();
        setTimeout(() => {
          if (this.checkVoiceString == '' || this.checkVoiceString == undefined) {
            this.toastProvider.showAtBottom("Voice not captured. Try saying something again")
          }
        }, 1000)
      }, 3000);
    }

  }

  // searchVoiceText(text) {
  //   if (text != undefined || text != '') {
  //     this.searchText = text.toUpperCase().trim();
  //     this.searchTextChanged.next(this.searchText);
  //     this.recentlySearched = false;
  //     this.showTrending = false;
  //     this.showRecommendations = false;
  //   } else {
  //     this.loadRecentScripts();
  //     this.getHotpursuitData();
  //   }
  // }

  VoiceHasPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        return hasPermission;
      });
  }

  voiceSearchMaching(text: any) {
    var _text = text.toString().toUpperCase().trim();
    _text = _text.replace("JANUARY", "JAN").
      replace("FEBRUARY", "FEB").
      replace("MARCH", "MAR").
      replace("APRIL", "APR").
      replace("JUNE", "JUN").
      replace("JULY", "JUL").
      replace("AUGUST", "AUG").
      replace("SEPTEMBER", "SEP").
      replace("OCTOBER", "OCT").
      replace("NOVEMBER", "NOV").
      replace("DECEMBER", "DEC").
      replace("FUTURES", "FUT").
      replace("FUTURE", "FUT").
      replace("OPTIONS", "OPT").
      replace("OPTION", "OPT");
    return _text.toUpperCase();
  }
}
