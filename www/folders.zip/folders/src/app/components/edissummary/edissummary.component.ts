import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { LoadingController, ModalController, NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { LoaderServicesProvider } from 'src/app/providers/loader-services/loader-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { clsScrip } from 'src/app/Common/clsScrip';

@Component({
  selector: 'app-edissummary',
  templateUrl: './edissummary.component.html',
  styleUrls: ['./edissummary.component.scss'],
  //changeDetection: ChangeDetectionStrategy.OnPush
})
export class EDISSummaryComponent implements OnInit, OnDestroy {

  showSuccess = false;
  objCDSL: any = {};
  iRequestValue: any = 0;
  iRequestCount = 0;
  iPerDayTransactionvalue = 0;
  iValueUtilized = 0;
  iSingleTranValue = 0;
  iCBDisabledCount = 0;
  iMaxCount = 0;
  dematAccNo = '';

  arrSummaryData = [];
  DPDetails: any = [];
  quantityToHold: any = '';
  originalQty: any = 0;
  arryReqValidationData: any = [];
  boolIsAllRecSelected = false;
  isIndeterminate: boolean = false;
  iCBCheckedCount: any = 0;
  boolEnbDisBtnAuth = false;
  iRadBtnCondition = 2;
  arrReqValidData = [];

  openwindowobj;
  iInterval: any = 0;
  submitIsInProgress = false;
  boolNoRecFound = false;
  selectedScripDisp = '0 Scrip(s)';

  @Input() scrip: clsScrip;
  @Input() Qty: any = 0;
  scripObject: clsScrip;
  showNoDataFound = false;
  interopOnOffFlag = false;

  EDISReqRes: any = { eDISReqId: "", sISINCode: "", sDepository: "", sDPId: "", sMktsegId: "", sToken: "", nTotalAvailableQty: "", nApprovedFreeQty: "", nOrderQty: "", status: "" }

  constructor(private alertProvider: AlertServicesProvider,
    private navCtrl: NavController,
    private toastCtrl: ToastServicesProvider,
    private loadCtrl: LoaderServicesProvider,
    private iab: InAppBrowser,
    private tranServ: TransactionService,
    //public navParam: NavParams,
    public modalCtrl: ModalController,
    //private cdr: ChangeDetectorRef
  ) {
    //this.scripObject = this.navParam.get("scrip");
    //this.originalQty = this.Qty;//this.navParam.get("Qty");
  }

  ngOnDestroy(): void {
    window.removeEventListener('message', (evt: any) => { });
  }

  ngOnInit() {
    this.getInteropSetting();
  }

  ngAfterViewInit() {
    //this.cdr.detectChanges();
    this.scripObject = this.scrip;
    this.originalQty = this.Qty;
    if (clsGlobal.User.DPDetails && clsGlobal.User.DPDetails.length > 0) {

      //clsGlobal.User.DPDetails[0].URL != '' && 
      if (clsGlobal.User.DPDetails[0].sDepository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_CDSL &&
        clsGlobal.User.DPDetails[0].sDPId != '' &&
        clsGlobal.User.DPDetails[0].nBeneficiaryAccountNumber != '') {
        this.objCDSL.boolInteropOnOffFlag = false;
        this.getDefaultExchange();
        this.getSummaryData();
        this.dematAccNo = clsGlobal.User.DPDetails[0].sDPId;
      }

      //this.getSummaryData();
      window.addEventListener('message', (evt: any) => {
        if (evt && evt.data) {
          //console.log('EDIS Response: ', evt.data);
          if (evt.data.respdata != undefined) {
            let jsonData = JSON.parse(evt.data.respdata);
            if (jsonData.Status == "Success")
              this.processEDISResponse(jsonData, undefined);
          }
        }
      });

    } else {
      this.toastCtrl.showAtBottom("DP detais not available.");
    }
  }

  async getInteropSetting() {
    try {

      this.interopOnOffFlag = false;
      if (!clsGlobal.User.interopSettingDetails) {
        await this.tranServ.getIntropConfiguration().then((intropConfigResponse: any) => {
          if (intropConfigResponse.status == 'success') {
            clsGlobal.User.interopSettingDetails = intropConfigResponse.data;
            for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
              if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1 &&
                (clsGlobal.User.interopSettingDetails[cnt].nCombinedSegmentId == clsConstants.C_V_COMBINED_CASH) &&
                (clsGlobal.User.interopSettingDetails[cnt].sSegment == clsConstants.C_S_CASH_TEXT)) {
                this.objCDSL.MarketSegmentId = clsGlobal.User.interopSettingDetails[cnt].nCombinedSegmentId;
                this.interopOnOffFlag = true;
              }
            }
          } else {

          }
        }, error => {

        });
      } else {
        for (var cnt = 0; cnt < clsGlobal.User.interopSettingDetails.length; cnt++) {
          if (clsGlobal.User.interopSettingDetails[cnt].nInteropPreferredCCL != -1 &&
            (clsGlobal.User.interopSettingDetails[cnt].nCombinedSegmentId == clsConstants.C_V_COMBINED_CASH) &&
            (clsGlobal.User.interopSettingDetails[cnt].sSegment == clsConstants.C_S_CASH_TEXT)) {
            this.objCDSL.MarketSegmentId = clsGlobal.User.interopSettingDetails[cnt].nCombinedSegmentId;
            this.interopOnOffFlag = true;
          }
        }
      }
    } catch (error) {

    }
  }

  getDefaultExchange() {
    try {

      if (clsGlobal.ExchManager.loginAllowed.getItem(clsConstants.C_V_NSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.objCDSL.ExchangeName = clsConstants.C_S_NSE_EXCHANGE_TEXT;
        this.objCDSL.MarketSegmentId = clsConstants.C_V_MAPPED_NSE_CASH;
      }
      else if (clsGlobal.ExchManager.loginAllowed.getItem(clsConstants.C_V_BSE_CASH.toString()) == clsConstants.C_S_ON) {
        this.objCDSL.ExchangeName = clsConstants.C_S_BSE_EXCHANGE_TEXT;
        this.objCDSL.MarketSegmentId = clsConstants.C_V_MAPPED_BSE_CASH;
      }
      else {
        this.toastCtrl.showAtBottom("No EQ segment allowed.");
      }

    } catch (error) {

    }
  }

  getSummaryData() {
    try {

      let sellQty = this.originalQty;
      //let mtSegId = this.scripObject == undefined ? -1 : this.scripObject.scripDet.MapMktSegId;
      let mtSegId = this.interopOnOffFlag ? clsConstants.C_V_COMBINED_CASH : -1;
      let token = this.scripObject == undefined ? -1 : this.scripObject.scripDet.token;
      let depository = clsGlobal.User.DPDetails[0].sDepository;
      let summaryMktSegId = this.scripObject == undefined ? -1 : this.scripObject.scripDet.MapMktSegId;

      this.loadCtrl.showLoader(true).then(() => {


        this.tranServ.getEDISSummaryDetails(sellQty, mtSegId, token, depository, summaryMktSegId).then((summaryData: any) => {
          this.loadCtrl.hideLoader();
          //console.log("Data: ", summaryData);
          if (summaryData.status == 'Success') {

            if (summaryData.data.ResponseStatus) {

              this.arrSummaryData = summaryData.data.DPQtyTable;
              this.arryReqValidationData = summaryData.data.EDISCDSLValidation[0];
              this.DPDetails = clsGlobal.User.DPDetails[0];

              if (this.arrSummaryData.length == 0) {
                this.showNoDataFound = true;
              } else {
                this.showNoDataFound = false;
              }

              if (summaryData.data.DPDetail != undefined) {
                this.DPDetails.ISIN = summaryData.data.DPDetail.ISIN;
                this.DPDetails.QuantityToHold = summaryData.data.DPDetail.QuantityToHold == -1 ? this.originalQty : summaryData.data.DPDetail.QuantityToHold;
                this.DPDetails.SecurityDescription = summaryData.data.DPDetail.SecurityDescription;
              }

              setTimeout(() => {

                for (let index = 0; index < this.arrSummaryData.length; index++) {

                  const element = this.arrSummaryData[index];
                  element.boolIsCBDisabled = false;
                  element.boolIsInputDisabled = false;
                  element.boolIsOrderSelected = true;
                  element.nEDISQty = 0;
                  element.showInvalidQty = false;

                  if (element.sISINCode == this.DPDetails.ISIN) {
                    element.nEDISQty = this.getMaxQty(element.eDISRequestQty, element.eDISCheckQty, this.originalQty);
                    element.boolIsCBDisabled = this.setCheckBoxDisabled(element);
                    //element.boolIsInputDisabled = true;
                  }
                  else
                    element.nEDISQty = this.getMaxQty(element.eDISRequestQty, element.eDISCheckQty, 0);

                }

                if (this.arrSummaryData.length > 0) {
                  this.boolIsAllRecSelected = true;
                  this.boolEnbDisBtnAuth = true;
                  this.iCBCheckedCount = this.arrSummaryData.length;

                  if (this.DPDetails.ISIN != undefined && this.DPDetails.ISIN != null && this.DPDetails.ISIN != "") {
                    this.arrSummaryData.forEach((value, index) => {
                      if (value.sISINCode === this.DPDetails.ISIN) {
                        this.arrSummaryData.splice(index, 1);
                        this.arrSummaryData.unshift(value);
                      }
                    });
                  }
                }

                this.selectedScripDisp = this.iCBCheckedCount + ' Scrip(s)'

              }, 10);

              if (this.arryReqValidationData != undefined) {
                this.iRequestCount = this.arryReqValidationData.UserTranCount;
                this.iPerDayTransactionvalue = this.arryReqValidationData.PerDayTransactionvalue;
                this.iValueUtilized = this.arryReqValidationData.ValueUtilized;
                this.iMaxCount = this.arryReqValidationData.MaxTranCount;
                this.iSingleTranValue = this.arryReqValidationData.Singletrans;
              }
            } else {
              let errCode = summaryData.data.ErrorCode;
              if (errCode != undefined) {
                let errMsg = clsGlobal.dMsgMaster.getItem(errCode).replace('{1}', this.scripObject.ExchangeName);
                //this.toastCtrl.showAtBottom(errMsg);
                this.alertProvider.showAlertCallbackWithSingleButton(errMsg).then((data) => {
                  this.closePage(undefined);
                });
              } else {
                this.EDISReqRes.status = "1";
                this.closePage(this.EDISReqRes);
              }

            }
          } else {
            this.alertProvider.showAlertCallbackWithSingleButton(summaryData.errorString).then((data) => {
              this.closePage(undefined);
            });

          }

        }).catch(error => {
          this.loadCtrl.hideLoader();
        })

      });

    } catch (error) {
      this.loadCtrl.hideLoader();
    }
  }

  getFreeQty(summItem) {
    return (summItem.TotalFreeQty - summItem.TodayFreeQty);
  }

  //,ApprovedQuantity, TotalFreeQty, sISINCode, TodayFreeQty
  setCheckBoxDisabled(summItem: any) {
    let flag = false;
    try {
      if (summItem.sISINCode == this.DPDetails.ISIN) //// Code Comments : In both Tabs Scrip with same ISIN, then check box should be disabled with selected mode.
        flag = true;
      else
        flag = (this.arryReqValidationData.DPCheck == 1 && (summItem.eDISDPQty == 0) || summItem.eDISDPQty == summItem.ApprovedQuantity) ? true : false;

      if (flag)
        this.iCBDisabledCount = this.iCBDisabledCount + 1;
    }
    catch (e) {
      //clsGlobal.logManager.writeErrorLog(e.message, 'SetCheckBoxDisabled()', strFileName, '');
    }
    return flag;
  }

  onEDISQtyChange(summItem) {
    try {


      let value = 0;
      if (summItem.sISINCode == this.DPDetails.ISIN) {
        value = this.getMaxQty(summItem.eDISRequestQty, summItem.eDISCheckQty, this.originalQty);
      } else {
        value = this.getMaxQty(summItem.eDISRequestQty, summItem.eDISCheckQty, 0);
      }


      if (summItem.nEDISQty == null || summItem.nEDISQty == "" || summItem.nEDISQty == 0) {
        summItem.nEDISQty = value;
        this.CalculateRequestValue();
        //this.boolIsFocus = true;
        // if (this.boolIsWCFReqInProgress == true) 
        //     this.boolIsWCFReqInProgress = false;
        //Global.Popup.showAlert("Order Error!", Global.Constants.C_S_EDIS_ODRREQ_ERRMSG5, null);
        summItem.showInvalidQty = true;
        return;
      }
      //else if ((summItem.sISINCode == this.DPDetails.ISIN) && this.OriginalQty != 0 && (parseInt(summItem.nEDISQty) < this.OriginalQty)) {
      else if ((summItem.sISINCode == this.DPDetails.ISIN) && this.originalQty != 0 && (parseInt(summItem.nEDISQty) < (parseInt(this.originalQty) - parseInt(summItem.eDISCheckQty)))) {
        summItem.nEDISQty = value;
        this.CalculateRequestValue();
        //this.boolIsFocus = true;
        // if (this.boolIsWCFReqInProgress == true)
        //     this.boolIsWCFReqInProgress = false;
        //Global.Popup.showAlert("Order Error!", Global.Constants.C_S_EDIS_ODRREQ_ERRMSG4, null);
        summItem.showInvalidQty = true;
        return;
      }
      else
        summItem.nEDISQty = summItem.nEDISQty


      summItem.showInvalidQty = false;
      this.CalculateRequestValue();

      // this.boolIsFocus = false;
      // if (this.boolIsWCFReqInProgress == true) {
      //     this.boolIsWCFReqInProgress = false;
      //     $scope.SubmitRequest();
      // }

    }
    catch (e) {
      // Global.LogManager.WriteLog('Exception: ' + e.message, 'OnEDISQtyChange', strFileName, '');
    }
  }

  getMaxQty(eDISRequestQty, eDISCheckQty, OriginalQty) {
    let val = 0, val1 = 0, val2 = 0;
    try {

      if ((this.quantityToHold != null && this.quantityToHold != undefined && this.quantityToHold != "")) {
        //let val1 = (TotalFreeQty - ApprovedQuantity);
        val1 = eDISRequestQty;
        //let val2 = (OriginalQty - (TodayFreeQty + ApprovedQuantity));
        val2 = (OriginalQty - eDISCheckQty);
      }
      else {
        // let val1 = (TotalFreeQty - ApprovedQuantity);
        val1 = eDISRequestQty;
        //  let val2 = (0 - (TodayFreeQty + ApprovedQuantity));
        val2 = (0 - eDISCheckQty);
        val = Math.max(val1, val2);
      }

      if (this.arryReqValidationData.DPCheck == 0)
        val = Math.max(val1, val2);
      else
        val = val1;

      val = (val > 0) ? val : 0;
    }
    catch (e) {
      //Global.LogManager.WriteLog(e.message, 'GetMaxQty()', strFileName, '');
    }
    return val;
  }

  CalculateRequestValue() {
    try {
      //// Code Comments : request value will get calculate
      this.iRequestValue = 0;
      for (let cnt = 0; cnt < this.arrSummaryData.length; cnt++) {
        if (this.arrSummaryData[cnt].boolIsOrderSelected) {
          let newVal = (this.arrSummaryData[cnt].ClosePrice * (parseInt(this.arrSummaryData[cnt].nEDISQty))).toFixed(2);
          this.iRequestValue = (parseInt(this.iRequestValue) + parseInt(newVal)).toFixed(2);
        }
      }
    }
    catch (e) {
      //Global.LogManager.WriteLog('Exception: ' + e.message, 'CalculateRequestValue', strFileName, '');
    }
  }

  selectSingleRecord(selectedRow, evt) {
    setTimeout(() => {
      try {


        if (this.submitIsInProgress) return;

        //console.log('Event Value: ', evt.currentTarget.value);

        if (this.boolIsAllRecSelected && (!selectedRow.boolIsOrderSelected)) {
          this.boolIsAllRecSelected = false;
          this.isIndeterminate = true;
          this.iCBCheckedCount = 0;
          selectedRow.boolIsOrderSelected = !selectedRow.boolIsOrderSelected;
          selectedRow.boolIsInputDisabled = !selectedRow.boolIsOrderSelected;

          this.iCBCheckedCount = (((this.arrSummaryData.length) - (this.iCBDisabledCount)) - 1);
        }
        else {

          selectedRow.boolIsOrderSelected = !selectedRow.boolIsOrderSelected;
          selectedRow.boolIsInputDisabled = !selectedRow.boolIsOrderSelected;

          this.iCBCheckedCount = selectedRow.boolIsOrderSelected ? (parseInt(this.iCBCheckedCount) + 1) : (parseInt(this.iCBCheckedCount) - 1);
          this.boolIsAllRecSelected = false;
          //if (this.iCBCheckedCount == ((this.arrSummaryData.length) - (this.iCBDisabledCount))) {
          if (this.iCBCheckedCount == this.arrSummaryData.length) {
            this.boolIsAllRecSelected = true;
            this.isIndeterminate = false;
          } else {
            this.isIndeterminate = true;
          }

        }
        this.boolEnbDisBtnAuth = this.iCBCheckedCount > 0 ? true : false;
        this.selectedScripDisp = this.iCBCheckedCount + ' Scrip(s)';
        this.CDSLCalculations();
      }
      catch (e) {
        //Global.LogManager.WriteLog('Exception: ' + e.message, 'SelectSingleRecord', strFileName, '');
      }

    }, 10);
  }

  selectAllRecords(evt) {
    try {

      setTimeout(() => {
        this.submitIsInProgress = true;
        this.boolIsAllRecSelected = !this.boolIsAllRecSelected;
        this.iCBDisabledCount = 0;
        this.iCBCheckedCount = 0;
        this.isIndeterminate = false;
        for (let index = 0; index < this.arrSummaryData.length; index++) {
          if (this.iRadBtnCondition == 2) {
            if (!this.arrSummaryData[index].boolIsCBDisabled) {
              this.arrSummaryData[index].boolIsOrderSelected = this.boolIsAllRecSelected;
              this.arrSummaryData[index].boolIsInputDisabled = !this.boolIsAllRecSelected;
            }
            else {
              if (this.DPDetails.ISIN != undefined && this.DPDetails.ISIN != null && this.DPDetails.ISIN != ""
                && (this.arrSummaryData[index].sISINCode == this.DPDetails.ISIN)) { //// Code Comments : When ISIN matched, then Set reccord checkbox and input boolean value as true
                this.arrSummaryData[index].boolIsOrderSelected = true;
                this.arrSummaryData[index].boolIsInputDisabled = false;
              }
              else {
                this.arrSummaryData[index].boolIsOrderSelected = false;
                this.arrSummaryData[index].boolIsInputDisabled = false;
                this.iCBDisabledCount = this.iCBDisabledCount + 1;
              }
            }
          }
          else {
            if (!this.arrSummaryData[index].boolIsCBDisabled) {
              this.arrSummaryData[index].boolIsOrderSelected = this.boolIsAllRecSelected;
              this.arrSummaryData[index].boolIsInputDisabled = !this.boolIsAllRecSelected;
            }
            else {
              this.arrSummaryData[index].boolIsOrderSelected = true;
              this.arrSummaryData[index].boolIsInputDisabled = false;
            }
          }
        }


        //// Code Comments : Scrip will same ISIn, will always selected..
        ////                1.) will check for ISIN in DPDetails
        ////                2.) Point 1 is true
        ////                        => Then boolean value true will set to authenticate button
        ////                        => Then check boolean value of select all checckbox => If true, then do subtract disabled reccord count, from display record length to set check box count else assign 1 as checkbox 
        ////                3.) Point 1 is false
        ////                        => Then boolean value of select all checckbox, will set to authenticate button
        ////                       => Then check boolean value of select all checckbox => If true, then do subtract disabled reccord count, from display record length to set check box count else assign 0 as checkbox   
        if (this.DPDetails.ISIN) {
          this.boolEnbDisBtnAuth = true;
          this.iCBCheckedCount = this.boolIsAllRecSelected ? ((this.arrSummaryData.length) - (this.iCBDisabledCount)) : 1;

          if ((!this.boolIsAllRecSelected) && (this.iCBCheckedCount == (this.arrSummaryData.length - this.iCBDisabledCount)))
            this.boolIsAllRecSelected = true;
        }
        else {
          this.boolEnbDisBtnAuth = this.boolIsAllRecSelected;
          this.iCBCheckedCount = this.boolIsAllRecSelected ? ((this.arrSummaryData.length) - (this.iCBDisabledCount)) : 0;
        }

        this.selectedScripDisp = this.iCBCheckedCount + ' Scrip(s)'

        this.CDSLCalculations();
        this.submitIsInProgress = false;
      });
    }
    catch (e) {
      //Global.LogManager.WriteLog('Exception: ' + e.message, 'this.SelectAllRecords', this.strFileName, '');
      this.submitIsInProgress = false;
    }
  }


  CDSLCalculations() {
    try {

      if (this.arryReqValidationData != undefined) {

        this.iRequestCount = this.arryReqValidationData.UserTranCount;
        this.iPerDayTransactionvalue = this.arryReqValidationData.PerDayTransactionvalue;
        this.iValueUtilized = this.arryReqValidationData.ValueUtilized;
        this.iMaxCount = this.arryReqValidationData.MaxTranCount;
        this.iSingleTranValue = this.arryReqValidationData.Singletrans;

        this.CalculateRequestValue();
      }
    }
    catch (e) {
      //Global.LogManager.WriteLog('Exception: ' + e.message, 'this.CDSLCalculations', this.strFileName, '');
    }
  }

  submitRequest() {
    try {
      if (this.submitIsInProgress) return;
      this.submitIsInProgress = true;
      let flag = this.requestValidation();
      if (flag) {
        this.openNSDLCDSLPage(this.DPDetails, this.objCDSL.ExchangeName, 'Equity', this.objCDSL.MarketSegmentId, this.arrReqValidData);
      } else {
        this.submitIsInProgress = false;
      }
    } catch (error) {

    }
  }

  requestValidation() {
    let flag = false;
    try {
      let errorMeg = "";
      let countError = 1;
      if (this.arryReqValidationData.MaxTranCount <= this.arryReqValidationData.UserTranCount)
        errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG1 + "\n\n";
      if (parseInt(this.iRequestValue) > this.arryReqValidationData.Singletrans)
        errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG2 + "\n\n";
      if (parseInt(this.iRequestValue) > (((this.iPerDayTransactionvalue) - (this.iValueUtilized))))
        errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG3 + "\n\n";
      //if (this.arryReqValidationData.DPCheck == 1 && this.arrSummaryData.some(el => parseInt(el.eDISQty) > (parseInt(parseInt(el.TotalFreeQty) - parseInt(el.ApprovedQuantity)))))
      //    errorMeg += (countError++) + "." + Global.Constants.C_S_EDIS_ODRREQ_ERRMSG4 + "\n\n";

      for (let cntData = 0; cntData < this.arrSummaryData.length; cntData++) {
        if (this.arrSummaryData[cntData].boolIsOrderSelected) { //// Code Comments : Check when record is selected
          let value = 0;
          if (this.arrSummaryData[cntData].sISINCode == this.DPDetails.ISIN)
            value = this.getMaxQty(this.arrSummaryData[cntData].eDISRequestQty, this.arrSummaryData[cntData].eDISCheckQty, this.originalQty);
          else
            value = this.getMaxQty(this.arrSummaryData[cntData].eDISRequestQty, this.arrSummaryData[cntData].eDISCheckQty, 0);

          if (this.arrSummaryData[cntData].nEDISQty == undefined || this.arrSummaryData[cntData].nEDISQty == null || this.arrSummaryData[cntData].nEDISQty == "" || parseInt(this.arrSummaryData[cntData].nEDISQty) <= 0) { //// Code Comments : Check for nEDISQty should be greater then zero, for same ISIN scrip.
            this.arrSummaryData[cntData].nEDISQty = value;
            errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG5 + "\n\n";
            this.arrSummaryData[cntData].showInvalidQty = true;
            break;
          }

          if ((this.originalQty != 0) && parseInt(this.arrSummaryData[cntData].nEDISQty) < parseInt((this.originalQty))) {
            this.arrSummaryData[cntData].nEDISQty = value;
            errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG4 + "\n\n";
            this.arrSummaryData[cntData].showInvalidQty = true;
            break;
          }

          if (this.arryReqValidationData.DPCheck == 1 && (parseInt(this.arrSummaryData[cntData].nEDISQty) > parseInt(this.arrSummaryData[cntData].TotalFreeQty))) {
            this.arrSummaryData[cntData].nEDISQty = value;
            errorMeg += (countError++) + "." + clsConstants.C_S_EDIS_ODRREQ_ERRMSG6 + "\n\n";
            this.arrSummaryData[cntData].showInvalidQty = true;
            break;
          }
        }
      }

      if (errorMeg) {
        //Global.Popup.showAlert("Order Error!", errorMeg, null);
        this.alertProvider.showAlert(errorMeg);
        flag = false;
      }
      else {
        flag = true;


        let tempArry = [];
        //angular.copy(this.arrSummaryData, tempArry);
        for (let cnt = 0; cnt < this.arrSummaryData.length; cnt++) {
          //this.arrSummaryData[cnt].nEDISQty > 0 ||
          if (this.arrSummaryData[cnt].boolIsOrderSelected) {
            tempArry.push(this.arrSummaryData[cnt]);
          }
        }
        if (tempArry.length > 0) {
          flag = true;
          this.arrReqValidData = tempArry;
          //angular.copy(tempArry,this.arryReqValidData);
        }
        else
          flag = false;
      }
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('edis-summary-comp', 'requestValidation', 'Exception: ' + e.message);
    }

    return flag;
  }


  openNSDLCDSLPage(EDISOnlineDetails, ExchangeName, InstrumentName, MarketSegmentId, arryMultiScrips) {
    try {

      let strUrl = clsTradingMethods.generateEDISUrl(EDISOnlineDetails, ExchangeName, InstrumentName, MarketSegmentId, arryMultiScrips);

      //console.log('EDIS URL: ', strUrl);
      this.openwindowobj = this.iab.create(strUrl, '_blank', 'location=yes');
      this.iInterval = 0;
      this.iInterval = setInterval(this.closedEDISThirdPartyURL.bind(this), 200, this.openwindowobj);
      // setInterval(function () {
      //     this.ClosedEDISThirdPartyURL(this.openwindowobj);
      // }, 200);
      this.openwindowobj.on('exit').subscribe((event) => {
        clearInterval(this.iInterval);
        //this.toastCtrl.showAtBottom('Exit Called');
        if ((this.openwindowobj != undefined) && (!this.openwindowobj.closed)) {
          setTimeout(() => {
            this.submitIsInProgress = false;
            this.openwindowobj.close();
          }, 1500);
        }
      });

    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('edis-summary-comp', 'openNSDLCDSLPage', 'Exception: ' + e.message);
    }
  }

  closedEDISThirdPartyURL(openwindowobj) {
    try {
      openwindowobj.executeScript({
        code: clsConstants.C_S_EDIS_THIRD_PARTY_RESPONSE_KEY
      },
        (data) => {
          try {

            this.submitIsInProgress = false;
            let jsonData = JSON.parse(data);
            //this.toastCtrl.showWithButton('jsonData' + data);
            if (jsonData.Status == 'Success') {

              this.processEDISResponse(jsonData, openwindowobj);

            }
            else {
              if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
                clearInterval(this.iInterval); //// will colse window
                setTimeout(function () {
                  openwindowobj.close();
                }, 1500);
              }
              //this.refreshEDISRptData();
            }
          } catch (error) {
            this.toastCtrl.showAtBottom('closedEDISThirdPartyURL error: ' + error.message);
          }
        });
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('edis-summary-comp', 'closedEDISThirdPartyURL', 'Exception: ' + e.message);
    }
  }

  processEDISResponse(jsonData, openwindowobj) {
    try {


      let ScripDetails = JSON.parse(jsonData.ScripDetails);
      //this.arrReqValidData.
      for (let index = 0; index < this.arrReqValidData.length; index++) {
        const element = this.arrReqValidData[index];
        let rowMatchedISIN = ScripDetails.find(i => i.ISIN == element.sISINCode);
        if (rowMatchedISIN) {

          element.Status = rowMatchedISIN.Status;
          element.Quantity = rowMatchedISIN.Qty;// rowMatchedISIN.Qty + value.ApprovedQuantity;

          if (element.sISINCode == this.DPDetails.ISIN) {

            this.EDISReqRes.eDISReqId = rowMatchedISIN.RefNo;
            this.EDISReqRes.nApprovedFreeQty = element.Quantity;
            this.EDISReqRes.nTotalAvailableQty = element.TotalFreeQty;
            this.EDISReqRes.sISINCode = this.DPDetails.ISIN;
            this.EDISReqRes.sDepository = this.DPDetails.sDepository;
            let data = clsTradingMethods.findDPAndClientID(this.DPDetails, this.DPDetails.sDepository);
            this.EDISReqRes.sDPId = data[0];
            this.EDISReqRes.sMktsegId = this.scripObject.scripDet.MktSegId;// this.MapMarketSegmentId;
            this.EDISReqRes.sToken = this.scripObject.scripDet.token;

            this.EDISReqRes.status = jsonData.Status;

          }

        }
      }

      this.submitIsInProgress = false;

      let arrFilterdScrips = this.arrReqValidData.filter(s => s.Status == 'Success');
      if (arrFilterdScrips.length > 0) {

        let objEDIS: any = {};
        objEDIS.userCode = clsGlobal.User.userCode;
        objEDIS.scrips = [];
        for (let index = 0; index < arrFilterdScrips.length; index++) {
          const element = arrFilterdScrips[index];
          let edisScrip: any = {};
          edisScrip.ISIN = element.sISINCode;
          edisScrip.Quantity = element.Quantity;
          objEDIS.scrips.push(edisScrip);
        }

        this.tranServ.updateEDISDPHolding(objEDIS).then(data => {

          if (this.scripObject != undefined) {
            this.modalCtrl.dismiss(this.EDISReqRes);
          } else {
            this.refreshEDISRptData();
          }

          if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
            clearInterval(this.iInterval); //// will colse window
            setTimeout(function () {
              openwindowobj.close();
            }, 10);
          }

        }).catch(error => {
          this.toastCtrl.showAtBottom("Error in updateEDISDPHolding: " + error);

          if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
            clearInterval(this.iInterval); //// will colse window
            setTimeout(function () {
              openwindowobj.close();
            }, 10);
          }

        });



      }
    } catch (error) {

    }
  }

  refreshEDISRptData() {
    try {
      if (!this.submitIsInProgress) {
        this.boolNoRecFound = false;

        this.arrSummaryData = [];
        this.arryReqValidationData = [];

        this.arrReqValidData = [];
        this.DPDetails = [];


        this.getSummaryData();
      }
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('edis-summary-comp', 'RefreshEDISRptData', 'Exception: ' + e.message);
    }
  }

  closePage(bData) {
    if (this.scripObject == undefined) {
      this.navCtrl.pop();
    } else {
      this.modalCtrl.dismiss(bData);
    }
  }

}
