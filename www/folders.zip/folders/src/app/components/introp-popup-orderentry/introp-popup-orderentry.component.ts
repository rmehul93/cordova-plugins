import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ModalController, Platform, PopoverController } from "@ionic/angular";
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';

@Component({
  selector: 'app-introp-popup-orderentry',
  templateUrl: './introp-popup-orderentry.component.html'
})
export class IntropPopupOrderentryComponent implements OnInit, OnDestroy {

  @Input("Order") objOE: any; //script objcet to create order entry.
  @Input("FromOE") isFromOrderEntry: boolean = false;
  @Output() messageEvent = new EventEmitter<object>();//used to emit event for popup close.
  @Output() onFocus = new EventEmitter();

  netPositionData:any;
  numberortell: any;
  bcastHandler:any
  lstScripKey: any = [];
  pricePrecision: any = 2;
  editIndex: number;
  selectedNetpositionItem: any;
  selQty: any = 0;
  arrValidity = [];
  selValidity: any;
  accordionhide: boolean = false;
  selectAll: boolean = false;
  selPrice: any = 0.00;
  price:any;
  zeroVal: number = 0;
  sqaureOffOrderCheckCount = 0;
  isIndeterminate: boolean = false;
  showSquareOrdersPopup: boolean = false;
  isSquareOffOrderClick: boolean = false;
  showOrderStatus : boolean = false;
  orderResponse : any = [];
  constructor(
    public platform: Platform,
    private toastCtrl: ToastServicesProvider,
    public modalCtrl: ModalController,
    private tranService: TransactionService,
    private http: clsHttpService,
    public popoverController: PopoverController,) {
  }

  ngOnDestroy(): void {
    //if (!this.isFromOrderEntry) {
    this.ionViewWillLeave();
    //}
    window.removeEventListener('message', (evt: any) => { });
  }

  async ngOnInit() {
    this.bcastHandler = this.receiveTouchlineResponse.bind(this);
    if (this.platform.is('android')) {
      this.numberortell = 'tel';
    }
    else {
      this.numberortell = 'number';
    }
     this.netPositionData = this.objOE;
     let scripdetail =  { scrips : []};
    await  this.netPositionData.forEach(netPositionDataItem => {

      let arrValidity = (clsGlobal.ExchManager.populateValidity(netPositionDataItem.exchange, netPositionDataItem.mktSegId));
      let enableFields = clsGlobal.ExchManager.enableDisable(netPositionDataItem.exchange, netPositionDataItem.instrument);
      netPositionDataItem.NetChangeInRs = "0.00";
      netPositionDataItem.arrowTrend = '';
      netPositionDataItem.LTPTrend = '';
      netPositionDataItem.PercNetChange = "0.00";
      if (netPositionDataItem.net_quantity > 0) {
        netPositionDataItem.buySell = clsConstants.C_V_ORDER_SELL;
        netPositionDataItem.buySellOperation = clsConstants.C_S_ORDER_SELL_TEXT
      }
      else {
        netPositionDataItem.buySell = clsConstants.C_V_ORDER_BUY;
        netPositionDataItem.buySellOperation = clsConstants.C_S_ORDER_BUY_TEXT
      }
      netPositionDataItem.isChecked = false;
      //  item.NetQuantity = Math.abs(parseInt(item.NetQuantity));
      netPositionDataItem.modifiedNetQuantity = Math.abs(parseInt(netPositionDataItem.net_quantity));
      netPositionDataItem.cancelOnLogout = false;
      netPositionDataItem.isModified = false;
      netPositionDataItem.selDiscQty = 0;
      netPositionDataItem.selValidity = arrValidity[0] || 'DAY';
      netPositionDataItem.selTriggerPrice = 0.00;
      netPositionDataItem.AvgNetPrice = 0.00;
      netPositionDataItem.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
      scripdetail.scrips.push({
        mkt: netPositionDataItem.exchange,
        token: netPositionDataItem.scrip_token
      })
     });

     await clsTradingMethods.getScripInfoElasticSearch(scripdetail, this.http).then((resp: any) => {
      if (resp.status) {
      resp.result.forEach(element => {
        this.netPositionData.forEach(netPositionDataItem => {
            if( netPositionDataItem.mktSegId == clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId) && netPositionDataItem.scrip_token == element.nToken  ){
              netPositionDataItem.scrip = element;
            }
        });
      });
      }  
    });
     this.createBroadcastforNetposition()
   }


   createBroadcastforNetposition() {
    try {
      for (let index = 0; index < this.netPositionData.length; index++) {
        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = this.netPositionData[index].scrip_token;
        objScrpKey.MktSegId =  this.netPositionData[index].mktSegId;
        this.lstScripKey.push(objScrpKey);
      }
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.ADD, this.lstScripKey);
    } catch (error) {
      console.log("Error + createBroadcastforNetposition" + error);
      clsGlobal.logManager.writeErrorLog('IntropOrderEnrtyPage', 'createBroadcastforNetposition', error.message);
    }
  }
 

  ionViewWillLeave() {
    try {

      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.lstScripKey);

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'ionViewWillLeave', error);
    }
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('Popup-Orderentry', 'sendTouchlineRequest', error);
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      let nFormat = 2;
      if (objMultiTLResp != null) {
        if (this.netPositionData.length > 0) {
          this.netPositionData.forEach(netPositionItem => {
            if ( (netPositionItem.scrip_token == objMultiTLResp.Scrip.token && netPositionItem.mktSegId == objMultiTLResp.Scrip.MktSegId ) || ( netPositionItem.isCombined &&  netPositionItem.preferred_scrip_token == objMultiTLResp.Scrip.token && netPositionItem.preferred_mktSegId == objMultiTLResp.Scrip.MktSegId )) {
            
              nFormat = objMultiTLResp.PriceFormat;

              let RegularLot = netPositionItem.market_lot;
              let PriceNum = netPositionItem.price_num;
              let PriceDen = netPositionItem.price_den;
              let GenNum = netPositionItem.gen_num;
              let GenDen = netPositionItem.gen_den;
              let BuyValue = parseFloat(netPositionItem.buy_value);
              let SellVal = parseFloat(netPositionItem.sell_value);
              let CurrentMTM = null;

              let NetQty = netPositionItem.net_quantity;
              let ReferanceRate = netPositionItem.reference_rate;
              objMultiTLResp.LTP = (parseFloat(objMultiTLResp.LTP) == 0 ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
              netPositionItem.ltp = objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined ? this.zeroVal.toFixed(objMultiTLResp.PriceFormat) : objMultiTLResp.LTP;


              CurrentMTM = clsTradingMethods.CalculateMTM(SellVal, NetQty, parseFloat(objMultiTLResp.LTP), RegularLot, GenNum, GenDen, PriceNum, PriceDen, BuyValue, objMultiTLResp.Scrip.MktSegId, ReferanceRate);
              netPositionItem.mtm = CurrentMTM.toFixed(2);
              if (NetQty) {
                netPositionItem.permtm = (((parseFloat(netPositionItem.ltp) - parseFloat(netPositionItem.net_price))) / (parseFloat(netPositionItem.net_price)) * 100 * NetQty).toFixed(2)
              } else {
                netPositionItem.permtm = 0.00
              }

              let arrNetChange = clsTradingMethods.getChangeInRs(objMultiTLResp.LTP, objMultiTLResp.ClosePrice, objMultiTLResp.PriceFormat, false, 'uptrend');
              netPositionItem.NetChangeInRs = arrNetChange[0];
              netPositionItem.PercNetChange = arrNetChange[1];
              netPositionItem.LTPTrend = arrNetChange[2];
              netPositionItem.arrowTrend = arrNetChange[3];
           }
          });
        }
      }
    }
    catch (error) {
      console.log('Popup-Orderentry', 'receiveTouchlineResponse', error);
    }

  }

  closePopUp() {
    //console.log(this.scripObject);
    let eventobj = {
      closePopUp: true
    }
    this.messageEvent.emit(eventobj);
  }


  accordiontoggle(index, netPositionDataItem) {

    if (this.editIndex != null) {
      if (index != this.editIndex) {
        this.selectedNetpositionItem = netPositionDataItem;
        this.editIndex = index;
        this.pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.selectedNetpositionItem.mktSegId, this.selectedNetpositionItem.scrip.DecimalLocator.toString().length - 1);
        this.selQty = Math.abs(parseInt(this.selectedNetpositionItem.modifiedNetQuantity));
        this.selPrice = parseInt(this.selectedNetpositionItem.LTP);
        this.arrValidity = (clsGlobal.ExchManager.populateValidity(this.selectedNetpositionItem.exchange, this.selectedNetpositionItem.ScripDetail.scripDet.MktSegId));
        if (this.selectedNetpositionItem.isModified) {
          this.selValidity = this.selectedNetpositionItem.selValidity;
        } else {
          this.selPrice = parseFloat(this.selectedNetpositionItem.ltp).toFixed(this.pricePrecision);
          this.selValidity = this.arrValidity[0];
        }
      } else {
        this.accordionhide = !this.accordionhide;
        this.clearFields();
      }
    }
    else {
      this.accordionhide = !this.accordionhide;
      if (this.accordionhide) {
        this.selectedNetpositionItem = netPositionDataItem;
        this.editIndex = index;
        this.pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.selectedNetpositionItem.mktSegId, this.selectedNetpositionItem.scrip.DecimalLocator.toString().length - 1);
        this.selQty = Math.abs(parseInt(this.selectedNetpositionItem.modifiedNetQuantity));
        this.selPrice = parseInt(this.selectedNetpositionItem.ltp);
        this.arrValidity = (clsGlobal.ExchManager.populateValidity(this.selectedNetpositionItem.exchange, this.selectedNetpositionItem.mktSegId));
        this.selValidity = this.arrValidity[0];
        
        if (this.selectedNetpositionItem.isModified) {
          this.selPrice = parseFloat(this.selectedNetpositionItem.AvgNetPrice).toFixed(this.pricePrecision);
          this.selValidity = this.selectedNetpositionItem.selValidity;
          if(parseInt(this.selPrice)==0){
            this.price = 'marketPrice'
          }else{
            this.price = 'yourPrice'
          }
          
        } else {
          this.selPrice = parseFloat(this.selectedNetpositionItem.ltp).toFixed(this.pricePrecision);
          this.selValidity = this.arrValidity[0];
          this.price = 'marketPrice'
        }
      } else {
        this.clearFields();
      }
    }

  }

  clearFields() {
    this.selectedNetpositionItem = null;
    this.editIndex = null;
    this.pricePrecision = null;
    this.selQty = null;
    this.selPrice = null;
    this.arrValidity = []
    this.selValidity = null;   
  }

  priceOnFocus() {
    this.onFocus.emit(this.objOE);
  }

  priceOnLostFocus() {
    if (this.selPrice == '') {
      this.selPrice = 0.00;
    }
    this.selPrice = parseFloat(this.selPrice).toFixed(this.pricePrecision);
  }

  segmentChanged(event) {
    this.price = event.detail.value;
    this.selPrice = 0
  }

  selectAllOrders(evet) {
    try {

      this.selectAll = !this.selectAll;
      setTimeout(() => {
        this.netPositionData.forEach(element => {
          element.isChecked = this.selectAll;
        });
      });
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "selectAllOrders", error);
    }
  }

  addOrderforSubmit(index, netPositionDataItem) {
    this.netPositionData[index].isChecked = !this.netPositionData[index].isChecked;
    /**To Set All Check Boxses */
    let copyOfobjOEDetails = this.netPositionData.filter(item => { return item.isChecked });

    if (copyOfobjOEDetails.length == this.netPositionData.length) {
      this.selectAll = true;
    } else {
      this.selectAll = false;
    }
  }


  checkUncheckOrder(evnt , netPositionDataItem) {
    netPositionDataItem.isChecked = evnt.target.checked;
    try {
      const totalItems = this.netPositionData.length;
      let checked = 0;
      this.netPositionData.map(element => {
        if (element.isChecked) checked++;
      });
      if (checked > 0 && checked < totalItems) {
        //If even one item is checked but not all
        this.isIndeterminate = true;
        this.selectAll = false;
      } else if (checked == totalItems) {
        //If all are checked
        this.selectAll = true;
        this.isIndeterminate = false;
      } else {
        //If none is checked
        this.isIndeterminate = false;
        this.selectAll = false;
      }

      this.sqaureOffOrderCheckCount = checked;
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "checkUncheckOrder", error);
    }
  }

  checkOrderData(index, netPositionItem) {
    let Price = (this.selPrice != undefined && this.selPrice != '') ? this.selPrice : 0;
    
    if (this.validatePrice(Price, netPositionItem, 1)) {
      if(parseInt(this.selQty) == 0){
        this.toastCtrl.showAtBottom("Minimum Quantity/Lot required")
        return false; 

      }
      else if(parseInt(this.selQty) >  parseInt(netPositionItem.net_quantity) ){
        this.toastCtrl.showAtBottom("Quantity/Lot should not be greater than original Quantity/Lot")
        return false;
      }else {
        let step = clsGlobal.ExchManager.getQtyIncVal(netPositionItem.mktSegId, netPositionItem.scrip.nRegularLot);
        if (parseInt(this.selQty) < step) {
          this.selQty = step;
          this.toastCtrl.showAtBottom("Minimum Quantity/Lot required " + step);
          return false;
        } else if (parseInt(this.selQty) % step != 0) {
          this.selQty = Math.abs(parseInt(netPositionItem.modifiedNetQuantity));
          this.toastCtrl.showAtBottom("Quantity should be multiple of lot size " + step)
          return false;
        }else{
          return true;
        }
      }

    }
  }

  modifyOrderData(index, netpositionItem) {
    if (this.checkOrderData(index, netpositionItem)) {
      netpositionItem.modifiedNetQuantity = this.selQty;
      netpositionItem.isModified = true;
      if(this.price == 'marketPrice'){
        netpositionItem.AvgNetPrice = 0.00;
        this.selPrice = 0.00;
      }else{
        netpositionItem.AvgNetPrice = this.selPrice;
      }
      
      netpositionItem.selValidity = this.selValidity || 'DAY';
      netpositionItem.selOrderType = parseInt(this.selPrice) == 0 ? 'RL-MKT' : 'RL' ;
      this.accordionhide = false;
      this.clearFields();
    } else {
    }
  }

  validatePrice(Price, netPositionDataItem, flag) {  
    if (Price != 0) {
      let PriceinPaise = parseInt(Math.round(parseFloat((Price * netPositionDataItem.scrip.DecimalLocator).toString())).toString());
      if (PriceinPaise % parseInt(netPositionDataItem.scrip.nPriceTick) != 0) {
        if (flag == 1) {
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL62") + netPositionDataItem.scrip.nPriceTick / netPositionDataItem.scrip.DecimalLocator + clsGlobal.dMsgMaster.getItem("NNSL63"));
          return false;
        } else if (flag == 2) {
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL69") +netPositionDataItem.scrip.nPriceTick / netPositionDataItem.scrip.DecimalLocator + clsGlobal.dMsgMaster.getItem("NNSL63"));
          return false;
        }
      }
      else{
        return true;
      }
    } else {
      return true;
    }
  }

  qtyOnLostFocus() {
    let step = clsGlobal.ExchManager.getQtyIncVal(this.selectedNetpositionItem.mktSegId, this.selectedNetpositionItem.market_lot);
    if (parseInt(this.selQty) > Math.abs(parseInt(this.selectedNetpositionItem.net_quantity))) {
      this.toastCtrl.showAtBottom("Quantity/Lot should not be greater than original Quantity/Lot");
      this.selQty = Math.abs(parseInt(this.selectedNetpositionItem.net_quantity));
    }
    else if (parseInt(this.selQty) < step) {
      this.selQty = step;
      this.toastCtrl.showAtBottom("Minimum Quantity/Lot required " + step);
    } else if (parseInt(this.selQty) % step != 0) {
      this.selQty = Math.abs(parseInt(this.selectedNetpositionItem.net_quantity));
      this.toastCtrl.showAtBottom("Quantity should be multiple of lot size " + step)
    }
  }

  getFormattedProductType(productType: string) {
    let product_type = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        product_type = productType.replace(/\w\S*/g, (txt) => { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase() })
        break;
      default:
        product_type = productType;
        break;
    }
    return product_type;
  }

  getFormattedQty(qty){
    return Math.abs(qty);
  }

  showChooseValidity :boolean = false;

  clickChooseValidity() {
    this.showChooseValidity = !this.showChooseValidity;
  }
  showValidity(validity) {

    let bShowValidity = true;
    try {
      if (validity == clsConstants.C_S_VALUE_GTD) {
        bShowValidity = false;
        return bShowValidity;
      }
    } catch (error) {
      return bShowValidity;
    }

    return bShowValidity;

  }

  setValidity(validity){
    this.selValidity = validity;
    this.showChooseValidity = false
  }

  filterCheckedOrders(sqaureofforderitem){
    return sqaureofforderitem.isChecked;
  }

  closeSquareOffOrderPopup(){
    this.showSquareOrdersPopup  = false
  }


  squareOffAllOrders(){
    try {
      if (this.sqaureOffOrderCheckCount == 0) {
        this.toastCtrl.showAtBottom("You need to select orders for sqaure off");
      }
      else {
        if (!this.accordionhide) {
          if(this.showSquareOrdersPopup){
            var sqaureOffOrderArray = [];
            this.netPositionData.forEach(element => {
              if (element.isChecked == true)
                sqaureOffOrderArray.push(element);
            });
            this.isSquareOffOrderClick = true;
           this.tranService.bulkOrderEntry(this.createOrdersRequest(sqaureOffOrderArray)).then((response:any)=>{
             if(response.status == 'success'){
               this.showSquareOrdersPopup = false;
               this.isSquareOffOrderClick = false;
               this.showOrderStatus = true;
               this.orderResponse = response.data;
               }else{
              this.toastCtrl.showAtBottom("Failed to submit Square-off orders request");
              this.showSquareOrdersPopup = false;
              this.isSquareOffOrderClick = false;
              this.closePopUp();
             }
           
           }, error=>{
            this.toastCtrl.showAtBottom("Failed to submit Square-off orders request");
            this.showSquareOrdersPopup = false;
            this.isSquareOffOrderClick = false;
            this.closePopUp();
            clsGlobal.logManager.writeErrorLog("SqaureOffOrdersPage" , "squareOffAllOrders" , error.message )
           })
  
          }else{
            
            var sqaureOffOrderArray = [];;
            this.netPositionData.forEach(element => {
              if (element.isChecked == true)
                sqaureOffOrderArray.push(element);
            });
  
            if (sqaureOffOrderArray.length > 0) {
              this.showSquareOrdersPopup = true
            }
          }
        }else{
          this.toastCtrl.showAtBottom("Complete the order modification before submit");
        }
        
        
        }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("SqaureOffOrdersPage" , "squareOffAllOrders_1" , error.message )
      clsGlobal.ConsoleLogging("Error", "squareOffAllOrders", error);
    }

    
  }

  createOrdersRequest(sqaureOffOrderArray) {
    let requestArray = [];

    sqaureOffOrderArray.forEach(element => {
      requestArray.push({
        "scrip_info": {
          "exchange": element.exchange,
          "scrip_token": element.scrip_token,
          "symbol": element.symbol,
          "series": element.series,
          "expiry_date": element.expiry_date,
          "strike_price": element.strike_price,
          "option_type": element.option_type
        },
        "transaction_type": element.modifiedNetQuantity > 0 ? 'SELL':'BUY',
        "product_type": element.product_type,
        "order_type":  parseInt(element.AvgNetPrice) == 0 ? 'RL-MKT' : 'RL' ,
        "quantity": Math.abs(element.modifiedNetQuantity),
        "price": element.AvgNetPrice,
        "trigger_price": 0,
        "disclosed_quantity": 0,
        "validity": element.selValidity,
        "is_amo": false,
        "order_identifier": ''
      });
    });

    return requestArray;

  }
}