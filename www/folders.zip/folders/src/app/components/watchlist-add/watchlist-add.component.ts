import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { DatabaseService } from 'src/app/providers/database-services/database-services';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { WatchlistService } from 'src/app/providers/watchlist-service.service';

@Component({
  selector: 'app-watchlist-add',
  templateUrl: './watchlist-add.component.html'
})
export class WatchlistAddComponent implements OnInit {

  //script key objcet to be passed clsScripKey.
  @Input("Scrip") objScrip: any;
  showWatchListSelection = true;
  profileList = [];
  selProfileId: any;
  selProfileName: any;
  profileScrips = [];
  @Output() closeEvent = new EventEmitter<object>();//used to emit event for popup close.

  constructor(private toastProvider: ToastServicesProvider,
    private dbService: DatabaseService,
    private watchlistServ: WatchlistService,
    private alertCtrl: AlertServicesProvider,) {

  }

  ngOnInit() { this.loadProfile(); }

  loadProfile() {
    try {

      this.profileList = [];
      this.watchlistServ.getWatchlistProfile().then((profileData: any) => {
        if (profileData) {

          for (let index = 0; index < profileData.length; index++) {
            const element = profileData[index];
            if (element.bIsPrivate.toString() == 'true') {
              let watchProfile = {
                nWatchListId: element.nWatchListId,
                sWatchListName: element.sWatchListName,
                bIsPrivate: element.bIsPrivate,//"false",
                bIsDefault: element.bIsDefault,//"false",
                sCreatedBy: element.sUserId,
                nTenantId: element.sTenantId
              };
              this.profileList.push(watchProfile);
            }
          }
          // this.profileList = profileData.filter((profileScrip) => {
          //   return profileScrip.bIsPrivate.toString() == 'true';
          // });
        }
      })

    } catch (error) {

    }
  }

  closeWatchListPopUp() {
    let eventobj = {
      closePopUp: true
    }
    this.closeEvent.emit(eventobj);
    //this.showWatchListSelection = !this.showWatchListSelection;
  }

  onProfileSelected(profile) {
    try {

      this.selProfileId = profile.nWatchListId;
      this.selProfileName = profile.sWatchListName;
      this.profileScrips = [];
      this.watchlistServ.getWatchlistProfileScrip(this.selProfileId, profile.sCreatedBy).then((profScrip: any) => {

        let initialWatchListCount = 0;
        let scripIndex = 0;
        if (profScrip != undefined) {

          initialWatchListCount = profScrip.length;

          for (let index = 0; index < profScrip.length; index++) {
            const element = profScrip[index];
            //this.profileScrips.push({ MktSegId: parseInt(element.nMarketSegmetId || element.nMarketSegmentId), Token: element.nToken, SeqNo: element.nSequenceNo, isNew: false });
            this.profileScrips.push({ MktSegId: parseInt( element.scripDet.MapMktSegId), Token:  element.scripDet.token, SeqNo: (index + 1), isNew: false });
           
            if (index == profScrip.length - 1) {
              //scripIndex = (element.nSequenceNo);
              index = (index+1);
            }
          }

          let isScripExist = this.profileScrips.filter(item => {
            return item.MktSegId == parseInt(this.objScrip.MapMktSegId) && item.Token == this.objScrip.token
          });

          if (isScripExist.length == 0) {

            let maxScripCnt = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_WATCHLIST_SCRIP_COUNT) || '50')
            if (this.profileScrips.length >= maxScripCnt) {
              this.toastProvider.showAtBottom(clsConstants.C_S_ERROR_PROFILE_SCRIP);
              return;
            }

            // let addeScrip = [];
            // addeScrip.push({ MktSegId: parseInt(this.objScrip.MktSegId), Token: this.objScrip.token, SeqNo: ++scripIndex });
            // //For in case of add in saved profile. 
            // let watclistObj: any = {};
            // watclistObj.scrip = addeScrip;
            // watclistObj.profileId = this.selProfileId;
            // this.watchlistServ.updateWatchlistScrip(watclistObj).then((data) => {
            //   this.toastProvider.showAtBottom("Scrip(s) added.");
            //   clsGlobal.reloadWatchlist = true;
            //   this.closeWatchListPopUp();
            // });
          }
          else {
            this.toastProvider.showAtBottom("Scrip already exist in watchlist.");
            return;
          }
        }
        //  else {

        //   let addeScrip = [];
        //   addeScrip.push({ MktSegId: parseInt(this.objScrip.MktSegId), Token: this.objScrip.token, SeqNo: ++scripIndex });
        //   //For in case of add in saved profile. 
        //   let watclistObj: any = {};
        //   watclistObj.scrip = addeScrip;
        //   watclistObj.profileId = this.selProfileId;
        //   this.watchlistServ.updateWatchlistScrip(watclistObj).then((data) => {
        //     this.toastProvider.showAtBottom("Scrip(s) added.");
        //     clsGlobal.reloadWatchlist = true;
        //     this.closeWatchListPopUp();
        //   });
        // }

        let watchScrip = [];
        watchScrip.push({
          nWatchListId: this.selProfileId,
          nMarketSegmentId: this.objScrip.MapMktSegId,
          nToken: this.objScrip.token,
          nSequenceNo: ++scripIndex
        })

        this.watchlistServ.addWatchlistScrip(profile, watchScrip).then((data) => {
          this.toastProvider.showAtBottom("Scrip(s) added.");
          clsGlobal.reloadWatchlist = true;
          this.closeWatchListPopUp();
        });

      }, (error) => {

      });

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('WatchlistPage', 'onProfileSelected', error);
    }

  }

}
