import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ModalController, NavController, Platform, PopoverController } from "@ionic/angular";
//import { FALSE_STR } from 'node_modules------/zone.js/lib/common/utils';
import { clsAppConfigConstants } from 'src/app/Common/clsAppConfigConstants';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { Dictionary } from 'src/app/Common/clsCustomClasses';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { clsBestFiveRequest } from 'src/app/communicator/clsBestFiveRequest';
import { clsBestFiveResponse } from 'src/app/communicator/clsBestFiveResponse';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { TransactionService } from 'src/app/providers/transaction.service';
import * as moment from 'moment';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { EDISSummaryComponent } from '../edissummary/edissummary.component';
import { clsMultiTouchLineResponse } from 'src/app/communicator/clsMultiTouchLineResponse';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';
import { MultilegLookupPage } from 'src/app/pages/multileg-lookup/multileg-lookup.page';
import { MultilegConfirmationPage } from 'src/app/pages/multileg-confirmation/multileg-confirmation.page';
import { PopoverPage } from '../pop-over/popover.page';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';

@Component({
  selector: 'app-popup-orderentry',
  templateUrl: './popup-orderentry.component.html'

})
export class PopupOrderentryComponent implements OnInit, OnDestroy {

  @Input("Order") objOE: any; //script objcet to create order entry.
  @Input("FromOE") isFromOrderEntry: boolean = false;
  @Output() messageEvent = new EventEmitter<object>();//used to emit event for popup close.
  @Output() onFocus = new EventEmitter();

  scripObject: clsScrip; //script objcet to create order entry.
  showMarket: boolean = true;
  showQty: boolean = true;
  showStopLoss: boolean = false;
  showConfirmBuySell: boolean = false;
  mode: string = "BUY";
  selectedExchange: string = "NSE";
  showExchange: boolean = false;
  prodTypeTab = "DELIVERY";
  deliveryPriceTab = "marketPrice";
  //intradayPriceTab = "marketPrice";
  showMarketDepth = false;
  showAddstoploss = false;
  bcastB5Handler: any;
  LTP: any = "0.00";
  NetChangeInRs = "0.00";
  PercNetChange = "0.00";
  LTPTrend = "";
  B5Data = [];
  showSelectpopup = false;
  showChooseValidity: boolean = false;

  isInitdone: boolean = false;
  objOEDetail: clsOEFormDetl;
  arrExchange = [];
  selExchange = '';
  arrInstruments = [];
  selInstrument = '';

  mpinEnable: boolean = false;

  arrValidity = [];
  selValidity = '';
  arrValidityUI = [];
  arrProductTypes = [];
  arrProductTypesUI = [];
  selProduct = '';
  selProductOrginal = '';
  arrOrderTypes = [];
  arrOrderTypesUI = [];
  selOrderType = '';
  selOrderTypeNew = '';
  arrMargin = [];
  selMargin = '';
  recommendationId = '';
  selBuySell;
  OEOperation = 'selectOEB';

  selSymbol = '';
  arrSeries = [];
  selSeries = '';
  selStrikePrice = '';
  selOptionType = '';
  selExpire = '';
  selProdPer: any = '';
  // MarketSegmentId based on Exchange & Instrument
  marketSegmentId = '';
  mapMarketSegmentId = '';
  // Global Attributes which used to bind with each UI fields value property...
  selMarketLot: any = '';
  selDecimalloc = 100;
  selPriceTick: any = '';

  //Added for ValueAlert Calculation
  priceNumerator: any = 1;
  priceDenominator: any = 1;
  genNumerator: any = 1;
  genDenominator: any = 1;
  intrinsicValue: any = 1;
  selToken: any = '';
  pageSource: any = '';
  selOperation: any;

  selQty: any = '';
  selPrice: any = '';
  selDiscQty: any = '';
  selTriggerPrice: any = '';
  selDay: any = '';
  selAmount: any = '';

  selMPMFFlag = '0';   //Kept by default as 0 for time being untill Margin Plus functionality is implemented
  isSpread = false;
  modifyFlag: boolean = false;
  FIILimit = '';
  NRILimit = '';
  AMOID = '';
  exchangeOrderNo = '';
  gatewayOrderNo = '';
  clientOrderNumber = ''
  clientExchangeOrderID = '';
  orderTime = '';
  participantID = '';
  SPOS = '';
  POSType = '';
  selCOL: boolean = false;
  selCutOff: any = '';

  buyPrice = 0;
  sellPrice = 0;
  LTPVal: any = '0.00'
  LPRVal = '';
  TPRVal = '';
  EnbDisSubmit = true;
  BOSuccessFailure = false;
  netChangeInRs: any = '0.00';
  percNetChange: any = '0.00';

  arrowTrend = '';

  hasBuySell = true;
  hasExchange = true;
  hasInstrument = true;
  hasSymbol = true;
  hasOrderType = true;
  hasQty = true;
  hasPrice = true;
  hasDiscQty = true;
  hasTriggerPrice = false;
  hasProductType = true;
  hasValidity = true;
  hasDay = false;
  hasSeries = false;
  hasOptionType = false;
  hasExpire = false;
  hasProdPer = false;
  hasStrikePrice = false;
  hasCOL = false;
  hasCOLEnabled = false;
  hasCutOff = false;
  hasMargin = false;

  originalQty: number = 0
  isBannedScrip: boolean = false;
  bannedScripErrorMsg: any = ";"
  isMinQtyToShow: boolean = false;
  isBracketDetailsVisible: boolean = false;

  dcEnableDisableFields: Dictionary<boolean>;

  isMPVisible = false;
  showMPDisclaimer = false;
  MPDisclaimer = '';
  MPTriggerPriceLowRange: any = 0;
  MPTriggerPriceHighRange: any = 0;
  MPLimitPriceLowRange: any = 0;
  MPLimitPriceHighRange: any = 0;

  MPCount = 0;
  MPHighPr: any = 0;
  MPLowPr: any = 0;
  MPDecLoc = 100;
  MPDecPrecision = 2;
  MPLimitTrigPerc = 0;
  MPTrigLimitPerc = 0;
  MPDPRFlag: any = 0;
  MPDPRRangePerc = 0;
  MPLTP = 0;
  MPClosePrice = 0;
  MPPriceTick: any = 0;
  MPBasePrice: any = 0;
  MPSetPrice = 0;
  MPVirtualHighPr = 0;
  MPVirtualLowPr = 0;
  MPActualHighPr = 0;
  MPActualLowPr = 0;
  MPSuccessFailure = false;
  MPIsLimitPrEnteredFirst = false;
  MPExpiryValue = '';
  MPStrikePriceValue = '';
  MPTradingAllowed = 0;
  MPLimitTrigPercMin = 0;
  selMPOrderType = '';
  selMPPrice: any = '';
  selMPTriggerPrice: any = '';
  isMPPriceOnFocus = false;
  isMPTrigPriceOnFocus = false;
  hasMPOrderType = false;
  hasMPTriggerPrice = true;
  hasMPPrice = true;
  showTriggerMP = true;
  MPTableText = '';
  MPArrStrikePrice: any = [];

  ProtPercDisclaimer = '';
  showProtPercDisclaimer = false;

  selProfitOrderPrice: any = '';
  selTrailingSL = false;
  trailingSLDisclaimer = clsGlobal.dMsgMaster.getItem("NNSL368");
  selSLJumpPrice: any = '';
  selLTPJumpPrice: any = '';
  PPRVal = '';
  profitPriceLowRange: any = 0;
  profitPriceHighRange: any = 0;
  bracketOrderId = '';
  legIndicator: any = '';
  BOGatewayOrderNo = '';
  profitPricePerc = 0;
  MPProdTypeIndicator = "0";
  isProfitOrderPriceOnFocus = false;
  isSLJumpPriceOnFocus = false;
  isLTPJumpPriceOnFocus = false;

  hasProfitOrderPrice = true;
  hasTrailingSL = true;
  trailingSLAllowed: boolean = false;

  // CR 3327
  capPrice: any = 0;
  floorPrice: any = 0;
  setPrice: any = 0;
  isLastClosingPrice: any = 0;
  isCutOffAllowed: any = 0;
  isSetPrice: any = 0;


  isPopulatePrice: boolean = false;
  isComputeMPRange: boolean = false;
  underlyingMktSegId: any = '';
  underlyingToken: any = '';
  underlyingLTP: any = ''
  isComputeMPOptionParams: boolean = false;

  dcOrderDetails: Dictionary<any> = new Dictionary<any>();

  priceFormatted = '';
  triggerPriceFormatted = '';
  MPPriceFormatted = '';
  MPTriggerPriceFormatted = '';

  showDepth: boolean = false;
  isMarketOrder: boolean = false;
  orderConfirmationModal: any;
  qtyCaption: any = 'Qty';
  //loadingElement: any;
  orderTypeOriginal: any = '';
  pricePrecision: any = 2;
  emptyBestFiveData: any = [];
  //flag to calculate first time prot per //Chetan A
  isfirstTime = true;
  arrError = [];

  totalBuyQty: any;
  totalSellQty: any;
  totalBidQtyPer: any = "-";
  totalAskQtyPer: any = "-";

  orderTypeToggle: any = 'Limit';
  defaultProductType: any = ''
  responseHandler: any;
  inputFieldPriceFormatter: any = "{type:'num',decimal:2}";
  COLDisclaimer = '';
  isConfirmedClick: boolean = false;
  //tempselPrice: any;
  modifydisabled: boolean = false;
  tempobjMultiTouchResp: any;
  validateonce: boolean = false;
  checkFlag: boolean = false;
  objScripUnderlying: any;
  isRangeComputed: Boolean = false;
  tempmodifyFlag: any = false;
  numberortell: any;
  isAMO = false;

  //BT-20365 : BT-20478: YOGESH KADAM :16-06-2020: NSDL & CDSL e-dis Implement in Beyond 2.0 <Start>
  eDISMode: any;
  eDISRequire: boolean = false;    // setting edis require flag to true.
  eDISParams: any;
  //BT-20365 : BT-20478: YOGESH KADAM :16-06-2020: NSDL & CDSL e-dis Implement in Beyond 2.0 <End>

  exchangeScripList = [];
  showDPRError = false;

  customValidityOptions: any = { buttons: [] };
  errorMessage: string = '';
  isCoverAllowed = false;
  isBracketAllowed = false;
  isMTFAllowed = false;

  isCoverDataFilled = false;
  isBracketDataFilled = false;

  approximateMargin: any = 0;
  fundsRequired:any =0;
  availableMargin: any = 0;
  fundsAvailable:any =0;
  orderValue: any = 0;
  showMTF = false;
  //displayExchList:any=[];
  displayExpiryDate = '';
  plcOrder: boolean = true;
  @ViewChild('divOrderScroll', { static: false }) divOrderScroll: ElementRef;
  selLot: any = '';

  calendar: any = {
    mode: 'month',
    currentDate: new Date(new Date().setDate(new Date().getDate() + clsGlobal.User.DefaultGTDDays)),
    locale: 'en-IN',
    dateFormatter: {
      formatMonthViewDay: function (date: Date) {
        return date.getDate();
      },
      formatMonthViewDayHeader: function (date: Date) {
        return date.toDateString().substr(0, 1);
      }
    },
  };
  showGTDDateSelection: boolean = false;
  GTDDate: any = new Date().toDateString();
  GTDNoOfDays: number = 0;
  showCalender: boolean = false;
  currentMonth = clsCommonMethods.getAlphaMonth(this.calendar.currentDate.getMonth());
  currentYear = this.calendar.currentDate.getFullYear();

  isMarginDisplay: boolean = false;
  isMarginBtnEnable: boolean = false;
  MarginLimit = "0.00";
  MarginUtilize = "0.00";
  MarginShortfall = "0.00";
  isFirstMarginCall = true;
  prevSelPrice: any = '';
  prevSelQuantity: any = 0;
  showMarginDisplay: any = true;
  orderID: any;
  eDISReqRefNo: any = '';
  edisNSDLData: any;

  bcastHandler: any;
  localScripKey: any = [];
  approxamt: any = "0.00";
  showRemoveLegPopup: boolean = false

  MultilegsDetails: any = [];
  leg1Edit: boolean = false;
  leg2Edit: boolean = false;
  leg3Edit: boolean = false;
  disableMain: boolean = false;
  legvalidity:  any;
  validityarray : any = [];
  validityarrayUI : any = [];
  chooseMultiLegValidity : boolean = false;

  onScrollChanged = new Subject<any>();
  subscription: any;
  disableSpread : boolean = false;

  shortFall: any = 0;
  fundFlag: boolean = false;
  showMarginLoader: boolean = false;

  showExchangeAction: boolean = false;
  swExchangeList = [];
  showOrderResult: boolean = false;
  isSLOrder: boolean = false;
  dataOE: any;
  confirmTxt: any;
  orderResultID: any;
  _setVar: any;
  exchangeAllowedArry: any = [];

  constructor(private navCtrl: NavController,
    public platform: Platform,
    private httpService: clsHttpService,
    private toastCtrl: ToastServicesProvider,
    private alertCtrl: AlertServicesProvider,
    public modalCtrl: ModalController,
    private tranService: TransactionService,
    private paramService: NavParamService,
    private iab: InAppBrowser,
    public popoverController: PopoverController,
    private appSync: AppsyncDbService) {

  }

  ngOnDestroy(): void {
    //if (!this.isFromOrderEntry) {
    this.ionViewWillLeave();
    //}
    window.removeEventListener('message', (evt: any) => { });
  }

  async ngOnInit() {
    try {
      //this.scripObject.formatScripDisplayName();
      if (this.platform.is('android')) {
        this.numberortell = 'tel';
      }
      else {
        this.numberortell = 'number';
      }

      if(clsGlobal.User.spreadScrips.length == 0)
      {
        this.subscription = this.onScrollChanged.
        pipe(debounceTime(500)).
        subscribe(evt => this.getMarginUtilization());
      }

      //this.availableFunds = this.kFormatter(clsGlobal.User.totalBuyingPower);
      this.paramService.myParam = '';
      this.objOEDetail = this.objOE;
      this.scripObject = this.objOEDetail.scripDetl;
      this.bcastB5Handler = this.receiveBestFiveResponse.bind(this);
      this.bcastHandler = this.receiveTouchlineResponse.bind(this);
      clsGlobal.pubsub.subscribe('B5RES', this.bcastB5Handler);
      clsGlobal.pubsub.subscribe('MTLRES', this.bcastHandler);
      if (this.showMarginDisplay)
        this.isMarginDisplay = true;
      if (!this.isFromOrderEntry) {
        this.sendB5Request(OperationType.ADD, this.scripObject);
      }
      this.checkForScrollDivRender();
      if (this.objOEDetail != undefined) {

        this.B5Data = [];
        this.pageSource = this.objOEDetail.pageSource;
        this.selOperation = this.objOEDetail.buySell == 1 ? clsConstants.C_S_ORDER_BUY_TEXT : clsConstants.C_S_ORDER_SELL_TEXT;
        this.scripObject = this.objOEDetail.scripDetl;
        this.isAMO=this.objOEDetail.isamo || false;
        this.getExchangeList();

        if (this.pageSource == clsConstants.C_V_ORDERBOOK_PAGENO) {
          this.modifyFlag = true;
        }

        this.selDecimalloc = parseInt(this.objOEDetail.scripDetl.DecimalLocator);
        if (isNaN((this.selDecimalloc)))
          this.selDecimalloc = 100;
        this.pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.selDecimalloc.toString().length - 1);
        this.onOperationChange(this.selOperation);
        //added for ResearchCallId by Om D 12 SEP.
        this.recommendationId = this.objOEDetail.recoId;

        this.selMarketLot = this.scripObject.MarketLot;
        this.selExchange = this.objOEDetail.scripDetl.ExchangeName;
        this.onExchangeChange();
        this.selInstrument = this.scripObject.InstrumentName;;
        this.onInstrumentChange();

        if (this.objOEDetail.productType != '')
          this.selProduct = this.objOEDetail.productType;

        this.selSeries = this.scripObject.Series;
        this.selExpire = this.scripObject.ExpiryDate;
        this.selStrikePrice = this.scripObject.StrikePrice;
        this.selOptionType = this.scripObject.OptionType == '' ? 'NA' : this.scripObject.OptionType;
        this.displayExpiryDate = this.scripObject.ExpiryDate == 'NA' ? '' : this.scripObject.ExpiryDate.substr(0, 2) + " " + this.scripObject.ExpiryDate.substr(2, 3)

        if (this.objOEDetail.orderType != undefined && this.objOEDetail.orderType != '') {
          this.selOrderType = this.objOEDetail.orderType;
          this.orderTypeOriginal = this.selOrderType;
        }
        this.onOrderTypesChange(null, null);

        if (this.pageSource == clsConstants.C_V_NETPOSITION_PAGENO ||
          this.pageSource == clsConstants.C_V_STOCKVIEW_PAGENO) {
          this.originalQty = this.objOEDetail.orderQty;
          if (this.selInstrument == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
            this.hasValidity = false;
        }

        ////CR 5879 Banned Script call
        //clsGlobal.BannedScriptStatusFlag = true;
        if ((this.selInstrument.indexOf('FUT') == 0 ||
          this.selInstrument.indexOf('OPT') == 0) &&
          clsGlobal.BannedScriptStatusFlag == true) {
          this.bannedScriptRequest(this.objOEDetail.scripDetl.scripDet.MktSegId, this.objOEDetail.scripDetl.scripDet.token);
        }

        if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT ||
          this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
          this.selPrice = '';// 0;
        } else {
          let valSelPrice = isNaN(this.objOEDetail.orderPrice) ? 0 : this.objOEDetail.orderPrice;
          this.selPrice = valSelPrice;//.toFixed(Global.ExchManager.ReturnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.SelDecimalloc.toString().length - 1));// ko.observable(valSelPrice.toFixed(Global.ExchManager.ReturnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.SelDecimalloc.toString().length - 1)));
        }
        /** <Norwin Dcruz> <16/12/2019> <USD : BT-3884> <Updated for when price is zero,call priceonlostfocus> **/
        if (parseFloat(this.selPrice) == 0 && this.selProduct != 'MULTILEGORDER')
          this.priceOnLostFocus();
        this.selPriceTick = this.objOEDetail.scripDetl.PriceTick;

        let valSelTrgPrice = isNaN(this.objOEDetail.orderTrigPrice) ? '' : this.objOEDetail.orderTrigPrice;
        this.selTriggerPrice = valSelTrgPrice;

        this.onProductTypeChange(null, null);

        if (this.objOEDetail.validity.length > 0) {
          this.selValidity = this.objOEDetail.validity;
        }
        this.onValidityChange('');

        if (this.objOEDetail.day != '')
          this.selDay = this.objOEDetail.day;

        //this.SelQty=(undefined);
        if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_QTY_AUTOFILL) == "true") {
          this.selQty = this.objOEDetail.orderQty;
          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES
          ) {
            this.selLot = this.selQty / this.selMarketLot;
          } else {
            this.selLot = this.selQty;
          }
        }

        if (this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
          this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
          this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_MSX_CASH) {
          this.isMinQtyToShow = true;
        }

        this.isPopulatePrice = true;

        if (this.pageSource == clsConstants.C_V_ORDERBOOK_PAGENO) {

          if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT ||
            this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
            //this.selProductOrginal = 
            this.selProduct = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
          }

          this.fnDisableFieldsForModify();
          this.modifyFlag = true;
          this.tempmodifyFlag = this.modifyFlag;
          this.exchangeOrderNo = this.objOEDetail.exchOrderNo;
          this.gatewayOrderNo = this.objOEDetail.gwOrderNo;
          this.clientOrderNumber = this.objOEDetail.cliOrderNo;
          this.clientExchangeOrderID = this.objOEDetail.cliExchangeOrderID;
          this.orderTime = this.objOEDetail.orderTime;
          //this.selDiscQty = this.objOEDetail.discQty;
          this.showCalender = false;

          this.prevSelPrice = this.selPrice;
          this.prevSelQuantity = (this.objOEDetail.orderQty);

          if (this.selValidity == clsConstants.C_S_VALUE_GTD) {
            this.GTDNoOfDays = parseInt(this.objOEDetail.day);
            this.GTDDate = new Date();
            this.GTDDate.setDate(this.GTDDate.getDate() + (this.GTDNoOfDays));
            this.calendar.currentDate = this.GTDDate;
            this.GTDDate = this.GTDDate.toDateString();
          }

          if (!this.dcEnableDisableFields.getItem("hasDiscQty"))
            this.selDiscQty = (undefined);
          else {
            this.selDiscQty = this.objOEDetail.discQty;
            this.hasDiscQty = this.dcEnableDisableFields.getItem("hasDiscQty");
          }
          this.selQty = this.objOEDetail.orderQty;
          this.originalQty = this.objOEDetail.orderQty;

          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES
          ) {
            this.selLot = this.selQty / this.selMarketLot;
          } else {
            this.selLot = this.selQty;
          }
          //change for Order Type
          this.hasOrderType = clsGlobal.ExchManager.orderTypeEnableDisable(this.selOrderType, this.scripObject.scripDet.MktSegId);

          if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT ||
            this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
            this.selPrice = '';//0;//Set it to zero

          if (this.objOEDetail.COL == clsConstants.C_S_ON)
            this.selCOL = true;
          else
            this.selCOL = false;

          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_MCX_DERIVATIVES
            || this.scripObject.scripDet.MktSegId == clsConstants.C_V_MSX_CASH
            || this.scripObject.scripDet.MktSegId == clsConstants.C_V_MSX_FAO) {
            if (this.objOEDetail.protPerc > 0)
              this.selProdPer = (parseFloat(this.objOEDetail.protPerc) / 100);
          }

          //CR 3327
          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_OFS_IPO_BONDS) {
            if (clsGlobal.User.OdinCategory == 5 || clsGlobal.User.nseEqParticipantID.length > 0) {
              this.selMargin = this.objOEDetail.OFSMargin;
            }
          }

          if (this.objOEDetail.productType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {

            this.selMPOrderType = this.objOEDetail.orderType; //Set the order type which is coming from orderbook

            this.hasPrice = false;//Disable OE price
            this.selPrice = '';//0;//Set it to zero
            this.hasTriggerPrice = false;//Disable OE trigger price
            this.selTriggerPrice = '';//Set it to zero

            //In case of stop loss then set the trigger price and make it enabled
            if (this.selMPOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
              this.selMPTriggerPrice = this.objOEDetail.orderTrigPrice;
              this.hasMPOrderType = true;
              this.hasMPTriggerPrice = true;
              this.isMPTrigPriceOnFocus = false;
              let valtmpPrice: any = isNaN(this.objOEDetail.orderPrice) ? 0 : this.objOEDetail.orderPrice;
              this.selMPPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);
            }

            // if (this.selMPOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
            //   this.hasMPOrderType = false;
            //   this.hasMPTriggerPrice = false;
            //   this.showTriggerMP = false;
            //   this.hasMPPrice = true;
            // }

            this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
            //Disabling quantity and validity for margin plus
            if (this.modifyFlag) {
              this.hasQty = false;
            }
            this.hasDiscQty = false;
            this.selDiscQty = '';
            this.hasValidity = false;
            this.hasOrderType = false;
            ///Condition handled for margin plus to flip sides in case of modification
            if (this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT) {
              this.selOperation = clsConstants.C_S_ORDER_SELL_TEXT;
              this.selBuySell = clsConstants.C_S_ORDER_SELL_TEXT;
            }
            else {
              this.selOperation = clsConstants.C_S_ORDER_BUY_TEXT;
              this.selBuySell = clsConstants.C_S_ORDER_BUY_TEXT;
            }
          }

          if (this.objOEDetail.productType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

            this.hasMPOrderType = false;
            //Disabling quantity and validity for bracket Order
            this.hasQty = false;
            this.hasDiscQty = false;
            this.selDiscQty = '';
            this.hasValidity = false;
            this.hasOrderType = false;

            this.hasPrice = false;
            this.hasMPPrice = false;
            this.hasMPTriggerPrice = false;
            this.hasProfitOrderPrice = false;
            this.hasTrailingSL = false;

            let valtmpPrice;
            //let pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.selDecimalloc.toString().length - 1);

            //if SL mkt then dont populate SL Price
            if (this.objOEDetail.SLOrderType == clsConstants.C_V_ORDER_STOPLOSS ||
              this.objOEDetail.SLOrderType == clsConstants.C_V_ORDER_STOPLOSS_MARKET) {
              valtmpPrice = isNaN(this.objOEDetail.SLOrderPrice) ? 0 : this.objOEDetail.SLOrderPrice;
              this.selMPPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);
              this.isMPPriceOnFocus = true;
            }

            valtmpPrice = isNaN(this.objOEDetail.SLTrigOrderPrice) ? 0 : this.objOEDetail.SLTrigOrderPrice;
            this.selMPTriggerPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);;
            this.isMPTrigPriceOnFocus = true;

            valtmpPrice = this.objOEDetail.SLJumpPrice;
            if (valtmpPrice > 0) { //If SL jump price > 0 then select SelTrailingSL checkbox
              this.hasTrailingSL = true;
              this.selTrailingSL = true;
              this.selSLJumpPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);
              this.isSLJumpPriceOnFocus = true;

              //if (clsGlobal.isJumpBothLtpAndTrigPrice) { //based on configuration fill LTP jump price
              valtmpPrice = this.objOEDetail.LTPJumpPrice;
              this.selLTPJumpPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);
              this.isLTPJumpPriceOnFocus = true;
              //}
            } else {
              this.hasTrailingSL = false;
            }
            /** <Norwin Dcruz> <10/12/2019> <USD : BT-3884> <To Diaable Trailing stop loss button when LTP Jump and SL Jump Price is 0 in modification> **/
            if (this.modifyFlag == true && this.objOEDetail.LTPJumpPrice.toString() == '0.00' && this.objOEDetail.SLJumpPrice.toString() == '0.00') {
              this.modifydisabled = true;
            }

            valtmpPrice = this.objOEDetail.profitOrderPrice;
            this.selProfitOrderPrice = parseFloat(valtmpPrice).toFixed(this.pricePrecision);;
            this.isProfitOrderPriceOnFocus = true;

            this.selProdPer = (parseInt(this.objOEDetail.protPerc) / this.selDecimalloc).toFixed(this.pricePrecision);

            this.bracketOrderId = this.objOEDetail.bracketOrderId;
            this.legIndicator = this.objOEDetail.legIndicator;
            this.BOGatewayOrderNo = this.objOEDetail.boGWOrderNo;

            let bracketOrderModifyBit = this.objOEDetail.boModifyBit;

            this.isMPPriceOnFocus = true;
            this.isProfitOrderPriceOnFocus = true;

            let b1stLegModify = false;
            let b2ndLegModify = false;
            let b3rdLegModify = false;

            if ((bracketOrderModifyBit & clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG1_MASKBIT) == clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG1_MASKBIT) {
              b1stLegModify = true;
              b2ndLegModify = true;
              b3rdLegModify = true;
            }
            if ((bracketOrderModifyBit & clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG2_MASKBIT) == clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG2_MASKBIT)
              b2ndLegModify = true;

            if ((bracketOrderModifyBit & clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG3_MASKBIT) == clsConstants.C_V_BRACKET_ORDER_MODIFY_LEG3_MASKBIT)
              b3rdLegModify = true;

            if (b2ndLegModify) {
              this.hasMPPrice = true;
              this.hasMPTriggerPrice = true;
              // this.hasTrailingSL = true;
              this.isMPPriceOnFocus = true;
            }

            if (b3rdLegModify) {
              this.hasProfitOrderPrice = true;
              this.isProfitOrderPriceOnFocus = true;
            }

            if (b1stLegModify) {
              this.hasQty = true;
              this.hasPrice = true;
              //this.isPriceOnFocus=true;
            }
            else
              this.hasProdPer = false; //if the 1st leg is partially or fully executed then the protection % field should be disabled in the modify Order entry screen.
          }
          //CR 3688
          if (this.selInstrument == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT) {
            this.hasOrderType = false;
            this.selDiscQty = 0;
            this.selTriggerPrice = '';
          }

          if (this.selMPTriggerPrice != '' && this.selMPTriggerPrice != 0) {
            this.isCoverDataFilled = true;
            this.isCoverAllowed = true;
          } else {
            this.isCoverDataFilled = false;
            this.isCoverAllowed = false;
          }

          if (this.selProfitOrderPrice != '' && this.selProfitOrderPrice != 0) {
            this.isBracketDataFilled = true;
            this.isBracketAllowed = true;
          } else {
            this.isBracketDataFilled = false;
            this.isBracketAllowed = false;
          }

          //CR 3327
          if (parseFloat(this.selPrice) == 0 && this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)
            this.selCutOff = true;

          if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
            this.deliveryPriceTab = 'limitPrice';
          }
          else if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
            this.deliveryPriceTab = 'marketPrice';
          }
          else if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
            this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
            this.deliveryPriceTab = 'triggerPrice';
          }

        }//order book cond ends here

        if (this.pageSource == clsConstants.C_V_STOCKVIEW_PAGENO
          || this.pageSource == clsConstants.C_V_NETPOSITION_PAGENO) {
          this.fnDisableFieldsForModify();
          this.selQty = this.objOEDetail.orderQty;

          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES
          ) {
            this.selLot = this.selQty / this.selMarketLot;
          } else {
            this.selLot = this.selQty;
          }
        }

        if (this.pageSource == clsConstants.C_V_MARKETWATCH_PAGENO ||
          this.pageSource == clsConstants.C_V_BESTFIVE_PAGENO ||
          this.pageSource == clsConstants.C_V_RECOMMENDATION_PAGE) {

          this.fnDisableFieldsForMW();

          if (this.pageSource == clsConstants.C_V_RECOMMENDATION_PAGE) {
            this.recommendationId = this.objOEDetail.recoId;

            this.selQty = this.objOEDetail.orderQty;
            this.originalQty = this.objOEDetail.orderQty;
            // if (this.scripObject.scrreipDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES
            //   ) {
            //   this.selLot = this.selQty / this.selMarketLot;
            // } else {
            this.selLot = this.selQty;
            //}
            if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT ||
              this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
              //this.selProductOrginal = 
              this.selProduct = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
            }
            if (this.objOEDetail.orderType != undefined && this.objOEDetail.orderType != '') {
              this.selOrderType = this.objOEDetail.orderType;
              this.orderTypeOriginal = this.selOrderType;
            }
            if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT) {
              this.deliveryPriceTab = 'limitPrice';
            }
            else if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
              this.deliveryPriceTab = 'marketPrice';
            }
            else if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
              this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
              this.deliveryPriceTab = 'triggerPrice';
            }

            // if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT ||
            //   this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
            //   this.selPrice = '';// 0;
            // } else {
            let valSelPrice = isNaN(this.objOEDetail.orderPrice) ? 0 : this.objOEDetail.orderPrice;
            this.selPrice = valSelPrice;//.toFixed(Global.ExchManager.ReturnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.SelDecimalloc.toString().length - 1));// ko.observable(valSelPrice.toFixed(Global.ExchManager.ReturnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.SelDecimalloc.toString().length - 1)));
            //}
            this.isPopulatePrice = false;
            if (this.objOEDetail.recoSQprice > 0) {
              // this.selProduct = (clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT);

              this.selProfitOrderPrice = this.objOEDetail.recoSQprice
              this.selMPPrice = this.objOEDetail.recoSLprice;

            }
            else {
              if (this.objOEDetail.recoSLprice > 0) {

                //this.selProduct = (clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
                this.selMPPrice = this.objOEDetail.recoSLprice;;
                this.selMPTriggerPrice = this.objOEDetail.recoSLprice;
                this.selTriggerPrice = this.objOEDetail.recoSLprice;

              }
            }

          }

          if (this.scripObject.ExpiryDate != 'NA') {
            this.validityarray = (clsGlobal.ExchManager.populateValidityForSpread(this.scripObject.scripDet.MapMktSegId, this.scripObject.Spread));
            this.legvalidity = this.validityarray[0];
            for (let index = 0; index < this.validityarray.length; index++) {
              const element = this.validityarray[index];
              let itemValidityType: any = {};
              //itemValidityType.isChecked = (this.validityarray == element) ? true : false;
              itemValidityType.value = element;
              itemValidityType.desc = clsTradingMethods.getValidityTypeDescription(element);
              this.validityarrayUI.push(itemValidityType);
            }
            if(clsGlobal.User.spreadScrips.length == 0)
            {
              this.disableSpread = false;
              let leg1Details: any = {
                legsymbol: this.scripObject.symbol,
                legexpiryDate: this.scripObject.ExpiryDate == 'NA' ? '' : this.scripObject.ExpiryDate,
                legexpiryDayIOS: this.scripObject.ExpiryDate.substr(2, 3) + '/' + this.scripObject.ExpiryDate.substr(0, 2) + '/' + this.scripObject.ExpiryDate.substr(-4),
                // this.legexpiryMonth : this.legexpiryDate.substr(2,3),
                legexchangename: this.scripObject.ExchangeName,
                leginstrumentName: this.scripObject.InstrumentName,
                //this.leginstru : this.leginstrumentName.substr(0,3)
                legstrikePrice: (this.scripObject.StrikePrice == 'NA') ? '' : this.scripObject.StrikePrice,
                legoptionType: this.scripObject.OptionType == 'NA' ? '' : this.scripObject.OptionType,
                originallegLot: this.selMarketLot,
                totallegLot : 1,
                legmktsegid: this.scripObject.scripDet.MktSegId,
                legmapmktsegid: this.scripObject.scripDet.MapMktSegId,
                legseries: 'XX',
                legDecimalLocator: this.scripObject.DecimalLocator || 100,
                legToken: this.scripObject.scripDet.token,
                legpricetick: this.scripObject.PriceTick,
                selmarketlegPrice: '0.00',
                legpriceprecision: this.pricePrecision,
                legpricetoggle: 'marketlegPrice',
                legprice: '0.00',
                legopenclose: false,
                legbuysell: 'BUY',
                sellimitlegPrice: '',
                removeLeg: false
              }
              this.MultilegsDetails.push(leg1Details);
              this.sendLegTouchLine();
              await this.getScripForSecondLeg();
            }
            else
            {
              this.disableSpread = true;
              this.MultilegsDetails = clsGlobal.User.spreadScrips;
              this.getMarginUtilization();
              this.sendLegTouchLine();
            }
          }
        }

        if (this.pageSource == clsConstants.C_V_STOCKVIEW_PAGENO) {
          this.showExchangeAction = true;
          if (this.objOEDetail.segmentsAllowed != '') {
            this.fillExchangeSegments();
          }
        }

        //this.sendB5Request(OperationType.ADD, this.scrip);

      } else {
        this.toastCtrl.showAtBottom('Invalid scrip detail received.');
      }

      window.addEventListener('message', (evt: any) => {
        if (evt && evt.data) {
          console.log('EDIS Response: ', evt.data);
          if (evt.data.respdata != undefined) {
            let jsonData = JSON.parse(evt.data.respdata);
            this.processEDISResponse(jsonData, undefined);
          }
        }
      });

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'ngOnInit', error);
    }

  }

  checkForScrollDivRender() {
    try {

      //console.log("Scroll Div:", this.divScrollContent);
      if (this.divOrderScroll != undefined) {
        this.divOrderScroll.nativeElement.addEventListener("scroll", (event) => {
          if (event) {
            //console.log('ScrollTop: ',event.target.scrollTop);
            if (event.target.scrollTop > 80) {
              this.priceOnFocus();
            }
          }
        });

      } else {
        setTimeout(() => {
          this.checkForScrollDivRender();
        }, 400);
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('WatchlistPage', 'checkForElementReder', error);
    }
  }

  onOperationChange(opType) {
    try {
      this.selOperation = opType;
      this.selBuySell = this.selOperation;
      this.validateonce = false;

      if (!this.modifyFlag)
        this.fnCheckForMarginPlus();

      /** <Norwin Dcruz> <13/12/2019> <USD : BT-3884> <Binding Price> **/
      if (this.pageSource != clsConstants.C_V_ORDERBOOK_PAGENO &&
        this.selProduct != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
        if (this.selOperation == clsConstants.C_S_ORDER_BUY_TEXT) {
          this.selPrice = this.sellPrice.toFixed(this.pricePrecision);
        } else {
          this.selPrice = this.buyPrice.toFixed(this.pricePrecision);
        }
      }
      //}
    }
    catch (e) {
      //this.toastCtrl.showAtBottom('OnOperationChange: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'OnOperationChange', e);

    }
  }

  onExchangeChange() {
    try {
      //fn_ResetFields();
      if (this.selExchange != undefined && this.selExchange != '') {
        //this.SelInstrument(undefined);
        this.populateInstrument(this.selExchange);
        this.selInstrument = this.arrInstruments[0];
      }
    }
    catch (e) {
      console.log(e);
      //this.toastCtrl.showAtBottom('onExchangeChange: ' + e.message);
    }
  }

  // Pouplate the Insturment for the selected Exchange...
  populateInstrument(_ExchName) {
    try {
      this.arrInstruments = clsGlobal.ExchManager.populateInstrument(_ExchName, clsConstants.C_V_ORDERENTRY_PAGE);
    }
    catch (e) {
      console.log(e);
      //this.toastCtrl.showAtBottom('populateInstrument: ' + e.message);
    }
  }

  onInstrumentChange() {
    try {
      //this.fnResetFields();
      this.getDetailsForInst(this.selExchange, this.selInstrument);
      // filling the validity dropdown
      this.selValidity = this.arrValidity[0];
      // filling the product type dropdown
      //this.selProduct = this.arrProductTypes[0];
      // filling the order type dropdown
      this.selOrderType = this.arrOrderTypes[0];

      // CR 3327
      // filling the order type dropdown
      this.selMargin = this.arrMargin[0];
      let QtyLotCaption = clsGlobal.ExchManager.getQtyLotCaption(this.scripObject.scripDet.MktSegId, this.scripObject.MarketLot, true);
      this.qtyCaption = QtyLotCaption;
    }
    catch (e) {
      //this.toastCtrl.showAtBottom('onInstrumentChange: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'onInstrumentChange', e);
    }
  }

  async getDetailsForInst(_ExchName, _InstName) {
    try {
      // First get the market Segment Id
      if (clsGlobal.ExchManager.loginAllowed.getItem(this.scripObject.scripDet.MktSegId.toString()) == clsConstants.C_S_ON) {

        // this.selDecimalloc = clsGlobal.ExchManager.getDecimalLocator(_ExchName, this.scripObject.scripDet.MktSegId);
        // Populate the Validaity
        this.arrValidity = (clsGlobal.ExchManager.populateValidity(_ExchName, this.scripObject.scripDet.MktSegId));
        // Populate the Product Types
        this.arrProductTypes = (clsGlobal.ExchManager.populateProductTypes(_ExchName, this.scripObject.scripDet.MktSegId, false));

        if (this.arrValidity != undefined) {
          this.arrValidityUI = [];
          this.selValidity = this.arrValidity[0];
          for (let index = 0; index < this.arrValidity.length; index++) {
            const element = this.arrValidity[index];
            let itemValidityType: any = {};
            itemValidityType.isChecked = (this.selValidity == element) ? true : false;
            itemValidityType.value = element;
            itemValidityType.desc = clsTradingMethods.getValidityTypeDescription(element);
            this.arrValidityUI.push(itemValidityType);
          }
        }
        if (this.arrProductTypes != undefined) {
          if (!this.selProduct) {

            this.selProduct = this.arrProductTypes[0];
            let prefProdType = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
            if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != "" && clsGlobal.User.userPreference != null) {
              if (clsGlobal.User.userPreference.sExchange != null && clsGlobal.User.userPreference.sExchange != undefined && clsGlobal.User.userPreference.sExchange != "") {
                let userPref = JSON.parse(clsGlobal.User.userPreference.sExchange);
                userPref.filter(x => {
                  if (x.marketSegmentId == this.scripObject.scripDet.MktSegId) {
                    this.selProduct = x.productType;
                    this.selProdPer = x.protection;                 
                  }
                })
              }
            } else {
              await this.appSync.getUserPreferenceData().then((res: any) => {
                if (res != undefined && res.length > 0) {
                  if (res[0].sExchange != null && res[0].sExchange != undefined && res[0].sExchange != "") {
                    let userPref = JSON.parse(res[0].sExchange);
                    userPref.filter(x => {
                      if (x.marketSegmentId == this.scripObject.scripDet.MktSegId) {
                        this.selProduct = x.productType;
                        this.selProdPer = x.protection;                    
                      }
                    })
                  }
                }
              }).catch(error => {
                console.log("Error in getting user preference : " + error);
              })
              // try {
              //   if (clsGlobal.User.userPreference == undefined) {
              //     prefProdType = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
              //   }
              //   else {
              //     prefProdType = JSON.parse(clsGlobal.User.userPreference.sOrder).productType == undefined || JSON.parse(clsGlobal.User.userPreference.sOrder).productType == "" ? clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT : JSON.parse(clsGlobal.User.userPreference.sOrder).productType;
              //   }
              // } catch (error) {

              // }

              // if (prefProdType == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT && (this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
              //   this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
              //   this.objOEDetail.scripDetl.scripDet.MktSegId != clsConstants.C_V_MSX_CASH)) {
              //   prefProdType = clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT;;
              // }

              // if (this.arrProductTypes.indexOf(prefProdType)) {


              //   this.selProduct = prefProdType;

              //   if (prefProdType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
              //     prefProdType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
              //     this.selProduct = clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT;
              //   }
              //   if (prefProdType == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT) {
              //     this.selProduct = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
              //   }
              // }

            }
            this.arrProductTypesUI = [];//to handel segment change.
            for (let index = 0; index < this.arrProductTypes.length; index++) {

              const element = this.arrProductTypes[index];
              //&& element != clsConstants.C_S_PRODUCTTYPE_MTF_TEXT
              if (element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
                element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

                let itemProdType: any = {};
                itemProdType.isChecked = (this.selProduct == element) ? true : false;
                itemProdType.name = clsTradingMethods.getProductTypeName(element);
                itemProdType.value = element;
                itemProdType.desc = clsTradingMethods.getProductTypeDescription(element);
                /** <Norwin Dcruz> <02/12/2019> <USD : BT-3884> <Commented in order to show bracket order in frontend> **/
                // if (element != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
                //   element != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
                if ((element == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT || element == clsConstants.C_S_PRODUCTTYPE_PTST_TEXT) && this.selInstrument == clsConstants.C_S_INSTRUMENT_EQUITIES_TEXT) {
                  this.arrProductTypesUI.push(itemProdType);
                } else {
                  if (element != clsConstants.C_S_PRODUCTTYPE_MTF_TEXT && element != clsConstants.C_S_PRODUCTTYPE_PTST_TEXT) {
                    this.arrProductTypesUI.push(itemProdType);
                  }
                }



              }

              if (element == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
                this.isCoverAllowed = true;
              }

              if (element == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
                this.isBracketAllowed = true;
              }

              if (element == clsConstants.C_S_PRODUCTTYPE_MTF_TEXT) {
                this.isMTFAllowed = true;
              }

            }
            if (this.scripObject.ExpiryDate != "NA" && this.scripObject.ExchangeName.toUpperCase() != 'NCDEX') {
              let itemProdType: any = {};
              itemProdType.isChecked = (this.selProduct.toUpperCase() == 'MULTILEGORDER') ? true : false;
              itemProdType.name = "Multileg Order";
              itemProdType.value = "MULTILEGORDER";
              itemProdType.desc = "Buy/Sell in Multiple Legs";
              this.arrProductTypesUI.push(itemProdType);
            }
          }

          // Populate the Order Types
          this.arrOrderTypes = (clsGlobal.ExchManager.populateOrderTypes(_ExchName, this.scripObject.scripDet.MktSegId));

          if (this.arrOrderTypes != undefined) {
            this.selOrderType = this.arrOrderTypes[0];
            for (let index = 0; index < this.arrOrderTypes.length; index++) {
              const element = this.arrOrderTypes[index];

              if (element == clsConstants.C_S_ORDER_REGULARLOT_TEXT ||
                element == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                element == clsConstants.C_S_ORDER_CALLAUCTION_TEXT) {

                let orderType = '';
                if (element == clsConstants.C_S_ORDER_REGULARLOT_TEXT ||
                  element == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT) {
                  orderType = clsConstants.C_S_ORDER_TYPE_REGULARLOT_TEXT;
                  let itemOrderType: any = {};
                  itemOrderType.isChecked = (this.selOrderType == element) ? true : false;
                  itemOrderType.value = orderType;//element;

                  this.arrOrderTypesUI.push(itemOrderType);
                }
                else if (element == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
                  element == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
                  orderType = clsConstants.C_S_ORDER_TYPE_STOPLOSS_TEXT;
                  let itemOrderType: any = {};
                  itemOrderType.isChecked = (this.selOrderType == element) ? true : false;
                  itemOrderType.value = orderType;//element;

                  this.arrOrderTypesUI.push(itemOrderType);
                }
                // else if (element == clsConstants.C_S_ORDER_CALLAUCTION_TEXT) {
                //   orderType = clsConstants.C_S_ORDER_TYPE_CALLAUCTION_TEXT;
                // }

              }

            }
          }

          // Populate the Margin dropdown
          this.arrMargin = (clsGlobal.ExchManager.populateMarginDD());

          // Get the Enable/Disable flags for all the UI elements...
          this.dcEnableDisableFields = clsGlobal.ExchManager.enableDisable(_ExchName, _InstName);
          // Enable / Disable the UI elements
          this.enableDisable();
          this.hasMargin = (clsGlobal.ExchManager.displayMarginDD(_ExchName, _InstName));
        }
    }
    }
    catch (e) {
      //this.toastCtrl.showAtBottom('getDetailsForInst: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getDetailsForInst', e);
    }
  }

  // Function to Enable / Disable the UI elements based on the value in the hash table...
  enableDisable() {
    try {
      if (this.pageSource != clsConstants.C_V_ORDERBOOK_PAGENO &&
        this.pageSource != clsConstants.C_V_NETPOSITION_PAGENO &&
        this.pageSource != clsConstants.C_V_STOCKVIEW_PAGENO) {
        this.hasBuySell = this.dcEnableDisableFields.getItem("hasBuySell");
        this.hasExchange = this.dcEnableDisableFields.getItem("hasExchange");
        this.hasInstrument = this.dcEnableDisableFields.getItem("hasInstrument");
        this.hasSymbol = this.dcEnableDisableFields.getItem("hasSymbol");

        this.hasSeries = this.dcEnableDisableFields.getItem("hasSeries");
        this.hasExpire = this.dcEnableDisableFields.getItem("hasExpire");
        this.hasStrikePrice = this.dcEnableDisableFields.getItem("hasStrikePrice");
        this.hasOptionType = this.dcEnableDisableFields.getItem("hasOptionType");
        this.hasOrderType = this.dcEnableDisableFields.getItem("hasOrderType");
        this.hasProductType = this.dcEnableDisableFields.getItem("hasProductType");
        this.hasValidity = this.dcEnableDisableFields.getItem("hasValidity");

        if (!this.dcEnableDisableFields.getItem("hasQty"))
          this.selQty = (undefined);
        this.hasQty = (this.dcEnableDisableFields.getItem("hasQty"));
        if (!this.dcEnableDisableFields.getItem("hasPrice"))
          this.selPrice = (undefined);
        this.hasPrice = (this.dcEnableDisableFields.getItem("hasPrice"));
        if (!this.dcEnableDisableFields.getItem("hasDiscQty"))
          this.selDiscQty = (undefined);
        this.hasDiscQty = (this.dcEnableDisableFields.getItem("hasDiscQty"));
        if (!this.dcEnableDisableFields.getItem("hasTriggerPrice"))
          this.selTriggerPrice = '';
        this.hasTriggerPrice = (this.dcEnableDisableFields.getItem("hasTriggerPrice"));
        if (!this.dcEnableDisableFields.getItem("hasDay"))
          this.selDay = 0;
        this.hasDay = (this.dcEnableDisableFields.getItem("hasDay"));
        //TODO:
        // if (!this.dcEnableDisableFields.getItem("hasProdPer"])
        //  this.selProdPer = (undefined);
        this.hasProdPer = this.dcEnableDisableFields.getItem("hasProdPer");
        this.hasCOL = this.dcEnableDisableFields.getItem("hasCOL");

        if (this.pageSource == clsConstants.C_V_ORDERBOOK_PAGENO)
          this.hasCOLEnabled = false;
        else {
          if (this.dcEnableDisableFields.getItem("hasCOLEnabled") != undefined)
            this.hasCOLEnabled = this.dcEnableDisableFields.getItem("hasCOLEnabled") && this.hasCOL;
          else
            this.hasCOLEnabled = this.hasCOL;
        }
        /** <Norwin Dcruz> <16/12/2019> <USD : BT-3884> <Disabling validity in case of bracket order> **/
        if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          this.hasValidity = false;

        /** <Norwin Dcruz> <24/12/2019> <USD : BT-3884> <Disabling ordertype in case of bracket order> **/
        if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          this.hasOrderType = false;
      }
    }
    catch (e) {
      console.log(e);
      //this.toastCtrl.showAtBottom('enableDisable: ' + e.message);
    }
  }

  // Function to Enable / Disable the UI elements based on the value in the hash table...
  enableDisableForModify() {
    try {
      // if (!this.dcEnableDisableFields.getItem("hasPrice"))
      //   this.selPrice = (undefined);
      // this.hasPrice = this.dcEnableDisableFields.getItem("hasPrice");
      if (!this.dcEnableDisableFields.getItem("hasDiscQty"))
        this.selDiscQty = (undefined);
      this.hasDiscQty = this.dcEnableDisableFields.getItem("hasDiscQty");
      if (!this.dcEnableDisableFields.getItem("hasTriggerPrice"))
        this.selTriggerPrice = '';
      this.hasTriggerPrice = this.dcEnableDisableFields.getItem("hasTriggerPrice");
      if (!this.dcEnableDisableFields.getItem("hasDay"))
        this.selDay = '';
      this.hasDay = this.dcEnableDisableFields.getItem("hasDay");

      //if (!this.dcEnableDisableFields.getItem("hasCOL"])
      //   this.SelCOLfalse;
      this.hasCOL = this.dcEnableDisableFields.getItem("hasCOL");
      this.hasCOLEnabled = this.hasCOL;

      /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Added for precision in price> **/
      if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && this.modifyFlag == true) {
        this.selProdPer = this.objOEDetail.protPerc;
      }
      else {
        if (parseFloat(this.selPrice) == 0 &&
          (this.objOEDetail.scripDetl.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES
            || this.objOEDetail.scripDetl.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSE_CASH
            || this.objOEDetail.scripDetl.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_BSECDX_DERIVATIVES)) {
          this.hasProdPer = true;
          this.selProdPer = this.objOEDetail.protPerc;
        }
      }


    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'enableDisableForModify', e);
    }
  }


  fnDisableFieldsForModify() {
    this.hasBuySell = false;
    this.hasExchange = false;
    this.hasInstrument = false;
    this.hasSymbol = false;
    this.hasSeries = false;
    this.hasExpire = false;
    this.hasStrikePrice = false;
    this.hasOptionType = false;
    this.hasProductType = false;
    if (this.selValidity != clsConstants.C_S_VALUE_GTD)
      this.hasDay = false;
    else
      this.hasDay = true;
  }

  fnDisableFieldsForMW() {
    this.hasExchange = false;
    this.hasInstrument = false;
    this.hasSymbol = false;
    this.hasSeries = false;
    this.hasExpire = false;
    this.hasStrikePrice = false;
    this.hasOptionType = false;
    this.hasProdPer = false;
  }

  onValidityChange(event) {
    try {

      if (event) {

        if (this.arrValidityUI != undefined) {
          let idxItem: number;
          for (let index = 0; index < this.arrValidityUI.length; index++) {
            const element = this.arrValidityUI[index];
            this.arrValidityUI[index].isChecked = false;
            if (element.value == event.detail.value) {
              idxItem = index;
              this.selValidity = event.detail.value;
            }
          }
          if (idxItem != undefined)
            this.arrValidityUI[idxItem].isChecked = true;
        }

        ///if (!this.modifyFlag) {
        if (event.detail.value == clsConstants.C_S_VALUE_GTD) {
          this.showGTDDateSelection = true;
          this.showCalenderDiv();
        } else {
          this.showGTDDateSelection = false;
        }
        //}
      }

      this.selDiscQty = 0;
      if (this.selValidity != undefined && this.selValidity != '') {

        this.getDetailsForValidity(this.selExchange, this.selValidity, this.selInstrument);
        if (parseFloat(this.selPrice) != 0) {
          //if(this.selProduct != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          this.hasProdPer = false;
        }

        if (this.selValidity == 'GTD') {
          this.showGTDDateSelection = true;
          this.showCalenderDiv();
        } else {
          this.showGTDDateSelection = false;
        }

      }
    }
    catch (e) {
      console.log(e);
      //this.toastCtrl.showAtBottom('onValidityChange: ' + e.message);
    }
  }

  getDetailsForValidity(_ExchName, _Validity, _instName) {
    try {
      this.dcEnableDisableFields = clsGlobal.ExchManager.getDetailsForValidity(_ExchName, _Validity, _instName, this.selOrderType);
      if (this.pageSource != clsConstants.C_V_ORDERBOOK_PAGENO &&
        this.pageSource != clsConstants.C_V_NETPOSITION_PAGENO &&
        this.pageSource != clsConstants.C_V_STOCKVIEW_PAGENO) {
        this.enableDisable();
        let _bDiscQtyFillValue = clsGlobal.ExchManager.getDiscQtyFillValue(this.scripObject.scripDet.MktSegId, _Validity, this.selOrderType, null);
        if (_bDiscQtyFillValue)
          this.selDiscQty = (this.selQty);
      }
      else
        this.enableDisableForModify();
    }
    catch (e) {
      //this.toastCtrl.showAtBottom('getDetailsForValidity: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getDetailsForValidity', e);
    }
  }


  bannedScriptRequest(MktSegment, Token) {
    try {
      let banScripReq: any = {};
      banScripReq.mktSegId = MktSegment;
      banScripReq.token = Token;
      banScripReq.siTemplateId = clsGlobal.User.SITemplateId;
      this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getBannedScripStatus/' + MktSegment + '/' + Token).subscribe(((data: any) => {
        try {

          if (data.status) {
            let Response = data.result;
            if (Response[0][""] != "") {
              if (Response[0][""] == "0") // If the value is other than 0 than it is a banned scrip
                this.isBannedScrip = false;
              else
                this.isBannedScrip = true;
            }
            if (this.isBannedScrip == true) {
              let strMessage = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_BANNED_SCRIP_MESSAGE);
              if (strMessage != undefined)
                this.bannedScripErrorMsg = strMessage;

              if (this.isBannedScrip == true && clsGlobal.BannedScriptStatusFlag == true) {
                this.alertCtrl.showAlertWithCallback("Security is in banned list, do you want to place order?").then((bSendOrder: any) => {
                  if (!bSendOrder) {
                    //this.goBack();
                  }
                });
              }

            }
          } else {
            console.log(data.errorCode);
            //this.toastCtrl.showAtBottom(data.errorCode);
          }

        } catch (error) {
          //this.toastCtrl.showAtBottom(error.message);
          clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'bannedScriptRequest', error);
        }
      }), error => {
        console.log(error);
        //this.toastCtrl.showAtBottom(error);
      })
    }
    catch (e) {
      console.log(e);
      //this.toastCtrl.showAtBottom('bannedScriptRequest: ' + e.message);
    }
  };

  onProductTypeChange(event, itemSelected) {

    try {

      if (itemSelected != undefined && itemSelected != null) {
        this.selProduct = itemSelected.value;
        this.setProductTypeSelected();
      }

      if (this.selProduct != undefined) {
        this.fnOnProductTypeChange();

        this.resetValidity();
        this.resetComplexOrderDetails();

        if (!this.modifyFlag)
          this.fnCheckForMarginPlus();
      }
      /** <Norwin Dcruz> <18/12/2019> <USD : BT-3884> <Added to get price values and range> **/
      this.priceOnLostFocus()


    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'onProductTypeChange', e);
    }
  }

  fnOnProductTypeChange() {
    try {
      this.isBracketDetailsVisible = false;
      this.hasDiscQty = this.dcEnableDisableFields.getItem("hasDiscQty");
      this.hasCOL = this.dcEnableDisableFields.getItem("hasCOL");
      this.hasValidity = true;

      this.setProtPerc();
      let prodType = this.selProduct;
      if (this.modifyFlag) {
        prodType = this.objOEDetail.productType;
      }
      //In case of Margin Plus, set the order type as SL Order Type and Disable as only SL Orders are valid in MP
      if (prodType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT
        || prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

        this.fnSetDefaultMPFields();

        if (prodType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
          this.hasPrice = false;
          this.selPrice = '';//0;
          this.hasMPOrderType = true;
          this.selTriggerPrice = '';
          this.hasTriggerPrice = false;
          this.MPTableText = ('Cover/Second Leg Order Detail');
          this.selDiscQty = '';
          this.hasDiscQty = false;
          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_NSE_CASH) {
            this.selValidity = clsConstants.C_S_VALUE_DAY;
            this.hasValidity = false;
          }
        }
        else if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

          this.selDiscQty = '';
          this.hasDiscQty = false; //disc qty & COL will be disabled
          this.hasCOL = false;
          this.hasValidity = false;
          this.hasPrice = true;
          this.hasMPOrderType = false;
          this.hasTriggerPrice = false;
          this.hasDay = false;
          this.selMPPrice = ''; // on productType change set SLPrice as 0 //CHETAN A
          this.hasOrderType = false;
          this.MPTableText = ('Stop Loss/Profit Order Detail');
          this.isBracketDetailsVisible = true;

          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_BSE_CASH)
            this.selValidity = (clsConstants.C_S_VALUE_EOTODY);
          else
            this.selValidity = clsConstants.C_S_VALUE_DAY;

          // Value for this global variable sets from OC license and on basis of CFT
          if ((this.scripObject.scripDet.MapMktSegId & parseInt(clsGlobal.User.TSLAllowed, 10)) == this.scripObject.scripDet.MapMktSegId) {
            this.trailingSLAllowed = true;
          }
          else {
            this.trailingSLAllowed = false;
          }
        }
      }
      else {
        if (this.selInstrument == clsConstants.C_S_INSTRUMENT_NCDEXCOMDTY_TEXT)
          this.hasOrderType = false;
        else
          this.hasOrderType = true;
        this.hasPrice = true;
      }
    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'fnOnProductTypeChange', e);
    }
  }

  fnSetDefaultMPFields() {
    //this.bFormat = true;
    this.selOrderType = (clsConstants.C_S_ORDER_REGULARLOT_TEXT);
    this.selMPOrderType = (clsConstants.C_S_ORDER_STOPLOSS_TEXT);

    let prodType = this.selProduct;
    if (this.modifyFlag) {
      prodType = this.objOEDetail.productType;
    }

    if (prodType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT)
      this.selMPPrice = (this.selPrice);

    this.selMPTriggerPrice = '';
    this.isMPTrigPriceOnFocus = true;

    if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

      /** <Norwin Dcruz> <04/12/2019> <USD : BT-3884> <Changing Order Type to RegularLot when Producttype is BracketOrder> 
      let itemSelected: any = { isChecked: true, value: clsConstants.C_S_ORDER_TYPE_REGULARLOT_TEXT }

      this.onOrderTypesChange(clsConstants.C_S_ORDER_TYPE_REGULARLOT_TEXT, itemSelected)

      /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Code end> **/


      this.legIndicator = clsConstants.C_V_BRACKET_MAIN_LEG_INDICATOR;
      this.selProfitOrderPrice = '';
      this.isProfitOrderPriceOnFocus = true;
      this.selSLJumpPrice = '';
      this.selLTPJumpPrice = '';

      if (this.selMPPrice == '') {
        this.hasProdPer = true;
      }

    }
    this.isMPPriceOnFocus = true;
    this.hasOrderType = false;

    this.hasDiscQty = false;
    this.selDiscQty = 0;
    //this.bFormat = false;
  }

  fnCheckForMarginPlus() {
    //In case of Margin Plus product type
    this.checkFlag = false;
    let prodType = this.selProduct;
    if (this.modifyFlag) {
      prodType = this.objOEDetail.productType;
    } else {
      let prodType = this.selProduct;
      if (this.isBracketDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
      } else if (this.isCoverDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
      }
    }

    if (prodType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT
      || prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

      this.isMPVisible = true;
      this.showMPDisclaimer = true;

      // let element = 0;
      // for (let index = 0; index < this.arrOrderTypesUI.length; index++) {
      //   this.arrOrderTypesUI[index].isChecked = false;
      //   if (this.arrOrderTypesUI[index].value.toUpperCase() == clsConstants.C_S_ORDER_TYPE_REGULARLOT_TEXT.toUpperCase())
      //     element = index;
      // }
      // this.arrOrderTypesUI[element].isChecked = true;

      if (prodType === clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {

        if (this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT) {
          this.MPDisclaimer = clsGlobal.dMsgMaster.getItem("OE103").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
        else {
          this.MPDisclaimer = clsGlobal.dMsgMaster.getItem("OE104").replace('Margin Plus', clsConstants.C_S_PRODUCTTYPE_MP_TEXT);
        }
      }

      if (this.isMarketOrder)
        this.selPrice = '';//0;

      if (this.selSeries != undefined || this.selExpire != undefined) {
        if (this.selInstrument.indexOf('OPT') >= 0)
          this.getMarginPlusParamForOptions();
        else
          this.fetchMarginPlusparams(null);
      }
    }
    else {
      this.isMPVisible = false;
      this.showMPDisclaimer = false;
    }
  }

  ///Function to fetch the margin plus parameters for option scrips
  getMarginPlusParamForOptions() {
    try {
      //Setting the optional params in case if it is not set
      let sSeries = this.selSeries != undefined ? this.selSeries : "-";
      let sExpDate = this.selExpire != undefined ? this.selExpire : "-";
      let sStrikePrice = (this.selStrikePrice != undefined && this.selStrikePrice != "NA") ? parseFloat(this.selStrikePrice) * this.scripObject.DecimalLocator : "-";
      let sOptionType = this.selOptionType != undefined ? this.selOptionType : "-";

      let mpParamReq: any = {};
      mpParamReq.mktSegmentId = this.scripObject.scripDet.MapMktSegId;
      mpParamReq.token = this.scripObject.scripDet.token;
      mpParamReq.instName = this.selInstrument;
      mpParamReq.series = sSeries;
      mpParamReq.expDate = sExpDate;
      mpParamReq.strikePrice = sStrikePrice;
      mpParamReq.optionType = sOptionType;
      mpParamReq.siTemplateId = clsGlobal.User.SITemplateId;

      //
      //this.httpService.getJson("http://172.25.100.174:8161/", clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getMarginPlusParamsForOptions/' + mpParamReq.mktSegmentId + '/' + mpParamReq.token + '/' + mpParamReq.instName + '/' + this.scripObject.symbol + '/' + mpParamReq.expDate + '/' + mpParamReq.strikePrice).subscribe(((data: any) => {
      this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getMarginPlusParamsForOptions/' + mpParamReq.mktSegmentId + '/' + mpParamReq.token + '/' + mpParamReq.instName + '/' + this.scripObject.symbol + '/' + mpParamReq.expDate + '/' + mpParamReq.strikePrice).subscribe(((data: any) => {
        this.fnSetMarginPlusParamForOptions(data);
      }),
        error => {
          this.toastCtrl.showAtBottom(error);
        });

    } catch (e) {

    }
  };

  ///Function to fetch the margin plus parameters
  fetchMarginPlusparams(_StkPriceMoneyMode: any) {
    try {
      //Setting the optional params in case if it is not set
      let sSeries = this.selSeries != undefined ? this.selSeries : "-";
      let sExpDate = this.selExpire != undefined ? this.selExpire : "-";
      let sStrikePrice = (this.selStrikePrice != undefined && this.selStrikePrice != "NA") ? parseFloat(this.selStrikePrice) * this.scripObject.DecimalLocator : "-";
      let sOptionType = this.selOptionType != undefined ? this.selOptionType : "-";
      let sMoneyMode = _StkPriceMoneyMode != undefined ? _StkPriceMoneyMode : "-";

      let mpParamReq: any = {};
      mpParamReq.mktSegmentId = this.scripObject.scripDet.MapMktSegId;
      mpParamReq.token = this.scripObject.scripDet.token;
      mpParamReq.instName = this.selInstrument;
      mpParamReq.series = sSeries;
      mpParamReq.expDate = sExpDate;
      mpParamReq.strikePrice = sStrikePrice;
      mpParamReq.optionType = sOptionType;
      mpParamReq.moneymode = sMoneyMode;
      mpParamReq.siTemplateId = clsGlobal.User.SITemplateId;

      let prodType = this.selProduct;
      if (this.isBracketDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
      } else if (this.isCoverDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
      }
      let productTypeCode = clsTradingMethods.getProductTypeValue(prodType);

      //clsGlobal.VirtualDirectory
      //this.httpService.getJson("http://172.25.100.174:8161/", clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getMarginPlusParams/' + mpParamReq.mktSegmentId + '/' + mpParamReq.token + '/' + mpParamReq.instName + '/' + this.scripObject.symbol + '/' + mpParamReq.series + '/' + mpParamReq.expDate + '/' + mpParamReq.strikePrice + '/' + mpParamReq.optionType + '/' + mpParamReq.moneymode + '/' + productTypeCode).subscribe(((data: any) => {
      this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getMarginPlusParams/' + mpParamReq.mktSegmentId + '/' + mpParamReq.token + '/' + mpParamReq.instName + '/' + this.scripObject.symbol + '/' + mpParamReq.series + '/' + mpParamReq.expDate + '/' + mpParamReq.strikePrice + '/' + mpParamReq.optionType + '/' + mpParamReq.moneymode + '/' + productTypeCode).subscribe(((data: any) => {
        this.fnSetMarginPlusparams(data);
      }),
        error => {
          this.showAddstoploss = false;
          this.toastCtrl.showAtBottom(error);
        });


    } catch (e) {
      this.showAddstoploss = false;
      this.toastCtrl.showAtBottom(e.message);
    }
  };

  ///Function to set the margin plus parameters and also validating the scrip for margin plus
  fnSetMarginPlusparams(_resp) {
    try {
      //Global.Validations.RemoveAllErrors();
      this.checkFlag = true;
      let objResponse = _resp;
      if (objResponse != null && objResponse.status) {
        if (objResponse.result.length > 0) {

          let objResponseParams = objResponse.result[0];
          this.MPCount = objResponseParams.nIsMatching;

          if (this.MPCount == 1) {

            if (objResponseParams.nDecimalLocator != '') {
              this.MPDecLoc = parseFloat(objResponseParams.nDecimalLocator);
              this.MPDecPrecision = clsTradingMethods.GetPriceFormatter(this.MPDecLoc.toString(), this.scripObject.scripDet.MktSegId, this.selInstrument);
            }

            if (this.MPDecLoc == undefined || this.MPDecLoc == 0)
              this.MPDecLoc = 100;

            if (objResponseParams.nMinDiffTriggerPricePercentage != '')
              this.MPLimitTrigPerc = parseFloat(objResponseParams.nMinDiffTriggerPricePercentage) / 10000;

            if (objResponseParams.nMinDiffLimitPricePercentage != '')
              this.MPTrigLimitPerc = parseFloat(objResponseParams.nMinDiffLimitPricePercentage) / 10000;

            if (objResponseParams.nDPRValidationOn != '')
              this.MPDPRFlag = parseFloat(objResponseParams.nDPRValidationOn);
            if (objResponseParams.nDPRPercentage != '')
              this.MPDPRRangePerc = parseFloat(objResponseParams.nDPRPercentage) / 10000;

            if (objResponseParams.PriceTick != '')
              this.MPPriceTick = parseFloat(((objResponseParams.PriceTick) / this.MPDecLoc).toFixed(this.MPDecPrecision));

            if (objResponseParams.nBasePrice != '')
              this.MPBasePrice = parseFloat(((objResponseParams.nBasePrice) / this.MPDecLoc).toFixed(this.MPDecPrecision))
            if (objResponseParams.ExpiryValue != '')
              this.MPExpiryValue = objResponseParams.ExpiryValue;
            if (objResponseParams.StrikePriceValue != '')
              this.MPStrikePriceValue = objResponseParams.StrikePriceValue;
            if (objResponseParams.nTradingAllowed != '')
              this.MPTradingAllowed = objResponseParams.nTradingAllowed != "" ? parseInt(objResponseParams.nTradingAllowed) : 0;
            if (objResponseParams.nMinDiffLimitTriggerPricePercentage != '')
              this.MPLimitTrigPercMin = parseFloat(objResponseParams.nMinDiffLimitTriggerPricePercentage) / 10000;
            if (objResponseParams.nProductType != '')
              this.MPProdTypeIndicator = objResponseParams.nProductType;
            if (objResponseParams.nProfitPricePercentage != '')
              this.profitPricePerc = parseFloat(objResponseParams.nProfitPricePercentage) / 10000;
          }

          if (this.MPCount != 0) {

            let prodType = this.selProduct;
            if (this.isBracketDataFilled) {
              prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
            } else if (this.isCoverDataFilled) {
              prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
            }
            //let productTypeCode = clsTradingMethods.getProductTypeValue(prodType);

            //MPProdTypeIndicator if 4 then MP allowed If 8192 then Bracket Order Allowed
            if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
              this.MPProdTypeIndicator != clsConstants.C_V_CRP_PRODTYPE_MASKMARGINPLUS.toString()) {

              this.MPSuccessFailure = false;
              this.alertCtrl.showAlert(clsTradingMethods.MPNotAllowedMsg(prodType));
              this.isCoverDataFilled = false;
              this.isBracketDataFilled = false;
            }
            else if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT &&
              this.MPProdTypeIndicator != clsConstants.C_V_CRP_PRODTYPE_MASKBRACKETORDER.toString()) {

              this.MPSuccessFailure = false;
              this.alertCtrl.showAlert(clsTradingMethods.MPNotAllowedMsg(prodType));
              this.isCoverDataFilled = false;
              this.isBracketDataFilled = false;
            }
            else {
              //this.isComputeMPRange = true;
              this.fnComputeMPRange(null);
            }
          }
          else {
            let prodType = this.selProduct;
            if (this.isBracketDataFilled) {
              prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
            } else if (this.isCoverDataFilled) {
              prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
            }
            this.alertCtrl.showAlert(clsTradingMethods.MPNotAllowedMsg(prodType));
            this.MPSuccessFailure = false;
            this.isCoverDataFilled = false;
            this.isBracketDataFilled = false;
            this.showAddstoploss = false;
          }
          this.fnShowMPError();
        }
        else {
          this.showAddstoploss = false;
          this.isCoverDataFilled = false;
          this.isBracketDataFilled = false;
        }
      } else {
        this.isCoverDataFilled = false;
        this.isBracketDataFilled = false;
      }
    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'fnSetMarginPlusparams', e);
    }
  }

  fnComputeMPRange(objMultiTouchResp: any) {

    //this.isRangeComputed =false;
    //clsGlobal.Validations.RemoveAllErrors();
    /* First on basis of Flag set for LCP / LTP / BasePrice assign relevant price to
    * dblSetPrice
    0 --> ClosePrice, 1 --> LTP,  2 --> BasePrice */
    if (this.MPDPRFlag === 0)
      this.MPSetPrice = this.MPClosePrice;
    else if (this.MPDPRFlag === 1)
      this.MPSetPrice = this.MPLTP;
    else if (this.MPDPRFlag === 2)
      this.MPSetPrice = this.MPBasePrice;

    //Proceed to calculate Virtual High and Low Price
    this.MPVirtualHighPr = this.MPSetPrice + (this.MPSetPrice * this.MPDPRRangePerc);
    this.MPVirtualLowPr = this.MPSetPrice - (this.MPSetPrice * this.MPDPRRangePerc);

    this.MPActualHighPr = parseFloat(this.fnRoundDown(this.MPActualHighPr, this.MPPriceTick).toFixed(this.MPDecPrecision));
    this.MPActualLowPr = parseFloat(this.fnRoundDown(this.MPActualLowPr, this.MPPriceTick).toFixed(this.MPDecPrecision));

    //Now Proceed to calculate Actual High and Low Price
    if (this.MPHighPr != 0)
      this.MPActualHighPr = Math.min(this.MPHighPr, this.MPVirtualHighPr);
    else
      this.MPActualHighPr = this.MPVirtualHighPr;

    if (this.MPLowPr != 0)
      this.MPActualLowPr = Math.max(this.MPLowPr, this.MPVirtualLowPr);
    else
      this.MPActualLowPr = this.MPVirtualLowPr;

    // Initial Level validation w.r.t. OrderSide
    // If any one of the following condition is true, reject the Order
    if (this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT) {
      this.fnPrimaryMarginPlusBuyValidation();
    }
    else {
      this.fnPrimaryMarginPlusSellValidation();
    }

    this.arrError = [];
    let prodType = this.selProduct;
    if (this.isBracketDataFilled) {
      prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
    } else if (this.isCoverDataFilled) {
      prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
    }
    // If above cases are not true, then proceed ahead with PriceBand related validations
    if (this.MPSuccessFailure) {

      if (this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT) {
        this.fnComputeBuySideMPPriceRange();
        /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <In Case of Bracket order Initial Price set for Trigger and Profit Order.It will not change in case of modify Braket Order> **/
        if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && !this.modifyFlag) {
          // this.selMPPrice = this.MPLimitPriceHighRange;
          // this.selMPTriggerPrice = this.MPTriggerPriceLowRange;
          // this.selProfitOrderPrice = this.profitPriceHighRange;
          // if (this.selMPPrice != '' && this.selMPPrice != 0 && this.selPrice != '' && this.selPrice != 0)
          //   this.hasProdPer = false;
          //this.isRangeComputed =true;
          if (this.checkFlag == true) {
            this.checkafterMarginPlus();
          }
        }
        /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Code End> **/

      }
      // SELL side case
      else {
        this.fnComputeSellSideMPPriceRange();
        /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <In Case of Bracket order Initial Price set for Trigger and Profit Order.It will not change in case of modify Braket Order> **/
        if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && !this.modifyFlag) {
          // this.selMPPrice = this.MPLimitPriceLowRange;
          // this.selMPTriggerPrice = this.MPTriggerPriceHighRange;
          // this.selProfitOrderPrice = this.profitPriceLowRange;
          // if (this.selMPPrice != '' && this.selMPPrice != 0 && this.selPrice != '' && this.selPrice != 0)
          //   this.hasProdPer = false;
          if (this.checkFlag == true) {
            this.checkafterMarginPlus();
          }
          //this.isRangeComputed =true;
        }
        /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Code End> **/
      }
    }
    else {
      this.arrError.push(clsTradingMethods.MPNotAllowedForLTPMsg(prodType, this.selPrice));
      this.MPSuccessFailure = false;
      this.isCoverDataFilled = false;
      this.isBracketDataFilled = false;
      this.showAddstoploss = false;
    }
    this.fnShowMPError();
  }

  checkafterMarginPlus() {

    let prodType = this.selProduct;
    if (this.isBracketDataFilled) {
      prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
    } else if (this.isCoverDataFilled) {
      prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
    }

    if (this.pageSource != clsConstants.C_V_ORDERBOOK_PAGENO &&
      prodType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
      if (this.selOperation == clsConstants.C_S_ORDER_BUY_TEXT) {

        if (this.selPrice != undefined && (this.selPrice == '' || this.selPrice == 0))
          this.selPrice = this.sellPrice.toFixed(this.pricePrecision);
        //to compute Buy side price range //Chetan A
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          this.fnComputeBuySideMPPriceRange();
      } else {
        if (this.selPrice != undefined && (this.selPrice == '' || this.selPrice == 0))
          this.selPrice = this.buyPrice.toFixed(this.pricePrecision);
        //to compute Buy side price range //Chetan A
        if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          this.fnComputeSellSideMPPriceRange();
      }
    }

    //For protection percentage Chetan A
    if (prodType != clsConstants.C_S_PRODUCTTYPE_MP_TEXT
      && prodType != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT
      && !this.isfirstTime) {
      this.setProtPerc();
    }

    else {
      this.isfirstTime = true;
    }
  }

  fnComputeBuySideMPPriceRange() {
    try {

      let prodType = this.selProduct;
      if (this.isBracketDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
      } else if (this.isCoverDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
      }

      let dblLTP1 = 0;
      if (isNaN(parseFloat(this.selPrice)) || parseFloat(this.selPrice) == 0)
        dblLTP1 = this.MPLTP;
      else
        dblLTP1 = parseFloat(this.selPrice);

      /* Calculate Trigger Low Side        */
      // Low Trigger Price Range should be calculated as
      // MAX(IF(OR(ISBLANK(LIMITPRICE1), LIMITPRICE1=0, LIMITPRICE1>(MAX(MIN(LTP1-(LTP1*TRIGGER_LIMIT_PERCENT%),LTP1-(LTP1*LTP_LIMIT_PERCENT%),Actual_High_Range),Actual_Low_Range)), LIMITPRICE1< Actual_Low_Range),Actual_Low_Range,LIMITPRICE1)+(LTP1*TRIGGER_LIMIT_PERCENT%),LTP1-(LTP1*LTP_TRIGGER_PERCENT%))
      let dblInitVal = Math.min((dblLTP1 - (dblLTP1 * this.MPTrigLimitPerc)), (dblLTP1 - (dblLTP1 * this.MPLimitTrigPercMin)));
      let dblVal1 = Math.min(dblInitVal, this.MPActualHighPr);
      let dblVal2 = Math.max(dblVal1, this.MPActualLowPr);

      let dblRes = 0;
      /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Added to make selprice 0> **/
      if (this.selMPPrice == '')
        this.selMPPrice = 0;
      if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) === 0 || parseFloat(this.selMPPrice) > dblVal2 || parseFloat(this.selMPPrice) < this.MPActualLowPr) {
        dblRes = this.MPActualLowPr;
      }
      else {
        dblRes = parseFloat(this.selMPPrice);
      }

      let dblTPR = 0;
      dblTPR = Math.max((parseFloat(dblRes.toString()) + (dblLTP1 * this.MPTrigLimitPerc)), (dblLTP1 - (dblLTP1 * this.MPLimitTrigPerc)));
      //dblTPR = parseFloat(Math.max(((dblRes) + (dblLTP1 * this.MPTrigLimitPerc)), (dblLTP1 - (dblLTP1 * this.MPLimitTrigPerc))).toFixed(this.MPDecPrecision));
      this.MPTriggerPriceLowRange = this.fnRoundUp(dblTPR, parseFloat(this.MPPriceTick));
      this.MPTriggerPriceLowRange = this.MPTriggerPriceLowRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      this.MPTriggerPriceHighRange = this.fnRoundDown(dblLTP1, parseFloat(this.MPPriceTick));
      //this.MPTriggerPriceHighRange = (this.MPTriggerPriceHighRange - parseFloat(this.MPPriceTick)).toFixed(this.MPDecPrecision).toString(); //Formatting again accd to decimal locator
      this.MPTriggerPriceHighRange = this.MPTriggerPriceHighRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator


      /* Calculate Limit Low Side
      * Actual_Low_Range     */
      this.MPLimitPriceLowRange = this.fnRoundUp(this.MPActualLowPr, parseFloat(this.MPPriceTick));
      this.MPLimitPriceLowRange = this.MPLimitPriceLowRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      /* Calculate Limit High Side*/
      //MAX(MIN(IF(OR(ISBLANK(TRIGGERPRICE1),TRIGGERPRICE1=0,TRIGGERPRICE1>LTP1,TRIGGERPRICE1<(MAX(Actual_Low_Range+(LTP1*TRIGGER_LIMIT_PERCENT%),LTP1-(LTP1*LTP_TRIGGER_PERCENT%)))),LTP1,TRIGGERPRICE1)-(LTP1*TRIGGER_LIMIT_PERCENT%),LTP1-(LTP1*LTP_LIMIT_PERCENT%),Actual_High_Range),Actual_Low_Range)
      let dblLPVal1 = Math.max(this.MPActualLowPr + (dblLTP1 * this.MPTrigLimitPerc), dblLTP1 - (dblLTP1 * this.MPLimitTrigPerc));
      let dblLPR: any = 0;
      if (isNaN(parseFloat(this.selMPTriggerPrice))
        || parseFloat(this.selMPTriggerPrice) === 0
        || parseFloat(this.selMPTriggerPrice) > dblLTP1
        || parseFloat(this.selMPTriggerPrice) < dblLPVal1) {
        dblLPR = dblLTP1;
        /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> < SLPrice range calculated based on trigger price. In case of buy low lowTriggerPrice is considered for range calculation.> **/
        if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
          dblLPR = this.MPTriggerPriceLowRange;
      }
      else {
        dblLPR = parseFloat(this.selMPTriggerPrice);
      }

      let dblLPRVal2 = 0;
      let dblInitLPRVal = Math.min(parseFloat(dblLPR) - (dblLTP1 * this.MPTrigLimitPerc), dblLTP1 - (dblLTP1 * this.MPLimitTrigPercMin));
      dblLPRVal2 = Math.min(dblInitLPRVal, this.MPActualHighPr);

      this.MPLimitPriceHighRange = this.fnRoundDown(Math.max(dblLPRVal2, this.MPActualLowPr), parseFloat(this.MPPriceTick));
      this.MPLimitPriceHighRange = this.MPLimitPriceHighRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      this.profitPriceLowRange = this.fnRoundUp(dblLTP1 + parseFloat(this.MPPriceTick), parseFloat(this.MPPriceTick)) //1 tick up form LTP
      this.profitPriceLowRange = this.profitPriceLowRange.toFixed(this.MPDecPrecision);
      //Min of Acutual High and LTP + % LTP
      this.profitPriceHighRange = Math.min(this.MPActualHighPr, dblLTP1 + (dblLTP1 * this.profitPricePerc));
      this.profitPriceHighRange = Math.max(this.profitPriceHighRange, parseFloat(this.profitPriceLowRange));
      this.profitPriceHighRange = this.fnRoundDown(this.profitPriceHighRange, parseFloat(this.MPPriceTick));
      this.profitPriceHighRange = this.profitPriceHighRange.toFixed(this.MPDecPrecision);


      let bValidate = true;
      if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
        if (parseFloat(this.profitPriceLowRange) > this.MPActualHighPr || (this.MPActualLowPr > (dblLTP1 - (dblLTP1 * this.MPLimitTrigPercMin))) ||
          (this.MPActualLowPr > (dblLTP1 - (dblLTP1 * this.MPTrigLimitPerc))) ||
          parseFloat(this.MPLimitPriceLowRange) > parseFloat(this.MPLimitPriceHighRange) || dblLTP1 > this.MPActualHighPr
        )
          bValidate = false;
      }
      else {
        if ((parseFloat(this.MPTriggerPriceLowRange) > parseFloat(this.MPTriggerPriceHighRange)) || (parseFloat(this.MPLimitPriceLowRange) > parseFloat(this.MPLimitPriceHighRange)))
          bValidate = false;
      }

      if (!bValidate) {
        //Global.Validations.AddError("OrderEntry", TradingGlobal.TradingMethods.MPNotAllowedForLTPMsg(this.SelProduct, this.SelPrice));
        this.arrError.push(clsTradingMethods.MPNotAllowedForLTPMsg(prodType, this.selPrice));
        this.MPSuccessFailure = false;
        this.MPLimitPriceLowRange = 0;
        this.MPLimitPriceHighRange = 0;
        this.MPTriggerPriceLowRange = 0;
        this.MPTriggerPriceHighRange = 0;
        this.profitPriceLowRange = 0;
        this.profitPriceHighRange = 0;
        this.selMPPrice = "";
        this.selMPTriggerPrice = "";
        this.selProfitOrderPrice = "";
        this.LPRVal = "";
        this.TPRVal = "";
        this.PPRVal = "";
        this.validateonce = true;
        this.isCoverDataFilled = false;
        this.isBracketDataFilled = false;
        this.showAddstoploss = false;
      }
      else {
        this.MPSuccessFailure = true
        this.LPRVal = (this.MPLimitPriceLowRange.toString() + " - " + this.MPLimitPriceHighRange.toString());
        this.TPRVal = (this.MPTriggerPriceLowRange.toString() + " - " + this.MPTriggerPriceHighRange.toString());
        this.PPRVal = (this.profitPriceLowRange.toString() + " - " + this.profitPriceHighRange.toString());
        /** <Norwin Dcruz> <24/12/2019> <USD : BT-3884> <Added to not calculate in case of modify when price is loaded and calculate if it changes> **/
        // if (this.tempmodifyFlag != undefined && this.tempmodifyFlag != true) {
        //   this.selMPPrice = this.MPLimitPriceHighRange;
        //   this.selMPTriggerPrice = this.MPTriggerPriceLowRange;
        //   this.selProfitOrderPrice = this.profitPriceHighRange;
        // }
        // this.tempmodifyFlag = false;
        if (!this.modifyFlag) {
          if (this.validatePriceForRange()) {
            this.showAddstoploss = false;
          }
        }
      }
    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'fnComputeBuySideMPPriceRange', e);
    }
  }

  /// <summary>
  /// Calculation to be done when User enters price / trigger price
  /// Below function will also be used when Margin plus is selected from Product type dropdown
  /// and Order side is SELL
  /// </summary>
  fnComputeSellSideMPPriceRange() {
    try {

      let prodType = this.selProduct;
      if (this.isBracketDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
      } else if (this.isCoverDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
      }

      let dblLTP1 = 0;
      if (isNaN(parseFloat(this.selPrice)) || parseFloat(this.selPrice) == 0)
        dblLTP1 = this.MPLTP;
      else
        dblLTP1 = parseFloat(this.selPrice);

      /* Calculate Trigger High Side        */
      // High Trigger Price Range should be calculated as
      // MIN(IF(OR(ISBLANK(LIMITPRICE2), LIMITPRICE2=0,LIMITPRICE2>Actual_High_Range, LIMITPRICE2< (MIN(MAX(LTP2+(LTP2*TRIGGER_LIMIT_PERCENT%),LTP2+(LTP2*LTP_LIMIT_PERCENT%),Actual_Low_Range),Actual_High_Range))),Actual_High_Range, LIMITPRICE2)-(LTP2*TRIGGER_LIMIT_PERCENT%),LTP2+(LTP2*LTP_TRIGGER_PERCENT%))
      let dblInitVal = Math.max((dblLTP1 + (dblLTP1 * this.MPTrigLimitPerc)), (dblLTP1 + (dblLTP1 * this.MPLimitTrigPercMin)));
      let dblVal1 = Math.max(dblInitVal, this.MPActualLowPr);
      let dblVal2 = Math.min(dblVal1, this.MPActualHighPr);


      let dblRes: any = 0;
      /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Added to make selprice 0> **/
      if (this.selMPPrice == '')
        this.selMPPrice = 0;
      if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) === 0 ||
        parseFloat(this.selMPPrice) > this.MPActualHighPr || parseFloat(this.selMPPrice) < dblVal2) {
        dblRes = this.MPActualHighPr;
      }
      else {
        dblRes = parseFloat(this.selMPPrice);
      }

      let dblTPR = 0;
      dblTPR = Math.min((parseFloat(dblRes) - (dblLTP1 * this.MPTrigLimitPerc)), (dblLTP1 + (dblLTP1 * this.MPLimitTrigPerc)));
      this.MPTriggerPriceHighRange = this.fnRoundDown(dblTPR, parseFloat(this.MPPriceTick));
      this.MPTriggerPriceHighRange = this.MPTriggerPriceHighRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      this.MPTriggerPriceLowRange = this.fnRoundUp(dblLTP1, parseFloat(this.MPPriceTick));
      this.MPTriggerPriceLowRange = (this.MPTriggerPriceLowRange).toFixed(this.MPDecPrecision);//Formatting again accd to decimal locator


      /* Calculate Limit High Side
      * Actual_High_Range     */
      this.MPLimitPriceHighRange = this.fnRoundDown(this.MPActualHighPr, parseFloat(this.MPPriceTick));
      this.MPLimitPriceHighRange = this.MPLimitPriceHighRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      /* Calculate Limit Low Side*/
      //MIN(MAX(IF(OR(ISBLANK(TRIGGERPRICE2),TRIGGERPRICE2=0,TRIGGERPRICE2>(MIN(Actual_High_Range-(LTP2*TRIGGER_LIMIT_PERCENT%),LTP2+(LTP2*LTP_TRIGGER_PERCENT%))),TRIGGERPRICE2<LTP2),LTP2,TRIGGERPRICE2)+(LTP2*TRIGGER_LIMIT_PERCENT%),LTP2+(LTP2*LTP_LIMIT_PERCENT%),Actual_Low_Range),Actual_High_Range)
      let dblLPVal1 = Math.min(this.MPActualHighPr - (dblLTP1 * this.MPTrigLimitPerc), dblLTP1 + (dblLTP1 * this.MPLimitTrigPerc));
      let dblLPR: any = 0;
      if (isNaN(parseFloat(this.selMPTriggerPrice)) || parseFloat(this.selMPTriggerPrice) === 0 ||
        parseFloat(this.selMPTriggerPrice) > dblLPVal1 || parseFloat(this.selMPTriggerPrice) < dblLTP1) {
        dblLPR = dblLTP1;
        // if (this.selProduct === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
        // dblLPR = this.MPTriggerPriceHighRange;
      }
      else {
        dblLPR = parseFloat(this.selMPTriggerPrice);
      }

      let dblLPRVal2 = 0;
      let dblInitLPRVal = Math.max(parseFloat(dblLPR) + (dblLTP1 * this.MPTrigLimitPerc), dblLTP1 + (dblLTP1 * this.MPLimitTrigPercMin));
      dblLPRVal2 = Math.max(dblInitLPRVal, this.MPActualLowPr);

      this.MPLimitPriceLowRange = this.fnRoundUp(Math.min(dblLPRVal2, this.MPActualHighPr), parseFloat(this.MPPriceTick));
      this.MPLimitPriceLowRange = this.MPLimitPriceLowRange.toFixed(this.MPDecPrecision); //Formatting again accd to decimal locator

      //max of Acutual low and LTP - % LTP
      this.profitPriceHighRange = this.fnRoundDown(dblLTP1 - parseFloat(this.MPPriceTick), parseFloat(this.MPPriceTick)).toFixed(this.MPDecPrecision); //1 tick down form LTP
      this.profitPriceLowRange = Math.max(this.MPActualLowPr, dblLTP1 - (dblLTP1 * this.profitPricePerc));
      this.profitPriceLowRange = Math.min(this.profitPriceLowRange, this.profitPriceHighRange);
      // =MIN(IF(MROUND(ACTUAL_PPR_LOW21,TICK_SIZE)<ACTUAL_PPR_LOW21,MROUND(ACTUAL_PPR_LOW21,TICK_SIZE)+TICK_SIZE,MROUND(ACTUAL_PPR_LOW21,TICK_SIZE)),ACTUAL_PPR_HIGH2)
      this.profitPriceLowRange = this.fnRoundUp(this.profitPriceLowRange, parseFloat(this.MPPriceTick)).toFixed(this.MPDecPrecision);


      let bValidate = true;
      if (prodType === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
        if (parseFloat(this.profitPriceHighRange) < this.MPActualLowPr ||
          (this.MPActualHighPr < (dblLTP1 + (dblLTP1 * this.MPLimitTrigPercMin))) ||
          (this.MPActualHighPr < (dblLTP1 + (dblLTP1 * this.MPTrigLimitPerc))) ||
          parseFloat(this.MPLimitPriceLowRange) > parseFloat(this.MPLimitPriceHighRange) || dblLTP1 < this.MPActualLowPr
        )
          bValidate = false;
      }
      else {
        if ((parseFloat(this.MPTriggerPriceLowRange) > parseFloat(this.MPTriggerPriceHighRange)) || (parseFloat(this.MPLimitPriceLowRange) > parseFloat(this.MPLimitPriceHighRange)))
          bValidate = false;
      }

      if (!bValidate) {
        //Global.Validations.AddError("OrderEntry", TradingGlobal.TradingMethods.MPNotAllowedForLTPMsg(this.SelProduct, this.SelPrice));
        this.arrError.push(clsTradingMethods.MPNotAllowedForLTPMsg(prodType, this.selPrice));
        this.MPSuccessFailure = false;
        this.MPLimitPriceLowRange = 0;
        this.MPLimitPriceHighRange = 0;
        this.MPTriggerPriceLowRange = 0;
        this.MPTriggerPriceHighRange = 0;
        this.LPRVal = "";
        this.TPRVal = "";
        this.PPRVal = "";
        this.selMPPrice = "";
        this.selMPTriggerPrice = "";
        this.selProfitOrderPrice = "";
        this.LPRVal = "";
        this.TPRVal = "";
        this.PPRVal = "";
        this.validateonce = true;
        this.showAddstoploss = false;
      }
      else {
        this.MPSuccessFailure = true;
        this.LPRVal = (this.MPLimitPriceLowRange.toString() + " - " + this.MPLimitPriceHighRange.toString());
        this.TPRVal = (this.MPTriggerPriceLowRange.toString() + " - " + this.MPTriggerPriceHighRange.toString());
        this.PPRVal = (this.profitPriceLowRange.toString() + " - " + this.profitPriceHighRange.toString());
        /** <Norwin Dcruz> <24/12/2019> <USD : BT-3884> <Added to not calculate in case of modify when price is loaded and calculate if it changes> **/
        // if (this.tempmodifyFlag != true) {
        //   this.selMPPrice = this.MPLimitPriceLowRange;
        //   this.selMPTriggerPrice = this.MPTriggerPriceHighRange;
        //   this.selProfitOrderPrice = this.profitPriceLowRange;
        // }
        // this.tempmodifyFlag = false;
        if (!this.modifyFlag) {
          if (this.validatePriceForRange()) {
            this.showAddstoploss = false;
          }
        }
      }

    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'fnComputeSellSideMPPriceRange', e);
    }
  }

  fnComputeMPOptionParams() {
    if (this.underlyingLTP > 0) {
      var stkPriceMoneyMode = this.calculateMoneyMode(this.underlyingLTP, this.selStrikePrice, this.selOptionType);
      this.fetchMarginPlusparams(stkPriceMoneyMode);
    }
    else {
      let prodType = this.selProduct;
      if (this.isBracketDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
      } else if (this.isCoverDataFilled) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
      }
      this.arrError.push(clsTradingMethods.MPNotAllowedForUnderlyingLTPMsg(prodType));
      this.MPSuccessFailure = false;
    }
    this.fnShowMPError();
  }

  ///this function calculates Money mode for option scrips
  calculateMoneyMode(dblSpotValue, strikePrice, OptionType) {
    var dblStrikePrice = parseFloat(strikePrice);
    var dblDifference = 0;

    if (this.MPArrStrikePrice.length >= 2) {
      dblDifference = parseFloat(this.MPArrStrikePrice[1]) - parseFloat(this.MPArrStrikePrice[0]);
    }

    if (dblDifference > 0) {
      var lnMoney = dblStrikePrice - dblSpotValue;
      var lnAbsMoney = (lnMoney < 0) ? (-1 * lnMoney) : lnMoney;

      if (lnAbsMoney != 0) {
        var bProcess = true;
        if (lnMoney < (-dblDifference * 11 / 2) + 0.0001)   // ITM  //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus   //(-dblDifference * 11 / 2) + 0.0001) 3/2 WAVE BT-17428 AERO
        {
          bProcess = false;
        }
        else if (lnMoney > (dblDifference * 11 / 2))      // ATM+2    //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus    //(dblDifference * 11 / 2) 3/2 WAVE  BT- 17428 AERO
        {
          bProcess = false;
        }
        if (bProcess) {
          if (lnMoney > 0) {
            //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus<Start>
            if (lnMoney > dblDifference * 9 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 13 /*AtTheMoney - 5*/;
              else
                return 12 /*AtTheMoney + 5*/;
            }
            else if (lnMoney > dblDifference * 7 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 11 /*AtTheMoney - 4*/;
              else
                return 10 /*AtTheMoney + 4*/;
            }
            else if (lnMoney > dblDifference * 5 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 9 /*AtTheMoney - 3*/;
              else
                return 8 /*AtTheMoney + 3*/;
            }
            else if (lnMoney > dblDifference * 3 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 7 /*AtTheMoney - 2*/;
              else
                return 6 /*AtTheMoney + 2*/;
            }
            else {
              //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus<End>
              if (OptionType == "PA" || OptionType == "PE")
                return 3 /*AtTheMoney - 1*/;
              else
                return 2 /*AtTheMoney + 1*/;
            }    //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus
          }
          else {
            //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus<Start>
            if (lnAbsMoney > dblDifference * 9 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 12 /*AtTheMoney + 5*/;
              else
                return 13 /*AtTheMoney - 5*/;
            }
            else if (lnAbsMoney > dblDifference * 7 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 10 /*AtTheMoney + 4*/;
              else
                return 11 /*AtTheMoney - 4*/;
            }
            else if (lnAbsMoney > dblDifference * 5 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 8 /*AtTheMoney + 3*/;
              else
                return 9 /*AtTheMone - 3*/;
            }
            else if (lnAbsMoney > dblDifference * 3 / 2) {
              if (OptionType == "PA" || OptionType == "PE")
                return 6 /*AtTheMoney + 2*/;
              else
                return 7 /*AtTheMoney - 2*/;
            }
            else {
              //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus<End>
              if (OptionType == "PA" || OptionType == "PE")
                return 2 /*AtTheMoney + 1*/;
              else
                return 3 /*AtTheMoney - 1*/;
            }    //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus
          }
        }
        //BT-17427:BT-17428:15052020:Hrishikesh:Changes in Product master for bracket order and margin plus<End>
      }
    }

    if (dblStrikePrice == dblSpotValue)
      return 1 /*AtTheMoney*/;
    else if (dblStrikePrice > dblSpotValue) {
      if (OptionType == "PA" || OptionType == "PE")
        return 4 /*InTheMoney*/;
      else
        return 5 /*OutofTheMoney*/;
    }
    else if (dblStrikePrice < dblSpotValue) {
      if (OptionType == "PA" || OptionType == "PE")
        return 5 /*OutofTheMoney*/;
      else
        return 4 /*InTheMoney*/;
    }
  }

  fnShowMPError() {
    if (this.MPSuccessFailure === false) {
      this.BOSuccessFailure = false;
      this.EnbDisSubmit = false;
      if (this.arrError.length > 0) {
        this.alertCtrl.showAlert(this.arrError[0]);
        this.arrError = [];
      }
    }
    else {
      this.BOSuccessFailure = true;
      this.EnbDisSubmit = true;
    }
  }

  fnPrimaryMarginPlusBuyValidation() {
    if ((this.MPLTP > this.MPActualHighPr) || (this.MPActualLowPr > (this.MPLTP - (this.MPLTP * this.MPTrigLimitPerc))))
      this.MPSuccessFailure = false;
    else
      this.MPSuccessFailure = true;
  }

  fnPrimaryMarginPlusSellValidation() {
    if ((this.MPLTP < this.MPActualLowPr) || (this.MPActualHighPr < (this.MPLTP + (this.MPLTP * this.MPTrigLimitPerc))))
      this.MPSuccessFailure = false;
    else
      this.MPSuccessFailure = true;
  }

  fnRoundUp(_dblPrice, _dblPriceTick) {
    let dblval = 0;
    let dblFactor = this.fnGetDivFactor(_dblPrice.toFixed(this.MPDecPrecision)) % this.fnGetDivFactor(_dblPriceTick);
    if (dblFactor == 0) {
      dblval = _dblPrice;
    }
    else {
      dblval = _dblPrice + (_dblPriceTick - (_dblPrice % _dblPriceTick));
    }
    return dblval;
  }

  fnRoundDown(_dblPrice, _dblPriceTick) {


    let dblval = 0;
    let dblFactor = this.fnGetDivFactor(_dblPrice.toFixed(this.MPDecPrecision)) % this.fnGetDivFactor(_dblPriceTick);
    if (dblFactor == 0) {
      dblval = _dblPrice;
    }
    else {
      dblval = _dblPrice - (_dblPrice % _dblPriceTick);
    }
    return dblval;
  }

  fnGetDivFactor(_dblVal) {
    return Math.round(parseFloat(_dblVal) * this.MPDecLoc);
  }

  validatePriceForRange() {
    try {

      if (parseFloat(this.selMPTriggerPrice) < parseFloat(this.MPTriggerPriceLowRange) || parseFloat(this.selMPTriggerPrice) > parseFloat(this.MPTriggerPriceHighRange)) {
        this.toastCtrl.showWithButton("Entered trigger price not in range: " + this.TPRVal);
        this.showAddstoploss = true;
        return false;
      }

      if ((parseFloat(this.selMPPrice) < parseFloat(this.MPLimitPriceLowRange) || parseFloat(this.selMPPrice) > parseFloat(this.MPLimitPriceHighRange)) && parseFloat(this.selMPPrice) != 0) {
        this.toastCtrl.showWithButton("Entered price not in range: " + this.LPRVal);
        this.showAddstoploss = true;
        return false;
      }

      return true;
      //this.showAddstoploss = false;

      // if ((this.selMPPrice < this.MPLimitPriceLowRange || this.selMPPrice > this.MPLimitPriceHighRange) && this.selMPPrice != 0) {
      //   this.toastCtrl.showWithButton("Entered price not in range: " + this.LPRVal);
      //   return;
      // }


    } catch (error) {

    }
  }

  ///Function to set the margin plus parameters and also validating the scrip for margin plus
  fnSetMarginPlusParamForOptions(_resp: any) {
    try {

      let objResponse = _resp;
      if (objResponse != null && objResponse.status && objResponse.result.length > 0) {

        let arrResponseParams = objResponse.result[0][0];

        this.underlyingMktSegId = clsTradingMethods.GetMarketSegmentID(clsTradingMethods.getSpotMarketSegmentId(this.scripObject.scripDet.MktSegId));
        if (this.scripObject.scripDet.MapMktSegId == clsConstants.C_V_MAPPED_MCX_DERIVATIVES) {
          this.underlyingToken = arrResponseParams.nWarningPercent;
        }
        else {
          this.underlyingToken = arrResponseParams.nAssetToken;
        }

        this.MPArrStrikePrice = [];
        let arrScripStrikePrice = objResponse.result[1];

        for (let i = 0; i < arrScripStrikePrice.length; i++) {
          if (!this.MPArrStrikePrice.includes(arrScripStrikePrice[i].StrikePrice))
            this.MPArrStrikePrice.push(arrScripStrikePrice[i].StrikePrice);
        }

        let scripKey: clsScripKey = new clsScripKey();
        scripKey.MktSegId = this.underlyingMktSegId;
        scripKey.token = this.underlyingToken;

        let objScripUnderlying: clsScrip = new clsScrip();
        objScripUnderlying.scripDet = scripKey;

        this.isComputeMPOptionParams = true;
        /** <Norwin Dcruz> <10/12/2019> <USD : BT-3884> <To unsubscribe and subscride again due to MFComputeFalg> **/
        // if(this.tempobjMultiTouchResp != undefined)
        // {
        this.sendB5Request(OperationType.REMOVE, objScripUnderlying);
        this.sendB5Request(OperationType.ADD, objScripUnderlying);
        // }


        //if underlying response not received then call it to show validation message
        setTimeout(function () {
          if (this.isComputeMPOptionParams) {
            this.isComputeMPOptionParams = false;
            this.fnComputeMPOptionParams();
          }
        }.bind(this), 300);

      }
    } catch (e) {
      //this.toastCtrl.showAtBottom('fnSetMarginPlusParamForOptions: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'fnSetMarginPlusParamForOptions', e);
    }
  }

  setOrderTypeSelected() {
    if (this.arrOrderTypesUI != undefined) {
      let idxItem: number;
      for (let index = 0; index < this.arrOrderTypesUI.length; index++) {
        const element = this.arrOrderTypesUI[index];
        this.arrOrderTypesUI[index].isChecked = false;
        if (element.value == this.selOrderTypeNew) {
          idxItem = index;
        }
        // if (element.value == this.selOrderType) {
        //   idxItem = index;
        // }
      }
      if (idxItem != undefined)
        this.arrOrderTypesUI[idxItem].isChecked = true;
    }
  }

  setProductTypeSelected() {
    if (this.arrProductTypesUI != undefined) {
      let idxItem: number;
      for (let index = 0; index < this.arrProductTypesUI.length; index++) {
        const element = this.arrProductTypesUI[index];
        this.arrProductTypesUI[index].isChecked = false;
        if (element.value == this.selProduct) {
          idxItem = index;
          //this.arrProductTypesUI[index].isChecked = true;
        }
      }
      if (idxItem != undefined)
        this.arrProductTypesUI[idxItem].isChecked = true;
    }
  }


  sendSubscritionRequest() {
    try {
      this.sendB5Request(OperationType.ADD, this.scripObject);
    } catch (e) {
      //this.toastCtrl.showAtBottom('sendB5Request' + e.message);
    }
  }

  sendB5Request(intOperationType: OperationType, objScrip: clsScrip) {
    try {
      let objTLReq = new clsBestFiveRequest();
      objTLReq.OperationType = intOperationType;
      objTLReq.ByPassRequestStore = false;
      objTLReq.Scrip = objScrip;
      clsGlobal.pubsub.publish("B5REQ", objTLReq);
    } catch (e) {
      //this.toastCtrl.showAtBottom('sendB5Request' + e.message);
    }
  }
  //calculate Histogram for overlay.
  calculateHistogram(sum: any, qty: number) {
    try {
      let histovalue = (Math.round(((qty * 100) / sum) * 100) / 100).toFixed(2);
      //console.log(histovalue);
      return histovalue;
    } catch (error) {
      console.log("Error in histor calculation ." + error);
      return 0;
    }
  }
  /**
   * Receive b5 broadcast and bind to html
   * @param objMultiTLResp
   */
  receiveBestFiveResponse(objB5Resp: clsBestFiveResponse) {
    try {

      if (objB5Resp != null) {
        //console.log(objMultiTLResp);
        if (this.scripObject.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
          this.scripObject.scripDet.token == objB5Resp.Scrip.token) {

          this.LTP = objB5Resp.LTP;
          let arrNetChange = clsTradingMethods.getChangeInRs(objB5Resp.LTP, objB5Resp.ClosePrc, objB5Resp.PriceFormat, false, 'uptrend');

          this.NetChangeInRs = arrNetChange[0];
          this.PercNetChange = arrNetChange[1];
          this.LTPTrend = arrNetChange[2];

          let bidSum = 0;
          let askSum = 0;

          for (let i = 0, len = objB5Resp.BestFiveData.length; i < len; i++) {
            if (objB5Resp.BestFiveData[i].sBidQty != undefined && objB5Resp.BestFiveData[i].sBidQty != '-' && objB5Resp.BestFiveData[i].sBidQty != 0)
              bidSum = bidSum + parseInt(objB5Resp.BestFiveData[i].sBidQty);

            if (objB5Resp.BestFiveData[i].sAskQty != undefined && objB5Resp.BestFiveData[i].sAskQty != '-' && objB5Resp.BestFiveData[i].sAskQty != 0)
              askSum = askSum + parseInt(objB5Resp.BestFiveData[i].sAskQty);
          }
          for (let i = 0, len = objB5Resp.BestFiveData.length; i < len; i++) {
            objB5Resp.BestFiveData[i].sBidPer = this.calculateHistogram(bidSum, objB5Resp.BestFiveData[i].sBidQty);
            objB5Resp.BestFiveData[i].sAskPer = this.calculateHistogram(askSum, objB5Resp.BestFiveData[i].sAskQty);
          }
          //this.PercNetChangeRaw = arrNetChange[3];
          // this.totalBuyQty = objB5Resp.TotBuyQty;
          // this.totalSellQty = objB5Resp.TotSellQty;
          this.totalBuyQty = (objB5Resp.TotBuyQty == '' ? '-' : objB5Resp.TotBuyQty);
          this.totalSellQty = (objB5Resp.TotSellQty == '' ? '-' : objB5Resp.TotSellQty);

          if (this.totalSellQty != '-' && this.totalBuyQty != '-') {
            let _totalQty = parseInt(this.totalSellQty) + parseInt(this.totalBuyQty);
            this.totalBidQtyPer = ((parseInt(this.totalBuyQty) / _totalQty) * 100).toFixed(2);
            this.totalAskQtyPer = ((parseInt(this.totalSellQty) / _totalQty) * 100).toFixed(2);
            //we will calculate qty percent 
          }
          this.B5Data = objB5Resp.BestFiveData;

          this.MPLTP = objB5Resp.LTP == "" ? 0 : parseFloat(objB5Resp.LTP);

          this.MPClosePrice = objB5Resp.ClosePrc == "" ? 0 : parseFloat(objB5Resp.ClosePrc);
          if (objB5Resp.BestFiveData.length > 0) {
            this.buyPrice = (objB5Resp.BestFiveData[0].sBid == "" || objB5Resp.BestFiveData[0].sBid == "-") ? 0 : parseFloat(objB5Resp.BestFiveData[0].sBid);
            this.sellPrice = (objB5Resp.BestFiveData[0].sAsk == "" || objB5Resp.BestFiveData[0].sAsk == "-") ? 0 : parseFloat(objB5Resp.BestFiveData[0].sAsk);
          }

          let pricePrecision = objB5Resp.PriceFormat;

          this.LTPVal = (this.MPLTP.toFixed(pricePrecision));

          if (objB5Resp.DPR != "") {
            this.MPHighPr = objB5Resp.DPR.split('-')[1];
            this.MPLowPr = objB5Resp.DPR.split('-')[0];
            if (this.MPHighPr == "-" || this.MPHighPr == "") {
              this.MPHighPr = 0;
            }

            if (this.MPLowPr == "-" || this.MPLowPr == "") {
              this.MPLowPr = 0;
            }
          }

          this.MPHighPr = parseFloat(this.MPHighPr);
          this.MPLowPr = parseFloat(this.MPLowPr);

          if (this.isPopulatePrice && (this.pageSource != clsConstants.C_V_ORDERBOOK_PAGENO)) {
            this.isPopulatePrice = false;
            let valSelPrice;
            if (this.selOperation == clsConstants.C_S_ORDER_BUY_TEXT)
              valSelPrice = this.sellPrice;
            else
              valSelPrice = this.buyPrice;

            valSelPrice = isNaN(parseFloat(valSelPrice)) ? 0 : parseFloat(valSelPrice);
            //this.selPrice = valSelPrice.toFixed(pricePrecision);
            /** <Norwin Dcruz> <16/12/2019> <USD : BT-3884> <Added to call this methiod> **/
            if(this.selProduct != 'MULTILEGORDER')
            this.priceOnLostFocus();
          }

          this.isRangeComputed = true;

          if (this.isComputeMPRange) {
            this.isComputeMPRange = false;
            //this.isRangeComputed = false;
            this.fnComputeMPRange(objB5Resp);
          }
        }

        if (this.underlyingMktSegId.toString() == objB5Resp.Scrip.MktSegId.toString() &&
          this.underlyingToken == objB5Resp.Scrip.token) {
          if (this.isComputeMPOptionParams) {
            this.isComputeMPOptionParams = false;
            this.underlyingLTP = objB5Resp.LTP == "" ? 0 : parseFloat(objB5Resp.LTP);
            this.fnComputeMPOptionParams();
          }
        }

        if (this.isFirstMarginCall) {
          this.isFirstMarginCall = false;
          //if (this.selQty > 0) {
          //this.getMarginUtilization();
          this.onScrollChanged.next(1);
          //}
        }

      }
    } catch (error) {
      //this.toastCtrl.showAtBottom("" + error.message);
      clsGlobal.logManager.writeErrorLog('OrderEntryPopup', 'receiveBestFiveResponse', error);
    }
  }

  closePopUp() {
    //console.log(this.scripObject);
    let eventobj = {
      closePopUp: true
    }
    this.messageEvent.emit(eventobj);
  }

  showMarketLimit(flag: string) {
    if (flag == 'M') {
      this.showMarket = true;
    }
    else {
      this.showMarket = false;
    }
  }

  showQtyAmount(flag: string) {
    if (flag == 'Q') {
      this.showQty = true;
    }
    else {
      this.showQty = false;
    }

  }

  stopLossSction() {
    this.showStopLoss = !this.showStopLoss;
  }

  async orderConfirmDialoge(type) {
    try {

      if (type == 'Validate') {
        //this.qtyOnLostFocus()
        if ((isNaN(parseInt(this.selQty)) || parseInt(this.selQty) == 0)) {

          if (this.modifyFlag && this.objOEDetail.productType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

          } else {
            if (this.selAmount < this.LTP) {
              this.toastCtrl.showWithButton("Quantity was not provided/calculated");
              return;
            } else {
              this.toastCtrl.showWithButton("Quantity must be provided");
              return;
            }
          }

        }

        // COmmented by omprakash as blank is valid price for market order.
        // if ((isNaN(parseFloat(this.selPrice)) || this.selPrice == '')
        //   && (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT ||
        //     this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)) {
        //   this.toastCtrl.showWithButton("Price must be provided");
        //   return;
        // } 

        //||
        //this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT
        if ((isNaN(parseFloat(this.selPrice)) || parseFloat(this.selPrice) == 0)
          && (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT)) {
          this.toastCtrl.showWithButton("Price must be provided");
          return;
        }

        if ((parseFloat(this.selPrice) != 0)
          && (this.MPLowPr != '0' && this.MPHighPr != '0') && (this.MPLowPr > parseFloat(this.selPrice)
            || this.MPHighPr < parseFloat(this.selPrice))) {
          this.toastCtrl.showWithButton("Enter price within the DPR range");
          return;
        }

        if ((isNaN(parseFloat(this.selTriggerPrice)) || parseFloat(this.selTriggerPrice) == 0)
          && (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT ||
            this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)) {
          this.toastCtrl.showWithButton("Trigger Price must be provided");
          return;
        }

        if (this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
          if (this.selBuySell == clsConstants.C_S_ORDER_BUY_TEXT) {
            if (parseFloat(this.selPrice) != 0 && parseFloat(this.selTriggerPrice) > parseFloat(this.selPrice)) {
              this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL71"));
              return;
            }
          }
          /*  For SELL side order Trigger Price should be greater than Order Price for Product Type
          other than Margin Plus. For Margin Plus case is vice versa  
          Note: Case is viceversa only for fresh order
          For MarginPlus modification order use original normal formula TrigPr > OrderPrice */
          else//Sell side case
          {
            if (parseFloat(this.selTriggerPrice) < parseFloat(this.selPrice)) {
              this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL73"));
              return;
            }
          }
        }

        if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT ||
          this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {

          if (isNaN(parseFloat(this.selMPTriggerPrice)) || parseFloat(this.selMPTriggerPrice) == 0) {
            this.toastCtrl.showWithButton("Trigger Price must be provided");
            return;
          }

          if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) == 0) {
            this.toastCtrl.showWithButton("Price must be provided");
            return;
          }
        }
        //Issue solved for Normal equity order .by omprakash on 01 March 21
        if (this.selMarketLot != undefined && this.selMarketLot != "0") {
          if (this.scripObject.scripDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES) {
            if (parseInt(this.selQty) % parseInt(this.selMarketLot) != 0) {
              this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL46") + this.selMarketLot);
              return;
            }
          }
        }

        if (this.selPrice != 0) {

          let DecimalLocator = this.selDecimalloc;

          if (this.selDecimalloc == 0)
            DecimalLocator = clsConstants.C_V_NORMAL_DECIMALLOCATOR;
          let _AllowedDecimal: any = DecimalLocator.toString().length - 1;

          let decChkPrice = parseFloat(this.selPrice);

          if (!(clsCommonMethods.DecDigits(decChkPrice.toString(), _AllowedDecimal))) {
            this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL61"));
            return;
          }


          let PriceinPaise = parseInt(Math.round(parseFloat((decChkPrice * DecimalLocator).toString())).toString());

          if (PriceinPaise % parseInt(this.selPriceTick) != 0) {
            let PriceFormatter = clsTradingMethods.GetPriceFormatter(DecimalLocator.toString(), this.scripObject.scripDet.MktSegId, this.selInstrument);
            let PriceTickInRs = (parseFloat(this.selPriceTick) / DecimalLocator).toFixed(PriceFormatter);
            this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTickInRs); //+ clsGlobal.dMsgMaster.getItem("NNSL63"));
            return
          }
        }

        // if (parseInt(this.selDiscQty) % parseInt(this.selMarketLot) != 0) {
        //   this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL58") + this.selMarketLot);
        // }

        if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT) {
          if (this.deliveryPriceTab != 'marketPrice' && !this.isBracketDataFilled && this.isCoverDataFilled) {
            this.toastCtrl.showAtBottom("Cover order main leg should be market.");
            return;
          }


          if (this.isBracketDataFilled && this.selValidity != clsConstants.C_S_VALUE_DAY && this.selValidity != clsConstants.C_S_VALUE_EOTODY) {
            this.toastCtrl.showAtBottom("Day validity allowed for bracket order.");
            return;
          }
        }

        if (this.pageSource == clsConstants.C_V_NETPOSITION_PAGENO ||
          this.pageSource == clsConstants.C_V_STOCKVIEW_PAGENO) {
          if (parseInt(this.selQty) > this.originalQty) {
            this.toastCtrl.showAtBottom("Entered quantity is greater than the original quantity.");
            return;
          }
        }

        await this.FetchEDISDetails().then((EDISReqRefNo: any) => {
          if (EDISReqRefNo.data != undefined) {
            if (EDISReqRefNo.data != 'close') {
              this.eDISReqRefNo = EDISReqRefNo.data;
              //this.showConfirmBuySell = !this.showConfirmBuySell;
              this.plcOrder = false;
              //this.errorMessage = undefined;
            } else {
              this.showConfirmBuySell = true;
              this.plcOrder = false;
            }
          } else {
            this.showConfirmBuySell = false;
            this.plcOrder = false;
            return;
          }
        }).catch(error => {
          this.showConfirmBuySell = true;
          this.plcOrder = false;
          return;
        });


      }

      this.showConfirmBuySell = !this.showConfirmBuySell;
      this.plcOrder = false;
      this.errorMessage = undefined;
    } catch (error) {
    }

  }

  placeOrder() {

    try {
      if (clsGlobal.User.isGuestUser) {
        let buttons: any = ["Login", "Skip"];
        this.alertCtrl.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }
      let SegmentId = this.scripObject.scripDet.MktSegId;//item.scripDetail.scripDet.MktSegId;
      if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
        this.alertCtrl.showAlert(
          "You are currently not allowed to place/modify/cancel order in this segment",
          "Order Error!"
        );
        return;
      }

      // if ((isNaN(parseInt(this.selAmount)) || parseInt(this.selAmount) == 0)) {
      //   this.toastCtrl.showWithButton("Amount must be provided");
      //   return;
      // }
      this.plcOrder = true;
      let reqBody: any = {};
      if (!this.modifyFlag) {

        reqBody = this.getOrderEntryRequest();
      } else {
        reqBody = this.getOrderModifyRequest();
      }

    } catch (error) {
      console.log(error);
      this.plcOrder = false;
      this.toastCtrl.showWithButton(error);
    }
    //this.navCtrl.navigateForward('orderconfirmation');
  }

  getOrderEntryRequest() {
    try {

      let prodType = this.selProduct;

      if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT) {
        if (this.isCoverDataFilled || this.isBracketDataFilled) {
          if (this.isBracketDataFilled) {
            prodType = clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT;
          } else {
            prodType = clsConstants.C_S_PRODUCTTYPE_MP_TEXT;
          }
        }
      }

      if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT) {
        prodType = clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT;
      }

      if (this.showMTF) {
        prodType = clsConstants.C_S_PRODUCTTYPE_MTF_TEXT;
      }

      let reqBody: any = {};
      if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
        reqBody =
        {
          "scrip_info": {
            "exchange": clsTradingMethods.getApiExchangeName(this.scripObject.scripDet.MktSegId),//this.scripObject.ExchangeName + "_" + this.scripObject.Series,
            "scrip_token": this.scripObject.scripDet.token,
            "symbol": this.scripObject.symbol,
            "series": this.scripObject.Series,
            "expiry_date": this.scripObject.ExpiryDate == "NA" ? "" : this.scripObject.ExpiryDate,
            "strike_price": this.scripObject.StrikePrice == "NA" ? "" : this.scripObject.StrikePrice,
            "option_type": this.scripObject.OptionType == "NA" ? "" : this.scripObject.OptionType,
          },
          "transaction_type": this.selBuySell,
          "main_leg": {
            "order_type": clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT,
            "quantity": this.selQty,
            "price": 0
          },
          "stoploss_leg": {
            "legs": [
              {
                "quantity": this.selQty,
                "price": parseFloat(this.selMPPrice || 0 ),
                "trigger_price": parseFloat(this.selMPTriggerPrice)
              }
            ]
          },
          "order_identifier":    this.objOEDetail.recoId || clsTradingMethods.getOrderIdentifier()
        }
        this.plcOrder = true;
        this.tranService.placeCoverOrder(reqBody)
          .then((response: any) => {
            //console.log(response);
            //this.plcOrder = false;

            reqBody.marketLot = this.selMarketLot;
            this.paramService.myParam = { "reqBody": reqBody, "response": response };
            this.showOrderResult = true;
            this.showConfirmBuySell = false;
            this.orderResultDetails();
            //clsGlobal.User.fundsDetails=[];
          }).catch(error => {
            //console.log(error);
            //this.orderConfirmDialoge('Close');
            this.plcOrder = true;
            this.errorMessage = "Unable to place order";//error.error.message;
            //this.toastCtrl.showWithButton(error.error.message);
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });

      }
      else if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
        reqBody =
        {
          "scrip_info": {
            "exchange": clsTradingMethods.getApiExchangeName(this.scripObject.scripDet.MktSegId),//this.scripObject.ExchangeName + "_" + this.scripObject.Series,
            "scrip_token": this.scripObject.scripDet.token,
            "symbol": this.scripObject.symbol,
            "series": this.scripObject.Series,
            "expiry_date": this.scripObject.ExpiryDate == "NA" ? "" : this.scripObject.ExpiryDate,
            "strike_price": this.scripObject.StrikePrice == "NA" ? "" : this.scripObject.StrikePrice,
            "option_type": this.scripObject.OptionType == "NA" ? "" : this.scripObject.OptionType,
          },
          "transaction_type": this.selBuySell,
          "main_leg": {
            "order_type": this.selOrderType,
            "quantity": this.selQty,
            "price": this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT ? this.selPrice : 0,
            "trigger_price": 0
          },
          "stoploss_leg": {
            "legs":
              [
                {
                  "quantity": this.selQty,
                  "price": parseFloat(this.selMPPrice || 0),
                  "trigger_price": parseFloat(this.selMPTriggerPrice)
                }
              ],
            "trail": {
              "ltp_jump_price": this.selLTPJumpPrice == '' ? 0 : parseFloat(this.selLTPJumpPrice),
              "stoploss_jump_price": this.selSLJumpPrice == '' ? 0 : parseFloat(this.selSLJumpPrice)
            }

          },
          "profit_leg": {
            "legs": [
              {
                "quantity": this.selQty,
                "price": parseFloat(this.selProfitOrderPrice)
              }
            ]
          },
          "order_identifier": this.objOEDetail.recoId || clsTradingMethods.getOrderIdentifier()
        }
        this.plcOrder = true;
        this.tranService.placeBracketOrder(reqBody)
          .then((response: any) => {
            reqBody.marketLot = this.selMarketLot;
            this.paramService.myParam = { "reqBody": reqBody, "response": response };
            this.showOrderResult = true;
            this.showConfirmBuySell = false;
            this.orderResultDetails();
            //clsGlobal.User.fundsDetails=[];
          }).catch(error => {
            //console.log(error);
            //this.orderConfirmDialoge('Close');
            this.plcOrder = true;
            this.errorMessage = "Unable to place order";//error.error.message;
            //this.toastCtrl.showWithButton(error.error.message);
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });

      }
      else {

        if (this.deliveryPriceTab == 'triggerPrice' && (this.selPrice == '' || parseFloat(this.selPrice) == 0)) {
          this.selOrderType = clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT;
        }

        reqBody =
        {
          "scrip_info": {
            "exchange": clsTradingMethods.getApiExchangeName(this.scripObject.scripDet.MktSegId),//this.scripObject.ExchangeName + "_" + this.scripObject.Series,
            "scrip_token": this.scripObject.scripDet.token,
            "symbol": this.scripObject.symbol,
            "series": this.scripObject.Series,
            "expiry_date": this.scripObject.ExpiryDate == "NA" ? "" : this.scripObject.ExpiryDate,
            "strike_price": this.scripObject.StrikePrice == "NA" ? "" : this.scripObject.StrikePrice,
            "option_type": this.scripObject.OptionType == "NA" ? "" : this.scripObject.OptionType,
          },
          "transaction_type": this.selBuySell,
          "product_type": prodType,
          "order_type": this.selOrderType,
          "quantity": this.selQty,
          "price": (this.selPrice) ? parseFloat(this.selPrice) : 0,
          "trigger_price": parseFloat(this.selTriggerPrice),
          "disclosed_quantity": 0,
          "validity": this.selValidity,
          "validity_days": this.GTDNoOfDays,
          "is_amo": this.isAMO,
          "order_identifier": this.objOEDetail.recoId || clsTradingMethods.getOrderIdentifier()
        }
        this.tranService.placeOrder(reqBody)
          .then((response: any) => {
            //console.log(response);
            //this.plcOrder = false;
            //this.closePopUp();
            reqBody.marketLot = this.selMarketLot;
            this.orderID = response.data.orderId;
            //this.toastCtrl.showAtBottom('Order Placed' + this.orderID);
            if (this.eDISReqRefNo != '' && this.eDISReqRefNo != undefined) {
              //this.toastCtrl.showWithButton('eDISReqRefNo' + JSON.stringify(this.eDISReqRefNo));
              this.insertEDISCDSLResponse();
            }
            this.paramService.myParam = { "reqBody": reqBody, "response": response };
            this.showOrderResult = true;
            this.showConfirmBuySell = false;
            this.orderResultDetails();
            //this.navCtrl.navigateForward(['/orderconfirmation']);
            //clsGlobal.User.fundsDetails=[];
          }).catch(error => {
            this.plcOrder = true;
            //console.log(error);
            //this.orderConfirmDialoge('Close');
            this.errorMessage = "Unable to place order";//error.error.message;
            //this.toastCtrl.showWithButton(error.error.message);
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });
      }
      return reqBody;
    } catch (error) {

    }
  }

  getOrderModifyRequest() {
    try {
      let reqBody = {};
      let prodType = this.selProduct;
      if (this.modifyFlag) {
        prodType = this.objOEDetail.productType;
      }
      if (prodType == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
        reqBody =
        {
          "main_leg": {
            "order_type": clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT,
            "quantity": this.selQty,
            "traded_quantity": this.objOEDetail.tradedQty,
            "price": 0
          },
          "stoploss_leg": {
            "legs": [
              {
                "quantity": this.selQty,
                "price": parseFloat(this.selMPPrice),
                "trigger_price": parseFloat(this.selMPTriggerPrice)
              }
            ]
          },
          "order_time": this.objOEDetail.orderTime
        }
        this.plcOrder = true;
        this.tranService.modifyCoverOrder(reqBody, this.objOEDetail.apiExchange, this.objOEDetail.gwOrderNo)
          .then((response: any) => {
            //console.log(response);
            //this.plcOrder = false;
            // this.closePopUp();
            //clsGlobal.User.fundsDetails=[];
            // this.paramService.myParam = { "reqBody": reqBody, "response": response };
            // this.navCtrl.navigateForward(['/orderconfirmation']);
            this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_TRANSACTION);

          }).catch(error => {
            //console.log(error);
            //this.orderConfirmDialoge('Close');
            this.plcOrder = true;
            this.errorMessage = "Unable to place order";//error.error.message;
            //this.toastCtrl.showWithButton(error.error.message);
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });
      }
      else if (prodType == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
        reqBody =
        {
          "main_leg": {
            "order_type": this.selOrderType,
            "quantity": this.selQty,
            "price": this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT ? this.selPrice : 0,
            "trigger_price": 0,
            "traded_quantity": this.objOEDetail.tradedQty,
          },
          "stoploss_leg": {
            "legs":
              [
                {
                  "quantity": 0,// this.selQty,
                  "price": parseFloat(this.selMPPrice),
                  "trigger_price": parseFloat(this.selMPTriggerPrice)
                }
              ],
            "trail": {
              "ltp_jump_price": this.selLTPJumpPrice == '' ? 0 : parseFloat(this.selLTPJumpPrice),
              "stoploss_jump_price": this.selSLJumpPrice == '' ? 0 : parseFloat(this.selSLJumpPrice)
            }

          },
          "profit_leg": {
            "legs": [
              {
                "quantity": 0,//this.selQty,
                "price": this.selProfitOrderPrice
              }
            ]
          },
          "fields_modified": {
            "main_leg_price": parseFloat(this.selPrice) != this.objOEDetail.orderPrice,
            "main_leg_qty": this.selQty != this.objOEDetail.orderQty,
            "stoploss_leg_price": parseFloat(this.selMPPrice) != this.objOEDetail.SLOrderPrice,
            "stoploss_trail_price": !this.hasTrailingSL ? false : parseFloat(this.selSLJumpPrice) != this.objOEDetail.SLJumpPrice,
            "profit_leg_price": parseFloat(this.selProfitOrderPrice) != this.objOEDetail.profitOrderPrice
          },
          "order_time": this.objOEDetail.orderTime
        }
        this.plcOrder = true;
        this.tranService.modifyBracketOrder(reqBody, this.objOEDetail.apiExchange, this.objOEDetail.gwOrderNo)
          .then((response: any) => {
            //console.log(response);
            //this.plcOrder = false;
            // this.closePopUp();
           // clsGlobal.User.fundsDetails=[];
            // this.paramService.myParam = { "reqBody": reqBody, "response": response };
            // this.navCtrl.navigateForward(['/orderconfirmation']);
            this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_TRANSACTION);

          }).catch(error => {
            //console.log(error);
            //this.orderConfirmDialoge('Close');
            this.plcOrder = true;
            this.errorMessage = "Unable to place order";//error.error.message;
            //this.toastCtrl.showWithButton(error.error.message);
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });

      }
      else {

        if (this.deliveryPriceTab == 'triggerPrice' && (this.selPrice == '' || parseFloat(this.selPrice) == 0)) {
          this.selOrderType = clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT;
        }

        reqBody = {
          "order_type": this.selOrderType,
          "quantity": this.selQty,
          "price": this.selPrice == '' ? 0 : parseFloat(this.selPrice),
          "trigger_price": parseFloat(this.selTriggerPrice),
          "disclosed_quantity": (this.selDiscQty == '' || this.selDiscQty == undefined) ? 0 : this.selDiscQty,
          "validity": this.selValidity,
          "validity_days": this.GTDNoOfDays,
          "traded_quantity": this.objOEDetail.tradedQty,
          "order_time": this.objOEDetail.orderTime
        }
        this.tranService.modifyOrder(reqBody, this.objOEDetail.apiExchange, this.objOEDetail.gwOrderNo)
          .then((response: any) => {
            //console.log(response);
            //this.closePopUp();
            //this.paramService.myParam = { "reqBody": reqBody, "response": response };
            //this.navCtrl.navigateForward(['/orderconfirmation']);
            if (this.eDISReqRefNo != '' && this.eDISReqRefNo != undefined) {
              this.insertEDISCDSLResponse();
            }
           // clsGlobal.User.fundsDetails=[];
            this.navCtrl.navigateForward(clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
          }).catch(error => {
            //console.log(error);
            this.orderConfirmDialoge('Close');
            //this.toastCtrl.showWithButton(error.error.message);
            this.errorMessage = "Unable to place order";//error.error.message;
            this.toastCtrl.showWithButton("Unable to place order, kindly contact administrator.");
          });
      }
      return reqBody;
    } catch (error) {
        console.log("Error i order modification "+error);
    }
  }

  orderResultDetails(){
    if (this.paramService.myParam) {
      this.dataOE = this.paramService.myParam;
      this.isSLOrder = (this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT || this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_TEXT);
      let symbol = '';
      let Lot :any = '';

      if (this.dataOE.reqBody.scrip_info.expiry_date != undefined &&
        this.dataOE.reqBody.scrip_info.expiry_date != '') {
        let expiry = this.dataOE.reqBody.scrip_info.expiry_date.substr(0, 2) + ' ' + this.dataOE.reqBody.scrip_info.expiry_date.substr(2, 3);

        if (this.dataOE.reqBody.scrip_info.strike_price != '') {
          symbol = this.dataOE.reqBody.scrip_info.symbol + ' ' + expiry + ' OPT ' + this.dataOE.reqBody.scrip_info.strike_price + ' ' + this.dataOE.reqBody.scrip_info.option_type;
        } else {
          symbol = this.dataOE.reqBody.scrip_info.symbol + ' ' + expiry + ' FUT';
        }
      } else {
        symbol = this.dataOE.reqBody.scrip_info.symbol;
      }

      if (!this.dataOE.reqBody.main_leg) {

        if (this.dataOE.reqBody.scrip_info.exchange == clsConstants.C_S_NSE_DERV_API) {

          Lot = this.dataOE.reqBody.quantity / this.dataOE.reqBody.marketLot;
          Lot += " Lot (" + this.dataOE.reqBody.quantity +") ";

        } else {
          
          Lot = this.dataOE.reqBody.quantity;
          if (this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_NSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_BSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_MCXSX_EQ_API ) {
              Lot += " Lot";
          }
        }

        this.confirmTxt = " You have placed an " + (this.isSLOrder ? "SL" : "") + " order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + ((this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT || this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) ? 'Market Price' : this.dataOE.reqBody.price);
        if (this.isSLOrder && this.dataOE.reqBody.order_type == clsConstants.C_S_ORDER_STOPLOSS_TEXT) {
          this.confirmTxt += " With SL Trigger @" + this.dataOE.reqBody.trigger_price;
        }
      }
      else {

        if (this.dataOE.reqBody.scrip_info.exchange == clsConstants.C_S_NSE_DERV_API) {
          Lot = this.dataOE.reqBody.main_leg.quantity / this.dataOE.reqBody.marketLot;
          Lot += " Lot";
        } else {
          Lot = this.dataOE.reqBody.main_leg.quantity;
          if (this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_NSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_BSE_EQ_API &&
            this.dataOE.reqBody.scrip_info.exchange != clsConstants.C_S_MCXSX_EQ_API ) {
              Lot += " Lot";
          }
        }

        let order_price = !this.dataOE.reqBody.trail ? 'Market Price' : (this.dataOE.reqBody.main_leg.price == 0 ? 'Market Price' : this.dataOE.reqBody.main_leg.price);
        if (!this.dataOE.reqBody.profit_leg) {
          this.confirmTxt = " You have placed an Intraday(CO) order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + order_price;
          this.confirmTxt += " with SL Trigger @" + this.dataOE.reqBody.stoploss_leg.legs[0].trigger_price + " , SL @" + this.dataOE.reqBody.stoploss_leg.legs[0].price;
        } else {
          this.confirmTxt = " You have placed an Intraday(BO) order to " + this.dataOE.reqBody.transaction_type + " " + Lot + " shares of " + symbol + " @ " + order_price;
          this.confirmTxt += " with SL Trigger @" + this.dataOE.reqBody.stoploss_leg.legs[0].trigger_price + " , SL @" + this.dataOE.reqBody.stoploss_leg.legs[0].price;
          this.confirmTxt += " , Trailing SL @" + this.dataOE.reqBody.stoploss_leg.trail.stoploss_jump_price + " and Book Profit @" + this.dataOE.reqBody.profit_leg.legs[0].price;
        }

      }
      this.orderResultID = this.dataOE.response.data.orderId;
      this._setVar=  setTimeout(() => {
        this.closeConfirmation(); 
      }, 5000); 
      clsGlobal.User.totalBuyingPower = undefined;
      clsGlobal.User.fundsDetails = [];
    }
  }

  segmentChanged(evt) {
    //console.log("event " + evt.detail);
    this.mode = evt.detail.value.toString().toUpperCase();
    this.selBuySell = evt.detail.value.toString().toUpperCase();
    this.getMarginUtilization();
  }

  prodTypeSegmentChanges(evt) {
    if(this.selProduct != evt.detail.value.toString().toUpperCase())
    this.priceOnFocus();
    this.prodTypeTab = evt.detail.value.toString().toUpperCase();
    this.selProduct = this.prodTypeTab;
    this.onProductTypeChange(null, null);
    if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT)
      this.deliveryPriceTab = 'marketPrice';

    //this.checkMarginShortFall();

    if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT ||
      this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
      this.isMarginDisplay = false;
    }
    else {
      if (this.showMarginDisplay)
        this.isMarginDisplay = true;
    }

    // if (!this.isFirstMarginCall && this.selQty > 0 &&
    //   this.selProduct != clsConstants.C_S_PRODUCTTYPE_MP_TEXT &&
    //   this.selProduct != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
    //   //if (this.selQty > 0)
    //   this.getMarginUtilization();
    // }
  }

  deliveryPriceTypeSegmentChanges(evt) {
    this.deliveryPriceTab = evt.detail.value.toString();
    if (this.deliveryPriceTab == 'marketPrice') {
      this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
      this.selPrice = '';//0
      this.selTriggerPrice = '';//0
      this.resetValidity();
    }
    else if (this.deliveryPriceTab == 'limitPrice') {
      this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
      this.showDPRError = false;
      //if (!this.modifyFlag) {
      this.selPrice = '';//0
      //}
    }
    else if (this.deliveryPriceTab == 'triggerPrice') {
      //if (!this.modifyFlag) {
      this.selTriggerPrice = '';//0
      this.selPrice = '';//0
      this.showDPRError = false;
      //}
      this.selOrderType = clsConstants.C_S_ORDER_STOPLOSS_TEXT;
      this.resetValidity();
      this.resetComplexOrderDetails();
    }
    if(clsGlobal.User.spreadScrips.length == 0)
    {
    this.getMarginUtilization();
    }
  }

  legPriceChange(evt, item) {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legToken == item.legToken &&
        this.MultilegsDetails[count].legmktsegid == item.legmktsegid) {
        this.MultilegsDetails[count].legpricetoggle = evt.detail.value.toString();
        if (this.MultilegsDetails[count].legpricetoggle == 'marketlegPrice') {
          this.MultilegsDetails[count].legprice = this.MultilegsDetails[count].selmarketlegPrice;
        }
        else if (this.MultilegsDetails[count].legpricetoggle == 'limitlegPrice') {
          //if (!this.modifyFlag) {
          this.MultilegsDetails[count].legprice = this.MultilegsDetails[count].sellimitlegPrice;//0
          //}
        }
      }
    }
  }

  clickAddstoploss() {
    this.showAddstoploss = !this.showAddstoploss;
    if (!this.isCoverDataFilled && !this.isBracketDataFilled) {
      this.selMPPrice = '';
      this.selMPTriggerPrice = '';
      this.selSLJumpPrice = '';
      this.selLTPJumpPrice = '';
      this.selProfitOrderPrice = '';
      this.isCoverDataFilled = false;
      this.isBracketDataFilled = false;
    }
    if (this.showAddstoploss && this.modifyFlag)
      this.fnCheckForMarginPlus();
  }

  clickMarketDepth() {
    this.showMarketDepth = !this.showMarketDepth;
  }

  showExchangePopUp() { 
    this.priceOnFocus();
    if (this.modifyFlag) {
      return;
    }
    if (this.scripObject.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
      this.scripObject.scripDet.MktSegId != clsConstants.C_V_BSE_CASH &&
      this.scripObject.scripDet.MktSegId != clsConstants.C_V_MSX_CASH) {
      return;
    }
    this.showExchange = !this.showExchange;
  }



  priceSelected(price: any) {

    this.clickMarketDepth();// to close depth popup.
    /** <Norwin Dcruz> <18/12/2019> <USD : BT-3884> <Added to retun price when bracket main leg is executed> **/
    if (this.hasPrice == false)
      return;
    if (price != "-" && price != "0" && price != "") {
      //solved for issue in case of market type price is set through market depth.
      //by omprakash on 16 March 2021 .
      if (this.deliveryPriceTab != "marketPrice")
        this.selPrice = price;
      else
        this.selPrice = 0;
    }
    /** <Norwin Dcruz> <16/12/2019> <USD : BT-3884> <Added to call this methiod> **/
    //this.priceOnLostFocus();
    this.priceOnFocus();
  }

  priceOnLostFocus() {
    this.onPriceChange();

    this.BOSuccessFailure = true;
    if (this.selProduct === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
      this.validateProfitOrderPrice();

    this.setProtPerc();

    if (this.selPrice != '' && this.selPrice != '-') {
      this.selPrice = parseFloat(this.selPrice).toFixed(this.pricePrecision);
    }
    let amt = parseFloat(this.selAmount);
    if (amt > 0) {
      //this.selQty = 0;
      this.amountOnLostFocus()
    }

    if (this.selPrice != '' && this.selPrice != '0' && this.selPrice != '-' && this.MPLowPr != '0' && this.MPHighPr != '0') {
      if (!(parseFloat(this.MPLowPr) <= parseFloat(this.selPrice) && parseFloat(this.selPrice) <= parseFloat(this.MPHighPr))) {
        this.showDPRError = true;
      } else {
        this.showDPRError = false;
      }
    }

    if (this.selPrice == '-') {
      this.selPrice = '';
    }

    //this.checkMarginShortFall();
    if(clsGlobal.User.spreadScrips.length == 0)
    {
    this.getMarginUtilization();
    }
  }



  qtyOnLostFocus() {

    //this.checkMarginShortFall();
    if (this.selLot != undefined && this.selLot != '') {
      //console.log('qtyOnLostFocus: ',this.selLot);
      if (this.objOEDetail.scripDetl.scripDet.MktSegId == clsConstants.C_V_NSE_DERIVATIVES) {
        this.selQty = this.selLot * this.selMarketLot;
      }
      else {
        this.selQty = this.selLot;
      }

      //this.getMarginUtilization();
      this.onScrollChanged.next(this.selQty);

    } else {
      this.selQty = 0;
    }
  }

  triggerPriceOnLostFocus() {

    this.onPriceChange();

    if (this.selTriggerPrice != '' && this.selTriggerPrice != '-') {
      this.selTriggerPrice = parseFloat(this.selTriggerPrice).toFixed(this.pricePrecision);
    }
    if (this.selTriggerPrice == '-') {
      this.selTriggerPrice = '';
    }
  }

  triggerMPPriceOnLostFocus() {
    if (this.selMPTriggerPrice != '' && this.selMPTriggerPrice != '-') {
      this.selMPTriggerPrice = parseFloat(this.selMPTriggerPrice).toFixed(this.pricePrecision);
    }
    if (this.selMPTriggerPrice == '-') {
      this.selMPTriggerPrice = '';
    }
  }

  MPPriceOnLostFocus() {
    if (this.selMPPrice != '' && this.selMPPrice != '-') {
      this.selMPPrice = parseFloat(this.selMPPrice).toFixed(this.pricePrecision);
    }
    if (this.selMPPrice == '-') {
      this.selMPPrice = '';
    }
  }

  SLJumpPriceOnLostFocus() {
    if (this.selSLJumpPrice != '' && this.selSLJumpPrice != '-') {
      this.selSLJumpPrice = parseFloat(this.selSLJumpPrice).toFixed(this.pricePrecision);
    }
    if (this.selSLJumpPrice == '-') {
      this.selSLJumpPrice = '';
    }
  }

  LTPJumpPriceOnLostFocus() {
    if (this.selLTPJumpPrice != '' && this.selLTPJumpPrice != '-') {
      this.selLTPJumpPrice = parseFloat(this.selLTPJumpPrice).toFixed(this.pricePrecision);
    }
    if (this.selLTPJumpPrice == '-') {
      this.selLTPJumpPrice = '';
    }
  }

  ProfitPriceOnLostFocus() {
    if (this.selProfitOrderPrice != '' && this.selProfitOrderPrice != '-') {
      this.selProfitOrderPrice = parseFloat(this.selProfitOrderPrice).toFixed(this.pricePrecision);
    }
    if (this.selProfitOrderPrice == '-') {
      this.selProfitOrderPrice = '';
    }
  }


  amountOnLostFocus() {
    try {

      let price = parseFloat(this.LTP);
      if ((isNaN(parseInt(this.selPrice)) || parseInt(this.selPrice) == 0)
      ) {
        price = parseFloat(this.LTP);

      } else {
        price = parseFloat(this.selPrice);
      }
      let amt = parseFloat(this.selAmount);
      if (amt > 0 && price != 0) {

        let qty: any = Math.floor(amt / price);

        if (this.scripObject.scripDet.MktSegId != clsConstants.C_V_NSE_CASH &&
          this.scripObject.scripDet.MktSegId != clsConstants.C_V_BSE_CASH
        ) {
          qty = Math.floor(amt / (price * this.selMarketLot));
        }

        if (!(isNaN(parseInt(qty)))) {
          this.selQty = Math.abs(qty);
        }
        else
          this.selQty = 0;

        this.selLot = this.selQty;

      }

      //this.checkMarginShortFall();
      //this.getMarginUtilization();
      this.onScrollChanged.next(this.selLot);

    } catch (error) {

    }

  }

  checkMarginShortFall() {
    try {

      if(parseFloat(this.shortFall) > 0)
      {
        this.fundFlag = true;
      }
      else
      {
        this.fundFlag = false;
      }

      // if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT) {
      //   let orderValue =  this.fundsRequired //this.getOrderValuePref();
      //   if (orderValue != 0 && orderValue > parseFloat(this.fundsAvailable)) {//clsGlobal.User.totalBuyingPower
      //     if (this.isMTFAllowed) {
      //       this.showMTF = true;
      //     } else {
      //       this.showMTF = false;
      //     }
      //   } else {
      //     this.showMTF = false;
      //   }
      // } else {
      //   this.showMTF = false;
      // }

    } catch (error) {

    }
  }

  validateProfitOrderPrice() {
    try {
      if (this.BOSuccessFailure) { //on price change do only if details populated successfully.

        if (this.MPActualLowPr == 0 && this.MPActualHighPr == 0) { }
        else {
          this.arrError = [];
          if (this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT) {
            this.fnComputeBuySideMPPriceRange();
            /** <Norwin Dcruz> <10/12/2019> <USD : BT-3884> <In Case of Bracket order Initial Price set for Trigger and Profit Order.It will not change in case of modify Braket Order> **/
            // if (this.selProduct === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && !this.modifyFlag) {
            //   if (this.selPrice != 0)
            //     this.selMPPrice = this.MPLimitPriceHighRange;
            //   this.selMPTriggerPrice = this.MPTriggerPriceLowRange;
            //   this.selProfitOrderPrice = this.profitPriceHighRange;

            // }
            /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Code End> **/
          }
          else {
            this.fnComputeSellSideMPPriceRange();
            /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <In Case of Bracket order Initial Price set for Trigger and Profit Order.It will not change in case of modify Braket Order> **/
            // if (this.selProduct === clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && !this.modifyFlag) {
            //   if (this.selPrice != 0)
            //     this.selMPPrice = this.MPLimitPriceLowRange;
            //   this.selMPTriggerPrice = this.MPTriggerPriceHighRange;
            //   this.selProfitOrderPrice = this.profitPriceLowRange;
            // }
            /** <Norwin Dcruz> <03/12/2019> <USD : BT-3884> <Code End> **/
          }


          if (this.MPSuccessFailure === false) {
            this.EnbDisSubmit = false;
            this.alertCtrl.showAlert(this.arrError[0]);
          }
          else {
            this.EnbDisSubmit = true;
          }
        }
      }
    }
    catch (e) {

    }
  }

  onPriceChange() {
    this.orderTypeChangeForPrice();
    this.onOrderTypesChange(undefined, undefined);

  }

  orderTypeChangeForPrice() {
    if (this.selPrice == '') {
      this.selPrice = '';//0;
      //this.selPrice = this.selPrice.toFixed(this.selDecimalloc);
    }
    let _price = this.selPrice;

    if (_price != '' && parseFloat(_price) != 0) {
      //bo
      if (this.selProduct != clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
        this.hasProdPer = false;

      if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT ||
        this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
        this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
      else
        this.selOrderType = clsConstants.C_S_ORDER_STOPLOSS_TEXT;

    } else {
      // if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_TEXT ||
      //   this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT)
      //   this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
      // else
      //   this.selOrderType = clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT;

    }
  }

  onOrderTypesChange(event, itemSelected) {
    try {
      /*
      //window.event.stopPropagation()
      // Getting all the details like validity, product types etc based on instrument...
      if (itemSelected != undefined && itemSelected != null) {
 
        let newOrderType = ''
        if (itemSelected.value == clsConstants.C_S_ORDER_TYPE_REGULARLOT_TEXT) {
          newOrderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;
 
        }
        else if (itemSelected.value == clsConstants.C_S_ORDER_TYPE_STOPLOSS_TEXT) {
          newOrderType = clsConstants.C_S_ORDER_STOPLOSS_TEXT;
        }
        else if (itemSelected.value == clsConstants.C_S_ORDER_TYPE_CALLAUCTION_TEXT) {
          newOrderType = clsConstants.C_S_ORDER_CALLAUCTION_TEXT;
        }
        //this.selOrderType = itemSelected.value;
        this.selOrderTypeNew = event;
        this.selOrderType = newOrderType;
        this.setOrderTypeSelected();
 
      }
 
      if (this.selOrderType != undefined) {
        this.getDetailsForOrderType(this.selExchange, this.selOrderType, this.selInstrument);
 
        if (this.selOrderType != clsConstants.C_S_ORDER_STOPLOSS_TEXT &&
          this.selOrderType != clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
          this.selTriggerPrice = '';
          this.hasTriggerPrice = false;
 
 
          if (clsGlobal.ExchManager.isPrimaryValidation(this.selExchange, this.selInstrument, this.scripObject.scripDet.MktSegId, this.selValidity)) {
            if (clsGlobal.ExchManager.isSecondaryValidation(this.scripObject.scripDet.MktSegId, "1")) {
              if (parseInt(this.selQty) != 0 && !this.modifyFlag) {
                if (this.selQty == "")
                  this.selDiscQty = '';
                //  else
                //    this.selDiscQty = this.selQty;
              }
            }
            this.hasDiscQty = true;
          }
          else {
            this.selDiscQty = '';
 
          }
        }
        //SL case --> Enable Trigger Price
        else {
 
          this.hasTriggerPrice = true;
          if (clsGlobal.ExchManager.isSecondaryValidation(this.scripObject.scripDet.MktSegId, "2")) {
            this.selDiscQty = '';
            this.hasDiscQty = false;
          }
 
        }
 
        if (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT ||
          this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) {
          this.isMarketOrder = true;
          if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT ||
            this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
            //this.tempselPrice = this.selPrice;
            this.selPrice = 0;
            this.hasProdPer = true;
          }
          //this.orderTypeToggle = 'Market';
        } else {
          // if(this.tempselPrice != undefined)
          // this.selPrice = this.tempselPrice;
          this.isMarketOrder = false;
          //this.orderTypeToggle = 'Limit';
        }
 
        //Set DiscQty to Qty. (This change is needed if you change validity dropdown first then the ordertype
        let _bDiscQtyFillValue = clsGlobal.ExchManager.getDiscQtyFillValue(this.scripObject.scripDet.MktSegId, this.selValidity, this.selOrderType, null);
        if (_bDiscQtyFillValue)
          this.selDiscQty = (this.selQty);
        //disable DiscQty if validity is IOC. (This change is needed if you change validity dropdown first then the ordertype
        if (this.selValidity == clsConstants.C_S_VALUE_IOC)
          this.hasDiscQty = false;
      }
 
      if (this.pageSource == clsConstants.C_V_MARKETWATCH_PAGENO) {
 
        this.fnDisableFieldsForMW();
      }
      this.setProtPerc();
      */
    }
    catch (e) {
      //this.toastCtrl.showAtBottom('onOrderTypesChange: ' + e.message);
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'onOrderTypesChange', e);
    }
  }

  setProtPerc() {
    try {
      let arrMktProtPerc = clsGlobal.ExchManager.getDetailsForMktProtPerc(this.selExchange, this.scripObject.scripDet.MapMktSegId, this.selPrice, this.scripObject.scripDet.MktSegId, this.selMPPrice, this.selProduct);
      //arrMktProtPerc will hold 2 items one is dcEnableDisableFields & 2nd is value of applicable ProtPerc
      this.dcEnableDisableFields = arrMktProtPerc[0];
      this.hasProdPer = this.dcEnableDisableFields.getItem("hasProdPer");

      /**
      (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT
        || this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT)
         */
      if (this.hasProdPer
        && (this.selProdPer == '' || this.selProdPer == undefined)) {
        if (this.dcEnableDisableFields.getItem("hasProdPer")) {

          let protPerc = arrMktProtPerc[1];
          let ProtPercOrderPref = (arrMktProtPerc[2] == null) ? undefined : arrMktProtPerc[2];
          this.selProdPer = (ProtPercOrderPref);
          if (protPerc != '') {
            this.ProtPercDisclaimer = (clsGlobal.dMsgMaster.getItem("NNSL351") + protPerc + " %");
            this.showProtPercDisclaimer = true;
          }
          else {
            this.showProtPercDisclaimer = false;
          }
        }
      }
      /** <Norwin Dcruz> <16/12/2019> <USD : BT-3884> <Added to enabled protection percent> **/
      if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT && (this.selPrice == '' || this.selPrice == 0) /*|| this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT */) {
        this.hasProdPer = true;
      }

      /** <Norwin Dcruz> <11/12/2019> <USD : BT-3884> <Added Protection percent check> **/
      if (!this.hasProdPer) {
        if (this.selProdPer == '' || this.selProdPer == undefined || this.selProdPer == null)
          this.selProdPer = undefined;
        this.ProtPercDisclaimer = ('');
        this.showProtPercDisclaimer = (false);
      }

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'setProtPerc', error);
    }
  }

  getEmptyBestFiveData() {
    let b1: any = {};
    b1.sBuyers = "-";
    b1.sBidQty = "-";
    b1.sBid = "-";
    b1.sSellers = "-";
    b1.sAskQty = "-";
    b1.sAsk = "-";
    b1.RowIndex = 0;
    b1.SelectedB5Class = "ht03";

    let b2: any = {};
    b2.sBuyers = "-";
    b2.sBidQty = "-";
    b2.sBid = "-";
    b2.sSellers = "-";
    b2.sAskQty = "-";
    b2.sAsk = "-";
    b2.RowIndex = 1;
    b2.SelectedB5Class = "ht03"; //ko.observable('ht03');

    let b3: any = {};
    b3.sBuyers = "-";
    b3.sBidQty = "-";
    b3.sBid = "-";
    b3.sSellers = "-";
    b3.sAskQty = "-";
    b3.sAsk = "-";
    b3.RowIndex = 2;
    b3.SelectedB5Class = "ht03";

    let b4: any = {};
    b4.sBuyers = "-";
    b4.sBidQty = "-";
    b4.sBid = "-";
    b4.sSellers = "-";
    b4.sAskQty = "-";
    b4.sAsk = "-";
    b4.RowIndex = 3;
    b4.SelectedB5Class = "ht03";

    let b5: any = {};
    b5.sBuyers = "-";
    b5.sBidQty = "-";
    b5.sBid = "-";
    b5.sSellers = "-";
    b5.sAskQty = "-";
    b5.sAsk = "-";
    b5.RowIndex = 4;
    b5.SelectedB5Class = "ht03"; //ko.observable('ht03');

    let emptyBestFiveData = null;
    emptyBestFiveData = [];
    emptyBestFiveData.push(b1);
    emptyBestFiveData.push(b2);
    emptyBestFiveData.push(b3);
    emptyBestFiveData.push(b4);
    emptyBestFiveData.push(b5);
    return emptyBestFiveData;
  }

  addCoverOrder() {
    try {

      this.isCoverDataFilled = false;
      this.isBracketDataFilled = false;

      if (isNaN(parseFloat(this.selMPTriggerPrice)) || parseFloat(this.selMPTriggerPrice) == 0) {
        this.toastCtrl.showAtBottom("Trigger Price must be provided");
        return;
      }

      // if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) == 0) {
      //   this.toastCtrl.showAtBottom("Price must be provided");
      //   return;
      // }

      this.isCoverDataFilled = true;

      if (this.isBracketAllowed) {

        if (this.selLTPJumpPrice != '' || this.selProfitOrderPrice != '' || this.selSLJumpPrice != '') {


          if (this.modifyFlag) {
            if (this.hasTrailingSL && (isNaN(parseFloat(this.selSLJumpPrice)) || parseFloat(this.selSLJumpPrice) == 0)) {
              this.toastCtrl.showAtBottom("SL Jump Price must be provided");
              return;
            }

            if (this.selLTPJumpPrice != '' || this.selLTPJumpPrice != '0') {
              if (parseFloat(this.selLTPJumpPrice) < parseFloat(this.selSLJumpPrice)) {
                this.toastCtrl.showAtBottom("LTP Jump price should be greater than Trail SL Price.");
                //ltp_jump_price should be grater than or equal to stoploss_jump_price
                return;
              }
            }

            if (this.hasProfitOrderPrice && (isNaN(parseFloat(this.selProfitOrderPrice)) || parseFloat(this.selProfitOrderPrice) == 0)) {
              this.toastCtrl.showAtBottom("Profit Order Price must be provided");
              return;
            }

          } else {
            if (this.hasProfitOrderPrice && (isNaN(parseFloat(this.selProfitOrderPrice)) || parseFloat(this.selProfitOrderPrice) == 0)) {
              this.toastCtrl.showAtBottom("Profit Order Price must be provided");
              return;
            }

            if (this.hasProfitOrderPrice) {
              if (this.selSLJumpPrice && parseFloat(this.selSLJumpPrice) != 0 && this.selLTPJumpPrice && parseFloat(this.selLTPJumpPrice) != 0) {
                if (this.selLTPJumpPrice != '' || this.selLTPJumpPrice != '0') {
                  if (parseFloat(this.selLTPJumpPrice) < parseFloat(this.selSLJumpPrice)) {
                    this.toastCtrl.showAtBottom("LTP Jump price should be greater than Trail SL Price.");
                    //ltp_jump_price should be grater than or equal to stoploss_jump_price
                    return;
                  }
                }
              }
            }
          }
          this.isBracketDataFilled = true;
        }

        if (!this.isBracketDataFilled) {
          if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) == 0) {
            this.toastCtrl.showAtBottom("Price must be provided");
            return;
          }
        }

        if (this.deliveryPriceTab != 'marketPrice' && !this.isBracketDataFilled) {
          this.toastCtrl.showAtBottom("Please fill bracket order details.");
          return;
        }

      }


      if (this.selBuySell == clsConstants.C_S_ORDER_BUY_TEXT) {
        if (parseFloat(this.selMPTriggerPrice) < parseFloat(this.selMPPrice)) {
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL70"));
          return;
        }
      }
      else//Sell side case
      {
        if (parseFloat(this.selMPTriggerPrice) > parseFloat(this.selMPPrice)) {
          this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL72"));
          return;
        }
      }

      if (!this.modifyFlag) {
        if (this.selSeries != undefined || this.selExpire != undefined) {
          if (this.selInstrument.indexOf('OPT') >= 0)
            this.showAddstoploss = false
          else
            this.showAddstoploss = false
        }
      } else {
        if (this.validatePriceForRange()) {
          this.showAddstoploss = false;
        }
      }

      if (this.isBracketDataFilled || this.isCoverDataFilled) {
        this.isMarginDisplay = true;
        this.isAMO = false;
        this.getMarginUtilization()
      }

      /*
      if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_MP_TEXT) {
 
        if (isNaN(parseFloat(this.selMPTriggerPrice)) || parseFloat(this.selMPTriggerPrice) == 0) {
          this.toastCtrl.showAtBottom("Trigger Price must be provided");
          return;
        }
 
        if (isNaN(parseFloat(this.selMPPrice)) || parseFloat(this.selMPPrice) == 0) {
          this.toastCtrl.showAtBottom("Price must be provided");
          return;
        }
 
        if (this.selProduct == clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
 
          // if (isNaN(parseInt(this.selSLJumpPrice)) || parseInt(this.selSLJumpPrice) == 0) {
          //   this.toastCtrl.showWithButton("Trigger Price must be provided");
          //   return;
          // }
 
          // if (isNaN(parseInt(this.selLTPJumpPrice)) || parseInt(this.selLTPJumpPrice) == 0) {
          //   this.toastCtrl.showWithButton("Price must be provided");
          //   return;
          // }
 
          if (this.selLTPJumpPrice != '' || this.selLTPJumpPrice != '') {
            if (parseInt(this.selLTPJumpPrice) > parseInt(this.selLTPJumpPrice)) {
              this.toastCtrl.showWithButton("LTP Jump price should be greater than Trail SL Price.");
            }
            return;
          }
 
          if (isNaN(parseInt(this.selProfitOrderPrice)) || parseInt(this.selProfitOrderPrice) == 0) {
            this.toastCtrl.showWithButton("Profit Order Price must be provided");
            return;
          }
 
        }
 
        //let TrigPriceinPaise = parseInt(Math.round(parseFloat((MPTriggerPrice * DecimalLocator).toString())).toString());
        //   if (TrigPriceinPaise % parseInt(PriceTick) != 0) {
        //     if (TokenNo != "") {
        //         this.addError("TriggerPrice", clsGlobal.dMsgMaster.getItem("NNSL69") + PriceTick + clsGlobal.dMsgMaster.getItem("NNSL63"));
        //     }
        // }
 
        if (this.selBuySell == clsConstants.C_S_ORDER_BUY_TEXT) {
          if (parseFloat(this.selMPTriggerPrice) < parseFloat(this.selMPPrice)) {
            this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL71"));
            return;
          }
        }
        else//Sell side case
        {
          if (parseFloat(this.selMPTriggerPrice) > parseFloat(this.selMPPrice)) {
            this.toastCtrl.showAtBottom(clsGlobal.dMsgMaster.getItem("NNSL73"));
            return;
          }
        }
      }
      */

      //this.showAddstoploss = false;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'addCoverOrder', error);
    }
  }

  priceOnFocus() {
    this.onFocus.emit(this.objOE);
  }

  getExchangeList() {
    try {
      if (clsGlobal.exchangeName.ContainsKey(this.scripObject.symbol)) {
        this.exchangeScripList = clsGlobal.exchangeName.getItem(this.scripObject.symbol);
      } else {
        this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + "v1/getScripFromInstrumentAndExchange/EQUITIES/" + null + "/" + this.scripObject.symbol).subscribe(exchData => {
          //console.log("Exchanges: ", exchData);
          let resultdata: any = exchData;

          if (resultdata.result == undefined) {
            return;
          }
          this.exchangeScripList = [];

          for (let index = 0; index < resultdata.result.hits.hits.length; index++) {
            const element = resultdata.result.hits.hits[index]._source;

            //let currScrip: clsScrip = new clsScrip();
            // currScrip.scripDet.MktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmentId);
            // currScrip.scripDet.token = element.nToken;
            // currScrip.symbol = element.sSymbol;
            // currScrip.Series = element.sSeries;
            // currScrip.InstrumentName = element.sInstrumentName;
            // currScrip.ExpiryDate = element.nExpiryDate;
            // currScrip.StrikePrice = element.nStrikePrice || "-1";
            // currScrip.OptionType = element.sOptionType || "NA";
            // currScrip.MarketLot = element.nRegularLot || 1;
            // currScrip.PriceTick = element.nPriceTick || 1;
            let currScrip: any;
            currScrip = clsCommonMethods.getScripObject(element).scripDetail;  
            //code to check for market allowed 
            let SegmentId =currScrip.scripDet.MktSegId;//item.scripDetail.scripDet.MktSegId;
            if (!clsCommonMethods.isLoginAllowed(SegmentId)) { 
                continue;
            }  

            let exchItem = this.exchangeScripList.filter(item => {  
              return item.ExchangeName == currScrip.ExchangeName; 
            });
            if (exchItem.length == 0)
              this.exchangeScripList.push(currScrip);
          } 
          clsGlobal.exchangeName.Add(this.scripObject.symbol, this.exchangeScripList);
        });
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getExchangeList', error);
    }
  }

  toggleExchange(scrip) {
    try {
      this.showExchange = !this.showExchange;
      //this.displayExchList = this.exchangeScripList.filter((element, index, array) => {
      // return element.ExchangeName != scrip.ExchangeName;
      //});
      this.sendB5Request(OperationType.REMOVE, this.scripObject);

      this.isCoverAllowed = false;
      this.isBracketAllowed = false;
      this.scripObject = scrip;
      this.sendB5Request(OperationType.ADD, this.scripObject);
      this.selMarketLot = this.scripObject.MarketLot;
      this.selExchange = this.objOEDetail.scripDetl.ExchangeName;
      this.selProduct = this.objOEDetail.productType;

      this.onExchangeChange();
      this.selInstrument = this.scripObject.InstrumentName;;
      this.onInstrumentChange();

      this.selDecimalloc = parseInt(this.scripObject.DecimalLocator);
      if (isNaN((this.selDecimalloc)))
        this.selDecimalloc = 100;
      this.pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.selDecimalloc.toString().length - 1);


      this.selSeries = this.scripObject.Series;
      this.selExpire = this.scripObject.ExpiryDate;
      this.selStrikePrice = this.scripObject.StrikePrice;
      this.selOptionType = this.scripObject.OptionType == '' ? 'NA' : this.scripObject.OptionType;

      this.deliveryPriceTab = 'marketPrice';
      this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;


    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'toggleExchange', error);
    }
  }

  closeExchangePopup() {
    this.showExchangeAction = !this.showExchangeAction;
    this.closePopUp();
  }

  ionViewWillLeave() {
    try {

      //clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      clsGlobal.pubsub.unsubscribe("B5RES", this.bcastB5Handler);

      this.sendB5Request(OperationType.REMOVE, this.scripObject);
      clsGlobal.pubsub.unsubscribe('MTLRES', this.bcastHandler);
      this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
      clearTimeout(this._setVar);
      if(this.paramService.myParam != '')
      {
        if(this.paramService.myParam.reqBody.type == '2L' || this.paramService.myParam.reqBody.type == '3L')
        {
          this.closePopUp();
        }
      }

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'ionViewWillLeave', error);
    }
  }

  addFunds() {
    this.paramService.myParam = this.shortFall;
    this.navCtrl.navigateForward('fundsadd');
  }

  numberOnlyValidation(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }

  getOrderValuePref() {
    let orderVal = 0;
    let price = (this.selOrderType == clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT || this.selOrderType == clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT) ? parseFloat(this.LTP) : this.selPrice;
    if (price == '') {
      price = parseFloat(this.LTP);
    }
    if ((!isNaN(price)) && price != '' && this.selQty != '') {
      switch (this.scripObject.scripDet.MktSegId) {
        case clsConstants.C_V_NSE_CASH:
        case clsConstants.C_V_BSE_CASH:
        case clsConstants.C_V_BSE_DERIVATIVES:
        case clsConstants.C_V_NSE_DERIVATIVES:
        case clsConstants.C_V_MSX_CASH:
        case clsConstants.C_V_OFS_IPO_BONDS:
          /**** FORMULA: OrderValue= OrderQty * Price ****/
          orderVal = price * this.selQty;
          break;

        case clsConstants.C_V_MCX_DERIVATIVES:
        case clsConstants.C_V_ICEX_DERIVATIVES: //BT-6543/BT-6569:ShrinathGurav:14102019: Order management for ICEX Commodity Segment in Wave.
        case clsConstants.C_V_MSX_DERIVATIVES:
        case clsConstants.C_V_NSX_DERIVATIVES:
        case clsConstants.C_V_BSECDX_DERIVATIVES:
        case clsConstants.C_V_NSEL_DERIVATIVES:
        case clsConstants.C_V_NSECOMM_DERIVATIVES: //BT-343/BT-5948:ShrinathGurav:17092019: Order management for NSE Commodity Segment in Wave. 
          /**** FORMULA: OrderValue= OrderQty * Price * ((Numerator/Denominator) * (GenNumerator/GenDenominator)) * RegularLotSize ****/
          orderVal = price * this.selQty * ((parseFloat(this.priceNumerator) / parseFloat(this.priceDenominator))
            * (parseFloat(this.genNumerator) / parseFloat(this.genDenominator))) * this.selMarketLot;
          break;

        case clsConstants.C_V_MSX_FAO:
          /**** FORMULA: OrderValue= OrderQty * Price * RegularLotSize ****/
          orderVal = price * this.selQty * this.selMarketLot;
          break;

        case clsConstants.C_V_BSECOMM_DERIVATIVES: //BT-345/BT-5947:GAURAVP:17092019: Changes in WAVE for BSE Commodity Segment.
          /**** FORMULA: OrderValue= OrderQty * Price * IntrinsicValue ****/
          orderVal = price * this.selQty * this.intrinsicValue;
          break;
        case clsConstants.C_V_NCDEX_DERIVATIVES:
          /**** FORMULA: OrderValue= OrderQty * Price * (Numerator/Denominator) ****/
          orderVal = price * this.selQty * (parseFloat(this.priceNumerator) / parseFloat(this.priceDenominator));
          break;

        default: break;

      }
    }
    return parseFloat(orderVal.toFixed(2));//
  }

  kFormatter(num) {
    let fundsValueInText = '';
    let digits = 1;
    if (isNaN(num))
      num = 0;

    var si = [
      { value: 1, symbol: "" },
      { value: 1E3, symbol: "K" },
      { value: 1E5, symbol: "Lac" },
      { value: 1E7, symbol: "Cr." },
      { value: 1E12, symbol: "T" },
      { value: 1E15, symbol: "P" },
      { value: 1E18, symbol: "E" }
    ];
    var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
    var i;
    for (i = si.length - 1; i > 0; i--) {
      if (num >= si[i].value) {
        break;
      }
    }
    return fundsValueInText = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
  }

  clickChooseValidity() {
    if (!this.hasValidity) return;
    if( this.modifyFlag && this.selValidity == clsConstants.C_S_VALUE_GTD ) return;
    this.showChooseValidity = !this.showChooseValidity;
  }

  setValidity(validity) {
    this.selValidity = validity;
    this.clickChooseValidity();
    this.onValidityChange(undefined);
  }

  showValidity(validity) {

    let bShowValidity = true;
    try {

      if (this.objOEDetail.scripDetl.scripDet.MktSegId == clsConstants.C_V_NSE_CASH ||
        this.objOEDetail.scripDetl.scripDet.MktSegId == clsConstants.C_V_BSE_CASH ||
        this.objOEDetail.scripDetl.scripDet.MktSegId == clsConstants.C_V_MSX_CASH) {

        if (!(this.selProduct == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT ||
          this.selProduct == clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT) && validity == clsConstants.C_S_VALUE_GTD) {
          bShowValidity = false;
          return bShowValidity;
        }

        if (this.deliveryPriceTab != 'limitPrice' && validity == clsConstants.C_S_VALUE_GTD) {
          bShowValidity = false;
          return bShowValidity;
        }
      
      }

    } catch (error) {
      return bShowValidity;
    }

    return bShowValidity;

  }

  getProductTypeDescription(productType) {
    productType = productType.trim();
    var strProdType = "";
    switch (productType) {
      case clsConstants.C_S_PRODUCTTYPE_MARGIN_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_INTRADAY_TEXT:
        strProdType = "Buy & Sell Today";
        break;
      case clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT:

        strProdType = "Hold Long term";
        break;

      case clsConstants.C_S_PRODUCTTYPE_CARRYFORWARD_TEXT:
        strProdType = "Till Expiry";
        break;
      case clsConstants.C_S_PRODUCTTYPE_MTF_TEXT:
        strProdType = "Margin Trading Funding";
        break;
      case clsConstants.C_S_PRODUCTTYPE_MP_TEXT:
        strProdType = "Cover";
        break;
      case clsConstants.C_S_PRODUCTTYPE_PTST_TEXT:
        strProdType = "Buy Today & Sell Tomorrow";
        break;
      case clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_AMO_INTRADAY_TEXT:
        strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_MARGIN_VALUE;
        break;
      case clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT:
      case clsConstants.C_S_PRODUCTTYPE_AMO_CARRYFORWARD_TEXT:
        strProdType = clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_VALUE;
        break;
      case clsConstants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT:
        strProdType = "Bracket";
        break;
    }
    return strProdType;
  }



  gtdDateSelected(event) {
    let today = new Date();
    let maxDate = new Date();
    maxDate.setDate(today.getDate() + clsGlobal.User.GTDDays);
    if (event.date > today && event.date <= maxDate) {
      this.GTDDate = new Date(event.date).toDateString();
      let currDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      this.GTDNoOfDays = this.findNoOfDays(new Date(event.date), currDate);
    } else {
      this.GTDDate = today.toDateString()
      this.GTDNoOfDays = 0;
    }


  }

  getDate(dateObj) {
    try {

      //let dateObj = new Date();
      let day = ("0" + dateObj.getDate()).slice(-2);
      let month = ("0" + (dateObj.getMonth() + 1)).slice(-2);
      let year = dateObj.getFullYear();

      let strDate = day + "/" + month + "/" + year;
      return strDate;

    } catch (error) {

    }
  }

  onCurrentDateChanged(event) {
    this.currentMonth = clsCommonMethods.getAlphaMonth(event.getMonth());
    this.currentYear = event.getFullYear();
    this.calendar.currentDate = event;
    this.GTDDate = new Date(event).toDateString();
    let today = new Date();
    let currDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    let selDate = new Date(event.getFullYear(), event.getMonth(), event.getDate());

    let maxDate = new Date();
    maxDate.setDate(today.getDate() + clsGlobal.User.GTDDays);
    if (selDate > today && selDate <= maxDate) {
      this.GTDNoOfDays = this.findNoOfDays(selDate, currDate);
    } else {
      this.GTDDate = today.toDateString()
      this.GTDNoOfDays = 0;
    }

  }
  showCalenderDiv() {
    this.showCalender = true;
  }

  confirmGTDDate() {
    this.showCalender = false;
  }
  closeCalendarPopup() {
    //this.GTDDate = new Date().toDateString();
    //this.GTDNoOfDays = 0;
    this.showCalender = false;
  }
  isDatefromCurrentMonth(date) {
    if (this.calendar.mode == 'month') {
      if (new Date(date.date).getMonth() == new Date(this.calendar.currentDate).getMonth()) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  findNoOfDays(firstDate: Date, secondDate: Date) {
    var diff = Math.abs(firstDate.getTime() - secondDate.getTime());
    return Math.ceil(diff / (1000 * 3600 * 24));
  }

  markDisabled(date: Date) {
    var current = new Date();
    let maxDate = new Date();
    maxDate.setDate(current.getDate() + clsGlobal.User.GTDDays);
    return date < current || date > maxDate;
  }

  setCalendarDateDisabled(event) {
    let today = new Date();
    let maxDate = new Date();
    maxDate.setDate(today.getDate() + clsGlobal.User.GTDDays);
    if (event.date > today && event.date <= maxDate) {
      return false;
    } else {
      return true;
    }
  }

  resetValidity() {
    if (this.selValidity == clsConstants.C_S_VALUE_GTD) {
      this.selValidity = this.arrValidity[0];
      this.showGTDDateSelection = false;
      this.GTDNoOfDays = 0;
      this.GTDDate = new Date().toDateString();
      this.calendar.currentDate = new Date();
    }
  }

  resetComplexOrderDetails() {
    this.isCoverDataFilled = false;
    this.isBracketDataFilled = false;
    this.selMPPrice = '';
    this.selMPTriggerPrice = '';
    this.selSLJumpPrice = '';
    this.selLTPJumpPrice = '';
    this.selProfitOrderPrice = '';
  }

  //BT-37892/BT-37893:RANI G:06012021:Margin display on order entry<End>
  bIsMarginReqInProcess =false;
  getMarginUtilization() {
    try {
      this.showMarginLoader = false;
      if (this.isMarginDisplay && (this.selQty > 0 || this.selProduct == 'MULTILEGORDER')) {
        this.showMarginLoader = true;
        //if(this.bIsMarginReqInProcess) return;
        let NoOfLegs = this.selProduct.toUpperCase() == 'MULTILEGORDER' ? this.MultilegsDetails.length : 1;
        //if (this.SelProduct == Global.Constants.C_S_PRODUCTTYPE_MP_TEXT)
        //    NoOfLegs = 2;
        //else if (this.SelProduct == Global.Constants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
        //    NoOfLegs = 3;
        this.isMarginBtnEnable = false;
        this.fundFlag = false;
        this.approximateMargin = 0;
        this.availableMargin = 0;
        this.shortFall = 0;
        let jData = {};
        jData["UserID"] = clsGlobal.User.userId;
        jData["GroupID"] = clsGlobal.User.groupId;
        jData["UCCClientID"] = "";
        jData["UCCGroupID"] = "";
        jData["NoOfLegs"] = NoOfLegs;
        jData["Mode"] = this.modifyFlag == false ? "N" : "M";
        jData["TemplateId"] = clsGlobal.User.SITemplateId;
        jData['UserCode'] = clsGlobal.User.userCode;
        if(this.selProduct.toUpperCase() != 'MULTILEGORDER')
        {
          jData["LegDetails"] = this.legDetailsObject(NoOfLegs);
        }
        else
        {
          jData["LegDetails"] = this.legMultilegDetailsObject(NoOfLegs);
        }
        jData['FETraceId'] = clsGlobal.User.userId + "_" + moment().format('ddmmyyHHMMss');
        jData['GroupCode'] = clsGlobal.User.groupCode;

        this.bIsMarginReqInProcess =true;

        this.tranService.getOrderMarginInfo(jData).then((response: any) => {
          this.bIsMarginReqInProcess =false;
          this.showMarginLoader = false;
          //console.log("Margin calculation "+ JSON.stringify(response));
          if (response.data.status == "200") {
            this.approximateMargin = this.kFormatter(response.data.result.ApproxMargin);
            this.fundsRequired = parseFloat(response.data.result.ApproxMargin);
            this.availableMargin = this.kFormatter(response.data.result.AvailableMargin);
            this.fundsAvailable = parseFloat(response.data.result.AvailableMargin);
            this.shortFall = parseFloat(response.data.result.ShortFall);
            this.checkMarginShortFall();
          }
        }).catch(error => {
          this.bIsMarginReqInProcess =false;
          this.showMarginLoader = false;
          //this.toastCtrl.showAtBottom("Unable to fetch margin details, kindly contact administrator.");
          console.log("Unable to fetch margin details, kindly contact administrator.");
        });
      }
      else
      {
        this.approximateMargin = 0;
        this.showMarginLoader = false;
      }
    }
    catch (e) {
      this.showMarginLoader = false;
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'getMarginUtilization', 'Exception: ' + e.message);
    }

  }

  legDetailsObject(NoOfLegs) {
    try {
      var LegDtls = [];
      for (var i = 1; i <= NoOfLegs; i++) {
        var jData_legDtls = {};
        jData_legDtls["LegNo"] = i;
        if (i == 1) {
          jData_legDtls["BuyOrSell"] = this.selBuySell === clsConstants.C_S_ORDER_BUY_TEXT ? 1 : 2;
        }
        //else if (i == 2 || i == 3) {
        //    if (this.SelBuySell === Global.Constants.C_S_ORDER_BUY_TEXT)
        //        jData_legDtls["BuyOrSell"] = 2;
        //    else
        //        jData_legDtls["BuyOrSell"] = 1;
        //}
        jData_legDtls["MarketSegmentId"] = this.scripObject.scripDet.MapMktSegId;//for BSE issue, solved 
        jData_legDtls["Token"] = this.scripObject.scripDet.token;
        jData_legDtls["Quantity"] = this.selQty != "" ? parseFloat(this.selQty) : 0;
        if (i == 1) {
          var Price = 0;
          var isMarketOrder = false;
          if (clsTradingMethods.isCommodityExchange(this.scripObject.scripDet.MapMktSegId.toString())) {
            if (this.selPrice == "") {
              isMarketOrder = true;
            }
          }
          else {
            if (this.selPrice == 0) {
              isMarketOrder = true;
            }
          }
          if (isMarketOrder && this.deliveryPriceTab == 'marketPrice') {
            var _iOrderType = clsGlobal.ExchManager.getOrderType(this.selOrderType, this.selPrice, this.selInstrument, this.selProduct, this.selMPMFFlag, this.isSpread);
            Price = clsGlobal.ExchManager.derivePriceforMarketOrder(this.selOperation, _iOrderType, this.selTriggerPrice, this.selPriceTick, this.selDecimalloc, this.selProdPer, this.buyPrice, this.sellPrice, this.MPLTP, this.MPClosePrice, this.MPLowPr, this.MPHighPr);
            if (Price == undefined) {
              Price = 0;
            }
            //if (this.SelProduct == Global.Constants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT) {
            //    var dblProtPercforBracket = this.SelProdPer;
            //    if (dblProtPercforBracket == null || dblProtPercforBracket == 'undefined') //if not defined in pref then take default value
            //        dblProtPercforBracket = Global.User.OrderPrefDic.items[this.MarketSegmentId].nDefaultProtPerc;
            //    Price = Global.ExchManager.DerivePriceforBracketMarketOrder(this.SelOperation, this.MPLTP, this.SelProfitOrderPrice, this.SelPriceTick, this.SelDecimalloc, dblProtPercforBracket, this.MPLowPr, this.MPHighPr);
            //}
            //else {
            //    Price = Global.ExchManager.DerivePriceforMarketOrder(this.SelOperation, _iOrderType, this.SelTriggerPrice, this.SelPriceTick, this.SelDecimalloc, this.SelProdPer, this.BuyPrice, this.SellPrice, this.MPLTP, this.MPClosePrice, this.MPLowPr, this.MPHighPr, this.MapMarketSegmentId);
            //}
          }
          else {
            Price = this.selPrice != "" && this.selPrice != undefined ? parseFloat(this.selPrice) : 0;
          }
          if(this.isCoverDataFilled || this.isBracketDataFilled)
          {
            Price = this.selMPPrice != "" && this.selMPPrice != undefined ? parseFloat(this.selMPPrice) : 0;
          }
          jData_legDtls["Price"] = Price;
          jData_legDtls["MktFlag"] = isMarketOrder == true ? 1 : 0;

          if (this.modifyFlag) {
            jData_legDtls["OldPrice"] = this.prevSelPrice != "" && this.prevSelPrice != undefined ? parseFloat(this.prevSelPrice) : 0;
          }
          else {
            jData_legDtls["OldPrice"] = 0;
          }

        }
        //else if (i == 2) {
        //    jData_legDtls["Price"] = this.SelMPPrice != "" && this.SelMPPrice != undefined ? parseInt((parseFloat(this.SelMPPrice) * parseFloat(this.SelDecimalloc)).toFixed(2)) : 0;
        //    if (this.ModifyFlag) {
        //        jData_legDtls["OldPrice"] = this.PrevSelMPPrice != "" && this.PrevSelMPPrice != undefined ? parseInt((parseFloat(this.PrevSelMPPrice) * parseFloat(this.SelDecimalloc)).toFixed(2)) : 0;
        //    }
        //    else
        //    {
        //        jData_legDtls["OldPrice"] = 0;
        //    }
        //    jData_legDtls["MktFlag"] = 0;
        //}
        //else if (i == 3) {
        //    jData_legDtls["Price"] = this.SelProfitOrderPrice != "" && this.SelProfitOrderPrice != undefined ? parseInt((parseFloat(this.SelProfitOrderPrice) * parseFloat(this.SelDecimalloc)).toFixed(2)) : 0;
        //    if (this.ModifyFlag) {
        //        jData_legDtls["OldPrice"] = this.PrevSelProfitOrderPrice != "" && this.PrevSelProfitOrderPrice != undefined ? parseInt((parseFloat(this.PrevSelProfitOrderPrice) * parseFloat(this.SelDecimalloc)).toFixed(2)) : 0;
        //    }
        //    else
        //    {
        //        jData_legDtls["OldPrice"] = 0;
        //    }
        //    jData_legDtls["MktFlag"] = 0;
        //}

        jData_legDtls["OldQuantity"] = this.prevSelQuantity != "" ? this.prevSelQuantity : 0;
        jData_legDtls["ProductType"] = clsTradingMethods.getProductTypeValue(this.selProduct);//this.SelProduct;
        //if (NoOfLegs == 3) { //Bracket Order
        //    if (i == 1)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_MAIN_LEG_INDICATOR;
        //    if (i == 2)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_SL_LEG_INDICATOR;
        //    if (i == 3)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_PROFIT_LEG_INDICATOR;
        //}
        //else {
        //    jData_legDtls["LegIndicator"] = 0;
        //}
        jData_legDtls["LegIndicator"] = 0;
        jData_legDtls["UserID"] = clsGlobal.User.userId;
        LegDtls.push(jData_legDtls);
      }
      return LegDtls;
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'LegDetailsObject', 'Exception: ' + e.message);
    }
  }

  FetchEDISDetails() {
    return new Promise((resolve, reject) => {
      try {
        if (this.checkForEDISFlag(this.selBuySell, this.selProduct, this.modifyFlag, this.originalQty, this.selQty)) {


          if (clsGlobal.User.DPDetails[0] != undefined) {

            if (clsGlobal.User.DPDetails[0].sDepository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_CDSL) {

              this.modalCtrl.create({
                component: EDISSummaryComponent,
                //cssClass: 'my-custom-class',
                componentProps: {
                  'scrip': this.scripObject,
                  'Qty': this.selQty
                }
              }).then(modal => {
                modal.present().then(data => {

                });
                modal.onDidDismiss().then(data => {
                  if (data != undefined) {
                    resolve(data);
                  } else {
                    reject('');
                  }
                })
              })

            } else {

              this.getNSDLSummaryData(resolve, reject);

            }
          } else {
            reject('');
          }

        } else {
          resolve("");
        }
      } catch (error) {
        clsGlobal.logManager.writeErrorLog('OrderEntryPage', 'FetchEDISDetails', error);
      }
    });
  }

  getNSDLSummaryData(resolve, reject) {
    try {

      let sellQty = this.selQty;
      let mtSegId = this.scripObject == undefined ? -1 : this.scripObject.scripDet.MapMktSegId;
      let token = this.scripObject == undefined ? -1 : this.scripObject.scripDet.token;
      let depository = clsGlobal.User.DPDetails[0].sDPId;
      let summaryMktSegId = this.scripObject == undefined ? -1 : this.scripObject.scripDet.MapMktSegId;

      this.tranService.getEDISSummaryDetails(sellQty, mtSegId, token, depository, summaryMktSegId).then((summaryData: any) => {

        //console.log("Data: ", summaryData);
        if (summaryData.status == 'Success') {

          if (summaryData.data.ResponseStatus) {

            this.edisNSDLData = summaryData.data;

            this.edisNSDLData.DPDetails = clsGlobal.User.DPDetails[0];

            if (summaryData.data.DPDetail != undefined) {
              this.edisNSDLData.ISIN = summaryData.data.DPDetail.ISIN;
              this.edisNSDLData.QuantityToHold = summaryData.data.DPDetail.QuantityToHold == -1 ? this.originalQty : summaryData.data.DPDetail.QuantityToHold;
              this.edisNSDLData.SecurityDescription = summaryData.data.DPDetail.SecurityDescription;
            }

            this.openNSDLCDSLPage(this.edisNSDLData.DPDetails, this.scripObject.ExchangeName, 'Equity', this.scripObject.scripDet.MapMktSegId, this.edisNSDLData.DPQtyTable);


          } else {
            let errCode = summaryData.data.ErrorCode;
            if (errCode != undefined) {
              let errMsg = clsGlobal.dMsgMaster.getItem(errCode).replace('{1}', this.scripObject.ExchangeName);
              //this.toastCtrl.showAtBottom(errMsg);
              this.alertCtrl.showAlertCallbackWithSingleButton(errMsg).then((data) => {

              });
            } else {
              //this.eDISReqRefNo.status = "1";
            }

          }
        } else {
          this.alertCtrl.showAlertCallbackWithSingleButton(summaryData.errorString).then((data) => {

          });

        }

      }).catch(error => {
        reject(undefined)
      })

    } catch (error) {
      reject(undefined)
    }
  }

  iInterval: any = 0;
  openNSDLCDSLPage(EDISOnlineDetails, ExchangeName, InstrumentName, MarketSegmentId, arryMultiScrips) {
    try {

      let strUrl = clsTradingMethods.generateEDISUrl(EDISOnlineDetails, ExchangeName, InstrumentName, MarketSegmentId, arryMultiScrips);

      let openwindowobj: any = this.iab.create(strUrl, '_blank', 'location=yes');
      this.iInterval = 0;
      this.iInterval = setInterval(this.closedEDISThirdPartyURL.bind(this), 200, openwindowobj);
      // setInterval(function () {
      //     this.ClosedEDISThirdPartyURL(this.openwindowobj);
      // }, 200);
      openwindowobj.on('exit').subscribe((event) => {
        clearInterval(this.iInterval);
        this.toastCtrl.showAtBottom('Exit Called');
        if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
          setTimeout(() => {
            openwindowobj.close();
          }, 1500);
        }

      });

    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('popup-order-entry', 'openNSDLCDSLPage', 'Exception: ' + e.message);
    }
  }

  closedEDISThirdPartyURL(openwindowobj) {
    try {
      openwindowobj.executeScript({
        code: clsConstants.C_S_EDIS_THIRD_PARTY_RESPONSE_KEY
      },
        (data) => {
          try {

            let jsonData = JSON.parse(data);
            this.toastCtrl.showAtBottom('jsonData' + jsonData);
            if (jsonData.Status == 'Success') {

              this.processEDISResponse(jsonData, openwindowobj);
              /*
              if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
                clearInterval(this.iInterval); //// will colse window
                setTimeout(function () {
                  openwindowobj.close();
                }, 1500);
              }

              let ScripDetails = JSON.parse(jsonData.ScripDetails);

              this.eDISReqRefNo.sISINCode = this.edisNSDLData.DPDetails.ISIN;
              this.eDISReqRefNo.sDepository = this.edisNSDLData.DPDetails.sDepository;
              let data = clsTradingMethods.findDPAndClientID(this.edisNSDLData.DPDetails, this.edisNSDLData.DPDetails.sDepository);
              this.eDISReqRefNo.sDPId = data[0];
              this.eDISReqRefNo.sMktsegId = this.scripObject.scripDet.MktSegId;// this.MapMarketSegmentId;
              this.eDISReqRefNo.sToken = this.scripObject.scripDet.token;

              this.eDISReqRefNo.status = jsonData.Status;
              this.eDISReqRefNo.eDISReqId = jsonData.RefNum;
              this.eDISReqRefNo.nTotalAvailableQty = jsonData.BlkQty;
              this.eDISReqRefNo.nApprovedFreeQty = this.edisNSDLData.DPDetails.QuantityToHold;
              */
            }
            else {
              if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
                clearInterval(this.iInterval); //// will colse window
                setTimeout(function () {
                  openwindowobj.close();
                }, 1500);
              }

            }
          } catch (error) {
            console.log(error);
            //this.toastCtrl.showAtBottom('closedEDISThirdPartyURL error: ' + error.message);
          }
        });
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'closedEDISThirdPartyURL', 'Exception: ' + e.message);
    }
  }


  checkForEDISFlag(SelOperation, SelProduct, ModifyFlag, OriginalQty, SelQty): boolean {
    let flag = false;
    try {

      if (!clsGlobal.User.POAStatus && SelOperation == clsConstants.C_S_ORDER_SELL_TEXT
        && (SelProduct == clsConstants.C_S_PRODUCTTYPE_DELIVERY_TEXT || SelProduct == clsConstants.C_S_PRODUCTTYPE_AMO_DELIVERY_TEXT)) {
        flag = true;
      }
      else {
        flag = false;
      }
      // when order is modified and modifiedQty is smaller/equals to Original Qty eDIS is not require. so set flag false.
      if (flag && ModifyFlag && (OriginalQty >= parseInt(SelQty))) {
        flag = false;
      }
    } catch (e) {
      clsGlobal.logManager.writeErrorLog('PopupOrderentryComponent', 'checkForEDISFlag', e);
    }
    return flag;
  }

  updateEDISReqRefNo() {
    try {
      this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + clsGlobal.LocalComId + clsGlobal.versionId + '/updateEDISRefNo/' + this.orderID + '/' + this.eDISReqRefNo).subscribe(((data: any) => {
        try {

        } catch (error) {
          //this.toastCtrl.showAtBottom(error.message);
          clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'updateEDISReqRefNo1', error);
        }
      }), error => {
        clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'updateEDISReqRefNo2', error);
      })
    } catch (error) {
      console.log(error);
    }
  }


  getFormattedNumbers(sNumber) {
    if (sNumber) {
      return clsCommonMethods.getNumberWithCurrencyFormat(sNumber);
    } else {
      return 0.00;
    }
  }

  insertEDISCDSLResponse() {
    try {

      if (
        clsGlobal.User.POAStatus == false &&
        (clsGlobal.User.DPDetails[0].sDepository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_CDSL || clsGlobal.User.DPDetails[0].sDepository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_NSDL) &&
        (this.eDISReqRefNo != undefined && this.eDISReqRefNo.eDISReqId != '')) {

        //this.toastCtrl.showWithButton('Inserting CDSL Resp');
        let jData = {};
        jData['sUserCode'] = clsGlobal.User.userCode
        jData["sRequestType"] = (this.modifyFlag ? "Order Modify" : " Order Entry");
        jData["eDISReqId"] = this.eDISReqRefNo.eDISReqId;
        jData["sISINCode"] = this.eDISReqRefNo.sISINCode;
        jData["sDepository"] = this.eDISReqRefNo.sDepository;
        jData["sDPId"] = this.eDISReqRefNo.sDPId;
        jData["sMktsegId"] = this.eDISReqRefNo.sMktsegId;
        jData["sToken"] = this.eDISReqRefNo.sToken;
        jData["nTotalAvailableQty"] = this.eDISReqRefNo.nTotalAvailableQty;
        jData["nApprovedFreeQty"] = this.eDISReqRefNo.nApprovedFreeQty;
        jData["nOrderQty"] = this.selQty;
        jData["nClientOrderNo"] = this.clientOrderNumber;
        jData["sProductCode"] = "WAVE";

        //this.toastCtrl.showWithButton('Inserting CDSL Resp');
        this.tranService.insertEDISResponse(jData).then((resp: any) => {
          //this.toastCtrl.showWithButton('Inserting CDSL Success');
        }).catch((error) => {
          //this.toastCtrl.showWithButton('Inserting CDSL Failed');
        });

        //var _strRequest = JSON.stringify(jData);
        //Global.CommonMethods.AjaxCallForJSON(Global.URL_TRADINGWCF, 'InserteDISReqRefNoponse', _strRequest, this.InsertEDSISReqResSuccess, "", true, null, Global.User.OCToken);
      }

    } catch (error) {
      console.log(error);
      //this.toastCtrl.showAtBottom('Erro Inserting CDSL Resp: ' + error.message);
    }
  }

  processEDISResponse(jsonData, openwindowobj) {
    try {
      if ((openwindowobj != undefined) && (!openwindowobj.closed)) {
        clearInterval(this.iInterval); //// will colse window
        setTimeout(function () {
          openwindowobj.close();
        }, 1500);
      }

      let ScripDetails = JSON.parse(jsonData.ScripDetails);
      //this.arrReqValidData.

      this.eDISReqRefNo.sISINCode = this.edisNSDLData.DPDetails.ISIN;
      this.eDISReqRefNo.sDepository = this.edisNSDLData.DPDetails.sDepository;
      let data = clsTradingMethods.findDPAndClientID(this.edisNSDLData.DPDetails, this.edisNSDLData.DPDetails.sDepository);
      this.eDISReqRefNo.sDPId = data[0];
      this.eDISReqRefNo.sMktsegId = this.scripObject.scripDet.MktSegId;// this.MapMarketSegmentId;
      this.eDISReqRefNo.sToken = this.scripObject.scripDet.token;

      this.eDISReqRefNo.status = jsonData.Status;

      this.eDISReqRefNo.status = jsonData.Status;
      this.eDISReqRefNo.eDISReqId = jsonData.RefNum;
      this.eDISReqRefNo.nTotalAvailableQty = jsonData.BlkQty;
      this.eDISReqRefNo.nApprovedFreeQty = this.edisNSDLData.DPDetails.QuantityToHold;


    } catch (error) {

    }
  }

  openCloseLeg(item) {
    this.priceOnFocus();
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legopenclose == true) {
        if (this.MultilegsDetails[count].legprice == '') {
          this.toastCtrl.showWithButton("Price must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].sellimitlegPrice) == 0 && this.MultilegsDetails[count].legpricetoggle == 'limitlegPrice') {
          this.toastCtrl.showWithButton("Price cannot be Zero for Limit");
          return;
        }
        if (this.MultilegsDetails[count].totallegLot == '') {
          this.toastCtrl.showWithButton("Lot must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].totallegLot) == 0) {
          this.toastCtrl.showWithButton("Lot cannot be Zero");
          return;
        }
        let PriceinPaise = parseInt(Math.round(parseFloat((this.MultilegsDetails[count].legprice * this.MultilegsDetails[count].legDecimalLocator).toString())).toString());

        if (PriceinPaise % parseInt(this.MultilegsDetails[count].legpricetick) != 0) {
          let PriceFormatter = clsTradingMethods.GetPriceFormatter(this.MultilegsDetails[count].legDecimalLocator.toString(), this.MultilegsDetails[count].legmktsegid, this.MultilegsDetails[count].leginstrumentName);
          let PriceTickInRs = (parseFloat(this.MultilegsDetails[count].legpricetick) / this.MultilegsDetails[count].legDecimalLocator).toFixed(PriceFormatter);
          this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTickInRs); //+ clsGlobal.dMsgMaster.getItem("NNSL63"));
          return
        }
      }
    }
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (item.legmktsegid == this.MultilegsDetails[count].legmktsegid && item.legToken == this.MultilegsDetails[count].legToken) {
        this.MultilegsDetails[count].legopenclose = true;
      }
      else {
        this.MultilegsDetails[count].legopenclose = false;
      }
    }
  }

  async getScripForSecondLeg() {
    try {
      if (this.scripObject.ExpiryDate != 'NA') {
        let month1 = this.scripObject.ExpiryDate.substr(2, 3).toLowerCase();
        var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
        var mon = months.indexOf(month1) + 1;
      }
      let scripObject = {
        mktSegid: this.scripObject.scripDet.MapMktSegId,
        symbol: this.scripObject.symbol,
        instrument: this.scripObject.InstrumentName,
        strikeprice: this.scripObject.StrikePrice == 'NA' ? 0 : parseFloat(this.scripObject.StrikePrice) * this.scripObject.DecimalLocator,
        optiontype: this.scripObject.OptionType == 'NA' ? '' : this.scripObject.OptionType,
        expiryDate: this.scripObject.ExpiryDate.substr(-4) + '-' + mon + '-' + this.scripObject?.ExpiryDate.substr(0, 2)
      }
      await this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + clsGlobal.LocalComId + clsGlobal.versionId + '/getScripForSecondLeg', scripObject).subscribe(((data: any) => {
        try {
          if (data.status.toUpperCase() == 'SUCCESS' && data.data != undefined) {
            let leg2Date = clsTradingMethods.getSecondLegDate(data.data.nExpiryDate)
            let leg2Details = {
              legexpiryDate: leg2Date,
              legexpiryDayIOS: leg2Date.substr(2, 3) + '/' + leg2Date.substr(0, 2) + '/' + leg2Date.substr(-4),
              // legexpiryDay : legexpiryDate.substr(0,2),
              // legexpiryMonth : legexpiryDate.substr(2,3),
              legsymbol: data.data.sSymbol.trim(),
              legseries: data.data.sSeries.trim(),
              legoptionType: data.data.sOptionType.trim() == 'XX' ? "" : data.data.sOptionType.trim(),
              leginstrumentName: data.data.sInstrumentName,
              //leginstru : leginstrumentName.substr(0,3),
              originallegLot: data.data.nRegularLot,
              totallegLot : 1,
              legstrikePrice: (data.data.nStrikePrice == -1 || data.data.nStrikePrice == 'NA') ? '' : (data.data.nStrikePrice / data.data.nPriceBdAttribute).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, data.data.nPriceBdAttribute.toString().length - 1)),
              legToken: data.data.nToken,
              legDecimalLocator: data.data.nPriceBdAttribute || 100,
              legmktsegid: this.scripObject.scripDet.MktSegId,
              legmapmktsegid: this.scripObject.scripDet.MapMktSegId,
              legpricetick: data.data.nPriceTick,
              legexchangename: clsTradingMethods.getExchangeName(this.scripObject.scripDet.MktSegId),
              legpriceprecision: clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, data.data.nPriceBdAttribute.toString().length - 1),
              legprice: '0.00',
              legopenclose: false,
              legbuysell: 'BUY',
              sellimitlegPrice: '',
              selmarketlegPrice: '0.00',
              legpricetoggle: 'marketlegPrice',
              removeLeg: false
            }
            this.MultilegsDetails.push(leg2Details);
            this.getMarginUtilization();
            this.sendLegTouchLine();
          }
        } catch (error) {
          //this.toastCtrl.showAtBottom(error.message);
          clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getScripForSecondLeg1', error);
        }
      }), error => {
        clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'getScripForSecondLeg2', error);
      })
    } catch (error) {
      console.log(error);
    }
  }

  legBuySellChange(evt, item) {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legToken == item.legToken &&
        this.MultilegsDetails[count].legmktsegid == item.legmktsegid) {
        this.MultilegsDetails[count].legbuysell = evt.detail.value.toUpperCase();
      }
    }
    this.getMarginUtilization();
  }

  plusminusleg(event, item) {
    this.priceOnFocus();
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legToken == item.legToken &&
        this.MultilegsDetails[count].legmktsegid == item.legmktsegid) {
        if (this.MultilegsDetails[count].totallegLot == '') {
          this.MultilegsDetails[count].totallegLot = 1
          return;
        }
        if (event == 'minus') {
          if (parseFloat(this.MultilegsDetails[count].totallegLot) == 1) {
            return;
          }
          if (parseFloat(this.MultilegsDetails[count].totallegLot) == 0) {
            this.toastCtrl.showWithButton("Lot cannot be negative");
            return;
          }
          this.MultilegsDetails[count].totallegLot = parseFloat(this.MultilegsDetails[count].totallegLot) - 1;
        }
        else if (event == 'plus') {
          this.MultilegsDetails[count].totallegLot = parseFloat(this.MultilegsDetails[count].totallegLot) + 1;
        }
      }
    }
    this.getMarginUtilization();
  }

  sendTouchlineRequest(opType: OperationType, scripList: any) {
    try {

      if (scripList != null && scripList.length > 0) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList = scripList;
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('Popup-Orderentry', 'sendTouchlineRequest', error);
    }
  }

  receiveTouchlineResponse(objMultiTLResp: clsMultiTouchLineResponse) {
    try {
      if (objMultiTLResp != null) {
        for (let count = 0; count < this.MultilegsDetails.length; count++) {
          if (this.MultilegsDetails[count].legToken == objMultiTLResp.Scrip.token &&
            this.MultilegsDetails[count].legmktsegid == objMultiTLResp.Scrip.MktSegId) {
            this.MultilegsDetails[count].selmarketlegPrice = (((parseFloat(objMultiTLResp.LTP) == 0) || objMultiTLResp.LTP == "" || objMultiTLResp.LTP == undefined) ? objMultiTLResp.ClosePrice : objMultiTLResp.LTP);
            if(this.MultilegsDetails[count].selmarketlegPrice == '')
            {
              let price = 0;
              this.MultilegsDetails[count].selmarketlegPrice = price.toFixed(this.MultilegsDetails[count].legpriceprecision);
            }
            this.MultilegsDetails[count].legprice = (this.MultilegsDetails[count].legpricetoggle == 'marketlegPrice' ? this.MultilegsDetails[count].selmarketlegPrice : this.MultilegsDetails[count].sellimitlegPrice);
          }
        }
      }
    }
    catch (error) {
      console.log('Popup-Orderentry', 'receiveTouchlineResponse', error);
    }

  }

  openMultilegConfirm() {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legopenclose == true) {
        if (this.MultilegsDetails[count].legprice == '') {
          this.toastCtrl.showWithButton("Price must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].sellimitlegPrice) == 0 && this.MultilegsDetails[count].legpricetoggle == 'limitlegPrice') {
          this.toastCtrl.showWithButton("Price cannot be Zero for Limit");
          return;
        }
        if (this.MultilegsDetails[count].totallegLot == '') {
          this.toastCtrl.showWithButton("Lot must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].totallegLot) == 0) {
          this.toastCtrl.showWithButton("Lot cannot be Zero");
          return;
        }
        let PriceinPaise = parseInt(Math.round(parseFloat((this.MultilegsDetails[count].legprice * this.MultilegsDetails[count].legDecimalLocator).toString())).toString());

        if (PriceinPaise % parseInt(this.MultilegsDetails[count].legpricetick) != 0) {
          let PriceFormatter = clsTradingMethods.GetPriceFormatter(this.MultilegsDetails[count].legDecimalLocator.toString(), this.MultilegsDetails[count].legmktsegid, this.MultilegsDetails[count].leginstrumentName);
          let PriceTickInRs = (parseFloat(this.MultilegsDetails[count].legpricetick) / this.MultilegsDetails[count].legDecimalLocator).toFixed(PriceFormatter);
          this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTickInRs); //+ clsGlobal.dMsgMaster.getItem("NNSL63"));
          return
        }
      }
    }
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      this.MultilegsDetails[count].legopenclose = false;
    }
    let confirmDetails = {
      legdetails: this.MultilegsDetails,
      approxmargin: this.approximateMargin,
      availableMargin: this.availableMargin,
      validity : this.legvalidity,
      isMultiLeg : true,
      isSpread : false
    }
    this.modalCtrl.create({
      component: MultilegConfirmationPage,
      //cssClass: 'my-custom-class',
      componentProps: {
        'scrip': confirmDetails,
      }
    }).then(modal => {
      modal.present().then(data => {

      });
      modal.onDidDismiss().then(data => {
        if(data.data != '' && data.data != undefined)
        {
          this.closePopUp();
        }
        else
        {
          this.sendLegTouchLine();
          this.sendB5Request(OperationType.ADD, this.scripObject);
        }
      })
    })
  }

  leglimitpriceLostFocus(item) {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legToken == item.legToken &&
        this.MultilegsDetails[count].legmktsegid == item.legmktsegid) {
        if (this.MultilegsDetails[count].legpricetoggle == 'limitlegPrice') {
          if (this.MultilegsDetails[count].sellimitlegPrice == '' || this.MultilegsDetails[count].sellimitlegPrice == undefined) {
            this.MultilegsDetails[count].sellimitlegPrice = '0.00';
          }
          this.MultilegsDetails[count].legprice = parseFloat(this.MultilegsDetails[count].sellimitlegPrice).toFixed(this.MultilegsDetails[count].legpriceprecision);
          this.MultilegsDetails[count].sellimitlegPrice = this.MultilegsDetails[count].legprice;
        }
      }
    }
    this.getMarginUtilization();
  }

  legopenlookup(i) {
    if (i == 0) {
      this.leg1Edit = true;
    }
    else if (i == 1) {
      this.leg2Edit = true;
    }
    else if (i == 2) {
      this.leg3Edit = true;
    }

    let legsdetails = {
      legdetails: this.MultilegsDetails,
      symbol: this.scripObject.symbol,
      exchange: this.scripObject.ExchangeName
    }
    this.modalCtrl.create({
      component: MultilegLookupPage,
      //cssClass: 'my-custom-class',
      componentProps: {
        'scrip': legsdetails,
      }
    }).then(modal => {
      modal.present().then(data => {

      });
      modal.onDidDismiss().then(data => {
        if (data.data != undefined) {
          if (this.leg1Edit) {
            this.MultilegsDetails[0].legsymbol = data.data._source.sSymbol;
            this.MultilegsDetails[0].legexpiryDate = data.data._source.nExpiryDate1 == 'NA' ? '' : data.data._source.nExpiryDate1;
            this.MultilegsDetails[0].legexpiryDayIOS = data.data._source.nExpiryDate1.substr(2, 3) + '/' + data.data._source.nExpiryDate1.substr(0, 2) + '/' + data.data._source.nExpiryDate1.substr(-4),
              // this.legexpiryDay = this.legexpiryDate.substr(0,2);
              // this.legexpiryMonth = this.legexpiryDate.substr(2,3);
              this.MultilegsDetails[0].legexchangename = data.data._source.sExchange;
            this.MultilegsDetails[0].leginstrumentName = data.data._source.sInstrumentName;
            //this.MultilegsDetails[0].leginstru = this.MultilegsDetails[0].leginstrumentName.substr(0,3);
            this.MultilegsDetails[0].legstrikePrice = (data.data._source.nStrikePrice1 == 'NA' || data.data._source.nStrikePrice1 == undefined) ? '' : data.data._source.nStrikePrice1;
            this.MultilegsDetails[0].legoptionType = data.data._source.sOptionType == 'NA' ? '' : data.data._source.sOptionType;
            this.MultilegsDetails[0].originallegLot = data.data._source.nRegularLot;
            this.MultilegsDetails[0].totallegLot = 1;
            this.MultilegsDetails[0].legmktsegid = clsTradingMethods.GetMarketSegmentID(data.data._source.nMarketSegmentId);
            this.MultilegsDetails[0].legmapmktsegid = data.data._source.nMarketSegmentId;
            this.MultilegsDetails[0].legseries = 'XX';
            this.MultilegsDetails[0].legDecimalLocator = data.data._source.nPriceBdAttribute || 100;
            this.MultilegsDetails[0].legToken = data.data._source.nToken;
            this.MultilegsDetails[0].legpricetick = data.data._source.nPriceTick;
            this.MultilegsDetails[0].selmarketlegPrice = '0.00';
            this.MultilegsDetails[0].sellimitlegPrice = '';
            this.MultilegsDetails[0].legpriceprecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.MultilegsDetails[0].legmktsegid, this.MultilegsDetails[0].legDecimalLocator.toString().length - 1);
            this.MultilegsDetails[0].legprice = (this.MultilegsDetails[0].legpricetoggle == 'marketlegPrice' ? this.MultilegsDetails[0].selmarketlegPrice : this.MultilegsDetails[0].sellimitlegPrice);
            this.MultilegsDetails[0].legopenclose = false;
            this.MultilegsDetails[0].legbuysell = 'BUY';
            this.MultilegsDetails[0].legpricetoggle = 'marketlegPrice';
            this.MultilegsDetails[0].removeLeg = false;
          }
          else if (this.leg2Edit) {
            this.MultilegsDetails[1].legsymbol = data.data._source.sSymbol;
            this.MultilegsDetails[1].legexpiryDate = data.data._source.nExpiryDate1 == 'NA' ? '' : data.data._source.nExpiryDate1;
            this.MultilegsDetails[1].legexpiryDayIOS = data.data._source.nExpiryDate1.substr(2, 3) + '/' + data.data._source.nExpiryDate1.substr(0, 2) + '/' + data.data._source.nExpiryDate1.substr(-4),
              // this.MultilegsDetails[1].legexpiryDay = this.MultilegsDetails[1].legexpiryDate.substr(0,2);
              // this.MultilegsDetails[1].legexpiryMonth = this.MultilegsDetails[1].legexpiryDate.substr(2,3);
              this.MultilegsDetails[1].legexchangename = data.data._source.sExchange;
            this.MultilegsDetails[1].leginstrumentName = data.data._source.sInstrumentName;
            //this.MultilegsDetails[1].leginstru = this.MultilegsDetails[1].leginstrumentName.substr(0,3);
            this.MultilegsDetails[1].legstrikePrice = (data.data._source.nStrikePrice1 == 'NA' || data.data._source.nStrikePrice1 == undefined) ? '' : data.data._source.nStrikePrice1;
            this.MultilegsDetails[1].legoptionType = data.data._source.sOptionType == 'NA' ? '' : data.data._source.sOptionType;
            this.MultilegsDetails[1].originallegLot = data.data._source.nRegularLot;
            this.MultilegsDetails[1].totallegLot = 1;
            this.MultilegsDetails[1].legmktsegid = clsTradingMethods.GetMarketSegmentID(data.data._source.nMarketSegmentId);
            this.MultilegsDetails[1].legmapmktsegid = data.data._source.nMarketSegmentId;
            this.MultilegsDetails[1].legseries = 'XX';
            this.MultilegsDetails[1].legDecimalLocator = data.data._source.nPriceBdAttribute || 100;
            this.MultilegsDetails[1].legToken = data.data._source.nToken;
            this.MultilegsDetails[1].legpricetick = data.data._source.nPriceTick;
            this.MultilegsDetails[1].selmarketlegPrice = '0.00';
            this.MultilegsDetails[1].sellimitlegPrice = '';
            this.MultilegsDetails[1].legpriceprecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.MultilegsDetails[1].legmktsegid, this.MultilegsDetails[1].legDecimalLocator.toString().length - 1);
            this.MultilegsDetails[1].legprice = (this.MultilegsDetails[1].legpricetoggle == 'marketlegPrice' ? this.MultilegsDetails[1].selmarketlegPrice : this.MultilegsDetails[1].sellimitlegPrice);
            this.MultilegsDetails[1].legopenclose = false;
            this.MultilegsDetails[1].legbuysell = 'BUY';
            this.MultilegsDetails[1].legpricetoggle = 'marketlegPrice';
            this.MultilegsDetails[1].removeLeg = false;
          }
          else if (this.leg3Edit) {
            this.MultilegsDetails[2].legsymbol = data.data._source.sSymbol;
            this.MultilegsDetails[2].legexpiryDate = data.data._source.nExpiryDate1 == 'NA' ? '' : data.data._source.nExpiryDate1;
            this.MultilegsDetails[2].legexpiryDayIOS = data.data._source.nExpiryDate1.substr(2, 3) + '/' + data.data._source.nExpiryDate1.substr(0, 2) + '/' + data.data._source.nExpiryDate1.substr(-4),
              // this.MultilegsDetails[2].legexpiryDay = this.MultilegsDetails[2].legexpiryDate.substr(0,2);
              // this.MultilegsDetails[2].legexpiryMonth = this.MultilegsDetails[2].legexpiryDate.substr(2,3);
              this.MultilegsDetails[2].legexchangename = data.data._source.sExchange;
            this.MultilegsDetails[2].leginstrumentName = data.data._source.sInstrumentName;
            //this.MultilegsDetails[2].leginstru = this.MultilegsDetails[2].leginstrumentName.substr(0,3);
            this.MultilegsDetails[2].legstrikePrice = (data.data._source.nStrikePrice1 == 'NA' || data.data._source.nStrikePrice1 == undefined) ? '' : data.data._source.nStrikePrice1;
            this.MultilegsDetails[2].legoptionType = data.data._source.sOptionType == 'NA' ? '' : data.data._source.sOptionType;
            this.MultilegsDetails[2].originallegLot = data.data._source.nRegularLot;
            this.MultilegsDetails[2].totallegLot = 1;
            this.MultilegsDetails[2].legmktsegid = clsTradingMethods.GetMarketSegmentID(data.data._source.nMarketSegmentId);
            this.MultilegsDetails[2].legmapmktsegid = data.data._source.nMarketSegmentId;
            this.MultilegsDetails[2].legseries = 'XX';
            this.MultilegsDetails[2].legDecimalLocator = data.data._source.nPriceBdAttribute || 100;
            this.MultilegsDetails[2].legToken = data.data._source.nToken;
            this.MultilegsDetails[2].legpricetick = data.data._source.nPriceTick;
            this.MultilegsDetails[2].selmarketlegPrice = '0.00';
            this.MultilegsDetails[2].sellimitlegPrice = '';
            this.MultilegsDetails[2].legpriceprecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.MultilegsDetails[2].legmktsegid, this.MultilegsDetails[2].legDecimalLocator.toString().length - 1);
            this.MultilegsDetails[2].legprice = (this.MultilegsDetails[2].legpricetoggle == 'marketlegPrice' ? this.MultilegsDetails[2].selmarketlegPrice : this.MultilegsDetails[2].sellimitlegPrice);
            this.MultilegsDetails[2].legopenclose = false;
            this.MultilegsDetails[2].legbuysell = 'BUY';
            this.MultilegsDetails[2].legpricetoggle = 'marketlegPrice';
            this.MultilegsDetails[2].removeLeg = false;
          }
          this.getMarginUtilization();
          // this.MultilegsDetails.sort((a, b) => {
          //   if(a.legexpiryDayIOS == b.legexpiryDayIOS)
          //   {
          //     return parseFloat(a.legstrikePrice == '' ? "0.00" : a.legstrikePrice) > parseFloat(b.legstrikePrice == '' ? "0.00" : b.legstrikePrice) ? 1 : -1;
          //   }
          //   else
          //   {
          //     return a.legexpiryDayIOS > b.legexpiryDayIOS ? 1 : -1;
          //   }
          // })

          // this.MultilegsDetails.sort((a, b) => {
          //   return parseFloat(a.legstrikePrice == '' ? "0.00" : a.legstrikePrice) > parseFloat(b.legstrikePrice == '' ? "0.00" : b.legstrikePrice) ? 1 : -1;
          // })
        }
        if (this.MultilegsDetails.length == 2) {
          if (this.MultilegsDetails[0].legsymbol == this.MultilegsDetails[1].legsymbol) {
            this.disableMain = false;
          }
          else {
            this.disableMain = true;
          }
        }
        else if (this.MultilegsDetails.length == 3) {
          if ((this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[1].legsymbol) && (this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[2].legsymbol)) {
            this.disableMain = false;
          }
          else {
            this.disableMain = true;
          }
        }
        this.selProduct = 'MULTILEGORDER';
        this.leg1Edit = false;
        this.leg2Edit = false;
        this.leg3Edit = false;
        this.sendLegTouchLine();
        this.sendB5Request(OperationType.ADD, this.scripObject);
      })
    })
    // this.paramService.multileg = legsdetails;
    // this.navCtrl.navigateForward('multileg-lookup');
  }

  /** <Norwin Dcruz> <24/04/2021> <Send Touchline for MultiLegs> **/
  sendLegTouchLine() {
    this.localScripKey = [];
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      let objScrpKey: clsScripKey = new clsScripKey();
      objScrpKey.token = this.MultilegsDetails[count].legToken;
      objScrpKey.MktSegId = this.MultilegsDetails[count].legmktsegid;
      this.localScripKey.push(objScrpKey);
    }
    this.sendTouchlineRequest(OperationType.ADD, this.localScripKey);
  }

  addLeg() {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].legopenclose == true) {
        if (this.MultilegsDetails[count].legprice == '') {
          this.toastCtrl.showWithButton("Price must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].sellimitlegPrice) == 0 && this.MultilegsDetails[count].legpricetoggle == 'limitlegPrice') {
          this.toastCtrl.showWithButton("Price cannot be Zero for Limit");
          return;
        }
        if (this.MultilegsDetails[count].totallegLot == '') {
          this.toastCtrl.showWithButton("Lot must be provided");
          return;
        }
        if (parseFloat(this.MultilegsDetails[count].totallegLot) == 0) {
          this.toastCtrl.showWithButton("Lot cannot be Zero");
          return;
        }
        let PriceinPaise = parseInt(Math.round(parseFloat((this.MultilegsDetails[count].legprice * this.MultilegsDetails[count].legDecimalLocator).toString())).toString());

        if (PriceinPaise % parseInt(this.MultilegsDetails[count].legpricetick) != 0) {
          let PriceFormatter = clsTradingMethods.GetPriceFormatter(this.MultilegsDetails[count].legDecimalLocator.toString(), this.MultilegsDetails[count].legmktsegid, this.MultilegsDetails[count].leginstrumentName);
          let PriceTickInRs = (parseFloat(this.MultilegsDetails[count].legpricetick) / this.MultilegsDetails[count].legDecimalLocator).toFixed(PriceFormatter);
          this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTickInRs); //+ clsGlobal.dMsgMaster.getItem("NNSL63"));
          return
        }
      }
    }
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      this.MultilegsDetails[count].legopenclose = false;
    }
    let legsdetails = {
      legdetails: this.MultilegsDetails,
      symbol: this.scripObject.symbol,
      exchange: this.scripObject.ExchangeName
    }
    this.modalCtrl.create({
      component: MultilegLookupPage,
      //cssClass: 'my-custom-class',
      componentProps: {
        'scrip': legsdetails,
      }
    }).then(modal => {
      modal.present().then(data => {

      });
      modal.onDidDismiss().then(data => {
        if (data.data != undefined) {
          let legdetail = {
            legsymbol: data.data._source.sSymbol,
            legexpiryDate: data.data._source.nExpiryDate1 == 'NA' ? '' : data.data._source.nExpiryDate1,
            legexpiryDayIOS: data.data._source.nExpiryDate1.substr(2, 3) + '/' + data.data._source.nExpiryDate1.substr(0, 2) + '/' + data.data._source.nExpiryDate1.substr(-4),
            // this.legexpiryDay : this.legexpiryDate.substr(0,2),
            // this.legexpiryMonth : this.legexpiryDate.substr(2,3),
            legexchangename: data.data._source.sExchange,
            leginstrumentName: data.data._source.sInstrumentName,
            //leginstru : leginstrumentName.substr(0,3),
            legstrikePrice: (data.data._source.nStrikePrice1 == 'NA' || data.data._source.nStrikePrice1 == undefined) ? '' : data.data._source.nStrikePrice1,
            legoptionType: data.data._source.sOptionType == 'NA' ? '' : data.data._source.sOptionType,
            originallegLot: data.data._source.nRegularLot,
            totallegLot : 1,
            legmktsegid: clsTradingMethods.GetMarketSegmentID(data.data._source.nMarketSegmentId),
            legmapmktsegid: data.data._source.nMarketSegmentId,
            legseries: 'XX',
            legDecimalLocator: data.data._source.nPriceBdAttribute || 100,
            legToken: data.data._source.nToken,
            legpricetick: data.data._source.nPriceTick,
            selmarketlegPrice: "0.00",
            sellimitlegPrice: '',
            legpriceprecision: clsGlobal.ExchManager.returnPrecisionForPrice(clsTradingMethods.GetMarketSegmentID(data.data._source.nMarketSegmentId), data.data._source.nPriceBdAttribute.toString().length - 1),
            legprice: "0.00",
            legopenclose: true,
            legbuysell: 'BUY',
            legpricetoggle: 'marketlegPrice',
            removeLeg: false
          }
          this.MultilegsDetails.push(legdetail);
          this.getMarginUtilization();

          // this.MultilegsDetails.sort((a, b) => {
          //   if(a.legexpiryDayIOS == b.legexpiryDayIOS)
          //   {
          //     return parseFloat(a.legstrikePrice == '' ? "0.00" : a.legstrikePrice) > parseFloat(b.legstrikePrice == '' ? "0.00" : b.legstrikePrice) ? 1 : -1;
          //   }
          //   else
          //   {
          //     return a.legexpiryDayIOS > b.legexpiryDayIOS ? 1 : -1;
          //   }
          // })      
        }
        if (this.MultilegsDetails.length == 2) {
          if (this.MultilegsDetails[0].legsymbol == this.MultilegsDetails[1].legsymbol) {
            this.disableMain = false;
          }
          else {
            this.disableMain = true;
          }
        }
        else if (this.MultilegsDetails.length == 3) {
          if ((this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[1].legsymbol) && (this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[2].legsymbol)) {
            this.disableMain = false;
          }
          else {
            this.disableMain = true;
          }
        }
        this.selProduct = 'MULTILEGORDER';
        this.sendLegTouchLine();
        this.sendB5Request(OperationType.ADD, this.scripObject);
      })
    })
  }

  removeLeg() {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      this.MultilegsDetails[count].legopenclose = false;
    }
    this.showRemoveLegPopup = true;
  }

  selectLeg(i) {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (i == count) {
        this.MultilegsDetails[count].removeLeg = !this.MultilegsDetails[count].removeLeg;
      }
      else {
        this.MultilegsDetails[count].removeLeg = false;
      }
    }
  }

  closeRemoveLegPopup() {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      this.MultilegsDetails[count].removeLeg = false;
    }
    this.showRemoveLegPopup = false;
  }

  deleteLeg() {
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if (this.MultilegsDetails[count].removeLeg) {
        this.MultilegsDetails.splice(count, 1);
      }
    }
    this.selProduct = 'MULTILEGORDER';
    if (this.MultilegsDetails.length == 2) {
      if (this.MultilegsDetails[0].legsymbol == this.MultilegsDetails[1].legsymbol) {
        this.disableMain = false;
      }
      else {
        this.disableMain = true;
      }
    }
    else if (this.MultilegsDetails.length == 3) {
      if ((this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[1].legsymbol) && (this.MultilegsDetails[0].legsymbol === this.MultilegsDetails[2].legsymbol)) {
        this.disableMain = false;
      }
      else {
        this.disableMain = true;
      }
    }
    this.sendTouchlineRequest(OperationType.REMOVE, this.localScripKey);
    this.sendLegTouchLine();
    this.getMarginUtilization()
    this.closeRemoveLegPopup();
  }

  getMultiLegFundRequirement() {
    let amount = 0;
    for (let count = 0; count < this.MultilegsDetails.length; count++) {
      if(this.MultilegsDetails[count].legprice != '')
      amount = amount + (parseFloat(this.MultilegsDetails[count].legprice) * (this.MultilegsDetails[count].totallegLot * this.MultilegsDetails[count].originallegLot));
    }
    this.approxamt = amount.toFixed(2);
    return this.approxamt;

  }

  async clickPopover(ev: any, stype) {
    const popover = await this.popoverController.create({
      component: PopoverPage,
      event: ev,
      translucent: true,
      mode: "ios",
      cssClass: 'order-entry-popover',
      backdropDismiss: true,
      componentProps: {
        'type': stype,
      }
    });
    await popover.present();
  }

  showChooseMultiLegValidity() {
    if(this.validityarrayUI.length > 1)
    this.chooseMultiLegValidity = !this.chooseMultiLegValidity;
  }

  setMultilegValidity(validity) {
    this.legvalidity = validity;
    this.showChooseMultiLegValidity();
  }

  setAMOStatus(evet){
    setTimeout(() => {
      this.isAMO = evet.detail.checked;
    }, 0);
  }

  legMultilegDetailsObject(NoOfLegs) {
    try {
      var LegDtls = [];
      for (var i = 0; i < NoOfLegs; i++) {
        var jData_legDtls = {};
        jData_legDtls["LegNo"] = i + 1;
        jData_legDtls["BuyOrSell"] = this.MultilegsDetails[i].legbuysell.toUpperCase() === clsConstants.C_S_ORDER_BUY_TEXT ? 1 : 2;
        jData_legDtls["MarketSegmentId"] = this.MultilegsDetails[i].legmktsegid;
        jData_legDtls["Token"] = this.MultilegsDetails[i].legToken;
        jData_legDtls["Quantity"] = this.MultilegsDetails[i].totallegLot * this.MultilegsDetails[i].originallegLot;
        jData_legDtls["Price"] = this.MultilegsDetails[i].legpricetoggle == 'marketlegPrice' ? parseFloat(this.MultilegsDetails[i].selmarketlegPrice) : parseFloat(this.MultilegsDetails[i].sellimitlegPrice);
        jData_legDtls["MktFlag"] = parseFloat(this.MultilegsDetails[i].legprice) == 0 ? 1 : 0;
        jData_legDtls["OldPrice"] = 0;
        jData_legDtls["OldQuantity"] = 0;
        jData_legDtls["ProductType"] = 'D'//this.SelProduct;
        jData_legDtls["LegIndicator"] = 0;
        jData_legDtls["UserID"] = clsGlobal.User.userId;
        LegDtls.push(jData_legDtls);
      }
      return LegDtls;
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('popup-orderentry', 'LegDetailsObject', 'Exception: ' + e.message);
    }
  }

  lotLostFocus(i){
    if(this.MultilegsDetails[i].totallegLot != '')
    {
      this.getMarginUtilization();
    }
  }

  cancelCoverBracket(){
    this.selProfitOrderPrice = '';
    this.selSLJumpPrice = '';
    this.selMPPrice = '';
    this.selMPTriggerPrice = '';
    this.isBracketDataFilled = false;
    this.isCoverDataFilled = false;
  }

  gotoTransaction() {
    try {
      this.paramService.myParam.mode = 'open';
      this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "gotoTransaction", error);
    }
  }

  closeConfirmation() {
    try {
      this.closePopUp();
    } catch (error) {
      clsGlobal.ConsoleLogging("Error", "closeConfirmation", error);
    }
  }

  fillExchangeSegments() {
    let segmentsAllowed = this.objOEDetail.segmentsAllowed;
    //1:22,8:500410,512:100013
    let arrToken = segmentsAllowed.split(',');
    let arrScrip = [];
    for (let index = 0; index < arrToken.length; index++) {
      let scrip = arrToken[index];
      let mktSegId = clsTradingMethods.GetMarketSegmentID(parseInt(scrip.split(':')[0]));
      let Token = scrip.split(':')[1];
      let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

      arrScrip.push({ "mkt": exchange, "token": Token });
    }
    //this.swExchangeList.push(objScrpKey);
    let req = { scrips: arrScrip };

    clsTradingMethods.getScripInfoElasticSearch(req, this.httpService).then((scripData: any) => {

      if (scripData.status == true) {
        if (scripData != undefined && scripData.result.length > 0) {

          for (let index = 0; index < scripData.result.length; index++) {
            const element = scripData.result[index];
            let selectedScripObj = clsCommonMethods.getScripObject(element).scripDetail;
            if (selectedScripObj != undefined) {
              this.swExchangeList.push(selectedScripObj);
            }
          }
        }
      }

    }, error => {
      this.toastCtrl.showAtBottom("Unable to fetch exchange scrip details.");
    });

  }

  toggleHoldingExchange(scrip) {
    try {
      this.showExchangeAction = !this.showExchangeAction;

      this.sendB5Request(OperationType.REMOVE, this.scripObject);

      this.isCoverAllowed = false;
      this.isBracketAllowed = false;
      this.scripObject = scrip;
      this.sendB5Request(OperationType.ADD, this.scripObject);
      this.selMarketLot = this.scripObject.MarketLot;
      this.selExchange = this.objOEDetail.scripDetl.ExchangeName;
      this.selProduct = this.objOEDetail.productType;

      this.onExchangeChange();
      this.selInstrument = this.scripObject.InstrumentName;;
      this.onInstrumentChange();

      this.selDecimalloc = parseInt(this.scripObject.DecimalLocator);
      if (isNaN((this.selDecimalloc)))
        this.selDecimalloc = 100;
      this.pricePrecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.selDecimalloc.toString().length - 1);


      this.selSeries = this.scripObject.Series;
      this.selExpire = this.scripObject.ExpiryDate;
      this.selStrikePrice = this.scripObject.StrikePrice;
      this.selOptionType = this.scripObject.OptionType == '' ? 'NA' : this.scripObject.OptionType;

      this.deliveryPriceTab = 'marketPrice';
      this.selOrderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
      this.onScrollChanged.next(this.selQty);

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('PopupOrderEntry', 'toggleHoldingExchange', error);
    }
  }

}
