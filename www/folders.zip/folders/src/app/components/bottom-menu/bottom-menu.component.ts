import { Component, OnInit, Input } from '@angular/core';
import { NavController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';

@Component({
  selector: 'app-bottom-menu',
  templateUrl: './bottom-menu.component.html'
})
export class BottomMenuComponent implements OnInit {

  index: number = 1;

  @Input() activeIndex: number;
  constructor(private navCtrl: NavController, private aletobj: AlertServicesProvider) { }

  ngOnInit() {
    try {
      this.index = this.activeIndex;
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("bottom-menu", "ngOnInit", error.message);
    }
  }
  clickEventHandler(event: number) {
    try {
      //this.aletobj.showAlert("clickEventHandler"+event);
      if ((clsGlobal.User.isGuestUser && event != 1) && (clsGlobal.User.isGuestUser && event != 2)) {
        let buttons: any = ["Login", "Skip"];
        this.aletobj.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
          () => {
            //success navigate to login screen 
            this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
          }, () => {
            //fail No or cancel click //do nothing.
          });
        return;
      }
      if (event == 1) {
        this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
      }
      else if (event == 2) {
        this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_MARKETMAIN);
      }
      else if (event == 3) {
        this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_TRANSACTION);
      }
      if (event == 4) {
        this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_PORTFOLIO);
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("bottom-menu", "clickEventHandler", error.message);
    }
  }
  showLookUp() {
    try {
      this.navCtrl.navigateForward('/lookup');
      //this.navCtrl.navigateForward('/scrip-lookup');
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("bottom-menu", "showLookUp", error.message);
    }
  }

}
