import { Component, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';

/**
 * Generated class for the Ionic3PincodeInputComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'pin-code',
  // templateUrl: './ionic3-pincode-input.html'
  template: `<ion-grid class="ion-no-padding pinCodeGrid">
                <form [formGroup]='pinCodeFormGroup'>
                <ion-row class="m-t-10 login-form-wrap">  
                        <ion-col class="ion-no-padding" *ngFor="let controlItem of this.pinCodeArray;let i = index;let last=last">
                        <ion-list lines="none" class="ion-no-padding ion-no-margin mpin-textbox">
                        <ion-item class="ion-no-margin ion-no-padding input-wrap ion-text-center">  
                        <input id="{{controlItem}}" autocomplete="off"  numericDir  maxlength="1" class="pinCodeInput ion-no-padding" [ngClass]="selectorClass" type="tel"  formControlName="{{controlItem}}"   (keyup)="onKeyUp($event,controlItem, i)" (keydown)="onKeyDown($event)"/>
                        </ion-item>
                        </ion-list>
                        </ion-col>
                    </ion-row>
                </form>
             </ion-grid>`, 
  styleUrls: ['./ionic3-pincode-input.scss'],
})
export class Ionic3PincodeInputComponent {

  public pinCodeArray: any[];
  public pinCodeFormGroup: FormGroup;

  @Input() name: string;
  @Input() selectorClass: string;
  @Input() color: string;
  @Input() isHidden: boolean = false;
  @Input() codeSize: number = 4;
  @Output() onComplete = new EventEmitter<string>();

  constructor() {
    this.initiateBuilder();
  }

  ngOnChanges(changes: SimpleChanges) {
    let stylebody = document.body.style;
    if (changes.color != undefined) {
      stylebody.setProperty('--borderColor', changes.color.currentValue);
    }
    if (changes.isHidden != undefined) {
      if (changes.isHidden.currentValue == false) {
        stylebody.setProperty('--charShape', 'none');
      } else {
        stylebody.setProperty('--charShape', 'disc');
      }
    }

    this.initiateBuilder();

  }

  initiateBuilder() {
    this.pinCodeFormGroup = new FormGroup({});

    for (let i = 0; i < this.codeSize; i++) {
      let formController: FormControl = new FormControl({ value: '', disabled: true }, [Validators.required]);
      this.pinCodeFormGroup.addControl('codeFiled' + this.name + i, formController);
    }

    let v_pinCodeArray: any[] = [];
    Object.keys(this.pinCodeFormGroup.value).forEach(function (key) {
      v_pinCodeArray.push(key);
    });

    this.pinCodeArray = v_pinCodeArray;
    this.pinCodeFormGroup.get('codeFiled' + this.name + '0').enable();
  }
  ngAfterViewInit() {
    let input: HTMLElement = document.querySelectorAll('.pinCodeInput').item(0) as HTMLElement;
    input.focus();
  }


  onKeyUp($event: any, item: any, index: any) {
    let v_index;

    let reg = new RegExp("[0-9]");

    if ($event.key == "Backspace") {
      if (index == 0) {
        v_index = 0;
      } else {
        v_index = index - 1;
        this.pinCodeFormGroup.get('codeFiled' + this.name + index).disable();
      }


    } else {
      if (reg.test($event.target.value)) {

        if (index == this.codeSize - 1) {
          v_index = this.codeSize - 1;
        } else {
          v_index = index + 1;
          this.pinCodeFormGroup.get('codeFiled' + this.name + v_index).enable();

        }
      }else{
        $event.target.value ='';
      }
    }


    let input: HTMLElement = document.querySelectorAll('.' + this.selectorClass).item(v_index) as HTMLElement; //document.getElementById($event.currentTarget.id) as HTMLElement;//
    input.focus();


    let pinCodeValue: string = '';
    // Object.keys(this.pinCodeFormGroup.value).forEach((key) => {
    //   pinCodeValue += this.pinCodeFormGroup.value[key];
    // });
    let inputElem: any = document.querySelectorAll('.' + this.selectorClass);
    for (let index = 0; index < inputElem.length; index++) {
      const element = inputElem[index];
      pinCodeValue += element.value;
    }
    this.onComplete.emit(pinCodeValue)

    /*
    if (index == this.codeSize - 1 && $event.key != "Backspace") {

      if (this.pinCodeFormGroup.valid) {
        this.onComplete.emit(pinCodeValue)
      } else {

      }
    }
    */

  }


  onKeyDown($event: any) {
    if ($event.key != "Backspace") {

      if ($event.target.value.length == 1) {
        return false;
      }

    }
  }




}
