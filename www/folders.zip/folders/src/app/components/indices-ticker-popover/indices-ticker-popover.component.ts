import { Component, OnInit } from '@angular/core';
import { NavParams, PopoverController } from '@ionic/angular';
import { clsConstants, OperationType } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsMultiTouchLineRequest } from 'src/app/communicator/clsMultiTouchLineRequest';

@Component({
  selector: 'app-indices-ticker-popover',
  templateUrl: './indices-ticker-popover.component.html'
})
export class IndicesTickerPopoverComponent implements OnInit {

  showIndicesSelection: boolean = false;
  showtickerCard: boolean = true;
  showtickerSetting: boolean = false;
  showSelectpopup: boolean = false;
  selIndicesList = [];
  allIndicesList = [];
  allExchange = [];
  selIndice: any = {};
  selExchange = '';
  selIndex = -1;
  exchIndicesList = [];
  showExchange: boolean = false;

  constructor(public popoverController: PopoverController,
    private localstorageservice: clsLocalStorageService,
    public navParam: NavParams) {
    this.selIndicesList = this.navParam.get("selIndices") || [];
    this.allIndicesList = this.navParam.get("allIndices") || [];
    this.allExchange = this.navParam.get("exchanges") || [];
  }

  ngOnInit() { }

  marketTickerFull() {
    this.showtickerSetting = false;
    this.showIndicesSelection = true;
  }

  showTickerSetting() {
    this.showtickerCard = false;
    this.popoverController.dismiss({showtickerSetting:true});
  }

  closeTickerSetting() {
    this.showIndicesSelection = false;
    this.showtickerSetting = false;
    this.showtickerCard = true;
  }

  marketTickerClose() {
    this.showIndicesSelection = false;
    this.showtickerSetting = true;
    this.showtickerCard = false;
  }

  changeTickerScrip(idxItem, index) {
    try {

      this.showIndicesSelection = true;
      this.showtickerSetting = false;
      this.showtickerCard = false;
      this.selIndice = idxItem;
      this.selIndex = index;
      this.selExchange = this.selIndice.Exchange;
      this.exchIndicesList = this.allIndicesList.filter(itemIndex => {
        return itemIndex.Exchange = idxItem.Exchange;
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'changeTickerScrip', error);
    }
  }

  showExchangePopUp() {

    this.showExchange = !this.showExchange;
  }

  toggleExchange(sExchange) {
    try {
      this.showExchange = !this.showExchange;

      if (this.selExchange != sExchange) {
        this.selExchange = sExchange;
        this.exchIndicesList = this.allIndicesList.filter(itemIndex => {
          return itemIndex.Exchange = sExchange;
        });
      }

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'toggleExchange', error);
    }
  }

  setSelectedIndices(item) {
    try {

      let itemIdx = this.selIndicesList[this.selIndex];

      if (itemIdx.sIndexDesc != item.sIndexDesc) {
        this.selIndicesList[this.selIndex] = item;

        let objScrpKey: clsScripKey = new clsScripKey();
        objScrpKey.token = itemIdx.nToken;
        objScrpKey.MktSegId = itemIdx.nMarketSegmentId;
        this.sendTouchlineRequest(OperationType.REMOVE, objScrpKey);

        objScrpKey.token = item.nToken;
        objScrpKey.MktSegId = item.nMarketSegmentId;
        this.sendTouchlineRequest(OperationType.ADD, objScrpKey);

        let keyIndices = clsGlobal.User.userId + "_" + clsConstants.LOCAL_STORAGE_INDICES_TICKER;
        this.localstorageservice.setObject(keyIndices,JSON.stringify(this.selIndicesList));
        
      }

      this.marketTickerClose();

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('indicetickerpopover', 'setSelectedIndices', error);
    }
  }


  /**
   * send request for broadcast
   * @param opType
   * @param scripList
   */
  sendTouchlineRequest(opType: OperationType, scrip: any) {
    try {

      if (scrip != null) {
        let objTLReq = new clsMultiTouchLineRequest();
        objTLReq.OperationType = opType;
        objTLReq.ScripList.push(scrip);
        clsGlobal.pubsub.publish('MTLREQ', objTLReq);
      }
    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('IndiceTicker', 'sendTouchlineRequest', error);
    }
  }


}
