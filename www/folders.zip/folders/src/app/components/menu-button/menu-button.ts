import { Component, Output, EventEmitter } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsLocalStorageService } from '../../Common/clsLocalStorageService';
import { clsConstants } from '../../Common/clsConstants';
//import { SecondmenuPage } from 'src/app/pages/secondmenu/secondmenu';

@Component({
  selector: 'menu-button',
  templateUrl: 'menu-button.html'
})

export class MenuButtonComponent {
  isGuest: boolean = true;
  @Output() onMenuSwipeUp = new EventEmitter();
  modalMenu: any;

  constructor(private navCtrl: NavController,
    public clsLocalStorage: clsLocalStorageService,
    public modalCtrl: ModalController) {
    setTimeout(() => {
      this.clsLocalStorage.getItem('isLoggedInUser').then((res: any) => {
        if (res != null) {
          if (JSON.parse(res).Type == clsConstants.EXISTING_REG_USER || JSON.parse(res).Type == clsConstants.REGISTERED_USER) {
            this.isGuest = false;
          }
          else {
            this.isGuest = true;
          }
        }
      });
    }, 500);

    clsGlobal.pubsub.subscribe('SESSIONEXPIRE', (data: any) => {
      if (this.modalMenu != undefined) {
        this.modalMenu.dismiss();
      }
      this.modalMenu = undefined;
    })

    clsGlobal.pubsub.subscribe('SESSIONEXPIRE_GATEWAY', (data: any) => {
      if (this.modalMenu != undefined) {
        this.modalMenu.dismiss(); 
      }
      this.modalMenu = undefined;
    })
  }

  async showMenu() {

    // const modalMenu = await this.modalCtrl.create({
    //   component: SecondmenuPage,
    //   //componentProps: { data: this.myPortfolioOnePlaceAPI },
    //   cssClass: clsGlobal.defaultTheme
    // });
    // await modalMenu.present();
    
    //this.navCtrl.push(SecondmenuPage, {}, { duration: 1000, direction: "forward", easing: "fade-in", animation: "md-transition", animate: true });
  }


  swipeCapture(event) {
    try {
      this.navCtrl.navigateForward('/' + clsConstants.C_S_PAGE_ROUTE_TRANSACTION);  
    } catch (error) {
      
    }
  }
  showSearch() {
    try {
      this.navCtrl.navigateForward('LookUpPage').then(() => {
        //this.navCtrl.remove(currentIndex);
      });

    } catch (error) {

    }
  }
  isKeyBoardOpen() {
    return clsGlobal.isKeyBoardOpen;
  }
}
