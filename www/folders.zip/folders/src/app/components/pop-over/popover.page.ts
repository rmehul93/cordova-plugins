import { Component, OnInit } from '@angular/core';
import { NavParams, PopoverController } from '@ionic/angular';
//import { PopoversComponent } from '../popovers/popovers.component'; 

@Component({
  selector: 'app-popover',
  templateUrl: './popover.page.html',
  //styleUrls: ['./popover.page.scss'],
})
export class PopoverPage implements OnInit {

  evType = 0;

  constructor(public popoverController: PopoverController,
    public navParam: NavParams) {

      let _evType=this.navParam.get("type")|| 0;
    this.evType = parseInt(_evType);
  }

  ngOnInit() {
  }

  gotItClick() {
    this.popoverController.dismiss(this.evType)
  }

  eventGotItClick() {
    this.popoverController.dismiss(this.evType)
  }

}
