import { clsAppConfigConstants } from './../../Common/clsAppConfigConstants';
import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NavController, MenuController } from '@ionic/angular';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal, clsPluginConstants } from 'src/app/Common/clsGlobal';
import { clsLocalStorageService } from 'src/app/Common/clsLocalStorageService';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { AuthenticationService } from 'src/app/providers/authentication.service';
import { BrowserServicesProvider } from 'src/app/providers/browser-services/browser-services';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { AppState } from 'src/app/app.global';
import { AppsyncDbService } from 'src/app/providers/appsync-db.service';
import { clsCommunicatorProvider } from 'src/app/communicator/clsCommunicatorProvider';
@Component({
  selector: 'app-hemberg-menu',
  templateUrl: './hemberg-menu.component.html',
})
export class HembergMenuComponent implements OnInit {
  //@Input("refereshData") objReferesh: any; //script objcet to create order entry.

  userName: string = "";
  userId: string = "";
  userInitials: string = "";
  totalPurchasingPower = "0.00";
  lastLogin: any = "";
  versionNo: any = "";
  needHelpData = [];
  currentTheme: any;
  isGuestUser: boolean = false;
  showBrokerPopUp: boolean = false;
  phoneNoCC: string = "";//to store customer Care
  phoneNoTEC: string = "";//to store Technical Help No
  contactEmail: string = ""; // Email Id od customer care
  activeAlertsCount: any = 0;
  amount: any;
  profilePic: any = "";
  showSSoMenu: boolean = false;
  showInviteMenu: boolean = false;
  showLinksMenu: boolean = false;
  promotionalData: any = [];
  showEDISMenu: boolean = false;
  fontSize = 'Regular';

  constructor(private alertProvider: AlertServicesProvider,
    private navCtrl: NavController,
    private navParams: NavParamService,
    private authservice: AuthenticationService,
    private localstorageservice: clsLocalStorageService,
    private menuCtrl: MenuController,
    private iab: BrowserServicesProvider,
    public http: HttpClient,
    private appSync: AppsyncDbService,
    public global: AppState,
    public ioa: BrowserServicesProvider,
    private commService: clsCommunicatorProvider
  ) { }

  ngOnInit() {
    console.log("hembergMenu");
    clsGlobal.pubsub.subscribe('MENU_SHOW_HIDE', (res: any) => {
      this.showHideMenu();
    });
    clsGlobal.pubsub.subscribe('MENU_DYNAMIC', (res: any) => {
      this.updateDynamicContent();
      //const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH) + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId + clsGlobal.versionId + '/' + "helpQuestion.json";
      //change for cloud front hosting.
      const url = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CDN_BASE_PATH)  + clsGlobal.LocalComId + clsGlobal.versionId + '/' + "helpQuestion.json";
      this.http.get(url).subscribe((res: any) => {
        this.needHelpData = res.NeedHelp;
        //console.log(this.needHelpData)
      },
        (err) => {
          console.log('failed loading help json data' + err);
        });
    });

    clsGlobal.pubsub.subscribe('MENU_THEME', (res: any) => {
      this.updateTheme();
    });
    clsGlobal.pubsub.subscribe('MENU_PROFILE', (res: any) => {
      this.updateProfile();
    });
    clsGlobal.pubsub.subscribe('MENU_FONT_ZOOM', (res: any) => {
      this.updateFontPreference();
    });
    //setInterval(() => this.showHideMenu(), 5000);
    // setInterval(() => this.updateDynamicContent(), 5000);
    //setInterval(() => this.updateTheme(), 1000);
    // setInterval(() => this.updateProfile(), 5000);

    
    
  }

  showHideMenu() {
    try {
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_SSO) != undefined &&
        (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_SSO).toString().trim().toUpperCase() == "TRUE"
          || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_SSO).toString().trim().toUpperCase() == "ON"
        )) {
        this.showSSoMenu = true;
      }
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_LINKS) != undefined &&
        (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_LINKS).toString().trim().toUpperCase() == "TRUE"
          || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_LINKS).toString().trim().toUpperCase() == "ON")) {
        this.showLinksMenu = true;
      }
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_INVITE_FRIENDS) != undefined &&
        (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_INVITE_FRIENDS).toString().trim().toUpperCase() == "TRUE"
          || clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SHOW_INVITE_FRIENDS).toString().trim().toUpperCase() == "ON"
        )) {
        this.showInviteMenu = true;
      }


    } catch (error) {
      clsGlobal.logManager.writeErrorLog('HembergMenuComponent', 'showHideMenu', error);
    }
  }

  updateProfile() {
    // Getting Profile picture from AppSync
    if (clsGlobal.User.userPreference != undefined && clsGlobal.User.userPreference != null) {
      this.profilePic = clsGlobal.User.userPreference?.sProfilePicPath;
      this.localstorageservice.setItem("PROFILE_PICTURE", this.profilePic);
    } else {
      // Getting Profile pic path from local storage
      this.localstorageservice.getItem("PROFILE_PICTURE").then((res: any) => {
        if (res != undefined && res != null) {
          this.profilePic = res;
        }
      }).catch(err => {
        console.log("Error in getting profile from local storage")
      })
    }

  }

  updateTheme() {
    this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_THEME)
      .then((item: any) => {
        if (item != undefined && item != 'undefined') {
          //const theme: any = JSON.parse(item);
          this.currentTheme = item;
        } else {
          this.currentTheme = clsGlobal.defaultTheme;
        }
      }, error => {
        console.log('Error in getting local storage theme.');
      });
  }
  updateDynamicContent() {
    let _PromoData = clsGlobal.dConfigMaster.getItem("APP_PROMOTIONAL_DATA");
    if (_PromoData != undefined)
      this.promotionalData = JSON.parse(_PromoData);

    this.userName = clsGlobal.User.userName;
    this.userId = clsGlobal.User.userId
    this.lastLogin = clsGlobal.User.lastLoginTime;
    this.versionNo = clsPluginConstants.AppVersion;
    this.isGuestUser = clsGlobal.User.isGuestUser;
    if (clsGlobal.User.isGuestUser) {
      this.userInitials = this.userId.split(/\s/).reduce((resp, word) => resp += word.slice(0, 1), '');
    } else {
      let userAcronym = this.userName.split(/\s/).reduce((resp, word) => resp += word.slice(0, 1), '');
      this.userInitials = userAcronym.toUpperCase();
    }
    this.kFormatter(parseInt((clsGlobal.User.totalBuyingPower || 0).toString().trim()));
    if (clsGlobal.isNewScripAlert) {
      this.activeAlertsCount = clsGlobal.scripAlertsList.filter((alert) => { return alert.triggered != 0 }).length;
    } else {
      this.activeAlertsCount = 0;
    }

    if (!clsGlobal.IsGuestUser) {
      this.showEDISMenu = true;
      if (clsGlobal.User.POAStatus == true || (clsGlobal.User.DPDetails[0] != undefined &&
        clsGlobal.User.DPDetails[0].sDepository == clsConstants.C_S_EDIS_ODRREQ_DEPOSITORY_NSDL)) {
        this.showEDISMenu = false;
      }
    }

  }

  openUrl(url) {
    try {
      this.ioa.openBrowser('', url, 1);
    } catch (error) {

    }
  }
  //Method to display Value in Thousand and cr format.
  kFormatter(num) {
    try {
      let digits = 1;

      var si = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E5, symbol: "Lac" },
        { value: 1E7, symbol: "Cr." },
        { value: 1E12, symbol: "T" },
        { value: 1E15, symbol: "P" },
        { value: 1E18, symbol: "E" }
      ];
      var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
      var i;
      for (i = si.length - 1; i > 0; i--) {
        if (num >= si[i].value) {
          break;
        }
      }
      this.totalPurchasingPower = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
    } catch (error) {
      console.log("Hemberg Menu ..Errror in number to text conversion." + error);
      this.totalPurchasingPower = "0.00";
    }
  }
  //handling of all menu click on 
  showProfile() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/profile');
  }

  showRecommendation() {
    // if (!this.checkGuestMode()) 
      this.navCtrl.navigateForward('/recommendation');
  }
  showLinks() {
    this.navCtrl.navigateForward('/links');
  }

  showSsoLinks() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/sso-links');
  }

  showSettings() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/settings');
  }

  showInviteFriend() {
    // if (!this.checkGuestMode()) 
      this.navCtrl.navigateForward('/invitefriends');
  }

  showHelp(index) {
    let selectedData = {
      selectedQ: index,
      helpData: this.needHelpData
    };
    this.menuCtrl.close();
    this.navParams.myParam = selectedData;
    this.navCtrl.navigateForward('needhelp');
  }

  /**
   * @method Navigate to Messages Page
   */
  showMessage() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/messages');
  }

  /**
   * @method Navigate to Calculators Page
   */
  showCalculators() {
    this.navCtrl.navigateForward('/calculators-main');
  }

  /**
   * @method Logout from the Application
   */
  doLogOut() {
    try {
      this.alertProvider.showAlertWithCallback("Are you sure you want to logout?", "Wave 2").then
        (success => {
          if (success == true) {
            //logout
            this.authservice.logout().then(response => {
              console.log("Response " + response);
            }).catch(error => {
              //
              console.log("Rsponse " + error);
            });
            clsGlobal.watchlistSyncDone = false;
            this.appSync.signOutCognito(clsGlobal.User.userName);
            this.appSync.signingCognito(clsGlobal.ComId, clsGlobal.ComId, "admin@" + clsGlobal.ComId);
            this.commService.disConnectBroadcast();
            //this.navCtrl.navigateRoot('signin');
            this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
              .then((item: any) => {
                if (item != undefined && item != 'undefined') {
                  const objMPIN: any = JSON.parse(item);
                  let showMpin: boolean = false;
                  clsGlobal.ClearGlobalObjects();
                  if (objMPIN.MPINEnable == 'Y' || objMPIN.Fingerprint == 'Y') {
                    //this.initializeBcastSocket(JSON.parse(res).userUniqueId);
                    this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_MPIN);

                  } else {
                    this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_LOGIN);

                  }
                } else {
                  this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
                }
              }, error => {
                console.log('Error in getting MPINDetails.');
              });
          }
        });
    } catch (error) {
      console.log("Error in Logout." + error);
    }
  }
  showTestPage() {
    this.navCtrl.navigateForward('/testpage');
  }

  /**
   * @method Navigate to funds main page
   */
  showFundsMain() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/fundsmain');
  }

  /**
   * @method close Hemberger Menu and navigate to add funds page
   */
  showAddFunds() {
    if (!this.checkGuestMode()) // if guest then return true.
    {
      if (this.validateAddFunds()) {
        this.navParams.myParam = this.amount;
        this.navCtrl.navigateForward('/fundsadd');
        this.amount = '';
      }
    }
  }
  validateAddFunds() {
    try {
      if (this.amount == '' || this.amount == 0 || this.amount == undefined) {
        this.alertProvider.showAlert("Fund transfer amount cannot be 0. Please try again with a different value!");
        return false;
      }
      var regex = new RegExp("^[0-9]+$");
      if (!regex.test(this.amount)) {
        this.alertProvider.showAlert("Special Characters are not allowed in Add Funds");
        return false;
      }
      this.menuCtrl.close();
      return true;

    }
    catch (error) {
      clsGlobal.logManager.writeErrorLog('hemberg-menu', 'validateAddFunds', error);
    }

  }
  /**
   * @method Get User entered amount
   * @param event : event object to get amount value
   */
  getUserAmount(event) {
    this.amount = event.target.value.trim();
  }

  /**
   * @method Close Hemberger Menu on click of cross icon
   */
  closeMenu() {
    this.menuCtrl.close();
    this.amount = '';
  }

  openAccountLink() {
    let link = "https://www.google.com";
    this.iab.openBrowser("form", link, 1);
  }


  /**
   * @method Theme change to light or dark
   * @param event Event object to get current theme value
   */
  ThemeToggleChangeMenu(event) {
    try {
      console.log(this.currentTheme);
      let isChecked: boolean = false;
      if (event.detail.value == 'light') {
        this.currentTheme = 'light';
        clsGlobal.defaultTheme = this.currentTheme;
        isChecked = false;
      }
      else {
        this.currentTheme = 'dark';
        clsGlobal.defaultTheme = this.currentTheme;
        isChecked = true;
      }
      this.global.set(clsConstants.LOCAL_STORAGE_THEME, this.currentTheme);
      this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_THEME, this.currentTheme);
      const toggle = document.querySelector('#themeToggle');
      document.body.classList.toggle('dark', isChecked);
      clsGlobal.logManager.writeUserAnalytics("HembergMenuComponent", "", "themeChanged", clsGlobal.defaultTheme);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog("HembergMenuComponent", "themeChanged", error);
    }

  }

  /**
   * @method Open up contact broker pop up
   */
  showContactBrokerPopUp() {
    this.showBrokerPopUp = !this.showBrokerPopUp;
    try {
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CUSTOMER_CARE).toString().length > 0) {
        this.phoneNoCC = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CUSTOMER_CARE);
      }
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_TECHNICAL_CARE).toString().length > 0) {
        this.phoneNoTEC = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_TECHNICAL_CARE);
      }
      if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CONTACT_EMAIL).toString().length > 0) {
        this.contactEmail = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_CONTACT_EMAIL);
      }
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('HembergMenuComponent', 'showContactBrokerPopUp', error);
    }
  }

  /**
   * @method Close Contact Broker PopUp on click of cross icon
   */
  cancelBrokerPopUp() {
    this.showBrokerPopUp = !this.showBrokerPopUp
  }

  /**
   * @method : Opens Up Phone dialer in mobile phone
   * @param telno : Telephone number of customer care
   */
  showPhoneDialer(telno: any) {
    window.open("tel:" + telno);
  }

  /**
  * @method : Opens Up Email PopUp in mobile phone
  * @param telno : Email Id of Client
  */
  showEmail() {
    window.open("mailTo:" + this.contactEmail);
  }

  //This method will return guest mode status.
  checkGuestMode() {
    if (clsGlobal.User.isGuestUser) {
      let buttons: any = ["Login", "Skip"];
      this.alertProvider.showAlertConfirmWithButtons("Sorry", "Register or Login to access this feature.", buttons,
        () => {
          //success navigate to login screen 
          this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
        }, () => {
          //fail No or cancel click //do nothing.
        });
      return true;
    }
    else {
      return false;
    }
  }

  showEDISPermission() {
    if (!this.checkGuestMode()) // if guest then return true.
      this.navCtrl.navigateForward('/e-dis-permission');
  }
  increaseFontSize() {
    const getZoomBody = document.getElementsByTagName('body')[0].style.zoom;
    if (getZoomBody == "1.1") {
      //already increased
    }
    else {
      let newValue = parseFloat(getZoomBody) + 0.1;
      document.getElementsByTagName('body')[0].style.zoom = newValue.toString();
    }
    this.setFontPreference('Large');
    // var scale = 'scale(1.05)';
    // document.body.style.webkitTransform =  scale;    // Chrome, Opera, Safari
    // document.body.style.msTransform =   scale;       // IE 9
    // document.body.style.transform = scale;     // General
  }
  regularFontSize() {
    let newValue = parseFloat("1");
    document.getElementsByTagName('body')[0].style.zoom = newValue.toString();
    this.setFontPreference('Regular');
    // const getZoomBody = document.getElementsByTagName('body')[0].style.zoom;
    // if(parseFloat(getZoomBody) !== 1.00) {
    //   let newValue = parseFloat(getZoomBody) - 0.05;
    //   document.getElementsByTagName('body')[0].style.zoom =  newValue.toString();
    // } else {
    //   alert('Set to Reset')
    // } 
    // var scale = 'scale(1)';
    // document.body.style.webkitTransform =  scale;    // Chrome, Opera, Safari
    // document.body.style.msTransform =   scale;       // IE 9
    // document.body.style.transform = scale;     // General
  }

  setFontPreference(fontType) {
    try {
      this.fontSize = fontType;
      this.localstorageservice.setItem("FONT_ZOOM", this.fontSize);
    } catch (error) {
      console.log("Error in saving Font preference in local storage");
    }
  }

  updateFontPreference() {
    this.localstorageservice.getItem("FONT_ZOOM").then((res: any) => {
      if (res != undefined && res != null) {
        this.fontSize = res;
        if (this.fontSize == 'Large') {
          const getZoomBody = document.getElementsByTagName('body')[0].style.zoom;
          if (getZoomBody == "1.1") {
            //already increased
          }
          else {
            let newValue = parseFloat(getZoomBody) + 0.1;
            document.getElementsByTagName('body')[0].style.zoom = newValue.toString();
          }
        }
      } else {

      }
    }).catch(err => {
      console.log("Error in getting Font preference from local storage");
    })
  }
}
