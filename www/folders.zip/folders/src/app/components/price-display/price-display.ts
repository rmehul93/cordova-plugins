import { Component, Input } from '@angular/core';

/**
 * Generated class for the PriceDisplayComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'price-display',
  templateUrl: 'price-display.html'
})
export class PriceDisplayComponent {

  @Input('price') inputPrice :any;
  @Input('largeFont') fontLarge :any ="";//font-size18
  @Input('smallFont') fontSmall :any  ="";//font-size12

  priceLeft:string="";
  priceRight:string="";
  
  constructor() {
    //console.log('Hello PriceDisplayComponent Component');
    //this.inputPrice.
  }

}
