import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { clsScrip } from 'src/app/Common/clsScrip';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { Platform, PopoverController, ModalController, NavController } from '@ionic/angular';
import { OperationType, clsConstants } from 'src/app/Common/clsConstants';
import { clsBestFiveRequest } from 'src/app/communicator/clsBestFiveRequest';
import { clsBestFiveResponse } from 'src/app/communicator/clsBestFiveResponse';
import { PopoverPage } from '../pop-over/popover.page';
import { ToastServicesProvider } from 'src/app/providers/toast-services/toast.services';
import { MultilegConfirmationPage } from 'src/app/pages/multileg-confirmation/multileg-confirmation.page';
import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import * as moment from 'moment';
import { TransactionService } from 'src/app/providers/transaction.service';
import { NavParamService } from 'src/app/providers/nav-param.service';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { AlertServicesProvider } from 'src/app/providers/alert-services/alert-services';
import { clsIndexDetail } from 'src/app/Common/clsIndexDetails';
import { clsScripKey } from 'src/app/Common/clsScripKey';

@Component({
  selector: 'app-spread-order-entry',
  templateUrl: './spread-order-entry.component.html'
})
export class SpreadOrderEntryComponent implements OnInit {

  @Input("Spreadorder") objOE: any; //script object to create spread order entry.
  @Output() messageEvent = new EventEmitter<object>();//used to emit event for popup close.
  scripObject: clsScrip;
  spreadDetails : any = [];
  numberortell: any;
  approximateMargin: any = 0;
  availableMargin: any = 0;
  approxamt : any = 0;
  totalLot : any = 1;
  originalspreadLot : any = '';
  leg1Expiry : any = '';
  leg2Expiry : any = '';
  segmenttoggle : any;
  bcastB5Handler: any;
  LTP: any = "0.00";
  NetChangeInRs = "0.00";
  PercNetChange = "(0.00)";
  LTPTrend = "";
  B5Data = [];
  showMarketDepth = false;
  totalBuyQty: any;
  totalSellQty: any;
  totalBidQtyPer: any = "-";
  totalAskQtyPer: any = "-";
  limitprice : any = '';
  leg1buysell : any;
  leg2buysell : any;
  validityarray : any = [];
  spreadValidity : any;
  arrValidityUI : any = [];
  showChooseValidity: boolean = false;
  objOEDetail: clsOEFormDetl;
  bIsMarginReqInProcess =false;
  modifyFlag: boolean = false;
  legLTP : any = '0.00';
  prevSelQuantity: any = 0;
  prevSelPrice: any = '';
  selDecimalloc = 100;
  priceprecision : any = 2;
  fundFlag : boolean = false;
  shortFall : any = 0;
  symbol : any;
  showMarginLoader : boolean = false;
  exchange : any;
  instrument : any;

  constructor(
    private httpService: clsHttpService,
    public platform: Platform,
    public popoverController: PopoverController,
    public modalCtrl: ModalController,
    private toastCtrl: ToastServicesProvider,
    private tranService: TransactionService,
    private paramService: NavParamService,
    private navCtrl: NavController,
    private alertCtrl: AlertServicesProvider,
  ) { }

  async ngOnInit() {
    this.objOEDetail = this.objOE;
    this.scripObject = this.objOEDetail.scripDetl;
    this.symbol = this.scripObject.symbol;
    this.exchange = this.scripObject.ExchangeName;
    this.instrument = this.scripObject.InstrumentName;
    this.bcastB5Handler = this.receiveBestFiveResponse.bind(this);
    clsGlobal.pubsub.subscribe('B5RES', this.bcastB5Handler);
    if (this.platform.is('android')) {
      this.numberortell = 'tel';
    }
    else {
      this.numberortell = 'number';
    }
    //this.availableFunds = this.kFormatter(clsGlobal.User.totalBuyingPower);
    this.originalspreadLot = this.scripObject.MarketLot;
    //this.sendB5Request(OperationType.ADD, this.scripObject);
    this.validityarray = (clsGlobal.ExchManager.populateValidityForSpread(this.scripObject.scripDet.MapMktSegId, 1));
    for (let index = 0; index < this.validityarray.length; index++) {
      const element = this.validityarray[index];
      let itemValidityType: any = {};
      //itemValidityType.isChecked = (this.validityarray == element) ? true : false;
      itemValidityType.value = element;
      itemValidityType.desc = clsTradingMethods.getValidityTypeDescription(element);
      this.arrValidityUI.push(itemValidityType);
    }
    this.selDecimalloc = parseInt(this.scripObject.DecimalLocator);
    if (isNaN((this.selDecimalloc)))
      this.selDecimalloc = 100;
    this.priceprecision = clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.selDecimalloc.toString().length - 1);
    if(this.objOEDetail.gwOrderNo == '')
    {
      this.spreadValidity = this.validityarray[0];
      this.segmenttoggle = 'MARKET';
      this.leg1buysell = this.objOE.buySell == 1 ? 'Buy' : 'Sell';
      this.leg2buysell = this.leg1buysell == 'Buy' ? 'Sell' : 'Buy';
      await this.getSpreadSymbol();
    }
    else
    {
      this.spreadValidity = this.objOEDetail.validity;
      this.spreadDetails =  [];
      this.modifyFlag = true;
      this.spreadDetails = this.objOEDetail.spreadDetails;
      this.leg1Expiry = this.spreadDetails[0].legexpiryDate;
      this.leg2Expiry = this.spreadDetails[1].legexpiryDate;
      this.leg1buysell = this.spreadDetails[0].legbuysell.toUpperCase() == 'BUY' ? 'Buy' : 'Sell';
      this.leg2buysell = this.spreadDetails[1].legbuysell.toUpperCase() == 'SELL' ? 'Sell' : 'Buy';
      this.segmenttoggle = 'LIMIT';
      this.limitprice = this.prevSelPrice = this.spreadDetails[0].legprice;
      if(this.objOEDetail.qtyOrlot.toUpperCase() == 'QTY')
      {
        this.totalLot = parseFloat(this.objOEDetail.spreadQty) / parseFloat(this.originalspreadLot);
      }
      else if(this.objOEDetail.qtyOrlot.toUpperCase() == 'LOT')
      {
        this.totalLot = this.objOEDetail.spreadQty;
      }
      this.prevSelQuantity = parseFloat(this.totalLot) * parseFloat(this.originalspreadLot)
      this.getMarginUtilization();
    }
  }

  async getSpreadSymbol() {
    try {
      let scripObject = {
        mktSegid: this.scripObject.scripDet.MapMktSegId,
        symbol: this.symbol,
        token: this.scripObject.scripDet.token
      }
      await this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + clsGlobal.LocalComId + clsGlobal.versionId + '/getScripFromSpreadSymbol', scripObject).subscribe(((data: any) => {
        try {
          if (data.status.toUpperCase() == 'SUCCESS' && data.data != undefined) {
            for (let count = 0; count < data.data.length; count++) {
              let legDate = clsTradingMethods.getSecondLegDate(data.data[count].nExpiryDate);
              let legDetails = {
                legexpiryDate: legDate,
                legexpiryDayIOS: legDate.substr(2, 3) + '/' + legDate.substr(0, 2) + '/' + legDate.substr(-4),
                // legexpiryDay : legexpiryDate.substr(0,2),
                // legexpiryMonth : legexpiryDate.substr(2,3),
                legsymbol: data.data[count].sSymbol.trim(),
                legseries: data.data[count].sSeries.trim(),
                legoptionType: data.data[count].sOptionType.trim() == 'XX' ? "" : data.data[count].sOptionType.trim(),
                leginstrumentName: data.data[count].sInstrumentName,
                //leginstru : leginstrumentName.substr(0,3),
                totallegLot : 1,
                originallegLot: data.data[count].nRegularLot,
                legstrikePrice: (data.data[count].nStrikePrice == -1 || data.data[count].nStrikePrice == 'NA') ? '' : (data.data[count].nStrikePrice / data.data[count].nPriceBdAttribute).toFixed(clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, data.data[count].nPriceBdAttribute.toString().length - 1)),
                legToken: data.data[count].nToken,
                legDecimalLocator: data.data[count].nPriceBdAttribute,
                legmktsegid: this.scripObject.scripDet.MktSegId,
                legmapmktsegid: this.scripObject.scripDet.MapMktSegId,
                legpricetick: data.data[count].nPriceTick,
                legexchangename: clsTradingMethods.getExchangeName(this.scripObject.scripDet.MktSegId),
                legpriceprecision: clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, data.data[count].nPriceBdAttribute.toString().length - 1),
                legprice: '0.00',
                legopenclose: false,
                legbuysell: 'BUY',
                sellimitlegPrice: '',
                selmarketlegPrice: '0.00',
                legpricetoggle: 'marketlegPrice',
                removeLeg: false,
                isin : data.data[count].sISINCode,
                securitydesc : data.data[count].sSecurityDesc,
                fiilimit : data.data[count].nFIILimit,
                nrilimit : data.data[count].nNRILimit,
              }
              this.spreadDetails.push(legDetails);
            }
            this.leg1Expiry = this.spreadDetails[0].legexpiryDate;
            this.leg2Expiry = this.spreadDetails[1].legexpiryDate;
            this.spreadDetails[0].legbuysell = this.leg1buysell.toUpperCase();
            this.spreadDetails[1].legbuysell = this.leg2buysell.toUpperCase();
            this.getMarginUtilization();
            // this.MultilegsDetails.push(leg2Details);
            // this.sendLegTouchLine();
          }
        } catch (error) {
          //this.toastCtrl.showAtBottom(error.message);
          clsGlobal.logManager.writeErrorLog('SpreadOrderEntry', 'getSpreadSymbol1', error);
        }
      }), error => {
        clsGlobal.logManager.writeErrorLog('SpreadOrderEntry', 'getSpreadSymbol2', error);
      })
    } catch (error) {
      console.log(error);
    }
  }

  kFormatter(num) {
    let fundsValueInText = '';
    let digits = 1;
    if (isNaN(num))
      num = 0;

    var si = [
      { value: 1, symbol: "" },
      { value: 1E3, symbol: "K" },
      { value: 1E5, symbol: "Lac" },
      { value: 1E7, symbol: "Cr." },
      { value: 1E12, symbol: "T" },
      { value: 1E15, symbol: "P" },
      { value: 1E18, symbol: "E" }
    ];
    var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
    var i;
    for (i = si.length - 1; i > 0; i--) {
      if (num >= si[i].value) {
        break;
      }
    }
    return fundsValueInText = (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
  }

  plusminus(event) {
    if (event == 'minus') {
      if (parseFloat(this.totalLot) == 1) {
        return;
      }
      if (this.totalLot == '') {
        this.totalLot = 1;
        return;
      }
      this.totalLot = parseFloat(this.totalLot) - 1;
    }
    else if (event == 'plus') {
      if (this.totalLot == '') {
        this.totalLot = 0;
      }        
      this.totalLot = parseFloat(this.totalLot) + 1;
    }
    this.getMarginUtilization();
  }

  sendB5Request(intOperationType: OperationType, objScrip: clsScrip) {
    try {
      let objTLReq = new clsBestFiveRequest();
      objTLReq.OperationType = intOperationType;
      objTLReq.ByPassRequestStore = false;
      objTLReq.Scrip = objScrip;
      clsGlobal.pubsub.publish("B5REQ", objTLReq);
    } catch (e) {
      //this.toastCtrl.showAtBottom('sendB5Request' + e.message);
    }
  }

  receiveBestFiveResponse(objB5Resp: clsBestFiveResponse) {
    try {

      if (objB5Resp != null) {
        //console.log(objMultiTLResp);
        if (this.scripObject.scripDet.MktSegId == objB5Resp.Scrip.MktSegId &&
          this.scripObject.scripDet.token == objB5Resp.Scrip.token) {

          this.LTP = (((parseFloat(objB5Resp.LTP) == 0) || objB5Resp.LTP == "" || objB5Resp.LTP == undefined) ? objB5Resp.ClosePrc : objB5Resp.LTP);
          if (this.LTP == '') {
            let price = 0;
            this.LTP = price.toFixed(objB5Resp.PriceFormat);
          }
          let arrNetChange = clsTradingMethods.getChangeInRs(objB5Resp.LTP, objB5Resp.ClosePrc, objB5Resp.PriceFormat, false, 'uptrend');

          this.NetChangeInRs = arrNetChange[0];
          this.PercNetChange = arrNetChange[1];
          this.LTPTrend = arrNetChange[2];

          let bidSum = 0;
          let askSum = 0;

          for (let i = 0, len = objB5Resp.BestFiveData.length; i < len; i++) {
            if (objB5Resp.BestFiveData[i].sBidQty != undefined && objB5Resp.BestFiveData[i].sBidQty != '-' && objB5Resp.BestFiveData[i].sBidQty != 0)
              bidSum = bidSum + parseInt(objB5Resp.BestFiveData[i].sBidQty);

            if (objB5Resp.BestFiveData[i].sAskQty != undefined && objB5Resp.BestFiveData[i].sAskQty != '-' && objB5Resp.BestFiveData[i].sAskQty != 0)
              askSum = askSum + parseInt(objB5Resp.BestFiveData[i].sAskQty);
          }
          for (let i = 0, len = objB5Resp.BestFiveData.length; i < len; i++) {
            objB5Resp.BestFiveData[i].sBidPer = this.calculateHistogram(bidSum, objB5Resp.BestFiveData[i].sBidQty);
            objB5Resp.BestFiveData[i].sAskPer = this.calculateHistogram(askSum, objB5Resp.BestFiveData[i].sAskQty);
          }
          //this.PercNetChangeRaw = arrNetChange[3];
          // this.totalBuyQty = objB5Resp.TotBuyQty;
          // this.totalSellQty = objB5Resp.TotSellQty;
          this.totalBuyQty = (objB5Resp.TotBuyQty == '' ? '-' : objB5Resp.TotBuyQty);
          this.totalSellQty = (objB5Resp.TotSellQty == '' ? '-' : objB5Resp.TotSellQty);

          if (this.totalSellQty != '-' && this.totalBuyQty != '-') {
            let _totalQty = parseInt(this.totalSellQty) + parseInt(this.totalBuyQty);
            this.totalBidQtyPer = ((parseInt(this.totalBuyQty) / _totalQty) * 100).toFixed(2);
            this.totalAskQtyPer = ((parseInt(this.totalSellQty) / _totalQty) * 100).toFixed(2);
            //we will calculate qty percent 
          }
          this.B5Data = objB5Resp.BestFiveData;
          var valSelPrice;
          if (this.leg1buysell.toUpperCase() == "BUY")
            valSelPrice = objB5Resp.BestFiveData[0].sAsk;
          else
            valSelPrice = objB5Resp.BestFiveData[0].sBid;

          valSelPrice = isNaN(parseFloat(valSelPrice)) ? 0 : parseFloat(valSelPrice).toFixed(objB5Resp.PriceFormat);
          this.legLTP = valSelPrice
        }


      }
    } catch (error) {
      //this.toastCtrl.showAtBottom("" + error.message);
      clsGlobal.logManager.writeErrorLog('OrderEntryPopup', 'receiveBestFiveResponse', error);
    }
  }

  calculateHistogram(sum: any, qty: number) {
    try {
      let histovalue = (Math.round(((qty * 100) / sum) * 100) / 100).toFixed(2);
      //console.log(histovalue);
      return histovalue;
    } catch (error) {
      console.log("Error in histor calculation ." + error);
      return 0;
    }
  }

  ionViewWillLeave() {
    try {
      clsGlobal.User.spreadScrips = [];
      clsGlobal.pubsub.unsubscribe("B5RES", this.bcastB5Handler);
      this.sendB5Request(OperationType.REMOVE, this.scripObject);
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('spread-order-entry', 'ionViewWillLeave', error);
    }
  }

  clickMarketDepth() {
    this.showMarketDepth = !this.showMarketDepth;
  }

  async clickPopover(ev: any, stype) {
    const popover = await this.popoverController.create({
      component: PopoverPage,
      event: ev,
      translucent: true,
      mode: "ios",
      cssClass: 'order-entry-popover',
      backdropDismiss: true,
      componentProps: {
        'type': stype,
      }
    });
    await popover.present();
  }

  closePopUp() {
    //console.log(this.scripObject);
    let eventobj = {
      closePopUp: true
    }
    this.messageEvent.emit(eventobj);
  }

  priceChange(evt){
    this.segmenttoggle = evt.detail.value.toUpperCase().toString();
    this.getMarginUtilization();
  }

  buysellchange() {
    if(this.spreadDetails.length == 0 || this.modifyFlag == true)
    return;
    this.sendB5Request(OperationType.REMOVE, this.scripObject);
    this.leg1buysell = this.leg1buysell == 'Buy' ? 'Sell' : 'Buy';
    this.leg2buysell = this.leg2buysell == 'Buy' ? 'Sell' : 'Buy';
    this.spreadDetails[0].legbuysell = this.leg1buysell.toUpperCase();
    this.spreadDetails[1].legbuysell = this.leg2buysell.toUpperCase();
    //[this.spreadDetails[0],this.spreadDetails[1]] = [this.spreadDetails[1],this.spreadDetails[0]];
    this.sendB5Request(OperationType.ADD, this.scripObject);
    this.getMarginUtilization();
  }

  clickChooseValidity() {
    if(this.arrValidityUI.length > 1 && !this.modifyFlag)
    this.showChooseValidity = !this.showChooseValidity;
  }

  setValidity(validity) {
    this.spreadValidity = validity;
    this.clickChooseValidity();
  }

  openSpreadConfirm() {
    if (this.segmenttoggle == 'LIMIT') {
      if (this.limitprice == '') {
        this.toastCtrl.showWithButton("Price must be provided");
        return;
      }
    }
    if (this.totalLot == '') {
      this.toastCtrl.showWithButton("Lot must be provided");
      return;
    }
    if (parseFloat(this.totalLot) == 0) {
      this.toastCtrl.showWithButton("Lot cannot be Zero");
      return;
    }
    if(this.segmenttoggle == 'MARKET')
    {
      var PriceinPaise = parseInt(Math.round(parseFloat((this.LTP * this.scripObject.DecimalLocator).toString())).toString());
    }
    else if(this.segmenttoggle == 'LIMIT')
    {
      var PriceinPaise = parseInt(Math.round(parseFloat((this.limitprice * this.scripObject.DecimalLocator).toString())).toString());
    }

    if (PriceinPaise % this.scripObject.PriceTick != 0) {
      let PriceFormatter = clsTradingMethods.GetPriceFormatter(this.scripObject.DecimalLocator.toString(), this.scripObject.scripDet.MktSegId, this.scripObject.InstrumentName);
      let PriceTickInRs = (this.scripObject.PriceTick / parseFloat(this.scripObject.DecimalLocator)).toFixed(PriceFormatter);
      this.toastCtrl.showWithButton(clsGlobal.dMsgMaster.getItem("NNSL62") + PriceTickInRs); //+ clsGlobal.dMsgMaster.getItem("NNSL63"));
      return
    }

    let spread = {
      spreadprice : this.segmenttoggle == 'MARKET' ? this.legLTP : this.limitprice,
      totallot : this.totalLot,
      originalspreadLot : this.originalspreadLot,
      mainlegsymbol : this.symbol,
      mainleginstrumentname : this.scripObject.InstrumentName,
      leg1symbol : this.spreadDetails[0].legsymbol.trim(),
      leg2symbol : this.spreadDetails[1].legsymbol.trim(),
      leg1buysell : this.leg1buysell,
      leg2buysell : this.leg2buysell,
      leg1Expiry : this.leg1Expiry,
      leg2Expiry : this.leg2Expiry,
      leg1token : this.spreadDetails[0].legToken,
      leg2token : this.spreadDetails[1].legToken,
      leg1instrumentname : this.spreadDetails[0].leginstrumentName,
      leg2instrumentname : this.spreadDetails[1].leginstrumentName,
      marketsegid : this.scripObject.scripDet.MktSegId,
      exchange : this.scripObject.ExchangeName,
      leg1strikeprice : this.spreadDetails[0].legstrikePrice,
      leg2strikeprice : this.spreadDetails[1].legstrikePrice,
      leg1optiontype : this.spreadDetails[0].legoptionType,
      leg2optiontype : this.spreadDetails[1].legoptionType,
      leg1series : this.spreadDetails[0].legseries,
      leg2series : this.spreadDetails[1].legseries,
      leg1pricetick : this.spreadDetails[0].legpricetick,
      leg2pricetick : this.spreadDetails[1].legpricetick,
      leg1decimalloc : this.spreadDetails[0].legDecimalLocator,
      leg2decimalloc : this.spreadDetails[1].legDecimalLocator,
      LTP : this.LTP,
      NetChangeInRs : this.NetChangeInRs,
      PercNetChange : this.PercNetChange,
      LTPTrend : this.LTPTrend,
    }
    let amount : any = 0;
    let price : any = 0;
    price = this.segmenttoggle == 'MARKET' ? this.legLTP : this.limitprice;
    if (price != '')
    {
      amount = amount + (parseFloat(price) * (this.totalLot * this.originalspreadLot));
    }
    this.approxamt = amount.toFixed(2);
    let confirmDetails = {
      legdetails: spread,
      approxmargin: this.approximateMargin,
      availableMargin: this.availableMargin,
      approxamt: this.approxamt,
      validity : this.spreadValidity,
      isMultiLeg: false,
      isSpread: true,
      modify : this.modifyFlag,
      gatewayNo : this.objOEDetail.gwOrderNo
    }
    this.modalCtrl.create({
      component: MultilegConfirmationPage,
      //cssClass: 'my-custom-class',
      componentProps: {
        'scrip': confirmDetails,
      }
    }).then(modal => {
      modal.present().then(data => {

      });
      modal.onDidDismiss().then(data => {
        if(data.data != '' && data.data != undefined)
        {
          this.closePopUp();
        }
        else
        {
        //this.sendLegTouchLine();
        this.sendB5Request(OperationType.ADD, this.scripObject);
        }
      })
    })
  }

  sendSubscritionRequest() {
    try {
      this.sendB5Request(OperationType.ADD, this.scripObject);
    } catch (e) {
      //this.toastCtrl.showAtBottom('sendB5Request' + e.message);
    }
  }

  //BT-37892/BT-37893:RANI G:06012021:Margin display on spread order entry<End>
  getMarginUtilization() {
    try {
      this.showMarginLoader = false;
      if(this.spreadDetails.length == 0)
      return;
      //if(this.bIsMarginReqInProcess) return;
      this.showMarginLoader = true;
      let NoOfLegs = this.spreadDetails.length;
      //if (this.SelProduct == Global.Constants.C_S_PRODUCTTYPE_MP_TEXT)
      //    NoOfLegs = 2;
      //else if (this.SelProduct == Global.Constants.C_S_PRODUCTTYPE_BRACKET_ORDER_TXT)
      //    NoOfLegs = 3;
      this.fundFlag = false;
      this.approximateMargin = 0;
      this.availableMargin = 0;
      this.shortFall = 0;
      let jData = {};
      jData["UserID"] = clsGlobal.User.userId;
      jData["GroupID"] = clsGlobal.User.groupId;
      jData["UCCClientID"] = "";
      jData["UCCGroupID"] = "";
      jData["NoOfLegs"] = NoOfLegs;
      jData["Mode"] = this.modifyFlag == false ? "N" : "M";
      jData["TemplateId"] = clsGlobal.User.SITemplateId;
      jData['UserCode'] = clsGlobal.User.userCode;
      jData["LegDetails"] = this.legDetailsObject(NoOfLegs);
      jData['FETraceId'] = clsGlobal.User.userId + "_" + moment().format('ddmmyyHHMMss');
      jData['GroupCode'] = clsGlobal.User.groupCode;

      this.bIsMarginReqInProcess = true;

      this.tranService.getOrderMarginInfo(jData).then((response: any) => {
        this.bIsMarginReqInProcess = false;
        this.showMarginLoader = false;
        //console.log("Margin calculation "+ JSON.stringify(response));
        if (response.data.status == "200") {
          this.approximateMargin = this.kFormatter(response.data.result.ApproxMargin);
          this.availableMargin = this.kFormatter(response.data.result.AvailableMargin);
          this.shortFall = parseFloat(response.data.result.ShortFall);
          this.checkMarginShortFall();
        }
      }).catch(error => {
        this.bIsMarginReqInProcess = false;
        this.showMarginLoader = false;
        //this.toastCtrl.showAtBottom("Unable to fetch margin details, kindly contact administrator.");
        console.log("Unable to fetch margin details, kindly contact administrator.");
      });
    }
    catch (e) {
      this.showMarginLoader = false;
      clsGlobal.logManager.writeErrorLog('spread-order-entry', 'getMarginUtilization', 'Exception: ' + e.message);
    }

  }

  legDetailsObject(NoOfLegs) {
    try {
      var LegDtls = [];
      var quantity = this.totalLot * this.originalspreadLot;
      for (var i = 0; i < NoOfLegs; i++) {
        var jData_legDtls = {};
        jData_legDtls["LegNo"] = i+1;
        if (i == 1) {
          jData_legDtls["BuyOrSell"] = this.leg1buysell.toUpperCase() === clsConstants.C_S_ORDER_BUY_TEXT ? 1 : 2;
        }
        else if(i == 2){
          jData_legDtls["BuyOrSell"] = this.leg2buysell.toUpperCase() === clsConstants.C_S_ORDER_BUY_TEXT ? 1 : 2;
        }
        //else if (i == 2 || i == 3) {
        //    if (this.SelBuySell === Global.Constants.C_S_ORDER_BUY_TEXT)
        //        jData_legDtls["BuyOrSell"] = 2;
        //    else
        //        jData_legDtls["BuyOrSell"] = 1;
        //}
        jData_legDtls["MarketSegmentId"] = this.spreadDetails[i].legmktsegid;
        jData_legDtls["Token"] = this.spreadDetails[i].legToken;
        jData_legDtls["Quantity"] = quantity;
        var Price;
        Price = this.segmenttoggle == 'MARKET' ? this.legLTP : this.limitprice;
        if(Price == '')
        Price = 0.00;
        jData_legDtls["Price"] = parseFloat(Price);
        jData_legDtls["MktFlag"] = 0;

        if (this.modifyFlag) {
          jData_legDtls["OldPrice"] = this.prevSelPrice != "" && this.prevSelPrice != undefined ? parseFloat(this.prevSelPrice) : 0;
        }
        else {
          jData_legDtls["OldPrice"] = 0;
        }

        jData_legDtls["OldQuantity"] = this.prevSelQuantity != "" ? this.prevSelQuantity : 0;
        jData_legDtls["ProductType"] = 'D';//this.SelProduct;
        //if (NoOfLegs == 3) { //Bracket Order
        //    if (i == 1)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_MAIN_LEG_INDICATOR;
        //    if (i == 2)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_SL_LEG_INDICATOR;
        //    if (i == 3)
        //        jData_legDtls["LegIndicator"] = Global.Constants.C_V_BRACKET_PROFIT_LEG_INDICATOR;
        //}
        //else {
        //    jData_legDtls["LegIndicator"] = 0;
        //}
        jData_legDtls["LegIndicator"] = 0;
        jData_legDtls["UserID"] = clsGlobal.User.userId;
        LegDtls.push(jData_legDtls);
      }
      return LegDtls;
    }
    catch (e) {
      clsGlobal.logManager.writeErrorLog('spread-order-entry', 'LegDetailsObject', 'Exception: ' + e.message);
    }
  }

  leglimitpriceLostFocus() {
    if (this.segmenttoggle == 'LIMIT') {
      if (this.limitprice == '' || this.limitprice == undefined) {
        this.limitprice = '0.00';
      }
      this.limitprice = parseFloat(this.limitprice).toFixed(parseFloat(clsGlobal.ExchManager.returnPrecisionForPrice(this.scripObject.scripDet.MktSegId, this.scripObject.DecimalLocator.toString().length - 1)));
      this.getMarginUtilization();
    }
  }

  lotLostFocus(){
    if(this.totalLot != '')
    {
      this.getMarginUtilization();
    }
  }

  priceSelected(price: any) {
    this.clickMarketDepth();
    if (price != "-" && price != "0" && price != "") {
      if (this.segmenttoggle == "LIMIT")
      {
        this.limitprice = price;
        this.getMarginUtilization();
      }
    }
  }

  openMultiLeg(){
    if(this.spreadDetails.length == 0 || this.modifyFlag)
    return;
    if (clsGlobal.User.isGuestUser) {
      this.alertCtrl.showAlert(
        "Register now to access this feature!",
        "Order Error!"
      );
      return;
    }
    //let scripinfoObj = clsCommonMethods.getScripObject(scripobj);
    let ScripObj = this.getScripObject();
    // Validation for Fresh order. If Login Disable from Admin Then it will check first before clicking buy button
    let SegmentId = ScripObj.scripDetail.scripDet.MktSegId;
    if (!clsCommonMethods.isLoginAllowed(SegmentId)) {
      this.alertCtrl.showAlert(
        "You are currently not allowed to place/modify/cancel order in this segment",
        "Order Error!"
      );
      return;
    }
    
    let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
    objOEFormDetail.scripDetl = ScripObj.scripDetail;//currScrip;
    //objOEFormDetail.exchOrderNo
    objOEFormDetail.pageSource = clsConstants.C_V_MARKETWATCH_PAGENO;
    objOEFormDetail.productType = "MULTILEGORDER";
    //this.selectedScrip = objOEFormDetail;
    this.paramService.myParam = objOEFormDetail;
    clsGlobal.User.spreadScrips = this.spreadDetails;
    this.navCtrl.navigateForward('orderentry');
  }

  getScripObject() {

    let objScrpKey = new clsScripKey();

    objScrpKey.MktSegId = this.spreadDetails[0].legmktsegid;
    objScrpKey.token = this.spreadDetails[0].legToken

    let scripInfo: clsScrip = new clsScrip();
    scripInfo.scripDet = objScrpKey;
    scripInfo.symbol = this.spreadDetails[0].legsymbol.trim();
    scripInfo.Series = this.spreadDetails[0].legseries;
    scripInfo.DecimalLocator = this.spreadDetails[0].legDecimalLocator == "0" ? "100" : this.spreadDetails[0].legDecimalLocator;
    scripInfo.InstrumentName = this.spreadDetails[0].leginstrumentName.trim();
    scripInfo.ExpiryDate = this.spreadDetails[0].legexpiryDate;
    scripInfo.OptionType = this.spreadDetails[0].legoptionType;
    scripInfo.MarketLot = this.spreadDetails[0].originallegLot;
    scripInfo.PriceTick = this.spreadDetails[0].legpricetick;
    scripInfo.SecurityDesc = this.spreadDetails[0].securitydesc.trim();
    // scripInfo.MWSecurityDesc = this.spreadDetails[0].sSecurityDesc.trim();
    scripInfo.StrikePrice = this.spreadDetails[0].legstrikePrice.trim();
    scripInfo.ISIN = this.spreadDetails[0].isin;
    scripInfo.SPOS = "";
    scripInfo.POS = "";
    //scripInfo.Quantity = this.spreadDetails[0].nRegularLot;
    //scripInfo.AssetToken = this.spreadDetails[0].nAssetToken;
    scripInfo.FIILimit = this.spreadDetails[0].fiilimit;
    scripInfo.NRILimit = this.spreadDetails[0].nrilimit;
    //scripInfo.Spread = this.spreadDetails[0].nSpread;
    //scripInfo.MarginTypeIndicator = this.spreadDetails[0].nMarginTypeIndicator;
    if (this.spreadDetails[0].leginstrumentName.indexOf('IDX') != -1) {
      scripInfo.isIndex = true;
    }
    else {
      scripInfo.isIndex = false;
    }

    scripInfo.formatScripDisplayName()

    let idData = new clsIndexDetail();
    idData.scripDetail = scripInfo;
    return idData;
  }

  checkMarginShortFall() {
    try {

      if(parseFloat(this.shortFall) > 0)
      {
        this.fundFlag = true;
      }
      else
      {
        this.fundFlag = false;
      }
    } catch (error) {

    }
  }

  addFunds() {
    this.paramService.myParam = this.shortFall;
    this.navCtrl.navigateForward('fundsadd');
  }
}
