import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MenuButtonComponent } from './menu-button/menu-button';
import { ExpandableHeader } from './expandable-header/expandable-header'; 
import { PriceDisplayComponent } from './price-display/price-display';
import { Ionic3PincodeInputComponent } from './pin-code/ionic3-pincode-input';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BottomMenuComponent } from "./bottom-menu/bottom-menu.component";
import { PopupOrderentryComponent } from "./popup-orderentry/popup-orderentry.component";
import { HembergMenuComponent } from './hemberg-menu/hemberg-menu.component';
import { IndiceTickerComponent} from './indice-ticker/indice-ticker.component';
import { DirectiveSharedModule } from '../directives/directive.shared.module';
import { WatchlistAddComponent } from './watchlist-add/watchlist-add.component';
import { NgCalendarModule  } from 'ionic2-calendar';
import { ScripNameComponent } from './scrip-name/scrip-name.component';
import { EDISSummaryComponent } from './edissummary/edissummary.component';
import { SpreadOrderEntryComponent } from './spread-order-entry/spread-order-entry.component';
import {IntropPopupOrderentryComponent} from './introp-popup-orderentry/introp-popup-orderentry.component'
//import { NavParams } from '@ionic/angular';
@NgModule({
    declarations: [
        MenuButtonComponent,
        ExpandableHeader,
        PriceDisplayComponent,
        Ionic3PincodeInputComponent,
        BottomMenuComponent,
        PopupOrderentryComponent,
        IntropPopupOrderentryComponent,
        HembergMenuComponent,
        IndiceTickerComponent,
        WatchlistAddComponent,
        ScripNameComponent,
        EDISSummaryComponent,
        SpreadOrderEntryComponent
    ],
    entryComponents: [EDISSummaryComponent],
    imports: [
        CommonModule,NgCalendarModule,
        FormsModule,
        ReactiveFormsModule,
        DirectiveSharedModule
    ],
    exports: [MenuButtonComponent,
        ExpandableHeader,
        PriceDisplayComponent, 
        Ionic3PincodeInputComponent,
        BottomMenuComponent,
        PopupOrderentryComponent,
        IntropPopupOrderentryComponent,
        HembergMenuComponent,
        IndiceTickerComponent,
        WatchlistAddComponent,
        ScripNameComponent,
        EDISSummaryComponent,
        SpreadOrderEntryComponent
    ],
    //providers: [NavParams],
    schemas: [
        CUSTOM_ELEMENTS_SCHEMA
    ]
})
export class ComponentsModule { }