import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-scrip-name',
  templateUrl: './scrip-name.component.html'
})
export class ScripNameComponent implements OnInit {

  //script  object to be passed clsScrip.
  @Input("Scrip") objScrip: any;
  
  constructor() { }

  ngOnInit() {}

}
