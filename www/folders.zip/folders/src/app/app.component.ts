import { Component, QueryList, ViewChildren } from '@angular/core';
import { Platform, ModalController, NavController, IonRouterOutlet } from '@ionic/angular';
// import { SplashScreen } from '@ionic-native/splash-screen/ngx';
// import { StatusBar } from '@ionic-native/status-bar/ngx';
// plugins
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { PushObject, Push, PushOptions } from '@ionic-native/push/ngx';
import { TranslateService } from '@ngx-translate/core';
import { Network } from '@ionic-native/network/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Insomnia } from '@ionic-native/insomnia/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { Device } from '@ionic-native/device/ngx';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
//import { Geolocation } from '@ionic-native/geolocation/ngx';
// classes
import { clsGlobal, clsPluginConstants } from './Common/clsGlobal';
import { AppState } from './app.global';
import { LogServicesProvider } from './providers/log-services/log-services';
import { clsConstants } from './Common/clsConstants';
import { ToastServicesProvider } from './providers/toast-services/toast.services';
import { AlertServicesProvider } from './providers/alert-services/alert-services';
import { NavParamService } from './providers/nav-param.service';
import { clsHttpService } from './Common/clsHTTPService'; 
import { clsAppConfigConstants } from './Common/clsAppConfigConstants';
// import { clsTradingMethods } from './Common/clsTradingMethods';
// import { clsCommonMethods } from './Common/clsCommonMethods';
// import { clsOEFormDetl } from './Common/clsOrderEntryFormDetl';
import { clsUser } from './Common/clsUser';
//import { DatabaseService } from './providers/database-services/database-services';
import { DatePipe } from '@angular/common';
import { clsLocalStorageService } from './Common/clsLocalStorageService';
import { RouterExtService } from './providers/router-ext-service.service';
import { Router } from '@angular/router';
// import { Events } from './communicator/clsEvents';
import { clsAppInitService } from './Common/clsAppInitService'; 
import { clsCommonMethods } from './Common/clsCommonMethods';
import { GlobalEventsService } from './providers/global-events.service';
import { AuthenticationService } from './providers/authentication.service';
import { AppsyncDbService } from './providers/appsync-db.service';
//import { SocketService } from './providers/socket.service';
 import { IRoot } from '@ionic-native/iroot/ngx'; 
 import { SocketIoServiceService } from './providers/socket-io-service.service';
 import { clsOEFormDetl } from 'src/app/Common/clsOrderEntryFormDetl';
import { clsTradingMethods } from './Common/clsTradingMethods';

declare var NativeFunctions: any;

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
})
export class AppComponent {
  preferendLang = 'english';
  rootPage: any; // = 'LoadingPage'; //mediator page for splash and main page. test by omprakash
  isNetworkAvailable = true;
  lastTimeBackPress = 0;
  timePeriodToExit = 2000;
  Classdate: any = new Date().toTimeString();
  pages: Array<{ title: string, component: any }>;
  _pushObject: PushObject;
  pluginPromise: any;
  isUATEnvironment: boolean = true; 
  
  @ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private device: Device,
    private appVersion: AppVersion,
    //private geolocation: Geolocation,
    private insomnia: Insomnia,
    private mobileAccessibility: MobileAccessibility, 
    private pushServiceObject: Push,
    private network: Network,
    private global: AppState,
    private httpService: clsHttpService, 
    private objAppInitService: clsAppInitService,
    //private db: DatabaseService, 
    private dateFormatter: DatePipe,
    private loggerService: LogServicesProvider,
    private alertservice: AlertServicesProvider,
    private toastservice: ToastServicesProvider,
    private localstorageservice: clsLocalStorageService,
    //private objAppState: AppState,
    private navParam: NavParamService, 
    //private modalCtrl: ModalController,
   // private authService : AuthenticationService,
    private nav: NavController, 
    private router: Router,
    //private events: Events,  
   private navCtrl : NavController,
   private globalEvents:GlobalEventsService,
   //private appSync : AppsyncDbService,
   private socketIoServiceService : SocketIoServiceService,
   private iroot: IRoot ,
   private appSync : AppsyncDbService
   
  ) {
    //clsGlobal.pubsub = this.events;
    clsGlobal.dateFormatter = this.dateFormatter;
    clsGlobal.logManager = this.loggerService;
    this.platform.ready().then(() => {  
    if (this.platform.is('cordova')) {
      console.log('is cordova');
      this.callNativeMethod();
      try {
         console.log(' IRoot', IRoot); 
        this.iroot.isRooted().then(data => {
          if(!data)
          { 
            //it is not rooted. so it will continue.
            this.initializeApp();
          }
          else{
          //it is rotted phone.
          this.hideSplash();
            this.toastservice.showAtBottom("Application is unable to run on rooted Phone.");
            setTimeout(() => {
                navigator['app'].exitApp(); //exit app.
            }, 2000);
          }
        }).catch((error) => {
          console.log("Error in isRooted check. " + error);
        });
    
      }
      catch (e) {
        console.log('Error: in roote checking. ' + e);
      }
    }
    else{
      //on chrome normal init.
      this.initializeApp();
    }
    }); 
  }

  async callNativeMethod() {
    const json = {
      "action": "launch_result",
      "action_data": {
        "result":"success"
      }
    }
    console.log('Call Native Method');
    NativeFunctions.callback(JSON.stringify(json));
}

  //Init application 
   initializeApp() {
    //this.platform.ready().then(() => {   
      console.log('Ionic ready fire : ' + (new Date()).toLocaleTimeString());
      try {
        this.statusBar.overlaysWebView(false);
        this.statusBar.styleDefault();
        this.statusBar.backgroundColorByHexString('#f2f4f7');
        
        // Set screen Orientation
        if (this.platform.is('cordova')) {
          // by default screen will be portrait mode
          try {
            window.screen.orientation.lock('portrait');
            console.log("Screen lock to potrait pass.");
          } catch (error) {
            console.log("Screen lock to potrait fails");
          }
        }
        if (this.platform.is('ios')) {
          clsGlobal.PlatformMode = 'ios';
        }
      } catch (error) {
        console.log('Status bar initialize error :' + error);
      }
      try {
        // this will disallowed system setting to make font size bigger.
        this.mobileAccessibility.usePreferredTextZoom(false);
        // will open app same as youtube irrespective of screen timeout
        this.insomnia.keepAwake()
          .then(() => console.log('success awake call'), () => console.log('unsessfull awake call')
          );
      } catch (error) {
        console.log('Mobile accessibility and insomnia error :' + error);
      }
      // to identify ui
      if (this.platform.is('mobile') || this.platform.is('iphone')) {
        clsGlobal.applicationType = clsGlobal.MOBILE;
      }
      else if (this.platform.is('ipad') || this.platform.is('tablet')) {
        clsGlobal.applicationType = clsGlobal.TABLET;
      }
      else {
        clsGlobal.applicationType = clsGlobal.DESKTOP;
      }
      try { 
        // register pubsub for token subscription.
        this.registerTopicChangeHandler();
        // set theme
        this.setTheme();
        // back button handling.
        this.backButtonEvent(); // backbutton registration 
        // default Language setting. If previous setting is not available
        this.setLanguageSettings();
        //keyboard event listeners
        this.setKeyboardListner();
        //get global events.
        //this.globalEvents.fetchEvents();
        //Get FCM notifications topic
        this.getFcmUserTopicDetails();
      } catch (error) {
        console.log('Error in registertopic,theme,backbutton :' + error);
      }
      try {
        // now app api call and other initialization
        this.isNetworkAvailable = this.checkNetwork();
        this.initAppOnNetworkAvailable();
      } catch (error) {
        this.hideSplash();
        this.alertservice.showAlert('plugins issue1 . ' + error);
      }
      try {
        clsGlobal.pubsub.subscribe('SESSIONEXPIRE', (data: any) => {
          this.logOutSessionExpired();
        });
    
        clsGlobal.pubsub.subscribe('SESSIONEXPIRE_GATEWAY', (data: any) => {
          if (!clsGlobal.IsSessionExpiredGateway) {
            clsGlobal.IsSessionExpiredGateway = true;
    
            // try {
            //   let activePortal = this.ionicApp._overlayPortal.getActive() || this.ionicApp._modalPortal.getActive();
            //   if (activePortal) {
            //     activePortal.dismiss();
            //     activePortal = this.ionicApp._modalPortal.getActive();
            //     if (activePortal) {
            //       activePortal.dismiss();
            //     }
            //   }
            // } catch (err) {
            //   clsGlobal.logManager.writeErrorLog('app.component', 'OVERLAY DISMISS SESSION EXPIRY', err);
            // }
    
            this.toastservice.showWithButton(data);
            this.logOutSessionExpired(); 
          }
        });
      } catch (error) { 
      }

      try {
        this.socketIoServiceService.getAlerts().subscribe(alert=>{
        console.log("AlertTriggerd" , alert)
        })
      } catch (error) { 
      } 
    //});
  } 
  /// Method to check initial connection and start app flow
  checkNetwork() {
    try {
      console.log("Network state "+this.network.type);
      if (this.network.type == null) // in browser it will be null
      {
        clsPluginConstants.NetWorkConnected = true;
        return true;
      }
      if (this.network.type != null && this.network.type.toUpperCase().trim() !== 'NONE' && this.network.type.toUpperCase().trim() !== 'UNKNOWN') {
        clsPluginConstants.NetWorkConnected = true;
      }
      else {
        clsPluginConstants.NetWorkConnected = false;
      }
      // watch network for a connection
      this.network.onConnect().subscribe(() => {
        // if network is already connected then dont show toast.
        if (!clsPluginConstants.NetWorkConnected) {
          this.toastservice.showAtBottom('You are now online.');
        }
        clsPluginConstants.NetWorkConnected = true;
        clsPluginConstants.NetWorkType = this.network.type;
        clsGlobal.pubsub.publish('NW:SWITCH', true);
        clsGlobal.nwPopupOpen = false; // if connected then popup display flag will be false since it is reconnected.
      });
      this.network.onDisconnect().subscribe(() => {
        // to do to subscribe for disconnection
        clsPluginConstants.NetWorkConnected = false;
        if (!clsGlobal.nwPopupOpen) { this.toastservice.showWithButton('No Internet. Please Check your internet connection.',undefined,'Retry'); }
        clsGlobal.nwPopupOpen = true; // to display single time.
        clsGlobal.pubsub.publish('NW:SWITCH', false);
      });
      // watch network for a disconnection
      this.network.onChange().subscribe(() => {
        // to do show network change.
        clsPluginConstants.NetWorkType = this.network.type;
        if (this.network.type.toString().toUpperCase() !== 'NONE') {
          //this.toastservice.showAtBottom('Network change to : ' + this.network.type.toString().toUpperCase());
        }
      });
      return clsPluginConstants.NetWorkConnected;
    }
    catch (error) {
      // in browser it will not check as cordova not available.
      console.log(error);
      return false;
    }
  }
  // if network connected we will call this mehtod.
  initAppOnNetworkAvailable() {
    try {   
      if (this.isNetworkAvailable) {  
        console.log('Root app component page visit');
        ///alert("Calling APP route");
        // FIRST APP INIT
        // ON INIT PAGE WE WILL START APP SYNC.
        this.platform.pause.subscribe(() => {
          clsGlobal.isPause = true;
          clsGlobal.pubsub.publish('APPSUSPEND');
        });
        
        this.platform.resume.subscribe(() => {
          clsGlobal.isPause = false;
          clsGlobal.pubsub.publish('APPRESUME');
        });

        if(this.isUATEnvironment){
          this.hideSplash();  
          this.localstorageservice.getItem("IS_UAT_SET").then((envset:any)=>{
            if (envset == null) {
              this.navCtrl.navigateRoot('uatenvionment-setting'); 
            }
            else
            { 
              clsGlobal.ComId = envset.ComId
              clsGlobal.LocalComId = envset.LocalComId;
              clsGlobal.URL = envset.URL;
              clsGlobal.PORT = envset.PORT;
              clsGlobal.VirtualDirectory=clsGlobal.URL + clsGlobal.PORT;
              clsGlobal.URL_CDSSERVER = clsGlobal.URL + clsGlobal.PORT + 'cds/';
              this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
            }
          }).catch((error)=>{ 
          });
        }
        else {
          // //changes for Welcome text display on Init screen.
          // this.appSync.getAppInfoKeyValue(clsAppConfigConstants.APP_INIT_SCREEN_TEXT).then((data) => {
          //   let _welcomeText = null;
          //   if (data != null) {
          //     data.forEach(element => {
          //       _welcomeText = element.sParamValue; 
          //       if (element.sTenantId == clsGlobal.ComId) { 
          //         return; 
          //       } 
          //     });
          //   }
          //   this.navParam.myParam = _welcomeText || null;
          //   this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
          // }).catch((error) => {
          //   this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
          // });
            this.navParam.myParam =   null;
            this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
        }
        
        //  this.objAppInitService.initializeApp().then((sucess) => { 
        //     if (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_BANNED_SCRIP_POPUP) == clsConstants.C_S_ON) {
        //       clsGlobal.BannedScriptStatusFlag = true;
        //     }
        //     else {
        //       clsGlobal.BannedScriptStatusFlag = false;
        //     }
        //     this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_INIT);
        //     this.hideSplash(); 
        //  }, (error) => {
        //   this.toastservice.showWithButton('Unable to initialize application.');
        //});  
        // Second Plugins will initialize 
        this.pluginsInitialize().then((success) => {
          this.notificationPluginInitialize().then((response) => {
            console.log('All plugins initialize completed.');
          }, (error) => {
            this.toastservice.showWithButton('Unable to initialize notificationPluginInitialize.' + error);
            this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_ERROROOPS);
          });
        }, (error) => {
          this.hideSplash();
          this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_ERROROOPS);
        }
        ); 
      }
      else {  
        this.hideSplash();
        this.navParam.myParam=this.isUATEnvironment;
        this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_ERRORNETWORK);
      }
    } catch (error) {
      console.log('initAppOnNwAvailable: ' + error);
      // this.alertservice.showAlert("initAppOnNwAvailable: " + JSON.stringify(error));
    }
  }
    networkCheckRetry()
    {
      if (!clsPluginConstants.NetWorkConnected){
        this.toastservice.showWithButton('No Internet. Please Check your internet connection.',()=>{
          this.networkCheckRetry();
        },'Retry');
      }
    }
   // Method to hide splash while routing to new page.
   hideSplash() {
    this.splashScreen.hide();
    /*
    SingIn,Home, MPIN and Dashboard page will hide splash.
    commented for white screen issue.
    if (this.platform.is('cordova'))
     this.splashScreen.hide(); */
  }
  // set theme
  setTheme() {
    try {
      /*
      as requested by client default theme will be dark. */
      this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_THEME).then((res: any) => {
        if (res == null) {
          this.global.set(clsConstants.LOCAL_STORAGE_THEME, 'light');
          clsGlobal.defaultTheme = 'light';
          this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_THEME, 'light');
        }
        else {
          this.global.set(clsConstants.LOCAL_STORAGE_THEME, res);
          clsGlobal.defaultTheme = res;
        }
      });
    } catch (error) {
      console.log('Set Theme error : ' + error);
    }
  }

  /**
   * Disc : To check guest user is already present or not
   */
   /*
  checkGuestAccount(){
    try{
      let d = new Date();
      let diff = clsCommonMethods.dateDifferenceInDay(d,d);// it required 2 parameter.
      console.log(diff);
      this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((res :any)=>{
        
        let resp = JSON.parse(res);
        if(resp.guestMode){
          if(diff <= clsConstants.guestTrailDays){
            this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
          }else{
            this.toastservice.showAtBottom("your Guest Trial Period Expired");
            this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
          }
        }   
        else{
          this.nav.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_HOME);
        }
      })
    }catch(error){
    }
  }

  */
  logOutSessionExpired() {
    try {
      //this.chatClient.logout();
      try {
        //this.commService.disConnectBroadcast();
       } catch (error) {
      }
      /*  clear user object and reset data to guest details. */
      clsGlobal.User = null;
      clsGlobal.User = new clsUser();
      clsGlobal.FreeStream = (clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_FREE_STREAMING) == clsConstants.C_S_ON);
      clsGlobal.User.userId = clsGlobal.FreeStreamWFHId;//clsGlobal.dateFormatter.transform(new Date(), "hhmmss") + new Date().getMilliseconds();
      clsGlobal.User.SITemplateId = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_GUEST_DEF_TEMPLATE);
      clsGlobal.DefaultSITemplate = clsGlobal.User.SITemplateId;
      clsGlobal.User.brodcastSocketUrl = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_GUEST_BCAST_SOCKET_URL);
        
       this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS)
       .then((item: any) => {
         if (item != undefined) {
           let objMPIN: any = JSON.parse(item);
           if (objMPIN.MPINEnable == 'Y' || objMPIN.NewFingerprint == 'Y') {
             this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_MPIN);
           } else {
             //SignInPage
             this.navCtrl.navigateRoot(clsConstants.C_S_PAGE_ROUTE_SIGNIN);
           }
         }
       });

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('app.component', 'logOutSessionExpired', error);
    }
  }   

  //method to signin user in app sync and start pre sync
  InitAppSyncService(){
     //this.appSync.confiltResolutionPreLogin(); 
     //this.appSync.signingCognito(clsGlobal.ComId,clsGlobal.ComId,"admin@"+clsGlobal.ComId);
     //this.appSync.signingCognito('appsyncadmin','appsyncadmin',"appsyncadmin@63moons.com");
     //this.appSync.signingCognito("OMAPI","OMAPI123","OMAPI@"+clsGlobal.ComId); 
     //this.appSync.signingCognito("YT","YT12345","YT@"+clsGlobal.ComId); 
  }

  // method to register listerner for topic change
  registerTopicChangeHandler() {
    try {

      clsGlobal.pubsub.subscribe('TEST_PUSH',()=>{
        let callbackData =  
            {
              "topicNo": "25043",
              "topicName": "25043",
              "masterRecoId": "",
              "recoSubType": "101",
              "scripInfo": "NSE EQUITIES ACC EQ",
              "scrip": "1$22",
              "price": "3001.25",
              "slprice": "",
              "sqprice": "",
              "qty": "",
              "endTime": "22May2021 23:59:00",
              "recoId": "227WAAUIAA",
              "analysisReportURL": "", 
              "action": "BUY"
          }
          this.doPushBuySellAction("BUY",callbackData); 
      });
      // this will subscribe single topic with User Name for recommendation.
      clsGlobal.pubsub.subscribe('TOPIC_SUBSCRIBE', (topicName: any) => { 
        if (!this.platform.is('android')) {
          topicName = topicName + '_ios'; // TO HANDLE PAYLOADS
        }
        try {
        this._pushObject.subscribe(topicName).then(success => {
          console.log('Success for sub topic : '+ topicName + ' Result: ' + success);
        }).catch(error => {
          console.log('error for sub topic ' + error);
        });
        } catch (error) {
        }
      });
       //This will be used for Topic selection changed and saved to Preference.
      clsGlobal.pubsub.subscribe('TOPIC_CHANGED', (data: any) => {
        try { 
          if (this._pushObject != null && this._pushObject !== undefined) {

            for (let index = 0; index < data.length; index++) {
              let topicName = data[index].TopicName;
              if (!this.platform.is('android')) {
                topicName = topicName + '_ios'; // TO HANDLE PAYLOADS
              }
              if (data[index].Selected == true) {
                this._pushObject.subscribe(topicName).then(success => {
                  console.log('Topic subscribe success' + success);
                }).catch(error => {
                  this.alertservice.showAlert('subscription error. : ' + error);
                  console.log('Topic subscribe unsuccess' + error);
                });
              }
              else {
                this._pushObject.unsubscribe(topicName).then(success => {
                  console.log('Success for unsub topic : ' + success);
                }).catch(error => {
                  console.log('error for unsub topic ' + error);
                });
              }
            } 
          }
          else {
           //alert("Push object is null"+JSON.stringify(data));
            console.log('data is null');
          }
        } catch (error) {
          console.log('unable to subscribe and unsubscribe.' + error);
          clsGlobal.logManager.writeErrorLog('app.components', 'registerTopicChangeHandlerIn', error);
        }
      });
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('app.components', 'registerTopicChangeHandlerOut', error);
    }
  }
  // initialize language settings.
  setLanguageSettings() {
    try {
      // this code will required in setting page.
      this.localstorageservice.getItem(clsConstants.LOCAL_STORAGE_PREFERRED_LANGUAGE).then(
        (lang) => {
          if (lang == null || lang === undefined) {
            this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_PREFERRED_LANGUAGE, 'english');
            this.preferendLang = 'english'; // if no language is set default will be english
          }
          else {
            this.preferendLang = lang; // previously set language.
            this.localstorageservice.setItem(clsConstants.LOCAL_STORAGE_PREFERRED_LANGUAGE, lang);
          }
          clsGlobal.defaultLanguage = this.preferendLang;
          // this.translate.setDefaultLang(this.preferendLang);
          // this.translate.use(this.preferendLang); // Set your language here
        },
        () => {
          this.toastservice.showAtBottom('Unable to process multilingual settings.');
        }
      );
    } catch (error) {
      this.toastservice.showAtBottom('Error to process multilingual settings.' + error);
    }
  }
  // All plugin initialization by calling pluginsInitialize 
  pluginsInitialize() {
    // create promise object for return
    this.pluginPromise = new Promise(function(resolve, reject) {
      try {
        // device info
        clsPluginConstants.DeviceUDID = this.device.uuid;
        clsPluginConstants.DeviceSerialNo = this.device.serial;
        clsPluginConstants.DeviceModel = this.device.model;
        clsPluginConstants.DeviceManufacturer = this.device.manufacturer;
        clsPluginConstants.DevicePlatform = this.device.platform;
        clsPluginConstants.DevicePlatformVersion = this.device.version;
        // create promis array to initialize application.
        const promises: Array<any> = [];
        // Application info
        promises.push(this.appVersion.getAppName().then((value) => {
          clsPluginConstants.AppName = value;
        }).catch((error) => {
          console.log('Error in getAppName :' + error);
        }));
        promises.push(this.appVersion.getPackageName().then((value) => {
          clsPluginConstants.AppPackageName = value;
          //clsGlobal.LocalComId = clsPluginConstants.AppPackageName.toLocaleLowerCase() + '/';
          //
         //clsGlobal.ComId=clsPluginConstants.AppPackageName.toLocaleLowerCase();
        }).catch((error) => {
          console.log('Error in getPackageName :' + error);
        }));
        promises.push(this.appVersion.getVersionCode().then((value) => {
          clsPluginConstants.AppVersionCode = value.toString();
        }).catch((error) => {
          console.log('Error in getVersionCode :' + error);
        }));
        promises.push(this.appVersion.getVersionNumber().then((value) => {
          clsPluginConstants.AppVersion = value;
        }).catch((error) => {
          console.log('Error in getVersionNumber :' + error);
        }));
        // location info set basic option
        const options = {
          enableHighAccuracy: true,
          timeout: 1000,
          maximumAge: 0
        };
        //geo is not required.
        // promises.push(this.geolocation.getCurrentPosition(options).then((resp) => {
        //   clsPluginConstants.GeoLocLatitude = resp.coords.latitude;
        //   clsPluginConstants.GeoLocLongitude = resp.coords.longitude;
        // }).catch((error) => {
        //   // this.alertProvider.showAlert('Error in location check :' + error.message + " Code :" + error.code);
        //   console.log('Error in location check :' + error.message + " Code :" + error.code+ " string : "+JSON.stringify(error));
        // }));
        this.splashScreen.show();
        Promise.all(promises).then(() => {
          console.log('All plugin promise ' + (new Date()).toLocaleTimeString());
          resolve('true'); // all plugins initialized
        }).catch((error) => {
          reject('Error in plugins ' + error);
        }
        );
      } catch (error) {
        reject('Error in plugins ' + error);
      }
    }.bind(this));
    return this.pluginPromise;
  }
  // notification plugin initialization
  notificationPluginInitialize() {
    // push plugin
    const pushPromise: any = new Promise(function (resolve, reject) {
      if (this.platform.is('ios')) {
        let androidSettings = {
          "forceShow": "true",
          "icon": "logo",
          "iconColor": "#45549f"
        };
        const options1: PushOptions = {
          android: androidSettings,
          ios: {
            alert: 'true',
            badge: true,
            sound: 'false',
            categories: {
              'buycall': {
                'yes': {
                  "callback": "notificationCallback", "title": "BUY", "foreground": true, "destructive": false
                }
              },
              'sellcall': {
                'yes': {
                  'callback': 'notificationCallback', "title": "SELL", "foreground": true, "destructive": false
                }
              }
            }
          }
        }
        // this._pushObject: PushObject = null;
        try {
          this._pushObject = this.pushServiceObject.init(options1);
        } catch (error) {
          // this.alertProvider.showAlert("Push init :" + error);
        }
        this._pushObject.on('notificationCallback').subscribe((notification: any) => {
          try {
            // this.alertProvider.showAlert("Notification callback. : "+JSON.stringify(notification));
            const action = notification.additionalData.actions[0].title.toUpperCase() == 'SELL' ? 'SELL' : 'BUY';
            this.doPushBuySellAction(action, notification.additionalData.callbackData);
          } catch (error) {
            // this.alertProvider.showAlert(error);
            clsGlobal.logManager.writeErrorLog('app.component', 'notificationcallBack', 'Error in notification service.' + error);
          }
        });
        this._pushObject.on('notification').subscribe((notification: any) => {
          //if (clsGlobal.pushPopUpDisplay) {
            this.toastservice.showWithButton(notification.message);
          //}
          if (this.platform.is('ios') && notification.additionalData.category != undefined) {
            notification.additionalData.callbackData = JSON.parse(notification.additionalData.callbackData);
            const action = notification.callbackData.action.toUpperCase();
            this.doPushBuySellAction(action, notification.additionalData.callbackData);
            return;
          }
        });
        this._pushObject.on('registration').subscribe((registration: any) => {
          clsPluginConstants.fcmRegKey = registration.registrationId;
          console.log("FCM key "+clsPluginConstants.fcmRegKey);
          let _defaultTopics = ['all', 'android', 'ios_ios'];
          for (let index = 0; index < _defaultTopics.length; index++) {

            if (this.platform.is('android') && _defaultTopics[index].indexOf('ios') >= 0) {
              continue;
            }
            if (this.platform.is('iphone') && _defaultTopics[index].indexOf('android') >= 0) {
              continue;
            }

            this._pushObject.subscribe(_defaultTopics[index].toString).then(success => {
              //alert("Topic default subscribed.");
              console.log("Topic subscription success : " + success);
            }).catch(error => {
              console.log("Topic subscription error : " + error);
            });
          }
          
        });
        this._pushObject.on('error').subscribe(error => {
          clsGlobal.logManager.writeErrorLog("app.component", "push registration", "Error in notification service." + error);
        });
        resolve("push enable");
      }
      else {
        this.pushServiceObject.hasPermission().then((res: any) => {
          if (res.isEnabled) {
            //this.alertProvider.showAlert('We have permission to send push notifications');
            //let _SenderId = "42117268680";//My local File.
            //let _SenderId = "16580933521"; //LIVE Nirmal Bang ID
            //var _SenderId = "921980726771"; //NBTESTjson
            //alert("SENDER ID " + _SenderId);
            let androidSettings = {
              "forceShow": "true",
              "icon": "logo",
              "iconColor": "#45549f"
            };
            let options1: PushOptions = {
              android: androidSettings,
              ios: {
                alert: 'true',
                badge: true,
                sound: 'false',
                categories: {
                  "buycall": {
                    "yes": {
                      "callback": "notificationCallback", "title": "BUY", "foreground": true, "destructive": false
                    }
                  },
                  "sellcall": {
                    "yes": {
                      "callback": "notificationCallback", "title": "SELL", "foreground": true, "destructive": false
                    }
                  }
                }
              }
            }
            // this._pushObject: PushObject = null;
            try {
              this._pushObject = this.pushServiceObject.init(options1);
            } catch (error) {
              //this.alertProvider.showAlert("Push init :" + error);
            }
            this._pushObject.on('notificationCallback').subscribe((notification: any) => {
              try {
                //this.alertProvider.showAlert("Notification callback. : "+JSON.stringify(notification));
                //alert("Notification callback. : "+JSON.stringify(notification));
                let action = notification.additionalData.actions[0].title.toUpperCase() == "SELL" ? "SELL" : "BUY";
                this.doPushBuySellAction(action, notification.additionalData.callbackData);
              } catch (error) {
                //this.alertProvider.showAlert(error);
                alert("Notification call back error: "+error);
                clsGlobal.logManager.writeErrorLog("app.component", "notificationcallBack", "Error in notification service." + error);
              }
            });
            this._pushObject.on('notification').subscribe((notification: any) => {
              //alert("Notification callback. : "+JSON.stringify(notification));
              //if (clsGlobal.pushPopUpDisplay)
               try {
                this.toastservice.showWithButton(notification.message); 
                if (this.platform.is('ios') && notification.additionalData.category != undefined) {
                  notification.additionalData.callbackData = JSON.parse(notification.additionalData.callbackData);
                  let action = notification.callbackData.action.toUpperCase();
                  this.doPushBuySellAction(action, notification.additionalData.callbackData);
                  return;
                }
               } catch (error) {
                 alert("Error in notification received and show "+error);
               }
            });
            this._pushObject.on('registration').subscribe((registration: any) => {
              //alert("FCM Reg id "+registration.registrationId);
              clsPluginConstants.fcmRegKey = registration.registrationId;
              this._pushObject.subscribe("all").then(success => {
                console.log("Topic 'all' subscription success : " + success);
              }).catch(error => {
                console.log("Topic 'all' subscription error : " + error);
              });
              try { 
                this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getFCMUserTopicDetails').subscribe(((respData: any) => {
                  if (respData.status) {
                    try {
                      let dataResultarr = respData.result;
                      for (var i = 0; i < dataResultarr.length; i++) {
                        if (dataResultarr[i].bSystemDefined == 1) {
                          let topicName = dataResultarr[i].sTopicName;
                          if (this.platform.is('android') && topicName.indexOf('ios') >= 0) {
                            continue;
                          }
                          if (this.platform.is('iphone') && topicName.indexOf('android') >= 0) {
                            continue;
                          }
                          if (topicName.toLowerCase() == "registered".toLowerCase())
                            continue;
                          if (this.platform.is('ios')) {
                            topicName = topicName + "_ios"; //TO HANDLE PAYLOADS
                          }
                          this._pushObject.subscribe(topicName).then(success => {
                            console.log("Topic subscription success : " + success);
                          }).catch(error => {
                            console.log("Topic subscription error : " + error);
                          });
                        }
                        // Checking for if data to show? if > 0 means data to show is present
                      }
                    } catch (error) {
                      //alert("Error in topic fetch 1."+error.message);
                      console.log("FCM Topic fetch error "+error.message);
                      clsGlobal.logManager.writeErrorLog('app.components', 'getFcmUserTopicDetails', error);
                    }
                  }
                }), error => {
                   //alert("Error in topic fetch."+error);
                  clsGlobal.logManager.writeErrorLog('app.components', 'getFcmUserTopicDetails', error);
                });
              } catch (error) {
                alert("Error in Registration topic fetch ."+error);
              }
            });
            this._pushObject.on('error').subscribe(error => {
              clsGlobal.logManager.writeErrorLog("app.component", "push registration", "Error in notification service." + error);
            });
            resolve("push enable");
          } else {
            resolve("push not enable error no permission.");
            console.log('We do not have permission to send push notifications:');
            clsGlobal.logManager.writeErrorLog('app.components', 'subscribe unsubscribe', "User has not given permission for push.");
          }
        }).catch(err => {
          resolve("push not enable error" + err);
          //alert("Notification Error 1. : "+err);
          console.log("Notification service error." + err);
          //this.toastservice.showAtBottom("Notification service error." + err);
        });
      }
    }.bind(this));
    return pushPromise;
  }


  async doPushBuySellAction(action: string, notification: any) {
    try {
      // alert("Buy Call back call :" + (new Date()).toLocaleTimeString());
     //  alert(" BUY 2 additionaldata.callbackData :" + JSON.stringify(notification));
      let strAction = action;
      let nMarketSegId = notification.scrip.split("$")[0];
      let nToken = notification.scrip.split("$")[1];

      //if logged in we will fetch scrip object and push OE page.
      if (clsGlobal.User.OCToken != null && clsGlobal.User.OCToken != undefined && clsGlobal.User.OCToken != '') {
        let Token = nToken;
        let mktSegId = clsTradingMethods.GetMarketSegmentID(nMarketSegId)
        let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

        let req = { scrips: [{ "mkt": exchange, "token": Token }] };

        await clsTradingMethods.getScripInfoElasticSearch(req, this.httpService).then((scripData: any) => {
          let scripObj=null;
          let isBracketAllowed=false;
          let isCoverAllowed=false;
          try {
            if (scripData.status == true) {
              try {
                if (scripData != undefined && scripData.result.length > 0) {
                  for (let index = 0; index < scripData.result.length; index++) {
                    const element = scripData.result[index];
                    scripObj = clsCommonMethods.getScripObject(element).scripDetail;
                  }
                }
                if (scripObj != undefined) {
                  let objOEFormDetail: clsOEFormDetl = new clsOEFormDetl();
                  //objOEFormDetail.buySell = strAction == "BUY" ? clsConstants.C_V_ORDER_BUY : clsConstants.C_V_ORDER_SELL;
                  objOEFormDetail.buyQty = 1;
                  objOEFormDetail.sellQty = 1;
                  objOEFormDetail.orderQty = 1;
    
                  if (strAction == clsConstants.C_S_ORDER_BUY_TEXT) {
                    objOEFormDetail.buySell = clsConstants.C_V_ORDER_BUY;
                    objOEFormDetail.buyPrice = notification.price;
                  }
                  else {
                    objOEFormDetail.buySell = clsConstants.C_V_ORDER_SELL;
                    objOEFormDetail.sellPrice = notification.price;
                  }
                  //checking if Bracket and cover allowed.
                  for(let index = 1 ; index < clsGlobal.User.productTypesList.length; index++){
                    if(clsGlobal.User.productTypesList[index] == "BRACKET"){
                       isBracketAllowed = true;
                    }
                    if(clsGlobal.User.productTypesList[index] == "COVER"){
                       isCoverAllowed = true;
                    }
                  }
                  let  productType = clsGlobal.User.userPreference == undefined || clsGlobal.User.userPreference.sOrder == null || clsGlobal.User.userPreference.sOrder == undefined ? "INTRADAY": JSON.parse(clsGlobal.User.userPreference.sOrder).productType;       
                  if (notification.slprice != "" && notification.sqprice == "") {
                    objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;//clsConstants.C_S_ORDER_STOPLOSS_MARKET_TEXT//"sl-mkt";//cover
                    objOEFormDetail.recoSQprice = 0; //item.sRecoDetails[0].SQPrice;
                    objOEFormDetail.recoSLprice = notification.slprice; 
                    if(isCoverAllowed){
                      objOEFormDetail.productType = "COVER";
                    }else{
                      objOEFormDetail.productType = productType;
                    }
                  }
                 else if (notification.slprice != "" && notification.sqprice != "") {
                    if (notification.price!=undefined && notification.price != "0") {
                      objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT;//C_S_ORDER_REGULARLOT_TEXT;//"rl";//bracket 
                    }
                    else {
                      objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_MARKET_TEXT;
                    }
                    objOEFormDetail.recoSQprice = notification.sqprice;
                    objOEFormDetail.recoSLprice = notification.slprice;
                    if (isBracketAllowed) {
                      objOEFormDetail.productType = "BRACKET";
                    } else {
                      objOEFormDetail.productType = productType;
                    }
                  }
                  else{
                    objOEFormDetail.recoSQprice = 0;//item.sRecoDetails[0].SQPrice;
                    objOEFormDetail.recoSLprice = 0;//item.sRecoDetails[0].SLPrice;
                    objOEFormDetail.orderType = clsConstants.C_S_ORDER_REGULARLOT_TEXT; //"rl";//normal
                    if(productType == "DELIVERY" && (exchange == clsConstants.C_S_NSE_DERV_API || exchange == clsConstants.C_S_BSE_DERV_API 
                      ||  exchange == clsConstants.C_S_MCX_DERV_API ||  exchange == clsConstants. C_S_ICEX_DERV_API 
                      ||  exchange == clsConstants.C_S_NCDEX_DERV_API) ){
                        objOEFormDetail.productType = "CARRYFORWARD";
                      }
                      else{
                        objOEFormDetail.productType = productType;
                      }
                  } 
  
                  objOEFormDetail.orderPrice = notification.price;
                  objOEFormDetail.scripDetl = scripObj;
                  objOEFormDetail.pageSource = clsConstants.C_V_RECOMMENDATION_PAGE;
                  objOEFormDetail.recoId = notification.recoId; 
                  this.navParam.myParam = objOEFormDetail; 
                  this.navCtrl.navigateForward("orderentry");
                } 
              } catch (error) {
                alert("Error in creating Order entry :"+error);
              }
            } else {
              console.log("Unable to fetch scrip details: ", Token, " ", exchange);
              return;
            }
          } catch (error) {
            alert("Error in Opening Order Entry. "+error);
          }
        });   
      }
      else { 
        //set global object since it is not logged in when logged in on dashboard page it will handle.
        clsGlobal.pushOEObj = { Action: strAction, MktSegId: nMarketSegId, Token: nToken, NotificationPrice: notification.price, RecoId: notification.recoId ,notificationobj:notification};
      }
    } catch (e) {
      //this.alertProvider.showAlert("script object. error1 : "+e);
      alert("Error in scrip obj creation :"+e);
      clsGlobal.logManager.writeErrorLog('app.component', 'doPushBuySellAction', e);
    }
    finally {
      /*  this._pushObject.finish(notification.recoId).then(() => {
         console.log('accept callback finished');
       }, () => {
         console.log('accept callback failed');
       }); */
    }
  }
  // hardware back button handling
  // active hardware back button
  backButtonEvent() {
    this.platform.backButton.subscribe(async () => {
      console.log("Back button click");
      this.routerOutlets.forEach((outlet: IonRouterOutlet) => {
        console.log("Back button click 2 URL: "+this.router.url);
        if (outlet && outlet.canGoBack()) {
          outlet.pop();
        } else {
          if (new Date().getTime() - this.lastTimeBackPress < this.timePeriodToExit) {
            navigator['app'].exitApp(); // work in ionic 4
          } else {
            this.toastservice.showAtBottom(`Press back again to exit App.`);
            this.lastTimeBackPress = new Date().getTime();
          }
        }
      });
    });
  }  
  setKeyboardListner()
  {
    window.addEventListener('keyboardDidShow', (event: any) => {
      clsGlobal.isKeyBoardOpen = true;
      clsGlobal.pubsub.publish("KEYBOARDSHOW");
    });
    window.addEventListener('keyboardWillHide', () => {
      clsGlobal.pubsub.publish("KEYBOARDHIDE");
      clsGlobal.isKeyBoardOpen = false;
    });
  }
  
  async getFcmUserTopicDetails() {
    try {
      await this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getFCMUserTopicDetails').subscribe(((respData: any) => {
        if (respData.status) {
          let dataResultarr = respData.result;
          clsGlobal.lstTopicList = dataResultarr;//Globally store data.
          let topicList = [];
          for (var i = 0; i < dataResultarr.length; i++) {
            if (dataResultarr[i].bSystemDefined != 1 && (dataResultarr[i].bIsCompalsary != 0 && dataResultarr[i].bIsDisplay != 0)) {
              topicList.push({
                TopicNo: dataResultarr[i].nTopicNo,
                TopicName: dataResultarr[i].sTopicName,
                TopicDisplayName: dataResultarr[i].sTopicDisplayName,
                bIsCompalsary: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false,
                bIsDisplay: parseInt(dataResultarr[i].bIsDisplay) > 0 ? true : false,
                //if topic is compalsory we will set selected by default
                Selected: parseInt(dataResultarr[i].bIsCompalsory) > 0 ? true : false

              });
            }
          }
          clsGlobal.lstTopicList = topicList;//Globally store data.
        }
        else {
          console.log("Fcm topic list not available");
        }
      }), error => {
        console.log("Error getFcmUserTopicDetails_1", error);
        clsGlobal.logManager.writeErrorLog('AppComponent', 'getFcmUserTopicDetails_2', error);
      });
    } catch (error) {
      console.log(error);
    }
  }
}


function ionicWebFunc()
{
  this.on_module_name = function(param){
    console.log( 'on_module_name ' + param );
    GET_ENVIRONMENT();
    GET_PARTNER_ID();
    GET_ENCRYPTED_AUTH_DATA();
    GET_USER_CONFIG();
    GET_MODULE_NAME();
    GET_SESSION_PING_CONFIG();
  };

  this.on_session_ping_config = function(param) {
    console.log( 'on_session_ping_config ' + param );
  }

  this.on_environment = function(param) {
    console.log( 'on_environment ' + param );
  }

  this.on_partner_id = function(param) {
    console.log( 'on_partner_id ' + param );
  }

  this.on_encrypted_auth_data = function(param) {
    console.log( 'on_encrypted_auth_data ' + param );
  }

  this.on_user_config = function(param) {
    console.log( 'on_user_config ' + param );
  }

  this.on_ping = function() {
    console.log( 'on_ping ');
  }

  
}
(window as any).WebFunctions = new ionicWebFunc();

function GET_ENVIRONMENT() {
  const json = {
    "action": "get_environment",
    "action_data": {
      "message":"get_environment"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_ENVIRONMENT responce ' + responce);
}

function GET_PARTNER_ID() {
  const json = {
    "action": "get_partner_id",
    "action_data": {
      "message":"get_partner_id"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_PARTNER_ID responce ' + responce);
}

function GET_ENCRYPTED_AUTH_DATA() {
  const json = {
    "action": "get_encrypted_auth_data",
    "action_data": {
      "message":"get_encrypted_auth_data"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_ENCRYPTED_AUTH_DATA responce ' + responce);
}

function GET_USER_CONFIG() {
  const json = {
    "action": "get_user_config",
    "action_data": {
      "message":"get_user_config"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_USER_CONFIG responce ' + responce);
}

function GET_MODULE_NAME() {
  const json = {
    "action": "get_module_name",
    "action_data": {
      "message":"get_module_name"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_MODULE_NAME responce ' + responce);
}

function GET_SESSION_PING_CONFIG() {
  const json = {
    "action": "get_session_ping_config",
    "action_data": {
      "message":"get_session_ping_config"
    }
  }
  const responce = NativeFunctions.callback(JSON.stringify(json));
  console.log('GET_SESSION_PING_CONFIG responce ' + responce);
}