import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [ 
  {
    path: 'initialize',
    loadChildren: () => import('./pages/initialize/initialize.module').then( m => m.InitializePageModule)
  },
  // {
  //   path: '',
  //   redirectTo: 'initialize',
  //   pathMatch: 'full'
  // },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'signin',
    loadChildren: () => import('./pages/signin/signin.module').then( m => m.SigninPageModule)
  },
  {
    path: 'watchlist',
    loadChildren: () => import('./pages/watchlist/watchlist.module').then( m => m.WatchlistPageModule)
  },
  {
    path: 'mpinlogin',
    loadChildren: () => import('./pages/mpinlogin/mpinlogin.module').then( m => m.MpinloginPageModule)
  },
  {
    path: 'forgotpassword',
    loadChildren: () => import('./pages/forgotpassword/forgotpassword.module').then( m => m.ForgotpasswordPageModule)
  },
  {
    path: 'forgetmpin',
    loadChildren: () => import('./pages/forgetmpin/forgetmpin.module').then( m => m.ForgetmpinPageModule)
  },
  {
    path: 'changempin',
    loadChildren: () => import('./pages/changempin/changempin.module').then( m => m.ChangempinPageModule)
  } ,
  {
    path: 'changepassword',
    loadChildren: () => import('./pages/changepassword/changepassword.module').then( m => m.ChangepasswordPageModule)
  },
  {
    path: 'lookup',
    loadChildren: () => import('./pages/lookup/lookup.module').then( m => m.LookupPageModule)
  },
  {
    path: 'create-watch-list',
    loadChildren: () => import('./pages/create-watch-list/create-watch-list.module').then( m => m.CreateWatchListPageModule)
  },
  {
    path: 'watchlistfilter',
    loadChildren: () => import('./pages/watchlistfilter/watchlistfilter.module').then( m => m.WatchlistfilterPageModule)
  },
  {
    path: 'menuhamburger',
    loadChildren: () => import('./pages/menuhamburger/menuhamburger.module').then( m => m.MenuhamburgerPageModule)
  },
  {
    path: 'scripinfo',
    loadChildren: () => import('./pages/scripinfo/scripinfo.module').then( m => m.ScripinfoPageModule)
  },
  {
    path: 'orderentry',
    loadChildren: () => import('./pages/orderentry/orderentry.module').then( m => m.OrderentryPageModule)
  },
  {
    path: 'orderconfirmation',
    loadChildren: () => import('./pages/orderconfirmation/orderconfirmation.module').then( m => m.OrderconfirmationPageModule)
  },
  {
    path: 'registration',
    loadChildren: () => import('./pages/registration/registration.module').then( m => m.RegistrationPageModule)
  },
  {
    path: 'transaction',
    loadChildren: () => import('./pages/transaction/transaction.module').then( m => m.TransactionPageModule)
  },
  {
    path: 'setmpin',
    loadChildren: () => import('./pages/setmpin/setmpin.module').then( m => m.SetmpinPageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./pages/profile/profile.module').then( m => m.ProfilePageModule)
  },
  {
    path: 'marketmain',
    loadChildren: () => import('./pages/marketmain/marketmain.module').then( m => m.MarketmainPageModule)
  },
  {
    path: 'recommendation',
    loadChildren: () => import('./pages/recommendation/recommendation.module').then( m => m.RecommendationPageModule)
  },
  {
    path: 'portfolio',
    loadChildren: () => import('./pages/portfolio/portfolio.module').then( m => m.PortfolioPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./pages/settings/settings.module').then( m => m.SettingsPageModule)
  },
  {
    path: 'invitefriends',
    loadChildren: () => import('./pages/invitefriends/invitefriends.module').then( m => m.InvitefriendsPageModule)
  },
  {
    path: 'help',
    loadChildren: () => import('./pages/help/help.module').then( m => m.HelpPageModule)
  },
  {
    path: 'messages',
    loadChildren: () => import('./pages/messages/messages.module').then( m => m.MessagesPageModule)
  },
  {
    path: 'widgets',
    loadChildren: () => import('./pages/widgets/widgets.module').then( m => m.WidgetsPageModule)
  },
  {
    path: 'managealerts',
    loadChildren: () => import('./pages/managealerts/managealerts.module').then( m => m.ManagealertsPageModule)
  },
  {
    path: 'scripinfo',
    loadChildren: () => import('./pages/scripinfo/scripinfo.module').then(m => m.ScripinfoPageModule)
  },  
  {
    path: 'setalerts',
    loadChildren: () => import('./pages/setalerts/setalerts.module').then( m => m.SetalertsPageModule)
  },
  {
    path: 'testpage',
    loadChildren: () => import('./pages/testpage/testpage.module').then( m => m.TestpagePageModule)
  },
  // {
  //   path: 'netposition',
  //   loadChildren: () => import('./pages/netposition/netposition.module').then( m => m.NetpositionPageModule)
  // },
  {
    path: 'marektnews',
    loadChildren: () => import('./pages/marektnews/marektnews.module').then( m => m.MarektnewsPageModule)
  },
  {
    path: 'indexview',
    loadChildren: () => import('./pages/indexview/indexview.module').then( m => m.IndexviewPageModule)
  },
  {
    path: 'indexviewdetails',
    loadChildren: () => import('./pages/indexviewdetails/indexviewdetails.module').then( m => m.IndexviewdetailsPageModule)
  },
  {
    path: 'create-watch-list-existing',
    loadChildren: () => import('./pages/create-watch-list-existing/create-watch-list-existing.module').then( m => m.CreateWatchListExistingPageModule)
  },
  {
    path : 'squareoff-orders',
    loadChildren: () => import('./pages/squareoff-orders/squareoff-orders.module').then( m => m.SquareoffOrdersPageModule)
  },
  {
    path: 'create-watch-list-global',
    loadChildren: () => import('./pages/create-watch-list-global/create-watch-list-global.module').then( m => m.CreateWatchListGlobalPageModule)
  },
  {
    path: 'needhelp',
    loadChildren: () => import('./pages/needhelp/needhelp.module').then( m => m.NeedhelpPageModule)
  },
  {
    path: 'fundsmain',
    loadChildren: () => import('./pages/fundsmain/fundsmain.module').then( m => m.FundsmainPageModule)
  },
  {
    path: 'fundsadd',
    loadChildren: () => import('./pages/fundsadd/fundsadd.module').then( m => m.FundsaddPageModule)
  },
  {
    path: 'fundsavailable',
    loadChildren: () => import('./pages/fundsavailable/fundsavailable.module').then( m => m.FundsavailablePageModule)
  },
  {
    path: 'screener-main',
    loadChildren: () => import('./pages/screener-main/screener-main.module').then( m => m.ScreenerMainPageModule)
  },
  {
    path: 'screener-view',
    loadChildren: () => import('./pages/screener-view/screener-view.module').then( m => m.ScreenerViewPageModule)
  },
  {
    path: 'fundswithdraw',
    loadChildren: () => import('./pages/fundswithdraw/fundswithdraw.module').then( m => m.FundswithdrawPageModule)
  },
  {
    path: 'fundstransfer',
    loadChildren: () => import('./pages/fundstransfer/fundstransfer.module').then( m => m.FundstransferPageModule)
  },
  {
    path: 'fundstransaction',
    loadChildren: () => import('./pages/fundstransaction/fundstransaction.module').then( m => m.FundstransactionPageModule)
  },
  {
    path: 'cancel-orders',
    loadChildren: () => import('./pages/cancel-orders/cancel-orders.module').then( m => m.CancelOrdersPageModule)
  },
  {
    path: 'watchlist-remove-reorder',
    loadChildren: () => import('./pages/watchlist-remove-reorder/watchlist-remove-reorder.module').then( m => m.WatchlistRemoveReorderPageModule)
  }, 
  {
    path: 'calculators-main',
    loadChildren: () => import('./pages/calculators-main/calculators-main.module').then( m => m.CalculatorsMainPageModule)
  },
  {
    path: 'calculators-fairvalue',
    loadChildren: () => import('./pages/calculators-fairvalue/calculators-fairvalue.module').then( m => m.CalculatorsFairvaluePageModule)
  },
  {
    path: 'calculators-optionvalue',
    loadChildren: () => import('./pages/calculators-optionvalue/calculators-optionvalue.module').then( m => m.CalculatorsOptionvaluePageModule)
  },
  {
    path: 'calculators-spanmargin',
    loadChildren: () => import('./pages/calculators-spanmargin/calculators-spanmargin.module').then( m => m.CalculatorsSpanmarginPageModule)
  },
  {
    path: 'calculator-lookup',
    loadChildren: () => import('./pages/calculator-lookup/calculator-lookup.module').then( m => m.CalculatorLookupPageModule)
  },
  {
    path: 'advance-chart-iq',
    loadChildren: () => import('./pages/advance-chart-iq/advance-chart-iq.module').then( m => m.AdvanceChartIqPageModule)
  },
  {
    path: 'fingerprint-enable',
    loadChildren: () => import('./pages/fingerprint-enable/fingerprint-enable.module').then( m => m.FingerprintEnablePageModule)
  },
  {
    path: 'push-notifications',
    loadChildren: () => import('./pages/push-notifications/push-notifications.module').then( m => m.PushNotificationsPageModule)
  },
  {
    path: 'in-app-notifications',
    loadChildren: () => import('./pages/in-app-notifications/in-app-notifications.module').then( m => m.InAppNotificationsPageModule)
  },
  {
    path: 'indexviewdetailslookup',
    loadChildren: () => import('./pages/indexviewdetailslookup/indexviewdetailslookup.module').then( m => m.IndexviewdetailslookupPageModule)
  },
  {
    path: 'links',
    loadChildren: () => import('./pages/links/links.module').then( m => m.LinksPageModule)
  },
  {
    path: 'sso-links',
    loadChildren: () => import('./pages/sso-links/sso-links.module').then( m => m.SsoLinksPageModule)
  },
  {
    path: 'order-protection',
    loadChildren: () => import('./pages/order-protection/order-protection.module').then( m => m.OrderProtectionPageModule)
  },
  {
    path: 'order-product-type',
    loadChildren: () => import('./pages/order-product-type/order-product-type.module').then( m => m.OrderProductTypePageModule)
  },
  {
    path: 'fii-dii-mf',
    loadChildren: () => import('./pages/fii-dii-mf/fii-dii-mf.module').then( m => m.FiiDiiMfPageModule)
  },
  {
    path: 'marketnews-lookup',
    loadChildren: () => import('./pages/marketnews-lookup/marketnews-lookup.module').then( m => m.MarketnewsLookupPageModule)
  },
  {
    path: 'uatenvionment-setting',
    loadChildren: () => import('./pages/uatenvionment-setting/uatenvionment-setting.module').then( m => m.UATEnvionmentSettingPageModule)
  },
  {
    path: 'bulk-block-deals',
    loadChildren: () => import('./pages/bulk-block-deals/bulk-block-deals.module').then( m => m.BulkBlockDealsPageModule)
  },
  {
    path: 'merger-demerger-details',
    loadChildren: () => import('./pages/merger-demerger-details/merger-demerger-details.module').then( m => m.MergerDemergerDetailsPageModule)
  },
  {
    path: 'e-dis-permission',
    loadChildren: () => import('./pages/e-dis-permission/e-dis-permission.module').then( m => m.EDISPermissionPageModule)
  },
  // {
  //   path: 'multileg-confirmation',
  //   loadChildren: () => import('./pages/multileg-confirmation/multileg-confirmation.module').then( m => m.MultilegConfirmationPageModule)
  // },
  {
    path: 'multileg-result',
    loadChildren: () => import('./pages/multileg-result/multileg-result.module').then( m => m.MultilegResultPageModule)
  },
  // {
  //   path: 'multileg-lookup',
  //   loadChildren: () => import('./pages/multileg-lookup/multileg-lookup.module').then( m => m.MultilegLookupPageModule)
  // },

{
    path: 'introp-orderentry',
    loadChildren: () => import('./pages/introp-orderentry/introp-orderentry.module').then( m => m.IntropOrderentryPageModule)
  },
  {
    path: 'spread-orderentry',
    loadChildren: () => import('./pages/spread-orderentry/spread-orderentry.module').then( m => m.SpreadOrderentryPageModule)
  },
  {
    path: 'premium-discount',
    loadChildren: () => import('./pages/premium-discount/premium-discount.module').then( m => m.PremiumDiscountPageModule)
  },
  {
    path: 'network-error',
    loadChildren: () => import('./pages/network-error/network-error.module').then( m => m.NetworkErrorPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
