import { Injectable } from '@angular/core';
import {AlertController } from '@ionic/angular';
import { clsGlobal, clsPluginConstants } from '../../Common/clsGlobal';

@Injectable({ providedIn: 'root' })
export class AlertServicesProvider { 
  constructor(
   private alertCtrl: AlertController

  ) {

    //console.log('Hello AlertServicesProvider Provider');
  }
 /**
  * Added and updated by Omprakash on 18 Jan 2019
  * @param message , string value , will display as message.
  * @param title , this is optional parameter , if not provide then application package name will display.
  */

 async showAlert(message: string ,title?: string) {
    let titleString : string =(title==""?clsGlobal.ApplicationName:title);
    const alert = await this.alertCtrl.create(
      {
        header :titleString,
        //subTitle: message,
        mode : "md",
        message:message,
        buttons: [
          {
            text: 'OK'
          }
        ]
      });

      return await alert.present();
  }
  /**
  * Added and updated by Omprakash on 18 Jan 2019
  * This method return promise with button click , usefull in Confirmation
  * @param message , string value , will display as message.
  * @param title , this is optional parameter , if not provide then application package name will display.
   */
   showAlertWithCallback( message: string,title?: string,): Promise<boolean> {
    let titleString : string =(title==""?clsPluginConstants.AppPackageName:title);
    return new Promise(async(resolve, reject) => {
      const confirm = await this.alertCtrl.create({
        header:titleString,
        mode : "md",
        message:' <img src="../../assets/img/light/extra-img/alert.svg" alt="alert" class="alert-icon"> ' + '<span class="alert-message-inner">' + message + '</span>',
        cssClass: clsGlobal.defaultTheme ,
        buttons: [{
          text: 'Confirm',
          handler: () => {
            confirm.dismiss().then(() => resolve(true));
            return false;
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            confirm.dismiss().then(() => resolve(false));
            return false;
          }
        }]
      });
  
      return await confirm.present();

    });
  }
   /**
  * Added and updated by Chetan on 03 APR 2019
  * This method return promise with button click , usefull in Confirmation
  * @param message , string value , will display as message.
  * @param title , this is optional parameter , if not provide then application package name will display.
   */
  showAlertCallbackWithSingleButton(message: string ,title?: string) {
    let titleString : string =(title==""?clsGlobal.ApplicationName:title);
    return new Promise(async(resolve, reject) => {
    const alert = await this.alertCtrl.create(
      {
        header :titleString,
        //subTitle: message,
        mode : "md",
        message:message,
        cssClass: clsGlobal.defaultTheme ,
        //enableBackdropDismiss : false ,
        buttons: [
          {
            text: 'OK',
           handler: () => {
            alert.dismiss()
            .then(() => {
              console.log("alert close success");
              resolve(true);
            }).
            catch(error=>{
              console.log("unable to dismiss alert"+error);
              reject(true);
            });
            return false;
          }
          }
        ]
      });
    return await alert.present();
  });
  }

  /**
 * This method is to display alert box with two buttons
* first button always will be yes , ok or confirm
* second button will be cancel no reject etc.
* @param title , string value , will display as message.
* @param message,
*  @param buttons, array of buttons(max 2)
*  @param successcallback, success callback
*  @param failcallback, reject,no cancell callback
   */
  async showAlertConfirmWithButtons(title: any, message: any, buttons: any,successcallback:any,failcallback:any) {
    let titleString: string = (title == "" ? clsGlobal.ApplicationName : title);

      const confirm = await this.alertCtrl.create({
        header: titleString,
        message: message,
        mode : "md",
        cssClass: clsGlobal.defaultTheme,
        buttons: [
          {
            text: buttons[0],
            handler: () => {
              successcallback();
            }
          },
          {
            text: buttons[1],
            role: 'cancel',
            handler: () => {
              failcallback();
            }
          }
        ]
      });
      
      await confirm.present();

  }
  async showPromtBox(successcallback:any,failcallback:any)
  {
    let titleString: string = "";

    const confirm = await this.alertCtrl.create({
      header: titleString,
      message: "Set com Id and API key if you want to change, else cancel it.",
      mode : "md",
      inputs: [
        {
          name: 'comId',
          placeholder: 'Eg. com.wave.dev',
          
        },
        {
          name: 'apiKey',
          placeholder: 'Eg. eyJhbGciOiJIUzI1NiJ9',
          
        }
      ],
      buttons: [
        {
          text: 'Done',
          handler: (data: any) => {
            successcallback(data);
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            failcallback();
          }
        }
      ]
    }); 
    await confirm.present();
  }
}

