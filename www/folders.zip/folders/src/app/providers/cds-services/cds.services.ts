import { Injectable } from '@angular/core';
import { clsHttpService } from '../../Common/clsHTTPService';
import { clsGlobal } from '../../Common/clsGlobal';
@Injectable({ providedIn: 'root' })
export class CDSServicesProvider {
    constructor(public objHttpService: clsHttpService

    ) { }

    //All cmot service calls settings.
    //AGM EGM calls
    getAGMEGM(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    let methodname = "GetAGMEGMData"
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getChangeCompanyName() {
        try {
            return new Promise((resolve, reject) => {
                try {
                    let methodname = "GetChangeofNameData"
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    // ****Added By Vivian Fernandes|Code Starts|28-02-2019***

    /** CDS call to get Indian market news,as per following section names,
     1)Equity Pre Session
     2)Equity Mid Session
     3)Equity End Session
     4)Commodity Pre Session
     5)Commodity Mid Session
     6)Commodity End Session
     7)Commodity Abstracts Session
     8)Stock-Alert
     9)Quick-Review
     10)Hot-Pursuit
     11)Corporate-Results
     12)Analyst-Poll
     13)Derivates-News
     14)IPO News
     15)Mutual Fund News
     16)Corporate-News
     17)Insurance news
     18)Foreign-Markets
     19)Other-Markets*/
    getIndianMarketNews(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetIndianMktNewsData", _requestObject)
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });

        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /** CDS call to get Insurance news */
    getInsuranceNews(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetInsuranceNews", _requestObject)
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });

        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /** CDS call to get News Details (Indian Market news)  */
    getNewsDetails(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetNewsDetails", _requestObject)
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });

        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }


    /** CDS call to get Sector List. */
    getSectorList(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+_requestObject,"GetSectorList")
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });


        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /** CDS call to get Sector-Wise-News. */
    getSectorWiseNews(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+_requestObject, "GetSectorWiseNewsData")
                        .subscribe(data => {
                            //resolve(data);
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });


        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /**CDS call to get Sector-Wise-News-details. */
    getSectorWiseNewsDetails(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+_requestObject, "GetSectorWiseNewsDetails")
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });


        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /** CDS call to get Premium | Discount data. */
    getPremiumDiscount(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+ _requestObject, "GetPremiumDiscountData")
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });


        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    /** CDS call to get Insurance news */
    getMergerAcquisitions(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetMergerDemergerData", _requestObject)
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });

        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }
    /** CDS call to get Insurance news */
    getCorporateAction(_requestObject: any) {
        try {

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetCorporateActionCalenderData", _requestObject)
                        .subscribe(data => {
                            var a: string = JSON.stringify(data).replace(/\s/g, " ");
                            //JSON.parse(a);
                            resolve(JSON.parse(a));
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });

        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    //****By Vivian Fernandes|Code Ends.|28-02-2019***

    getAnnouncement(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    let methodname = "GetAnnoucementsData"
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getBoardMeetings(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    let methodname = "GetBoardMeetingsData"
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getCompanyName(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postJson(clsGlobal.URL_CDSSERVER, "GetChangeofNameData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }
    getSectorInfo(_requestObject: any) {

    }
    //created by omprakash on 28 feb
    getBookCloserDetails(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetBookClosureData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getAboutUsData() {
        try {
            //_dataWrappedParameters = { "strRequest": clsGlobal.clsCommonMethods.UrlEncoding(clsGlobal.clsCommonMethods.Encrypt(_strReq)) };

            //"AGM/-/15-Oct-2018/15-Jan-2019/1/10?responsetype=json&apikey=/3qRJ77KD3WLpY+uu0lj4njoHcjf0S64rTJ+By6QSNM=";


            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.get(clsGlobal.VirtualDirectory + "Files/Abouts.txt", "")
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });


        }
        catch (e) {

        }
    }

    /** <Norwin Dcruz> <14/02/2019> <To get Bulk Block Deal Data from CDS> **/
    getBulkBlockDetails(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetBulkBlockDealData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }

    }

    /** <Norwin Dcruz> <14/02/2019> <To get FII DII MF Data from CDS> **/
    getFIIDIIMFDetails(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetFIIDIIMFData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getOpenIpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetIPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }


    getCloseIpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetIPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getForthComingIpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetIPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getIpoFpoSynopsisData(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetIPOSynopsisData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getOpenFpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetFPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCloseFpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetFPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getForthComingFpoList(_requestObject: any) {

        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetFPOData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }


    getHotPursuit(_requestObject: any) {
        try {

            let methodname: string = "GetHotPursuitData";//"http://63moonsproapis.cmots.com/Market.svc/hot-pursuit/10?responsetype=json&apikey=AvhD8x2VdHcR5IfGS0BrXSP8I4O2wVAg+biv8p/pUPM=";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER, _requestObject + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getScripNews(_requestObject: any) {
        try {
            let methodname: string = "GetScripWiseNewsData";//"http://63moonsproapis.cmots.com/Market.svc/ScriptWiseNews/476/3?responsetype=json&apikey=AvhD8x2VdHcR5IfGS0BrXSP8I4O2wVAg+biv8p/pUPM=";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyBackground(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyBackgroundData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanySector(_requestObject: any) {
        try {
            let methodname: string = "GetCompanySectorData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyExchange(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyExchangeData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getBoardofDirectors(_requestObject: any) {
        try {
            let methodname: string = "GetBoardofDirectorData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyResult(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyResultData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyBalanceSheet(_requestObject: any) {

        try {
            let methodname: string = "GetCompanyBalanceSheetData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyFinancialRatio(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyFinancialRatioData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getIndexConstituents(_requestObject: any) {
        try {
            let methodname: string = "GetIndexConstituentsData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getWorldIndices() {
        try {
            let methodname: string = "GetWorldIndicesData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    /**Chetan A
     * desc: method to get authToken from cds server
     * date: 02 March 2019
     * params-userId incase of guest user pass mobile number
     * params - RequestToken is session id
     * params - jProviderCode is data provider vendor
     */
    getAuthToken(UserID: any, RequestToken: string, jProviderCode: string) {
        try {
            let userdata: any = {};
            userdata.parameters.jData.UserID = UserID,
                userdata.parameters.jData.TenantAuthKey = 'A!@#$%^&*()';
            userdata.parameters.jData.RequestToken = RequestToken;
            userdata.parameters.jData.UDID = '';
            userdata.parameters.jProviderCode = "CMOT";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "Authenticate", userdata)
                        .subscribe(data => {
                            resolve(data);
                        }, (error) => {
                            reject("Oops something went wrong. Please try again later.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
            // WWLogManager.WriteLog(e.message, 'SendMessage', 'WCFComm.ts', '');
        }
    }

    getPutCallRatio(_requestObject: any) {
        try {
            let methodname: string = "GetPutCallRatio";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, methodname, _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyProfitLoss(_requestObject: any) {
        try {
            let methodname: string = "GetProfitLossData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyMFHolding(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyWiseMFHolding";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    /**This method is used to fetch cmot data for forthcoming results
     *
     * @param _requestObject
     */

    getForthComingResult(_requestObject: any) {
        try {
            let methodname: string = "GetForthcomingResultsData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getMergerAcquisitionResult(_requestObject: any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, "GetMergerDemergerData", _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyShareHoldingPattern(_requestObject: any) {
        try {
            let methodname: string = "GetShareHoldingPatternData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getDelistedShares(_requestObject: any) {
        try {
            let methodname: string = "GetDelistedSharesData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.postWithHeaders(clsGlobal.URL_CDSSERVER, methodname, _requestObject)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getDivident(_requestObject: any) {
        try {
            let methodname: string = "GetDividentData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getSplits(_requestObject: any) {
        try {
            let methodname: string = "GetSpiltstData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    GetBookClosure(_requestObject: any) {
        try {
            let methodname: string = "GetBookClosure";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    GetBookClosureData(_requestObject: any) {
        try {
            let methodname: string = "GetBookClosureData";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }


    GetMovingAvg(_requestObject: any) {
        try {
            let methodname: string = "GetMovingAverage";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getHealthTotalScore(_requestObject: any) {
        try {
            let methodname: string = "GetHealthTotalScore";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getRightsData(_requestObject: any) {
        try {
            let methodname: string = "GetRightsData"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getBuyBackData(_requestObject: any) {
        try {
            let methodname: string = "GetBuyBack"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getVolumeVsDeliveryData(_requestObject: any) {
        try {
            let methodname: string = "GetVolumeVSDelivery"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getQuarterlyTrend(_requestObject: any) {
        try {
            let methodname: string = "GetQuarterlyTrend"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }
    getComapnyHistory(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyHistory"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCompanyListingInfo(_requestObject: any) {
        try {
            let methodname: string = "GetCompanyListingInformation";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getCdsBroadcast(_requestObject: any) {
        try {
            let methodname: string = "GetQuoteDetails";

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {

                            let respBcast : any = {};
                            respBcast.req = _requestObject;
                            respBcast.resp = data;

                            resolve(respBcast);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getEventData( fromDate , toDate){
        try {
            let methodname: string = "GetMarketEventData";
            let _requestObject :string = "/"+ fromDate +"/" +toDate +"/NSE_EQ/25/1/10"

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + _requestObject, "/" + methodname)
                        .subscribe(data => {

                            let respBcast : any = {};
                            respBcast.req = _requestObject;
                            respBcast.resp = data;

                            resolve(respBcast);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {
           // reject("Unable to fetch data.");
        }
    }

    getFIIDIIMFData(methodName:any) {
        try {
            let methodname: string = methodName;

            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+methodName,"/GetFIIDIIMFData")
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getBulkBlockData(methodName:any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+methodName,"/GetBulkBlockDealData")
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

    getMergerDemergerData(methodName:any) {
        try {
            return new Promise((resolve, reject) => {
                try {
                    this.objHttpService.getWithHeaders(clsGlobal.URL_CDSSERVER + clsGlobal.LocalComId
                        + clsGlobal.versionId + "/"+methodName,"/GetMergerDemergerData")
                        .subscribe(data => {
                            resolve(data);
                        }, error => {
                            reject("Unable to fetch data.");
                        });
                } catch (error) {
                    reject("Unable to fetch data.");
                }
            });
        }
        catch (e) {

        }
    }

}
