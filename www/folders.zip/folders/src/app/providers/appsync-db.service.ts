import { clsLocalStorageService } from './../Common/clsLocalStorageService';
import { Injectable } from '@angular/core';
import { Auth, DataStore, Hub, syncExpression } from 'aws-amplify';
import { AppInfo, MsgInfo, NewWatchListProfile, NewWatchListScrips, UserPreference } from 'src/models';
import { DISCARD, Predicates } from "@aws-amplify/datastore";
import { clsGlobal } from '../Common/clsGlobal';
import { ConditionalExpr } from '@angular/compiler';
import { Platform } from '@ionic/angular';
@Injectable({
  providedIn: 'root'
})
export class AppsyncDbService {
  private resolveFnc: any;
  private rejectFnc: any;
  constructor(private platform: Platform,
    public objStorage: clsLocalStorageService
  ) {
  }
  async initializeAppsync() {
    try {
      return await new Promise((resolve, reject) => {
        console.log('I must be first to call.');
        this.resolveFnc = resolve;
        this.rejectFnc = reject;
        // login and syncing for Prelogin. 
        //this.confiltResolutionPreLogin(); 
        this.confiltResolution();
        this.checkingSyncComplete();
        //tenant wise login.
        //this.signingCognito(clsGlobal.ComId, clsGlobal.ComId, "admin@" + clsGlobal.ComId);
        this.signingCognito(clsGlobal.ComId, clsGlobal.ComId, "admin@" + "63moons.com");
        //check sync complete , when sync complete and ready done , promise return.

      });
    } catch (error) {
      alert("Error in init call " + error);
      return this.rejectFnc(false);
    }
  }
  /**
   * This will be call to login to APP SYNC.
   */
  async signingCognitoForTradingUser() {
    try {
      await this.signOutCognito(clsGlobal.ComId).then(async (result) => {
        await this.signingCognito(clsGlobal.User.userId, clsGlobal.User.userId + "123", clsGlobal.User.userId + "@" + "63moons.com").then((result) => {
          console.log("APP Sync Signing successful...");
          clsGlobal.pubsub.publish("MENU_THEME");
          // this.getUserPreferenceData().then((res: any) => {
          //   if (res != undefined && res.length > 0) {
          //     clsGlobal.User.userPreference = res[0];
          //     if(clsGlobal.User.userPreference.sProfilePicPath !=null || clsGlobal.User.userPreference.sProfilePicPath !=undefined)
          //     this.objStorage.setItem("PROFILE_PICTURE", clsGlobal.User.userPreference.sProfilePicPath);
          //   }
          // });

          //now load user preference in global user object.
        }).catch((error) => {
          console.log("Unable to signing new user." + error);
        });
      });
      //await this.confiltResolution();


    } catch (error) {
      console.log("Error in signing Trading user ." + error);
    }
  }

  async signingCognito(username, password, email) {
    try {
      password = password.length < 6 ? password + "1234" : password;
      console.log("Signing AppSync with user : " + username + " password " + password + " Email " + email);
      //alert("Signing AppSync with user : " + username +" password "+password+ " Email "+email);
      let a = await Auth.signIn({
        username,
        password
      }).then(a => {
        console.log(a);
        console.log("User login success. " + a);
        //after login data sync started.
        this.dataSyncStart();
      }).catch(e => {
        console.log("Error in signing error code :" + e.code + " Error " + e.message);
        if (e.code == "NotAuthorizedException" || e.code == "UserNotFoundException") {
          let a = Auth.signUp({
            username,
            password,
            attributes: { email }
          }).then(a => {
            console.log(" Sign-up success. " + a);
            let b = Auth.signIn({
              username,
              password
            }).then(a => {
              console.log(a);
              console.log("User login success. " + a);
              //after login data sync started.
              this.dataSyncStart();
            }).catch(e => {
              console.log("Unable to Sign-In. " + JSON.stringify(e));
            });
          }).catch(e => {
            console.log("Unable to Sign-Up. " + JSON.stringify(e));
          });
        }
      });
    } catch (error) {
      console.log('error signing up:', error);
    }
  }

  signOutCognito(username) {
    try {
      console.log("Signing Out AppSync with user : " + username);

      return Auth.signOut(username).then(async (result) => {
        console.log("Signout from cognito " + result);
        //await this.clearUserData(); 
        //await DataStore.stop();
        //await DataStore.clear(); 
        //await DataStore.start();

      }).catch(error => {
        console.log("Unable to signOut" + error);
      });
    } catch (error) {
      console.log("Error SignOut ." + error)
    }
  }

  // confiltResolutionPreLogin() {


  //   DataStore.configure({
  //     errorHandler: (error) => {
  //       console.warn("Unrecoverable error", { error });
  //       console.log('Unrecoverable error : ' + error);
  //     },
  //     conflictHandler: async (data) => {
  //       // Example conflict handler

  //       const modelConstructor = data.modelConstructor;
  //       if (modelConstructor === MsgInfo) {
  //         const remoteModel = data.remoteModel;
  //         const localModel = data.localModel;
  //         const newModel = modelConstructor.copyOf(remoteModel, (d) => {
  //           d.sMessage = localModel.sMessage;
  //         });
  //         console.log("Conflict occur MSGInfo " + newModel);
  //         return newModel;
  //       }
  //       if (modelConstructor === AppInfo) {
  //         const remoteModel = data.remoteModel;
  //         const localModel = data.localModel;
  //         const newModel = modelConstructor.copyOf(remoteModel, (d) => {
  //           d.sParamValue = localModel.sParamValue;
  //         });
  //         console.log("Conflict occur APPInfo " + newModel);
  //         return newModel;
  //       }
  //       console.log("Conflict occur discard ");
  //       return DISCARD;
  //     },
  //     syncExpressions: [
  //       syncExpression(MsgInfo, () => {
  //         return msg => msg.or((msg1) => msg1.sTenantId('eq', '0').or(msg1 => msg1.sTenantId('eq', clsGlobal.ComId)));
  //       }),
  //       syncExpression(AppInfo, () => {
  //         //return msg => msg.sTenantId('eq', clsGlobal.ComId);
  //         return appInfo => appInfo.or((appInfo1) => appInfo1.sTenantId('eq', '0').or(appInfo1 => appInfo1.sTenantId('eq', clsGlobal.ComId)));
  //       }),
  //       syncExpression(UserPreference, () => {
  //         // Sync preference across all tenant (ie. sTenantId=0), or my tenant (ie. sTenantId=sComId), or my user (ie. sTenantId=sComId && sUserId=sUserId)
  //         return preference => preference.or((pref1) => pref1.sTenantId('eq', '0')
  //           .and(pref1 => pref1.sTenantId('eq', clsGlobal.ComId).and(pref1 => pref1.sUserId('eq', '0')))
  //           .and(pref1 => pref1.sTenantId('eq', clsGlobal.ComId).and(pref1 => pref1.sUserId('eq', clsGlobal.User.userId))));
  //       })
  //     ],
  //     maxRecordsToSync: 30000,
  //     fullSyncInterval: 0, // minutes
  //   });
  // }

  async clearUserData() {

    await DataStore.delete(NewWatchListProfile, c => c.or((c1) => c1.sUserId('eq', clsGlobal.User.userId)
      .and(c1 => c1.sUserId('eq', clsGlobal.User.userId).sTenantId('eq', '0'))));

    await DataStore.delete(NewWatchListScrips, c => c.sUserId("eq", clsGlobal.User.userId));
  }

  checkingSyncComplete() {
    console.log("Checking sync.....");
    //Create listener
    const listener = Hub.listen("datastore", async hubData => {
      //const  { event, data } = hubData.payload;
      console.log(hubData.payload.event + " completed." + JSON.stringify(hubData.payload));
      if (hubData.payload.event === "ready") {
        console.log("Scync completed. Ready done !" + JSON.stringify(hubData.payload));
        this.getUserPreferenceData().then((res: any) => {
          if (res != undefined && res.length > 0) {
            clsGlobal.User.userPreference = res[0];
            if (clsGlobal.User.userPreference.sProfilePicPath != null && clsGlobal.User.userPreference.sProfilePicPath != undefined)
              this.objStorage.setItem("PROFILE_PICTURE", clsGlobal.User.userPreference.sProfilePicPath);
            clsGlobal.pubsub.publish("MENU_PROFILE");
          }
        });
        //this will indicate that data is sync  and now proceed.
        this.resolveFnc();
        // Remove listener
        listener();
      }
    });
  }

  confiltResolution() {
    DataStore.configure({
      errorHandler: (error) => {
        //console.warn("Unrecoverable error", { error });
        console.log('Unrecoverable error : ' + JSON.stringify(error));
      },
      conflictHandler: async (data) => {
        // Example conflict handler

        const modelConstructor = data.modelConstructor;
        if (modelConstructor === NewWatchListProfile) {
          const remoteModel = data.remoteModel;
          const localModel = data.localModel;
          const newModel = modelConstructor.copyOf(remoteModel, (d) => {
            d.sWatchListName = localModel.sWatchListName;
          });
          return newModel;
        }
        if (modelConstructor === MsgInfo) {
          const remoteModel = data.remoteModel;
          const localModel = data.localModel;
          const newModel = modelConstructor.copyOf(remoteModel, (d) => {
            d.sMessage = localModel.sMessage;
          });
          return newModel;
        }
        if (modelConstructor === AppInfo) {
          const remoteModel = data.remoteModel;
          const localModel = data.localModel;
          const newModel = modelConstructor.copyOf(remoteModel, (d) => {
            d.sParamValue = localModel.sParamValue;
          });
          return newModel;
        }
        return DISCARD;
      },
      syncExpressions: [
        syncExpression(MsgInfo, () => {
          return msg => msg.or((msg1) => msg1.sTenantId('eq', '0').or(msg1 => msg1.sTenantId('eq', clsGlobal.ComId)));
        }),
        syncExpression(AppInfo, () => {
          //return msg => msg.sTenantId('eq', clsGlobal.ComId);
          console.log(" 1 : "+clsGlobal.ComId);
          return appInfo => appInfo.or((appInfo1) => appInfo1.sTenantId('eq', '0').or(appInfo1 => appInfo1.sTenantId('eq', clsGlobal.ComId)));
        }),
        syncExpression(UserPreference, () => { 
          // Sync preference across all tenant (ie. sTenantId=0), or my tenant (ie. sTenantId=sComId), or my user (ie. sTenantId=sComId && sUserId=sUserId)
         console.log("Preference clsGlobal.User.userId :"+clsGlobal.User.userId + " ComId:"+clsGlobal.ComId);
          if (clsGlobal.User.userId) {
            return preference => preference.or((pref1) => pref1.sTenantId('eq', '0')
              .and(pref1 => pref1.sTenantId('eq', clsGlobal.ComId).and(pref1 => pref1.sUserId('eq', '0')))
              .and(pref1 => pref1.sTenantId('eq', clsGlobal.ComId).and(pref1 => pref1.sUserId('eq', clsGlobal.User.userId))));
          }
          else {
            return preference => preference.or((pref1) => pref1.sTenantId('eq', '0')
              .and(pref1 => pref1.sTenantId('eq', clsGlobal.ComId).and(pref1 => pref1.sUserId('eq', '0'))));
          }
        }),
        syncExpression(NewWatchListProfile, () => {
          console.log("Profile clsGlobal.User.userId  :"+clsGlobal.User.userId + " ComId:"+clsGlobal.ComId);
          if(clsGlobal.User.userId){
            return watchlistProfile => watchlistProfile.or((prof1) => prof1.sTenantId('eq', '0')
            .and(prof1 => prof1.sTenantId('eq', clsGlobal.ComId).sUserId('eq', 'CHIEF'))
            .and(prof1 => prof1.sTenantId('eq', clsGlobal.ComId).sUserId('eq', clsGlobal.User.userId)));
          }
          else{
            return watchlistProfile => watchlistProfile.or((prof1) => prof1.sTenantId('eq', '0')
            .and(prof1 => prof1.sTenantId('eq', clsGlobal.ComId).sUserId('eq', 'CHIEF')));
          } 
        }),
        syncExpression(NewWatchListScrips, () => { 
          if (clsGlobal.User.userId) {
            return watchlistScrip => watchlistScrip.or((scrip) => scrip.sTenantId('eq', '0')
              .and(scrip => scrip.sTenantId('eq', clsGlobal.ComId).sUserId('eq', 'CHIEF'))
              .and(scrip => scrip.sTenantId('eq', clsGlobal.ComId).sUserId('eq', clsGlobal.User.userId)));
          }
          else {
            return watchlistScrip => watchlistScrip.or((scrip) => scrip.sTenantId('eq', '0')
              .and(scrip => scrip.sTenantId('eq', clsGlobal.ComId).sUserId('eq', 'CHIEF')));
          }
        })
      ],
      maxRecordsToSync: 30000,
      fullSyncInterval: 0, // minutes
      syncPageSize: 2000
    });
  }

  async dataSyncStart() {

    await DataStore.stop();
    //await this.clearUserData(); 
    this.confiltResolution();
    //await DataStore.clear();
    this.checkingSyncComplete(); 
    await DataStore.start();

    // setTimeout(async () => {
    //   await DataStore.stop();
    //   await DataStore.clear();
    //   await DataStore.start();
    // }, 1000);

  }

  async getAppInfoFromAppSync() {
    //return await DataStore.query(AppInfo, c => (c.sTenantId("eq", "0") || c.sTenantId("eq", clsGlobal.ComId))).then((data: any) => {
    return await DataStore.query(AppInfo).then((data: any) => {
      if (data.length > 0) {
        clsGlobal.dConfigMaster.Clear();
        for (let k = 0; k < data.length; k++) {
          if (clsGlobal.dConfigMaster.ContainsKey(data[k].sParamName)) {
            if (data[k].sTenantId == clsGlobal.ComId) {
              console.log("Key with tenant setting." + JSON.stringify(data[k]));
              clsGlobal.dConfigMaster.Add(data[k].sParamName, data[k].sParamValue);
            }
          } 
          else if(data[k].sTenantId=="0" || data[k].sTenantId == clsGlobal.ComId){
            clsGlobal.dConfigMaster.Add(data[k].sParamName, data[k].sParamValue);
          }
        }
      }
      console.log("App Info read completed. Total count : " + clsGlobal.dConfigMaster.Count());

    }).catch((error) => {
      console.log("Error in getAppInfoFromAppSync : " + error);
    });
  }

  async getAppInfoKeyValue(appinfoKey)
  {
    return await DataStore.query(AppInfo, c => c.sParamName("eq", appinfoKey)).then((data: any) => {
          return data;
    }).catch((error) => { 
      console.log("Error in getAppInfoKeyValue : " + error);
      return null;
    });
  }
  async getMsgInfoFromAppSync() {
    return await DataStore.query(MsgInfo, c => c.sTenantId("eq", "0")).then((data) => {
      if (data.length > 0) {
        clsGlobal.dMsgMaster.Clear();
        for (let k = 0; k < data.length; k++) {
          if (clsGlobal.dMsgMaster.ContainsKey(data[k].sMsgCode)) {
            if (data[k].sTenantId == clsGlobal.ComId) {
              clsGlobal.dMsgMaster.Add(data[k].sMsgCode, data[k].sMessage);
            }
          }
          else if (data[k].sTenantId == "0" || data[k].sTenantId == clsGlobal.ComId) {
            clsGlobal.dMsgMaster.Add(data[k].sMsgCode, data[k].sMessage);
          }
        }
        console.log("Message master read completed. Total count : " + clsGlobal.dMsgMaster.Count());
      }
    }).catch((ex) => {
      console.log("Error in getMsgInfoFromAppSync : " + ex);
    });
  }

  async getWatchListScrips(userWatchListProfileId, userId) {
    let profScrip = await DataStore.query(NewWatchListScrips, c => c.nWatchListId("eq", userWatchListProfileId).sUserId("eq", userId));
    profScrip.sort((scrip1, scrip2) => { return scrip1.nSequenceNo - scrip2.nSequenceNo })
    return profScrip;
  }
  /**
   * 
   * @param user 
   * Method to get UserWatchlist.
   * clsGlobal.User.userId will be used.
   */
  async getWatchListProfiles() {

    // let userData = await DataStore.query(NewWatchListProfile, c => c.or((c1) => c1.sUserId('eq', clsGlobal.User.userId)
    //   .and(c1 => c1.sUserId('eq', clsGlobal.User.userId).sTenantId('eq', '0'))
    //   .and(c1 => c1.sUserId('eq', "CHIEF").sTenantId('eq', clsGlobal.ComId))));
    // let userData = await DataStore.query(NewWatchListProfile, c => c.and((c1) => c1.sUserId('eq', clsGlobal.User.userId).sTenantId('eq', clsGlobal.ComId)
    //   .or(c1 => c1.sUserId('eq', clsGlobal.User.userId).sTenantId('eq', '0'))));

    let userData = await DataStore.query(NewWatchListProfile, c => c.and((c1) => c1.sUserId('eq', clsGlobal.User.userId)
      .or(c1 => c1.sTenantId('eq', clsGlobal.ComId).or(c2 => c2.sTenantId('eq', '0')))));

    return userData;
  }

  async getWatchListGlobalProfiles() {
    //let globalProfile = await DataStore.query(NewWatchListProfile, c => c.sTenantId("eq", "0").sUserId('eq', "CHIEF"));
    let globalProfile = await DataStore.query(NewWatchListProfile, c => c.and((c1) => c1.sUserId('eq', 'CHIEF')
      .or(c2 => c2.sTenantId('eq', '0').or(c3 => c3.sTenantId('eq', clsGlobal.ComId)))));
    return globalProfile;
  }

  /**
   * Method to get User Preference data 
   * clsGlobal.User.userId and TenantId will be used.
   */
  async getUserPreferenceData() {
    return await DataStore.query(UserPreference, c => c.sUserId("eq", clsGlobal.User.userId) && c.sTenantId('eq', clsGlobal.ComId));
  }

  /**
   * 
   * @param userPreferenceObject 
   * Method to save preference data, array of all the settings.
   * 
   */
  async saveUpdateUserPreferenceData(userPreferenceObject) {
    try {
      //userWatchListProfile 
      const original = await DataStore.query(UserPreference, c => c.sUserId("eq", clsGlobal.User.userId) && c.sTenantId('eq', clsGlobal.ComId));
      if (original == undefined || original[0] == undefined || original[0] == null) {
        //this will be save.
        await DataStore.save(
          new UserPreference({
            sExchange: userPreferenceObject.sExchange,
            sInAppNotification: userPreferenceObject.sInAppNotification,
            sNotification: userPreferenceObject.sNotification,
            sOrder: userPreferenceObject.sOrder,
            sProfilePicPath: userPreferenceObject.sProfilePicPath,
            sTheme: userPreferenceObject.sTheme,
            sUserId: clsGlobal.User.userId,
            sTenantId: clsGlobal.ComId
          })
        );
      }
      else {
        //this will be update.
        await DataStore.save(
          UserPreference.copyOf(original[0], updated => {
            updated.sExchange = userPreferenceObject.sExchange;
            updated.sInAppNotification = userPreferenceObject.sInAppNotification;
            updated.sNotification = userPreferenceObject.sNotification;
            updated.sOrder = userPreferenceObject.sOrder;
            updated.sProfilePicPath = userPreferenceObject.sProfilePicPath;
            updated.sTheme = userPreferenceObject.sTheme;
          }), (p) => p.sUserId("eq", clsGlobal.User.userId) && p.sTenantId('eq', clsGlobal.ComId));
      }
    } catch (error) {
      console.log("Error in saving user preference Data " + error);
    }
  }

  /**
   * 
   * @param userWatchListProfile 
   * Method to add WatchList Profile.
   */
  async saveWatchListProfile(userWatchListProfile) {
    try {
      await DataStore.save(
        new NewWatchListProfile({
          nWatchListId: userWatchListProfile.nWatchListId,
          sWatchListName: userWatchListProfile.sWatchListName,
          bIsDefault: userWatchListProfile.bIsDefault,//.toString(),
          bIsPrivate: userWatchListProfile.bIsPrivate,//.toString(),
          sUserId: userWatchListProfile.sCreatedBy,
          sTenantId: userWatchListProfile.nTenantId == '' ? '0' : userWatchListProfile.nTenantId
        })
      );
      // .then(data=>{

      // },error=>{
      //   console.log("Error in inserting profile: ", JSON.stringify(error));
      // }).catch(error=>{
      //   console.log("Error in inserting profile: ", JSON.stringify(error));
      // });
    } catch (error) {
      console.log("Error in saving Watchlist Profile." + error);
    }
  }

  /**
   * 
   * @param userWatchListProfile 
   * Method to Update watch list profile , only watchlist name will update.
   */
  async updateWatchListProfile(userWatchListProfile) {
    //userWatchListProfile 
    const original = await DataStore.query(NewWatchListProfile, c => c.nWatchListId("eq", userWatchListProfile.nWatchListId).sUserId("eq", userWatchListProfile.sCreatedBy).sTenantId("eq", userWatchListProfile.nTenantId));

    return await DataStore.save(

      NewWatchListProfile.copyOf(original[0], updated => {
        updated.sWatchListName = userWatchListProfile.sWatchListName;
      }), (p) => p.id('eq', original[0].id)

      // NewWatchListProfile.copyOf(original[0], updated => {
      //   updated.sWatchListName = userWatchListProfile.sWatchListName;
      //   updated.bIsDefault = userWatchListProfile.bIsDefault;
      // }), (p) => p.nWatchListId("eq", original[0].nWatchListId)
      //sUserId("eq", userWatchListProfile.sUserId).sTenantId("eq", userWatchListProfile.nTenantId)
    );
  }

  /**
   * 
   * @param userProfileId 
   * @param userWatchListScripData 
   *  Method to Add Update WatchList Profile Scripts
   */
  saveWatchListProfileScrips(profile, userWatchListScripData) {
    try {
      let count = 1;
      userWatchListScripData.forEach(element => {
        DataStore.save(
          new NewWatchListScrips({
            nWatchListId: element.nWatchListId,
            nMarketSegmetId: element.nMarketSegmentId,
            nToken: parseInt(element.nToken),
            nSequenceNo: element.nSequenceNo || count++,
            sUserId: profile.sCreatedBy,
            sTenantId: profile.nTenantId == '' ? '0' : profile.nTenantId
          })
        );
      });
    } catch (error) {
      console.log("Error in saving WatchList Profile Scripts." + error);
    }
  }

  /**
   * @param userProfileId 
   * @param userWatchListScripData 
   * Method to update watchlist scrips , required parameter Profile id and watchlist scrips.
   */
  async updateWatchListProfileScrips(userProfileId, userWatchListScripData) {
    try {
      //first delete all scrips from watchlist and then add new watchlist scrip array.
      const todelete = await DataStore.query(NewWatchListScrips, c => c.nWatchListId("eq", userProfileId));
      todelete.forEach(element => {
        DataStore.delete(element);
      });
      //delete and add.
      let count = 1;
      await userWatchListScripData.forEach(element => {
        DataStore.save(
          new NewWatchListScrips({
            nWatchListId: userProfileId,
            nMarketSegmetId: element.MktId,
            nToken: element.Token,
            nSequenceNo: element.seqNo || count++,
            sUserId: clsGlobal.User.userId,
            sTenantId: clsGlobal.ComId
          })
        );
      });
    } catch (error) {
      console.log("Error in Update watchList scrips." + error);
    }
  }

  /**
   * 
   * @param userProfileId 
   * Method to delete watchlist,  required parameter is watchlist Id.
   */
  async deleteWatchList(userProfileId) {
    try {
      //delete profile and then delete its scrips , sequence can be change.
      //await DataStore.delete(WatchListProfile, c => c.nWatchListId("eq", userProfileId.nWatchListId));
      const todelete = await DataStore.query(NewWatchListProfile, c => c.nWatchListId("eq", userProfileId.nWatchListId).sUserId("eq", clsGlobal.User.userId));
      // DataStore.delete(todelete);
      todelete.forEach(element => {
        DataStore.delete(element);
      });

      //await DataStore.delete(WatchListScrips, c => c.nWatchListId("eq", userProfileId.nWatchListId));
      const todeleteScrip = await DataStore.query(NewWatchListScrips, c => c.nWatchListId("eq", userProfileId.nWatchListId).sUserId("eq", clsGlobal.User.userId));
      todeleteScrip.forEach(element => {
        DataStore.delete(element);
      });

    } catch (error) {
      console.log("Error in delete watchlist." + error);
    }
  }

  /**
  * 
  * @param userProfileId 
  * Method to delete watchlist,  required parameter is watchlist Id.
  */
  deleteWatchListScrip(delScrips) {
    try {

      return new Promise((resolve, reject) => {
        try {


          delScrips.forEach((element) => {

            const todeleteScrip = DataStore.query(NewWatchListScrips, c => c.nWatchListId("eq", element.nWatchListId).
              nMarketSegmetId("eq", element.nMarketSegmentId).nToken("eq", element.nToken).sUserId("eq", element.sCreatedBy).sTenantId("eq", clsGlobal.ComId)).then(todeleteScrip => {
                todeleteScrip.forEach(elem => {
                  DataStore.delete(elem);
                });
                resolve(true);
              }, error => {
                resolve(false);
                console.log("Error deleting profile scrip: ", error);
              });
          });

        } catch (error) {
          resolve(false);
          console.log("Error deleting profile scrip: ", error.message);
        }
      });



    } catch (error) {
      console.log("Error in delete watchlist scrip." + error);
    }
  }

  async reorderWatchListScrip(watchListId, userWatchListScripData) {
    try {

      return new Promise(async (resolve, reject) => {
        try {

          await DataStore.delete(NewWatchListScrips, scrip => scrip.nWatchListId("eq", watchListId).sUserId("eq", clsGlobal.User.userId).sTenantId("eq", clsGlobal.ComId));

          userWatchListScripData.forEach(async (element) => {
            await DataStore.save(
              new NewWatchListScrips({
                nWatchListId: element.nWatchListId,
                nMarketSegmetId: element.nMarketSegmentId,
                nToken: element.nToken,
                nSequenceNo: element.nSequenceNo,
                sUserId: clsGlobal.User.userId,
                sTenantId: clsGlobal.ComId
              })
            );
          });

          resolve(true);

        } catch (error) {
          resolve(false);
          console.log("Error re-order profile scrip: ", error.message);
        }
      })




    } catch (error) {
      console.log("Error in reorder watchlist scrip." + error);
    }
  }


}
