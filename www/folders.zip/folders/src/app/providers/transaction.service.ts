import { Injectable } from '@angular/core';
import { clsGlobal } from '../Common/clsGlobal';
import { clsHttpService } from '../Common/clsHTTPService';
import { HttpClient, HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private http: clsHttpService) { }

  /**
   * Fetch order Book 
   */
  getOrderBook(pageNo , pageSize , orderStatus) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders?offset=' + pageNo + '&limit=' + pageSize +'&orderStatus=' + orderStatus).subscribe((orderBookResponse: any) => {
        resolve(orderBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  /**
   * Fetch Multileg Order book 
   */
   getMultilegOrderBook(pageNo , pageSize , orderType , orderStatus ) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/multilegOrders?offset=' + pageNo + '&limit=' + pageSize +'&orderType='+ orderType +'&orderStatus=' + orderStatus).subscribe((orderBookResponse: any) => {
        resolve(orderBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  /**
   * Fetch GTD Order book 
   */
   getGTDOrderBook(pageNo , pageSize , orderStatus) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/gtdOrders?offset=' + pageNo + '&limit=' + pageSize +'&orderStatus=' + orderStatus).subscribe((orderBookResponse: any) => {
        resolve(orderBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  /**
   * Fetch GTD Order book History
   */
   getGTDOrderSummary(pageNo , pageSize , gtdOrderId) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/gtdOrdersHistory?offset=' + pageNo + '&limit=' + pageSize +'&gtdOrderId=' + gtdOrderId).subscribe((gtdOrderSummaryResponse: any) => {
        resolve(gtdOrderSummaryResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

 
  //  getGTDOrderTradeSummary(gtdOrderId , orderDateTime) {
  //   return new Promise((resolve, reject) => {
  //     this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/gtdOrderTradeHistory?gtdOrderId=' + gtdOrderId +'&orderDateTime=' + orderDateTime).subscribe((orderBookResponse: any) => {
  //       resolve(orderBookResponse);
  //     },
  //       (error: any) => {
  //         reject(error);
  //       });
  //   });
  // }


  /**
   * Fetch order Bool Call
   */
  getOrderBookfromOrderId(orderNumber) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders?offset=1&limit=100&order_id=' + orderNumber).subscribe((orderBookResponse: any) => {
        resolve(orderBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  /**
   * 
   * @param orderNumber 
   * 
   * 
   */
  getOrderHistory(orderNumber: string) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/' + orderNumber).subscribe((orderHistoryResponse: any) => {
        resolve(orderHistoryResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  /**
   * 
   * @param orderNumber 
   */
  getTradeBookFromOrderId(orderNumber: string , orderNumbers:any) {
    let orderIds  = '';
    if(orderNumbers.length > 0 ){
      orderIds = orderNumbers.join(',')
    }
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/trades?offset=1&limit=100&order_id=' + orderNumber +'&order_ids=' + orderIds).subscribe((tradeBookResponse: any) => {
        resolve(tradeBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  
  getTradeBook() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/trades?offset=1&limit=100').subscribe((tradeBookResponse: any) => {
        resolve(tradeBookResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }
 
  getNetPositionDaily(intropStatus) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/portfolio/positions/daily?intropStatus=' +intropStatus ).subscribe((netPositionResponmse: any) => {
        resolve(netPositionResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getNetPositionExpiry(intropStatus) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/portfolio/positions/expiry?intropStatus=' +intropStatus).subscribe((netPositionResponmse: any) => {
        resolve(netPositionResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  getHoldingsData() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v2/portfolio/holdings').subscribe((holdingsResponmse: any) => {
        resolve(holdingsResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  placeOrder(reqBody) {
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/regular', reqBody).subscribe((holdingsResponmse: any) => {
        resolve(holdingsResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  placeCoverOrder(reqBody) {
    return new Promise((resolve, reject) => {

      //http://localhost:3100/transactional/v1/orders/cover
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/cover', reqBody).subscribe((respCover: any) => {
        resolve(respCover);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  placeBracketOrder(reqBody) {
    return new Promise((resolve, reject) => {

      //http://localhost:3100/transactional/v1/orders/bracket
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/bracket', reqBody).subscribe((respCover: any) => {
        resolve(respCover);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  placeMultiLegOrder(reqBody){
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + clsGlobal.versionId + '/orders/multileg', reqBody).subscribe((holdingsResponmse: any) => {
        resolve(holdingsResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  modifyOrCancelSpreadOrder(reqBody,gateway,modifyorcancel){
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + clsGlobal.versionId + '/orders/multileg/' + modifyorcancel +'/' + gateway, reqBody).subscribe((modifyResponse: any) => {
        resolve(modifyResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  modifyOrder(reqBody, exchange, orderid) {
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/regular/' + exchange + "/" + orderid, reqBody).subscribe((holdingsResponmse: any) => {
        resolve(holdingsResponmse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  modifyCoverOrder(reqBody, exchange, orderid) {
    return new Promise((resolve, reject) => {
      
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/cover/' + exchange + "/" + orderid, reqBody).subscribe((respCover: any) => {
        resolve(respCover);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  modifyBracketOrder(reqBody, exchange, orderid) {
    return new Promise((resolve, reject) => {
      
      let headers = new HttpHeaders({});
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/bracket/' + exchange + "/" + orderid, reqBody).subscribe((respCover: any) => {
        resolve(respCover);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  exitBracketOrder(exchange, orderid) {
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.deleteJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/bracket/' + exchange + "/" + orderid).subscribe((orderResponse: any) => {
        resolve(orderResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  cancelOrder(exchange, orderid) {
    return new Promise((resolve, reject) => {
      let headers = new HttpHeaders({});
      //headers = headers.append('Authorization', 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTU1MTk2NDkyNSwibWVtYmVySWQiOjkwOTA5MCwidXNlcmlkIjo5MDkwOTAsInRlbmFudGlkIjo5MDkwOTAsIm1lbWJlckluZm8iOnsidGVuYW50SWQiOiJjb20ud2F2ZS5iZXlvbmRiZXRhIiwiZ3JvdXBJZCI6IiIsInVzZXJJZCI6Im5vcndpbiIsInRlbXBsYXRlSWQiOiJXQVZFMlAwIiwidWRJZCI6IjEyMzQ1Njc4OTAifSwiZXhwIjo2MDAxNTUxOTY0OTI1fQ.WVVsOE0Ai2aqL1mRYoP_3AVQ1q9JGgSHMh99q0iiQ0A');
      headers = headers.append('Authorization', 'Bearer ' + clsGlobal.User.sessionId);
      let options = { headers: headers };
      this.http.deleteJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/regular/' + exchange + "/" + orderid).subscribe((orderResponse: any) => {
        resolve(orderResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  //This will be new call as per UI
  //user can place multiple cancel or single cancel in this call.
  //it will be post call.
  cancelOrders(orderList) {
    return new Promise((resolve, reject) => {
      let reqBody = {
        orders: orderList
      }
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/cancelorders', reqBody).subscribe((cancelResponse: any) => {
        //  this.http.postJson("http://localhost:8175",  '/transactional/v1/cancelorders',reqBody).subscribe((cancelResponse: any) => {
        resolve(cancelResponse); //need to handle response and display i UI.
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  positionConversion(exchange, scrip_token, transaction_type, quantity, old_product_type, new_product_type, bo_order_id) {
    let reqBody = {
      "exchange": exchange,
      "scrip_token": scrip_token,
      "transaction_type": transaction_type,
      "quantity": quantity,
      "old_product_type": old_product_type,
      "new_product_type": new_product_type,
      "bo_order_id": bo_order_id
    };
    return new Promise((resolve, reject) => {
     
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/portfolio/positions', reqBody).subscribe((positionConversionResponse: any) => {
        resolve(positionConversionResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  bulkOrderEntry(orderArray: any) {
    return new Promise((resolve, reject) => {
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/orders/bulkOrders', orderArray).subscribe((orderEntryResponse: any) => {
        resolve(orderEntryResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getProductWiseBalanceInfo() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/producteWiseBalance').subscribe((fundsBalanceResponce: any) => {
        resolve(fundsBalanceResponce);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getPeridiocityWiseBalanceInfo() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/peridiocityWiseBalance').subscribe((fundsBalanceResponce: any) => {
        resolve(fundsBalanceResponce);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getBankListForselectedProduct(productId,bnkOption) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getBanksForSelectedProduct/' + productId + "/" + bnkOption).subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  transferFunds(moveFromProductID, moveToProductID, transferAmount) {

    let reqBody = {
      "moveFromProductID": moveFromProductID,
      "moveToProductID": moveToProductID,
      "transferAmount": transferAmount
    }
    return new Promise((resolve, reject) => {
      //"http://172.25.92.67:8175/"
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/fundsTransfer', reqBody).subscribe((trxResp: any) => {
        resolve(trxResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  withdrawFunds(reqBody) {
    return new Promise((resolve, reject) => {
      //clsGlobal.VirtualDirectory
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/fundsWithdrawal', reqBody).subscribe((withdrawResp: any) => {
        resolve(withdrawResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  recentTransaction(reqBody) {
    return new Promise((resolve, reject) => {
      //clsGlobal.VirtualDirectory --"http://172.25.92.67:8175/"
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/fundsReport', reqBody).subscribe((reportResp: any) => {
        resolve(reportResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  mappedProduct(productId) {
    return new Promise((resolve, reject) => {
      //clsGlobal.VirtualDirectory
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/fundTransferMappedProduct/' + productId).subscribe((reportResp: any) => {
        resolve(reportResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getMappedBankList(productId, bankId) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getMappedBanksList/' + productId + "/" + bankId).subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getUPIList() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getUPIDetails/').subscribe((upiListResponse: any) => {
        resolve(upiListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getGatewayList(productId) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getGatewayDetails/' + productId).subscribe((gwListResponse: any) => {
        resolve(gwListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getBankAccList(productId, bankId) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getBankAccList/' + productId + "/" + bankId).subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  cancelWithdraw(reqBody) {
    return new Promise((resolve, reject) => {
      //clsGlobal.VirtualDirectory
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/fundsWithdrawalCancellation', reqBody).subscribe((reportResp: any) => {
        resolve(reportResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getBrokerCode(bankId) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getBrokerCode/' + bankId).subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getOrderMarginInfo(reqBody) {
    return new Promise((resolve, reject) => {
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getOrderMarginInfo' , reqBody).subscribe((utilResponse: any) => {
        resolve(utilResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getDPDetails() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getDPDetailsEDIS/').subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getEDISSummaryDetails(sellQty,segId,token,depository,summaryMktSegId) {
    return new Promise((resolve, reject) => {
      let param = clsGlobal.User.userCode + '/' + sellQty + '/'+ segId + '/' + token + '/' + depository + '/' + summaryMktSegId;
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getEDISSummary/' + param).subscribe((summaryResp: any) => {
        resolve(summaryResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  updateEDISDPHolding(objEDIS) {
    return new Promise((resolve, reject) => {
      //let param = clsGlobal.User.userCode + '/' + sellQty + '/'+ segId + '/' + token + '/' + depository + '/' + summaryMktSegId;
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/setEDISHolding' , objEDIS).subscribe((summaryResp: any) => {
        resolve(summaryResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  insertEDISResponse(objEDIS) {
    return new Promise((resolve, reject) => {
      //let param = clsGlobal.User.userCode + '/' + sellQty + '/'+ segId + '/' + token + '/' + depository + '/' + summaryMktSegId;
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/insertEDISResp' , objEDIS).subscribe((summaryResp: any) => {
        resolve(summaryResp);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getIntropConfiguration() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getInteropConfiguration' ).subscribe((intropConfigResponse: any) => {
        resolve(intropConfigResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  getBalanceDetails(productId, bankId, accountNo) {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getBalanceDetails/' + productId + "/" + bankId+ "/" + accountNo).subscribe((bankListResponse: any) => {
        resolve(bankListResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  getPurchasePower() {
    return new Promise((resolve, reject) => {
		//"http://172.25.92.67:8175/"
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Transactional + 'v1/getPurchasePower').subscribe((fundsResponse: any) => {
        resolve(fundsResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


}

