import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { clsGlobal } from '../Common/clsGlobal';
import { clsHttpService } from '../Common/clsHTTPService';
import * as xml2js from 'xml2js';
import { clsCommonMethods } from '../Common/clsCommonMethods';
import { interval } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GlobalEventsService {

  private whatshotInterval:any;
  constructor(private httpService: clsHttpService) {
    // this will fire for first time on subscription. next call as per setinterval. 
    console.log('Inside constructor');
    this.fetchEvents();
    clsGlobal.pubsub.subscribe('STARTWHATSHOTDATA', (data: any) => { 
       //calling reco for first time.
       this.getRecommendation();
      this.whatshotInterval =  setInterval(() => {
         if(clsGlobal.User.OCToken.length>0)
         this.fetchEventsinterval(); 
       }, 300000); 
     });
 
     clsGlobal.pubsub.subscribe('STOPWHATSHOTDATA', (data: any) => {
      clearInterval(this.whatshotInterval);
     });
    
   } 
  ngOnInit(): void {  
                               
   
  }

  fetchEvents() { 
    return new Promise((resolve, reject) => { 
      try { 
        //clsGlobal.EventList = [];
        if (clsGlobal.EventList.length == 0) {
          this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
            + 'v1/getWhatsHotData')
            .subscribe((respData: any) => {
              if (respData.status == true) {
                //console.log(respData.result);           
                for (let index = 0; index < respData.result.length; index++) {
                  clsGlobal.EventList.push(respData.result[index])
                } 
              } 
            }, error => {
                console.log("Error in fetchEvents()  : "+error);
            });
        } else {
          resolve(true);
        }

      } catch (error) {
        reject(error);
        console.log("Error in event fetch");
      } 
    }); 
  }

  getRecommendation() {
    try {

      let recmParamReq: any = {};
      recmParamReq.mktSegId = null;
      recmParamReq.token = null;
      recmParamReq.allowedNewsCat = clsGlobal.User.NewsCategories;//'25045';//"25037, 25034, 25000, -1, ";
      this.httpService.postJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/getRecommendation', recmParamReq).subscribe(resRec => {

        if (resRec.status == true) {
          let recdata: any = resRec.result;
          for (let i = 0; i < recdata.length; i++) {
            let recoExists = clsGlobal.EventList.filter((existelement) => {
              return existelement.mktid == recdata[i].nMarketSegmentId &&
                existelement.token == recdata[i].nToken
                && existelement.event == "Reco";
            });
            if (recoExists.length == 0) {
              clsGlobal.EventList.push({
                "name": recdata[i].sScripDesc.split(" ")[2],
                "token": recdata[i].nToken,
                "mktid": recdata[i].nMarketSegmentId,
                "event": "Reco",
                "type": "Reco",
                "data": this.convertXmlToJson(recdata[i].sRecoDetails),
                "filter": false,
                "date": clsCommonMethods.getRecoDateTime(recdata[i].dEndTime),
                "recoId": recdata[i].sRecoId,
                "buysell": this.convertXmlToJson(recdata[i].sRecoDetails)[0].nBuySellText,
                "class": '',
                "class2": '',
                "Desc": 'Recommendation'
              })
            }

          }

        }
        else {
          //todo // call fail.
        }
        console.log(resRec);

      }, error => {
        console.log(error)
        clsGlobal.logManager.writeErrorLog('researchcall', 'getRecommendation_1', error.message);
      })

    } catch (error) {
      clsGlobal.logManager.writeErrorLog('researchcall', 'getRecommendation_2', error.message);
    }

  }
  convertXmlToJson(sRecoDetails) {
    try {
      let json = [];
      xml2js.parseString(sRecoDetails, function (err, result) {
        for (let i = 0; i < result.RecoDetails.RecoChild.length; i++) {
          let data = result.RecoDetails.RecoChild[i].$
          data.nBuySellText = data.nBuySell == "1" ? "BUY" : "SELL";
          json.push(data);
        }
      });
      return json
    } catch (error) {
      console.log(error);
    }
  }


  fetchEventsinterval() { 
    return new Promise((resolve, reject) => { 
      try { 
        clsGlobal.EventList = clsGlobal.EventList.filter(obj => obj.type == "Reco"); 
          this.httpService.getJson(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId
            + 'v1/getWhatsHotData')
            .subscribe((respData: any) => {
              if (respData.status == true) { 
                for (let index = 0; index < respData.result.length; index++) {
                  clsGlobal.EventList.push(respData.result[index])
                }
                //clsGlobal.EventList = respData.result;
                //this.getRecommendation();
              }

            }, error => {

            });

      } catch (error) {
        reject(error);
        console.log("Error in event fetch");
      }    

    });

    //return _promise;


  }  
}


// async fetchEventList() {

  //   let _promise = await new Promise((resolve, reject) => {
  //     if (this.eventList.length > 0) {
  //       resolve();
  //     }
  //     else {
  //       try {
  //         let headers = new HttpHeaders({});
  //         headers = headers.append('Access-Control-Allow-Origin', '*');
  //         const url = 'https://testcdncss.s3.ap-south-1.amazonaws.com/event.json';
  //         //'https://dmtl7vwzvw1wn.cloudfront.net/event.json'; 
  //         this.http.get(url, { headers, responseType: 'json' }).subscribe((respData: any) => {
  //           if (respData != null && respData != undefined) {
  //             this.eventList = respData;// JSON.parse(respData); 
  //             this.applyEventToWatchList();
  //             resolve();
  //           }
  //         }, error => {
  //           reject();
  //           console.log('In http error  2 ' + JSON.stringify(error));
  //         });
  //       } catch (error) {
  //         console.log("Error in event fetch");
  //       }
  //     }
  //   }).catch(error => {
  //     console.log("eeror in fetchevent" + error);
  //   });
  //   return _promise;
  // }