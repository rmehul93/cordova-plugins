import { clsTradingMethods } from './../../Common/clsTradingMethods';
import { Platform } from '@ionic/angular';
import { Injectable } from '@angular/core';
import { SQLitePorter } from '@ionic-native/sqlite-porter/ngx';
import { HttpClient } from '@angular/common/http';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { clsConstants } from 'src/app/Common/clsConstants';
import { clsGlobal } from 'src/app/Common/clsGlobal';
import { clsHttpService } from 'src/app/Common/clsHTTPService';
import { clsScripKey } from 'src/app/Common/clsScripKey';
import { clsCommonMethods } from 'src/app/Common/clsCommonMethods';
import { AlertServicesProvider } from '../alert-services/alert-services';

export interface ScripObject {
  id: number;
  exchange: string;
  token: number;
  symbol: string;
  series: string;
  instrument: string;
  expiry: string;
  strikeprice: string;
  optiontype: string;
  ts: number;
  lotsize: number;
  sec: number;
  cc: number
}

@Injectable({ providedIn: 'root' })

export class DatabaseService {
  // private database: SQLiteObject;
  private database: any;
  private dbReady: Subject<boolean> = new Subject();
  //CDNServiceURL = clsGlobal.URL + '/' + clsGlobal.CDNService + 'files/' + clsGlobal.LocalComId;//clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_BANNER_BASE_PATH);
  scriplist = new BehaviorSubject([]);
  months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  current_datetime = new Date()
  formatted_date = clsCommonMethods.getFormattedDays(this.current_datetime.getDate()) + this.months[this.current_datetime.getMonth()] + this.current_datetime.getFullYear();
  cdnurl = clsGlobal.S3BucketPath;

  constructor(private plt: Platform,
    private sqliteporter: SQLitePorter,
    private sqlite: SQLite,
    private http: HttpClient,
    private alertObj: AlertServicesProvider,
    public httpService: clsHttpService,
    public platform: Platform
  ) {

    // this.plt.ready().then(() => {
    //   try { 
    //     if (!this.plt.is('cordova')) {
    //       let db = (<any>window).openDatabase('appdata.db', '1.0', 'DEV', 10 * 1024 * 1024); 
    //       this.database = this.browserDBInstance(db);
    //       this.seedDatabase();
    //     } else {
    //       //create the database of given name.
    //       console.log("*********************Opening db on Device.");
    //       this.sqlite.create({
    //         name: 'appdata.db',
    //         location: 'default' 
    //       }).then((db: SQLiteObject) => {
    //         console.log("*******************DB created.")
    //         this.database = db;
    //         this.seedDatabase();
    //       }).catch(err => {
    //         console.log("******************Error in creating database : " + err)
    //       });
    //     } 
    //   } catch (error) {
    //     this.alertObj.showAlert('Error in DatabaseService constructor.' + error);
    //     console.log('Error in DatabaseService constructor.' + error);
    //   }
    // }).catch(err => { 
    //   console.log("Error in platform ready : " + err)
    // })
  }
 

  /**
   * Create browser database
   */
  browserDBInstance = (db) => {

    return {
      executeSql: (sql, data) => {
        return new Promise((resolve, reject) => {
          db.transaction((tx) => {
            tx.executeSql(sql, data || [], (tx, rs) => {
              resolve(rs)
            });
          });
        })
      },
      sqlBatch: (arr) => {
        return new Promise((r, rr) => {
          db.transaction((tx) => {
            var count = 0;
            arr.forEach((data) => {
              tx.executeSql(data[0], data[1] || [], (tx, rs) => {
                count++;
                if (count == arr.length) {
                  r(rs);
                }
              });
            });
          });
        })
      }
    }
  }

  /**
   * 1 : This method creates tables in db
   * 2 : Check bod status then load info
   */
  async seedDatabase() {
    //local table creation.
    if (!this.plt.is('cordova')) {

      await this.createTables().then(res => {
        //BOD CHECKING
        this.checkBodStatus().then(async (data) => {
          if (data) {
            await this.loadAppInfo();
            await this.loadMsgInfo();
            await this.loadScripMaster();
          }
          this.dbReady.next(true);
        }, error => {
          console.log('Error in creating tables for sql lite1 Chrome: ' + error);
        })
      }).catch(error => {
        console.log('Error in creating tables for sql lite2 Chrome: ' + error);
      });
    } else {
      //device db creation.
      try {
        let _url = this.cdnurl + "master/" + 'scriptbatch.json';
        //let _url = 'scriptbatch.json';
        console.log("Fetching data from start on "+(new Date().toLocaleTimeString()) +" URL: " + _url );
        this.httpService.getStaticFile(_url).subscribe((sql: any) => {
          console.log("Fetch data complete on "+(new Date().toLocaleTimeString()));
          let respData = JSON.parse(sql);
          if (respData != null && respData != undefined) {
            let insertrowstring = "";
            for (let i = 0; i < respData.length; i++) {
              insertrowstring = insertrowstring + respData[i].value + ';\n';
            }
            //console.log("TABLE CREATION for SQLLITE: " + insertrowstring);
            try {
              console.log("TABLE CREATION for SQLLITE data started on: "+(new Date().toLocaleTimeString()));
              this.sqliteporter.importSqlToDb(this.database, insertrowstring)
                .then(async (data) => {
                  console.log("TABLE CREATION for SQLLITE data end on: " + JSON.stringify(data));
                  await this.loadAppInfo();
                  await this.loadMsgInfo();
                  await this.loadScripMaster();
                  this.dbReady.next(true);
                })
                .catch(e => {
                  console.log('Error in creating tables for sql lite1 importSqlToDb APK1: ' + JSON.stringify(e));
                });
            } catch (error) {
              console.log('Error in creating tables for sql lite2 importSqlToDb APK2: ' + error);
            }
          }
        }, error => {
          console.log('Error in creating tables for sql lite1 APK: ' + JSON.stringify(error));
        });
      } catch (error) {
        console.log("Error in creating tables for sql lite2 APK:" + error);
      }
    }

  }



  getDatabaseState() {
    return this.dbReady.asObservable();
  }

  /**
 * create tables in given database
 */
  async createTables() {
    return await new Promise((resolve, reject) => {

      try {
        let _url = this.cdnurl + "master/" + 'scriptbatch.json';
        console.log("Fetching data for chrome " + _url);
        this.httpService.getStaticFile(_url).subscribe((sql: any) => {
          let respData = JSON.parse(sql);
          if (respData != null && respData != undefined) {
            const insertRows = [];
            let insertrowstring = "";
            for (let i = 0; i < respData.length; i++) {
              insertRows.push([
                respData[i].value
              ]);
              insertrowstring = insertrowstring + respData[i].value + ';\n';
            }
            console.log("CREATEING TABLE FOR CHROME " + insertrowstring);
            this.database.sqlBatch(insertRows).then((result) => {
              console.log("Table created on chrome. Result :" + JSON.stringify(result));
              resolve(true);
            }).catch(error => {
              console.log("ERROR Table created on chrome. : " + error);
            });
          }
        }, error => {
          console.log('In http error : ' + JSON.stringify(error));
        });
      } catch (error) {
        console.log('Error in create tables . ' + JSON.stringify(error));
      }
    })
  }

  /**
* @method : Check BOD Status then inserting data in SQLite
* 1 : If bodmaster is empty then do bod entry and insert data in database from CDN Service
* 2 : If bodmaster table is not empty and bod is not done then
*      (a) Delete bodmaster table data
*      (b) Do bod entry of current date
*      (c) Delete old data from table and load new data in table from CDN Service
* 3 : If bodmaster table is not empty and bod is done then load data from local sqlite database
*/
  async checkBodStatus() {
    return await new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM bodmaster').then(async (res) => {
          if (res.rows.length == 0) {
            resolve(true);
          } else if (res.rows.length > 0) {
            let lastBodTime = res.rows[0].bod_date;
            if (new Date(this.formatted_date) > new Date(lastBodTime)) {
              await this.delete("bodmaster").then(async (data) => {
                for (let i = 0; i < res.rows.length; i++) {
                  let tableName = res.rows[i].table_name;
                  await this.delete(tableName).then(res => {
                  }).catch(err => {
                    console.log(err);
                    reject(err);
                  })
                }
              }).catch(error => {
                console.log("Error in delete bodmaster table data" + error);
                reject(false);
              });
              resolve(true);
            }
            resolve(true);
          }
        }).catch(err => {
          reject(err);
        })
      } catch (error) {
        console.log("Error in checking BOD Status : " + error);
      }
    })
  }


  /**
    * @method : Do BOD entry in bodmaster table
    * @param date : current date
    * a@param tableName : Name of table in database
    */
  async doBod(tableName, date) {
    return await new Promise((resolve, reject) => {
      try {
        this.database.executeSql('INSERT INTO bodmaster (table_name,bod_date) VALUES (?,?)', [tableName, date]).then(data => {
          resolve(true)
        }).catch(error => {
          reject(error.message);
        });
      }
      catch (error) {
        reject(error.message)
      }
    });
  }

  /**
 * Desc : 1. To fetch data from database (SQL lite) and stored it into local array.
 *        2. Call getAppInfo() method to update data.
 */

getAllAppInfo() {
  return new Promise((resolve, reject) => {
    try {
      this.database.executeSql('SELECT * FROM appinfo', [])
        .then((data: any) => {
          resolve(data);
        })
      }
        catch(error){

        } 
      });
 } 
 getAllMsgInfo() {
  return new Promise((resolve, reject) => {
    try {
      this.database.executeSql('SELECT * FROM msginfo', [])
        .then((data: any) => {
          resolve(data);
        })
      }
        catch(error){

        } 
      });
 } 



  loadAppInfo() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM appinfo', [])
          .then((data: any) => {
            if (data.rows.length > 0) {
              for (let k = 0; k < data.rows.length; k++) {
                // clsGlobal.dConfigMaster.Add(
                //   data.rows.item(k).sParamName,
                //   data.rows.item(k).sParamValue
                // );
              }
              resolve(true);
              return;
            }
            else {
              this.getAppInfo().then(async (data) => {
                await this.doBod('appinfo', this.formatted_date).then(res => {
                }).catch(err => {
                  console.log("Error in inserting appinfo in sqllite1." + err);
                  reject(err);
                });
                resolve(true);
              }).catch(error => {
                console.log("Error in inserting appinfo in sqllite2." + error);
                reject(false);
              })
            }
          }).catch((error: any) => {
            console.log("Error in inserting appinfo in sqllite3." + error.message);
            reject(error.message);
          });
      } catch (error) {
        console.log("Error in inserting appinfo in sqllite4." + error.message);
        reject(error.message)
      }
    });
  }

  /**
   * Desc : 1. To fetch JSON data from CDN service.
   *        2. 1st delete the old data from table then send that JSON data to add into SQL lite.
   */

  async getAppInfo() {
    return await new Promise(async (resolve, reject) => {
      try {

        const url = this.cdnurl + 'config/APPINFO.json';
        this.httpService.getStaticFile(url).subscribe(async (respData: any) => {

          if (respData != null && respData != undefined) {
            respData = JSON.parse(respData);
            for (let k = 0; k < respData.applicationconfig.length; k++) {
              // clsGlobal.dConfigMaster.Add(
              //   respData.applicationconfig[k].sParamName,
              //   respData.applicationconfig[k].sParamValue,
              // );
            }
            try {
              const insertRows = [];
              Array.prototype.forEach.call(respData.applicationconfig, results => {
                insertRows.push([
                  "INSERT INTO appinfo (sParamName,sParamValue) VALUES (?,?)",
                  [results.sParamName, results.sParamValue]
                ]);
              });
              this.database.sqlBatch(insertRows).then((result) => {
                resolve(true);
              }).catch(error => {
                reject(error.message);
              });

            } catch (error) {
              console.log("Error in insert app info in sqllite ." + error);
              reject(false);
            }
          }
        }, error => {
          reject(error);
          console.log('In http error  2 ' + JSON.stringify(error));
        });
      } catch (error) {
        console.log('In http error  3 ' + JSON.stringify(error));
        reject(error.message)
      }
    });
  }



  /**
 * Desc : Delete data from table.
 * @param tablename : Tablename to delete data.
 */

  async delete(tablename) {
    return await new Promise((resolve, reject) => {
      try {
        let query = "DELETE FROM " + tablename;
        this.database.executeSql(query, []).then(data => {
          resolve(data);
        }).catch(error => {
          reject(error.message);
        })
      } catch (error) {
        reject(error.message);
      }
    })
  }


  /**
  * Desc : 1. To fetch data from database (SQL lite) and stored it into local array.
  *        2. Call getMsgInfo() method to update data.
  */

  async loadMsgInfo() {
    return await new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM msginfo', [])
          .then((data: any) => {
            if (data.rows.length > 0) {
              for (let k = 0; k < data.rows.length; k++) {
                clsGlobal.dMsgMaster.Add(
                  data.rows.item(k).sMsgCode,
                  data.rows.item(k).sMessage,
                );
              }
              resolve(true);
              return;
            }
            else {
              this.getMsgInfo().then(async (data) => {
                await this.doBod('msginfo', this.formatted_date).then(res => {
                }).catch(err => {
                  console.log(err)
                  reject(err);
                });
                resolve(true);
              }).catch(error => {
                reject(false);
              })
            }
          }).catch((error: any) => {
            alert("in select msg info   " + error.message)
            reject(error.message);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
   * Desc : 1. To fetch JSON data from CDN service.
   *        2. 1st delete the old data from table then send that JSON data to add into SQL lite.
   */

  async getMsgInfo(): Promise<boolean> {
    return await new Promise(async (resolve, reject) => {
      try {
        //const url = this.CDNServiceURL + 'appconfig/MSGINFO.json';
        const url = this.cdnurl + 'config/MSGINFO.json';
        this.httpService.getStaticFile(url).subscribe(async (respData: any) => {
          if (respData != null && respData != undefined) {
            respData = JSON.parse(respData);
            for (let k = 0; k < respData.messagemaster.length; k++) {
              clsGlobal.dMsgMaster.Add(
                respData.messagemaster[k].sMsgCode,
                respData.messagemaster[k].sMessage
              );
            }
            const insertRows = [];
            Array.prototype.forEach.call(respData.messagemaster, results => {
              insertRows.push([
                "INSERT INTO msginfo (sMsgCode,sMessage) VALUES (?,?)",
                [results.sMsgCode, results.sMessage]
              ]);
            });
            await this.database.sqlBatch(insertRows).then((result) => {
              resolve(true);
            }).catch(error => {
              reject(error.message);
            });

            resolve(true);
          }
        }, error => {
          reject(error.msg);
          console.log('In http error  2 ' + JSON.stringify(error.msg));
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /**
    * Desc : 1. To fetch data from database (SQL lite) and stored it into local array.
    *        2. Call getFullScripMaster() method to update data.
    */
  async loadScripMaster() {
    return await new Promise((resolve, reject) => {
      try {
        //first check data exist or not.
        this.database.executeSql('SELECT COUNT(*) as TotalCount FROM scripmaster', []).then(data => {
          if (data.rows.length > 0) {
            if (data.rows[0] != undefined && data.rows[0].TotalCount != undefined && data.rows[0].TotalCount > 0) {
              //Go for incremental scrip master download TODO
              console.log("Table count(*) for ScripMaster ." + data.rows[0].TotalCount);
              resolve(true);
              return;
            }
            else {
              console.log("Table count(*) for ScripMaster is zero .1");
              // go for full download.
              this.getFullScripMaster();
              resolve(true);
              return;
            }
          }
          else {
            // go for full download.
            console.log("Table count(*) for ScripMaster is zero .2");
            this.getFullScripMaster();
            resolve(true);
            return;
          }
        }).catch((error: any) => {
          console.log("Error select Scrip master  loadScripMaster 1: " + error);
          reject(error.message);
        });
        //if data exist then go for incremental download
        //if data not exists then go for full download.
      }
      catch (error) {
        console.log("Error select Scrip master  loadScripMaster 2: " + error.message)
        reject(error.message);
      }
    });
  }

  /**
* Desc : 1. To fetch JSON data from CDN service.
*        2. 1st delete the old data from table then send that JSON data to add into SQL lite.
*/
  getFullScripMaster() {
    return new Promise(async (resolve, reject) => {
      try {
        //create array for every call.
        const exchangearray = //['NSE_EQ.json','NSE_FO.json'];
          ['NSE_EQ.json', 'NSE_FO.json',
            'BSE_EQ.json', 'BSE_FO.json',
            'MCX_FO.json', 'MCX_SPOT.json',
            'NCDEX_FO.json', 'NCDEX_SPOT.json',
            'NSE_CUR.json', 'BSE_CUR.json',
            'NSECUR_SPOT.json', 'BSECUR_SPOT.json'
          ];
        exchangearray.forEach(element => {
          try {
            this.httpService.getJson(this.cdnurl + "master/" + element, '').subscribe(async (respData: any) => {
              if (respData != null && respData != undefined) {
                try {
                  const insertRows = [];
                  const exchange = element.split('.')[0];
                  Array.prototype.forEach.call(respData, results => {
                    let _strikePrice = results.strike || "";
                    let _optiontype = results.opt || "";
                    let _expiry = results.exp || "";
                    let _desc = results.sym + " " + _expiry + " " + _strikePrice + " " + _optiontype;
                    insertRows.push([
                      "INSERT INTO scripmaster ( exchange  ,token  , symbol , series , instrument, expiry ,strikeprice , optiontype ," +
                      " tick , lotsize, assettoken, decimallocator, ordervalue, cmotcode , description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)",
                      [exchange,
                        results.code,
                        results.sym,
                        results.ser,
                        results.inst,
                        _expiry,
                        _strikePrice,
                        _optiontype,
                        results.tick,
                        results.lot,
                        results.at,
                        results.decloc,
                        "",
                        0,
                        _desc
                      ]
                    ]);
                  });
                  // const _insertRows=[];
                  // _insertRows.push(
                  //   ["INSERT INTO scripmaster ( exchange  ,token  , symbol , series , instrument, expiry ,strikeprice , optiontype , tick , lotsize , desc , sec , cc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)",

                  //   ["NSE_EQ", 
                  //     111,
                  //     "TEST", 
                  //     "EQ", 
                  //     "EQUITIES", 
                  //     "", 
                  //     "",
                  //     _optiontype, 
                  //     results.tick, 
                  //     results.lot, 
                  //     _desc,
                  //     0, 
                  //     0]
                  // ])
                  console.log("JSON FETCH for " + element + " No. of rows :" + insertRows.length);
                  this.database.sqlBatch(insertRows).then((result) => {
                    console.log(element + ' Inserted. ' + result);
                  }).catch(error => {
                    console.log("Error in sqlBatch Insert getFullScripMaster :" + error);
                    reject(error.message);
                  })
                  resolve(true);
                } catch (error) {
                  console.log("Error in fetching scrip master for  ." + element + " Error : " + error);
                }
                resolve(true);
              }
            }, error => {
              reject(error.msg);
              console.log('Error  getFullScripMaster 1 : ' + JSON.stringify(error));
            });
          } catch (error) {
            console.log("Error in getting file " + element + " Error " + error.message);
          }

        });

        await this.doBod('scripmaster', this.formatted_date).then(res => {
        }).catch(err => {
          console.log('Error  getFullScripMaster 2 : ' + err);
          reject(err);
        });

      } catch (error) {
        console.log('Error  getFullScripMaster 3 : ' + error);
        reject(error.message)
      }
    });
  }

  getAppInfoFromDB() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM appinfo', [])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              resolve(true);
              return;
            }
          }).catch((error: any) => {
            reject(error.message);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
  * Load scrips from database
  */
  getScripByToken(exchange, token, mktSegId) {
    return new Promise((resolve, reject) => {
      try {
        //console.log("Fetching Token details " + exchange + " Token " + token);
        this.database.executeSql('SELECT * FROM ScripMaster WHERE exchange= ? and token = ? ', [exchange, token]).then(data => {
          const scrips = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              //let objScrip = new ScripObject();
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.token = data.rows.item(i).token
              scripKey.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              scrips.push({
                id: data.rows.item(i).id,
                exchange: data.rows.item(i).exchange,
                exchangeName: clsTradingMethods.getExchangeName(scripKey.MktSegId),
                mktSegId: mktSegId,
                token: data.rows.item(i).token,
                symbol: data.rows.item(i).symbol,
                series: data.rows.item(i).series,
                instrument: data.rows.item(i).instrument,
                expiry: data.rows.item(i).expiry,
                sp: data.rows.item(i).strikeprice,//data.rows.item(i).sp,
                ot: data.rows.item(i).optiontype,//data.rows.item(i).ot,
                ts: data.rows.item(i).ts,
                ls: data.rows.item(i).ls,
                sec: data.rows.item(i).sec,
                cc: data.rows.item(i).cmotcode,//data.rows.item(i).cc,
                //strikeprice: data.rows.item(i).strikeprice,
                //optiontype: data.rows.item(i).optiontype,
                assettoken: data.rows.item(i).assettoken,
                //cmotcode: data.rows.item(i).cmotcode,
                decimallocator: data.rows.item(i).decimallocator,
                key: scripKey
              });
            }
          }
          resolve(scrips);
        }).catch((error: any) => {
          reject(error.message);
          console.log("Error in Fetching Token details 1" + exchange + " Token " + token + " Error :" + error.message);
        });
      }
      catch (error) {
        console.log("Error in Fetching Token details 2 " + exchange + " Token " + token + " Error :" + error.message);
        reject(error.message);
      }
    });
  }

  getScripByInstAndAssestToken(instrument, assettoken) {
    return new Promise((resolve, reject) => {
      try {
        //console.log("Fetching Token details " + exchange + " Token " + token);
        this.database.executeSql('SELECT * FROM ScripMaster WHERE instrument = ? and assettoken = ?', [instrument, assettoken]).then(data => {
          const scrips = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              //let objScrip = new ScripObject();
              let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(data.rows.item(i).exchange);
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.token = data.rows.item(i).token
              scripKey.MktSegId = mktSegId;//clsTradingMethods.GetMarketSegmentID(mktSegId);
              scrips.push({
                exchange: data.rows.item(i).exchange,
                exchangeName: clsTradingMethods.getExchangeName(mktSegId),
                mktSegId: mktSegId,
                token: data.rows.item(i).token,
                symbol: data.rows.item(i).symbol,
                series: data.rows.item(i).series,
                instrument: data.rows.item(i).instrument,
                expiry: data.rows.item(i).expiry,
                strikeprice: data.rows.item(i).strikeprice,
                optiontype: data.rows.item(i).optiontype,
                assettoken: data.rows.item(i).assettoken,
                cmotcode: data.rows.item(i).cmotcode,
                decimallocator: data.rows.item(i).decimallocator,
                key: scripKey
              });
            }
          }
          resolve(scrips);
        }).catch((error: any) => {
          reject(error.message);
          //console.log("Error in Fetching Token details 1" + exchange + " Token " + token + " Error :" + error.message);
        });
      }
      catch (error) {
        //console.log("Error in Fetching Token details 2 " + exchange + " Token " + token + " Error :" + error.message);
        reject(error.message);
      }
    });
  }

  /**
   * Desc : To add Watchlist Profile data into SQL lite.
   * @param profile : watchlist array JSON data.
   */

  addWatchlistProfile(profile) {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];
        Array.prototype.forEach.call(profile, results => {
          insertRows.push([
            "INSERT INTO watchlistprofile (nWatchListId,sWatchListName,bIsPrivate,bIsDefault,sCreatedBy,nTenantId) VALUES (?,?,?,?,?,?)",
            [results.nWatchListId, results.sWatchListName, results.bIsPrivate, results.bIsDefault, results.sCreatedBy, results.nTenantId]
          ]);
        });
        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })
        //resolve(true);
      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : To delete Watchlist Profile data into SQL lite.
   * @param profile : watchlist JSON data.
   */

  deleteWatchlistProfile(profile) {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];
        insertRows.push([
          "DELETE FROM watchlistprofile WHERE nWatchListId = ? and sCreatedBy = ?  ",
          [profile.nWatchListId, clsGlobal.User.userId]
        ]);

        if (profile.nTenantId != undefined && profile.nTenantId != "") {
          insertRows.push([
            "DELETE FROM watchlistscrip WHERE nWatchListId = ?",
            [profile.nWatchListId]
          ]);
        }

        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })

      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : To delete Watchlist Profile data into SQL lite.
   * @param profile : watchlist JSON data.
   */

  deleteWatchlistProfileScrip(profileId) {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];
        insertRows.push([
          "DELETE FROM watchlistscrip WHERE nWatchListId = ? ",
          [profileId]
        ]);
        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })

      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : To add Watchlist Profile Scrip data into SQL lite.
   * @param profile : watchlist scrip array JSON data.
   */

  addWatchlistProfileScrip(profileScrip) {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];
        Array.prototype.forEach.call(profileScrip, results => {
          insertRows.push([
            "INSERT INTO watchlistscrip (nWatchListId,nMarketSegmentId,nToken,nSequenceNo) VALUES (?,?,?,?) ",
            [results.nWatchListId, results.nMarketSegmentId, results.nToken, results.nSequenceNo]
          ]);
        });
        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })

      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : Update Default Watchlist Profile Scrip data into SQL lite.
   * @param profile : watchlist scrip data.
   */

  updateDefaultWatchlistProfile(profile) {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];

        if (profile.bIsPrivate.toString() == "false") {
          insertRows.push([
            "UPDATE watchlistprofile SET bIsDefault = ? WHERE nWatchListId = ? and sCreatedBy = ? ",
            [profile.bIsDefault, profile.profileId, clsGlobal.User.userId]
          ]);
        }
        else {
          insertRows.push([
            "UPDATE watchlistprofile SET bIsDefault = ? WHERE nWatchListId = ? and sCreatedBy IN( ?, ?) ",
            [profile.bIsDefault, profile.profileId, clsGlobal.User.userId, 'CHIEF']
          ]);
        }

        if (profile.bIsDefault) {
          insertRows.push(
            [
              "UPDATE watchlistprofile SET bIsDefault = ? WHERE nWatchListId <> ? and sCreatedBy IN( ?, ?) ",
              [!profile.bIsDefault, profile.profileId, clsGlobal.User.userId, 'CHIEF']
            ]);
        }

        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })

      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : Update Default Watchlist Profile Scrip data into SQL lite.
   * @param profile : watchlist scrip data.
   */

  updateWatchlistProfileName(profile) {
    return new Promise((resolve, reject) => {
      try {

        this.database.executeSql("UPDATE watchlistprofile SET sWatchListName = ? WHERE nWatchListId = ?", [profile.profileName, profile.profileId])
          .then((data: any) => {
            if (data.rows.length > 0) {
              resolve(true);
            } else {
              resolve(undefined);
            }
          }).catch(error => {
            reject(error.message);
          });

      } catch (error) {
        reject(error.message);
        console.log('Error in update Watchlist ProfileName in sqldb ' + error.message);
      }
    });
  }

  /**
   * Desc : To get Watchlist Profile data from SQL lite.
   * @param profile : watchlist profile array JSON data.
   */

  getWatchlistProfile() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM watchlistprofile where sCreatedBy IN (?,?)', [clsGlobal.User.userId, 'CHIEF'])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              //alert("in select app info count " + data.rows.length)
              const profileData = [];
              for (let i = 0; i < data.rows.length; i++) {
                //const element = data.rows[index];
                profileData.push({
                  nWatchListId: data.rows.item(i).nWatchListId,
                  sWatchListName: data.rows.item(i).sWatchListName,
                  bIsPrivate: data.rows.item(i).bIsPrivate,
                  bIsDefault: data.rows.item(i).bIsDefault,
                  sCreatedBy: data.rows.item(i).sCreatedBy,
                  nTenantId: data.rows.item(i).nTenantId
                })
              }
              resolve(profileData);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            //alert("in select app info " + error.message);
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
   * This will fetch watchlist only for User.
   */
  getWatchlistProfileOnlyForUser() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM watchlistprofile where sCreatedBy IN (?)', [clsGlobal.User.userId])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              //alert("in select app info count " + data.rows.length)
              const profileData = [];
              for (let i = 0; i < data.rows.length; i++) {
                //const element = data.rows[index];
                profileData.push({
                  nWatchListId: data.rows.item(i).nWatchListId,
                  sWatchListName: data.rows.item(i).sWatchListName,
                  bIsPrivate: data.rows.item(i).bIsPrivate,
                  bIsDefault: data.rows.item(i).bIsDefault,
                  sCreatedBy: data.rows.item(i).sCreatedBy,
                  nTenantId: data.rows.item(i).nTenantId
                })
              }
              resolve(profileData);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            //alert("in select app info " + error.message);
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
   * Desc : To get Watchlist Profile data from SQL lite.
   * @param profile : watchlist profile array JSON data.
   */

  getWatchlistProfileScrips(profileId) {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM watchlistscrip WHERE nWatchListId = ? ORDER BY nSequenceNo ASC', [profileId])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              //alert("in select app info count " + data.rows.length)
              const profileScripData = [];
              for (let i = 0; i < data.rows.length; i++) {
                //const element = data.rows[index];
                profileScripData.push({
                  nWatchListId: data.rows.item(i).nWatchListId,
                  nMarketSegmentId: data.rows.item(i).nMarketSegmentId,
                  nToken: data.rows.item(i).nToken,
                  nSequenceNo: data.rows.item(i).nSequenceNo
                })
              }
              resolve(profileScripData);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            //alert("in select app info " + error.message);
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  getWatchlistAllProfileScrips() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM watchlistscrip WHERE nWatchListId IN ( SELECT * FROM watchlistprofile WHERE sCreatedBy = ? ) ORDER BY nWatchListId ,nSequenceNo', [clsGlobal.User.userId])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              //alert("in select app info count " + data.rows.length)
              const profileScripData = [];
              for (let i = 0; i < data.rows.length; i++) {
                //const element = data.rows[index];
                profileScripData.push({
                  nWatchListId: data.rows.item(i).nWatchListId,
                  nMarketSegmentId: data.rows.item(i).nMarketSegmentId,
                  nToken: data.rows.item(i).nToken
                })
              }
              resolve(profileScripData);
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            ///alert("in select app info " + error.message);
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
   * Desc : To add Watchlist Profile Scrip data into SQL lite.
   * @param profile : watchlist scrip array JSON data.
   */

  getMaxWatchlistId() {
    return new Promise((resolve, reject) => {
      try {

        let defGuestWatchID = 10000;
        this.database.executeSql("SELECT MAX(nWatchListId) as MAXId FROM watchlistprofile where sCreatedBy = ? and nTenantId <> '' ", [clsGlobal.User.userId]).then(data => {
          if (data.rows.length > 0) {
            if (data.rows[0] != undefined && data.rows[0].MAXId != undefined && data.rows[0].MAXId > 0) {

              let maxID = parseInt(data.rows[0].MAXId) + 1;
              resolve(maxID);
              return;
            }
            else {

              resolve(defGuestWatchID);
              return;
            }
          }
          else {
            resolve(defGuestWatchID);
            return;
          }

        });

      } catch (error) {
        reject(error.message);
        console.log('Error in getMaxWatchlistId in sqldb ' + error.message);
      }
    });
  }

  isGlobalProfileScripExist(profileId) {
    return new Promise((resolve, reject) => {
      try {

        this.database.executeSql("SELECT COUNT(*) as ScripCnt FROM watchlistscrip where nWatchListId = ?  ", [profileId]).then(data => {
          if (data.rows.length > 0) {
            if (data.rows[0] != undefined && data.rows[0].ScripCnt != undefined && data.rows[0].ScripCnt > 0) {
              //let maxID = parseInt(data.rows[0].MAXId) + 1;
              resolve(true);
              return;
            }
            else {
              resolve(false);
              return;
            }
          }
          else {
            resolve(false);
            return;
          }

        });

      } catch (error) {
        resolve(false);
        console.log('Error in isGlobalProfileScripExist in sqldb ' + error.message);
      }
    });
  }

  isGlobalProfilExist(profileId) {
    return new Promise((resolve, reject) => {
      try {

        this.database.executeSql("SELECT COUNT(*) as ScripCnt FROM watchlistprofile where nWatchListId = ?  and sCreatedBy = ? ", [profileId, clsGlobal.User.userId]).then(data => {
          if (data.rows.length > 0) {
            if (data.rows[0] != undefined && data.rows[0].ScripCnt != undefined && data.rows[0].ScripCnt > 0) {
              //let maxID = parseInt(data.rows[0].MAXId) + 1;
              resolve(true);
              return;
            }
            else {
              resolve(false);
              return;
            }
          }
          else {
            resolve(false);
            return;
          }

        });

      } catch (error) {
        resolve(false);
        console.log('Error in isGlobalProfileScripExist in sqldb ' + error.message);
      }
    });
  }

  /**
  * Load Exchange from database
  */
  getSymbolExchange(symbol) {
    return new Promise((resolve, reject) => {
      try {
        //console.log("Fetching Token details " + exchange + " Token " + token);
        this.database.executeSql("SELECT * FROM ScripMaster WHERE symbol = ? and instrument='EQUITIES'", [symbol]).then(data => {
          const scrips = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              //let objScrip = new ScripObject();
              let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(data.rows.item(i).exchange);
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.token = data.rows.item(i).token
              scripKey.MktSegId = mktSegId;//clsTradingMethods.GetMarketSegmentID(mktSegId);
              scrips.push({
                id: data.rows.item(i).id,
                exchange: data.rows.item(i).exchange,
                exchangeName: clsTradingMethods.getExchangeName(mktSegId),
                mktSegId: mktSegId,
                token: data.rows.item(i).token,
                symbol: data.rows.item(i).symbol,
                series: data.rows.item(i).series,
                instrument: data.rows.item(i).instrument,
                expiry: data.rows.item(i).expiry,
                sp: data.rows.item(i).sp,
                ot: data.rows.item(i).ot,
                ts: data.rows.item(i).ts,
                ls: data.rows.item(i).ls,
                sec: data.rows.item(i).sec,
                cc: data.rows.item(i).cc,
                key: scripKey
              });
            }
          }
          resolve(scrips);
        }).catch((error: any) => {
          reject(error.message);
          //console.log("Error in Fetching Token details 1" + exchange + " Token " + token + " Error :" + error.message);
        });
      }
      catch (error) {
        //console.log("Error in Fetching Token details 2 " + exchange + " Token " + token + " Error :" + error.message);
        reject(error.message);
      }
    });
  }

  getScripFromInstrumentSymbol(searchText, instrument) {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM ScripMaster WHERE symbol Like ? and instrument Like ?', [searchText + "%", instrument + "%"]).then(data => {
          const scrips = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              //let objScrip = new ScripObject();
              let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(data.rows.item(i).exchange);
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.token = data.rows.item(i).token
              scripKey.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              scrips.push({
                exchange: data.rows.item(i).exchange,
                exchangeName: clsTradingMethods.getExchangeName(mktSegId),
                mktSegId: mktSegId,
                token: data.rows.item(i).token,
                symbol: data.rows.item(i).symbol.trim(),
                series: data.rows.item(i).series,
                instrument: data.rows.item(i).instrument,
                expiry: data.rows.item(i).expiry,
                strikeprice: clsTradingMethods.ConvertToRe(data.rows.item(i).strikeprice, mktSegId, data.rows.item(i).decimallocator.toString()),
                optiontype: data.rows.item(i).optiontype,
                assettoken: data.rows.item(i).assettoken,
                cmotcode: data.rows.item(i).cmotcode,
                decimallocator: data.rows.item(i).decimallocator,
                description: data.rows.item(i).description.trim(),
              });
            }
          }
          resolve(scrips);
        }).catch((error: any) => {
          reject(error.message);
          console.log("Error in Fetching scrip search record 1" + searchText + " Error :" + error.message);
        });
      }
      catch (error) {
        console.log("Error in Fetching scrip search record 2" + searchText + " Error :" + error.message);
        reject(error.message);
      }
    });
  }


  //this method will call when need to remove all data from sqllite.
  clear() {
    return new Promise((resolve, reject) => {
      this.sqliteporter
        .wipeDb(this.database)
        .then((data) => {
          resolve(data);
        }).catch((error) => {
          reject(error);
        });
    });
  }

  /**
 * for search scrip
 */
  getScripForSearch(searchText) {
    return new Promise((resolve, reject) => {
      try {
        //console.log("Fetching Token details " + exchange + " Token " + token);
        let count = 50; //parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SCRIP_SEARCH_COUNT) || '50');
        this.database.executeSql('SELECT * FROM ScripMaster WHERE description Like ? LIMIT ' + count + '', ["%" + searchText + "%"]).then(data => {
          const scrips = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              //let objScrip = new ScripObject();
              let mktSegId = clsTradingMethods.getMktSegFromApiExchangeName(data.rows.item(i).exchange);
              let scripKey: clsScripKey = new clsScripKey();
              scripKey.token = data.rows.item(i).token
              scripKey.MktSegId = clsTradingMethods.GetMarketSegmentID(mktSegId);
              scrips.push({
                id: data.rows.item(i).id,
                exchange: data.rows.item(i).exchange,
                exchangeName: clsTradingMethods.getExchangeName(scripKey.MktSegId),
                mktSegId: mktSegId,
                token: data.rows.item(i).token,
                symbol: data.rows.item(i).symbol,
                series: data.rows.item(i).series,
                instrument: data.rows.item(i).instrument,
                expiry: data.rows.item(i).expiry,
                sp: data.rows.item(i).sp,
                ot: data.rows.item(i).ot,
                ts: data.rows.item(i).ts,
                ls: data.rows.item(i).ls,
                sec: data.rows.item(i).sec,
                cc: data.rows.item(i).cc,
                assetToken: data.rows.item(i).assettoken,
                key: scripKey
              });
            }
          }
          resolve(scrips);
        }).catch((error: any) => {
          reject(error.message);
          console.log("Error in Fetching scrip search record 1" + searchText + " Error :" + error.message);
        });
      }
      catch (error) {
        console.log("Error in Fetching scrip search record 2" + searchText + " Error :" + error.message);
        reject(error.message);
      }
    });
  }

  addUserPreference(type, preference) {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('INSERT INTO userpreference (type,preference) VALUES (?,?)', [type, preference]).then(data => {
          // clsGlobal.inAppNotificationDetails.push({
          //   type: type,
          //   preference: preference
          // })
          resolve(true);
        }).catch(error => {
          reject(error.message);
        });
      }
      catch (error) {
        reject(error.message)
      }
    });
  }


  getUserPreference() {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM userpreference')
          .then((data: any) => {
            if (data.rows.length > 0) {
              // for (let i = 0; i < data.rows.length; i++) {
              //   clsGlobal.inAppNotificationDetails.push({
              //     type: data.rows.item(i).type,
              //     preference: data.rows.item(i).preference
              //   })
              // }
              resolve(data);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  getUserSpecificPreference(type) {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM userpreference where type = ?', [type])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // for (let i = 0; i < data.rows.length; i++) {
              //   clsGlobal.inAppNotificationDetails.push({
              //     type: data.rows.item(i).type,
              //     preference: data.rows.item(i).preference
              //   })
              // }
              resolve(data);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }
  deleteUserPreference(type) {
    return new Promise((resolve, reject) => {
      try {
        let query = "DELETE FROM userpreference WHERE type = ?";
        this.database.executeSql(query, [type]).then(data => {
          resolve(data);
        }).catch(error => {
          reject(error.message);
        })
      } catch (error) {
        reject(error.message);
      }
    })
  }
  updateUserPreference(type, preference) {
    return new Promise((resolve, reject) => {
      this.database.executeSql('UPDATE userpreference SET preference = ? WHERE type = ?', [preference, type]).then(res => {
        resolve(res);
      }).catch(err => {
        reject(err);
      })
    });
  }

  /**
   * Desc : To get Watchlist Profile data from SQL lite.
   * @param profile : watchlist profile array JSON data.
   */

  getWatchlisProfileScrips(profileId) {
    return new Promise((resolve, reject) => {
      try {
        this.database.executeSql('SELECT * FROM watchlistscrip WHERE nWatchListId = ? ORDER BY nSequenceNo ASC', [profileId])
          .then((data: any) => {
            if (data.rows.length > 0) {
              // to check data is available in db or not.
              //alert("in select app info count " + data.rows.length)
              const profileScripData = [];
              for (let i = 0; i < data.rows.length; i++) {
                //const element = data.rows[index];
                profileScripData.push({
                  nWatchListId: data.rows.item(i).nWatchListId,
                  nMarketSegmentId: data.rows.item(i).nMarketSegmentId,
                  nToken: data.rows.item(i).nToken,
                  nSequenceNo: data.rows.item(i).nSequenceNo
                })
              }
              resolve(profileScripData);
              return;
            } else {
              resolve(undefined);
            }
          }).catch((error: any) => {
            //alert("in select app info " + error.message);
            resolve(undefined);
          });
      } catch (error) {
        reject(error.message)
      }
    });
  }

  /**
  * Desc : To delete Watchlist alll Profile data into SQL lite.
  * @param profile : watchlist JSON data.
  */

  deleteAllWatchlistProfile() {
    return new Promise((resolve, reject) => {
      try {

        const insertRows = [];
        insertRows.push([
          "DELETE FROM watchlistprofile"]
        );

        insertRows.push([
          "DELETE FROM watchlistscrip"
        ]);

        this.database.sqlBatch(insertRows).then((result) => {
          resolve(true);
        }).catch(error => {
          reject(error.message);
        })

      } catch (error) {
        reject(error.message);
        console.log('Error in adding data to watchlist profile in sqldb ' + error.message);
      }
    });
  }

  isOtherUserProfileExist() {
    return new Promise((resolve, reject) => {
      try {

        this.database.executeSql("SELECT COUNT(*) as ProfileCnt FROM watchlistprofile where  sCreatedBy NOT IN (?) ", [clsGlobal.User.userId]).then(data => {
          if (data.rows.length > 0) {
            if (data.rows[0] != undefined && data.rows[0].ProfileCnt != undefined && data.rows[0].ProfileCnt > 0) {
              //let maxID = parseInt(data.rows[0].MAXId) + 1;
              resolve(true);
              return;
            }
            else {
              resolve(false);
              return;
            }
          }
          else {
            resolve(false);
            return;
          }

        });

      } catch (error) {
        resolve(false);
        console.log('Error in isOtherUserProfileExist in sqldb ' + error.message);
      }
    });
  }
}
