import { Injectable } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsAppConfigConstants } from '../../Common/clsAppConfigConstants';

@Injectable({ providedIn: 'root' })
export class ToastServicesProvider {
    private toastServiceTimer: number;
    constructor(
        private toastCtrl: ToastController,

    ) {
        // console.log('Hello ToastController Provider');
        this.toastServiceTimer = 2000;
    }
    /**
     * Added and updated by Omprakash on 18 Jan 2019
     * @param message , string value , will display as message.
     */
    async showAtTop(messagestring: string) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            cssClass: clsGlobal.defaultTheme,
            duration: this.toastServiceTimer,
            position: 'top',
            //dismissOnPageChange: true
        });
        await toast.present();
    }
    async showAtMiddle(messagestring: string) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            cssClass: clsGlobal.defaultTheme,
            duration: this.toastServiceTimer,
            position: "middle",
            //dismissOnPageChange: true
        });
        await toast.present();
    }
    async showAtBottom(messagestring: string) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            duration: this.toastServiceTimer,
            cssClass: clsGlobal.defaultTheme,
            position: "bottom"
        });
        await toast.present();
    }

    async showWithButton(messagestring: string, closeHandler?: any, btnText?: string, duration?: number) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            position: 'bottom',
            duration: duration,
            cssClass: clsGlobal.defaultTheme,
            buttons: [{ text: btnText || 'Ok', side: 'end', role: 'cancel' }]
        });

        toast.onDidDismiss().then(() => {
            if (closeHandler != undefined) {
                closeHandler();
            }
        });

        await toast.present();
    }

    async showWithUndoButton(messagestring: string, closeHandler?: any, btnText?: string, duration?: number) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            position: 'bottom',
            duration: duration,
            cssClass: clsGlobal.defaultTheme,
            buttons: [
                {
                    text: btnText || 'Ok',
                    side: 'end',
                    handler: () => {
                        if (closeHandler != undefined) {
                            closeHandler();
                        }
                    }
                }
            ]
        });

        toast.onDidDismiss().then(() => {
            // if (closeHandler != undefined) {
            //     closeHandler();
            // }
        });

        await toast.present();
    }

    async showWithButtonDismissOnPageChange(messagestring: string, closeHandler?: any) {
        const toast = await this.toastCtrl.create({
            message: messagestring,
            position: 'bottom',
            cssClass: clsGlobal.defaultTheme,
            //showCloseButton: true,
            //closeButtonText: 'OK',
            //dismissOnPageChange: true
        });

        toast.onDidDismiss().then(() => {
            if (closeHandler != undefined) {
                closeHandler();
            }
        });

        await toast.present();
    }
    /** dismissed only toast */
    dismissed() {
        try {
            //this.toastCtrl.dismiss();
        } catch (e) { }

    }
}

