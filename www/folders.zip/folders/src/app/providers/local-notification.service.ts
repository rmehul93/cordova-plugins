import { Injectable } from '@angular/core';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';

@Injectable({
  providedIn: 'root'
})
export class LocalNotificationService {

  constructor(private localNotifications: LocalNotifications) { 
  }

  /**
   * 
   * @param id :Notification ID
   * @param text :Nottification Text 
   * @param title : Notification Title
   * @param data : Data To Be pass on from Notification
   * @param icon : Notification Icon URL
   * @param sound : Notification sound URL , Avalible on Android Only,  use :   sound: isAndroid ? 'file://sound.mp3': 'file://beep.caf',
   * @param led : Notification Led Color Code , default set to #FFFFFF
   * @param trigger : Trigger Time to generate notification in milliseconds
   * @param actions : Providing actions for notification,  Default object actions object 
   *      actions : [
   *                  {id:'yes' , title:'Yes'},
   *                  {id:'no' , title:'No'}
   *                ]
   * 
   */
  scheduleNotification(id :number , text:string , title :string , data ? :any, icon ? : string  ,  sound ?:string,led ? :string , trigger ?:number, actions?:any ){
    this.localNotifications.schedule({
      id:id,
      text:text,
      title:title,
      data: data? data : null,
      icon:icon ? icon: "",
      sound: sound ? sound : "",
      led :led ? led : '#FFFFFF',
      trigger : {at: new Date(new Date().getTime() + trigger)},
      actions :actions ? actions : null,
    });


  }


  getInstanceOfLocalNotification(){
    return this.localNotifications;
  }

  getAllLocalNotifications(){
    this.localNotifications.getAll();
  }

  getLocalNotification(notificationId){
    this.localNotifications.get(notificationId);
  }
}
