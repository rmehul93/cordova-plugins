import { Injectable } from '@angular/core';
import * as socketIo from 'socket.io-client';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { clsConstants } from '../Common/clsConstants';
import { clsGlobal } from '../Common/clsGlobal';
import { clsAppConfigConstants } from '../Common/clsAppConfigConstants';

@Injectable({
  providedIn: 'root'
})
export class SocketIoServiceService {
  public socketURL: string = "";//"172.25.92.66:4002"; 
  private socket;
  private loginObject: any;
  observer_orders: Observer<any>;
  observer_alerts: Observer<any>;
  reconnectionAttempts: number = 0;
  config: any = {};
  isFirstTime = true;
  constructor() {



  }
  public initSocket(loginobj) {

    let retryCount = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_RECONNECTION_RETRY_COUNT));
    if (this.isFirstTime) {
      //retryCount = -1;
      if (retryCount == undefined || retryCount == -1) {
        retryCount = Infinity;
      }
      this.config = {
        transports: ['websocket'],
        reconnection: true,
        autoConnect: true,
        reconnectionAttempts: retryCount,
        reconnectionDelay: parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_SOCKET_RECONNECTION_TIME_VALUE)) || 2000,
        timeout: 3000
      };
      this.isFirstTime = false;
    }

    if (retryCount == -1 || this.reconnectionAttempts < retryCount) {
      this.reconnectionAttempts++;
      this.socketURL = loginobj.messageSocket || clsGlobal.dConfigMaster.getItem("APP_ONLINE_MESSAGE_SOCKET");
      this.socket = socketIo(this.socketURL, this.config);
      this.loginObject = loginobj;
      //console.log("Socket io initiating");

      this.socket.on('connect', () => {
        this.socket.emit('loginAPI', this.loginObject);
        this.messageReceviedListener();
        //this.reconnectionAttempts = 0;
      });
      this.socket.on('disconnect', () => {
        console.log("Socket io disconnect");
      });
    }
  }
  messageReceviedListener() {
    this.socket.on('MSG:DATA', (msgData) => {
      //console.log('MSG:DATA', msgData)
      if (msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_ORDER ||
        msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_TRADE ||
        msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_POS_CONV ||
        msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_GTD_ORDER) {

        if (this.observer_orders != undefined)
          this.observer_orders.next(msgData);

        clsGlobal.User.totalBuyingPower = undefined;
      }
      else if (msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_ALERT) {
        if (this.observer_alerts != undefined)
          this.observer_alerts.next(msgData);
      }
      else if (msgData.MesssageType == clsConstants.OMEX_MESSAGETYPE_MKTSTAT) {
        // will do.
      }
    });
    this.socket.on('MSG:MISC', (msgData) => {
      if (msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_ALERT) {
        if (this.observer_alerts != undefined)
          this.observer_alerts.next(msgData);
      }
    });
    this.socket.on('MSG:NOTRAN', (msgData) => {
      if (msgData.MessageType == clsConstants.OMEX_MESSAGETYPE_ALERT) {
        if (this.observer_alerts != undefined)
          this.observer_alerts.next(msgData);
      }
    });
    this.socket.on('event', function (data) {
      console.log("Event received.");
    });

    this.socket.on('disconnect', () => {
      setTimeout(() => {
        this.initSocket(this.loginObject);
      }, this.config.reconnectionDelay);
      //this.initSocket(this.loginObject);
    })
  }

  createOrderObservable(): Observable<any> {
    return new Observable(observer => {
      this.observer_orders = observer;
    });
  }
  createAlertsObservable(): Observable<any> {
    return new Observable(observer => {
      this.observer_alerts = observer;
    });
  }
  getOrders(): Observable<any> {
    return this.createOrderObservable();
  }
  getAlerts(): Observable<any> {
    return this.createAlertsObservable();
  }

}
