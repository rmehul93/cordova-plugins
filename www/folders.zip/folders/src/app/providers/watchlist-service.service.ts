import { Injectable } from '@angular/core';
import { NewWatchListProfile, NewWatchListScrips } from 'src/models';
import { clsCommonMethods } from '../Common/clsCommonMethods';
import { clsConstants } from '../Common/clsConstants';
import { clsGlobal } from '../Common/clsGlobal';
import { clsHttpService } from '../Common/clsHTTPService';
import { clsLocalStorageService } from '../Common/clsLocalStorageService';
import { clsTradingMethods } from '../Common/clsTradingMethods';
import { AppsyncDbService } from './appsync-db.service';
import { DatabaseService } from './database-services/database-services';
import { ToastServicesProvider } from './toast-services/toast.services';

@Injectable({
  providedIn: 'root'
})
export class WatchlistService {

  isAllProfileFetched = false;
  constructor(
    private objHttpService: clsHttpService,
    private localstorageservice: clsLocalStorageService,
    public toastProvider: ToastServicesProvider,
    private appSync: AppsyncDbService,
    private dbService: DatabaseService) {

  }

  getWatchlistProfile() {
    return new Promise((resolve, reject) => {
      try {

        this.appSync.getWatchListProfiles().then((arrProfile: NewWatchListProfile[]) => {

          if (arrProfile != undefined && arrProfile.length > 0) {
            resolve(arrProfile);
          } else {
            resolve(undefined);
          }

        }, error => {
          reject(error.message);
        });

      }
      catch (error) {
        reject(error.message);
      }
    });
  }

  getAllWatchlistProfile() {
    return new Promise((resolve, reject) => {
      try {

      }
      catch (error) {
        resolve(true)
        console.log('Error in getAllWatchlistProfile: ', (error.message));
      }
    });
  }

  getWatchlistProfileScrip(profileID, userId, bFetchScripData = true) {
    return new Promise((resolve, reject) => {
      try {
        // this.dbService.getWatchlistProfileScrips(profileID).then(data => {
        //   resolve(data);
        // }
        //   , (error) => {
        //     resolve(undefined);
        //   })
        if (bFetchScripData) {
          if (clsGlobal.profileScrip.ContainsKey(profileID)) {
            let arrScrips = clsGlobal.profileScrip.getItem(profileID);
            resolve(arrScrips);
          }
          else {
            this.appSync.getWatchListScrips(profileID, userId).then((arrProfile: NewWatchListScrips[]) => {

              if (arrProfile != undefined && arrProfile.length > 0) {
                let scripInfo = [];
                let arrScrip = [];

                for (let index = 0; index < arrProfile.length; index++) {
                  const element = arrProfile[index];
                  let Token = element.nToken;
                  let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId)
                  let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

                  arrScrip.push({ "mkt": exchange, "token": Token });
                }

                if (arrScrip.length > 0) {
                  let req = { scrips: arrScrip };

                  clsTradingMethods.getScripInfoElasticSearch(req, this.objHttpService).then((scripData: any) => {

                    if (scripData.status == true) {
                      if (scripData != undefined && scripData.result.length > 0) {

                        for (let index = 0; index < arrProfile.length; index++) {

                          const element = arrProfile[index];
                          let Token = element.nToken;
                          let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId)
                          let scripItem = scripData.result.filter(item => {
                            return mktSegId == clsTradingMethods.GetMarketSegmentID(parseInt(item.nMarketSegmentId)) &&
                              Token == item.nToken;
                          })

                          if (scripItem.length > 0) {
                            let selectedScripObj = clsCommonMethods.getScripObject(scripItem[0]).scripDetail;
                            if (selectedScripObj != undefined) {
                              scripInfo.push(selectedScripObj);
                            }
                          }
                        }

                        clsGlobal.profileScrip.Add(profileID, scripInfo);

                      }
                    }
                    resolve(scripInfo);

                  }, error => {
                    this.toastProvider.showAtBottom("Unable to fetch scrip details.");
                    resolve(undefined);
                  });

                } else {
                  resolve(undefined);
                }

              } else {
                resolve(undefined);
              }

            }, error => {
              reject(error.message);
            });

          }
        } else {
          this.appSync.getWatchListScrips(profileID, userId).then((arrProfile: NewWatchListScrips[]) => {

            if (arrProfile != undefined && arrProfile.length > 0) {
              //let scripInfo = [];
              let arrScrip = [];

              for (let index = 0; index < arrProfile.length; index++) {
                const element = arrProfile[index];
                let Token = element.nToken;
                let mktSegId = clsTradingMethods.GetMarketSegmentID(element.nMarketSegmetId)
                let exchange = clsTradingMethods.getApiExchangeName(mktSegId);

                arrScrip.push({scripDet:{ "MktSegId": mktSegId,"MapMktSegId": element.nMarketSegmetId, "token": Token }});
              }
              resolve(arrScrip);
            } else {
              resolve(undefined);
            }

          });
        }
      }
      catch (error) {
        reject(error.message);
      }
    });
  }

  getWatchlistAllProfileScrips() {
    return new Promise((resolve, reject) => {
      try {

        // this.dbService.getWatchlistAllProfileScrips().then((data: any) => {
        //   resolve(data);
        // }
        //   , (error) => {
        //     resolve(undefined);
        //   })
        resolve(undefined);
      }
      catch (error) {
        reject(error.message);
      }
    });
  }

  getGlobalWatchlistProfile() {
    return new Promise((resolve, reject) => {
      try {

        this.appSync.getWatchListGlobalProfiles().then((arrProfile: NewWatchListProfile[]) => {

          if (arrProfile != undefined && arrProfile.length > 0) {
            resolve(arrProfile);
          } else {
            resolve(undefined);
          }

        }, error => {
          reject(error.message);
        });
      }
      catch (error) {
        reject(error.message);
      }
    });
  }
  //clsGlobal.VirtualDirectory,
  addNewWatchlist(objWatchlist) {
    try {
      return new Promise(async (resolve, reject) => {

        await this.appSync.saveWatchListProfile(objWatchlist);
        resolve(true);
      });
    } catch (error) {

    }
  }

  addWatchlistScrip(objWatchlist, arrWatchlistScrip) {
    try {
      return new Promise(async (resolve, reject) => {

        await this.appSync.saveWatchListProfileScrips(objWatchlist, arrWatchlistScrip);
        if (clsGlobal.profileScrip.ContainsKey(objWatchlist.nWatchListId)) {
          clsGlobal.profileScrip.Remove(objWatchlist.nWatchListId);
        }
        resolve(true);

      });
    } catch (error) {

    }
  }

  updateWatchlistScrip(objWatchlist) {
    try {
      return new Promise((resolve, reject) => {


      });
    } catch (error) {

    }
  }

  deleteWatchlistScrip(objWatchlist) {
    try {
      return new Promise(async (resolve, reject) => {
        await this.appSync.deleteWatchListScrip(objWatchlist);
        if (clsGlobal.profileScrip.ContainsKey(objWatchlist[0].nWatchListId)) {
          //clsGlobal.profileScrip.Remove(objWatchlist[0].nWatchListId);
          let profileID = objWatchlist[0].nWatchListId;
          let arrScrips = clsGlobal.profileScrip.getItem(profileID);
          for (let index = 0; index < objWatchlist.length; index++) {
            const objScrip = objWatchlist[index];
            for (let ictr = 0; ictr < arrScrips.length; ictr++) {
              const element = arrScrips[ictr];
              if (element.scripDet.MapMktSegId == objScrip.nMarketSegmentId &&
                element.scripDet.token == objScrip.nToken) {
                arrScrips.splice(ictr, 1);
                break;
              }
            }
          }
          clsGlobal.profileScrip.Add(profileID, arrScrips);
        }
        resolve(true);

      });
    } catch (error) {

    }
  }

  deleteWatchlist(objWatchlist) {
    try {
      return new Promise(async (resolve, reject) => {
        await this.appSync.deleteWatchList(objWatchlist);
        if (clsGlobal.profileScrip.ContainsKey(objWatchlist.nWatchListId)) {
          clsGlobal.profileScrip.Remove(objWatchlist.nWatchListId);
        }
        resolve(true);

      });
    } catch (error) {

    }
  }

  updateDefaultProfile(objWatchlist) {
    try {
      return new Promise((resolve, reject) => {
        if (!clsGlobal.IsGuestUser) {

          this.objHttpService.postJson(clsGlobal.VirtualDirectory, clsConstants.NONTRANSACTIONAL + clsConstants.C_S_API_UPDATE_PROFILE_SCRIP, objWatchlist).subscribe((respProfile: any) => {
            //console.log('ProfileList: ' + respProfile.data);
            try {
              if (respProfile.status == "success") {

                //this.toastProvider.showAtBottom("Default profile set successfully.");
                this.dbService.updateDefaultWatchlistProfile(objWatchlist);
                resolve(true);

              } else {

                this.toastProvider.showAtBottom(respProfile.errorString);
                reject(respProfile.errorString);
              }
            } catch (error) {

              clsGlobal.logManager.writeErrorLog("watchlist-service", "updateDefaultProfile", error);
              reject(error);
            }
          },
            (error: any) => {
              reject(error);
            });
        }
        else {
          this.dbService.updateDefaultWatchlistProfile(objWatchlist);
          resolve(true);
        }
      });
    } catch (error) {

    }
  }

  updatProfileName(objProfile) {
    try {
      return new Promise((resolve, reject) => {

        this.appSync.updateWatchListProfile(objProfile).then(resule => {
          resolve(true);
        }, error => {
          resolve(false);
        });

      });
    } catch (error) {

    }
  }

  deleteAllWatchlist() {
    try {
      return this.dbService.deleteAllWatchlistProfile();
    } catch (error) {

    }
  }

  reorderWatchListScrip(watchListId, scripData) {
    try {

      return new Promise(async (resolve, reject) => {
        await this.appSync.reorderWatchListScrip(watchListId, scripData);
        if (clsGlobal.profileScrip.ContainsKey(watchListId)) {
          //clsGlobal.profileScrip.Remove(watchListId);
          let profileID = watchListId;
          let arrScrips = clsGlobal.profileScrip.getItem(profileID);
          let arrRearrange = [];
          for (let index = 0; index < scripData.length; index++) {
            const objScrip = scripData[index];
            let filterScrip = arrScrips.filter(element => {
              return element.scripDet.MapMktSegId == objScrip.nMarketSegmentId &&
                element.scripDet.token == objScrip.nToken;
            });
            arrRearrange.push(filterScrip[0]);
          }
          clsGlobal.profileScrip.Remove(profileID);
          clsGlobal.profileScrip.Add(profileID, arrRearrange);
        }
        resolve(true);
      });

    }
    catch (e) {

    }
  }

}
