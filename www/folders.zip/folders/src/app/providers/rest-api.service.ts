import { Injectable } from '@angular/core';
import { clsConstants } from '../Common/clsConstants';
import { clsGlobal } from '../Common/clsGlobal';
import { clsHttpService } from '../Common/clsHTTPService';
import { clsAPIParser } from '../communicator/clsAPIParser';

@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  apiParser: clsAPIParser;
  constructor(public httpClient: clsHttpService) {
    this.apiParser = clsAPIParser.Instance;
  }

  /**
   * @method : Process Login Request and return response
   * @param objUser : User Login Object
   */
  getLoginResponse(objUser: any) {
    let reqLogin = this.apiParser.getLoginRequest(objUser);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION, reqLogin).subscribe((resLogin: any) => {
        resolve(resLogin);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Process Logout request
   */
  getLogoutResponse() {
    return new Promise((resolve, reject) => {
      this.httpClient.deleteJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION).subscribe((reslogout: any) => {
        resolve(reslogout);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Process Registration Request and return response
   * @param regObj User Registration Object
   */
  getRegistrationResponse(regObj) {
    let reqRegistration = this.apiParser.getRegistrationRequest(regObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_REGISTRATION, reqRegistration).subscribe((resRegistration: any) => {
        resolve(resRegistration);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get User Profile details like bank account and basic details
   */
  getProfileResponse() {
    return new Promise((resolve, reject) => {
      this.httpClient.getJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_PROFILE).subscribe((profileRes: any) => {
        resolve(profileRes);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get User basic details 
   * @param userId User Id of User
   */
  getUserDetailsResponse(userId) {
    return new Promise((resolve, reject) => {
      this.httpClient.getJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.LocalComId + clsGlobal.versionId + '/getUserDetails/' + userId).subscribe((userDetailsRes: any) => {
        resolve(userDetailsRes);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get User Balance details
   */
  getUserBalanceResponse() {
    return new Promise((resolve, reject) => {
      this.httpClient.getJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_BALANCE).subscribe((balanceRes: any) => {
        resolve(balanceRes);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get Forgot Mpin Otp Response
   * @param resetMpinObj : Reset MPIN Object
   */
  getForgotMpinOtpResponse(resetMpinObj) {
    let reqResetMpinObj = this.apiParser.getForgotMpinOtpRequest(resetMpinObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_RESET_MPIN_OTP, reqResetMpinObj).subscribe((resResetmpin: any) => {
        resolve(resResetmpin);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get Forgot Mpin Response
   * @param resetMpinObj : Forgot Mpin Object
   */
  getForgotMpinResponse(resetMpinObj) {
    let reqResetMpinObj = this.apiParser.getForgotMpinChangeRequest(resetMpinObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_VERIFY_MPIN_OTP, reqResetMpinObj).subscribe((resResetmpin: any) => {
        resolve(resResetmpin);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get Forgot Password Response
   * @param resetPasswordObj : Forgot Password Object
   */
  getForgotPasswordResponse(resetPasswordObj) {
    let reqVerifyPasswordObj = this.apiParser.getForgotPasswordOtpRequest(resetPasswordObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_VERIFY_PASSWORD_OTP, reqVerifyPasswordObj).subscribe((resResetpassword: any) => {
        resolve(resResetpassword);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Get Forgot Password Otp response
   * @param resetPasswordObj Forgot Password Otp Object
   */
  getForgotPasswordOtpResponse(resetPasswordObj) {
    let reqResetMpinObj = this.apiParser.getForgotMpinOtpRequest(resetPasswordObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_RESET_PASSWORD_OTP, reqResetMpinObj).subscribe((resResetpassword: any) => {
        resolve(resResetpassword);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });

  }
  /**
   * @method : Get Change MPIN Response
   * @param resetMPINObj Change MPIN Object
   */
  getChangeMPINResponse(resetMPINObj) {
    let reqResetMpinObj = this.apiParser.getChangeMPINRequest(resetMPINObj);
    return new Promise((resolve, reject) => {
      this.httpClient.putJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_CHANGE_MPIN, reqResetMpinObj).subscribe((resResetMPIN: any) => {
        resolve(resResetMPIN);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  /**
   * @method : Process change password request
   * @param changePasswordObj Change Password Object
   */
  getChangePasswordResponse(changePasswordObj) {
    let reqChgPasswordObj = this.apiParser.getChangePwdRequest(changePasswordObj);
    return new Promise((resolve, reject) => {
      this.httpClient.putJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.versionId + clsConstants.C_S_API_AUTHENTICATION_CHANGE_PASSWORD, reqChgPasswordObj).subscribe((resChangePassword: any) => {
        resolve(resChangePassword);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

  handleError(objError, reject) {
    try {
      if (objError.status != 0) {
        if(objError.status==503 || objError.status==500) // If service not available.
        {
          reject("Unable to proceed. Please try after sometime. Error code:"+objError.status);
        }
        else if (objError.status=400) 
        {
          //added by Vivian F to Handle navigation at UI end , based on error code
          let msg = (objError.error.errors) ? {"errorCode":objError.error.errors,"message":objError.error.message } : objError.error.message;  
          reject(msg);
        }
        else {
          reject("Oops something went wrong. Unable to proceed. Error code:"+objError.status);
        } 
      } else {
        reject("Oops something went wrong. Unable to proceed.");
      }
    } catch (error) {

    }
  }

  /**
   * @method : Process Fingerprint enable request
   * @param fingerprintEnableObj Fingerprint Enable Object
   */
  getfingerprintEnableResponse(fingerprintEnableObj) {
    let reqfingerprintEnableObj = this.apiParser.getFingerPrintEnableRequest(fingerprintEnableObj);
    return new Promise((resolve, reject) => {
      this.httpClient.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.LocalComId + clsGlobal.versionId + '/' +'validateOTPNormal', reqfingerprintEnableObj).subscribe((resfingerprintEnableObj: any) => {
        resolve(resfingerprintEnableObj);
      },
        (error: any) => {
          this.handleError(error, reject);
        });
    });
  }

}
