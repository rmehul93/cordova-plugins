import { Injectable } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouterExtService {

  private previousUrl: string = undefined;
  private currentUrl: string = undefined;

  constructor(private router: Router) { }

  initRouterListening() {
    this.currentUrl = this.router.url;
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
        //console.log('previousUrl: ' + this.previousUrl);
        //console.log('currentUrl: ' + this.currentUrl);
      };
    });
  }

  public getPreviousUrl(){
    return this.previousUrl;
  }
}
