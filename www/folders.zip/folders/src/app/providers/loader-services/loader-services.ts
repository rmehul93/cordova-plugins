import { Injectable } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { clsGlobal } from '../../Common/clsGlobal';
import { clsAppConfigConstants } from '../../Common/clsAppConfigConstants';

@Injectable({ providedIn: 'root' })
export class LoaderServicesProvider {

  constructor(private loadingCtrl: LoadingController) {
    console.log('Hello LoaderServicesProvider Provider');
    this.durationTime = parseInt(clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_LOADER_DISPLAY_MILLISECONDS)) || 20000;
  }
  private loadingElement: any;
  private durationTime: number;

  async  showLoader(dismissonPageChange?:boolean) {
    if (!this.loadingElement) {
      this.loadingElement = await  this.loadingCtrl.create({
        spinner: null,//"crescent",
        message: "<div><div class='ion-text-center ion-padding flex-body-content'><ion-spinner name='crescent' class='small-loader'></ion-spinner></div></div>",
        //dismissOnPageChange: dismissonPageChange!=undefined?dismissonPageChange:true,
        backdropDismiss: false,
        showBackdrop: true,
        duration: this.durationTime //default 20 sec Number of milliseconds to wait before dismissing the loading indicator.
      });
      await  this.loadingElement.present();
    }
    else
    {
      this.loadingElement=undefined;
    }
  }

  hideLoader() {
    if (this.loadingElement != undefined) {
      this.loadingElement.dismiss().then(()=>{
        this.loadingElement = undefined;
      });
    }
  }

  showLoaderforText(dismissonPageChange?:boolean) {
    if (!this.loadingElement) {
      this.loadingElement = this.loadingCtrl.create({
        spinner: null,
        message: "<div class='voice-loader'></div>",
        //dismissOnPageChange: dismissonPageChange||true,
        backdropDismiss: false,
        showBackdrop: true,
        duration: this.durationTime //default 20 sec Number of milliseconds to wait before dismissing the loading indicator.
      });
      this.loadingElement.present();
    }
  }

  hideLoaderforText() {
    if (this.loadingElement != undefined) {
      this.loadingElement.dismiss();
      this.loadingElement = undefined;
    }
  }
}
