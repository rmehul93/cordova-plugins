import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class NavParamService {
   myParam: any; // of course replace any with a nice interface of your own
   otp: any;
   mobile: any;
   page: any;
   multileg : any;
   pageData:any;
 }