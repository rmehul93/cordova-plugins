import { Injectable } from '@angular/core';
import { Socket } from 'ngx-socket-io';


export class SocketConfig extends Socket {

  constructor() { 
    super({url : "ws://172.25.91.40:4002" , options:{transports:['websocket']}});
   }
 
}
@Injectable({
  providedIn: 'root'
})
export class SocketService {
  constructor(private socketConfig: SocketConfig) {  
   }

   connectSocket(){
    this.socketConfig.connect();
   }
   disconnectSocket(){
     this.socketConfig.disconnect();
   }

   getSocketConfig(){
     return this.socketConfig;
   }

   loginToSocketServer(msgLogin:any){
    this.socketConfig.emit('loginAPI', msgLogin);
   }

   getOrderMessage(){
     return this.socketConfig.fromEvent("MSD:DATA");
   }

   getConnectMessage(){
     return this.socketConfig.fromEvent("connect");
   }

   getDisConnectMessage(){
    return this.socketConfig.fromEvent("disconnect");
  }


}
