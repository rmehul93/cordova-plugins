import { Injectable } from '@angular/core';
import { clsHttpService } from '../../Common/clsHTTPService';
import { clsGlobal,clsPluginConstants } from '../../Common/clsGlobal';
 
@Injectable({ providedIn: 'root' })
export class LogServicesProvider {
  analyticArray:any=[];
  constructor(public http: clsHttpService) {
    try {
      //write data in analytics after every 15 sec.
      setInterval(() => this.CheckAndWritingAnalytics(), 15000);
    }
    catch (error) {
      console.log("Unable to write analytics data." + error);
    }
  }
   
  CheckAndWritingAnalytics()
  {
    try {
      {
        if(this.analyticArray.length>0){
          let _data=this.analyticArray;
          this.analyticArray=[];
        this.http.postWithHeaders(clsGlobal.VirtualDirectory, clsGlobal.AnalyticsService + clsGlobal.LocalComId + 'v1/writetoAnalytics', _data).subscribe((data => {
          
        }), error => {
           console.log("Error in analytics writing "+error);
        });
       }
      }
    } catch (error) {
      console.log("Error in checkandWriting analytics"+error);
    }
  }
  writeErrorLog(pageName, functionName, exception) {
    try {
      let errorData: any = {};

      errorData.tenantId = clsGlobal.LocalComId.replace('/','');
      errorData.UserId = clsGlobal.User.userId;
      errorData.DateTime = clsGlobal.dateFormatter.transform(new Date(), 'ddMMMyyyy HH:mm:ss');
      errorData.pageName = pageName;
      errorData.functionName = functionName;
      errorData.errorMsg = exception.message==undefined?exception:exception.message;

      this.http.postJson(clsGlobal.VirtualDirectory, 'loggerservice/apperror', errorData).subscribe((data => {
        // console.log(data);
      }), error => {
        //console.log(error);
      })
    } catch (error) {

    }
  }

  createLogPayload(fileName, methodName, message, description, callstack, labels, tags) {
    return {
        "file": fileName,
        "function": methodName,
        "message": message,
        "desc": description,
        "stack": callstack,
        "labels": labels, //can be JSON Array with file, function, checkpoint
        "tags": tags //can be JSON Array with tags attached
    }
  }
  
  writeLog(tenantId, type, reqHeader, payload) {
    try {
        if (!reqHeader && clsGlobal.User.sessionId) {
          reqHeader = {'Authorization': 'Bearer ' + clsGlobal.User.sessionId};
        }
        
        let data = {
            "time": new Date().toISOString(),
            "service": {
                "ip": clsGlobal.URL,
                "port": clsGlobal.PORT,
                "seqNo": clsGlobal.logSequenceNo++
            },
            "tenantId": tenantId,
            "type": type,
            "reqHeader": reqHeader,
            "payload": payload
        }
  
        this.http.postJson(clsGlobal.VirtualDirectory, 'loggerservice/apperror', data).subscribe((data => {
          // console.log(data);
        }), error => {
          //console.log(error);
        })
    } catch (error) {
        console.log('Exception in writing log: ' + error);
    }
  }
  
  writeUserAnalytics(pagename:any,message:any,eventName?:any,eventData?:any)
  {
    try {
      let analyticsData: any = {};
    analyticsData.UId = clsGlobal.User.userId || '';
    analyticsData.Dt = clsGlobal.dateFormatter.transform(new Date(), 'dd/MMM/yyyy HH:mm:ss');
    analyticsData.PName=pagename || '';
    analyticsData.EName=eventName || '';//Search , profile , theme change, OE
    //KEYS , SEARCH_, PROFILE_ADD,PROFILE_REMOVE, OE_SCRIP_
    analyticsData.EData=eventData  || '';//search script , profile remove add,theme change , OE script.
    analyticsData.UDID= clsPluginConstants.DeviceUDID  || '';
    analyticsData.Model= clsPluginConstants.DeviceModel || '',//MI A1, J5
    analyticsData.SrNo=clsPluginConstants.DeviceSerialNo || '',//MI A1, J5
    analyticsData.Mfc= clsPluginConstants.DeviceManufacturer|| '',// MI Motorola,
    analyticsData.Pl= clsPluginConstants.DevicePlatform || '',//andriod ios etc.
    analyticsData.PlVr= clsPluginConstants.DevicePlatformVersion || '',// 8.0, 11.2 etc
    analyticsData.Lon= clsPluginConstants.GeoLocLongitude || '';
    analyticsData.Lat= clsPluginConstants.GeoLocLatitude || '';
    //analyticsData.AName= clsPluginConstants.AppName || '';
    analyticsData.AVr= clsPluginConstants.AppVersion || '';
    //analyticsData.AVerCode= clsPluginConstants.AppVersionCode || '';
    analyticsData.Pkg= clsPluginConstants.AppPackageName || '';
    analyticsData.FKey= clsPluginConstants.fcmRegKey || '';
    analyticsData.Msg=message || '';
    analyticsData.PTag = '';
    analyticsData.PData = '';
    this.analyticArray.push(analyticsData);
    } catch (error) {
      console.log("Error in writeUserAnalytics."+error);
    }
  }

}
