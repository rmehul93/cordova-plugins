import { Injectable } from '@angular/core';
import { Animation, AnimationController } from '@ionic/angular';
import { Gesture, GestureController } from '@ionic/angular';
import { CupertinoPane, CupertinoSettings } from 'cupertino-pane';

@Injectable({
  providedIn: 'root'
})
export class GlobalAnimationService {

  constructor(private animationCtrl: AnimationController,
    private gestureCtrl: GestureController
    ) { }
      myPane :any;
  watchListPaneBottomToTop(myElementRef:any){
    let settings: CupertinoSettings = { 
      breaks: {
        top: { // Topper point that pane can reach
          enabled: true, // Enable or disable breakpoint
          height: window.screen.height, // Pane breakpoint height
          bounce: true // Bounce pane on transition
        }
        , middle: {  
            enabled: true, // Enable or disable breakpoint
            height: window.screen.height - (45), // Pane breakpoint height
            bounce: true // Bounce pane on transition 
         },
         bottom: { 
          enabled: true, // Enable or disable breakpoint
          height: window.screen.height - (45+50), // Pane breakpoint height
          bounce: true // Bounce pane on transition 
          } 
      },
      bottomClose:false,
      lowerThanBottom:false,
      buttonClose:false,
      showDraggable:false,
      handleKeyboard:false,
      onWillDismiss: () => {
        console.log("Will dismiss");
      },
      onDragEnd:()=>{
        console.log("onDragEnd ends");
        this.consoleCurrentPostion();
      },
      onTransitionEnd:()=>{
        console.log("onTransitionEnd ends");
        this.consoleCurrentPostion();
      }
    };
    this.myPane = new CupertinoPane(myElementRef, settings);
    //this.myPane.enableDrag();
    this.myPane.present({animate: true});
    
    setTimeout(() => {
      this.myPane.moveToBreak('top');
    }, 2000);
  }
  consoleCurrentPostion()
  {
     console.log(this.myPane.currentBreak());
  }
  dontMissCardRightToLeft(myElementRef:any)
  {
    console.log("Animation for hot cards called.");
    const animation: Animation = this.animationCtrl.create()
    .addElement(myElementRef)
    .duration(1000)
    .iterations(1)
    .fromTo('transform', 'translateX(300px)', 'translateX(0px)')
    //.fromTo('opacity', '1', '0.2');
    animation.play();
  }
  swipeGesture(myElementRef:any)
  {
    const gesture = this.gestureCtrl.create({
      el: myElementRef,
      threshold: 15,
      gestureName: 'my-gesture',
      onMove: (detail) => { this.onMove(detail); }
    });
    gesture.enable();
  }
  onMove(detail) {
    const type = detail.type;
    const currentX = detail.currentX;
    const deltaX = detail.deltaX;
    const velocityX = detail.velocityX;
    console.log("Gesture "+type +" currentX"+currentX + " deltaX"+deltaX +" velocityX"+velocityX);
     
  }
}
