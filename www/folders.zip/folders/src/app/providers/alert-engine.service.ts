import { Injectable } from '@angular/core';
import { clsGlobal } from '../Common/clsGlobal';
import { clsHttpService } from '../Common/clsHTTPService';

@Injectable({
  providedIn: 'root'
})
export class AlertEngineService {

  constructor(private http: clsHttpService) { }

  getScripAlerts() {
    return new Promise((resolve, reject) => {
      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.AlertKafka + clsGlobal.LocalComId + 'v1/alerts/getUserAlerts/' + clsGlobal.User.userId).subscribe((scripAlerts: any) => {
        resolve(scripAlerts);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  setScripAlert(alertRequest:any){
    
    return new Promise((resolve, reject) => {
      this.http.postJson(clsGlobal.VirtualDirectory, clsGlobal.AlertKafka + clsGlobal.LocalComId + 'v1/alerts/setScripAlert', alertRequest).subscribe((scripAlertResponse: any) => {
        resolve(scripAlertResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


  deleteAlert(alertId:any){
    return new Promise((resolve, reject) => {
      this.http.deleteJson(clsGlobal.VirtualDirectory, clsGlobal.AlertKafka + clsGlobal.LocalComId + 'v1/alerts/setScripAlert/' + clsGlobal.User.userId + '/' + alertId).subscribe((scripAlertResponse: any) => {
        resolve(scripAlertResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }

  updateScripAlert(alertRequest:any){
    return new Promise((resolve, reject) => {
      this.http.putJson(clsGlobal.VirtualDirectory, clsGlobal.AlertKafka + clsGlobal.LocalComId + 'v1/alerts/setScripAlert', alertRequest).subscribe((scripAlertResponse: any) => {
        resolve(scripAlertResponse);
      },
        (error: any) => {
          reject(error);
        });
    });
  }


}
