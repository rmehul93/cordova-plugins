import { Injectable } from '@angular/core';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';

@Injectable({ providedIn: 'root' })
export class BrowserServicesProvider {

  constructor(private iab: InAppBrowser
    ) {
    console.log('Hello BrowserServicesProvider Provider');
    //
  }
  /**
   *
   * @param title title for inappbrowser(not in use)
   * @param sURL url to open
   * @param mode 1 means system(chrome, safari) 2 means inApp
   */
  openBrowser(title:string,sURL:string, mode?:number)
  {
    try {
      var browser;
      if( mode==undefined || mode==null || mode==1)
      {
         browser=this.iab.create(sURL,"_system");
      }
      else if(mode==2)
      {
         browser=this.iab.create(sURL,"_blank");
      }
      else{ //third mode will open url in iframe in iframe-container page
        //this.navCtrl.push(IframeContainerPage, {title:title,url:sURL});
      }
      browser.show();
    } catch (error) {
      //this.toastctrl.showAtBottom(error);
    }
  }

}
