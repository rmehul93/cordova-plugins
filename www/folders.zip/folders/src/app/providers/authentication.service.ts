import { AlertEngineService } from './alert-engine.service';
import { Injectable } from '@angular/core';
import { clsCommunicatorProvider } from '../communicator/clsCommunicatorProvider';
import { clsHttpService } from '../Common/clsHTTPService';
import { clsGlobal, clsPluginConstants } from '../Common/clsGlobal';
import { reject } from 'q';
import { clsCommonMethods } from '../Common/clsCommonMethods';
import { AlertServicesProvider } from './alert-services/alert-services';
import { clsConstants } from '../Common/clsConstants';
import { ToastServicesProvider } from './toast-services/toast.services';
import { clsLocalStorageService } from '../Common/clsLocalStorageService';
import { clsExchManager } from '../Common/clsExchManager';
import { NavController, Platform } from '@ionic/angular';
import { RestApiService } from './rest-api.service';
import { SocketIoServiceService } from 'src/app/providers/socket-io-service.service';
import { AppsyncDbService } from './appsync-db.service';
import { Hub } from 'aws-amplify';
import { LocalNotificationService } from './local-notification.service';
import { clsTradingMethods } from 'src/app/Common/clsTradingMethods';
import { TransactionService } from './transaction.service';
import { clsAppConfigConstants } from '../Common/clsAppConfigConstants';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  reqId: string = (new Date()).getHours() + '' + (new Date()).getMinutes() + '' + (new Date()).getSeconds() + '' + (new Date()).getMilliseconds();
  alertSubscription: any;
  orderSubscription :any;
  constructor(
    private navCtrl: NavController,
    //private chatClient: ChatService,
    private commService: clsCommunicatorProvider,
    private http: clsHttpService,
    private alertProvider: AlertServicesProvider,
    private toastProvider: ToastServicesProvider,
    private objStorage: clsLocalStorageService,
    private localNotificationService : LocalNotificationService ,
    private platform: Platform,
    private socketService: SocketIoServiceService,
    private alertEngineService: AlertEngineService,
    private toastObj: ToastServicesProvider,
    private appSync: AppsyncDbService,
    private restApiService: RestApiService,
    private tranServ: TransactionService) {
  }
  login(reqLogin) {
    return new Promise((resolve, reject) => {
      this.restApiService.getLoginResponse(reqLogin).then((resp: any) => {
        console.log(JSON.stringify(resp));
        this.processLoginResponse(resp, reqLogin)
        resolve(resp)
      },
        (error) => {
          reject(error)
          // this.toastProvider.showAtBottom(error);
        });
    });
  }
  loginWithMPIN(reqLogin) {
    return new Promise((resolve, reject) => {
      this.restApiService.getLoginResponse(reqLogin).then((resp: any) => {
        console.log(resp)
        this.processLoginResponse(resp, reqLogin)
        resolve(resp)
      },
        (error) => {
          reject(error)
          //this.toastProvider.showAtBottom(error);
        });
    });
  }
  private InitiateSocketConnection(resp) {
    let msgLogin: any = {};  
    msgLogin.jToken = resp.data.access_token;
    msgLogin.jRequestID = this.reqId;
    msgLogin.messageSocket=resp.data.others.messageSocket;
    this.socketService.initSocket(msgLogin);//socket i.o server connection.
   
  }
  public DisconnectionSocketConnetion() {
    this.commService.disConnectBroadcast();
  }

  private subscribeAlerts() {

    this.alertSubscription = this.socketService.getAlerts().subscribe((data) => {
      console.log("Alert data" , data);
      if(data.triggered == 1){
        let alertInAppNotificationObject;
        if(clsGlobal.inAppNotificationDetails.length > 0 ){
          alertInAppNotificationObject =  clsGlobal.inAppNotificationDetails.filter(x=> { return x.type == "alerts"} )[0];
        }
        if(alertInAppNotificationObject.selected){
          this.localNotificationService.scheduleNotification(1, "Alert Triggred" , data.data.remarks , data , "", "" , "" , 100 ,[])
        }else{
          let msg = "Alert Triggred" +  data.data.remarks ;
          // this.toastObj.showWithButton(msg , ()=>{

          // });
        }
        
      }
     
    });

    this.orderSubscription= this.socketService.getOrders().subscribe((data)=>{
      let orderInAppNotificationObject ;
      if(clsGlobal.inAppNotificationDetails.length > 0 ){
        orderInAppNotificationObject =  clsGlobal.inAppNotificationDetails.filter(x=> { return x.type == "order_message"} )[0];
      }
      
      if(orderInAppNotificationObject && orderInAppNotificationObject.selected){
        this.localNotificationService.scheduleNotification(1, "Order Traded" , "order Trader for " + data.Symbol , data , "", "" , "" , 100 ,[])
      }else{
        // let msg = "Order Traded for " +  data.Symbol ;
        //   this.toastObj.showWithButton(msg , ()=>{
        //  });
      }
  });

    try {
      this.alertEngineService.getScripAlerts().then((alertsResponse: any) => {
        if (alertsResponse.status = 'success') {
          clsGlobal.scripAlertsList = alertsResponse.data;
        }
      }, error => {
        console.log(error)
      })
    } catch (error) {
      clsGlobal.logManager.writeErrorLog('Authentication Service', 'getScripAlerts', error.message);
    }
  }

  private unsubscribeAlerts() {
    this.alertSubscription = null;

  }
  private processLoginResponse(response, reqLogin) {
    try {
      if (response.status == "success") {
        if (response.data.logonstatus) {
          //not getting logonstatus from response
          //TODO//!response.result.logonstatus  
          this.forceLogin(response, reqLogin);
        }
        else {
         
          clsGlobal.IsSessionExpiredGateway = false;//changes for gateway session expired.
          this.setUserDetails(response, reqLogin);
          //socket creation
          this.InitiateSocketConnection(response);
        }
      } else {
        //resolve("false", response);
        //reject(response);
        this.toastProvider.showWithButtonDismissOnPageChange(response.errorString);
      }
    } catch (error) {
      //this.loadingCtrl.hideLoader();
      //console.log(error);
      reject(error);
      clsGlobal.logManager.writeErrorLog("authentication.service", "processLoginResponse", error);
    }
  }
  forceLogin(response, reqLogin) {
    if (response.data.messageCode == 'FORCELOGIN') {
      let buttons: any = ['Confirm', 'cancel']
      this.alertProvider.showAlertConfirmWithButtons('FORCE LOGIN', response.result.message, buttons,
        () => {
          reqLogin.forceLogin = true;
          //this.replicateUserDataFromcouch(clsGlobal.User.userId);
          //"http://172.25.100.174:9900/"
          this.http.postJson(clsGlobal.VirtualDirectory, clsConstants.AUTHENTICATION + clsGlobal.LocalComId + 'v1/applogin', reqLogin).subscribe(data => {
            this.processLoginResponse(data, reqLogin);
          }, error => {
            reject(error);
          });
        },
        () => {
          //fail No or cancel click //do nothing.
          // resolve("false", response);
        });
    }
  }
  async setUserDetails(response, reqLogin) {
    try {
      try {
        this.commService.disConnectBroadcast();
      } catch (error) {
        clsGlobal.logManager.writeErrorLog("MpinloginPage", "setUserDetails_1", error.message);
      } 
      clsGlobal.IsGuestUser = false; //user is register user.
      let exchArr = response.data.exchanges;
      let mktSegAllowed = clsTradingMethods.getApiExchangeMktSegment(response.data.exchanges);
      clsGlobal.User.userId = reqLogin.user_id;
      clsGlobal.User.userName = response.data.user_name;
        
      try {
        if(response.data.others!=undefined)
        { 
        clsGlobal.User.userCode = response.data.others.userCode;
        clsGlobal.User.groupId = response.data.others.groupId;
        clsGlobal.User.groupCode = response.data.others.groupCode;
        clsGlobal.User.NewsCategories = response.data.others.newsCategories;
        clsGlobal.User.POAStatus = (response.data.others.POA) == 2 ? false : true; 
        clsGlobal.User.GTDDays = response.data.others.nGTDMaxDays;
        clsGlobal.User.DefaultGTDDays = response.data.others.nGTDDefault;
        clsGlobal.User.OCToken=response.data.others.ocToken;
        clsGlobal.User.managerIP=response.data.others.managerIP;
        } 
      } catch (error) {
        console.log("error in usercode groupid setting in login response."+error);
      }
      
      clsGlobal.User.sessionId = response.data.access_token;
      clsGlobal.User.cftAllowed = mktSegAllowed;//response.data.cftAllowed;
      clsGlobal.User.logonSuccessFlag = response.data.logonSuccess;
      clsGlobal.User.lastLoginTime = response.data.login_time;
      clsGlobal.User.viewAllowed = mktSegAllowed;//response.data.viewAllowed;
      clsGlobal.User.loginAllowed = mktSegAllowed;//response.data.loginAllowed;
      clsGlobal.User.brodcastSocketUrl = response.data.others.broadCastSocket || "ws://203.114.240.122:4510";//203.114.240.122
      clsGlobal.User.userIdHexaValue = clsCommonMethods.EncrypQueryString(clsGlobal.User.userId); 
      clsGlobal.User.exchangesList = response.data.exchanges;
      clsGlobal.User.productTypesList = response.data.product_types;
      clsGlobal.User.BracketOrderAllowed = response.data.bracketOrderAllowed;
      clsGlobal.User.TSLAllowed = response.data.trailingSLAllowed;
      //clsGlobal.User.viewAllowed = response.data.viewAllowed;
      clsGlobal.User.OEProductString = response.data.product_types;
      clsGlobal.profileScrip.Clear();
      clsGlobal.User.Holding =[];
      clsGlobal.User.HoldingScrips =[];
      clsGlobal.userSelectedWatchlist = undefined;

      await this.appSync.signingCognitoForTradingUser();
      this.getIntropDetails();
      //This will start timer for getevents. default time is 5 min.
      clsGlobal.pubsub.publish('STARTWHATSHOTDATA');
      //This will register topic on name of user will be used for targeted recommendation.
      clsGlobal.pubsub.publish('TOPIC_SUBSCRIBE',clsGlobal.User.userId);
      //25043,25035,25034,25039,25014,25033,25000,
      //reco 
      clsGlobal.User.NewsCategories.split(',').forEach(e=>{
        if(e) 
        clsGlobal.pubsub.publish('TOPIC_SUBSCRIBE',e); 
      });
      clsGlobal.pubsub.publish('MENU_DYNAMIC');
       //this.commService.loadCommunicator();//broadcast connection.
      this.subscribeAlerts();
      // TODO    // clsGlobal.User.lastLoginTime =  clsTradingMethods.getLastLogonTime(response.data.lastLogonTime, undefined);
      //in both signin or mpin or fingerprint login this will init.
      this.commService.loadCommunicator();
      clsGlobal.IsGuestUser = false; //user is register user.
      //signing to congnitor
      clsGlobal.watchlistSyncDone =false;
      clsGlobal.ExchManager = new clsExchManager(this.http, null);

      if(clsGlobal.User.POAStatus == false){

        this.tranServ.getDPDetails().then((dpDetails:any)=>{
            //console.log("DP Details: ", dpDetails);
            let arrUserDPDetails = [];
            dpDetails.data.URL = clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_EDIS_REQUEST_NEWNETNET_URL) ? clsGlobal.dConfigMaster.getItem(clsAppConfigConstants.APP_EDIS_REQUEST_NEWNETNET_URL) : "";
            arrUserDPDetails.push(dpDetails.data);

            clsGlobal.User.DPDetails = arrUserDPDetails;
        }).catch(error=>{

        });
      }

      /*
      const listener = Hub.listen("datastore", async hubData => {

        if (hubData.payload.event === "ready") {

          listener();

          if (reqLogin.login_type == "PASSWORD" || reqLogin.login_type == "") {
            //Localstorage update.
            let objMPIN: any = {
              userId: clsGlobal.User.userId,
              groupId: clsGlobal.User.groupId,
              userName: clsGlobal.User.userName,
              MPINEnable: 'N',
              Fingerprint: 'N',
              mpinInvalidAttempt: 0
            };

            if (response.data.mpin_enabled != undefined && response.data.mpin_enabled == true) {
              objMPIN.MPINEnable = 'Y';
              objMPIN.mpinInvalidAttempt = response.data.mpinInvalidAttempt || 0;
            }
            //LOCAL STORAGE.
            if (response.data.fingerprint_enabled != undefined && response.data.fingerprint_enabled == true) {
              objMPIN.Fingerprint = 'Y';
            }
            this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
            clsGlobal.User.isGuestUser = false;
            if (response.data.mpin_enabled != undefined && response.data.mpin_enabled == true) {
              this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
            }
            else { //IT is manadatory to set MPIN
              this.navCtrl.navigateRoot(['/' + clsConstants.C_S_PAGE_ROUTE_SETMPIN, { id: '' }]);
            }
          }
          else if (reqLogin.login_type == "MPIN" || reqLogin.login_type == "FINGERPRINT") {
            await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {
              if (item != undefined) {
                let objMPIN: any = JSON.parse(item);
                // objMPIN.LastLoginTime = lastLogonTime;
                objMPIN.mpinInvalidAttempt = 0;
                if (response.data.fingerprint_enabled != undefined && response.data.fingerprint_enabled == true) {
                  objMPIN.Fingerprint = 'Y'; ///this is new key.
                } else {
                  objMPIN.Fingerprint = 'N';
                }
                this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
              }
            }, error => {
              console.log('Error while retrieving local storage details.');
              clsGlobal.logManager.writeErrorLog("MpinloginPage", "setUserDetails_2", error.message);
            });
            //this.navCtrl.setRoot(DashboardPage);
            this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
            //this.clearFields();
          }

        }

      });

      */

      if (reqLogin.login_type == "PASSWORD" || reqLogin.login_type == "") {
        //Localstorage update.
        let objMPIN: any = {
          userId: clsGlobal.User.userId,
          groupId: clsGlobal.User.groupId,
          userName: clsGlobal.User.userName,
          MPINEnable: 'N',
          Fingerprint: 'N',
          mpinInvalidAttempt: 0
        };

        if (response.data.mpin_enabled != undefined && response.data.mpin_enabled == true) {
          objMPIN.MPINEnable = 'Y';
          objMPIN.mpinInvalidAttempt = response.data.mpinInvalidAttempt || 0;
        }
        //LOCAL STORAGE.
        if (response.data.fingerprint_enabled != undefined && response.data.fingerprint_enabled == true) {
          objMPIN.Fingerprint = 'Y';
        }
        this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
        clsGlobal.User.isGuestUser = false;
        if (response.data.mpin_enabled != undefined && response.data.mpin_enabled == true) {
          this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
        }
        else { //IT is manadatory to set MPIN
          this.navCtrl.navigateRoot(['/' + clsConstants.C_S_PAGE_ROUTE_SETMPIN, { id: '' }]);
        }
      }
      else if (reqLogin.login_type == "MPIN" || reqLogin.login_type == "FINGERPRINT") {
        await this.objStorage.getItem(clsConstants.LOCAL_STORAGE_USER_DETAILS).then((item: any) => {
          if (item != undefined) {
            let objMPIN: any = JSON.parse(item);
            // objMPIN.LastLoginTime = lastLogonTime;
            objMPIN.mpinInvalidAttempt = 0;
            if (response.data.fingerprint_enabled != undefined && response.data.fingerprint_enabled == true) {
              objMPIN.Fingerprint = 'Y'; ///this is new key.
            } else {
              objMPIN.Fingerprint = 'N';
            }
            this.objStorage.setObject(clsConstants.LOCAL_STORAGE_USER_DETAILS, objMPIN);
          }
        }, error => {
          console.log('Error while retrieving local storage details.');
          clsGlobal.logManager.writeErrorLog("MpinloginPage", "setUserDetails_2", error.message);
        });
        //this.navCtrl.setRoot(DashboardPage);
        this.navCtrl.navigateRoot('/' + clsConstants.C_S_PAGE_ROUTE_WATCHLIST);
        //this.clearFields();
      }
      let appRegistrationData: any = {};
      appRegistrationData.Type = 3; //2--> user login.
      appRegistrationData.userId = clsGlobal.User.userId;
      appRegistrationData.groupId = clsGlobal.User.groupId;
      appRegistrationData.userType = 'R';
      appRegistrationData.email = '';
      appRegistrationData.mobile = '';
      appRegistrationData.deviceType = clsGlobal.applicationType;
      appRegistrationData.pluginData = clsPluginConstants.GetPluginDetails();
      this.http.postWithHeaders(clsGlobal.VirtualDirectory, clsGlobal.Nontransactional + clsGlobal.LocalComId + 'v1/setRegDetail', appRegistrationData).subscribe(((respData: any) => {
        if (!respData.status) {
          //this.toastProvider.showAtBottom(respData.result.message);
        }
      }), error => {
        //this.toastProvider.showAtBottom(error);
        console.log("Error in segRegDetails." + JSON.stringify(error));
      });

      this.http.getJson(clsGlobal.VirtualDirectory, clsGlobal.Authentication + "v1/user/profile").subscribe(data => {
        let profileDetails: any = data;
        if (profileDetails.status == "success") {
          //clsGlobal.User.userName = profileDetails.data.user_name;//already set in login response
          clsGlobal.User.email = profileDetails.data.email;
          clsGlobal.User.mobile = profileDetails.data.mobile_no;
          //this.pan =clsGlobal.User.PAN= profileDetails.data.pan;
          clsGlobal.User.address = profileDetails.data.address;
          clsGlobal.User.bankdetails = profileDetails.data.bank_details;
        }
        else {
          //this.toastProvider.showAtBottom("Error in getting profile data");
        }
      }, error => {
        //this.toastProvider.showAtBottom("Error in getting profile data");
      });

    } catch (error) {
      clsGlobal.logManager.writeErrorLog("MpinloginPage", "setUserDetails_3", error.message);
    }
  }

  logout() {
    clsGlobal.watchlistSyncDone=false;
    clsGlobal.pubsub.publish('STOPWHATSHOTDATA');
    return new Promise((resolve, reject) => {
      this.restApiService.getLogoutResponse().then((resp: any) => {
        console.log(resp)
        let msgLogin: any = {};
        //this.socketService.disconnectSocket();
        if (this.alertSubscription != undefined)
          this.alertSubscription.unsubscribe();
        this.processLogoutResponse(resp);
        resolve(resp);
      },
        (error) => {
          reject(error)
          // this.toastProvider.showAtBottom(error);
        });
    });
  }

  //process log out response.
  private processLogoutResponse(logoutres: any) {
    console.log("Response " + logoutres);
  }

  getUserProfile() {
    return new Promise((resolve, reject) => {
      this.restApiService.getProfileResponse().then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error)
        });
    });
  }

  getUserInfo(userId) {
    return new Promise((resolve, reject) => {
      this.restApiService.getUserDetailsResponse(userId).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error)
        });
    });
  }

  getBalanceInfo() {
    return new Promise((resolve, reject) => {
      this.restApiService.getUserBalanceResponse().then((resp: any) => {
        if (resp.status != undefined && resp.status == "success") {
          if (resp.data != undefined)
            clsGlobal.User.fundsDetails = resp.data;
        }
        console.log(JSON.stringify(resp));
        resolve(resp);
      },
        (error) => {
          reject(error)
        });
    });
  }

  userRegistration(reqRegistration) {
    return new Promise((resolve, reject) => {
      this.restApiService.getRegistrationResponse(reqRegistration).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  resetMpinOtpGenerate(reqResetMpinOtp) {
    return new Promise((resolve, reject) => {
      this.restApiService.getForgotMpinOtpResponse(reqResetMpinOtp).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  forgotMpinChange(reqResetMpin) {
    return new Promise((resolve, reject) => {
      this.restApiService.getForgotMpinResponse(reqResetMpin).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }
  forgotPasswordChange(reqResetPassword) {
    return new Promise((resolve, reject) => {
      this.restApiService.getForgotPasswordResponse(reqResetPassword).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }
  resetPasswordOtpGenerate(reqResetPasswordOtp) {
    return new Promise((resolve, reject) => {
      this.restApiService.getForgotPasswordOtpResponse(reqResetPasswordOtp).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  changeMPIN(reqChangeMPIN) {
    return new Promise((resolve, reject) => {
      this.restApiService.getChangeMPINResponse(reqChangeMPIN).then((resp: any) => {
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  changePassword(reqChangePassword) {
    return new Promise((resolve, reject) => {
      this.restApiService.getChangePasswordResponse(reqChangePassword).then((resp: any) => {
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  fingerprintEnable(reqfingerprintEnable) {
    return new Promise((resolve, reject) => {
      this.restApiService.getfingerprintEnableResponse(reqfingerprintEnable).then((resp: any) => {
        console.log(resp)
        resolve(resp);
      },
        (error) => {
          reject(error);
        });
    });
  }

  private getIntropDetails(){
    this.tranServ.getIntropConfiguration().then((intropConfigResponse: any) => {
      if (intropConfigResponse.status == 'success') {
        clsGlobal.User.interopSettingDetails = intropConfigResponse.data;
        
      } 
    }, error => {

    });

  }
}
