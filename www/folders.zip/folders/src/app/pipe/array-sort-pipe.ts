import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "sort"
})
export class ArraySortPipe  implements PipeTransform {
  transform(array: any, field: string, orderDesc: boolean = false): any[] {

    var fields =field.split('.');

    if (!Array.isArray(array)) {
      return;
    }

    array.sort((a: any, b: any) => {
      if(fields.length == 1)
      {
      if (a[field] < b[field]) {
        return (orderDesc)?1:-1;
      } else if (a[field] > b[field]) {
        return (orderDesc)?-1:1;
      } else {
        return 0;
      }
    }else{
      if (a[fields[0]][fields[1]] < b[fields[0]][fields[1]]) {
        return (orderDesc)?1:-1;
      } else if (a[fields[0]][fields[1]] > b[fields[0]][fields[1]]) {
        return (orderDesc)?-1:1;
      } else {
        return 0;
      }
    }
    });
    return array;
  }
}
